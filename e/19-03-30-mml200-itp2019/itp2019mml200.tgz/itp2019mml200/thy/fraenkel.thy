theory fraenkel
  imports domain_1 setwiseo
begin
(*begin*)
reserve B for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve A, X, x for "setHIDDENM2"
theorem fraenkel_sch_1:
  fixes Af0 Ff1 Pp1 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for v be ElementSUBSET-1M1-of Af0 holds Pp1(v) implies Qp1(v)"
  shows "{Ff1(v) where v be ElementSUBSET-1M1-of Af0 : Pp1(v) } c=TARSKIR1 {Ff1(u) where u be ElementSUBSET-1M1-of Af0 : Qp1(u) }"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(v9) where v9 be ElementSUBSET-1M1-of Af0 : Pp1(v9) } implies x inHIDDENR3 {Ff1(u) where u be ElementSUBSET-1M1-of Af0 : Qp1(u) }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {Ff1(v9) where v9 be ElementSUBSET-1M1-of Af0 : Pp1(v9) }"
      then obtain v where
        [ty]:"v be ElementSUBSET-1M1-of Af0" and 
        A2: "x =HIDDENR1 Ff1(v)"and A3: "Pp1(v)"
         sorry
      have "Qp1(v)"
        using A1 A3 sorry
      thus "x inHIDDENR3 {Ff1(u) where u be ElementSUBSET-1M1-of Af0 : Qp1(u) }"
        using A2 sorry
    qed "sorry"
    thus "{Ff1(v) where v be ElementSUBSET-1M1-of Af0 : Pp1(v) } c=TARSKIR1 {Ff1(u) where u be ElementSUBSET-1M1-of Af0 : Qp1(u) }"
      using tarski_def_3 sorry
  qed

theorem fraenkel_sch_2:
  fixes Af0 Bf0 Ff2 Pp2 Qp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Pp2(u,v) implies Qp2(u,v)"
  shows "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : Pp2(u9,v9) } implies x inHIDDENR3 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : Pp2(u9,v9) }"
      then obtain u v where
        [ty]:"u be ElementSUBSET-1M1-of Af0" "v be ElementSUBSET-1M1-of Bf0" and 
        A2: "x =HIDDENR1 Ff2(u,v)"and A3: "Pp2(u,v)"
         sorry
      have "Qp2(u,v)"
        using A1 A3 sorry
      thus "x inHIDDENR3 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
        using A2 sorry
    qed "sorry"
    thus "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
      using tarski_def_3 sorry
  qed

theorem fraenkel_sch_3:
  fixes Bf0 Ff1 Pp1 Qp1 
  assumes
[ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: " for v be ElementSUBSET-1M1-of Bf0 holds Pp1(v) iff Qp1(v)"
  shows "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) }"
  proof-
    let ?A = "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
    let ?B = "{Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) }"
    have A2: " for v be ElementSUBSET-1M1-of Bf0 holds Pp1(v) implies Qp1(v)"
      using A1 sorry
    have "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) } & {Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
    proof(rule conjMI)
      show "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) }"
        using fraenkel_sch_1 A2 sorry
      have A3: " for v be ElementSUBSET-1M1-of Bf0 holds Qp1(v) implies Pp1(v)"
        using A1 sorry
      show "{Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
        using fraenkel_sch_1 A3 sorry
    qed
    thus "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Ff1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Qp1(v2) }"
      using xboole_0_def_10 sorry
  qed

theorem fraenkel_sch_4:
  fixes Af0 Bf0 Ff2 Pp2 Qp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Pp2(u,v) iff Qp2(u,v)"
  shows "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
  proof-
    let ?B = "{Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
    let ?A = "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
    have A2: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Pp2(u,v) implies Qp2(u,v)"
      using A1 sorry
    have "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) } & {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) } c=TARSKIR1 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
    proof(rule conjMI)
      show "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
        using fraenkel_sch_2 A2 sorry
      have A3: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Qp2(u,v) implies Pp2(u,v)"
        using A1 sorry
      show "{Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) } c=TARSKIR1 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
        using fraenkel_sch_2 A3 sorry
    qed
    thus "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
      using xboole_0_def_10 sorry
  qed

theorem fraenkel_sch_5:
  fixes Bf0 Ff1 Gf1 Pp1 
  assumes
[ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: " for v be ElementSUBSET-1M1-of Bf0 holds Ff1(v) =HIDDENR1 Gf1(v)"
  shows "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
  proof-
    let ?X = "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
    let ?Y = "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
    have A2: "?Y c=TARSKIR1 ?X"
    proof-
      have "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } implies x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?Y"
          then obtain v1 where
            [ty]:"v1 be ElementSUBSET-1M1-of Bf0" and 
            A3: "x =HIDDENR1 Gf1(v1)"and A4: "Pp1(v1)"
             sorry
          have "x =HIDDENR1 Ff1(v1)"
            using A1 A3 sorry
          thus "x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
            using A4 sorry
        qed "sorry"
        thus "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?X c=TARSKIR1 ?Y"
    proof-
      have "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } implies x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then obtain v1 where
            [ty]:"v1 be ElementSUBSET-1M1-of Bf0" and 
            A5: "x =HIDDENR1 Ff1(v1)"and A6: "Pp1(v1)"
             sorry
          have "x =HIDDENR1 Gf1(v1)"
            using A1 A5 sorry
          thus "x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
            using A6 sorry
        qed "sorry"
        thus "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
      using A2 sorry
  qed

theorem fraenkel_sch_6:
  fixes Bf0 Ff1 Gf1 Pp1 
  assumes
[ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
   A1: " for v be ElementSUBSET-1M1-of Bf0 holds Pp1(v) implies Ff1(v) =HIDDENR1 Gf1(v)"
  shows "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
  proof-
    let ?X = "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
    let ?Y = "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
    have A2: "?Y c=TARSKIR1 ?X"
    proof-
      have "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } implies x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?Y"
          then obtain v1 where
            [ty]:"v1 be ElementSUBSET-1M1-of Bf0" and 
            A3: "x =HIDDENR1 Gf1(v1)"and A4: "Pp1(v1)"
             sorry
          have "x =HIDDENR1 Ff1(v1)"
            using A1 A3 A4 sorry
          thus "x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
            using A4 sorry
        qed "sorry"
        thus "{Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) } c=TARSKIR1 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?X c=TARSKIR1 ?Y"
    proof-
      have "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } implies x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then obtain v1 where
            [ty]:"v1 be ElementSUBSET-1M1-of Bf0" and 
            A5: "x =HIDDENR1 Ff1(v1)"and A6: "Pp1(v1)"
             sorry
          have "x =HIDDENR1 Gf1(v1)"
            using A1 A5 A6 sorry
          thus "x inHIDDENR3 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
            using A6 sorry
        qed "sorry"
        thus "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } c=TARSKIR1 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff1(v1) where v1 be ElementSUBSET-1M1-of Bf0 : Pp1(v1) } =XBOOLE-0R4 {Gf1(v2) where v2 be ElementSUBSET-1M1-of Bf0 : Pp1(v2) }"
      using A2 sorry
  qed

theorem fraenkel_sch_7:
  fixes Af0 Bf0 Ff2 Gf2 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Gf2(x1,x2) be objectHIDDENM1" and
   A1: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Ff2(u,v) =HIDDENR1 Gf2(u,v)"
  shows "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
  proof-
    let ?Y = "{Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
    let ?X = "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
    have A2: "?Y c=TARSKIR1 ?X"
    proof-
      have "{Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) } c=TARSKIR1 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) } implies x inHIDDENR3 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?Y"
          then obtain u1 v1 where
            [ty]:"u1 be ElementSUBSET-1M1-of Af0" "v1 be ElementSUBSET-1M1-of Bf0" and 
            A3: "x =HIDDENR1 Gf2(u1,v1)"and A4: "Pp2(u1,v1)"
             sorry
          have "x =HIDDENR1 Ff2(u1,v1)"
            using A1 A3 sorry
          thus "x inHIDDENR3 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
            using A4 sorry
        qed "sorry"
        thus "{Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) } c=TARSKIR1 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "?X c=TARSKIR1 ?Y"
    proof-
      have "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } implies x inHIDDENR3 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then obtain u1 v1 where
            [ty]:"u1 be ElementSUBSET-1M1-of Af0" "v1 be ElementSUBSET-1M1-of Bf0" and 
            A5: "x =HIDDENR1 Ff2(u1,v1)"and A6: "Pp2(u1,v1)"
             sorry
          have "x =HIDDENR1 Gf2(u1,v1)"
            using A1 A5 sorry
          thus "x inHIDDENR3 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
            using A6 sorry
        qed "sorry"
        thus "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Gf2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
      using A2 sorry
  qed

theorem fraenkel_sch_8:
  fixes Af0 Bf0 Ff2 Pp2 Qp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Pp2(u,v) iff Qp2(u,v)" and
   A2: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Ff2(u,v) =HIDDENR1 Ff2(v,u)"
  shows "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Ff2(v2,u2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
  proof-
    have A3: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Qp2(u,v) implies Pp2(u,v)"
      using A1 sorry
    have A4: "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Qp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Pp2(u2,v2) }"
      using fraenkel_sch_2 A3 sorry
    let ?H = "\<lambda>Lamb1. \<lambda>Lamb2. Ff2(Lamb2,Lamb1)"
    have A5: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Pp2(u,v) implies Qp2(u,v)"
      using A1 sorry
    have A6: "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } c=TARSKIR1 {Ff2(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
      using fraenkel_sch_2 A5 sorry
    have A7: " for u be ElementSUBSET-1M1-of Af0 holds  for v be ElementSUBSET-1M1-of Bf0 holds Ff2(u,v) =HIDDENR1 ?H(u,v)"
      using A2 sorry
    have "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Qp2(u1,v1) } =XBOOLE-0R4 {?H(u2,v2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
      using fraenkel_sch_7 A7 sorry
    thus "{Ff2(u1,v1) where u1 be ElementSUBSET-1M1-of Af0, v1 be ElementSUBSET-1M1-of Bf0 : Pp2(u1,v1) } =XBOOLE-0R4 {Ff2(v2,u2) where u2 be ElementSUBSET-1M1-of Af0, v2 be ElementSUBSET-1M1-of Bf0 : Qp2(u2,v2) }"
      using A6 A4 sorry
  qed

mtheorem fraenkel_th_1:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(A,B) holds  for G be FunctionFUNCT-2M1-of(A,B) holds  for X be setHIDDENM2 holds F  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> G  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X implies ( for x be ElementSUBSET-1M1-of A holds x inTARSKIR2 X implies F .FUNCT-1K1 x =XBOOLE-0R4 G .FUNCT-1K1 x)"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for F be FunctionFUNCT-2M1-of(A,B) holds  for G be FunctionFUNCT-2M1-of(A,B) holds  for X be setHIDDENM2 holds F  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> G  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X implies ( for x be ElementSUBSET-1M1-of A holds x inTARSKIR2 X implies F .FUNCT-1K1 x =HIDDENR1 G .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix F assume [ty]: "F be FunctionFUNCT-2M1-of(A,B)"
    fix G assume [ty]: "G be FunctionFUNCT-2M1-of(A,B)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "F  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> G  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
    assume A2: "x inTARSKIR2 X"
    then have "F .FUNCT-1K1 x =HIDDENR1 (G  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X).FUNCT-1K1 x"
      using A1 funct_1_th_49 sorry
    also have "... = G .FUNCT-1K1 x"
      using A2 funct_1_th_49 sorry
    finally show "F .FUNCT-1K1 x =HIDDENR1 G .FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fraenkel_th_2:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds FuncsFUNCT-2K1(A,B) c=TARSKIR1 boolZFMISC-1K1 ([:ZFMISC-1K2 A,B :])"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K1(A,B) implies x inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 A,B :])"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 FuncsFUNCT-2K1(A,B)"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "x =HIDDENR1 f"and A2: "domRELAT-1K1 f =XBOOLE-0R4 A"and A3: "rngFUNCT-1K2 f c=TARSKIR1 B"
      using funct_2_def_2 sorry
    have A4: "f c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :]"
      using relat_1_th_7 sorry
    have "[:ZFMISC-1K2 domRELAT-1K1 f,rngFUNCT-1K2 f :] c=RELAT-1R2 [:ZFMISC-1K2 A,B :]"
      using A2 A3 zfmisc_1_th_95 sorry
    then have "f c=RELAT-1R2 [:ZFMISC-1K2 A,B :]"
      using A4 sorry
    thus "x inHIDDENR3 boolZFMISC-1K1 ([:ZFMISC-1K2 A,B :])"
      using A1 sorry
  qed "sorry"
  thus "FuncsFUNCT-2K1(A,B) c=TARSKIR1 boolZFMISC-1K1 ([:ZFMISC-1K2 A,B :])"
    using tarski_def_3 sorry
qed "sorry"

mtheorem fraenkel_th_3:
" for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 A) & Y c=TARSKIR1 B implies ( for f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y) holds f be PartFuncPARTFUN1M1-of(A,B))"
proof-
  have " for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1 & (X c=TARSKIR1 A & Y c=TARSKIR1 B) implies ( for f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y) holds f be PartFuncPARTFUN1M1-of(A,B))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI)
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X c=TARSKIR1 A"
      and A3: "Y c=TARSKIR1 B"
    fix f assume [ty]: "f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y)"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A4: "f =XBOOLE-0R4 g"and A5: "domRELAT-1K1 g =XBOOLE-0R4 X"and A6: "rngFUNCT-1K2 g c=TARSKIR1 Y"
      using A1 funct_2_def_2 sorry
    have "rngFUNCT-1K2 g c=TARSKIR1 B"
      using A3 A6 sorry
    thus "f be PartFuncPARTFUN1M1-of(A,B)"
      using A2 A4 A5 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem fraenkel_sch_9:
  fixes Af0 Bf0 Xf0 ff0 gf0 Pp1 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty]: "ff0 be FunctionFUNCT-2M1-of(Af0,Bf0)" and
  [ty]: "gf0 be FunctionFUNCT-2M1-of(Af0,Bf0)" and
   A1: "ff0  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =RELSET-1R2\<^bsub>(Af0,Bf0)\<^esub> gf0  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0" and
   A2: " for u be ElementSUBSET-1M1-of Af0 holds u inTARSKIR2 Xf0 implies (Pp1(u) iff Qp1(u))"
  shows "{ff0 .FUNCT-1K1 u9 where u9 be ElementSUBSET-1M1-of Af0 : Pp1(u9) & u9 inTARSKIR2 Xf0 } =XBOOLE-0R4 {gf0 .FUNCT-1K1 v9 where v9 be ElementSUBSET-1M1-of Af0 : Qp1(v9) & v9 inTARSKIR2 Xf0 }"
  proof-
    let ?F = "\<lambda>Lamb1. ff0 .FUNCT-1K1 Lamb1"
    let ?G = "\<lambda>Lamb1. gf0 .FUNCT-1K1 Lamb1"
    let ?PP = "\<lambda>Lamb1. Pp1(Lamb1) & Lamb1 inTARSKIR2 Xf0"
    let ?QQ = "\<lambda>Lamb1. Qp1(Lamb1) & Lamb1 inTARSKIR2 Xf0"
    let ?C = "{?G(v9) where v9 be ElementSUBSET-1M1-of Af0 : ?PP(v9) }"
    have A3: " for v be ElementSUBSET-1M1-of Af0 holds ?PP(v) iff ?QQ(v)"
      using A2 sorry
    have A4: "?C =XBOOLE-0R4 {?G(v9) where v9 be ElementSUBSET-1M1-of Af0 : ?QQ(v9) }"
      using fraenkel_sch_3 A3 sorry
    have A5: " for v be ElementSUBSET-1M1-of Af0 holds ?PP(v) implies ?F(v) =XBOOLE-0R4 ?G(v)"
      using A1 fraenkel_th_1 sorry
    have "{?F(u9) where u9 be ElementSUBSET-1M1-of Af0 : ?PP(u9) } =XBOOLE-0R4 ?C"
      using fraenkel_sch_6 A5 sorry
    thus "{ff0 .FUNCT-1K1 u9 where u9 be ElementSUBSET-1M1-of Af0 : Pp1(u9) & u9 inTARSKIR2 Xf0 } =XBOOLE-0R4 {gf0 .FUNCT-1K1 v9 where v9 be ElementSUBSET-1M1-of Af0 : Qp1(v9) & v9 inTARSKIR2 Xf0 }"
      using A4 sorry
  qed

theorem fraenkel_sch_10:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows "{x where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 Af0"
  proof-
    have "{x where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } be SubsetSUBSET-1M2-of Af0"
      using domain_1_sch_7 sorry
    thus "{x where x be ElementSUBSET-1M1-of Af0 : Pp1(x) } c=TARSKIR1 Af0"
       sorry
  qed

theorem fraenkel_sch_11:
  fixes Af0 Bf0 Ff2 Pp2 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for st1 be setHIDDENM2 holds st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } implies Qp1(st1)"
  shows " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds Pp2(s,t) implies Qp1(Ff2(s,t))"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be ElementSUBSET-1M1-of Af0"
    fix t assume [ty]: "t be ElementSUBSET-1M1-of Bf0"
    assume "Pp2(s,t)"
    then have "Ff2(s,t) inHIDDENR3 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) }"
       sorry
    thus "Qp1(Ff2(s,t))"
      using A1 sorry
  qed "sorry"

theorem fraenkel_sch_12:
  fixes Af0 Bf0 Ff2 Pp2 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds Pp2(s,t) implies Qp1(Ff2(s,t))"
  shows " for st1 be setHIDDENM2 holds st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } implies Qp1(st1)"
  proof(rule ballI,rule impI)
    fix st1 assume [ty]: "st1 be setHIDDENM2"
    assume "st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) }"
    then have " ex s1 be ElementSUBSET-1M1-of Af0 st  ex t1 be ElementSUBSET-1M1-of Bf0 st st1 =HIDDENR1 Ff2(s1,t1) & Pp2(s1,t1)"
       sorry
    thus "Qp1(st1)"
      using A1 sorry
  qed "sorry"

theorem fraenkel_sch_13:
  fixes Af0 Bf0 Cf0 Ff2 Pp2 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Cf0"
  shows "{st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } =XBOOLE-0R4 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
  proof-
    have "{st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } c=TARSKIR1 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) } & {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) } c=TARSKIR1 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) }"
    proof(rule conjMI)
      show "{st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } c=TARSKIR1 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } implies x inHIDDENR3 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) }"
          then obtain st1 where
            [ty]:"st1 be ElementSUBSET-1M1-of Cf0" and 
            A1: "x =HIDDENR1 st1"and A2: "st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) }"and A3: "Qp1(st1)"
             sorry
          have " ex s1 be ElementSUBSET-1M1-of Af0 st  ex t1 be ElementSUBSET-1M1-of Bf0 st st1 =XBOOLE-0R4 Ff2(s1,t1) & Pp2(s1,t1)"
            using A2 sorry
          thus "x inHIDDENR3 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
            using A1 A3 sorry
        qed "sorry"
        thus "{st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } c=TARSKIR1 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) } implies x inHIDDENR3 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
        then obtain s2 t2 where
          [ty]:"s2 be ElementSUBSET-1M1-of Af0" "t2 be ElementSUBSET-1M1-of Bf0" and 
          A4: "x =HIDDENR1 Ff2(s2,t2)"and A5: "Pp2(s2,t2)"and A6: "Qp1(Ff2(s2,t2))"
           sorry
        have "Ff2(s2,t2) inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) }"
          using A5 sorry
        thus "x inHIDDENR3 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) }"
          using A4 A6 sorry
      qed "sorry"
      thus "{Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) } c=TARSKIR1 {st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) }"
        using tarski_def_3 sorry
    qed
    thus "{st1 where st1 be ElementSUBSET-1M1-of Cf0 : st1 inTARSKIR2 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Pp2(s1,t1) } & Qp1(st1) } =XBOOLE-0R4 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Pp2(s2,t2) & Qp1(Ff2(s2,t2)) }"
      using xboole_0_def_10 sorry
  qed

theorem fraenkel_sch_14:
  fixes Af0 Ff1 Pp1 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows "{Ff1(s) where s be ElementSUBSET-1M1-of Af0 : s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s) } =XBOOLE-0R4 {Ff1(s2) where s2 be ElementSUBSET-1M1-of Af0 : Qp1(s2) & Pp1(s2) }"
  proof-
    let ?QQ = "\<lambda>Lamb1. Qp1(Lamb1) & Pp1(Lamb1)"
    let ?PP = "\<lambda>Lamb1. Lamb1 inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(Lamb1)"
    have A1: " for s be ElementSUBSET-1M1-of Af0 holds ?PP(s) iff ?QQ(s)"
    proof-
      have " for s be ElementSUBSET-1M1-of Af0 holds  not ((s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s)) &  not (Qp1(s) & Pp1(s))) &  not ((Qp1(s) & Pp1(s)) &  not (s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s)))"
      proof(rule ballI)
        fix s assume [ty]: "s be ElementSUBSET-1M1-of Af0"
        have "s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } implies Qp1(s)"
        proof(rule impI)
          assume "s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) }"
          then have " ex s1 be ElementSUBSET-1M1-of Af0 st s =XBOOLE-0R4 s1 & Qp1(s1)"
             sorry
          thus "Qp1(s)"
             sorry
        qed
        thus " not ((s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s)) &  not (Qp1(s) & Pp1(s))) &  not ((Qp1(s) & Pp1(s)) &  not (s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show "{Ff1(s) where s be ElementSUBSET-1M1-of Af0 : s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp1(s) } =XBOOLE-0R4 {Ff1(s2) where s2 be ElementSUBSET-1M1-of Af0 : Qp1(s2) & Pp1(s2) }"
      using fraenkel_sch_3 A1 sorry
  qed

theorem fraenkel_sch_15:
  fixes Af0 Bf0 Ff2 Pp2 Qp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1"
  shows "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t) } =XBOOLE-0R4 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Qp1(s2) & Pp2(s2,t2) }"
  proof-
    let ?QQ = "\<lambda>Lamb1. \<lambda>Lamb2. Qp1(Lamb1) & Pp2(Lamb1,Lamb2)"
    let ?PP = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(Lamb1,Lamb2)"
    have A1: " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds ?PP(s,t) iff ?QQ(s,t)"
    proof-
      have " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds  not ((s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t)) &  not (Qp1(s) & Pp2(s,t))) &  not ((Qp1(s) & Pp2(s,t)) &  not (s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t)))"
      proof(rule ballI,rule ballI)
        fix s assume [ty]: "s be ElementSUBSET-1M1-of Af0"
        fix t assume [ty]: "t be ElementSUBSET-1M1-of Bf0"
        have "s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } implies Qp1(s)"
        proof(rule impI)
          assume "s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) }"
          then have " ex s1 be ElementSUBSET-1M1-of Af0 st s =XBOOLE-0R4 s1 & Qp1(s1)"
             sorry
          thus "Qp1(s)"
             sorry
        qed
        thus " not ((s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t)) &  not (Qp1(s) & Pp2(s,t))) &  not ((Qp1(s) & Pp2(s,t)) &  not (s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t)))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : s inTARSKIR2 {s1 where s1 be ElementSUBSET-1M1-of Af0 : Qp1(s1) } & Pp2(s,t) } =XBOOLE-0R4 {Ff2(s2,t2) where s2 be ElementSUBSET-1M1-of Af0, t2 be ElementSUBSET-1M1-of Bf0 : Qp1(s2) & Pp2(s2,t2) }"
      using fraenkel_sch_4 A1 sorry
  qed

theorem fraenkel_sch_16:
  fixes Af0 Bf0 Ff2 Pp2 Qp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds Pp2(s,t) implies ( ex s9 be ElementSUBSET-1M1-of Af0 st Qp2(s9,t) & Ff2(s,t) =HIDDENR1 Ff2(s9,t))"
  shows "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Pp2(s,t) } c=TARSKIR1 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Qp2(s1,t1) }"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Pp2(s,t) } implies x inHIDDENR3 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Qp2(s1,t1) }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Pp2(s,t) }"
      then obtain s t where
        [ty]:"s be ElementSUBSET-1M1-of Af0" "t be ElementSUBSET-1M1-of Bf0" and 
        A2: "x =HIDDENR1 Ff2(s,t)"and A3: "Pp2(s,t)"
         sorry
      have " ex s9 be ElementSUBSET-1M1-of Af0 st Qp2(s9,t) & Ff2(s,t) =HIDDENR1 Ff2(s9,t)"
        using A1 A3 sorry
      thus "x inHIDDENR3 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Qp2(s1,t1) }"
        using A2 sorry
    qed "sorry"
    thus "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Pp2(s,t) } c=TARSKIR1 {Ff2(s1,t1) where s1 be ElementSUBSET-1M1-of Af0, t1 be ElementSUBSET-1M1-of Bf0 : Qp2(s1,t1) }"
      using tarski_def_3 sorry
  qed

theorem fraenkel_sch_17:
  fixes Df0 Af0 Ff1 Pp1 
  assumes
[ty]: "Df0 be setHIDDENM2" and
  [ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows "{Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Ff1(y) inHIDDENR3 Af0 & Pp1(y) } c=TARSKIR1 Af0"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Ff1(y) inHIDDENR3 Af0 & Pp1(y) } implies x inHIDDENR3 Af0"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Ff1(y) inHIDDENR3 Af0 & Pp1(y) }"
      then have " ex y be ElementSUBSET-1M1-of Df0 st (x =HIDDENR1 Ff1(y) & Ff1(y) inHIDDENR3 Af0) & Pp1(y)"
         sorry
      thus "x inHIDDENR3 Af0"
         sorry
    qed "sorry"
    thus "{Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Ff1(y) inHIDDENR3 Af0 & Pp1(y) } c=TARSKIR1 Af0"
      using tarski_def_3 sorry
  qed

theorem fraenkel_sch_18:
  fixes Df0 Af0 Ff1 Qp1 
  assumes
[ty]: "Df0 be setHIDDENM2" and
  [ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows "{Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Qp1(y) &  not Ff1(y) inHIDDENR3 Af0 } missesXBOOLE-0R1 Af0"
  proof-
    have "{Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Qp1(y) &  not Ff1(y) inHIDDENR3 Af0 } meetsXBOOLE-0R5 Af0 implies  not  True "
    proof(rule impI)
      assume "{Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Qp1(y) &  not Ff1(y) inHIDDENR3 Af0 } meetsXBOOLE-0R5 Af0"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 {Ff1(y) where y be ElementSUBSET-1M1-of Df0 : Qp1(y) &  not Ff1(y) inHIDDENR3 Af0 }"and A2: "x inHIDDENR3 Af0"
        using xboole_0_th_3 sorry
      have " ex y be ElementSUBSET-1M1-of Df0 st (x =HIDDENR1 Ff1(y) & Qp1(y)) &  not Ff1(y) inHIDDENR3 Af0"
        using A1 sorry
      thus " not  True "
        using A2 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem fraenkel_sch_19:
  fixes Af0 Bf0 Ff2 xf0 Pp2 Qp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty]: "xf0 be ElementSUBSET-1M1-of Bf0" and
   A1: " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds Qp2(s,t) iff t =XBOOLE-0R4 xf0 & Pp2(s,t)"
  shows "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } =XBOOLE-0R4 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
  proof-
    have "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } c=TARSKIR1 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) } & {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) } c=TARSKIR1 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) }"
    proof(rule conjMI)
      show "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } c=TARSKIR1 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } implies x inHIDDENR3 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) }"
          then obtain s t where
            [ty]:"s be ElementSUBSET-1M1-of Af0" "t be ElementSUBSET-1M1-of Bf0" and 
            A2: "x =HIDDENR1 Ff2(s,t)"and A3: "Qp2(s,t)"
             sorry
          have A4: "Pp2(s,t)"
            using A1 A3 sorry
          have "t =XBOOLE-0R4 xf0"
            using A1 A3 sorry
          thus "x inHIDDENR3 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
            using A2 A4 sorry
        qed "sorry"
        thus "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } c=TARSKIR1 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) } implies x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
        then obtain s9 where
          [ty]:"s9 be ElementSUBSET-1M1-of Af0" and 
          A5: "x =HIDDENR1 Ff2(s9,xf0)"and A6: "Pp2(s9,xf0)"
           sorry
        have "Qp2(s9,xf0)"
          using A1 A6 sorry
        thus "x inHIDDENR3 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) }"
          using A5 sorry
      qed "sorry"
      thus "{Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) } c=TARSKIR1 {Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) }"
        using tarski_def_3 sorry
    qed
    thus "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : Qp2(s,t) } =XBOOLE-0R4 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
      using xboole_0_def_10 sorry
  qed

theorem fraenkel_sch_20:
  fixes Af0 Bf0 Ff2 xf0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
  [ty]: "xf0 be ElementSUBSET-1M1-of Bf0"
  shows "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : t =XBOOLE-0R4 xf0 & Pp2(s,t) } =XBOOLE-0R4 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
  proof-
    let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 xf0 & Pp2(Lamb1,Lamb2)"
    have A1: " for s be ElementSUBSET-1M1-of Af0 holds  for t be ElementSUBSET-1M1-of Bf0 holds ?Q(s,t) iff t =XBOOLE-0R4 xf0 & Pp2(s,t)"
       sorry
    show "{Ff2(s,t) where s be ElementSUBSET-1M1-of Af0, t be ElementSUBSET-1M1-of Bf0 : t =XBOOLE-0R4 xf0 & Pp2(s,t) } =XBOOLE-0R4 {Ff2(s9,xf0) where s9 be ElementSUBSET-1M1-of Af0 : Pp2(s9,xf0) }"
      using fraenkel_sch_19 A1 sorry
  qed

reserve phi for "ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B)"
mtheorem fraenkel_th_4:
" for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 A) & Y c=TARSKIR1 B implies ( for f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y) holds  ex phi be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B) st phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 f)"
proof-
  have " for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1 & (X c=TARSKIR1 A & Y c=TARSKIR1 B) implies ( for f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y) holds  ex tVar1 be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B) st tVar1  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI)
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "FuncsFUNCT-2K1(X,Y) <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X c=TARSKIR1 A"
      and A3: "Y c=TARSKIR1 B"
    fix f assume [ty]: "f be ElementSUBSET-1M1-of FuncsFUNCT-2K1(X,Y)"
    obtain f9 where 
      [ty]:"f9 be PartFuncPARTFUN1M1-of(A,B)" and f9Def:"f9 = f"
      using A1 A2 A3 fraenkel_th_3 sorry
    obtain phi where
      [ty]:"phi be FunctionFUNCT-2M1-of(A,B)" and 
      A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> f9 implies phi .FUNCT-1K1 x =XBOOLE-0R4 f9 .FUNCT-1K1 x"
      using funct_2_th_71 sorry
    have 
      [ty]:"phi be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B)"
      using funct_2_th_8 sorry
    show " ex tVar1 be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B) st tVar1  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 f"
    proof(rule bexI[of _ "phi"])
      have " ex g be FunctionFUNCT-1M1 st (f =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 Y"
        using A1 funct_2_def_2 sorry
      then have "domRELSET-1K1\<^bsub>(A)\<^esub> f9 =HIDDENR1 A /\\XBOOLE-0K3 X"
        using xboole_1_th_28 sorry
      also have "... = domRELSET-1K1\<^bsub>(A)\<^esub> phi /\\SUBSET-1K8\<^bsub>(A)\<^esub> X"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(A)\<^esub> f9 =HIDDENR1 domRELSET-1K1\<^bsub>(A)\<^esub> phi /\\SUBSET-1K8\<^bsub>(A)\<^esub> X"
         sorry
      thus "phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =XBOOLE-0R4 f"
        using A4 funct_1_th_46 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fraenkel_th_5:
" for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for phi be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B) holds phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> (A /\\XBOOLE-0K3 X)"
proof-
  have " for B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for phi be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B) holds phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> (A /\\XBOOLE-0K3 X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix phi assume [ty]: "phi be ElementFUNCT-2M4\<^bsub>(A,B)\<^esub>-of FuncsFUNCT-2K9(A,B)"
    have "domRELSET-1K1\<^bsub>(A)\<^esub> phi =XBOOLE-0R4 A"
      using funct_2_def_1 sorry
    then have A1: "domRELSET-1K1\<^bsub>(A)\<^esub> (phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X) =HIDDENR1 (domRELSET-1K1\<^bsub>(A)\<^esub> phi /\\SUBSET-1K8\<^bsub>(A)\<^esub> A)/\\SUBSET-1K8\<^bsub>(A)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(A)\<^esub> phi /\\SUBSET-1K8\<^bsub>(A)\<^esub> (A /\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    finally have "domRELSET-1K1\<^bsub>(A)\<^esub> (phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(A)\<^esub> phi /\\SUBSET-1K8\<^bsub>(A)\<^esub> (A /\\XBOOLE-0K3 X)"
       sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(A)\<^esub> (phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X) implies (phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X).FUNCT-1K1 x =XBOOLE-0R4 phi .FUNCT-1K1 x"
      using funct_1_th_47 sorry
    thus "phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> X =RELSET-1R2\<^bsub>(A,B)\<^esub> phi  |PARTFUN1K2\<^bsub>(A,B)\<^esub> (A /\\XBOOLE-0K3 X)"
      using A1 funct_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem fraenkel_sch_21:
  fixes Af0 Xf0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: "Xf0 be finiteFINSET-1V1"
  shows "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
  proof-
    let ?M = "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
    show "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
    proof-
      have cases: "Af0 be emptyXBOOLE-0V1 or Af0 be  non emptyXBOOLE-0V1"
         sorry
      have case1: "Af0 be emptyXBOOLE-0V1 implies {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
      proof(rule impI)
        assume A2: "Af0 be emptyXBOOLE-0V1"
        have "?M c=TARSKIR1 {TARSKIK1 Ff1({}XBOOLE-0K1)}"
        proof-
          have "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 {TARSKIK1 Ff1({}XBOOLE-0K1)}"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } implies x inHIDDENR3 {TARSKIK1 Ff1({}XBOOLE-0K1)}"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?M"
              then obtain w where
                [ty]:"w be ElementSUBSET-1M1-of Af0" and 
                A3: "x =HIDDENR1 Ff1(w) & w inTARSKIR2 Xf0"
                 sorry
              have "w =XBOOLE-0R4 {}XBOOLE-0K1"
                using A2 subset_1_def_1 sorry
              thus "x inHIDDENR3 {TARSKIK1 Ff1({}XBOOLE-0K1)}"
                using A3 tarski_def_1 sorry
            qed "sorry"
            thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 {TARSKIK1 Ff1({}XBOOLE-0K1)}"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
           sorry
      qed
      have case2: "Af0 be  non emptyXBOOLE-0V1 implies {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
      proof(rule impI)
        assume A4: "Af0 be  non emptyXBOOLE-0V1"
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 f =XBOOLE-0R4 Xf0 /\\XBOOLE-0K3 Af0"and A6: " for y be objectHIDDENM1 holds y inHIDDENR3 Xf0 /\\XBOOLE-0K3 Af0 implies f .FUNCT-1K1 y =HIDDENR1 Ff1(y)"
          using funct_1_sch_3 sorry
        have "?M =XBOOLE-0R4 f .:FUNCT-1K5 Xf0"
        proof-
          have "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } =XBOOLE-0R4 f .:FUNCT-1K5 Xf0"
          proof-
            have "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 f .:FUNCT-1K5 Xf0 & f .:FUNCT-1K5 Xf0 c=TARSKIR1 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
            proof(rule conjMI)
              show "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 f .:FUNCT-1K5 Xf0"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } implies x inHIDDENR3 f .:FUNCT-1K5 Xf0"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 ?M"
                  then obtain u where
                    [ty]:"u be ElementSUBSET-1M1-of Af0" and 
                    A7: "x =HIDDENR1 Ff1(u)"and A8: "u inTARSKIR2 Xf0"
                     sorry
                  have A9: "u inTARSKIR2 domRELAT-1K1 f"
                    using A4 A5 A8 xboole_0_def_4 sorry
                  then have "f .FUNCT-1K1 u =HIDDENR1 Ff1(u)"
                    using A5 A6 sorry
                  thus "x inHIDDENR3 f .:FUNCT-1K5 Xf0"
                    using A7 A8 A9 funct_1_def_6 sorry
                qed "sorry"
                thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } c=TARSKIR1 f .:FUNCT-1K5 Xf0"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 f .:FUNCT-1K5 Xf0 implies x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 f .:FUNCT-1K5 Xf0"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A10: "y inHIDDENR3 domRELAT-1K1 f"and A11: "y inHIDDENR3 Xf0"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
                  using funct_1_def_6 sorry
                have 
                  [ty]:"y be ElementSUBSET-1M1-of Af0"
                  using A5 A10 xboole_0_def_4 sorry
                have "x =HIDDENR1 Ff1(y)"
                  using A5 A6 A10 A12 sorry
                thus "x inHIDDENR3 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
                  using A11 sorry
              qed "sorry"
              thus "f .:FUNCT-1K5 Xf0 c=TARSKIR1 {Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 }"
                using tarski_def_3 sorry
            qed
            thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } =XBOOLE-0R4 f .:FUNCT-1K5 Xf0"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "{Ff1(w) where w be ElementSUBSET-1M1-of Af0 : w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed

theorem fraenkel_sch_22:
  fixes Af0 Bf0 Xf0 Yf0 Ff2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: "Xf0 be finiteFINSET-1V1" and
   A2: "Yf0 be finiteFINSET-1V1"
  shows "{Ff2(u,v) where u be ElementSUBSET-1M1-of Af0, v be ElementSUBSET-1M1-of Bf0 : u inTARSKIR2 Xf0 & v inTARSKIR2 Yf0 } be finiteFINSET-1V1"
  proof-
    let ?G = "\<lambda>Lamb1. Ff2(Lamb1 `1XTUPLE-0K1,Lamb1 `2XTUPLE-0K2)"
    let ?M = "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 }"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 Xf0 /\\XBOOLE-0K3 Af0,Yf0 /\\XBOOLE-0K3 Bf0 :]"and A4: " for y be objectHIDDENM1 holds y inHIDDENR3 [:ZFMISC-1K2 Xf0 /\\XBOOLE-0K3 Af0,Yf0 /\\XBOOLE-0K3 Bf0 :] implies f .FUNCT-1K1 y =HIDDENR1 ?G(y)"
      using funct_1_sch_3 sorry
    have A5: "domRELAT-1K1 f =XBOOLE-0R4 ([:ZFMISC-1K2 Xf0,Yf0 :])/\\XBOOLE-0K3 ([:ZFMISC-1K2 Af0,Bf0 :])"
      using A3 zfmisc_1_th_100 sorry
    have "?M =XBOOLE-0R4 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
    proof-
      have "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } =XBOOLE-0R4 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
      proof-
        have "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } c=TARSKIR1 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :]) & f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :]) c=TARSKIR1 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 }"
        proof(rule conjMI)
          show "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } c=TARSKIR1 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } implies x inHIDDENR3 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?M"
              then obtain u v where
                [ty]:"u be ElementSUBSET-1M1-of Af0" "v be ElementSUBSET-1M1-of Bf0" and 
                A6: "x =HIDDENR1 Ff2(u,v)"and A7: "u inTARSKIR2 Xf0"and A8: "v inTARSKIR2 Yf0"
                 sorry
              have A9: "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> u,v ] inTARSKIR2 [:ZFMISC-1K2 Xf0,Yf0 :]"
                using A7 A8 zfmisc_1_th_87 sorry
              then have A10: "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> u,v ] inTARSKIR2 domRELAT-1K1 f"
                using A5 xboole_0_def_4 sorry
              have A11: "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> u,v ] `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 v"
                 sorry
              have "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> u,v ] `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 u"
                 sorry
              then have "f .BINOP-1K1(u,v) =HIDDENR1 Ff2(u,v)"
                using A3 A4 A10 A11 sorry
              thus "x inHIDDENR3 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
                using A6 A9 A10 funct_1_def_6 sorry
            qed "sorry"
            thus "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } c=TARSKIR1 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :]) implies x inHIDDENR3 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A12: "y inHIDDENR3 domRELAT-1K1 f"and A13: "y inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"and A14: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_6 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :]"
              using A5 A12 xboole_0_def_4 sorry
            have A15: "y =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> y `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub>,y `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub> ]"
              using mcart_1_th_21 sorry
            then have A16: "y `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub> inTARSKIR2 Xf0"
              using A13 zfmisc_1_th_87 sorry
            have A17: "y `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub> inTARSKIR2 Yf0"
              using A13 A15 zfmisc_1_th_87 sorry
            have "x =HIDDENR1 Ff2(y `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub>,y `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub>)"
              using A3 A4 A12 A14 sorry
            thus "x inHIDDENR3 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 }"
              using A16 A17 sorry
          qed "sorry"
          thus "f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :]) c=TARSKIR1 {Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 }"
            using tarski_def_3 sorry
        qed
        thus "{Ff2(u9,v9) where u9 be ElementSUBSET-1M1-of Af0, v9 be ElementSUBSET-1M1-of Bf0 : u9 inTARSKIR2 Xf0 & v9 inTARSKIR2 Yf0 } =XBOOLE-0R4 f .:FUNCT-1K5 ([:ZFMISC-1K2 Xf0,Yf0 :])"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "{Ff2(u,v) where u be ElementSUBSET-1M1-of Af0, v be ElementSUBSET-1M1-of Bf0 : u inTARSKIR2 Xf0 & v inTARSKIR2 Yf0 } be finiteFINSET-1V1"
      using A1 A2 sorry
  qed

theorem fraenkel_sch_23:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0" and
   A1: " for x be ElementSUBSET-1M1-of Af0 holds Pp2(x,x)" and
   A2: " for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Af0 holds  for z be ElementSUBSET-1M1-of Af0 holds Pp2(x,y) & Pp2(y,z) implies Pp2(x,z)"
  shows " for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 Bf0 implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 Bf0 & Pp2(y,x)) & ( for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 Bf0 & Pp2(z,y) implies Pp2(y,z)))"
  proof-
    have " for x be ElementSUBSET-1M1-of Af0 holds  not (x inTARSKIR2 Bf0 & ( for y be ElementSUBSET-1M1-of Af0 holds  not ((y inTARSKIR2 Bf0 & Pp2(y,x)) & ( for z be ElementSUBSET-1M1-of Af0 holds  not ((z inTARSKIR2 Bf0 & Pp2(z,y)) &  not Pp2(y,z))))))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 Lamb2 & Pp2(y,Lamb1)) & ( for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 Lamb2 & Pp2(z,y) implies Pp2(y,z))"
      let ?Q = "\<lambda>Lamb1.  for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 Lamb1 implies ?R(x,Lamb1)"
      have A3: " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 holds  for x be ElementSUBSET-1M1-of Af0 holds ( for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 B implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B & Pp2(y,x)) & ( for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 B & Pp2(z,y) implies Pp2(y,z)))) implies ( for xc be ElementSUBSET-1M1-of Af0 holds xc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,xc)) & ( for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(z,y) implies Pp2(y,z))))"
      proof(rule ballI,rule ballI,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Af0"
        assume A4: "?Q(B)"
        show " for xc be ElementSUBSET-1M1-of Af0 holds xc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,xc)) & ( for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(z,y) implies Pp2(y,z)))"
        proof-
          have " for z be ElementSUBSET-1M1-of Af0 holds z inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc)))"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be ElementSUBSET-1M1-of Af0"
            assume A5: "z inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
            have " ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc))"
            proof-
              show " ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc))"
              proof-
                have cases: "z inTARSKIR2 B or z =XBOOLE-0R4 x"
                  using A5 zfmisc_1_th_136 sorry
                have case1: "z inTARSKIR2 B implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc)))"
                proof(rule impI)
                  assume "z inTARSKIR2 B"
                  then obtain y where
                    [ty]:"y be ElementSUBSET-1M1-of Af0" and 
                    A6: "y inTARSKIR2 B"and A7: "Pp2(y,z)"and A8: " for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 B & Pp2(x,y) implies Pp2(y,x)"
                    using A4 sorry
                  have "Pp2(x,y) & (x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v)))) or  not Pp2(x,y) & ( not Pp2(x,y) implies y inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(y,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,y) implies Pp2(y,v))))"
                  proof-
                    show "Pp2(x,y) & (x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v)))) or  not Pp2(x,y) & ( not Pp2(x,y) implies y inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(y,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,y) implies Pp2(y,v))))"
                    proof-
                      have cases: "Pp2(x,y) or  not Pp2(x,y)"
                         sorry
                      have case1: "Pp2(x,y) implies x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v)))"
                      proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                        assume A9: "Pp2(x,y)"
                        show "x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          using zfmisc_1_th_136 sorry
                        show "Pp2(x,z)"
                          using A2 A7 A9 sorry
                        fix v assume [ty]: "v be ElementSUBSET-1M1-of Af0"
                        assume A10: "v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          and A11: "Pp2(v,x)"
                        have A12: "v inTARSKIR2 B implies Pp2(x,v)"
                        proof(rule impI)
                          assume A13: "v inTARSKIR2 B"
                          have "Pp2(v,y)"
                            using A2 A9 A11 sorry
                          then have "Pp2(y,v)"
                            using A8 A13 sorry
                          thus "Pp2(x,v)"
                            using A2 A9 sorry
                        qed
                        have "v inTARSKIR2 B or v =XBOOLE-0R4 x"
                          using A10 zfmisc_1_th_136 sorry
                        thus "Pp2(x,v)"
                          using A1 A12 sorry
                      qed "sorry"
                      have case2: " not Pp2(x,y) implies y inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(y,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,y) implies Pp2(y,v)))"
                      proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                        assume A14: " not Pp2(x,y)"
                        show "y inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          using A6 xboole_0_def_3 sorry
                        show "Pp2(y,z)"
                          using A7 sorry
                        fix v assume [ty]: "v be ElementSUBSET-1M1-of Af0"
                        assume A15: "v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          and A16: "Pp2(v,y)"
                        have "v inTARSKIR2 B or v =XBOOLE-0R4 x"
                          using A15 zfmisc_1_th_136 sorry
                        thus "Pp2(y,v)"
                          using A8 A14 A16 sorry
                      qed "sorry"
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc))"
                     sorry
                qed
                have case2: "z =XBOOLE-0R4 x implies ( ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc)))"
                proof(rule impI)
                  assume A17: "z =XBOOLE-0R4 x"
                  have "( ex w be ElementSUBSET-1M1-of Af0 st w inTARSKIR2 B & Pp2(w,x)) & ( ex u be ElementSUBSET-1M1-of Af0 st u inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(u,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,u) implies Pp2(u,v)))) or ( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)) & (( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)) implies x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,x) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v))))"
                  proof-
                    show "( ex w be ElementSUBSET-1M1-of Af0 st w inTARSKIR2 B & Pp2(w,x)) & ( ex u be ElementSUBSET-1M1-of Af0 st u inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(u,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,u) implies Pp2(u,v)))) or ( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)) & (( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)) implies x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,x) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v))))"
                    proof-
                      have cases: "( ex w be ElementSUBSET-1M1-of Af0 st w inTARSKIR2 B & Pp2(w,x)) or ( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x))"
                         sorry
                      have case1: "( ex w be ElementSUBSET-1M1-of Af0 st w inTARSKIR2 B & Pp2(w,x)) implies ( ex u be ElementSUBSET-1M1-of Af0 st u inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(u,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,u) implies Pp2(u,v))))"
                      proof(rule impI)
                        assume " ex w be ElementSUBSET-1M1-of Af0 st w inTARSKIR2 B & Pp2(w,x)"
                        then obtain w where
                          [ty]:"w be ElementSUBSET-1M1-of Af0" and 
                          A18: "w inTARSKIR2 B"and A19: "Pp2(w,z)"
                          using A17 sorry
                        obtain y where
                          [ty]:"y be ElementSUBSET-1M1-of Af0" and 
                          A20: "y inTARSKIR2 B"and A21: "Pp2(y,w)"and A22: " for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 B & Pp2(x,y) implies Pp2(y,x)"
                          using A4 A18 sorry
                        obtain u where 
                          [ty]:"u be ElementSUBSET-1M1-of Af0" and uDef:"u = y"
                           sorry
                        show " ex u be ElementSUBSET-1M1-of Af0 st u inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(u,z) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,u) implies Pp2(u,v)))"
                        proof(rule bexI[of _ "u"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                          show "u inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                            using A20 xboole_0_def_3 sorry
                          show "Pp2(u,z)"
                            using A2 A19 A21 sorry
                          fix v assume [ty]: "v be ElementSUBSET-1M1-of Af0"
                          assume A23: "v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                            and A24: "Pp2(v,u)"
                          have "v inTARSKIR2 B or v =XBOOLE-0R4 x"
                            using A23 zfmisc_1_th_136 sorry
                          thus "Pp2(u,v)"
                            using A2 A17 A19 A21 A22 A24 sorry
                        qed "sorry"
                      qed
                      have case2: "( for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)) implies x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & (Pp2(x,x) & ( for v be ElementSUBSET-1M1-of Af0 holds v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x} & Pp2(v,x) implies Pp2(x,v)))"
                      proof(rule impI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                        assume A25: " for w be ElementSUBSET-1M1-of Af0 holds w inTARSKIR2 B implies  not Pp2(w,x)"
                        show "x inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          using zfmisc_1_th_136 sorry
                        show A26: "Pp2(x,x)"
                          using A1 sorry
                        fix v assume [ty]: "v be ElementSUBSET-1M1-of Af0"
                        assume A27: "v inTARSKIR2 B \\/XBOOLE-0K2 {DOMAIN-1K6\<^bsub>(Af0)\<^esub> x}"
                          and A28: "Pp2(v,x)"
                        have " not v inTARSKIR2 B"
                          using A25 A28 sorry
                        thus "Pp2(x,v)"
                          using A26 A27 zfmisc_1_th_136 sorry
                      qed "sorry"
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus " ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc))"
                    using A17 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " ex y be ElementSUBSET-1M1-of Af0 st (y inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(y,z)) & ( for zc be ElementSUBSET-1M1-of Af0 holds zc inTARSKIR2 B \\/SETWISEOK8\<^bsub>(Af0)\<^esub> {.SETWISEOK5\<^bsub>(Af0)\<^esub> x.} & Pp2(zc,y) implies Pp2(y,zc))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
      qed "sorry"
      have A29: "?Q({}.SETWISEOK1 Af0)"
         sorry
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 holds ?Q(B)"
        using setwiseo_sch_4 A29 A3 sorry
      thus " for x be ElementSUBSET-1M1-of Af0 holds  not (x inTARSKIR2 Bf0 & ( for y be ElementSUBSET-1M1-of Af0 holds  not ((y inTARSKIR2 Bf0 & Pp2(y,x)) & ( for z be ElementSUBSET-1M1-of Af0 holds  not ((z inTARSKIR2 Bf0 & Pp2(z,y)) &  not Pp2(y,z))))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem fraenkel_sch_24:
  fixes Af0 Bf0 xf0 Ff1 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "xf0 be ElementSUBSET-1M1-of FinFINSUB-1K5 Bf0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be ElementSUBSET-1M1-of Af0"
  shows " ex c1 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 st  for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 c1 iff ( ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9))"
  proof-
    have " ex tVar3 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 st  for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 tVar3 & ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9)))) &  not ( not ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9))) &  not t inTARSKIR2 tVar3)"
    proof-
      let ?R = "\<lambda>Lamb1.  ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & Lamb1 =XBOOLE-0R4 Ff1(t9)) & Pp2(Lamb1,t9)"
      let ?c = "{Ff1(t9) where t9 be ElementSUBSET-1M1-of Bf0 : t9 inTARSKIR2 xf0 }"
      let ?c1 = "{tt where tt be ElementSUBSET-1M1-of Af0 : ?R(tt) }"
      have A1: "?c1 c=TARSKIR1 ?c"
      proof-
        have "{tt where tt be ElementSUBSET-1M1-of Af0 :  ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & tt =XBOOLE-0R4 Ff1(t9)) & Pp2(tt,t9) } c=TARSKIR1 {Ff1(t9) where t9 be ElementSUBSET-1M1-of Bf0 : t9 inTARSKIR2 xf0 }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {tt where tt be ElementSUBSET-1M1-of Af0 :  ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & tt =XBOOLE-0R4 Ff1(t9)) & Pp2(tt,t9) } implies x inHIDDENR3 {Ff1(t9) where t9 be ElementSUBSET-1M1-of Bf0 : t9 inTARSKIR2 xf0 }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?c1"
            then have " ex tt be ElementSUBSET-1M1-of Af0 st x =HIDDENR1 tt & ( ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & tt =XBOOLE-0R4 Ff1(t9)) & Pp2(tt,t9))"
               sorry
            thus "x inHIDDENR3 {Ff1(t9) where t9 be ElementSUBSET-1M1-of Bf0 : t9 inTARSKIR2 xf0 }"
               sorry
          qed "sorry"
          thus "{tt where tt be ElementSUBSET-1M1-of Af0 : ?R(tt) } c=TARSKIR1 {Ff1(t9) where t9 be ElementSUBSET-1M1-of Bf0 : t9 inTARSKIR2 xf0 }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A2: "?c1 c=TARSKIR1 Af0"
        using fraenkel_sch_10 sorry
      have A3: "xf0 be finiteFINSET-1V1"
         sorry
      have "?c be finiteFINSET-1V1"
        using fraenkel_sch_21 A3 sorry
      then obtain c1 where 
        [ty]:"c1 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0" and c1Def:"c1 = ?c1"
        using A1 A2 finsub_1_def_5 sorry
      show " ex tVar3 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 st  for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 tVar3 & ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9)))) &  not ( not ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9))) &  not t inTARSKIR2 tVar3)"
      proof(rule bexI[of _ "c1"],rule ballI)
        fix t assume [ty]: "t be ElementSUBSET-1M1-of Af0"
        have "t inTARSKIR2 c1 implies ( ex tt be ElementSUBSET-1M1-of Af0 st t =XBOOLE-0R4 tt & ( ex t9 be ElementSUBSET-1M1-of Bf0 st (t9 inTARSKIR2 xf0 & tt =XBOOLE-0R4 Ff1(t9)) & Pp2(tt,t9)))"
           sorry
        thus " not (t inTARSKIR2 c1 & ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9)))) &  not ( not ( for t9 be ElementSUBSET-1M1-of Bf0 holds  not ((t9 inTARSKIR2 xf0 & t =XBOOLE-0R4 Ff1(t9)) & Pp2(t,t9))) &  not t inTARSKIR2 c1)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem fraenkel_cl_1:
  mlet "A be finiteFINSET-1V1\<bar>setHIDDENM2", "B be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster FuncsFUNCT-2K1(A,B) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "FuncsFUNCT-2K1(A,B) be finiteFINSET-1V1"
  proof-
    have "boolZFMISC-1K1 ([:ZFMISC-1K2 A,B :]) be finiteFINSET-1V1"
       sorry
    thus "FuncsFUNCT-2K1(A,B) be finiteFINSET-1V1"
      using fraenkel_th_2 finset_1_th_1 sorry
  qed
qed "sorry"

mtheorem fraenkel_th_6:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A be finiteFINSET-1V1 & B be finiteFINSET-1V1 implies FuncsFUNCT-2K1(A,B) be finiteFINSET-1V1"
   sorry

theorem fraenkel_sch_25:
  fixes Af0 Bf0 Xf0 Yf0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
   A1: "Xf0 be finiteFINSET-1V1" and
   A2: "Yf0 be finiteFINSET-1V1" and
   A3: " for phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds  for psi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =RELSET-1R2\<^bsub>(Af0,Bf0)\<^esub> psi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 implies Ff1(phi) =HIDDENR1 Ff1(psi)"
  shows "{Ff1(phi9) where phi9 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) : phi9 .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0 } be finiteFINSET-1V1"
  proof-
    have " not {Ff1(phi9) where phi9 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) : phi9 .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0 } be finiteFINSET-1V1 implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 Lamb1 implies Lamb2 =HIDDENR1 Ff1(phi)"
      let ?Z = "{Ff1(phi9) where phi9 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) : phi9 .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0 }"
      let ?x = "the ElementSUBSET-1M1-of ?Z"
      have A4: "Bf0 /\\XBOOLE-0K3 Yf0 c=TARSKIR1 Bf0"
        using xboole_1_th_17 sorry
      assume A5: " not {Ff1(phi9) where phi9 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) : phi9 .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0 } be finiteFINSET-1V1"
      then have "?Z <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      then have "?x inTARSKIR2 ?Z"
         sorry
      then obtain phi where
        [ty]:"phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0)" and 
        "?x =HIDDENR1 Ff1(phi)"and A6: "phi .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0"
         sorry
      have "Bf0 /\\XBOOLE-0K3 Yf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies Af0 /\\XBOOLE-0K3 Xf0 =XBOOLE-0R4 {}XBOOLE-0K1"
      proof(rule impI)
        assume "Bf0 /\\XBOOLE-0K3 Yf0 =XBOOLE-0R4 {}XBOOLE-0K1"
        then have A7: "phi .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 {}XBOOLE-0K1"
          using A6 xboole_1_th_3 xboole_1_th_19 sorry
        have "Af0 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(Af0)\<^esub> phi"
          using funct_2_def_1 sorry
        then have "Af0 missesXBOOLE-0R1 Xf0"
          using A7 relat_1_th_118 sorry
        thus "Af0 /\\XBOOLE-0K3 Xf0 =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
      qed
      then obtain FF Z where 
        [ty]:"FF be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and FFDef:"FF = FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)" and
        [ty]:"Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and ZDef:"Z = ?Z"
        using A5 funct_2_th_8 sorry
      have A8: "Bf0 /\\XBOOLE-0K3 Yf0 c=TARSKIR1 Yf0"
        using xboole_1_th_17 sorry
      have A9: "Af0 /\\XBOOLE-0K3 Xf0 c=TARSKIR1 Af0"
        using xboole_1_th_17 sorry
      have A10: " for f be ElementSUBSET-1M1-of FF holds  ex g be ElementSUBSET-1M1-of Z st  for phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 f implies g =HIDDENR1 Ff1(phi)"
      proof(rule ballI)
        fix f assume [ty]: "f be ElementSUBSET-1M1-of FF"
        obtain phi where
          [ty]:"phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0)" and 
          A11: "phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> (Af0 /\\XBOOLE-0K3 Xf0) =XBOOLE-0R4 f"
          using A9 A4 fraenkel_th_4 sorry
        have A12: "phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 f"
          using A11 fraenkel_th_5 sorry
        have " ex g be FunctionFUNCT-1M1 st (f =XBOOLE-0R4 g & domRELAT-1K1 g =XBOOLE-0R4 Af0 /\\XBOOLE-0K3 Xf0) & rngFUNCT-1K2 g c=TARSKIR1 Bf0 /\\XBOOLE-0K3 Yf0"
          using funct_2_def_2 sorry
        then have "rngRELSET-1K2\<^bsub>(Bf0)\<^esub> (phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0) c=TARSKIR1 Yf0"
          using A8 A12 sorry
        then have "phi .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0"
          using relat_1_th_115 sorry
        then have "Ff1(phi) inHIDDENR3 Z"
           sorry
        then obtain g9 where 
          [ty]:"g9 be ElementSUBSET-1M1-of Z" and g9Def:"g9 = Ff1(phi)"
           sorry
        obtain g where 
          [ty]:"g be ElementSUBSET-1M1-of Z" and gDef:"g = g9"
           sorry
        show " ex g be ElementSUBSET-1M1-of Z st  for phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 f implies g =HIDDENR1 Ff1(phi)"
        proof(rule bexI[of _ "g"])
          show " for phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) holds phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 =XBOOLE-0R4 f implies g =HIDDENR1 Ff1(phi)"
            using A3 A12 sorry
        qed "sorry"
      qed "sorry"
      obtain F where
        [ty]:"F be FunctionFUNCT-2M1-of(FF,Z)" and 
        A13: " for f be ElementSUBSET-1M1-of FF holds ?P(f,F .FUNCT-2K3\<^bsub>(FF,Z)\<^esub> f)"
        using funct_2_sch_3 A10 sorry
      have "Z c=TARSKIR1 F .:RELSET-1K7\<^bsub>(FF,Z)\<^esub> FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 Z implies y inHIDDENR3 F .:RELSET-1K7\<^bsub>(FF,Z)\<^esub> FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 Z"
          then obtain phi where
            [ty]:"phi be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0)" and 
            A14: "y =HIDDENR1 Ff1(phi)"and A15: "phi .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 Yf0"
             sorry
          have "rngRELSET-1K2\<^bsub>(Bf0)\<^esub> (phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0) c=TARSKIR1 Yf0"
            using A15 relat_1_th_115 sorry
          then have A16: "rngRELSET-1K2\<^bsub>(Bf0)\<^esub> (phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0) c=TARSKIR1 Bf0 /\\XBOOLE-0K3 Yf0"
            using xboole_1_th_19 sorry
          have A17: "domRELSET-1K1\<^bsub>(Af0)\<^esub> (phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0) =HIDDENR1 domRELSET-1K1\<^bsub>(Af0)\<^esub> phi /\\SUBSET-1K8\<^bsub>(Af0)\<^esub> Xf0"
            using relat_1_th_61 sorry
          also have "... = Af0 /\\XBOOLE-0K3 Xf0"
            using funct_2_def_1 sorry
          finally have "domRELSET-1K1\<^bsub>(Af0)\<^esub> (phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0) =HIDDENR1 Af0 /\\XBOOLE-0K3 Xf0"
             sorry
          then obtain x where 
            [ty]:"x be ElementSUBSET-1M1-of FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)" and xDef:"x = phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0"
            using A16 funct_2_def_2 sorry
          have "phi  |PARTFUN1K2\<^bsub>(Af0,Bf0)\<^esub> Xf0 inTARSKIR2 FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)"
            using A17 A16 funct_2_def_2 sorry
          then have A18: "x inTARSKIR2 domRELSET-1K1\<^bsub>(FF)\<^esub> F"
            using funct_2_def_1 sorry
          have "y =HIDDENR1 F .FUNCT-1K1 x"
            using A13 A14 sorry
          thus "y inHIDDENR3 F .:RELSET-1K7\<^bsub>(FF,Z)\<^esub> FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)"
            using A18 funct_1_def_6 sorry
        qed "sorry"
        thus "Z c=TARSKIR1 F .:RELSET-1K7\<^bsub>(FF,Z)\<^esub> FuncsFUNCT-2K1(Af0 /\\XBOOLE-0K3 Xf0,Bf0 /\\XBOOLE-0K3 Yf0)"
          using tarski_def_3 sorry
      qed
      thus " False "
        using A1 A2 A5 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem fraenkel_sch_26:
  fixes Af0 Bf0 xf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "xf0 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0" and
   A1: " for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies ( ex ff be ElementSUBSET-1M1-of Bf0 st Pp2(t,ff))"
  shows " ex ff be FunctionFUNCT-2M1-of(Af0,Bf0) st  for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
  proof-
    have " not ( not ( for ff be FunctionFUNCT-2M1-of(Af0,Bf0) holds  not ( for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 xf0 &  not Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t))))) implies  False "
    proof(rule impI)
      let ?b = "the ElementSUBSET-1M1-of Bf0"
      let ?M = "{{ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(tt,ff) } where tt be ElementSUBSET-1M1-of Af0 : tt inTARSKIR2 xf0 }"
      let ?f = "the FunctionFUNCT-2M1-of(Af0,Bf0)"
      assume A2: " not ( not ( for ff be FunctionFUNCT-2M1-of(Af0,Bf0) holds  not ( for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 xf0 &  not Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)))))"
      then obtain t where
        [ty]:"t be ElementSUBSET-1M1-of Af0" and 
        A3: "t inTARSKIR2 xf0"and " not Pp2(t,?f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
         sorry
      have "{ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) } inTARSKIR2 ?M"
        using A3 sorry
      then obtain M where 
        [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = ?M"
         sorry
      have " for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1"
      proof(rule ballI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        assume "X inTARSKIR2 M"
        then obtain t where
          [ty]:"t be ElementSUBSET-1M1-of Af0" and 
          A4: "X =XBOOLE-0R4 {ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) }"and A5: "t inTARSKIR2 xf0"
           sorry
        obtain ff where
          [ty]:"ff be ElementSUBSET-1M1-of Bf0" and 
          A6: "Pp2(t,ff)"
          using A1 A5 sorry
        have "ff inTARSKIR2 X"
          using A4 A6 sorry
        thus "X <>HIDDENR2 {}XBOOLE-0K1"
           sorry
      qed "sorry"
      then obtain Choice where
        [ty]:"Choice be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 Choice =XBOOLE-0R4 M"and A7: " for X be setHIDDENM2 holds X inTARSKIR2 M implies Choice .FUNCT-1K1 X inTARSKIR2 X"
        using funct_1_th_111 sorry
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 inTARSKIR2 xf0 implies Lamb2 =XBOOLE-0R4 Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(Lamb1,ff) })) & (Lamb1 inTARSKIR2 xf0 or Lamb2 =XBOOLE-0R4 ?b)"
      have A8: " for t be ElementSUBSET-1M1-of Af0 holds  ex y be ElementSUBSET-1M1-of Bf0 st (t inTARSKIR2 xf0 implies y =XBOOLE-0R4 Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) })) & (t inTARSKIR2 xf0 or y =XBOOLE-0R4 the ElementSUBSET-1M1-of Bf0)"
      proof(rule ballI)
        fix t assume [ty]: "t be ElementSUBSET-1M1-of Af0"
        have A9: "t inTARSKIR2 xf0 implies Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) }) be ElementSUBSET-1M1-of Bf0"
        proof(rule impI)
          let ?s = "{ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) }"
          assume "t inTARSKIR2 xf0"
          then have "?s inTARSKIR2 M"
             sorry
          then have "Choice .FUNCT-1K1 ?s inTARSKIR2 ?s"
            using A7 sorry
          then have " ex ff be ElementSUBSET-1M1-of Bf0 st Choice .FUNCT-1K1 ?s =XBOOLE-0R4 ff & Pp2(t,ff)"
             sorry
          thus "Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) }) be ElementSUBSET-1M1-of Bf0"
             sorry
        qed
        have "t inTARSKIR2 xf0 implies t inTARSKIR2 xf0"
           sorry
        thus " ex y be ElementSUBSET-1M1-of Bf0 st (t inTARSKIR2 xf0 implies y =XBOOLE-0R4 Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) })) & (t inTARSKIR2 xf0 or y =XBOOLE-0R4 the ElementSUBSET-1M1-of Bf0)"
          using A9 sorry
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of(Af0,Bf0)" and 
        A10: " for x be ElementSUBSET-1M1-of Af0 holds ?Q(x,f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> x)"
        using funct_2_sch_3 A8 sorry
      have " for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies Pp2(t,f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be ElementSUBSET-1M1-of Af0"
        assume A11: "t inTARSKIR2 xf0"
        then have A12: "{ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) } inTARSKIR2 M"
           sorry
        have "f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t =XBOOLE-0R4 Choice .FUNCT-1K1 ({ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) })"
          using A10 A11 sorry
        then have "f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t inTARSKIR2 {ff where ff be ElementSUBSET-1M1-of Bf0 : Pp2(t,ff) }"
          using A7 A12 sorry
        then have " ex ff be ElementSUBSET-1M1-of Bf0 st f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t =XBOOLE-0R4 ff & Pp2(t,ff)"
           sorry
        thus "Pp2(t,f .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
           sorry
      qed "sorry"
      thus " False "
        using A2 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem fraenkel_sch_27:
  fixes Af0 Bf0 xf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "xf0 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0" and
   A1: " for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies ( ex ff be ElementSUBSET-1M1-of Bf0 st Pp2(t,ff))"
  shows " ex ff be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) st  for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
  proof-
    have " ex tVar5 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) st  for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 xf0 &  not Pp2(t,tVar5 .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t))"
    proof-
      have A2: " for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies ( ex ff be ElementSUBSET-1M1-of Bf0 st Pp2(t,ff))"
        using A1 sorry
      obtain ff where
        [ty]:"ff be FunctionFUNCT-2M1-of(Af0,Bf0)" and 
        A3: " for t be ElementSUBSET-1M1-of Af0 holds t inTARSKIR2 xf0 implies Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t)"
        using fraenkel_sch_26 A2 sorry
      have 
        [ty]:"ff be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0)"
        using funct_2_th_8 sorry
      show " ex tVar5 be ElementFUNCT-2M4\<^bsub>(Af0,Bf0)\<^esub>-of FuncsFUNCT-2K9(Af0,Bf0) st  for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 xf0 &  not Pp2(t,tVar5 .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t))"
      proof(rule bexI[of _ "ff"])
        show " for t be ElementSUBSET-1M1-of Af0 holds  not (t inTARSKIR2 xf0 &  not Pp2(t,ff .FUNCT-2K3\<^bsub>(Af0,Bf0)\<^esub> t))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem fraenkel_sch_28:
  fixes Af0 Bf0 Xf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Xf0 be setHIDDENM2" and
   A1: "Xf0 be finiteFINSET-1V1" and
   A2: " for w be ElementSUBSET-1M1-of Af0 holds  for x be ElementSUBSET-1M1-of Bf0 holds  for y be ElementSUBSET-1M1-of Bf0 holds Pp2(w,x) & Pp2(w,y) implies x =XBOOLE-0R4 y"
  shows "{x where x be ElementSUBSET-1M1-of Bf0 :  ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,x) & w inTARSKIR2 Xf0 } be finiteFINSET-1V1"
  proof-
    have "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } be finiteFINSET-1V1"
    proof-
      let ?M = "{x where x be ElementSUBSET-1M1-of Bf0 :  ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,x) & w inTARSKIR2 Xf0 }"
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. (Pp2(Lamb1,Lamb2) & Lamb1 inHIDDENR3 Xf0) & Lamb2 inHIDDENR3 Bf0"
      have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Af0 & ?Q(x,y) implies y inHIDDENR3 Bf0"
         sorry
      have A4: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Af0 & ?Q(x,y1)) & ?Q(x,y2) implies y1 =HIDDENR1 y2"
        using A2 sorry
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(Af0,Bf0)" and 
        A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Af0)\<^esub> f iff x inHIDDENR3 Af0 & ( ex y be objectHIDDENM1 st ?Q(x,y))"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Af0)\<^esub> f implies ?Q(x,f .FUNCT-1K1 x)"
        using partfun1_sch_2 A3 A4 sorry
      have "?M =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
      proof-
        have "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
        proof-
          have "{x where x be ElementSUBSET-1M1-of Bf0 :  ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,x) & w inTARSKIR2 Xf0 } c=TARSKIR1 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 & f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 {x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) }"
          proof(rule conjMI)
            show "{x where x be ElementSUBSET-1M1-of Bf0 :  ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,x) & w inTARSKIR2 Xf0 } c=TARSKIR1 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
            proof-
              have "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } c=TARSKIR1 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 {x where x be ElementSUBSET-1M1-of Bf0 :  ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,x) & w inTARSKIR2 Xf0 } implies x inHIDDENR3 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 ?M"
                  then obtain u where
                    [ty]:"u be ElementSUBSET-1M1-of Bf0" and 
                    A7: "x =HIDDENR1 u"and A8: " ex w be ElementSUBSET-1M1-of Af0 st Pp2(w,u) & w inTARSKIR2 Xf0"
                     sorry
                  obtain w where
                    [ty]:"w be ElementSUBSET-1M1-of Af0" and 
                    A9: "Pp2(w,u)"and A10: "w inTARSKIR2 Xf0"
                    using A8 sorry
                  have A11: "w inTARSKIR2 domRELSET-1K1\<^bsub>(Af0)\<^esub> f"
                    using A5 A9 A10 sorry
                  then have "?Q(w,f .FUNCT-1K1 w)"
                    using A6 sorry
                  then have "f .FUNCT-1K1 w =HIDDENR1 x"
                    using A2 A7 A9 sorry
                  thus "x inHIDDENR3 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
                    using A10 A11 funct_1_def_6 sorry
                qed "sorry"
                thus "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } c=TARSKIR1 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
                  using tarski_def_3 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 implies x inHIDDENR3 {x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A12: "y inHIDDENR3 domRELSET-1K1\<^bsub>(Af0)\<^esub> f"and A13: "y inHIDDENR3 Xf0"and A14: "x =HIDDENR1 f .FUNCT-1K1 y"
                using funct_1_def_6 sorry
              have 
                [ty]:"x be ElementSUBSET-1M1-of Bf0"
                using A6 A12 A14 sorry
              have "Pp2(y,x)"
                using A6 A12 A14 sorry
              thus "x inHIDDENR3 {x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) }"
                using A12 A13 sorry
            qed "sorry"
            thus "f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0 c=TARSKIR1 {x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) }"
              using tarski_def_3 sorry
          qed
          thus "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(Af0,Bf0)\<^esub> Xf0"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{x where x be ElementSUBSET-1M1-of Bf0 :  not ( for w be ElementSUBSET-1M1-of Af0 holds  not (Pp2(w,x) & w inTARSKIR2 Xf0)) } be finiteFINSET-1V1"
        using A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

end
