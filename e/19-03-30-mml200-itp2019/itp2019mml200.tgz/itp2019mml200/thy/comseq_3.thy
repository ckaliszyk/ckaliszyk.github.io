theory comseq_3
  imports series_1 comseq_1 funct_3 arytm_0
   "../mizar_extension/E_number"
begin
(*begin*)
reserve rseq, rseq1, rseq2 for "Real-SequenceSEQ-1M1"
reserve seq, seq1, seq2 for "Complex-SequenceCOMSEQ-1M1"
reserve k, n, n1, n2, m for "NatNAT-1M1"
reserve p, r for "RealXREAL-0M1"
mlemma comseq_3_lm_1:
"0cCOMPLEX1K6 =COMPLEX1R1 0NUMBERSK6 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
   sorry

mtheorem comseq_3_th_1:
" for n be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0cCOMPLEX1K6 & (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (<i>COMPLEX1K8) <>HIDDENR2 0cCOMPLEX1K6"
   sorry

mtheorem comseq_3_th_2:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI,rule impI,rule ballI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    let ?P = "\<lambda>Lamb1. absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    assume A1: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... =  |.COMPLEX1K10 0NUMBERSK6 .| +XCMPLX-0K2 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using absvalue_def_1 sorry
        also have "... =  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k.| +XCMPLX-0K2 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A3 seq_1_th_12 sorry
        also have "... = Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix m assume [ty]: "m be NatNAT-1M1"
    have A4: "?P(0NUMBERSK6)"
      using series_1_def_1 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A2 sorry
    then have "Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
       sorry
    also have "... =  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|"
      using seq_1_th_12 sorry
    also have "... =  |.COMPLEX1K10 0NUMBERSK6 .|"
      using A1 sorry
    also have "... = 0NUMBERSK6"
      using absvalue_def_1 sorry
    finally show "Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_3:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies rseq be absolutely-summableSERIES-1V2"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6) implies rseq be absolutely-summableSERIES-1V2"
  proof(rule ballI,rule impI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar2 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 tVar2 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
      show " ex tVar2 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 tVar2 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "0NUMBERSK6"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "0NUMBERSK6 <=XXREAL-0R1 m"
        have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6 .|"
          using A1 comseq_3_th_2 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_def_1 sorry
        finally have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> rseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
          using A2 sorry
      qed "sorry"
    qed "sorry"
    thus "rseq be absolutely-summableSERIES-1V2"
      using bexI[of _ "0NUMBERSK6"] comseq_2_def_5 series_1_def_2 series_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma comseq_3_lm_2:
" for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 0NUMBERSK6"
  using seq_1_th_57 sorry

mtheorem comseq_3_cl_1:
"cluster summableSERIES-1V1 also-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be summableSERIES-1V1 implies it be convergentCOMSEQ-2V3"
    using series_1_th_4 sorry
qed "sorry"

mtheorem comseq_3_cl_2:
"cluster absolutely-summableSERIES-1V2 also-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be absolutely-summableSERIES-1V2 implies it be summableSERIES-1V1"
     sorry
qed "sorry"

mtheorem comseq_3_cl_3:
"cluster absolutely-summableSERIES-1V2 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be absolutely-summableSERIES-1V2"
    using comseq_3_lm_2 comseq_3_th_3 sorry
qed "sorry"

mtheorem comseq_3_th_4:
" for rseq be Real-SequenceSEQ-1M1 holds rseq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n <=XXREAL-0R1 m & n <=XXREAL-0R1 l implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p))"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds rseq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar3 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not ((tVar3 <=XXREAL-0R1 m & tVar3 <=XXREAL-0R1 l) &  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p)))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    assume A1: "rseq be convergentCOMSEQ-2V3"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 p"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
      using A1 seq_4_th_41 sorry
    show " ex tVar3 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not ((tVar3 <=XXREAL-0R1 m & tVar3 <=XXREAL-0R1 l) &  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p)"
    proof(rule bexI[of _ "n"])
      have " for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n <=XXREAL-0R1 m & n <=XXREAL-0R1 l implies  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p"
      proof(rule ballI,rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        fix l assume [ty]: "l be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m & n <=XXREAL-0R1 l"
        then have " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M &  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A2 sorry
        then have A3: " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        have " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| =COMPLEX1R1  |.COMPLEX1K10 (rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-REAL-1K5 (rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) .|"
           sorry
        then have " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <=XXREAL-0R1  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          using complex1_th_57 sorry
        thus " |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
      thus " for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not ((n <=XXREAL-0R1 m & n <=XXREAL-0R1 l) &  |.COMPLEX1K10 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l .| <XXREAL-0R3 p)"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_5:
" for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l)"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 Lamb1"
    have A2: " for l be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l implies Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (l +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix l assume [ty]: "l be NatNAT-1M1"
      assume A3: "?P(l)"
      have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p"
        using A1 sorry
      then have A4: "p *XCMPLX-0K3 l +XCMPLX-0K2 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 l +XCMPLX-0K2 p"
        using xreal_1_th_6 sorry
      have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) +REAL-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M))-REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using series_1_def_1 sorry
      also have "... = (Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+REAL-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      finally have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+REAL-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l +XCMPLX-0K2 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
        using A3 xreal_1_th_6 sorry
      thus "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (l +NAT-1K1 \<one>\<^sub>M)"
        using A4 xxreal_0_th_2 sorry
    qed "sorry"
    have A5: "?P(0NUMBERSK6)"
       sorry
    show " for l be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 l"
      using nat_1_sch_2 A5 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_6:
" for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule impI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 p *XCMPLX-0K3 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    assume A1: " for n be NatNAT-1M1 holds rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p"
    have A2: " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "?P(n)"
      have "rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p"
        using A1 sorry
      then have A4: "p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 p"
        using xreal_1_th_6 sorry
      have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      then have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A3 xreal_1_th_6 sorry
      thus "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using A4 xxreal_0_th_2 sorry
    qed "sorry"
    have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    then have A5: "?P(0NUMBERSK6)"
      using A1 sorry
    show " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
      using nat_1_sch_2 A5 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_7:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix rseq2 assume [ty]: "rseq2 be Real-SequenceSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    assume A1: " for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    have A2: " for n be NatNAT-1M1 holds (n <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies (n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A3: "?P(n)"
      have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule impI)
        assume A4: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
        then have "rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        then have A5: "p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_6 sorry
        have "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M & Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 xreal_1_th_29 sorry
        then have A6: "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 A4 xreal_1_th_6 xxreal_0_th_2 sorry
        have "p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
        also have "... = p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally have "p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A6 A5 xxreal_0_th_2 sorry
      qed
      thus "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have A7: "?P(0NUMBERSK6)"
    proof-
      have "0NUMBERSK6 <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 m"
        have "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) & p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        thus "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A7 A2 sorry
    thus "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 p *XCMPLX-0K3 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_8:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n +XCMPLX-0K2 l <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for rseq2 be Real-SequenceSEQ-1M1 holds  for m be NatNAT-1M1 holds  for p be RealXREAL-0M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n +XCMPLX-0K2 l <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix rseq2 assume [ty]: "rseq2 be Real-SequenceSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: " for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. n +XCMPLX-0K2 Lamb1 <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    have A2: " for l be NatNAT-1M1 holds ?P(l) implies ?P(l +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for l be NatNAT-1M1 holds (n +XCMPLX-0K2 l <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) implies (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
      proof(rule ballI,rule impI,rule impI)
        fix l assume [ty]: "l be NatNAT-1M1"
        assume A3: "?P(l)"
        assume A4: "n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 m"
        then have "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) +REAL-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
          using A1 series_1_def_1 sorry
        then have "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_6 sorry
        then have A5: "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using xreal_1_th_9 sorry
        have "n +XCMPLX-0K2 l <XXREAL-0R3 (n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        then have A6: "(Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M)"
          using A3 A4 xreal_1_th_6 xxreal_0_th_2 sorry
        have "p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p *XCMPLX-0K3 ((Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) +REAL-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M))-REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
           sorry
        also have "... = p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using series_1_def_1 sorry
        finally have "p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 p *XCMPLX-0K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 l)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
           sorry
        thus "Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (l +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          using A5 A6 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "?P(0NUMBERSK6)"
       sorry
    show " for l be NatNAT-1M1 holds n +XCMPLX-0K2 l <=XXREAL-0R1 m implies Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 p *XCMPLX-0K3 (Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 l) -REAL-1K5 Partial-SumsSERIES-1K3 rseq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using nat_1_sch_2 A7 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_9:
" for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  proof(rule ballI,rule impI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A2: "Partial-SumsSERIES-1K3 rseq be non-decreasingVALUED-0V11"
      using series_1_th_16 sorry
    have A3: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI,rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m"
      then have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
        using A2 seqm_3_th_6 sorry
      then have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using xreal_1_th_9 sorry
      thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using absvalue_def_1 sorry
    qed "sorry"
    have " for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A4: "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) <=XXREAL-0R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 seqm_3_th_6 sorry
      have "Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) & 0NUMBERSK6 <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using A1 series_1_def_1 sorry
      thus " |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A4 absvalue_def_1 sorry
    qed "sorry"
    thus "( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  not  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1 Partial-SumsSERIES-1K3 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_10:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds (seq1 be convergentCOMSEQ-2V3 & seq2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 0cCOMPLEX1K6 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq2"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds (seq1 be convergentCOMSEQ-2V3 & seq2 be convergentCOMSEQ-2V3) & limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 0cCOMPLEX1K6 implies limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be convergentCOMSEQ-2V3 & seq2 be convergentCOMSEQ-2V3"
      and A2: "limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 0cCOMPLEX1K6"
    have "limCOMSEQ-2K3 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 limCOMSEQ-2K3 seq1 -XCMPLX-0K6 limCOMSEQ-2K3 seq2"
      using A1 comseq_2_th_26 sorry
    thus "limCOMSEQ-2K3 seq1 =COMPLEX1R1 limCOMSEQ-2K3 seq2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve z for "ComplexXCMPLX-0M1"
reserve Nseq, Nseq1 for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
mlemma comseq_3_lm_3:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using valued_1_th_18 sorry
    thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using complex1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef comseq_3_def_1 (" _ GeoSeqCOMSEQ-3K1" [220]220 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z GeoSeqCOMSEQ-3K1 \<rightarrow> Complex-SequenceCOMSEQ-1M1 means
  \<lambda>it. it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
proof-
  (*existence*)
    show " ex it be Complex-SequenceCOMSEQ-1M1 st it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
    proof-
      have " ex tVar4 be Complex-SequenceCOMSEQ-1M1 st tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
      proof-
        obtain z9 where 
          [ty]:"z9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and z9Def:"z9 = z"
          using xcmplx_0_def_2 sorry
        let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10(Lamb2 *XCMPLX-0K3 z9,COMPLEXNUMBERSK3)"
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of COMPLEXNUMBERSK3" and 
          A1: "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ?f(n,f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
          using nat_1_sch_12 sorry
        show " ex tVar4 be Complex-SequenceCOMSEQ-1M1 st tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 tVar4 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
          show "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7"
            using A1 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          have "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ?f(n,f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
            using A1 sorry
          thus "f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 f .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Complex-SequenceCOMSEQ-1M1 holds  for it2 be Complex-SequenceCOMSEQ-1M1 holds (it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)) & (it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 it2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & (( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z) & (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z))) implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
        fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
        assume A2: "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7"
          and A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
          and A4: "seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7"
          and A5: " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
        let ?P = "\<lambda>Lamb1. seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
        have A6: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "?P(k)"
            then have "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z"
              using A3 sorry
            also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A5 sorry
            finally show "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A7: "?P(0NUMBERSK6)"
          using A2 A4 sorry
        have " for n be NatNAT-1M1 holds ?P(n)"
          using nat_1_sch_2 A7 A6 sorry
        thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) COMSEQ_3K2(" _  |^COMSEQ-3K2  _ " [190,190]190) where
  "z  |^COMSEQ-3K2 n \<equiv> z  |^NEWTONK1 n"

mtheorem comseq_3_def_2:
  mlet "z be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"redefine func z  |^COMSEQ-3K2 n \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z  |^COMSEQ-3K2 n iff it =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
  proof-
    have " for w be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  not (w =HIDDENR1 z  |^NEWTONK1 n &  not w =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) &  not (w =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n &  not w =HIDDENR1 z  |^NEWTONK1 n)"
    proof(rule ballI)
      have 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      let ?P = "\<lambda>Lamb1. z  |^NEWTONK1 Lamb1 =COMPLEX1R1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
      fix w assume [ty]: "w be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds z  |^NEWTONK1 n =COMPLEX1R1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies z  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "?P(n)"
          then have "z  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
            using newton_th_6 sorry
          also have "... = z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using comseq_3_def_1 sorry
          finally show "z  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "z  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 1rCOMPLEX1K7"
        using complex1_def_4 newton_th_4 sorry
      also have "... = z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
        using comseq_3_def_1 sorry
      finally have "z  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
         sorry
      then have A2: "?P(0NUMBERSK6)"
         sorry
      have " for n be NatNAT-1M1 holds ?P(n)"
        using nat_1_sch_2 A2 A1 sorry
      then have "z  |^NEWTONK1 n =COMPLEX1R1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      thus " not (w =HIDDENR1 z  |^NEWTONK1 n &  not w =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) &  not (w =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n &  not w =HIDDENR1 z  |^NEWTONK1 n)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_add_1:
  mlet "z be ComplexXCMPLX-0M1", "n be NatNAT-1M1"
"cluster z  |^NEWTONK1 n as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z  |^NEWTONK1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem comseq_3_th_11:
" for z be ComplexXCMPLX-0M1 holds z  |^COMSEQ-3K2 (0NUMBERSK6) =COMPLEX1R1 1rCOMPLEX1K7"
  using complex1_def_4 newton_th_4 sorry

mdef comseq_3_def_3 ("ReCOMSEQ-3K3  _ " [228]228 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func ReCOMSEQ-3K3 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))"
    proof-
      let ?A = "domRELAT-1K1 f"
      let ?F = "\<lambda>Lamb1. ReCOMPLEX1K3 (f .FUNCT-1K1 Lamb1)"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)))))"
        proof-
          have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =HIDDENR1 ?A & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?A implies f .FUNCT-1K1 x =HIDDENR1 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      let ?A = "domRELAT-1K1 f"
      let ?F = "\<lambda>Lamb1. ReCOMPLEX1K3 (f .FUNCT-1K1 Lamb1)"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
      proof-
        have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 g =HIDDENR1 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)) & (domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)))) implies g =HIDDENR1 h"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          assume A1: "domRELAT-1K1 g =HIDDENR1 domRELAT-1K1 f"
            and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 ?F(x)"
            and A3: "domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 f"
            and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 g"
            then have "g .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)"
              using A2 sorry
            also have "... = h .FUNCT-1K1 x"
              using A1 A3 A4 A5 sorry
            finally show "g .FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "g =HIDDENR1 h"
            using A1 A3 funct_1_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef comseq_3_def_4 ("ImCOMSEQ-3K4  _ " [228]228 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func ImCOMSEQ-3K4 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))"
    proof-
      let ?A = "domRELAT-1K1 f"
      let ?F = "\<lambda>Lamb1. ReCOMPLEX1K3 (f .FUNCT-1K1 Lamb1)"
      let ?F = "\<lambda>Lamb1. ImCOMPLEX1K4 (f .FUNCT-1K1 Lamb1)"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)))))"
        proof-
          have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =HIDDENR1 ?A & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?A implies f .FUNCT-1K1 x =HIDDENR1 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
    proof-
      let ?A = "domRELAT-1K1 f"
      let ?F = "\<lambda>Lamb1. ReCOMPLEX1K3 (f .FUNCT-1K1 Lamb1)"
      let ?F = "\<lambda>Lamb1. ImCOMPLEX1K4 (f .FUNCT-1K1 Lamb1)"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) & (domRELAT-1K1 it2 =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x))) implies it1 =HIDDENR1 it2"
      proof-
        have " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 g =HIDDENR1 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)) & (domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)))) implies g =HIDDENR1 h"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          assume A6: "domRELAT-1K1 g =HIDDENR1 domRELAT-1K1 f"
            and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 ?F(x)"
            and A8: "domRELAT-1K1 h =HIDDENR1 domRELAT-1K1 f"
            and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A10: "x inHIDDENR3 domRELAT-1K1 g"
            then have "g .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)"
              using A7 sorry
            also have "... = h .FUNCT-1K1 x"
              using A6 A8 A9 A10 sorry
            finally show "g .FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "g =HIDDENR1 h"
            using A6 A8 funct_1_th_2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem comseq_3_cl_4:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster ReCOMSEQ-3K3 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 f be real-valuedVALUED-0V7"
  proof-
    have "ReCOMSEQ-3K3 f be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (ReCOMSEQ-3K3 f) implies ReCOMSEQ-3K3 f .FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (ReCOMSEQ-3K3 f)"
        then have "ReCOMSEQ-3K3 f .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (f .FUNCT-1K1 x)"
          using comseq_3_def_3 sorry
        thus "ReCOMSEQ-3K3 f .FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "ReCOMSEQ-3K3 f be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_cl_5:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster ImCOMSEQ-3K4 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 f be real-valuedVALUED-0V7"
  proof-
    have "ImCOMSEQ-3K4 f be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (ImCOMSEQ-3K4 f) implies ImCOMSEQ-3K4 f .FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (ImCOMSEQ-3K4 f)"
        then have "ImCOMSEQ-3K4 f .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (f .FUNCT-1K1 x)"
          using comseq_3_def_4 sorry
        thus "ImCOMSEQ-3K4 f .FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "ImCOMSEQ-3K4 f be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax COMSEQ_3K5 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("ReCOMSEQ-3K5\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "ReCOMSEQ-3K5\<^bsub>(X)\<^esub> f" \<rightharpoonup> "ReCOMSEQ-3K3 f"

mtheorem comseq_3_add_2:
  mlet "X be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,COMPLEXNUMBERSK3)"
"cluster ReCOMSEQ-3K3 f as-term-is PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
  proof-
    have A1: "domRELAT-1K1 f c=TARSKIR1 X"
      using relat_1_def_18 sorry
    have A2: "rngFUNCT-1K2 (ReCOMSEQ-3K3 f) c=TARSKIR1 REALNUMBERSK2"
      using valued_0_def_3 sorry
    have "domRELAT-1K1 (ReCOMSEQ-3K3 f) =HIDDENR1 domRELAT-1K1 f"
      using comseq_3_def_3 sorry
    thus "ReCOMSEQ-3K3 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
      using A1 A2 relset_1_th_4 sorry
  qed
qed "sorry"

syntax COMSEQ_3K6 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("ImCOMSEQ-3K6\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "ImCOMSEQ-3K6\<^bsub>(X)\<^esub> f" \<rightharpoonup> "ImCOMSEQ-3K4 f"

mtheorem comseq_3_add_3:
  mlet "X be setHIDDENM2", "f be PartFuncPARTFUN1M1-of(X,COMPLEXNUMBERSK3)"
"cluster ImCOMSEQ-3K4 f as-term-is PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
  proof-
    have A3: "domRELAT-1K1 f c=TARSKIR1 X"
      using relat_1_def_18 sorry
    have A4: "rngFUNCT-1K2 (ImCOMSEQ-3K4 f) c=TARSKIR1 REALNUMBERSK2"
      using valued_0_def_3 sorry
    have "domRELAT-1K1 (ImCOMSEQ-3K4 f) =HIDDENR1 domRELAT-1K1 f"
      using comseq_3_def_4 sorry
    thus "ImCOMSEQ-3K4 f be PartFuncPARTFUN1M1-of(X,REALNUMBERSK2)"
      using A3 A4 relset_1_th_4 sorry
  qed
qed "sorry"

abbreviation(input) COMSEQ_3K7("ReCOMSEQ-3K7  _ " [228]228) where
  "ReCOMSEQ-3K7 c \<equiv> ReCOMSEQ-3K3 c"

mtheorem comseq_3_def_5:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"redefine func ReCOMSEQ-3K7 c \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
proof
(*compatibility*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 c iff ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
  proof-
    have " for f be Real-SequenceSEQ-1M1 holds (f =FUNCT-1R1 ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c implies ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))) & (( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) implies f =HIDDENR1 ReCOMSEQ-3K3 c)"
    proof(rule ballI,rule conjMI,rule impI)
      fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
      have A1: "domRELAT-1K1 (ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 domRELAT-1K1 c"
        using comseq_3_def_3 sorry
      have A2: "domRELAT-1K1 c =HIDDENR1 NATNUMBERSK1"
        using funct_2_def_1 sorry
      have A3: "domRELAT-1K1 f =HIDDENR1 NATNUMBERSK1"
        using funct_2_def_1 sorry
      show "f =FUNCT-1R1 ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c implies ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
        using A1 A2 comseq_3_def_3 ordinal1_def_12 sorry
      assume A4: " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domRELAT-1K1 f"
        then have "f .FUNCT-1K1 x =HIDDENR1 ReCOMPLEX1K3 (c .FUNCT-1K1 x)"
          using A4 sorry
        also have "... = ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
          using A1 A2 A3 A5 comseq_3_def_3 sorry
        finally show "f .FUNCT-1K1 x =HIDDENR1 ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus "f =HIDDENR1 ReCOMSEQ-3K3 c"
        using A1 A2 A3 funct_1_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_add_4:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K3 c as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ReCOMSEQ-3K3 c be Real-SequenceSEQ-1M1"
  proof-
    have "domRELAT-1K1 (ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 domRELAT-1K1 c"
      using comseq_3_def_3 sorry
    also have "... = NATNUMBERSK1"
      using funct_2_def_1 sorry
    finally have "domRELAT-1K1 (ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 NATNUMBERSK1"
       sorry
    then have "ReCOMSEQ-3K5\<^bsub>(NATNUMBERSK1)\<^esub> c be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
      using partfun1_def_2 sorry
    thus "ReCOMSEQ-3K3 c be Real-SequenceSEQ-1M1"
       sorry
  qed
qed "sorry"

abbreviation(input) COMSEQ_3K8("ImCOMSEQ-3K8  _ " [228]228) where
  "ImCOMSEQ-3K8 c \<equiv> ImCOMSEQ-3K4 c"

mtheorem comseq_3_def_6:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"redefine func ImCOMSEQ-3K8 c \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
proof
(*compatibility*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 c iff ( for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
  proof-
    have " for f be Real-SequenceSEQ-1M1 holds (f =FUNCT-1R1 ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c implies ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))) & (( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) implies f =HIDDENR1 ImCOMSEQ-3K4 c)"
    proof(rule ballI,rule conjMI,rule impI)
      fix f assume [ty]: "f be Real-SequenceSEQ-1M1"
      have A6: "domRELAT-1K1 (ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 domRELAT-1K1 c"
        using comseq_3_def_4 sorry
      have A7: "domRELAT-1K1 c =HIDDENR1 NATNUMBERSK1"
        using funct_2_def_1 sorry
      have A8: "domRELAT-1K1 f =HIDDENR1 NATNUMBERSK1"
        using funct_2_def_1 sorry
      show "f =FUNCT-1R1 ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c implies ( for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
        using A6 A7 ordinal1_def_12 comseq_3_def_4 sorry
      assume A9: " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 domRELAT-1K1 f"
        then have "f .FUNCT-1K1 x =HIDDENR1 ImCOMPLEX1K4 (c .FUNCT-1K1 x)"
          using A9 sorry
        also have "... = ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
          using A6 A7 A8 A10 comseq_3_def_4 sorry
        finally show "f .FUNCT-1K1 x =HIDDENR1 ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus "f =HIDDENR1 ImCOMSEQ-3K4 c"
        using A6 A7 A8 funct_1_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_add_5:
  mlet "c be Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K4 c as-term-is Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show "ImCOMSEQ-3K4 c be Real-SequenceSEQ-1M1"
  proof-
    have "domRELAT-1K1 (ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 domRELAT-1K1 c"
      using comseq_3_def_4 sorry
    also have "... = NATNUMBERSK1"
      using funct_2_def_1 sorry
    finally have "domRELAT-1K1 (ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c) =HIDDENR1 NATNUMBERSK1"
       sorry
    then have "ImCOMSEQ-3K6\<^bsub>(NATNUMBERSK1)\<^esub> c be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>"
      using partfun1_def_2 sorry
    thus "ImCOMSEQ-3K4 c be Real-SequenceSEQ-1M1"
       sorry
  qed
qed "sorry"

mtheorem comseq_3_th_12:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "z =COMPLEX1R1 ReCOMPLEX1K3 z +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_13 sorry
    then have A1: " |.COMPLEX1K10 z.| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8) .| +XCMPLX-0K2  |.COMPLEX1K10 0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8) .|"
      using complex1_th_56 sorry
    have "ReCOMPLEX1K3 (0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 0NUMBERSK6 & ImCOMPLEX1K4 (0NUMBERSK6 +XCMPLX-0K2 ImCOMPLEX1K4 z *XCMPLX-0K3 (<i>COMPLEX1K8)) =COMPLEX1R1 ImCOMPLEX1K4 z"
      using complex1_th_12 sorry
    thus " |.COMPLEX1K10 z.| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 z.| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 z.|"
      using A1 complex1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_13:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 ReCOMPLEX1K3 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 ImCOMPLEX1K4 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 ReCOMPLEX1K3 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 ImCOMPLEX1K4 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A1: "0NUMBERSK6 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_6 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A2: "sqrtSQUARE-1K3 (ImCOMPLEX1K4 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using A1 square_1_th_26 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A3: "0NUMBERSK6 +XCMPLX-0K2 (ReCOMPLEX1K3 z)^2SQUARE-1K1 <=XXREAL-0R1 (ImCOMPLEX1K4 z)^2SQUARE-1K1 +XCMPLX-0K2 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
      using xreal_1_th_6 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 (ReCOMPLEX1K3 z)^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have " |.COMPLEX1K10 z.| =COMPLEX1R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1) & sqrtSQUARE-1K3 (ReCOMPLEX1K3 z)^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 ((ReCOMPLEX1K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (ImCOMPLEX1K4 z)^2SQUARE-1K1)"
      using A3 complex1_def_12 square_1_th_26 sorry
    thus " |.COMPLEX1K10 ReCOMPLEX1K3 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 ImCOMPLEX1K4 z.| <=XXREAL-0R1  |.COMPLEX1K10 z.|"
      using A2 complex1_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_14:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 & ImCOMSEQ-3K8 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 & ImCOMSEQ-3K8 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "ReCOMSEQ-3K7 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2"
      and A2: "ImCOMSEQ-3K8 seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A3: "ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      finally have "ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      have "ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      finally have "ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      thus "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using A3 complex1_th_3 sorry
    qed "sorry"
    thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_15:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_8 sorry
      also have "... = ReCOMPLEX1K3 ((seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_1 sorry
      also have "... = ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "(ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_8 sorry
      also have "... = ImCOMPLEX1K4 ((seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_1 sorry
      also have "... = ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "(ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_16:
" for seq be Complex-SequenceCOMSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
  proof(rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      also have "... = -REAL-1K1 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (-XCMPLX-0K4 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_17 sorry
      also have "... = ReCOMPLEX1K3 ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_8 sorry
      also have "... = ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 -REAL-1K1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      also have "... = -REAL-1K1 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (-XCMPLX-0K4 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_17 sorry
      also have "... = ImCOMPLEX1K4 ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_8 sorry
      also have "... = ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_17:
" for r be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds r *XCMPLX-0K3 ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (r *XCMPLX-0K3 z) & r *XCMPLX-0K3 ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (r *XCMPLX-0K3 z)"
proof-
  have " for r be RealXREAL-0M1 holds  for z be ComplexXCMPLX-0M1 holds r *XCMPLX-0K3 ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (r *XCMPLX-0K3 z) & r *XCMPLX-0K3 ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (r *XCMPLX-0K3 z)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    obtain r9 where 
      [ty]:"r9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and r9Def:"r9 = r"
      using xcmplx_0_def_2 sorry
    have "r =COMPLEX1R1 r +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    then have A1: "ReCOMPLEX1K3 r =COMPLEX1R1 r & ImCOMPLEX1K4 r =COMPLEX1R1 0NUMBERSK6"
      using complex1_th_12 sorry
    have "r *XCMPLX-0K3 z =HIDDENR1 (ReCOMPLEX1K3 r9 *REAL-1K4 ReCOMPLEX1K3 z -REAL-1K5 ImCOMPLEX1K4 r9 *REAL-1K4 ImCOMPLEX1K4 z)+XCMPLX-0K2 (ReCOMPLEX1K3 r9 *REAL-1K4 ImCOMPLEX1K4 z +REAL-1K3 ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 r9)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using complex1_th_82 sorry
    also have "... = r *XCMPLX-0K3 ReCOMPLEX1K3 z +XCMPLX-0K2 (r *XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 sorry
    finally have "r *XCMPLX-0K3 z =HIDDENR1 r *XCMPLX-0K3 ReCOMPLEX1K3 z +XCMPLX-0K2 (r *XCMPLX-0K3 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8)"
       sorry
    thus "r *XCMPLX-0K3 ReCOMPLEX1K3 z =COMPLEX1R1 ReCOMPLEX1K3 (r *XCMPLX-0K3 z) & r *XCMPLX-0K3 ImCOMPLEX1K4 z =COMPLEX1R1 ImCOMPLEX1K4 (r *XCMPLX-0K3 z)"
      using complex1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_18:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) & ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_th_16 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_th_15 sorry
      finally show "(ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_th_16 sorry
      also have "... = (ImCOMSEQ-3K8 seq1 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_th_15 sorry
      finally show "(ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_19:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) & r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_th_17 sorry
      also have "... = ReCOMPLEX1K3 ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_6 sorry
      also have "... = ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = r *XCMPLX-0K3 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_th_17 sorry
      also have "... = ImCOMPLEX1K4 ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_6 sorry
      also have "... = ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_20:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq & ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq & ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 ((z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_6 sorry
      also have "... = ReCOMPLEX1K3 ((ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))+XCMPLX-0K2 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using complex1_th_82 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_12 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 (ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-REAL-1K1 (ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 ((z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_6 sorry
      also have "... = ImCOMPLEX1K4 ((ReCOMPLEX1K3 z *REAL-1K4 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))+XCMPLX-0K2 (ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 z)*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using complex1_th_82 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 z"
        using complex1_th_12 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 z *REAL-1K4 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMPLEX1K4 z *REAL-1K4 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMPLEX1K3 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMPLEX1K4 z (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_21:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 & ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 & ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 ((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = ReCOMPLEX1K3 ((ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))+XCMPLX-0K2 (ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using complex1_th_82 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_12 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 (ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-REAL-1K1 (ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
         sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_10 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 ((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = ImCOMPLEX1K4 ((ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) -REAL-1K5 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))+XCMPLX-0K2 (ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))*XCMPLX-0K3 (<i>COMPLEX1K8))"
        using complex1_th_82 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using complex1_th_12 sorry
      also have "... = ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ImCOMPLEX1K4 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ImCOMSEQ-3K8 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *REAL-1K4 ReCOMSEQ-3K7 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      also have "... = (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      finally show "ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2 +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) COMSEQ_3K9(" _ *COMSEQ-3K9  _ " [164,164]164) where
  "seq *COMSEQ-3K9 Nseq \<equiv> Nseq (#)RELAT-1K5 seq"

mtheorem comseq_3_add_6:
  mlet "Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1", "seq be Complex-SequenceCOMSEQ-1M1"
"cluster Nseq (#)RELAT-1K5 seq as-term-is Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show "Nseq (#)RELAT-1K5 seq be Complex-SequenceCOMSEQ-1M1"
  proof-
    have "domRELAT-1K1 (seq *VALUED-0K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Nseq) =HIDDENR1 NATNUMBERSK1"
      using funct_2_def_1 sorry
    thus "Nseq (#)RELAT-1K5 seq be Complex-SequenceCOMSEQ-1M1"
       sorry
  qed
qed "sorry"

mtheorem comseq_3_th_22:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq & ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq & ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
  proof(rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix Nseq assume [ty]: "Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 ((seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n))"
        using funct_2_th_15 sorry
      also have "... = ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = (ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 ((seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n))"
        using funct_2_th_15 sorry
      also have "... = ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = (ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_23:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & (ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI,rule conjMI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "(ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
      have "(ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 ((seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "(ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) COMSEQ_3K10("Partial-SumsCOMSEQ-3K10  _ " [350]350) where
  "Partial-SumsCOMSEQ-3K10 s \<equiv> Partial-SumsSERIES-1K2 s"

mtheorem comseq_3_add_7:
  mlet "s be Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K2 s as-term-is Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show "Partial-SumsSERIES-1K2 s be Complex-SequenceCOMSEQ-1M1"
  proof-
    have A1: "domRELAT-1K1 Partial-SumsSERIES-1K2 s =HIDDENR1 NATNUMBERSK1"
      using partfun1_def_2 sorry
    have "rngFUNCT-1K2 Partial-SumsSERIES-1K2 s c=TARSKIR1 COMPLEXNUMBERSK3"
      using valued_0_def_1 sorry
    then have "Partial-SumsSERIES-1K2 s be PartFuncPARTFUN1M1-of(NATNUMBERSK1,COMPLEXNUMBERSK3)"
      using A1 relset_1_th_4 sorry
    thus "Partial-SumsSERIES-1K2 s be Complex-SequenceCOMSEQ-1M1"
       sorry
  qed
qed "sorry"

mdef comseq_3_def_7 ("SumCOMSEQ-3K11  _ " [260]260 ) where
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"func SumCOMSEQ-3K11 seq \<rightarrow> ElementSUBSET-1M1-of COMPLEXNUMBERSK3 equals
  limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq"
proof-
  (*coherence*)
    show "limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem comseq_3_th_24:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 0cCOMPLEX1K6)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 0cCOMPLEX1K6)"
  proof(rule ballI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    let ?P = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 0cCOMPLEX1K6 +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A1 A3 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally show "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix m assume [ty]: "m be NatNAT-1M1"
    have A4: "?P(0NUMBERSK6)"
      using series_1_def_1 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A2 sorry
    then have "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
       sorry
    thus "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 0cCOMPLEX1K6"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_25:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies ( for m be NatNAT-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    let ?P = "\<lambda>Lamb1. ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        have "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1  |.COMPLEX1K10 0cCOMPLEX1K6.| +XCMPLX-0K2 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using complex1_th_44 sorry
        also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A3 valued_1_th_18 sorry
        also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    fix m assume [ty]: "m be NatNAT-1M1"
    have A4: "?P(0NUMBERSK6)"
      using series_1_def_1 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A2 sorry
    then have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
       sorry
    also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m.|"
      using valued_1_th_18 sorry
    also have "... = 0NUMBERSK6"
      using A1 complex1_th_44 sorry
    finally show "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_26:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    let ?P = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    let ?R = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 =COMPLEX1R1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "?P(k)"
        then have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_5 sorry
        also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) +REAL-1K3 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_5 sorry
        also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using complex1_th_8 sorry
        also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using series_1_def_1 sorry
        also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using comseq_3_def_5 sorry
        finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: " for k be NatNAT-1M1 holds ?R(k) implies ?R(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k =COMPLEX1R1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "?R(k)"
        then have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_6 sorry
        also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) +REAL-1K3 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using comseq_3_def_6 sorry
        also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using complex1_th_8 sorry
        also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          using series_1_def_1 sorry
        also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using comseq_3_def_6 sorry
        finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using comseq_3_def_6 sorry
    also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using series_1_def_1 sorry
    also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using comseq_3_def_6 sorry
    finally have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    then have A3: "?R(0NUMBERSK6)"
       sorry
    have A4: " for n be NatNAT-1M1 holds ?R(n)"
      using nat_1_sch_2 A3 A2 sorry
    have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using comseq_3_def_5 sorry
    also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
      using series_1_def_1 sorry
    also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using comseq_3_def_5 sorry
    finally have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    then have A5: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A5 A1 sorry
    thus "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_27:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
  using series_1_th_5 sorry

mtheorem comseq_3_th_28:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
  proof(rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have A1: "ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq2"
      using comseq_3_th_18 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq2"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq2)"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq2)"
      using series_1_th_6 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2))"
      using comseq_3_th_18 sorry
    also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_3_th_26 sorry
    finally have "ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2) =HIDDENR1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
    have "ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2) =HIDDENR1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq2"
      using comseq_3_th_18 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq2"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq2)"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq2)"
      using series_1_th_6 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2))"
      using comseq_3_th_18 sorry
    also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_3_th_26 sorry
    finally have "ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2) =HIDDENR1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
    thus "Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using A1 comseq_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_29:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?P = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have A1: " for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A2: "?P(n)"
      have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = z *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A2 valued_1_th_6 sorry
      also have "... = z *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using valued_1_th_6 sorry
      also have "... = z *XCMPLX-0K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
         sorry
      also have "... = z *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using valued_1_th_6 sorry
      finally have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using valued_1_th_6 sorry
    also have "... = z *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using valued_1_th_6 sorry
    finally have "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
       sorry
    then have A3: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_30:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1.  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
    have A1: " for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "?P(k)"
      then have A2: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).|"
        using xreal_1_th_6 sorry
      have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) .| &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).|"
        using complex1_th_56 series_1_def_1 sorry
      then have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).|"
        using A2 xxreal_0_th_2 sorry
      then have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using valued_1_th_18 sorry
      thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
    qed "sorry"
    have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
      using valued_1_th_18 sorry
    finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6).|"
       sorry
    then have A3: "?P(0NUMBERSK6)"
      using series_1_def_1 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A3 A1 sorry
    thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_31:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    have A1: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof-
      have " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        let ?P = "\<lambda>Lamb1. 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        have A2: " for k be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n implies 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          have A3: "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) +REAL-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M))-REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using series_1_def_1 sorry
          also have "... = (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|)-XCMPLX-0K6 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using valued_1_th_18 sorry
          also have "... = (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|"
             sorry
          finally have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|"
             sorry
          have A4: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|"
            using complex1_th_46 sorry
          assume "?P(k)"
          thus "0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A3 A4 sorry
        qed "sorry"
        have A5: "?P(0NUMBERSK6)"
           sorry
        show " for k be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using nat_1_sch_2 A5 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| =COMPLEX1R1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A1 absvalue_def_1 sorry
    have A7: " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
    proof-
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
      proof(rule ballI,rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then obtain k where
          [ty]:"k be NatNAT-1M1" and 
          A8: "m =COMPLEX1R1 n +XCMPLX-0K2 k"
          using nat_1_th_10 sorry
        have A9: " for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
        proof-
          let ?P = "\<lambda>Lamb1.  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 Lamb1) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 Lamb1) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          have A10: " for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "?P(k)"
            then have A11: " |.COMPLEX1K10 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)+XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M) .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).| &  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|"
              using complex1_th_56 xreal_1_th_6 sorry
            have A12: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| =HIDDENR1  |.COMPLEX1K10 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
              using series_1_def_1 sorry
            also have "... =  |.COMPLEX1K10 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)+XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M) .|"
               sorry
            finally have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| =HIDDENR1  |.COMPLEX1K10 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)+XCMPLX-0K2 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M) .|"
               sorry
            have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).| =HIDDENR1 (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)+XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|"
              using A6 sorry
            also have "... = (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).|)-XCMPLX-0K6 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
            also have "... = (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) +REAL-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M))-REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using valued_1_th_18 sorry
            also have "... = Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using series_1_def_1 sorry
            also have "... =  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
              using A6 sorry
            finally have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M).| =HIDDENR1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
               sorry
            thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M)) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
              using A12 A11 xxreal_0_th_2 sorry
          qed "sorry"
          have A13: "?P(0NUMBERSK6)"
             sorry
          show " for k be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k) -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k) -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
            using nat_1_sch_2 A13 A10 sorry
        qed
        show " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          using A9 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
    proof(rule ballI,rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix m assume [ty]: "m be NatNAT-1M1"
      have "m <=XXREAL-0R1 n implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
      proof(rule impI)
        assume "m <=XXREAL-0R1 n"
        then have A14: " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .|"
          using A7 sorry
        have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 -REAL-1K1 (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m) .|"
          using complex1_th_52 sorry
        also have "... =  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
           sorry
        finally have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
           sorry
        thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          using A14 complex1_th_60 sorry
      qed
      thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
        using A7 sorry
    qed "sorry"
    thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_32:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & (Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI,rule conjMI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using comseq_3_th_26 sorry
      also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 ((Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_5 sorry
      finally show "(Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
      have "(Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k)"
        using comseq_3_th_26 sorry
      also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +XCMPLX-0K2 k))"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 ((Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using nat_1_def_3 sorry
      also have "... = ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_def_6 sorry
      finally show "(Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) & Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_33:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) implies Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)) implies Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1"
  proof(rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
    have A2: " for n be NatNAT-1M1 holds ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) & ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
    proof(rule ballI,rule conjMI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMPLEX1K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      also have "... = ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
        using A1 sorry
      also have "... = ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using comseq_3_def_5 sorry
      finally show "ReCOMSEQ-3K7 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
         sorry
      have "ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMPLEX1K4 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_6 sorry
      also have "... = ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6))"
        using A1 sorry
      also have "... = ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using comseq_3_def_6 sorry
      finally show "ImCOMSEQ-3K8 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
         sorry
    qed "sorry"
    have A3: "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M))"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
      using comseq_3_th_23 sorry
    also have "... = Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1"
      using A2 series_1_th_11 sorry
    also have "... = ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1"
      using comseq_3_th_32 sorry
    also have "... = ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
      using comseq_3_th_18 sorry
    finally have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =HIDDENR1 ImCOMSEQ-3K8 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
       sorry
    have "ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M))"
      using comseq_3_th_26 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
      using comseq_3_th_23 sorry
    also have "... = Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1"
      using A2 series_1_th_11 sorry
    also have "... = ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1"
      using comseq_3_th_32 sorry
    also have "... = ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
      using comseq_3_th_18 sorry
    finally have "ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =HIDDENR1 ReCOMSEQ-3K7 (Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
       sorry
    thus "Partial-SumsCOMSEQ-3K10 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> \<one>\<^sub>M -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1"
      using A3 comseq_3_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_34:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be non-decreasingVALUED-0V11"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be non-decreasingVALUED-0V11"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using comseq_3_lm_3 sorry
    thus "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be non-decreasingVALUED-0V11"
      using series_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_6:
  mlet "seq be Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) as-term-is non-decreasingVALUED-0V11 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) implies it be non-decreasingVALUED-0V11"
    using comseq_3_th_34 sorry
qed "sorry"

mtheorem comseq_3_th_35:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for m be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for m be NatNAT-1M1 holds ( for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 m implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    assume A1: " for n be NatNAT-1M1 holds n <=XXREAL-0R1 m implies seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 m implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k) implies (k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        assume A4: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
        have "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_29 sorry
        then have "Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A3 A4 series_1_def_1 xxreal_0_th_2 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using A1 A4 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        finally show "Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
    proof-
      have "0NUMBERSK6 <=XXREAL-0R1 m implies Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 m"
        have "Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using A1 sorry
        also have "... = Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        finally show "Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A5 A2 sorry
    thus "Partial-SumsCOMSEQ-3K10 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_36:
" for z be ComplexXCMPLX-0M1 holds 1rCOMPLEX1K7 <>HIDDENR2 z implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  not ( not 1rCOMPLEX1K7 <>HIDDENR2 z &  not ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)))"
  proof(rule ballI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have " for z be ComplexXCMPLX-0M1 holds 1rCOMPLEX1K7 <>HIDDENR2 z implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ComplexXCMPLX-0M1"
      let ?P = "\<lambda>Lamb1. Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
      assume "1rCOMPLEX1K7 <>HIDDENR2 z"
      then have A1: "1rCOMPLEX1K7 -XCMPLX-0K6 z <>HIDDENR2 0cCOMPLEX1K6"
         sorry
      have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have " for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z) implies Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "?P(n)"
          then have "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z) +XCMPLX-0K2 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 1rCOMPLEX1K7"
            using complex1_def_4 series_1_def_1 sorry
          also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z) +XCMPLX-0K2 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z)/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
            using A1 complex1_def_4 xcmplx_1_th_60 sorry
          also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z) +XCMPLX-0K2 (z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (1rCOMPLEX1K7 -XCMPLX-0K6 z))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
            using xcmplx_1_th_74 sorry
          also have "... = ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
            using complex1_def_4 xcmplx_1_th_62 sorry
          also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z)/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
             sorry
          also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
            using newton_th_6 sorry
          finally show "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
        using series_1_def_1 sorry
      also have "... = 1rCOMPLEX1K7"
        using comseq_3_def_1 sorry
      also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 z)/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using A1 complex1_def_4 xcmplx_1_th_60 sorry
      also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
         sorry
      finally have "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
         sorry
      then have A3: "?P(0NUMBERSK6)"
         sorry
      show " for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using nat_1_sch_2 A3 A2 sorry
    qed "sorry"
    thus " not ( not 1rCOMPLEX1K7 <>HIDDENR2 z &  not ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_37:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds z <>HIDDENR2 1rCOMPLEX1K7 & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "z <>HIDDENR2 1rCOMPLEX1K7"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    let ?P = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1"
    have A3: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "?P(n)"
      then have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z *XCMPLX-0K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using A2 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (z *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using comseq_3_def_1 sorry
      finally have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 1rCOMPLEX1K7"
      using complex1_def_4 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
      using comseq_3_def_1 sorry
    finally have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 z GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6)"
       sorry
    then have A4: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A3 sorry
    then have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n)"
       sorry
    then have "Partial-SumsCOMSEQ-3K10 seq =HIDDENR1 Partial-SumsCOMSEQ-3K10 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z GeoSeqCOMSEQ-3K1)"
      using valued_1_th_7 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)"
      using comseq_3_th_29 sorry
    finally have "Partial-SumsCOMSEQ-3K10 seq =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)"
       sorry
    then have "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
      using valued_1_th_6 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
      using A1 comseq_3_th_36 sorry
    finally show "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem comseq_3_th_38:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies (a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3 iff c be convergentCOMSEQ-2V3)"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies (a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3 implies c be convergentCOMSEQ-2V3) & (c be convergentCOMSEQ-2V3 implies a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI,rule conjMI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    show "a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3 implies c be convergentCOMSEQ-2V3"
    proof(rule impMI ,rule impI)
      assume A2: "a be convergentCOMSEQ-2V3"
        and A3: "b be convergentCOMSEQ-2V3"
      obtain a1 where
        [ty]:"a1 be RealXREAL-0M1" and 
        A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 a1 .| <XXREAL-0R3 p)"
        using A2 seq_2_def_6 sorry
      obtain b1 where
        [ty]:"b1 be RealXREAL-0M1" and 
        A5: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 b1 .| <XXREAL-0R3 p)"
        using A3 seq_2_def_6 sorry
      have 
        [ty]:"a1 be RealXREAL-0M1" and
        [ty]:"b1 be RealXREAL-0M1"
         sorry
      obtain g where 
        [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and gDef:"g = a1 +XCMPLX-0K2 b1 *XCMPLX-0K3 (<i>COMPLEX1K8)"
        using xcmplx_0_def_2 sorry
      have Cut1304: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar6 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar6 <=XXREAL-0R1 m &  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A6: "0NUMBERSK6 <XXREAL-0R3 p"
          then obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A7: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 a1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
            using A4 sorry
          obtain n2 where
            [ty]:"n2 be NatNAT-1M1" and 
            A8: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 b1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
            using A5 A6 sorry
          have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2 & n2 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
            using nat_1_th_11 sorry
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A9: "n1 <=XXREAL-0R1 n"and A10: "n2 <=XXREAL-0R1 n"
             sorry
          show " ex tVar6 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  not (tVar6 <=XXREAL-0R1 m &  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
          proof(rule bexI[of _ "n"])
            have " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            proof-
              have " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                have "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ReCOMPLEX1K3 g =COMPLEX1R1 a1"
                  using A1 complex1_th_12 sorry
                then have A11: "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 a1"
                  using complex1_th_19 sorry
                have "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ImCOMPLEX1K4 g =COMPLEX1R1 b1"
                  using A1 complex1_th_12 sorry
                then have A12: "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 b1"
                  using complex1_th_19 sorry
                assume A13: "n <=XXREAL-0R1 m"
                then have "n2 <=XXREAL-0R1 m"
                  using A10 xxreal_0_th_2 sorry
                then have A14: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 b1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
                  using A8 sorry
                have "n1 <=XXREAL-0R1 m"
                  using A9 A13 xxreal_0_th_2 sorry
                then have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 a1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
                  using A7 sorry
                then have A15: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 a1 .| +XCMPLX-0K2  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 b1 .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
                  using A14 xreal_1_th_8 sorry
                have " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g).| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g).|"
                  using comseq_3_th_12 sorry
                thus " not  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
                  using A15 A11 A12 xxreal_0_th_2 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            thus " for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for VarFor1 be objectHIDDENM1 holds  not ( not VarFor1 <=XXREAL-0R1 0NUMBERSK6 & ( for VarFor2 be setHIDDENM2 holds  not ( for VarFor3 be setHIDDENM2 holds  not (VarFor2 <=XXREAL-0R1 VarFor3 & VarFor1 <=XXREAL-0R1  |.COMPLEX1K10 c .FUNCT-1K1 VarFor3 -XCMPLX-0K6 g .|))))"
      proof-
        show " for VarFor1 be objectHIDDENM1 holds  not ( not VarFor1 <=XXREAL-0R1 0NUMBERSK6 & ( for VarFor2 be setHIDDENM2 holds  not ( for VarFor3 be setHIDDENM2 holds  not (VarFor2 <=XXREAL-0R1 VarFor3 & VarFor1 <=XXREAL-0R1  |.COMPLEX1K10 c .FUNCT-1K1 VarFor3 -XCMPLX-0K6 g .|))))"
          using Cut1304 sorry
      qed
      thus "c be convergentCOMSEQ-2V3"
        using bexI[of _ "g"] comseq_2_def_5 sorry
    qed
    assume "c be convergentCOMSEQ-2V3"
    then obtain z where
      [ty]:"z be ComplexXCMPLX-0M1" and 
      A16: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p)"
       sorry
    show "a be convergentCOMSEQ-2V3"
    proof-
      have 
        [ty]:"z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar8 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar8 <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 a .FUNCT-1K1 m -XCMPLX-0K6 ReCOMPLEX1K3 z .|)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A17: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A18: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p"
          using A16 A17 sorry
        show " ex tVar8 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar8 <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 a .FUNCT-1K1 m -XCMPLX-0K6 ReCOMPLEX1K3 z .|"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have A19: " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p"
            using A18 sorry
          have "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z) =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -REAL-1K5 ReCOMPLEX1K3 z"
            using A1 complex1_th_19 sorry
          then have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 z .| <=XXREAL-0R1  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .|"
            using comseq_3_th_13 sorry
          thus " not p <=XXREAL-0R1  |.COMPLEX1K10 a .FUNCT-1K1 m -XCMPLX-0K6 ReCOMPLEX1K3 z .|"
            using A19 xxreal_0_th_2 sorry
        qed "sorry"
      qed "sorry"
      thus "a be convergentCOMSEQ-2V3"
        using bexI[of _ "ReCOMPLEX1K3 z"] comseq_2_def_5 sorry
    qed
    have " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar10 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar10 <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 b .FUNCT-1K1 m -XCMPLX-0K6 ImCOMPLEX1K4 z .|)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A20: "p >XXREAL-0R4 0NUMBERSK6"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A21: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p"
        using A16 A20 sorry
      show " ex tVar10 be setHIDDENM2 st  for m be NatNAT-1M1 holds tVar10 <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 b .FUNCT-1K1 m -XCMPLX-0K6 ImCOMPLEX1K4 z .|"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A22: " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p"
          using A21 sorry
        have A23: "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z) =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -REAL-1K5 ImCOMPLEX1K4 z"
          using complex1_th_19 sorry
        have "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
          using A1 sorry
        then have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 z .| <=XXREAL-0R1  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .|"
          using A23 comseq_3_th_13 sorry
        thus " not p <=XXREAL-0R1  |.COMPLEX1K10 b .FUNCT-1K1 m -XCMPLX-0K6 ImCOMPLEX1K4 z .|"
          using A22 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "b be convergentCOMSEQ-2V3"
      using bexI[of _ "ImCOMPLEX1K4 z"] comseq_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_39:
" for a be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1 holds  for b be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1 holds  for c be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies c be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 c =COMPLEX1R1 limSEQ-2K1 a +XCMPLX-0K2 (limSEQ-2K1 b)*XCMPLX-0K3 (<i>COMPLEX1K8)"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
  fix a assume [ty]: "a be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1"
  fix b assume [ty]: "b be convergentCOMSEQ-2V3\<bar>Real-SequenceSEQ-1M1"
  fix c assume [ty]: "c be Complex-SequenceCOMSEQ-1M1"
  obtain g where 
    [ty]:"g be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and gDef:"g = limSEQ-2K1 a +XCMPLX-0K2 (limSEQ-2K1 b)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using xcmplx_0_def_2 sorry
  assume A1: " for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  thus A2: "c be convergentCOMSEQ-2V3"
    using comseq_3_th_38 sorry
  have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
  proof-
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar11 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar11 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using seq_2_def_7 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 b .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A3 seq_2_def_7 sorry
      have "n1 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2 & n2 <=XXREAL-0R1 n1 +XCMPLX-0K2 n2"
        using nat_1_th_11 sorry
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A6: "n1 <=XXREAL-0R1 n"and A7: "n2 <=XXREAL-0R1 n"
         sorry
      show " ex tVar11 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar11 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A8: "n <=XXREAL-0R1 m"
        then have "n2 <=XXREAL-0R1 m"
          using A7 xxreal_0_th_2 sorry
        then have A9: " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 b .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A5 sorry
        have "n1 <=XXREAL-0R1 m"
          using A6 A8 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A4 sorry
        then have A10: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 a .| +XCMPLX-0K2  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 b .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A9 xreal_1_th_8 sorry
        have "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ReCOMPLEX1K3 g =COMPLEX1R1 limSEQ-2K1 a"
          using A1 complex1_th_12 sorry
        then have A11: "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 a"
          using complex1_th_19 sorry
        have "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ImCOMPLEX1K4 g =COMPLEX1R1 limSEQ-2K1 b"
          using A1 complex1_th_12 sorry
        then have A12: "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 b"
          using complex1_th_19 sorry
        have " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <=XXREAL-0R1  |.COMPLEX1K10 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g).| +XCMPLX-0K2  |.COMPLEX1K10 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g).|"
          using comseq_3_th_12 sorry
        thus " not  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
          using A10 A11 A12 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "limCOMSEQ-2K3 c =COMPLEX1R1 limSEQ-2K1 a +XCMPLX-0K2 (limSEQ-2K1 b)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A2 comseq_2_def_6 sorry
qed "sorry"

mtheorem comseq_3_th_40:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3) & limSEQ-2K1 a =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 b =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
  fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
  fix c assume [ty]: "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
  assume A1: " for n be NatNAT-1M1 holds ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
  have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p)"
  proof-
    have " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar12 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar12 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "p >XXREAL-0R4 0NUMBERSK6"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .| <XXREAL-0R3 p"
        using A3 comseq_2_def_6 sorry
      show " ex tVar12 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar12 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A5: " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .| <XXREAL-0R3 p"
          using A4 sorry
        have "ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c) =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
          using A1 complex1_th_19 sorry
        then have " |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c) .| <=XXREAL-0R1  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .|"
          using comseq_3_th_13 sorry
        thus " not  |.COMPLEX1K10 b .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p"
          using A5 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A6: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p)"
  proof-
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar13 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar13 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A7: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .| <XXREAL-0R3 p"
        using A7 comseq_2_def_6 sorry
      show " ex tVar13 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar13 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        have "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
          using A1 sorry
        then have "ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c) =COMPLEX1R1 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)"
          using complex1_th_19 sorry
        then have A9: " |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c) .| <=XXREAL-0R1  |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .|"
          using comseq_3_th_13 sorry
        assume "n <=XXREAL-0R1 m"
        then have " |.COMPLEX1K10 c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 limCOMSEQ-2K3 c .| <XXREAL-0R3 p"
          using A8 sorry
        thus " not  |.COMPLEX1K10 a .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (limCOMSEQ-2K3 c) .| <XXREAL-0R3 p"
          using A9 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3"
    using A1 comseq_3_th_38 sorry
  thus "((a be convergentCOMSEQ-2V3 & b be convergentCOMSEQ-2V3) & limSEQ-2K1 a =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 b =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
    using A6 A2 seq_2_def_7 sorry
qed "sorry"

mtheorem comseq_3_th_41:
" for c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1 holds ((ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3) & limSEQ-2K1 ReCOMSEQ-3K7 c =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 ImCOMSEQ-3K8 c =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
proof(rule ballI)
  fix c assume [ty]: "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
  have "( for n be NatNAT-1M1 holds ReCOMSEQ-3K7 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) & ( for n be NatNAT-1M1 holds ImCOMSEQ-3K8 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
    using comseq_3_def_5 comseq_3_def_6 sorry
  thus "((ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3) & limSEQ-2K1 ReCOMSEQ-3K7 c =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 c)) & limSEQ-2K1 ImCOMSEQ-3K8 c =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 c)"
    using comseq_3_th_40 sorry
qed "sorry"

mtheorem comseq_3_cl_7:
  mlet "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K7 c as-term-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 c implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_41 sorry
qed "sorry"

mtheorem comseq_3_cl_8:
  mlet "c be convergentCOMSEQ-2V3\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K8 c as-term-is convergentCOMSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 c implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_41 sorry
qed "sorry"

mtheorem comseq_3_th_42:
" for c be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3 implies (c be convergentCOMSEQ-2V3 & ReCOMPLEX1K3 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ReCOMSEQ-3K7 c) & ImCOMPLEX1K4 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ImCOMSEQ-3K8 c"
proof(rule ballI,rule impI)
  fix c assume [ty]: "c be Complex-SequenceCOMSEQ-1M1"
  assume A1: "ReCOMSEQ-3K7 c be convergentCOMSEQ-2V3 & ImCOMSEQ-3K8 c be convergentCOMSEQ-2V3"
  have A2: "( for n be NatNAT-1M1 holds ReCOMSEQ-3K7 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)) & ( for n be NatNAT-1M1 holds ImCOMSEQ-3K8 c .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (c .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
    using comseq_3_def_5 comseq_3_def_6 sorry
  then have "limCOMSEQ-2K3 c =COMPLEX1R1 limSEQ-2K1 ReCOMSEQ-3K7 c +XCMPLX-0K2 (limSEQ-2K1 ImCOMSEQ-3K8 c)*XCMPLX-0K3 (<i>COMPLEX1K8)"
    using A1 comseq_3_th_39 sorry
  thus "(c be convergentCOMSEQ-2V3 & ReCOMPLEX1K3 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ReCOMSEQ-3K7 c) & ImCOMPLEX1K4 (limCOMSEQ-2K3 c) =COMPLEX1R1 limSEQ-2K1 ImCOMSEQ-3K8 c"
    using A1 A2 comseq_3_th_39 complex1_th_12 sorry
qed "sorry"

mtheorem comseq_3_th_43:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds ((0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M) & seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 z) & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z.| &  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M implies (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 z & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 z.|"
      and A2: " |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M"
    let ?g = "\<lambda>Lamb1. ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain rseq1 where
      [ty]:"rseq1 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?g(n)"
      using seq_1_sch_1 sorry
    assume A4: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =COMPLEX1R1 z"
      and A5: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
    have A6: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
      proof-
        let ?P = "\<lambda>Lamb1.  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Lamb1.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
        have A7: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (k +NAT-1K1 \<one>\<^sub>M) implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A8: "?P(k)"
            have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> k *XCMPLX-0K3 z .|"
              using A5 sorry
            also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ( |.COMPLEX1K10 z.|)"
              using A8 complex1_th_65 sorry
            also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (k +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 \<one>\<^sub>M"
              using power_th_25 sorry
            also have "... = ( |.COMPLEX1K10 z.|)to-powerPOWERK2 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
              using A1 power_th_27 sorry
            finally have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =HIDDENR1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
               sorry
            thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (k +NAT-1K1 \<one>\<^sub>M).| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A9: "?P(0NUMBERSK6)"
          using A4 power_th_25 sorry
        have " for n be NatNAT-1M1 holds ?P(n)"
          using nat_1_sch_2 A9 A7 sorry
        thus " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A10: " for n be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      then have A11: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).|"
        using comseq_3_def_5 sorry
      have " |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
        using A6 comseq_3_th_13 sorry
      thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 A11 sorry
    qed "sorry"
    have A12: " for n be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A13: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
        using A6 sorry
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| &  |.COMPLEX1K10 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using comseq_3_th_13 seq_1_th_12 sorry
      then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.COMPLEX1K10 z.|)to-powerPOWERK2 (n +NAT-1K1 \<one>\<^sub>M)"
        using A13 comseq_3_def_6 sorry
      thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 sorry
    qed "sorry"
    have "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
      using seq_1_th_57 sorry
    then have A14: "limSEQ-2K1 (seq-constSEQ-1K1 (0NUMBERSK6)) =COMPLEX1R1 0NUMBERSK6"
      using seq_4_th_25 sorry
    have A15: "rseq1 be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq1 =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 series_1_th_1 sorry
    have " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
      thus "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
    qed "sorry"
    then have A16: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) be convergentCOMSEQ-2V3 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) =COMPLEX1R1 0NUMBERSK6"
      using A14 A15 A10 seq_2_th_19 seq_2_th_20 sorry
    then have A17: "ReCOMSEQ-3K7 seq be convergentCOMSEQ-2V3"
      using seq_4_th_15 sorry
    have " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
      thus "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
    qed "sorry"
    then have A18: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) be convergentCOMSEQ-2V3 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) =COMPLEX1R1 0NUMBERSK6"
      using A14 A15 A12 seq_2_th_19 seq_2_th_20 sorry
    then have A19: "ImCOMSEQ-3K8 seq be convergentCOMSEQ-2V3"
      using seq_4_th_15 sorry
    have "limSEQ-2K1 ImCOMSEQ-3K8 seq =COMPLEX1R1 0NUMBERSK6"
      using A18 seq_4_th_15 sorry
    then have A20: "ImCOMPLEX1K4 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A17 A19 comseq_3_th_42 sorry
    have "limSEQ-2K1 ReCOMSEQ-3K7 seq =COMPLEX1R1 0NUMBERSK6"
      using A16 seq_4_th_15 sorry
    then have "ReCOMPLEX1K3 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A17 A19 comseq_3_th_42 sorry
    thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
      using A17 A19 A20 comseq_3_lm_1 comseq_3_th_42 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_44:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: " |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)"
    have A3: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z  |^COMSEQ-3K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using A2 sorry
      also have "... = z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 z"
        using newton_th_6 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
        using A2 sorry
      finally show "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 z"
         sorry
    qed "sorry"
    have A4: " |.COMPLEX1K10 z.| =COMPLEX1R1 0NUMBERSK6 implies seq be convergentCOMSEQ-2V3 & (seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6)"
    proof(rule impI,rule conjMI)
      assume " |.COMPLEX1K10 z.| =COMPLEX1R1 0NUMBERSK6"
      then have A5: "z =COMPLEX1R1 0cCOMPLEX1K6"
        using complex1_th_45 sorry
      have A6: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using A2 A5 sorry
        also have "... = 0cCOMPLEX1K6 GeoSeqCOMSEQ-3K1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 0cCOMPLEX1K6"
          using comseq_3_def_1 sorry
        also have "... = 0cCOMPLEX1K6"
           sorry
        finally show "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 0cCOMPLEX1K6"
           sorry
      qed "sorry"
      thus "seq be convergentCOMSEQ-2V3"
        using comseq_2_th_9 sorry
      show "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
        using A6 comseq_2_th_9 comseq_2_th_10 sorry
    qed
    have A7: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z  |^COMSEQ-3K2 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    also have "... = z"
       sorry
    finally have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) =HIDDENR1 z"
       sorry
    have " |.COMPLEX1K10 z.| <>HIDDENR2 0NUMBERSK6 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
    proof(rule impI)
      have A8: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 z.|"
        using complex1_th_46 sorry
      assume " |.COMPLEX1K10 z.| <>HIDDENR2 0NUMBERSK6"
      thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
        using A1 A7 A3 A8 comseq_3_th_43 sorry
    qed
    thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_45:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 r) implies  not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be convergentCOMSEQ-2V3 or limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) <>HIDDENR2 0NUMBERSK6"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 r) implies  not ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be convergentCOMSEQ-2V3 & limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) <>HIDDENR2 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r >XXREAL-0R4 0NUMBERSK6"
      and A2: " ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 r"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| >=XXREAL-0R2 r"
      using A2 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies  |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >=XXREAL-0R2 r"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A4: "n >=XXREAL-0R2 m"
      have "0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using comseq_3_lm_3 sorry
      then have " |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using absvalue_def_1 sorry
      also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      finally have " |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
         sorry
      thus " |.COMPLEX1K10 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| >=XXREAL-0R2 r"
        using A3 A4 sorry
    qed "sorry"
    thus " not ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be convergentCOMSEQ-2V3 & limSEQ-2K1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) <>HIDDENR2 0NUMBERSK6)"
      using A1 series_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_46:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 iff ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  not (seq be convergentCOMSEQ-2V3 &  not ( for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p)))))) &  not (( for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))))) &  not seq be convergentCOMSEQ-2V3)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have A1: "( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p)) implies ReCOMSEQ-3K7 seq be convergentCOMSEQ-2V3 & (ImCOMSEQ-3K8 seq be convergentCOMSEQ-2V3 & seq be convergentCOMSEQ-2V3)"
    proof(rule impI,rule conjMI,rule conjMI)
      assume A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p)"
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar14 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar14 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar14 .| <XXREAL-0R3 p)"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A4: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
            using A2 A3 sorry
          show " ex tVar14 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar14 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar14 .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "n <=XXREAL-0R1 m"
            then have A5: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
              using A4 sorry
            have "ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -REAL-1K5 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using complex1_th_19 sorry
            also have "... = ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using comseq_3_def_5 sorry
            also have "... = ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using comseq_3_def_5 sorry
            finally have "ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
            then have " |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
              using comseq_3_th_13 sorry
            thus " not  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p"
              using A5 xxreal_0_th_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus A6: "ReCOMSEQ-3K7 seq be convergentCOMSEQ-2V3"
        using seq_4_th_41 sorry
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p)"
      proof-
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar15 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar15 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar15 .| <XXREAL-0R3 p)"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A7: "0NUMBERSK6 <XXREAL-0R3 p"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A8: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
            using A2 A7 sorry
          show " ex tVar15 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar15 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> tVar15 .| <XXREAL-0R3 p"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "n <=XXREAL-0R1 m"
            then have A9: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
              using A8 sorry
            have "ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m) -REAL-1K5 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using complex1_th_19 sorry
            also have "... = ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
              using comseq_3_def_6 sorry
            also have "... = ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using comseq_3_def_6 sorry
            finally have "ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =HIDDENR1 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
               sorry
            then have " |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
              using comseq_3_th_13 sorry
            thus " not  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p"
              using A9 xxreal_0_th_2 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "ImCOMSEQ-3K8 seq be convergentCOMSEQ-2V3"
        using seq_4_th_41 sorry
      thus "seq be convergentCOMSEQ-2V3"
        using A6 comseq_3_th_42 sorry
    qed
    have "seq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))"
    proof(rule impI,rule ballI,rule impI)
      assume "seq be convergentCOMSEQ-2V3"
      then obtain z where
        [ty]:"z be ComplexXCMPLX-0M1" and 
        A10: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p)"
         sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A11: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A10 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A12: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A11 sorry
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 z .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A11 sorry
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 z .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
          using A12 xreal_1_th_8 sorry
        then have A13: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 z -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
          using complex1_th_60 sorry
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 z .| +XCMPLX-0K2  |.COMPLEX1K10 z -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
          using complex1_th_63 sorry
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
          using A13 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " not (seq be convergentCOMSEQ-2V3 &  not ( for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p)))))) &  not (( for p be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 p & ( for n be NatNAT-1M1 holds  not ( for m be NatNAT-1M1 holds  not (n <=XXREAL-0R1 m &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))))) &  not seq be convergentCOMSEQ-2V3)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_47:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n <=XXREAL-0R1 m & n <=XXREAL-0R1 l implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 p))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be convergentCOMSEQ-2V3 implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds tVar17 <=XXREAL-0R1 m & tVar17 <=XXREAL-0R1 l implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 p))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be convergentCOMSEQ-2V3"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "0NUMBERSK6 <XXREAL-0R3 p"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
      using A1 comseq_3_th_46 sorry
    show " ex tVar17 be NatNAT-1M1 st  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds tVar17 <=XXREAL-0R1 m & tVar17 <=XXREAL-0R1 l implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 p"
    proof(rule bexI[of _ "n"],rule ballI,rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      fix l assume [ty]: "l be NatNAT-1M1"
      assume "n <=XXREAL-0R1 m & n <=XXREAL-0R1 l"
      then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 sorry
      then have A3: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 p /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_8 sorry
      have " |.COMPLEX1K10 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)-XCMPLX-0K6 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
        using complex1_th_57 sorry
      thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> l .| <XXREAL-0R3 p"
        using A3 xxreal_0_th_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_48:
" for rseq be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & rseq be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq =COMPLEX1R1 0NUMBERSK6 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
proof-
  have " for rseq be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & (rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 0NUMBERSK6) implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix rseq assume [ty]: "rseq be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A2: "rseq be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq =COMPLEX1R1 0NUMBERSK6"
    have A3: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
      thus "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
    qed "sorry"
    have "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
      using seq_1_th_57 sorry
    then have A4: "limSEQ-2K1 (seq-constSEQ-1K1 (0NUMBERSK6)) =COMPLEX1R1 0NUMBERSK6"
      using seq_4_th_25 sorry
    have " for n be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using comseq_3_def_5 sorry
      then have A5: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).|"
        using seq_1_th_12 sorry
      have " |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 comseq_3_th_13 sorry
      thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A5 xxreal_0_th_2 sorry
    qed "sorry"
    then have A6: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) be convergentCOMSEQ-2V3 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ReCOMSEQ-3K7 seq) =COMPLEX1R1 0NUMBERSK6"
      using A2 A4 A3 seq_2_th_19 seq_2_th_20 sorry
    then have A7: "ReCOMSEQ-3K7 seq be convergentCOMSEQ-2V3"
      using seq_4_th_15 sorry
    have A8: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using seq_1_th_12 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
      thus "(seq-constSEQ-1K1 (0NUMBERSK6)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_57 sorry
    qed "sorry"
    have " for n be NatNAT-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A9: "ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 ImCOMSEQ-3K8 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using comseq_3_def_6 seq_1_th_12 sorry
      have " |.COMPLEX1K10 ImCOMPLEX1K4 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| &  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 comseq_3_th_13 sorry
      thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A9 xxreal_0_th_2 sorry
    qed "sorry"
    then have A10: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) be convergentCOMSEQ-2V3 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (ImCOMSEQ-3K8 seq) =COMPLEX1R1 0NUMBERSK6"
      using A2 A4 A8 seq_2_th_19 seq_2_th_20 sorry
    then have A11: "ImCOMSEQ-3K8 seq be convergentCOMSEQ-2V3"
      using seq_4_th_15 sorry
    have "limSEQ-2K1 ImCOMSEQ-3K8 seq =COMPLEX1R1 0NUMBERSK6"
      using A10 seq_4_th_15 sorry
    then have A12: "ImCOMPLEX1K4 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A7 A11 comseq_3_th_42 sorry
    have "limSEQ-2K1 ReCOMSEQ-3K7 seq =COMPLEX1R1 0NUMBERSK6"
      using A6 seq_4_th_15 sorry
    then have "ReCOMPLEX1K3 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A7 A11 comseq_3_th_42 sorry
    thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
      using A7 A11 A12 comseq_3_lm_1 comseq_3_th_42 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem comseq_3_th_49:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq1 implies ReCOMSEQ-3K7 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ReCOMSEQ-3K7 seq1 & ImCOMSEQ-3K8 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ImCOMSEQ-3K8 seq1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq1 implies ReCOMSEQ-3K7 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ReCOMSEQ-3K7 seq1 & ImCOMSEQ-3K8 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ImCOMSEQ-3K8 seq1"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume "seq be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq1"
    then obtain Nseq where
      [ty]:"Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A1: "seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 *COMSEQ-3K9 Nseq"
      using valued_0_def_17 sorry
    have "ReCOMSEQ-3K7 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A1 comseq_3_th_22 sorry
    thus "ReCOMSEQ-3K7 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ReCOMSEQ-3K7 seq1"
       sorry
    have "ImCOMSEQ-3K8 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A1 comseq_3_th_22 sorry
    thus "ImCOMSEQ-3K8 seq be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ImCOMSEQ-3K8 seq1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_50:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be boundedCOMSEQ-2V2 implies ( ex seq1 be Complex-SequenceCOMSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be convergentCOMSEQ-2V3)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be boundedCOMSEQ-2V2 implies  not ( for seq1 be Complex-SequenceCOMSEQ-1M1 holds  not (seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be convergentCOMSEQ-2V3))"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume "seq be boundedCOMSEQ-2V2"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 r"and A2: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <XXREAL-0R3 r"
      using comseq_2_th_8 sorry
    have " for n be NatNAT-1M1 holds  |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have " |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1  |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| &  |.COMPLEX1K10 ReCOMPLEX1K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using comseq_3_def_5 comseq_3_th_13 sorry
      thus " |.COMPLEX1K10 ReCOMSEQ-3K7 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
        using A2 xxreal_0_th_2 sorry
    qed "sorry"
    then have "ReCOMSEQ-3K7 seq be boundedCOMSEQ-2V1"
      using A1 seq_2_th_3 sorry
    then obtain rseq1 where
      [ty]:"rseq1 be Real-SequenceSEQ-1M1" and 
      A3: "rseq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ReCOMSEQ-3K7 seq"and A4: "rseq1 be convergentCOMSEQ-2V3"
      using seq_4_th_40 sorry
    obtain Nseq where
      [ty]:"Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A5: "rseq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A3 valued_0_def_17 sorry
    have A6: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <XXREAL-0R3 r"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have " |.COMPLEX1K10 (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (Nseq .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n).|"
        using funct_2_th_15 sorry
      thus " |.COMPLEX1K10 (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <XXREAL-0R3 r"
        using A2 sorry
    qed "sorry"
    have " for n be NatNAT-1M1 holds  |.COMPLEX1K10 ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have " |.COMPLEX1K10 ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| =COMPLEX1R1  |.COMPLEX1K10 ImCOMPLEX1K4 ((seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| &  |.COMPLEX1K10 ImCOMPLEX1K4 ((seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n).| <=XXREAL-0R1  |.COMPLEX1K10 (seq *COMSEQ-3K9 Nseq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using comseq_3_def_6 comseq_3_th_13 sorry
      thus " |.COMPLEX1K10 ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <XXREAL-0R3 r"
        using A6 xxreal_0_th_2 sorry
    qed "sorry"
    then have "ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) be boundedCOMSEQ-2V1"
      using A1 seq_2_th_3 sorry
    then obtain rseq2 where
      [ty]:"rseq2 be Real-SequenceSEQ-1M1" and 
      A7: "rseq2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq)"and A8: "rseq2 be convergentCOMSEQ-2V3"
      using seq_4_th_40 sorry
    obtain Nseq1 where
      [ty]:"Nseq1 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A9: "rseq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 (seq *COMSEQ-3K9 Nseq) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1"
      using A7 valued_0_def_17 sorry
    have "ReCOMSEQ-3K7 ((seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1) =HIDDENR1 ReCOMSEQ-3K7 (seq *COMSEQ-3K9 Nseq) *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1"
      using comseq_3_th_22 sorry
    also have "... = rseq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1"
      using A5 comseq_3_th_22 sorry
    finally have "ReCOMSEQ-3K7 ((seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1) =HIDDENR1 rseq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1"
       sorry
    then have A10: "ReCOMSEQ-3K7 ((seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1) be convergentCOMSEQ-2V3"
      using A4 seq_4_th_16 sorry
    have "seq *COMSEQ-3K9 Nseq be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & (seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq *COMSEQ-3K9 Nseq"
      using valued_0_def_17 sorry
    then have A11: "(seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq"
      using valued_0_th_20 sorry
    have "ImCOMSEQ-3K8 ((seq *COMSEQ-3K9 Nseq)*COMSEQ-3K9 Nseq1) be convergentCOMSEQ-2V3"
      using A8 A9 comseq_3_th_22 sorry
    thus " not ( for seq1 be Complex-SequenceCOMSEQ-1M1 holds  not (seq1 be subsequenceVALUED-0M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of seq & seq1 be convergentCOMSEQ-2V3))"
      using A11 A10 comseq_3_th_42 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef comseq_3_def_8 ("summableCOMSEQ-3V1" 70 ) where
"attr summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>seq. Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3)"..

mtheorem comseq_3_cl_9:
"cluster summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be summableCOMSEQ-3V1"
  proof-
    have " ex tVar18 be Complex-SequenceCOMSEQ-1M1 st tVar18 be summableCOMSEQ-3V1"
    proof-
      show " ex tVar18 be Complex-SequenceCOMSEQ-1M1 st tVar18 be summableCOMSEQ-3V1"
      proof(rule bexI[of _ "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"])
        have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar20 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar20 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6) .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0cCOMPLEX1K6 .|))"
        proof(rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
          show " ex tVar20 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar20 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6) .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0cCOMPLEX1K6 .|)"
          proof(rule bexI[of _ "0NUMBERSK6"])
            have " for n be NatNAT-1M1 holds (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
              using ordinal1_def_12 funcop_1_th_7 sorry
            thus " for VarFor1 be setHIDDENM2 holds  not (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6) .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0cCOMPLEX1K6 .|)"
              using A1 comseq_3_th_24 complex1_th_44 sorry
          qed "sorry"
        qed "sorry"
        thus "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 be summableCOMSEQ-3V1"
          using bexI[of _ "0cCOMPLEX1K6"] comseq_2_def_5 comseq_3_def_8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_cl_10:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsCOMSEQ-3K10 seq as-term-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 Partial-SumsCOMSEQ-3K10 seq implies it be convergentCOMSEQ-2V3"
    using comseq_3_def_8 sorry
qed "sorry"

mdef comseq_3_def_9 ("absolutely-summableCOMSEQ-3V2" 70 ) where
"attr absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1 means
  (\<lambda>seq.  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1)"..

mtheorem comseq_3_th_51:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6) implies seq be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar22 be setHIDDENM2 st  for m be NatNAT-1M1 holds  not (tVar22 <=XXREAL-0R1 m & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .FUNCT-1K1 m -XCMPLX-0K6 tVar22 .|))"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A2: "0NUMBERSK6 <XXREAL-0R3 p"
      show " ex tVar22 be setHIDDENM2 st  for m be NatNAT-1M1 holds  not (tVar22 <=XXREAL-0R1 m & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .FUNCT-1K1 m -XCMPLX-0K6 tVar22 .|)"
      proof(rule bexI[of _ "0NUMBERSK6"],rule ballI)
        fix m assume [ty]: "m be NatNAT-1M1"
        have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 -XCMPLX-0K6 0NUMBERSK6 .|"
          using A1 comseq_3_th_25 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_def_1 sorry
        finally have " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " not (0NUMBERSK6 <=XXREAL-0R1 m & p <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .|)"
          using A2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be absolutely-summableCOMSEQ-3V2"
      using bexI[of _ "0NUMBERSK6"] comseq_2_def_5 series_1_def_2 comseq_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_11:
"cluster absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be absolutely-summableCOMSEQ-3V2"
  proof-
    have " ex tVar23 be Complex-SequenceCOMSEQ-1M1 st tVar23 be absolutely-summableCOMSEQ-3V2"
    proof-
      show " ex tVar23 be Complex-SequenceCOMSEQ-1M1 st tVar23 be absolutely-summableCOMSEQ-3V2"
      proof(rule bexI[of _ "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"])
        have " for n be NatNAT-1M1 holds (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 0cCOMPLEX1K6"
          using ordinal1_def_12 funcop_1_th_7 sorry
        thus "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 be absolutely-summableCOMSEQ-3V2"
          using comseq_3_th_51 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_cl_12:
  mlet "seq be absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| implies it be summableSERIES-1V1"
    using comseq_3_def_9 sorry
qed "sorry"

mtheorem comseq_3_th_52:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be summableCOMSEQ-3V1"
    then have "ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
       sorry
    then have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    then have A2: "ReCOMSEQ-3K7 seq be summableSERIES-1V1"
       sorry
    have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
      using A1 sorry
    then have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    then have A3: "ImCOMSEQ-3K8 seq be summableSERIES-1V1"
       sorry
    then have "limSEQ-2K1 ImCOMSEQ-3K8 seq =COMPLEX1R1 0NUMBERSK6"
      using series_1_th_4 sorry
    then have A4: "ImCOMPLEX1K4 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A2 A3 comseq_3_th_42 sorry
    have "limSEQ-2K1 ReCOMSEQ-3K7 seq =COMPLEX1R1 0NUMBERSK6"
      using A2 series_1_th_4 sorry
    then have "ReCOMPLEX1K3 (limCOMSEQ-2K3 seq) =COMPLEX1R1 0NUMBERSK6"
      using A2 A3 comseq_3_th_42 sorry
    thus "seq be convergentCOMSEQ-2V3 & limCOMSEQ-2K3 seq =COMPLEX1R1 0cCOMPLEX1K6"
      using A2 A3 A4 comseq_3_lm_1 comseq_3_th_42 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_13:
"cluster summableCOMSEQ-3V1 also-is convergentCOMSEQ-2V3 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be summableCOMSEQ-3V1 implies it be convergentCOMSEQ-2V3"
    using comseq_3_th_52 sorry
qed "sorry"

mtheorem comseq_3_th_53:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies (ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1) & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies (ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1) & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have A1: "limSEQ-2K1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) & limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq)"
      using comseq_3_th_26 sorry
    assume A2: "seq be summableCOMSEQ-3V1"
    then have "ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
       sorry
    then have A3: "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    have "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
      using A2 sorry
    then have A4: "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    have "limSEQ-2K1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq) & limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq)"
      using A2 comseq_3_th_41 sorry
    thus "(ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1) & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A3 A4 A1 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_14:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ReCOMSEQ-3K7 seq as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ReCOMSEQ-3K7 seq implies it be summableSERIES-1V1"
    using comseq_3_th_53 sorry
qed "sorry"

mtheorem comseq_3_cl_15:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster ImCOMSEQ-3K8 seq as-term-is summableSERIES-1V1 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 ImCOMSEQ-3K8 seq implies it be summableSERIES-1V1"
    using comseq_3_th_53 sorry
qed "sorry"

mtheorem comseq_3_th_54:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 +XCMPLX-0K2 SumCOMSEQ-3K11 seq2"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 +XCMPLX-0K2 SumCOMSEQ-3K11 seq2"
  proof(rule ballI,rule ballI,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1"
    then have A2: "Partial-SumsCOMSEQ-3K10 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 be convergentCOMSEQ-2V3"
       sorry
    have A3: "Partial-SumsCOMSEQ-3K10 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_3_th_27 sorry
    have "SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 limCOMSEQ-2K3 (Partial-SumsCOMSEQ-3K10 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2)"
      using comseq_3_th_27 sorry
    also have "... = limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq1 +XCMPLX-0K2 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq2"
      using A1 comseq_2_th_14 sorry
    finally have "SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq1 +XCMPLX-0K2 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq2"
       sorry
    thus "seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 +XCMPLX-0K2 SumCOMSEQ-3K11 seq2"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_55:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 -XCMPLX-0K6 SumCOMSEQ-3K11 seq2"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1 implies seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 -XCMPLX-0K6 SumCOMSEQ-3K11 seq2"
  proof(rule ballI,rule ballI,rule impI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be summableCOMSEQ-3V1 & seq2 be summableCOMSEQ-3V1"
    then have A2: "Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 be convergentCOMSEQ-2V3"
       sorry
    have A3: "Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_3_th_28 sorry
    have "SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 limCOMSEQ-2K3 (Partial-SumsCOMSEQ-3K10 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq2)"
      using comseq_3_th_28 sorry
    also have "... = limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq1 -XCMPLX-0K6 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq2"
      using A1 comseq_2_th_26 sorry
    finally have "SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq1 -XCMPLX-0K6 limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq2"
       sorry
    thus "seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =COMPLEX1R1 SumCOMSEQ-3K11 seq1 -XCMPLX-0K6 SumCOMSEQ-3K11 seq2"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_16:
  mlet "seq1 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "seq2 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq1 +SERIES-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_54 sorry
qed "sorry"

mtheorem comseq_3_cl_17:
  mlet "seq1 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "seq2 be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_55 sorry
qed "sorry"

mtheorem comseq_3_th_56:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for z be ComplexXCMPLX-0M1 holds z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 z *XCMPLX-0K3 SumCOMSEQ-3K11 seq)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for z be ComplexXCMPLX-0M1 holds z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 z *XCMPLX-0K3 SumCOMSEQ-3K11 seq)"
  proof(rule ballI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be summableCOMSEQ-3V1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    have A2: "Partial-SumsCOMSEQ-3K10 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq"
      using comseq_3_th_29 sorry
    have "SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 limCOMSEQ-2K3 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 seq)"
      using comseq_3_th_29 sorry
    also have "... = z *XCMPLX-0K3 SumCOMSEQ-3K11 seq"
      using A1 comseq_2_th_18 sorry
    finally have "SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 z *XCMPLX-0K3 SumCOMSEQ-3K11 seq"
       sorry
    thus "z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =COMPLEX1R1 z *XCMPLX-0K3 SumCOMSEQ-3K11 seq"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_18:
  mlet "z be ElementSUBSET-1M1-of COMPLEXNUMBERSK3", "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 z (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq implies it be summableCOMSEQ-3V1"
    using comseq_3_th_56 sorry
qed "sorry"

mtheorem comseq_3_th_57:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1 implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ReCOMSEQ-3K7 seq be summableSERIES-1V1 & ImCOMSEQ-3K8 seq be summableSERIES-1V1 implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "ReCOMSEQ-3K7 seq be summableSERIES-1V1"
      and A2: "ImCOMSEQ-3K8 seq be summableSERIES-1V1"
    have "Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) be convergentCOMSEQ-2V3"
      using A2 sorry
    then have A3: "ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    have "Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) be convergentCOMSEQ-2V3"
      using A1 sorry
    then have A4: "ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3"
      using comseq_3_th_26 sorry
    then have A5: "limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 ImCOMPLEX1K4 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq)"
      using A3 comseq_3_th_42 sorry
    have A6: "limSEQ-2K1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) & limSEQ-2K1 ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq)"
      using comseq_3_th_26 sorry
    have "Partial-SumsCOMSEQ-3K10 seq be convergentCOMSEQ-2V3 & limSEQ-2K1 ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq =COMPLEX1R1 ReCOMPLEX1K3 (limCOMSEQ-2K3 Partial-SumsCOMSEQ-3K10 seq)"
      using A4 A3 comseq_3_th_42 sorry
    thus "seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A6 A5 complex1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_58:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1)"
  proof(rule ballI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be summableCOMSEQ-3V1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A2: "ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n & ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using comseq_3_th_23 sorry
    have "ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n be summableSERIES-1V1 & ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n be summableSERIES-1V1"
      using A1 series_1_th_12 sorry
    thus "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1"
      using A2 comseq_3_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_19:
  mlet "seq be summableCOMSEQ-3V1\<bar>Complex-SequenceCOMSEQ-1M1", "n be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n as-term-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n implies it be summableCOMSEQ-3V1"
    using comseq_3_th_58 sorry
qed "sorry"

mtheorem comseq_3_th_59:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( ex n be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1) implies seq be summableCOMSEQ-3V1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( ex n be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1) implies seq be summableCOMSEQ-3V1"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume Given: " ex n be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n be summableCOMSEQ-3V1"
       sorry
    have "ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using comseq_3_th_23 sorry
    then have A2: "ImCOMSEQ-3K8 seq be summableSERIES-1V1"
      using A1 series_1_th_13 sorry
    have "ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using comseq_3_th_23 sorry
    then have "ReCOMSEQ-3K7 seq be summableSERIES-1V1"
      using A1 series_1_th_13 sorry
    thus "seq be summableCOMSEQ-3V1"
      using A2 comseq_3_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_60:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds SumCOMSEQ-3K11 seq =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 implies ( for n be NatNAT-1M1 holds SumCOMSEQ-3K11 seq =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule ballI,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be summableCOMSEQ-3V1"
    then have "SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using comseq_3_th_53 sorry
    then have A2: "ReCOMPLEX1K3 SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 seq) & ImCOMPLEX1K4 SumCOMSEQ-3K11 seq =COMPLEX1R1 SumSERIES-1K4 (ImCOMSEQ-3K8 seq)"
      using complex1_th_12 sorry
    fix n assume [ty]: "n be NatNAT-1M1"
    have A3: "SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 SumSERIES-1K4 (ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) *XCMPLX-0K3 (<i>COMPLEX1K8)"
      using A1 comseq_3_th_53 sorry
    have A4: "SumSERIES-1K4 (ImCOMSEQ-3K8 seq) =HIDDENR1 Partial-SumsSERIES-1K3 (ImCOMSEQ-3K8 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 series_1_th_15 sorry
    also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using comseq_3_th_26 sorry
    also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ImCOMSEQ-3K8 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      using comseq_3_th_23 sorry
    also have "... = ImCOMSEQ-3K8 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ImCOMPLEX1K4 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A3 complex1_th_12 sorry
    also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ImCOMPLEX1K4 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using comseq_3_def_6 sorry
    also have "... = ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      using complex1_th_8 sorry
    finally have "SumSERIES-1K4 (ImCOMSEQ-3K8 seq) =HIDDENR1 ImCOMPLEX1K4 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
       sorry
    have "SumSERIES-1K4 (ReCOMSEQ-3K7 seq) =HIDDENR1 Partial-SumsSERIES-1K3 (ReCOMSEQ-3K7 seq) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A1 series_1_th_15 sorry
    also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ReCOMSEQ-3K7 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using comseq_3_th_26 sorry
    also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 SumSERIES-1K4 (ReCOMSEQ-3K7 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      using comseq_3_th_23 sorry
    also have "... = ReCOMSEQ-3K7 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A3 complex1_th_12 sorry
    also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) +REAL-1K3 ReCOMPLEX1K3 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using comseq_3_def_5 sorry
    also have "... = ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      using complex1_th_8 sorry
    finally have "SumSERIES-1K4 (ReCOMSEQ-3K7 seq) =HIDDENR1 ReCOMPLEX1K3 (Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
       sorry
    thus "SumCOMSEQ-3K11 seq =COMPLEX1R1 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 SumCOMSEQ-3K11 (seq ^\\VALUED-0K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
      using A2 A4 complex1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_61:
" for seq be Complex-SequenceCOMSEQ-1M1 holds Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3 iff seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  not (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3 &  not seq be absolutely-summableCOMSEQ-3V2) &  not (seq be absolutely-summableCOMSEQ-3V2 &  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have "Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3 iff  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
       sorry
    thus " not (Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3 &  not seq be absolutely-summableCOMSEQ-3V2) &  not (seq be absolutely-summableCOMSEQ-3V2 &  not Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) be bounded-aboveSEQ-2V3)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_20:
  mlet "seq be absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1"
"cluster Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) as-term-is bounded-aboveSEQ-2V3 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) implies it be bounded-aboveSEQ-2V3"
    using comseq_3_th_61 sorry
qed "sorry"

mtheorem comseq_3_th_62:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be summableCOMSEQ-3V1 iff ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p))"
  using comseq_3_th_46 sorry

mtheorem comseq_3_th_63:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be absolutely-summableCOMSEQ-3V2 implies seq be summableCOMSEQ-3V1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be absolutely-summableCOMSEQ-3V2 implies seq be summableCOMSEQ-3V1"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be absolutely-summableCOMSEQ-3V2"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p"
        using A1 seq_4_th_41 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have A3: " |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 p"
          using A2 sorry
        have " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <=XXREAL-0R1  |.COMPLEX1K10 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 Partial-SumsSERIES-1K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
          using comseq_3_th_31 sorry
        thus " |.COMPLEX1K10 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> m -XCMPLX-0K6 Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .| <XXREAL-0R3 p"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be summableCOMSEQ-3V1"
      using comseq_3_th_62 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_cl_21:
"cluster absolutely-summableCOMSEQ-3V2 also-is summableCOMSEQ-3V1 for Complex-SequenceCOMSEQ-1M1"
proof
(*coherence*)
  show " for it be Complex-SequenceCOMSEQ-1M1 holds it be absolutely-summableCOMSEQ-3V2 implies it be summableCOMSEQ-3V1"
    using comseq_3_th_63 sorry
qed "sorry"

mtheorem comseq_3_cl_22:
"cluster absolutely-summableCOMSEQ-3V2 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be absolutely-summableCOMSEQ-3V2"
  proof-
    have " ex tVar25 be Complex-SequenceCOMSEQ-1M1 st tVar25 be absolutely-summableCOMSEQ-3V2"
    proof-
      let ?C = "the absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1"
      show " ex tVar25 be Complex-SequenceCOMSEQ-1M1 st tVar25 be absolutely-summableCOMSEQ-3V2"
      proof(rule bexI[of _ "?C"])
        show "the absolutely-summableCOMSEQ-3V2\<bar>Complex-SequenceCOMSEQ-1M1 be absolutely-summableCOMSEQ-3V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_3_th_64:
" for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M implies z GeoSeqCOMSEQ-3K1 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
proof-
  have " for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M implies z GeoSeqCOMSEQ-3K1 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    let ?seq2 = "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
    let ?f = "\<lambda>Lamb1. z  |^COMSEQ-3K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain seq1 where
      [ty]:"seq1 be Complex-SequenceCOMSEQ-1M1" and 
      A1: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 ?f(n)"
      using comseq_1_sch_1 sorry
    assume A2: " |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M"
    then have A3: "limCOMSEQ-2K3 seq1 =COMPLEX1R1 0cCOMPLEX1K6"
      using A1 comseq_3_th_44 sorry
    have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using A2 comseq_3_th_36 complex1_th_48 sorry
      also have "... = (1rCOMPLEX1K7 -XCMPLX-0K6 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using A1 sorry
      also have "... = (1rCOMPLEX1K7 *XCMPLX-0K3 ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n -XCMPLX-0K6 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using complex1_def_4 funcop_1_th_7 sorry
      also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))*XCMPLX-0K3 ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-XCMPLX-0K4 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
        using xcmplx_1_th_74 sorry
      also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))*XCMPLX-0K3 ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_8 sorry
      also have "... = (1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))*XCMPLX-0K3 ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = ((1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    have A5: " for n be NatNAT-1M1 holds ?seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 1rCOMPLEX1K7"
      using ordinal1_def_12 funcop_1_th_7 sorry
    then have A6: "?seq2 be convergentCOMSEQ-2V3"
      using comseq_2_th_9 sorry
    have A7: "seq1 be convergentCOMSEQ-2V3"
      using A2 A1 comseq_3_th_44 sorry
    then have A8: "?seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be convergentCOMSEQ-2V3"
      using A6 sorry
    have "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) be convergentCOMSEQ-2V3 & SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
    proof(rule conjMI)
      show "Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) be convergentCOMSEQ-2V3"
        using A4 funct_2_th_63 A8 sorry
      have "limCOMSEQ-2K3 (?seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 limCOMSEQ-2K3 ?seq2 -XCMPLX-0K6 limCOMSEQ-2K3 seq1"
        using A7 A6 comseq_2_th_26 sorry
      also have "... = 1rCOMPLEX1K7"
        using A3 A5 comseq_2_th_10 sorry
      finally have "limCOMSEQ-2K3 (?seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 1rCOMPLEX1K7"
         sorry
      then have "limCOMSEQ-2K3 ((1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (?seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)) =HIDDENR1 (1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))*XCMPLX-0K3 1rCOMPLEX1K7"
        using A8 comseq_2_th_18 sorry
      also have "... = 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using complex1_def_4 sorry
      finally have "limCOMSEQ-2K3 ((1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (?seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)) =HIDDENR1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
         sorry
      thus "SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
        using A4 funct_2_th_63 sorry
    qed
    thus "z GeoSeqCOMSEQ-3K1 be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1) =COMPLEX1R1 1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
      using comseq_3_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_65:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for z be ComplexXCMPLX-0M1 holds  |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n) implies seq be summableCOMSEQ-3V1 & SumCOMSEQ-3K11 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix z assume [ty]: "z be ComplexXCMPLX-0M1"
    assume A1: " |.COMPLEX1K10 z.| <XXREAL-0R3 \<one>\<^sub>M"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 z *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 ((1rCOMPLEX1K7 -XCMPLX-0K6 z  |^COMSEQ-3K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
        using A1 A2 comseq_3_th_37 complex1_th_48 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1) .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using A1 comseq_3_th_36 complex1_th_48 sorry
      also have "... = (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "Partial-SumsCOMSEQ-3K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    then have A3: "Partial-SumsCOMSEQ-3K10 seq =FUNCT-2R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> Partial-SumsCOMSEQ-3K10 (z GeoSeqCOMSEQ-3K1)"
       sorry
    have A4: "z GeoSeqCOMSEQ-3K1 be summableCOMSEQ-3V1"
      using A1 comseq_3_th_64 sorry
    thus "seq be summableCOMSEQ-3V1"
      using A3 sorry
    have "SumCOMSEQ-3K11 seq =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 SumCOMSEQ-3K11 (z GeoSeqCOMSEQ-3K1)"
      using A3 A4 comseq_2_th_18 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (1rCOMPLEX1K7 /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z))"
      using A1 comseq_3_th_64 sorry
    also have "... = (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 1rCOMPLEX1K7)/XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
      using xcmplx_1_th_74 sorry
    also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
      using complex1_def_4 sorry
    finally have "SumCOMSEQ-3K11 seq =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
       sorry
    thus "SumCOMSEQ-3K11 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (1rCOMPLEX1K7 -XCMPLX-0K6 z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_66:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds rseq1 be summableSERIES-1V1 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq2 be absolutely-summableCOMSEQ-3V2"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds rseq1 be summableSERIES-1V1 & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq2 be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "rseq1 be summableSERIES-1V1"
      and A2: " ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies  |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A2 sorry
    have A4: " for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have " |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_18 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using complex1_th_46 sorry
    qed "sorry"
    have Cut2236: " for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "m <=XXREAL-0R1 n"
      then have " |.COMPLEX1K10 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A3 sorry
      thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_18 sorry
    qed "sorry"
    have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.| be summableSERIES-1V1"
    proof-
      show " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.| be summableSERIES-1V1"
        using A1 A4 series_1_th_19 Cut2236 sorry
    qed
    thus "seq2 be absolutely-summableCOMSEQ-3V2"
      using comseq_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_67:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & seq2 be absolutely-summableCOMSEQ-3V2 implies seq1 be absolutely-summableCOMSEQ-3V2 & SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1.|) <=XXREAL-0R1 SumSERIES-1K4 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2.|)"
  using series_1_th_20 sorry

mtheorem comseq_3_th_68:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_27 sorry

mtheorem comseq_3_th_69:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M implies seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M implies seq be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule ballI,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "(( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M"
    have Cut2262: " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6"
      using comseq_3_lm_3 sorry
    have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
    proof-
      show " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
        using A1 series_1_th_28 Cut2262 sorry
    qed
    thus "seq be absolutely-summableCOMSEQ-3V2"
      using comseq_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_70:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n implies rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M)"
    have " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6"
      using comseq_3_lm_3 sorry
    thus " not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
      using A1 series_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_71:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 >XXREAL-0R4 \<one>\<^sub>M implies  not seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 >XXREAL-0R4 \<one>\<^sub>M implies  not seq be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule ballI,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "(( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 n -rootPOWERK1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 >XXREAL-0R4 \<one>\<^sub>M"
    have Cut2284: " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6"
      using comseq_3_lm_3 sorry
    have " not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
    proof-
      show " not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
        using A1 series_1_th_30 Cut2284 sorry
    qed
    thus " not seq be absolutely-summableCOMSEQ-3V2"
      using comseq_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_72:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be non-increasingVALUED-0V12 & ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerPOWERK2 n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerPOWERK2 n) implies (seq be absolutely-summableCOMSEQ-3V2 iff rseq1 be summableSERIES-1V1)"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be non-increasingVALUED-0V12 & ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerPOWERK2 n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerPOWERK2 n) implies  not (seq be absolutely-summableCOMSEQ-3V2 &  not rseq1 be summableSERIES-1V1) &  not (rseq1 be summableSERIES-1V1 &  not seq be absolutely-summableCOMSEQ-3V2)"
  proof(rule ballI,rule ballI,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be non-increasingVALUED-0V12 & ( for n be NatNAT-1M1 holds rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerPOWERK2 n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerPOWERK2 n)"
    then have " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be non-increasingVALUED-0V12 & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 0NUMBERSK6) & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M to-powerPOWERK2 n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<two>\<^sub>M to-powerPOWERK2 n"
      using comseq_3_lm_3 sorry
    then have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1 iff rseq1 be summableSERIES-1V1"
      using series_1_th_31 sorry
    thus " not (seq be absolutely-summableCOMSEQ-3V2 &  not rseq1 be summableSERIES-1V1) &  not (rseq1 be summableSERIES-1V1 &  not seq be absolutely-summableCOMSEQ-3V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_73:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for p be RealXREAL-0M1 holds p >XXREAL-0R4 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_32 sorry

mtheorem comseq_3_th_74:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for p be RealXREAL-0M1 holds p <=XXREAL-0R1 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n to-powerPOWERK2 p) implies  not seq be absolutely-summableCOMSEQ-3V2"
  using series_1_th_33 sorry

mtheorem comseq_3_th_75:
" for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & rseq1 be convergentCOMSEQ-2V3) & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M implies seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for rseq1 be Real-SequenceSEQ-1M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & (rseq1 be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M) implies seq be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix rseq1 assume [ty]: "rseq1 be Real-SequenceSEQ-1M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      and A2: "rseq1 be convergentCOMSEQ-2V3 & limSEQ-2K1 rseq1 <XXREAL-0R3 \<one>\<^sub>M"
    have " for n be NatNAT-1M1 holds (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & ((( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) & (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
    proof(rule ballI,rule conjMI,rule conjMI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A3: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using A1 valued_1_th_18 sorry
      thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 complex1_th_47 sorry
      show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 A3 complex1_th_47 sorry
      show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6 & rseq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A1 A3 complex1_th_47 sorry
    qed "sorry"
    then have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be absolutely-summableSERIES-1V2"
      using A2 series_1_th_37 sorry
    thus "seq be absolutely-summableCOMSEQ-3V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_3_th_76:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not seq be absolutely-summableCOMSEQ-3V2"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6) & ( ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M) implies  not seq be absolutely-summableCOMSEQ-3V2"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
      and A2: " ex m be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 sorry
    have A4: " for n be NatNAT-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using A1 sorry
      then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.| <>HIDDENR2 0NUMBERSK6"
        using complex1_th_47 sorry
      thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
        using valued_1_th_18 sorry
    qed "sorry"
    have Cut2345: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 m implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /REAL-1K6 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<one>\<^sub>M"
      using A3 sorry
    have " not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
    proof-
      show " not  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.| be summableSERIES-1V1"
        using A4 series_1_th_39 Cut2345 sorry
    qed
    thus " not seq be absolutely-summableCOMSEQ-3V2"
      using comseq_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
