theory card_5
  imports ordinal4 card_4 funct_5 xfamily
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, n, m for "NatNAT-1M1"
reserve A, B, C for "OrdinalORDINAL1M3"
reserve X for "setHIDDENM2"
reserve x, y, z for "objectHIDDENM1"
mlemma card_5_lm_1:
"\<one>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 \<one>\<^sub>M"
   sorry

mlemma card_5_lm_2:
"\<two>\<^sub>M =XBOOLE-0R4 cardCARD-1K4 \<two>\<^sub>M"
   sorry

(*begin*)
reserve f, g, h, fx for "FunctionFUNCT-1M1"
reserve K, M, N for "CardinalCARD-1M1"
reserve phi, psi for "Ordinal-SequenceORDINAL2M1"
mtheorem card_5_th_1:
" for X be setHIDDENM2 holds nextcardCARD-1K2 (cardCARD-1K1 X) =XBOOLE-0R4 nextcardCARD-1K2 X"
proof-
  have " for X be setHIDDENM2 holds nextcardCARD-1K2 (cardCARD-1K1 X) =XBOOLE-0R4 nextcardCARD-1K2 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "cardCARD-1K1 (cardCARD-1K1 X) inTARSKIR2 nextcardCARD-1K2 X & ( for M be CardinalCARD-1M1 holds cardCARD-1K1 (cardCARD-1K1 X) inTARSKIR2 M implies nextcardCARD-1K2 X c=ORDINAL1R1 M)"
      using card_1_def_3 sorry
    thus "nextcardCARD-1K2 (cardCARD-1K1 X) =XBOOLE-0R4 nextcardCARD-1K2 X"
      using card_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_2:
" for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds y inHIDDENR3 UnionCARD-3K3 f iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x)"
proof-
  have " for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds (y inHIDDENR3 UnionCARD-3K3 f implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x) implies y inHIDDENR3 UnionCARD-3K3 f)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "y inHIDDENR3 UnionCARD-3K3 f implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x)"
    proof-
      have "y inHIDDENR3 UnionCARD-3K3 f implies ( ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 tVar1)"
      proof(rule impI)
        assume "y inHIDDENR3 UnionCARD-3K3 f"
        then obtain X where
          [ty]:"X be setHIDDENM2" and 
          A1: "y inHIDDENR3 X"and A2: "X inTARSKIR2 rngFUNCT-1K2 f"
          using tarski_def_4 sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 domRELAT-1K1 f & X =XBOOLE-0R4 f .FUNCT-1K1 x"
          using A2 funct_1_def_3 sorry
        show " ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 tVar1"
        proof(rule bexI[of _ "x"])
          show "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x"
            using A1 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 f .FUNCT-1K1 x"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A4: "x inHIDDENR3 domRELAT-1K1 f"and A5: "y inHIDDENR3 f .FUNCT-1K1 x"
       sorry
    have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using A4 funct_1_def_3 sorry
    thus "y inHIDDENR3 UnionCARD-3K3 f"
      using A5 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_3:
" for A be OrdinalORDINAL1M3 holds alephCARD-1K3 A be infiniteFINSET-1V2"
proof-
  have " for A be OrdinalORDINAL1M3 holds  not alephCARD-1K3 A be infiniteFINSET-1V2"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "{}XBOOLE-0K1 c=MEMBEREDR6 A"
       sorry
    then have "omegaORDINAL1K4 c=MEMBEREDR6 alephCARD-1K3 A"
      using card_1_th_23 card_1_th_46 sorry
    thus " not alephCARD-1K3 A be infiniteFINSET-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_4:
" for M be CardinalCARD-1M1 holds M be infiniteFINSET-1V2 implies ( ex A be OrdinalORDINAL1M3 st M =XBOOLE-0R4 alephCARD-1K3 A)"
proof-
  have " for M be CardinalCARD-1M1 holds  not ( not M be infiniteFINSET-1V2 & ( for A be OrdinalORDINAL1M3 holds  not M =XBOOLE-0R4 alephCARD-1K3 A))"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 be infiniteFINSET-1V2 implies ( ex A be OrdinalORDINAL1M3 st Lamb1 =XBOOLE-0R4 alephCARD-1K3 A)"
    have A1: " for K be CardinalCARD-1M1 holds ?P(K) implies ?P(nextcardCARD-1K2 K)"
    proof-
      have " for K be CardinalCARD-1M1 holds (K be infiniteFINSET-1V2 implies ( ex A be OrdinalORDINAL1M3 st K =XBOOLE-0R4 alephCARD-1K3 A)) &  not nextcardCARD-1K2 K be finiteFINSET-1V1 implies ( ex tVar2 be OrdinalORDINAL1M3 st nextcardCARD-1K2 K =XBOOLE-0R4 alephCARD-1K3 tVar2)"
      proof(rule ballI,rule impMI ,rule impI)
        fix K assume [ty]: "K be CardinalCARD-1M1"
        assume A2: "?P(K)"
          and A3: " not nextcardCARD-1K2 K be finiteFINSET-1V1"
        have "K be finiteFINSET-1V1 implies  False "
        proof(rule impI)
          assume "K be finiteFINSET-1V1"
          then obtain K9 where 
            [ty]:"K9 be finiteFINSET-1V1\<bar>setHIDDENM2" and K9Def:"K9 = K"
             sorry
          have "nextcardCARD-1K2 (SegmORDINAL1K6 cardCARD-1K4 K9) =XBOOLE-0R4 cardCARD-1K4 (SegmORDINAL1K6 (cardCARD-1K4 K9 +NAT-1K1 \<one>\<^sub>M))"
            using nat_1_th_42 sorry
          thus " False "
            using A3 sorry
        qed
        then obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A4: "K =XBOOLE-0R4 alephCARD-1K3 A"
          using A2 sorry
        show " ex tVar2 be OrdinalORDINAL1M3 st nextcardCARD-1K2 K =XBOOLE-0R4 alephCARD-1K3 tVar2"
        proof(rule bexI[of _ "succORDINAL1K1 A"])
          show "nextcardCARD-1K2 K =XBOOLE-0R4 alephCARD-1K3 (succORDINAL1K1 A)"
            using A4 card_1_th_19 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for K be CardinalCARD-1M1 holds (K <>HIDDENR2 {}XBOOLE-0K1 & K be limit-cardinalCARD-1V2) & ( for N be CardinalCARD-1M1 holds N inTARSKIR2 K implies ?P(N)) implies ?P(K)"
    proof-
      have " for K be CardinalCARD-1M1 holds K <>HIDDENR2 {}XBOOLE-0K1 & (K be limit-cardinalCARD-1V2 & (( for N be CardinalCARD-1M1 holds N inTARSKIR2 K implies (N be infiniteFINSET-1V2 implies ( ex A be OrdinalORDINAL1M3 st N =XBOOLE-0R4 alephCARD-1K3 A))) &  not K be finiteFINSET-1V1)) implies ( ex tVar3 be OrdinalORDINAL1M3 st K =XBOOLE-0R4 alephCARD-1K3 tVar3)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix K assume [ty]: "K be CardinalCARD-1M1"
        let ?a = "\<lambda>Lamb1. alephCARD-1K3 Lamb1"
        let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be OrdinalORDINAL1M3 st Lamb1 =HIDDENR1 alephCARD-1K3 A & Lamb2 =HIDDENR1 A"
        assume "K <>HIDDENR2 {}XBOOLE-0K1"
          and A6: "K be limit-cardinalCARD-1V2"
          and A7: " for N be CardinalCARD-1M1 holds N inTARSKIR2 K implies ?P(N)"
          and A8: " not K be finiteFINSET-1V1"
        let ?P = "\<lambda>Lamb1.  ex N be CardinalCARD-1M1 st N =HIDDENR1 Lamb1 &  not N be finiteFINSET-1V1"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A9: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 K & ?P(x)"
          using xboole_0_sch_1 sorry
        have A10: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st ?R(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies  not ( for y be objectHIDDENM1 holds  not ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 alephCARD-1K3 A & y =HIDDENR1 A))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A11: "x inHIDDENR3 X"
            then obtain N where
              [ty]:"N be CardinalCARD-1M1" and 
              A12: "N =HIDDENR1 x"and A13: " not N be finiteFINSET-1V1"
              using A9 sorry
            have "N inTARSKIR2 K"
              using A9 A11 A12 sorry
            then have " ex A be OrdinalORDINAL1M3 st x =HIDDENR1 alephCARD-1K3 A"
              using A7 A12 A13 sorry
            thus " not ( for y be objectHIDDENM1 holds  not ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 alephCARD-1K3 A & y =HIDDENR1 A))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A14: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ?R(x,f .FUNCT-1K1 x))"
          using classes1_sch_1 A10 sorry
        have " for x be setHIDDENM2 holds x inTARSKIR2 rngFUNCT-1K2 f implies x be OrdinalORDINAL1M3 & x c=TARSKIR1 rngFUNCT-1K2 f"
        proof(rule ballI,rule impI,rule conjMI)
          fix x assume [ty]: "x be setHIDDENM2"
          assume "x inTARSKIR2 rngFUNCT-1K2 f"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A15: "y inHIDDENR3 X"and A16: "x =XBOOLE-0R4 f .FUNCT-1K1 y"
            using A14 funct_1_def_3 sorry
          obtain A where
            [ty]:"A be OrdinalORDINAL1M3" and 
            A17: "y =HIDDENR1 alephCARD-1K3 A"and A18: "x =XBOOLE-0R4 A"
            using A14 A15 A16 sorry
          show "x be OrdinalORDINAL1M3"
            using A18 sorry
          show "x c=TARSKIR1 rngFUNCT-1K2 f"
          proof-
            have " for z be objectHIDDENM1 holds z inHIDDENR3 x implies z inHIDDENR3 rngFUNCT-1K2 f"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A19: "z inHIDDENR3 x"
              then obtain z9 where 
                [ty]:"z9 be OrdinalORDINAL1M3" and z9Def:"z9 = z"
                using A18 sorry
              have A20: "alephCARD-1K3 z9 inTARSKIR2 alephCARD-1K3 A"
                using A18 A19 card_1_th_21 sorry
              have "alephCARD-1K3 A inTARSKIR2 K"
                using A9 A15 A17 sorry
              then have A21: "alephCARD-1K3 z9 inTARSKIR2 K"
                using A20 ordinal1_th_10 sorry
              have " not alephCARD-1K3 z9 be finiteFINSET-1V1"
                using card_5_th_3 sorry
              then have A22: "alephCARD-1K3 z9 inTARSKIR2 X"
                using A9 A21 sorry
              then have " ex A be OrdinalORDINAL1M3 st alephCARD-1K3 z9 =XBOOLE-0R4 alephCARD-1K3 A & f .FUNCT-1K1 alephCARD-1K3 z9 =XBOOLE-0R4 A"
                using A14 sorry
              then have "z9 =XBOOLE-0R4 f .FUNCT-1K1 alephCARD-1K3 z9"
                using card_1_th_22 sorry
              thus "z inHIDDENR3 rngFUNCT-1K2 f"
                using A14 A22 funct_1_def_3 sorry
            qed "sorry"
            thus "x c=TARSKIR1 rngFUNCT-1K2 f"
              using tarski_def_3 sorry
          qed
        qed "sorry"
        then obtain A where 
          [ty]:"A be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ADef:"A = rngFUNCT-1K2 f"
          using ordinal1_th_19 sorry
        obtain L where
          [ty]:"L be SequenceORDINAL1M4" and 
          A23: "domRELAT-1K1 L =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies L .FUNCT-1K1 B =XBOOLE-0R4 ?a(B))"
          using ordinal2_sch_2 sorry
        have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies succORDINAL1K1 B inTARSKIR2 A"
        proof(rule ballI,rule impI)
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume "B inTARSKIR2 A"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A24: "x inHIDDENR3 X"and A25: "B =XBOOLE-0R4 f .FUNCT-1K1 x"
            using A14 funct_1_def_3 sorry
          obtain C where
            [ty]:"C be OrdinalORDINAL1M3" and 
            A26: "x =HIDDENR1 alephCARD-1K3 C"and A27: "B =XBOOLE-0R4 C"
            using A14 A24 A25 sorry
          have A28: "alephCARD-1K3 (succORDINAL1K1 C) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 C)"
            using card_1_th_19 sorry
          have "alephCARD-1K3 C inTARSKIR2 K"
            using A9 A24 A26 sorry
          then have A29: "alephCARD-1K3 (succORDINAL1K1 C) c=ORDINAL1R1 K"
            using A28 card_3_th_90 sorry
          have "alephCARD-1K3 (succORDINAL1K1 C) <>HIDDENR2 K"
            using A6 A28 sorry
          then have A30: "alephCARD-1K3 (succORDINAL1K1 C) inTARSKIR2 K"
            using A29 card_1_th_3 sorry
          have " not alephCARD-1K3 (succORDINAL1K1 C) be finiteFINSET-1V1"
            using card_5_th_3 sorry
          then have A31: "alephCARD-1K3 (succORDINAL1K1 C) inTARSKIR2 X"
            using A9 A30 sorry
          then obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A32: "alephCARD-1K3 (succORDINAL1K1 C) =XBOOLE-0R4 alephCARD-1K3 D"and A33: "f .FUNCT-1K1 alephCARD-1K3 (succORDINAL1K1 C) =XBOOLE-0R4 D"
            using A14 sorry
          have "succORDINAL1K1 C =XBOOLE-0R4 D"
            using A32 card_1_th_22 sorry
          thus "succORDINAL1K1 B inTARSKIR2 A"
            using A14 A27 A31 A33 funct_1_def_3 sorry
        qed "sorry"
        then have "A be limit-ordinalORDINAL1V4"
          using ordinal1_th_28 sorry
        then have A34: "A =XBOOLE-0R4 {}XBOOLE-0K1 or alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 L"
          using A23 card_1_th_20 sorry
        show " ex tVar3 be OrdinalORDINAL1M3 st K =XBOOLE-0R4 alephCARD-1K3 tVar3"
        proof(rule bexI[of _ "A"])
          have "supORDINAL2K4 L c=ORDINAL1R1 K"
          proof-
            have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 supORDINAL2K4 L implies x inTARSKIR2 K"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be OrdinalORDINAL1M3"
              assume A35: "x inTARSKIR2 supORDINAL2K4 L"
              obtain x9 where 
                [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
                 sorry
              obtain C where
                [ty]:"C be OrdinalORDINAL1M3" and 
                A36: "C inTARSKIR2 rngFUNCT-1K2 L"and A37: "x9 c=ORDINAL1R1 C"
                using A35 ordinal2_th_21 sorry
              obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A38: "y inHIDDENR3 domRELAT-1K1 L"and A39: "C =XBOOLE-0R4 L .FUNCT-1K1 y"
                using A36 funct_1_def_3 sorry
              have 
                [ty]:"y be OrdinalORDINAL1M3"
                using A38 sorry
              have A40: "C =XBOOLE-0R4 alephCARD-1K3 y"
                using A23 A38 A39 sorry
              obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A41: "z inHIDDENR3 domRELAT-1K1 f"and A42: "y =XBOOLE-0R4 f .FUNCT-1K1 z"
                using A23 A38 funct_1_def_3 sorry
              have " ex D be OrdinalORDINAL1M3 st z =HIDDENR1 alephCARD-1K3 D & y =XBOOLE-0R4 D"
                using A14 A41 A42 sorry
              then have "C inTARSKIR2 K"
                using A9 A14 A40 A41 sorry
              thus "x inTARSKIR2 K"
                using A37 ordinal1_th_12 sorry
            qed "sorry"
            thus "supORDINAL2K4 L c=ORDINAL1R1 K"
              using ordinal1_def_5 sorry
          qed
          then have "cardCARD-1K1 supORDINAL2K4 L c=ORDINAL1R1 cardCARD-1K1 K"
            using card_1_th_11 sorry
          then have A43: "cardCARD-1K1 supORDINAL2K4 L c=ORDINAL1R1 K"
             sorry
          have "A =XBOOLE-0R4 {}XBOOLE-0K1 & K =XBOOLE-0R4 omegaORDINAL1K4 or A <>HIDDENR2 {}XBOOLE-0K1 & (A <>HIDDENR2 {}XBOOLE-0K1 implies (K <>HIDDENR2 alephCARD-1K3 A implies  False ))"
          proof-
            show "A =XBOOLE-0R4 {}XBOOLE-0K1 & K =XBOOLE-0R4 omegaORDINAL1K4 or A <>HIDDENR2 {}XBOOLE-0K1 & (A <>HIDDENR2 {}XBOOLE-0K1 implies (K <>HIDDENR2 alephCARD-1K3 A implies  False ))"
            proof-
              have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
                 sorry
              have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies K =XBOOLE-0R4 omegaORDINAL1K4"
              proof(rule impI)
                assume "A =XBOOLE-0R4 {}XBOOLE-0K1"
                then have " not omegaORDINAL1K4 inTARSKIR2 X"
                  using A14 relat_1_th_42 sorry
                then have " not omegaORDINAL1K4 inTARSKIR2 K"
                  using A9 sorry
                then have A44: "K c=ORDINAL1R1 omegaORDINAL1K4"
                  using card_1_th_4 sorry
                have "omegaORDINAL1K4 c=MEMBEREDR6 K"
                  using A8 card_3_th_85 sorry
                thus "K =XBOOLE-0R4 omegaORDINAL1K4"
                  using A44 sorry
              qed
              have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies (K <>HIDDENR2 alephCARD-1K3 A implies  False )"
              proof(rule impI,rule impI)
                assume A45: "A <>HIDDENR2 {}XBOOLE-0K1"
                assume "K <>HIDDENR2 alephCARD-1K3 A"
                then have A46: "cardCARD-1K1 supORDINAL2K4 L inTARSKIR2 K"
                  using A34 A43 A45 card_1_th_3 sorry
                have " not alephCARD-1K3 A be finiteFINSET-1V1"
                  using card_5_th_3 sorry
                then have A47: "cardCARD-1K1 supORDINAL2K4 L inTARSKIR2 X"
                  using A9 A34 A45 A46 sorry
                then obtain B where
                  [ty]:"B be OrdinalORDINAL1M3" and 
                  A48: "cardCARD-1K1 supORDINAL2K4 L =XBOOLE-0R4 alephCARD-1K3 B"and A49: "f .FUNCT-1K1 cardCARD-1K1 supORDINAL2K4 L =XBOOLE-0R4 B"
                  using A14 sorry
                have "A =XBOOLE-0R4 B"
                  using A34 A45 A48 card_1_th_22 sorry
                then have "A inTARSKIR2 A"
                  using A14 A47 A49 funct_1_def_3 sorry
                thus " False "
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "K =XBOOLE-0R4 alephCARD-1K3 A"
            using card_1_th_46 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A50: "?P({}XBOOLE-0K1)"
       sorry
    have " for M be CardinalCARD-1M1 holds ?P(M)"
      using card_1_sch_1 A50 A1 A5 sorry
    thus " not ( not M be infiniteFINSET-1V2 & ( for A be OrdinalORDINAL1M3 holds  not M =XBOOLE-0R4 alephCARD-1K3 A))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_cl_1:
  mlet "phi be Ordinal-SequenceORDINAL2M1"
"cluster UnionCARD-3K3 phi as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "UnionCARD-3K3 phi be ordinalORDINAL1V3"
  proof-
    have " ex A be OrdinalORDINAL1M3 st rngFUNCT-1K2 phi c=TARSKIR1 A"
      using ordinal2_def_4 sorry
    then have "OnORDINAL1K2 (rngFUNCT-1K2 phi) =XBOOLE-0R4 rngFUNCT-1K2 phi"
      using ordinal3_th_6 sorry
    thus "UnionCARD-3K3 phi be ordinalORDINAL1V3"
      using ordinal3_th_5 sorry
  qed
qed "sorry"

mtheorem card_5_th_5:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies ( ex phi be Ordinal-SequenceORDINAL2M1 st ((phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X) & phi be increasingORDINAL2V2) & domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X) & rngFUNCT-1K2 phi =XBOOLE-0R4 X)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies ( ex tVar4 be Ordinal-SequenceORDINAL2M1 st tVar4 =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X) & (tVar4 be increasingORDINAL2V2 & (domRELAT-1K1 tVar4 =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngFUNCT-1K2 tVar4 =XBOOLE-0R4 X)))"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?R = "RelInclWELLORD2K1 X"
    let ?B = "order-type-ofWELLORD2K2 ?R"
    let ?phi = "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 ?B,?R)"
    assume A1: "X c=TARSKIR1 A"
    then have "?R be well-orderingWELLORD1V2"
      using wellord2_th_8 sorry
    then have "(?R,RelInclWELLORD2K1 ?B)are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    then have "RelInclWELLORD2K1 ?B be well-orderingWELLORD1V2 & (RelInclWELLORD2K1 ?B,?R)are-isomorphicWELLORD1R4"
      using wellord1_th_40 wellord2_th_8 sorry
    then have A2: "?phi is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 ?B,?R)"
      using wellord1_def_9 sorry
    then have A3: "?phi be one-to-oneFUNCT-1V2"
      using wellord1_def_7 sorry
    have A4: "fieldRELAT-1K3 (RelInclWELLORD2K1 ?B) =XBOOLE-0R4 ?B"
      using wellord2_def_1 sorry
    then have A5: "domRELAT-1K1 ?phi =XBOOLE-0R4 ?B"
      using A2 wellord1_def_7 sorry
    have A6: "fieldRELAT-1K3 ?R =XBOOLE-0R4 X"
      using wellord2_def_1 sorry
    then have A7: "rngFUNCT-1K2 ?phi =XBOOLE-0R4 X"
      using A2 wellord1_def_7 sorry
    obtain phi where 
      [ty]:"phi be SequenceORDINAL1M4" and phiDef:"phi = ?phi"
      using A5 ordinal1_def_7 sorry
    have 
      [ty]:"phi be Ordinal-SequenceORDINAL2M1"
      using A1 A7 ordinal2_def_4 sorry
    show " ex tVar4 be Ordinal-SequenceORDINAL2M1 st tVar4 =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X) & (tVar4 be increasingORDINAL2V2 & (domRELAT-1K1 tVar4 =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngFUNCT-1K2 tVar4 =XBOOLE-0R4 X))"
    proof(rule bexI[of _ "phi"],rule conjMI,rule conjMI)
      show "phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)"
         sorry
      show "phi be increasingORDINAL2V2"
      proof-
        have " for a be OrdinalORDINAL1M3 holds  for b be OrdinalORDINAL1M3 holds a inTARSKIR2 b & b inTARSKIR2 domRELAT-1K1 phi implies phi .FUNCT-1K1 a inTARSKIR2 phi .FUNCT-1K1 b"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix a assume [ty]: "a be OrdinalORDINAL1M3"
          fix b assume [ty]: "b be OrdinalORDINAL1M3"
          assume A8: "a inTARSKIR2 b"
            and A9: "b inTARSKIR2 domRELAT-1K1 phi"
          have A10: "a inTARSKIR2 domRELAT-1K1 phi"
            using A8 A9 ordinal1_th_10 sorry
          obtain a9 b9 where 
            [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = phi .FUNCT-1K1 a" and
            [ty]:"b9 be OrdinalORDINAL1M3" and b9Def:"b9 = phi .FUNCT-1K1 b"
             sorry
          have A11: "b9 inTARSKIR2 X"
            using A7 A9 funct_1_def_3 sorry
          have "a c=ORDINAL1R1 b"
            using A8 ordinal1_def_2 sorry
          then have "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 ?B"
            using A5 A9 A10 wellord2_def_1 sorry
          then have A12: "[TARSKIK4 a9,b9 ] inHIDDENR3 ?R"
            using A2 wellord1_def_7 sorry
          have "a9 inTARSKIR2 X"
            using A7 A10 funct_1_def_3 sorry
          then have A13: "a9 c=ORDINAL1R1 b9"
            using A12 A11 wellord2_def_1 sorry
          have "a <>HIDDENR2 b"
            using A8 sorry
          then have "a9 <>HIDDENR2 b9"
            using A3 A9 A10 sorry
          then have "a9 c<XBOOLE-0R2 b9"
            using A13 sorry
          thus "phi .FUNCT-1K1 a inTARSKIR2 phi .FUNCT-1K1 b"
            using ordinal1_th_11 sorry
        qed "sorry"
        thus "phi be increasingORDINAL2V2"
          using ordinal2_def_12 sorry
      qed
      show "domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngFUNCT-1K2 phi =XBOOLE-0R4 X"
        using A2 A4 A6 wellord1_def_7 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_6:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies supORDINAL2K3 X is-cofinal-withORDINAL2R2 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies supORDINAL2K3 X is-cofinal-withORDINAL2R2 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X c=TARSKIR1 A"
    then obtain phi where
      [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
      "phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)"and A2: "(phi be increasingORDINAL2V2 & domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X) & rngFUNCT-1K2 phi =XBOOLE-0R4 X"
      using card_5_th_5 sorry
    have Cut338: "OnORDINAL1K2 X =XBOOLE-0R4 X"
      using A1 ordinal3_th_6 sorry
    have "((domRELAT-1K1 phi =HIDDENR1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngRELAT-1K2 phi c=TARSKIR1 supORDINAL2K3 X) & phi be increasingORDINAL2V2) & supORDINAL2K3 X =HIDDENR1 supORDINAL2K4 phi"
    proof-
      show "((domRELAT-1K1 phi =HIDDENR1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngRELAT-1K2 phi c=TARSKIR1 supORDINAL2K3 X) & phi be increasingORDINAL2V2) & supORDINAL2K3 X =HIDDENR1 supORDINAL2K4 phi"
        using A2 ordinal2_def_3 Cut338 sorry
    qed
    thus "supORDINAL2K3 X is-cofinal-withORDINAL2R2 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
      using bexI[of _ "phi"] ordinal2_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_7:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds X c=TARSKIR1 A implies cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?R = "RelInclWELLORD2K1 X"
    let ?B = "order-type-ofWELLORD2K2 ?R"
    let ?phi = "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 ?B,?R)"
    assume "X c=TARSKIR1 A"
    then have "?R be well-orderingWELLORD1V2"
      using wellord2_th_8 sorry
    then have "(?R,RelInclWELLORD2K1 ?B)are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    then have "RelInclWELLORD2K1 ?B be well-orderingWELLORD1V2 & (RelInclWELLORD2K1 ?B,?R)are-isomorphicWELLORD1R4"
      using wellord1_th_40 wellord2_th_8 sorry
    then have A1: "?phi is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 ?B,?R)"
      using wellord1_def_9 sorry
    have "fieldRELAT-1K3 ?R =XBOOLE-0R4 X"
      using wellord2_def_1 sorry
    then have A2: "rngFUNCT-1K2 ?phi =XBOOLE-0R4 X"
      using A1 wellord1_def_7 sorry
    have "fieldRELAT-1K3 (RelInclWELLORD2K1 ?B) =XBOOLE-0R4 ?B"
      using wellord2_def_1 sorry
    then have A3: "domRELAT-1K1 ?phi =XBOOLE-0R4 ?B"
      using A1 wellord1_def_7 sorry
    have "?phi be one-to-oneFUNCT-1V2"
      using A1 wellord1_def_7 sorry
    then have "(?B,X)are-equipotentWELLORD2R2"
      using A3 A2 wellord2_def_4 sorry
    thus "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X)"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_8:
" for A be OrdinalORDINAL1M3 holds  ex B be OrdinalORDINAL1M3 st B c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  ex tVar6 be OrdinalORDINAL1M3 st tVar6 c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 tVar6"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?M = "cardCARD-1K1 A"
    have "(?M,A)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 ?M"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 A"
      using wellord2_def_4 sorry
    let ?P = "\<lambda>Lamb1.  not f .FUNCT-1K1 Lamb1 inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 Lamb1"
    have 
      [ty]:"f be SequenceORDINAL1M4"
      using A2 ordinal1_def_7 sorry
    have 
      [ty]:"f be Ordinal-SequenceORDINAL2M1"
      using A3 ordinal2_def_4 sorry
    obtain X where
      [ty]:"X be setHIDDENM2" and 
      A4: " for x be setHIDDENM2 holds x inTARSKIR2 X iff x inTARSKIR2 ?M & ?P(x)"
      using xfamily_sch_1 sorry
    let ?R = "RelInclWELLORD2K1 X"
    let ?B = "order-type-ofWELLORD2K2 ?R"
    show " ex tVar6 be OrdinalORDINAL1M3 st tVar6 c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 tVar6"
    proof(rule bexI[of _ "?B"],rule conjMI)
      have A5: "X c=TARSKIR1 ?M"
        using A4 sorry
      thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 cardCARD-1K1 A"
        using wellord2_th_14 sorry
      let ?phi = "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 ?B,?R)"
      have "?R be well-orderingWELLORD1V2"
        using A5 wellord2_th_8 sorry
      then have "(?R,RelInclWELLORD2K1 ?B)are-isomorphicWELLORD1R4"
        using wellord2_def_2 sorry
      then have "RelInclWELLORD2K1 ?B be well-orderingWELLORD1V2 & (RelInclWELLORD2K1 ?B,?R)are-isomorphicWELLORD1R4"
        using wellord1_th_40 wellord2_th_8 sorry
      then have A6: "?phi is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 ?B,?R)"
        using wellord1_def_9 sorry
      then have A7: "?phi be one-to-oneFUNCT-1V2"
        using wellord1_def_7 sorry
      have "fieldRELAT-1K3 (RelInclWELLORD2K1 ?B) =XBOOLE-0R4 ?B"
        using wellord2_def_1 sorry
      then have A8: "domRELAT-1K1 ?phi =XBOOLE-0R4 ?B"
        using A6 wellord1_def_7 sorry
      have "fieldRELAT-1K3 ?R =XBOOLE-0R4 X"
        using wellord2_def_1 sorry
      then have A9: "rngFUNCT-1K2 ?phi =XBOOLE-0R4 X"
        using A6 wellord1_def_7 sorry
      obtain phi where 
        [ty]:"phi be SequenceORDINAL1M4" and phiDef:"phi = ?phi"
        using A8 ordinal1_def_7 sorry
      have 
        [ty]:"phi be Ordinal-SequenceORDINAL2M1"
        using A5 A9 ordinal2_def_4 sorry
      have A10: "domRELAT-1K1 (f *FUNCT-1K3 phi) =XBOOLE-0R4 ?B"
        using A2 A5 A8 A9 relat_1_th_27 sorry
      then obtain xi where 
        [ty]:"xi be SequenceORDINAL1M4" and xiDef:"xi = f *FUNCT-1K3 phi"
        using ordinal1_def_7 sorry
      have "rngFUNCT-1K2 (f *FUNCT-1K3 phi) c=TARSKIR1 A"
        using A3 relat_1_th_26 sorry
      then have 
        [ty]:"xi be Ordinal-SequenceORDINAL2M1"
        using ordinal2_def_4 sorry
      have "(domRELAT-1K1 xi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngFUNCT-1K2 xi c=TARSKIR1 A) & (xi be increasingORDINAL2V2 & A =HIDDENR1 supORDINAL2K4 xi)"
      proof(rule conjMI,rule conjMI)
        show "domRELAT-1K1 xi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X & rngFUNCT-1K2 xi c=TARSKIR1 A"
          using A2 A3 A5 A8 A9 relat_1_th_26 relat_1_th_27 sorry
        show "xi be increasingORDINAL2V2"
        proof-
          have " for a be OrdinalORDINAL1M3 holds  for b be OrdinalORDINAL1M3 holds a inTARSKIR2 b & b inTARSKIR2 domRELAT-1K1 xi implies xi .FUNCT-1K1 a inTARSKIR2 xi .FUNCT-1K1 b"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix a assume [ty]: "a be OrdinalORDINAL1M3"
            fix b assume [ty]: "b be OrdinalORDINAL1M3"
            assume A11: "a inTARSKIR2 b"
              and A12: "b inTARSKIR2 domRELAT-1K1 xi"
            have A13: "a inTARSKIR2 domRELAT-1K1 xi"
              using A11 A12 ordinal1_th_10 sorry
            then have A14: "phi .FUNCT-1K1 a inTARSKIR2 X"
              using A8 A9 A10 funct_1_def_3 sorry
            have "a <>HIDDENR2 b"
              using A11 sorry
            then have A15: "phi .FUNCT-1K1 a <>HIDDENR2 phi .FUNCT-1K1 b"
              using A8 A7 A10 A12 A13 sorry
            obtain a9 b9 where 
              [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = phi .FUNCT-1K1 a" and
              [ty]:"b9 be OrdinalORDINAL1M3" and b9Def:"b9 = phi .FUNCT-1K1 b"
               sorry
            obtain a99 b99 where 
              [ty]:"a99 be OrdinalORDINAL1M3" and a99Def:"a99 = f .FUNCT-1K1 a9" and
              [ty]:"b99 be OrdinalORDINAL1M3" and b99Def:"b99 = f .FUNCT-1K1 b9"
               sorry
            have A16: "phi .FUNCT-1K1 b inTARSKIR2 X"
              using A8 A9 A10 A12 funct_1_def_3 sorry
            then have " not b99 inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 b9"
              using A4 sorry
            then have A17: "UnionCARD-3K3 f  |RELAT-1K8 b9 c=ORDINAL1R1 b99"
              using ordinal1_th_16 sorry
            have "a c=ORDINAL1R1 b"
              using A11 ordinal1_def_2 sorry
            then have "[TARSKIK4 a,b ] inHIDDENR3 RelInclWELLORD2K1 ?B"
              using A10 A12 A13 wellord2_def_1 sorry
            then have "[TARSKIK4 phi .FUNCT-1K1 a,phi .FUNCT-1K1 b ] inHIDDENR3 ?R"
              using A6 wellord1_def_7 sorry
            then have "a9 c=ORDINAL1R1 b9"
              using A14 A16 wellord2_def_1 sorry
            then have "a9 c<XBOOLE-0R2 b9"
              using A15 sorry
            then have "a9 inTARSKIR2 b9"
              using ordinal1_th_11 sorry
            then have "a99 c=ORDINAL1R1 UnionCARD-3K3 f  |RELAT-1K8 b9"
              using A2 A5 A14 funct_1_th_50 zfmisc_1_th_74 sorry
            then have A18: "a99 c=ORDINAL1R1 b99"
              using A17 sorry
            have "a99 <>HIDDENR2 b99"
              using A1 A2 A5 A15 A14 A16 sorry
            then have A19: "a99 c<XBOOLE-0R2 b99"
              using A18 sorry
            have "a99 =XBOOLE-0R4 xi .FUNCT-1K1 a & b99 =XBOOLE-0R4 xi .FUNCT-1K1 b"
              using A11 A12 funct_1_th_12 ordinal1_th_10 sorry
            thus "xi .FUNCT-1K1 a inTARSKIR2 xi .FUNCT-1K1 b"
              using A19 ordinal1_th_11 sorry
          qed "sorry"
          thus "xi be increasingORDINAL2V2"
            using ordinal2_def_12 sorry
        qed
        have "A c=ORDINAL1R1 supORDINAL2K4 xi & supORDINAL2K4 xi c=TARSKIR1 A"
        proof(rule conjMI)
          show "A c=ORDINAL1R1 supORDINAL2K4 xi"
          proof-
            have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 A implies x inTARSKIR2 supORDINAL2K4 xi"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be OrdinalORDINAL1M3"
              assume "x inTARSKIR2 A"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A20: "y inHIDDENR3 domRELAT-1K1 f"and A21: "x =XBOOLE-0R4 f .FUNCT-1K1 y"
                using A3 funct_1_def_3 sorry
              obtain x9 where 
                [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x" and
                [ty]:"y be OrdinalORDINAL1M3"
                using A20 sorry
              have "x inTARSKIR2 supORDINAL2K4 xi"
              proof-
                show "x inTARSKIR2 supORDINAL2K4 xi"
                proof-
                  have cases: " not f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y or f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y"
                     sorry
                  have case1: " not f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y implies x inTARSKIR2 supORDINAL2K4 xi"
                  proof(rule impI)
                    assume " not f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y"
                    then have "y inTARSKIR2 X"
                      using A2 A4 A20 sorry
                    then obtain z where
                      [ty]:"z be objectHIDDENM1" and 
                      A22: "z inHIDDENR3 ?B & y =XBOOLE-0R4 phi .FUNCT-1K1 z"
                      using A8 A9 funct_1_def_3 sorry
                    have "x9 =XBOOLE-0R4 xi .FUNCT-1K1 z & xi .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 xi"
                      using A10 A21 A22 funct_1_th_12 funct_1_def_3 sorry
                    thus "x inTARSKIR2 supORDINAL2K4 xi"
                      using ordinal2_th_19 sorry
                  qed
                  have case2: "f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y implies x inTARSKIR2 supORDINAL2K4 xi"
                  proof(rule impI)
                    assume A23: "f .FUNCT-1K1 y inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 y"
                    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 y & f .FUNCT-1K1 y inTARSKIR2 f .FUNCT-1K1 Lamb1"
                    obtain z where
                      [ty]:"z be objectHIDDENM1" and 
                      A24: "z inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 y)"and A25: "f .FUNCT-1K1 y inTARSKIR2 (f  |RELAT-1K8 y).FUNCT-1K1 z"
                      using A23 card_5_th_2 sorry
                    have 
                      [ty]:"z be OrdinalORDINAL1M3"
                      using A24 sorry
                    have A26: "(f  |RELAT-1K8 y).FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 z"
                      using A24 funct_1_th_47 sorry
                    have "domRELAT-1K1 (f  |RELAT-1K8 y) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 y"
                      using relat_1_th_61 sorry
                    then have "z inTARSKIR2 y"
                      using A24 xboole_0_def_4 sorry
                    then have A27: " ex C be OrdinalORDINAL1M3 st ?P(C)"
                      using A25 A26 sorry
                    obtain C where
                      [ty]:"C be OrdinalORDINAL1M3" and 
                      A28: "?P(C) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies C c=ORDINAL1R1 B)"
                      using ordinal1_sch_1 A27 sorry
                    have "C inTARSKIR2 cardCARD-1K1 A & (f .FUNCT-1K1 C inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 C implies  False )"
                    proof(rule conjMI,rule impI)
                      show "C inTARSKIR2 cardCARD-1K1 A"
                        using A2 A20 A28 ordinal1_th_10 sorry
                      assume "f .FUNCT-1K1 C inTARSKIR2 UnionCARD-3K3 f  |RELAT-1K8 C"
                      then obtain a where
                        [ty]:"a be objectHIDDENM1" and 
                        A29: "a inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 C)"and A30: "f .FUNCT-1K1 C inTARSKIR2 (f  |RELAT-1K8 C).FUNCT-1K1 a"
                        using card_5_th_2 sorry
                      have 
                        [ty]:"a be OrdinalORDINAL1M3"
                        using A29 sorry
                      obtain fa fy where 
                        [ty]:"fa be OrdinalORDINAL1M3" and faDef:"fa = (f  |RELAT-1K8 C).FUNCT-1K1 a" and
                        [ty]:"fy be OrdinalORDINAL1M3" and fyDef:"fy = f .FUNCT-1K1 y"
                         sorry
                      have "f .FUNCT-1K1 a =XBOOLE-0R4 fa"
                        using A29 funct_1_th_47 sorry
                      then have A31: "fy inTARSKIR2 f .FUNCT-1K1 a"
                        using A28 A30 ordinal1_th_10 sorry
                      have "domRELAT-1K1 (f  |RELAT-1K8 C) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 C"
                        using relat_1_th_61 sorry
                      then have A32: "a inTARSKIR2 C"
                        using A29 xboole_0_def_4 sorry
                      then have "a inTARSKIR2 y"
                        using A28 ordinal1_th_10 sorry
                      thus " False "
                        using A28 A32 A31 ordinal1_th_5 sorry
                    qed
                    then have "C inTARSKIR2 X"
                      using A4 sorry
                    then obtain z where
                      [ty]:"z be objectHIDDENM1" and 
                      A33: "z inHIDDENR3 ?B"and A34: "C =XBOOLE-0R4 phi .FUNCT-1K1 z"
                      using A8 A9 funct_1_def_3 sorry
                    have 
                      [ty]:"z be OrdinalORDINAL1M3"
                      using A33 sorry
                    obtain xz where 
                      [ty]:"xz be OrdinalORDINAL1M3" and xzDef:"xz = xi .FUNCT-1K1 z"
                       sorry
                    have "xz inTARSKIR2 rngFUNCT-1K2 xi"
                      using A10 A33 funct_1_def_3 sorry
                    then have A35: "xz inTARSKIR2 supORDINAL2K4 xi"
                      using ordinal2_th_19 sorry
                    have "x9 inTARSKIR2 xz"
                      using A10 A21 A28 A33 A34 funct_1_th_12 sorry
                    thus "x inTARSKIR2 supORDINAL2K4 xi"
                      using A35 ordinal1_th_10 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "x inTARSKIR2 supORDINAL2K4 xi"
                 sorry
            qed "sorry"
            thus "A c=ORDINAL1R1 supORDINAL2K4 xi"
              using ordinal1_def_5 sorry
          qed
          have "supORDINAL2K3 A =XBOOLE-0R4 A"
            using ordinal2_th_18 sorry
          thus "supORDINAL2K4 xi c=TARSKIR1 A"
            using A3 ordinal2_th_22 relat_1_th_26 sorry
        qed
        thus "A =HIDDENR1 supORDINAL2K4 xi"
          using xboole_0_def_10 sorry
      qed
      thus "A is-cofinal-withORDINAL2R2 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
        using bexI[of _ "xi"] ordinal2_def_17 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_9:
" for A be OrdinalORDINAL1M3 holds  ex M be CardinalCARD-1M1 st (M c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 M) & ( for B be OrdinalORDINAL1M3 holds A is-cofinal-withORDINAL2R2 B implies M c=ORDINAL1R1 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  ex M be setHIDDENM2 st (M c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 M) & ( for B be OrdinalORDINAL1M3 holds A is-cofinal-withORDINAL2R2 B &  not M c=ORDINAL1R1 B implies  False )"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. Lamb1 c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 Lamb1"
    have A1: " ex B be OrdinalORDINAL1M3 st ?P(B)"
      using card_5_th_8 sorry
    obtain C where
      [ty]:"C be OrdinalORDINAL1M3" and 
      A2: "?P(C)"and A3: " for B be OrdinalORDINAL1M3 holds ?P(B) implies C c=ORDINAL1R1 B"
      using ordinal1_sch_1 A1 sorry
    obtain M where 
      [ty]:"M be setHIDDENM2" and MDef:"M = cardCARD-1K1 C"
       sorry
    show " ex M be setHIDDENM2 st (M c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 M) & ( for B be OrdinalORDINAL1M3 holds A is-cofinal-withORDINAL2R2 B &  not M c=ORDINAL1R1 B implies  False )"
    proof(rule bexI[of _ "M"],rule conjMI,rule ballI,rule impMI ,rule impI)
      obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A4: "B c=ORDINAL1R1 M"and A5: "C is-cofinal-withORDINAL2R2 B"
        using card_5_th_8 sorry
      have A6: "M c=ORDINAL1R1 C"
        using card_1_th_8 sorry
      then have A7: "B c=ORDINAL1R1 C"
        using A4 sorry
      then have "B c=ORDINAL1R1 cardCARD-1K1 A"
        using A2 xboole_1_th_1 sorry
      then have "C c=ORDINAL1R1 B"
        using A2 A3 A5 ordinal4_th_37 sorry
      then have A8: "C =XBOOLE-0R4 B"
        using A7 sorry
      thus "M c=ORDINAL1R1 cardCARD-1K1 A & A is-cofinal-withORDINAL2R2 M"
        using A2 A4 A6 xboole_0_def_10 sorry
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume A9: "A is-cofinal-withORDINAL2R2 B"
        and A10: " not M c=ORDINAL1R1 B"
      have A11: "C =XBOOLE-0R4 M"
        using A4 A6 A8 sorry
      then have " not B c=ORDINAL1R1 cardCARD-1K1 A"
        using A3 A9 A10 sorry
      thus " False "
        using A2 A11 A10 xboole_1_th_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_5_lm_3:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2 implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 phi implies A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A)"
proof-
  have " for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2 implies  not (psi be increasingORDINAL2V2 &  not ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 phi &  not (A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix phi assume [ty]: "phi be Ordinal-SequenceORDINAL2M1"
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    assume A1: "rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi"
      and A2: "phi be increasingORDINAL2V2"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domRELAT-1K1 phi implies Lamb1 inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 Lamb1 =XBOOLE-0R4 psi .FUNCT-1K1 Lamb1"
    have "( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 psi implies psi .FUNCT-1K1 A inTARSKIR2 psi .FUNCT-1K1 B) implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 phi implies A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A)"
    proof(rule impI)
      assume A3: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 psi implies psi .FUNCT-1K1 A inTARSKIR2 psi .FUNCT-1K1 B"
      have A4: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
      proof-
        have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A & B inTARSKIR2 domRELAT-1K1 phi implies B inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 B =XBOOLE-0R4 psi .FUNCT-1K1 B) & A inTARSKIR2 domRELAT-1K1 phi implies A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A"
        proof(rule ballI,rule impMI ,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          assume A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A & B inTARSKIR2 domRELAT-1K1 phi implies B inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 B =XBOOLE-0R4 psi .FUNCT-1K1 B"
            and A6: "A inTARSKIR2 domRELAT-1K1 phi"
          have "phi .FUNCT-1K1 A inTARSKIR2 rngFUNCT-1K2 phi"
            using A6 funct_1_def_3 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A7: "x inHIDDENR3 domRELAT-1K1 psi"and A8: "phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 x"
            using A1 funct_1_def_3 sorry
          have 
            [ty]:"x be OrdinalORDINAL1M3"
            using A7 sorry
          have A9: "A inTARSKIR2 x implies  False "
          proof(rule impI)
            assume A10: "A inTARSKIR2 x"
            then have A11: "A inTARSKIR2 domRELAT-1K1 psi"
              using A7 ordinal1_th_10 sorry
            then have "psi .FUNCT-1K1 A inTARSKIR2 rngFUNCT-1K2 psi"
              using funct_1_def_3 sorry
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A12: "y inHIDDENR3 domRELAT-1K1 phi"and A13: "psi .FUNCT-1K1 A =XBOOLE-0R4 phi .FUNCT-1K1 y"
              using A1 funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A12 sorry
            have "psi .FUNCT-1K1 A inTARSKIR2 psi .FUNCT-1K1 x"
              using A3 A7 A10 sorry
            then have " not A c=ORDINAL1R1 y"
              using A2 A8 A12 A13 ordinal1_th_5 ordinal4_th_9 sorry
            then have A14: "y inTARSKIR2 A"
              using ordinal1_th_16 sorry
            then have A15: "psi .FUNCT-1K1 y =XBOOLE-0R4 phi .FUNCT-1K1 y"
              using A5 A12 sorry
            have "psi .FUNCT-1K1 y inTARSKIR2 psi .FUNCT-1K1 A"
              using A3 A11 A14 sorry
            thus " False "
              using A13 A15 sorry
          qed
          have "x inTARSKIR2 A implies  False "
          proof(rule impI)
            assume A16: "x inTARSKIR2 A"
            then have "phi .FUNCT-1K1 x inTARSKIR2 phi .FUNCT-1K1 A & x inTARSKIR2 domRELAT-1K1 phi"
              using A2 A6 ordinal1_th_10 sorry
            then have "phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 A"
              using A5 A8 A16 sorry
            thus " False "
               sorry
          qed
          thus "A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A"
            using A7 A8 A9 ordinal1_th_14 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      show " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 phi implies A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A"
        using ordinal1_sch_2 A4 sorry
    qed
    thus " not (psi be increasingORDINAL2V2 &  not ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 phi &  not (A inTARSKIR2 domRELAT-1K1 psi & phi .FUNCT-1K1 A =XBOOLE-0R4 psi .FUNCT-1K1 A))))"
      using ordinal2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_10:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2 implies phi =FUNCT-1R1 psi"
proof-
  have " for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2 implies phi =FUNCT-1R1 psi"
  proof(rule ballI,rule ballI,rule impI)
    fix phi assume [ty]: "phi be Ordinal-SequenceORDINAL2M1"
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    assume A1: "(rngFUNCT-1K2 phi =XBOOLE-0R4 rngFUNCT-1K2 psi & phi be increasingORDINAL2V2) & psi be increasingORDINAL2V2"
    have A2: "domRELAT-1K1 phi =XBOOLE-0R4 domRELAT-1K1 psi"
    proof-
      have "domRELAT-1K1 phi c=ORDINAL1R1 domRELAT-1K1 psi & domRELAT-1K1 psi c=TARSKIR1 domRELAT-1K1 phi"
      proof(rule conjMI)
        show "domRELAT-1K1 phi c=ORDINAL1R1 domRELAT-1K1 psi"
          using A1 card_5_lm_3 sorry
        have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 domRELAT-1K1 psi implies x inTARSKIR2 domRELAT-1K1 phi"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be OrdinalORDINAL1M3"
          assume "x inTARSKIR2 domRELAT-1K1 psi"
          thus "x inTARSKIR2 domRELAT-1K1 phi"
            using A1 card_5_lm_3 sorry
        qed "sorry"
        thus "domRELAT-1K1 psi c=TARSKIR1 domRELAT-1K1 phi"
          using ordinal1_def_5 sorry
      qed
      thus "domRELAT-1K1 phi =XBOOLE-0R4 domRELAT-1K1 psi"
        using xboole_0_def_10 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 phi implies phi .FUNCT-1K1 x =XBOOLE-0R4 psi .FUNCT-1K1 x"
      using A1 card_5_lm_3 sorry
    thus "phi =FUNCT-1R1 psi"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_11:
" for phi be Ordinal-SequenceORDINAL2M1 holds phi be increasingORDINAL2V2 implies phi be one-to-oneFUNCT-1V2"
proof-
  have " for phi be Ordinal-SequenceORDINAL2M1 holds  not (phi be increasingORDINAL2V2 &  not phi be one-to-oneFUNCT-1V2)"
  proof(rule ballI)
    fix phi assume [ty]: "phi be Ordinal-SequenceORDINAL2M1"
    have "( for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 phi implies phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 B) implies phi be one-to-oneFUNCT-1V2"
    proof(rule impI)
      assume A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 phi implies phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 B"
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 phi & y inHIDDENR3 domRELAT-1K1 phi) & phi .FUNCT-1K1 x =XBOOLE-0R4 phi .FUNCT-1K1 y implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domRELAT-1K1 phi & y inHIDDENR3 domRELAT-1K1 phi"
          and A3: "phi .FUNCT-1K1 x =XBOOLE-0R4 phi .FUNCT-1K1 y"
        obtain A B where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x" and
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = y"
          using A2 sorry
        have A4: "(A inTARSKIR2 B or A =XBOOLE-0R4 B) or B inTARSKIR2 A"
          using ordinal1_th_14 sorry
        have " not phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 B"
          using A3 sorry
        thus "x =HIDDENR1 y"
          using A1 A2 A3 A4 sorry
      qed "sorry"
      thus "phi be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    thus " not (phi be increasingORDINAL2V2 &  not phi be one-to-oneFUNCT-1V2)"
      using ordinal2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_12:
" for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (phi ^ORDINAL4K1 psi) |RELAT-1K8 domRELAT-1K1 phi =FUNCT-1R1 phi"
proof-
  have " for phi be Ordinal-SequenceORDINAL2M1 holds  for psi be Ordinal-SequenceORDINAL2M1 holds (phi ^ORDINAL4K1 psi) |RELAT-1K8 domRELAT-1K1 phi =FUNCT-1R1 phi"
  proof(rule ballI,rule ballI)
    fix phi assume [ty]: "phi be Ordinal-SequenceORDINAL2M1"
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    have "domRELAT-1K1 (phi ^ORDINAL4K1 psi) =XBOOLE-0R4 domRELAT-1K1 phi +^ORDINAL2K10 domRELAT-1K1 psi"
      using ordinal4_def_1 sorry
    then have "domRELAT-1K1 phi c=ORDINAL1R1 domRELAT-1K1 (phi ^ORDINAL4K1 psi)"
      using ordinal3_th_24 sorry
    then have A1: "domRELAT-1K1 phi =XBOOLE-0R4 domRELAT-1K1 (phi ^ORDINAL4K1 psi) /\\XBOOLE-0K3 domRELAT-1K1 phi"
      using xboole_1_th_28 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 phi implies phi .FUNCT-1K1 x =XBOOLE-0R4 (phi ^ORDINAL4K1 psi).FUNCT-1K1 x"
      using ordinal4_def_1 sorry
    thus "(phi ^ORDINAL4K1 psi) |RELAT-1K8 domRELAT-1K1 phi =FUNCT-1R1 phi"
      using A1 funct_1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_13:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K1 ({Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M }) c=ORDINAL1R1 M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
proof-
  have " for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K1 ({Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M }) c=ORDINAL1R1 M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?Z = "{Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M }"
    have "(X,cardCARD-1K1 X)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 cardCARD-1K1 X"
      using wellord2_def_4 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex X be setHIDDENM2 st  ex A be OrdinalORDINAL1M3 st  ex phi be Ordinal-SequenceORDINAL2M1 st ((((X =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 [TARSKIK4 A,phi ]) & domRELAT-1K1 phi =XBOOLE-0R4 M) & phi  |RELAT-1K8 A be increasingORDINAL2V2) & rngFUNCT-1K2 (phi  |RELAT-1K8 A) =XBOOLE-0R4 f .:FUNCT-1K5 X) & ( for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & B inTARSKIR2 M implies phi .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1)"
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 ?Z implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M } implies ( ex y be objectHIDDENM1 st  ex tVar10 be setHIDDENM2 st  ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be Ordinal-SequenceORDINAL2M1 st tVar10 =HIDDENR1 x & ((((y =HIDDENR1 [TARSKIK4 tVar11,tVar12 ] & domRELAT-1K1 tVar12 =XBOOLE-0R4 M) & tVar12  |RELAT-1K8 tVar11 be increasingORDINAL2V2) & rngFUNCT-1K2 (tVar12  |RELAT-1K8 tVar11) =XBOOLE-0R4 f .:FUNCT-1K5 tVar10) & ( for B be OrdinalORDINAL1M3 holds tVar11 c=ORDINAL1R1 B & B inTARSKIR2 M implies tVar12 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1)))"
      proof(rule ballI,rule impI)
        let ?f = "\<lambda>Lamb1. {}XBOOLE-0K1"
        fix x assume [ty]: "x be objectHIDDENM1"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
          using tarski_th_1 sorry
        let ?A = "order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx)"
        obtain xi2 where
          [ty]:"xi2 be Ordinal-SequenceORDINAL2M1" and 
          A5: "domRELAT-1K1 xi2 =XBOOLE-0R4 M -^ORDINAL3K5 ?A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 M -^ORDINAL3K5 ?A implies xi2 .FUNCT-1K1 B =XBOOLE-0R4 ?f(B))"
          using ordinal2_sch_3 sorry
        assume "x inHIDDENR3 ?Z"
        then have A6: " ex Y be SubsetSUBSET-1M2-of X st x =HIDDENR1 Y & cardCARD-1K1 Y inTARSKIR2 M"
           sorry
        obtain xi1 where
          [ty]:"xi1 be Ordinal-SequenceORDINAL2M1" and 
          "xi1 =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 ?A,RelInclWELLORD2K1 (f .:FUNCT-1K5 xx))"and A7: "xi1 be increasingORDINAL2V2"and A8: "domRELAT-1K1 xi1 =XBOOLE-0R4 ?A"and A9: "rngFUNCT-1K2 xi1 =XBOOLE-0R4 f .:FUNCT-1K5 xx"
          using A3 card_5_th_5 relat_1_th_111 sorry
        let ?phi = "xi1 ^ORDINAL4K1 xi2"
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = [TARSKIK4 ?A,?phi ]"
           sorry
        show " ex y be objectHIDDENM1 st  ex tVar10 be setHIDDENM2 st  ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be Ordinal-SequenceORDINAL2M1 st tVar10 =HIDDENR1 x & ((((y =HIDDENR1 [TARSKIK4 tVar11,tVar12 ] & domRELAT-1K1 tVar12 =XBOOLE-0R4 M) & tVar12  |RELAT-1K8 tVar11 be increasingORDINAL2V2) & rngFUNCT-1K2 (tVar12  |RELAT-1K8 tVar11) =XBOOLE-0R4 f .:FUNCT-1K5 tVar10) & ( for B be OrdinalORDINAL1M3 holds tVar11 c=ORDINAL1R1 B & B inTARSKIR2 M implies tVar12 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1))"
        proof(rule bexI[of _ "y"])
          show " ex tVar10 be setHIDDENM2 st  ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be Ordinal-SequenceORDINAL2M1 st tVar10 =HIDDENR1 x & ((((y =HIDDENR1 [TARSKIK4 tVar11,tVar12 ] & domRELAT-1K1 tVar12 =XBOOLE-0R4 M) & tVar12  |RELAT-1K8 tVar11 be increasingORDINAL2V2) & rngFUNCT-1K2 (tVar12  |RELAT-1K8 tVar11) =XBOOLE-0R4 f .:FUNCT-1K5 tVar10) & ( for B be OrdinalORDINAL1M3 holds tVar11 c=ORDINAL1R1 B & B inTARSKIR2 M implies tVar12 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1))"
          proof(rule bexI[of _ "xx"])
            show " ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be Ordinal-SequenceORDINAL2M1 st xx =HIDDENR1 x & ((((y =HIDDENR1 [TARSKIK4 tVar11,tVar12 ] & domRELAT-1K1 tVar12 =XBOOLE-0R4 M) & tVar12  |RELAT-1K8 tVar11 be increasingORDINAL2V2) & rngFUNCT-1K2 (tVar12  |RELAT-1K8 tVar11) =XBOOLE-0R4 f .:FUNCT-1K5 xx) & ( for B be OrdinalORDINAL1M3 holds tVar11 c=ORDINAL1R1 B & B inTARSKIR2 M implies tVar12 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1))"
            proof(rule bexI[of _ "?A"])
              show " ex tVar12 be Ordinal-SequenceORDINAL2M1 st xx =HIDDENR1 x & ((((y =HIDDENR1 [TARSKIK4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx),tVar12 ] & domRELAT-1K1 tVar12 =XBOOLE-0R4 M) & tVar12  |RELAT-1K8 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx)) be increasingORDINAL2V2) & rngFUNCT-1K2 (tVar12  |RELAT-1K8 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx))) =XBOOLE-0R4 f .:FUNCT-1K5 xx) & ( for B be OrdinalORDINAL1M3 holds order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx) c=ORDINAL1R1 B & B inTARSKIR2 M implies tVar12 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1))"
              proof(rule bexI[of _ "?phi"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                show "xx =HIDDENR1 x"
                   sorry
                have "cardCARD-1K1 (f .:FUNCT-1K5 xx) =XBOOLE-0R4 cardCARD-1K1 ?A"
                  using A3 card_5_th_7 relat_1_th_111 sorry
                then have "cardCARD-1K1 ?A inTARSKIR2 M"
                  using A6 card_1_th_67 ordinal1_th_12 sorry
                then have "?A inTARSKIR2 M"
                  using card_3_th_44 sorry
                then have "?A c=ORDINAL1R1 M"
                  using ordinal1_def_2 sorry
                then have "?A +^ORDINAL2K10 (M -^ORDINAL3K5 ?A) =XBOOLE-0R4 M"
                  using ordinal3_def_5 sorry
                thus "((y =HIDDENR1 [TARSKIK4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx),xi1 ^ORDINAL4K1 xi2 ] & domRELAT-1K1 (xi1 ^ORDINAL4K1 xi2) =XBOOLE-0R4 M) & (xi1 ^ORDINAL4K1 xi2) |RELAT-1K8 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx)) be increasingORDINAL2V2) & rngFUNCT-1K2 ((xi1 ^ORDINAL4K1 xi2) |RELAT-1K8 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 (f .:FUNCT-1K5 xx))) =XBOOLE-0R4 f .:FUNCT-1K5 xx"
                  using A7 A8 A9 A5 card_5_th_12 ordinal4_def_1 sorry
                fix B assume [ty]: "B be OrdinalORDINAL1M3"
                assume A10: "?A c=ORDINAL1R1 B"
                  and A11: "B inTARSKIR2 M"
                have A12: "B -^ORDINAL3K5 ?A inTARSKIR2 M -^ORDINAL3K5 ?A"
                  using A10 A11 ordinal3_th_53 sorry
                have "B =XBOOLE-0R4 ?A +^ORDINAL2K10 (B -^ORDINAL3K5 ?A)"
                  using A10 ordinal3_def_5 sorry
                then have "?phi .FUNCT-1K1 B =XBOOLE-0R4 xi2 .FUNCT-1K1 (B -^ORDINAL3K5 ?A)"
                  using A8 A5 A12 ordinal4_def_1 sorry
                thus "(xi1 ^ORDINAL4K1 xi2).FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1"
                  using A5 A12 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A13: "domRELAT-1K1 g =XBOOLE-0R4 ?Z & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?Z implies ?P(x,g .FUNCT-1K1 x))"
      using classes1_sch_1 A4 sorry
    assume A14: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 g implies x inHIDDENR3 [:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 g"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A15: "y inHIDDENR3 domRELAT-1K1 g"and A16: "x =HIDDENR1 g .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        obtain yy A phi where
          [ty]:"yy be setHIDDENM2" "A be OrdinalORDINAL1M3" "phi be Ordinal-SequenceORDINAL2M1" and 
          A17: "yy =HIDDENR1 y"and A18: "x =HIDDENR1 [TARSKIK4 A,phi ]"and A19: "domRELAT-1K1 phi =XBOOLE-0R4 M"and A20: "phi  |RELAT-1K8 A be increasingORDINAL2V2"and A21: "rngFUNCT-1K2 (phi  |RELAT-1K8 A) =XBOOLE-0R4 f .:FUNCT-1K5 yy"and A22: " for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B & B inTARSKIR2 M implies phi .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1"
          using A13 A15 A16 sorry
        have A23: " ex Y be SubsetSUBSET-1M2-of X st y =HIDDENR1 Y & cardCARD-1K1 Y inTARSKIR2 M"
          using A13 A15 sorry
        have "rngFUNCT-1K2 phi c=TARSKIR1 cardCARD-1K1 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 phi implies x inHIDDENR3 cardCARD-1K1 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 phi"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A24: "z inHIDDENR3 domRELAT-1K1 phi"and A25: "x =HIDDENR1 phi .FUNCT-1K1 z"
              using funct_1_def_3 sorry
            have 
              [ty]:"z be OrdinalORDINAL1M3"
              using A24 sorry
            have "z inTARSKIR2 A or A c=ORDINAL1R1 z"
              using ordinal1_th_16 sorry
            then have "x inHIDDENR3 f .:FUNCT-1K5 yy & f .:FUNCT-1K5 yy c=TARSKIR1 cardCARD-1K1 X or x =HIDDENR1 {}XBOOLE-0K1"
              using A3 A19 A21 A22 A24 A25 funct_1_th_50 relat_1_th_111 sorry
            thus "x inHIDDENR3 cardCARD-1K1 X"
              using A14 ordinal3_th_8 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 phi c=TARSKIR1 cardCARD-1K1 X"
            using tarski_def_3 sorry
        qed
        then have A26: "phi inTARSKIR2 FuncsFUNCT-2K1(M,cardCARD-1K1 X)"
          using A19 funct_2_def_2 sorry
        have A27: "A c=ORDINAL1R1 M or M c=ORDINAL1R1 A"
           sorry
        have "phi  |RELAT-1K8 A be one-to-oneFUNCT-1V2"
          using A20 card_5_th_11 sorry
        then have "(domRELAT-1K1 (phi  |RELAT-1K8 A),f .:FUNCT-1K5 yy)are-equipotentWELLORD2R2"
          using A21 wellord2_def_4 sorry
        then have "cardCARD-1K1 (domRELAT-1K1 (phi  |RELAT-1K8 A)) =XBOOLE-0R4 cardCARD-1K1 (f .:FUNCT-1K5 yy)"
          using card_1_th_5 sorry
        then have "cardCARD-1K1 (domRELAT-1K1 (phi  |RELAT-1K8 A)) inTARSKIR2 M"
          using A23 card_1_th_67 ordinal1_th_12 A17 sorry
        then have A28: "domRELAT-1K1 (phi  |RELAT-1K8 A) inTARSKIR2 M"
          using card_3_th_44 sorry
        then have "domRELAT-1K1 (phi  |RELAT-1K8 A) <>HIDDENR2 M"
           sorry
        then have "A inTARSKIR2 M"
          using A19 A28 A27 relat_1_th_62 relat_1_th_68 sorry
        thus "x inHIDDENR3 [:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]"
          using A18 A26 zfmisc_1_th_87 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 g c=TARSKIR1 [:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]"
        using tarski_def_3 sorry
    qed
    then have A29: "cardCARD-1K1 (rngFUNCT-1K2 g) c=ORDINAL1R1 cardCARD-1K1 ([:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :])"
      using card_1_th_11 sorry
    have "g be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & (y inHIDDENR3 domRELAT-1K1 g & g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y) implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A30: "x inHIDDENR3 domRELAT-1K1 g"
          and A31: "y inHIDDENR3 domRELAT-1K1 g"
          and A32: "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
        obtain yy A2 phi2 where
          [ty]:"yy be setHIDDENM2" "A2 be OrdinalORDINAL1M3" "phi2 be Ordinal-SequenceORDINAL2M1" and 
          A33: "yy =HIDDENR1 y"and A34: "g .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 A2,phi2 ]"and "domRELAT-1K1 phi2 =XBOOLE-0R4 M"and "phi2  |RELAT-1K8 A2 be increasingORDINAL2V2"and A35: "rngFUNCT-1K2 (phi2  |RELAT-1K8 A2) =XBOOLE-0R4 f .:FUNCT-1K5 yy"and " for B be OrdinalORDINAL1M3 holds A2 c=ORDINAL1R1 B & B inTARSKIR2 M implies phi2 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1"
          using A13 A31 sorry
        obtain xx A1 phi1 where
          [ty]:"xx be setHIDDENM2" "A1 be OrdinalORDINAL1M3" "phi1 be Ordinal-SequenceORDINAL2M1" and 
          A36: "xx =HIDDENR1 x"and A37: "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 A1,phi1 ]"and "domRELAT-1K1 phi1 =XBOOLE-0R4 M"and "phi1  |RELAT-1K8 A1 be increasingORDINAL2V2"and A38: "rngFUNCT-1K2 (phi1  |RELAT-1K8 A1) =XBOOLE-0R4 f .:FUNCT-1K5 xx"and " for B be OrdinalORDINAL1M3 holds A1 c=ORDINAL1R1 B & B inTARSKIR2 M implies phi1 .FUNCT-1K1 B =XBOOLE-0R4 {}XBOOLE-0K1"
          using A13 A30 sorry
        have A39: "A1 =XBOOLE-0R4 A2 & phi1 =FUNCT-1R1 phi2"
          using A32 A37 A34 xtuple_0_th_1 sorry
        have A40: " ex Y be SubsetSUBSET-1M2-of X st x =HIDDENR1 Y & cardCARD-1K1 Y inTARSKIR2 M"
          using A13 A30 sorry
        have "xx =XBOOLE-0R4 yy"
        proof-
          have "xx c=TARSKIR1 yy & yy c=TARSKIR1 xx"
          proof(rule conjMI)
            show "xx c=TARSKIR1 yy"
            proof-
              have " for z be objectHIDDENM1 holds z inHIDDENR3 xx implies z inHIDDENR3 yy"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                assume A41: "z inHIDDENR3 xx"
                then have "f .FUNCT-1K1 z inTARSKIR2 f .:FUNCT-1K5 xx"
                  using A2 A40 funct_1_def_6 A36 sorry
                then have " ex x1 be objectHIDDENM1 st (x1 inHIDDENR3 domRELAT-1K1 f & x1 inHIDDENR3 yy) & f .FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 x1"
                  using A38 A35 A39 funct_1_def_6 sorry
                thus "z inHIDDENR3 yy"
                  using A1 A2 A40 A41 A36 sorry
              qed "sorry"
              thus "xx c=TARSKIR1 yy"
                using tarski_def_3 sorry
            qed
            have " for z be objectHIDDENM1 holds z inHIDDENR3 yy implies z inHIDDENR3 xx"
            proof(rule ballI,rule impI)
              fix z assume [ty]: "z be objectHIDDENM1"
              have A42: " ex Y be SubsetSUBSET-1M2-of X st y =HIDDENR1 Y & cardCARD-1K1 Y inTARSKIR2 M"
                using A13 A31 sorry
              assume A43: "z inHIDDENR3 yy"
              then have "f .FUNCT-1K1 z inTARSKIR2 f .:FUNCT-1K5 yy"
                using A2 A42 funct_1_def_6 A33 sorry
              then have " ex x1 be objectHIDDENM1 st (x1 inHIDDENR3 domRELAT-1K1 f & x1 inHIDDENR3 xx) & f .FUNCT-1K1 z =XBOOLE-0R4 f .FUNCT-1K1 x1"
                using A38 A35 A39 funct_1_def_6 sorry
              thus "z inHIDDENR3 xx"
                using A1 A2 A42 A43 A33 sorry
            qed "sorry"
            thus "yy c=TARSKIR1 xx"
              using tarski_def_3 sorry
          qed
          thus "xx =XBOOLE-0R4 yy"
            using xboole_0_def_10 sorry
        qed
        thus "x =HIDDENR1 y"
          using A33 A36 sorry
      qed "sorry"
      thus "g be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    then have A44: "(?Z,rngFUNCT-1K2 g)are-equipotentWELLORD2R2"
      using A13 wellord2_def_4 sorry
    have "cardCARD-1K1 ([:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]) =HIDDENR1 cardCARD-1K1 ([:ZFMISC-1K2 M,cardCARD-1K1 (FuncsFUNCT-2K1(M,cardCARD-1K1 X)) :])"
      using card_2_th_7 sorry
    also have "... = M *`CARD-2K2 cardCARD-1K1 (FuncsFUNCT-2K1(M,cardCARD-1K1 X))"
      using card_2_def_2 sorry
    also have "... = M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
      using card_2_def_3 sorry
    finally have "cardCARD-1K1 ([:ZFMISC-1K2 M,FuncsFUNCT-2K1(M,cardCARD-1K1 X) :]) =HIDDENR1 M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
       sorry
    thus "cardCARD-1K1 ({Y where Y be SubsetSUBSET-1M2-of X : cardCARD-1K1 Y inTARSKIR2 M }) c=ORDINAL1R1 M *`CARD-2K2 (expCARD-2K3(cardCARD-1K1 X,M))"
      using A44 A29 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_14:
" for M be CardinalCARD-1M1 holds M inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,M)"
proof-
  have " for M be CardinalCARD-1M1 holds M inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,M)"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    have "cardCARD-1K1 (boolZFMISC-1K1 M) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 M) & cardCARD-1K1 M =XBOOLE-0R4 M"
      using card_2_th_31 sorry
    thus "M inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,M)"
      using card_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_cl_2:
"cluster infiniteFINSET-1V2 for CardinalCARD-1M1"
proof
(*existence*)
  show " ex it be CardinalCARD-1M1 st it be infiniteFINSET-1V2"
  proof-
    have " ex tVar13 be CardinalCARD-1M1 st  not tVar13 be infiniteFINSET-1V2"
    proof-
      show " ex tVar13 be CardinalCARD-1M1 st  not tVar13 be infiniteFINSET-1V2"
      proof(rule bexI[of _ "omegaORDINAL1K4"])
        show " not omegaORDINAL1K4 be infiniteFINSET-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_5_cl_3:
"cluster infiniteFINSET-1V2 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be infiniteFINSET-1V2 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

syntax CARD_5M1 :: "Ty" ("AlephCARD-5M1" 70)
translations "AlephCARD-5M1" \<rightharpoonup> "infiniteFINSET-1V2\<bar>CardinalCARD-1M1"

mdef card_5_def_1 ("cfCARD-5K1  _ " [164]164 ) where
  mlet "M be CardinalCARD-1M1"
"func cfCARD-5K1 M \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. M is-cofinal-withORDINAL2R2 it & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it c=ORDINAL1R1 N)"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st M is-cofinal-withORDINAL2R2 it & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it c=ORDINAL1R1 N)"
    proof-
      have " ex tVar14 be CardinalCARD-1M1 st M is-cofinal-withORDINAL2R2 tVar14 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies tVar14 c=ORDINAL1R1 N)"
      proof-
        let ?P = "\<lambda>Lamb1. M is-cofinal-withORDINAL2R2 Lamb1 & Lamb1 be CardinalCARD-1M1"
        have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A2: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
          using ordinal1_sch_1 A1 sorry
        obtain K where 
          [ty]:"K be CardinalCARD-1M1" and KDef:"K = A"
          using A2 sorry
        show " ex tVar14 be CardinalCARD-1M1 st M is-cofinal-withORDINAL2R2 tVar14 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies tVar14 c=ORDINAL1R1 N)"
        proof(rule bexI[of _ "K"],rule conjMI,rule ballI,rule impI)
          show "M is-cofinal-withORDINAL2R2 K"
            using A2 sorry
          fix N assume [ty]: "N be CardinalCARD-1M1"
          assume "M is-cofinal-withORDINAL2R2 N"
          thus "K c=ORDINAL1R1 N"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds (M is-cofinal-withORDINAL2R2 it1 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it1 c=ORDINAL1R1 N)) & (M is-cofinal-withORDINAL2R2 it2 & ( for N be CardinalCARD-1M1 holds M is-cofinal-withORDINAL2R2 N implies it2 c=ORDINAL1R1 N)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mdef card_5_def_2 (" _ -powerfunc-ofCARD-5K2  _ " [164,164]164 ) where
  mlet "M be CardinalCARD-1M1", "N be CardinalCARD-1M1"
"func N -powerfunc-ofCARD-5K2 M \<rightarrow> Cardinal-FunctionCARD-3M1 means
  \<lambda>it. ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
proof-
  (*existence*)
    show " ex it be Cardinal-FunctionCARD-3M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
    proof-
      have " ex tVar15 be Cardinal-FunctionCARD-3M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 tVar15 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies tVar15 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
      proof-
        let ?f = "\<lambda>Lamb1. expCARD-2K3(cardCARD-1K1 Lamb1,N)"
        let ?P = "\<lambda>Lamb1. Lamb1 be CardinalCARD-1M1"
        obtain X where
          [ty]:"X be setHIDDENM2" and 
          A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 M & ?P(x)"
          using xboole_0_sch_1 sorry
        obtain f where
          [ty]:"f be Cardinal-FunctionCARD-3M1" and 
          A4: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be setHIDDENM2 holds x inTARSKIR2 X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
          using card_3_sch_1 sorry
        show " ex tVar15 be Cardinal-FunctionCARD-3M1 st ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 tVar15 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies tVar15 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
          show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f iff x inHIDDENR3 M & x be CardinalCARD-1M1"
            using A3 A4 sorry
          fix K assume [ty]: "K be CardinalCARD-1M1"
          assume "K inTARSKIR2 M"
          then have "K =XBOOLE-0R4 cardCARD-1K1 K & K inTARSKIR2 X"
            using A3 sorry
          thus "f .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N)"
            using A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Cardinal-FunctionCARD-3M1 holds  for it2 be Cardinal-FunctionCARD-3M1 holds (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it1 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies it2 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be Cardinal-FunctionCARD-3M1 holds  for f2 be Cardinal-FunctionCARD-3M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & (( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies f1 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f2 iff x inHIDDENR3 M & x be CardinalCARD-1M1) & ( for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies f2 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 M & Lamb1 be CardinalCARD-1M1"
        fix f1 assume [ty]: "f1 be Cardinal-FunctionCARD-3M1"
        fix f2 assume [ty]: "f2 be Cardinal-FunctionCARD-3M1"
        assume A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 iff ?P(x)"
          and A6: " for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies f1 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N)"
          and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f2 iff ?P(x)"
          and A8: " for K be CardinalCARD-1M1 holds K inTARSKIR2 M implies f2 .FUNCT-1K1 K =XBOOLE-0R4 expCARD-2K3(K,N)"
        have A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A10: "x inHIDDENR3 domRELAT-1K1 f1"
          then obtain K where 
            [ty]:"K be CardinalCARD-1M1" and KDef:"K = x"
            using A5 sorry
          have A11: "K inTARSKIR2 M"
            using A5 A10 sorry
          then have "f1 .FUNCT-1K1 x =HIDDENR1 expCARD-2K3(K,N)"
            using A6 sorry
          also have "... = f2 .FUNCT-1K1 x"
            using A8 A11 sorry
          finally show "f1 .FUNCT-1K1 x =HIDDENR1 f2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        have "domRELAT-1K1 f1 =XBOOLE-0R4 domRELAT-1K1 f2"
          using xboole_0_sch_2 A5 A7 sorry
        thus "f1 =HIDDENR1 f2"
          using A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem card_5_cl_4:
  mlet "A be OrdinalORDINAL1M3"
"cluster alephCARD-1K3 A as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "alephCARD-1K3 A be infiniteFINSET-1V2"
    using card_5_th_3 sorry
qed "sorry"

(*begin*)
reserve a, b for "AlephCARD-5M1"
(*\$CT*)
mtheorem card_5_th_16:
" for n be NatNAT-1M1 holds  for a be AlephCARD-5M1 holds ((((a <>HIDDENR2 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a <>HIDDENR2 \<two>\<^sub>M) & a <>HIDDENR2 cardCARD-1K4 n) & cardCARD-1K4 n inTARSKIR2 a) & omegaORDINAL1K4 c=MEMBEREDR6 a"
proof-
  have " for n be NatNAT-1M1 holds  for a be AlephCARD-5M1 holds (((( not a <>HIDDENR2 0NUMBERSK6 &  not a <>HIDDENR2 \<one>\<^sub>M) &  not a <>HIDDENR2 \<two>\<^sub>M) &  not a <>HIDDENR2 cardCARD-1K4 n) & cardCARD-1K4 n inTARSKIR2 a) & omegaORDINAL1K4 c=MEMBEREDR6 a"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix a assume [ty]: "a be AlephCARD-5M1"
    have "omegaORDINAL1K4 c=MEMBEREDR6 a & cardCARD-1K4 n inTARSKIR2 omegaORDINAL1K4"
      using card_3_th_85 sorry
    thus "(((( not a <>HIDDENR2 0NUMBERSK6 &  not a <>HIDDENR2 \<one>\<^sub>M) &  not a <>HIDDENR2 \<two>\<^sub>M) &  not a <>HIDDENR2 cardCARD-1K4 n) & cardCARD-1K4 n inTARSKIR2 a) & omegaORDINAL1K4 c=MEMBEREDR6 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_17:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies M be AlephCARD-5M1"
proof-
  have " for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies M be AlephCARD-5M1"
  proof(rule ballI,rule ballI,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix a assume [ty]: "a be AlephCARD-5M1"
    assume "a c=ORDINAL1R1 M or a inTARSKIR2 M"
    then have A1: "a c=ORDINAL1R1 M"
      using ordinal1_th_16 sorry
    have "omegaORDINAL1K4 c=MEMBEREDR6 a"
      using card_5_th_16 sorry
    then have "omegaORDINAL1K4 c=MEMBEREDR6 M"
      using A1 sorry
    thus "M be AlephCARD-5M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_18:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies ((a +`CARD-2K1 M =XBOOLE-0R4 M & M +`CARD-2K1 a =XBOOLE-0R4 M) & a *`CARD-2K2 M =XBOOLE-0R4 M) & M *`CARD-2K2 a =XBOOLE-0R4 M"
proof-
  have " for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds a c=ORDINAL1R1 M or a inTARSKIR2 M implies a +`CARD-2K1 M =XBOOLE-0R4 M & (M +`CARD-2K1 a =XBOOLE-0R4 M & (a *`CARD-2K2 M =XBOOLE-0R4 M & M *`CARD-2K2 a =XBOOLE-0R4 M))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix a assume [ty]: "a be AlephCARD-5M1"
    have "cardCARD-1K4 (0NUMBERSK6) inTARSKIR2 a"
      using card_5_th_16 sorry
    then have A1: "0NUMBERSK6 inTARSKIR2 a"
       sorry
    assume A2: "a c=ORDINAL1R1 M or a inTARSKIR2 M"
    then have A3: "M be infiniteFINSET-1V2"
      using card_5_th_17 sorry
    have A4: "a c=ORDINAL1R1 M"
      using A2 ordinal1_th_16 sorry
    show "a +`CARD-2K1 M =XBOOLE-0R4 M"
      using card_2_th_76 A3 A4 sorry
    show "M +`CARD-2K1 a =XBOOLE-0R4 M"
      using card_2_th_76 A3 A4 sorry
    show "a *`CARD-2K2 M =XBOOLE-0R4 M"
      using A1 card_4_th_16 A3 A4 sorry
    show "M *`CARD-2K2 a =XBOOLE-0R4 M"
      using A1 card_4_th_16 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_19:
" for a be AlephCARD-5M1 holds a +`CARD-2K1 a =XBOOLE-0R4 a & a *`CARD-2K2 a =XBOOLE-0R4 a"
  using card_2_th_75 card_4_th_15 sorry

mtheorem card_5_th_20:
" for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds M c=ORDINAL1R1 expCARD-2K3(M,a)"
proof-
  have " for M be CardinalCARD-1M1 holds  for a be AlephCARD-5M1 holds M c=ORDINAL1R1 expCARD-2K3(M,a)"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix a assume [ty]: "a be AlephCARD-5M1"
    have "\<one>\<^sub>M inTARSKIR2 a"
      using card_5_lm_1 card_5_th_16 sorry
    then have "M =XBOOLE-0R4 0NUMBERSK6 & {}XBOOLE-0K1 c=MEMBEREDR6 expCARD-2K3(M,a) or expCARD-2K3(M,\<one>\<^sub>M) c=ORDINAL1R1 expCARD-2K3(M,a) & expCARD-2K3(M,\<one>\<^sub>M) =XBOOLE-0R4 M"
      using card_2_th_27 card_2_th_93 sorry
    thus "M c=ORDINAL1R1 expCARD-2K3(M,a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_21:
" for a be AlephCARD-5M1 holds unionTARSKIK3 a =XBOOLE-0R4 a"
  using ordinal1_def_6 sorry

mtheorem card_5_cl_5:
  mlet "a be AlephCARD-5M1", "M be CardinalCARD-1M1"
"cluster a +`CARD-2K1 M as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "a +`CARD-2K1 M be infiniteFINSET-1V2"
  proof-
    have " not a +`CARD-2K1 M be finiteFINSET-1V1"
    proof-
      have "a c=ORDINAL1R1 M or M c=ORDINAL1R1 a"
         sorry
      then have "a +`CARD-2K1 M =XBOOLE-0R4 M & M be AlephCARD-5M1 or a +`CARD-2K1 M =XBOOLE-0R4 a"
        using card_5_th_18 card_2_th_76 sorry
      thus " not a +`CARD-2K1 M be finiteFINSET-1V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_5_cl_6:
  mlet "M be CardinalCARD-1M1", "a be AlephCARD-5M1"
"cluster M +`CARD-2K1 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "M +`CARD-2K1 a be infiniteFINSET-1V2"
     sorry
qed "sorry"

mtheorem card_5_cl_7:
  mlet "a be AlephCARD-5M1", "b be AlephCARD-5M1"
"cluster a *`CARD-2K2 b as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "a *`CARD-2K2 b be infiniteFINSET-1V2"
  proof-
    have " not a *`CARD-2K2 b be finiteFINSET-1V1"
    proof-
      have "a c=ORDINAL1R1 b or b c=ORDINAL1R1 a"
         sorry
      thus " not a *`CARD-2K2 b be finiteFINSET-1V1"
        using card_5_th_18 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_5_cl_8:
  mlet "a be AlephCARD-5M1", "b be AlephCARD-5M1"
"cluster expCARD-2K3(a,b) as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "expCARD-2K3(a,b) be infiniteFINSET-1V2"
  proof-
    have " not expCARD-2K3(a,b) be finiteFINSET-1V1"
    proof-
      have "\<one>\<^sub>M inTARSKIR2 b"
        using card_5_lm_1 card_5_th_16 sorry
      then have A1: "expCARD-2K3(a,\<one>\<^sub>M) c=ORDINAL1R1 expCARD-2K3(a,b)"
        using card_2_th_92 sorry
      have "expCARD-2K3(a,\<one>\<^sub>M) =XBOOLE-0R4 a & omegaORDINAL1K4 c=MEMBEREDR6 a"
        using card_5_th_16 card_2_th_27 sorry
      then have "omegaORDINAL1K4 c=MEMBEREDR6 expCARD-2K3(a,b)"
        using A1 sorry
      thus " not expCARD-2K3(a,b) be finiteFINSET-1V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mdef card_5_def_3 ("regularCARD-5V1" 70 ) where
"attr regularCARD-5V1 for AlephCARD-5M1 means
  (\<lambda>IT. cfCARD-5K1 IT =XBOOLE-0R4 IT)"..

syntax CARD_5V2 :: "Ty" ("irregularCARD-5V2" 70)
translations "irregularCARD-5V2" \<rightharpoonup> " non regularCARD-5V1"

mtheorem card_5_cl_9:
  mlet "a be AlephCARD-5M1"
"cluster nextcardCARD-1K2 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "nextcardCARD-1K2 a be infiniteFINSET-1V2"
  proof-
    have " not nextcardCARD-1K2 a be finiteFINSET-1V1"
    proof-
      have A1: "omegaORDINAL1K4 c=MEMBEREDR6 a"
        using card_5_th_16 sorry
      have "a inTARSKIR2 nextcardCARD-1K2 a"
        using card_1_th_18 sorry
      then have "a c=ORDINAL1R1 nextcardCARD-1K2 a"
        using ordinal1_th_16 sorry
      then have "omegaORDINAL1K4 c=MEMBEREDR6 nextcardCARD-1K2 a"
        using A1 sorry
      thus " not nextcardCARD-1K2 a be finiteFINSET-1V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_5_th_22:
"cfCARD-5K1 omegaORDINAL1K4 =XBOOLE-0R4 omegaORDINAL1K4"
proof-
  have "cfCARD-5K1 omegaORDINAL1K4 <>HIDDENR2 omegaORDINAL1K4 implies  False "
  proof(rule impI)
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 c=TARSKIR1 Lamb1"
    assume A1: "cfCARD-5K1 omegaORDINAL1K4 <>HIDDENR2 omegaORDINAL1K4"
    have "cfCARD-5K1 omegaORDINAL1K4 c=ORDINAL1R1 omegaORDINAL1K4"
      using card_5_def_1 sorry
    then have "cfCARD-5K1 omegaORDINAL1K4 inTARSKIR2 omegaORDINAL1K4"
      using A1 card_1_th_3 sorry
    then obtain B where 
      [ty]:"B be finiteFINSET-1V1\<bar>setHIDDENM2" and BDef:"B = cfCARD-5K1 omegaORDINAL1K4"
       sorry
    let ?n = "cardCARD-1K4 B"
    have A2: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds ?P(x,y) & ?P(y,x) implies x =XBOOLE-0R4 y"
       sorry
    have A3: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds ?P(x,y) & ?P(y,z) implies ?P(x,z)"
      using xboole_1_th_1 sorry
    have "omegaORDINAL1K4 is-cofinal-withORDINAL2R2 ?n"
      using card_5_def_1 sorry
    then obtain xi where
      [ty]:"xi be Ordinal-SequenceORDINAL2M1" and 
      A4: "domRELAT-1K1 xi =XBOOLE-0R4 ?n"and A5: "rngFUNCT-1K2 xi c=TARSKIR1 omegaORDINAL1K4"and "xi be increasingORDINAL2V2"and A6: "omegaORDINAL1K4 =XBOOLE-0R4 supORDINAL2K4 xi"
       sorry
    obtain rxi where 
      [ty]:"rxi be finiteFINSET-1V1\<bar>setHIDDENM2" and rxiDef:"rxi = rngFUNCT-1K2 xi"
      using A4 finset_1_th_8 sorry
    have A7: "rxi <>HIDDENR2 {}XBOOLE-0K1"
      using A6 ordinal2_th_18 sorry
    obtain x where
      [ty]:"x be setHIDDENM2" and 
      A8: "x inTARSKIR2 rxi & ( for y be setHIDDENM2 holds y inTARSKIR2 rxi & y <>HIDDENR2 x implies  not ?P(y,x))"
      using card_2_sch_3 A7 A2 A3 sorry
    have 
      [ty]:"x be OrdinalORDINAL1M3"
      using A5 A8 sorry
    have " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 rngFUNCT-1K2 xi implies A inTARSKIR2 succORDINAL1K1 x"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume "A inTARSKIR2 rngFUNCT-1K2 xi"
      then have "A c=ORDINAL1R1 x or  not x c=ORDINAL1R1 A"
        using A8 sorry
      thus "A inTARSKIR2 succORDINAL1K1 x"
        using ordinal1_th_22 sorry
    qed "sorry"
    then have A9: "omegaORDINAL1K4 c=MEMBEREDR6 succORDINAL1K1 x"
      using A6 ordinal2_th_20 sorry
    have "succORDINAL1K1 x inTARSKIR2 omegaORDINAL1K4"
      using A5 A8 ordinal1_th_28 sorry
    thus " False "
      using A9 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_23:
" for a be AlephCARD-5M1 holds cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
proof-
  have " for a be AlephCARD-5M1 holds cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
  proof(rule ballI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    have "nextcardCARD-1K2 a is-cofinal-withORDINAL2R2 cfCARD-5K1 nextcardCARD-1K2 a"
      using card_5_def_1 sorry
    then obtain xi where
      [ty]:"xi be Ordinal-SequenceORDINAL2M1" and 
      A1: "domRELAT-1K1 xi =XBOOLE-0R4 cfCARD-5K1 nextcardCARD-1K2 a"and A2: "rngFUNCT-1K2 xi c=TARSKIR1 nextcardCARD-1K2 a"and "xi be increasingORDINAL2V2"and A3: "nextcardCARD-1K2 a =XBOOLE-0R4 supORDINAL2K4 xi"
       sorry
    have A4: "cardCARD-1K1 (UnionCARD-3K3 xi) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 xi) & SumCARD-3K6 (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a) =XBOOLE-0R4 (cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a"
      using card_2_th_65 card_3_th_39 sorry
    have A5: "cardCARD-1K1 (nextcardCARD-1K2 a) =XBOOLE-0R4 nextcardCARD-1K2 a & succORDINAL1K1 (UnionCARD-3K3 xi) =XBOOLE-0R4 UnionCARD-3K3 xi +^ORDINAL2K10 \<one>\<^sub>M"
      using ordinal2_th_31 sorry
    have A6: " for x be objectHIDDENM1 holds x inHIDDENR3 cfCARD-5K1 nextcardCARD-1K2 a implies CardCARD-3K1 xi .FUNCT-1K1 x c=TARSKIR1 (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A7: "x inHIDDENR3 cfCARD-5K1 nextcardCARD-1K2 a"
      have "xi .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 xi"
        using A1 A7 funct_1_def_3 sorry
      then have A8: "cardCARD-1K1 (xi .FUNCT-1K1 x) inTARSKIR2 nextcardCARD-1K2 a"
        using A2 card_1_th_8 ordinal1_th_12 sorry
      have "CardCARD-3K1 xi .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (xi .FUNCT-1K1 x) & (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a).FUNCT-1K1 x =XBOOLE-0R4 a"
        using A1 A7 card_3_def_2 funcop_1_th_7 sorry
      thus "CardCARD-3K1 xi .FUNCT-1K1 x c=TARSKIR1 (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a).FUNCT-1K1 x"
        using A8 card_3_th_91 sorry
    qed "sorry"
    have "domRELAT-1K1 (CardCARD-3K1 xi) =XBOOLE-0R4 domRELAT-1K1 xi & domRELAT-1K1 (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a) =XBOOLE-0R4 cfCARD-5K1 nextcardCARD-1K2 a"
      using card_3_def_2 funcop_1_th_13 sorry
    then have "SumCARD-3K6 (CardCARD-3K1 xi) c=ORDINAL1R1 SumCARD-3K6 (cfCARD-5K1 nextcardCARD-1K2 a -->FUNCOP-1K7 a)"
      using A1 A6 card_3_th_30 sorry
    then have "cardCARD-1K1 (UnionCARD-3K3 xi) c=ORDINAL1R1 (cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a"
      using A4 sorry
    then have A9: "cardCARD-1K1 (UnionCARD-3K3 xi) +`CARD-2K1 \<one>\<^sub>M c=ORDINAL1R1 (cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a +`CARD-2K1 \<one>\<^sub>M"
      using card_2_th_84 sorry
    have A10: "cardCARD-1K1 (UnionCARD-3K3 xi +^ORDINAL2K10 \<one>\<^sub>M) =XBOOLE-0R4 cardCARD-1K1 (UnionCARD-3K3 xi) +`CARD-2K1 cardCARD-1K4 \<one>\<^sub>M"
      using card_2_th_13 sorry
    have " ex A be OrdinalORDINAL1M3 st rngFUNCT-1K2 xi c=TARSKIR1 A"
      using ordinal2_def_4 sorry
    then have "OnORDINAL1K2 (rngFUNCT-1K2 xi) =XBOOLE-0R4 rngFUNCT-1K2 xi"
      using ordinal3_th_6 sorry
    then have A11: "cardCARD-1K1 (nextcardCARD-1K2 a) c=ORDINAL1R1 cardCARD-1K1 (succORDINAL1K1 (UnionCARD-3K3 xi))"
      using A3 card_1_th_11 ordinal3_th_72 sorry
    have A12: "cfCARD-5K1 nextcardCARD-1K2 a c=ORDINAL1R1 nextcardCARD-1K2 a"
      using card_5_def_1 sorry
    have "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
    proof-
      show "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
      proof-
        have cases: "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 0NUMBERSK6 or cfCARD-5K1 nextcardCARD-1K2 a <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 0NUMBERSK6 implies cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
        proof(rule impI)
          assume "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 0NUMBERSK6"
          then have A13: "(cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a =XBOOLE-0R4 0NUMBERSK6"
            using card_2_th_20 sorry
          show "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
            using A11 A5 A9 A10 A13 sorry
        qed
        have case2: "cfCARD-5K1 nextcardCARD-1K2 a <>HIDDENR2 0NUMBERSK6 implies cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
        proof(rule impI)
          assume A14: "cfCARD-5K1 nextcardCARD-1K2 a <>HIDDENR2 0NUMBERSK6"
          have "0NUMBERSK6 c=ORDINAL1R1 cfCARD-5K1 nextcardCARD-1K2 a"
             sorry
          then have A15: "0NUMBERSK6 inTARSKIR2 cfCARD-5K1 nextcardCARD-1K2 a"
            using A14 card_1_th_3 sorry
          have A16: "cfCARD-5K1 nextcardCARD-1K2 a c=ORDINAL1R1 a or a c=ORDINAL1R1 cfCARD-5K1 nextcardCARD-1K2 a"
             sorry
          have "\<one>\<^sub>M inTARSKIR2 a"
            using card_5_lm_1 card_5_th_16 sorry
          then have A17: "((cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a =XBOOLE-0R4 a & a +`CARD-2K1 \<one>\<^sub>M =XBOOLE-0R4 a) & a inTARSKIR2 nextcardCARD-1K2 a or (cfCARD-5K1 nextcardCARD-1K2 a)*`CARD-2K2 a =XBOOLE-0R4 cfCARD-5K1 nextcardCARD-1K2 a & cfCARD-5K1 nextcardCARD-1K2 a be AlephCARD-5M1"
            using A15 A16 card_5_th_18 card_1_th_18 card_2_th_76 card_4_th_16 sorry
          then have "nextcardCARD-1K2 a c=ORDINAL1R1 cfCARD-5K1 nextcardCARD-1K2 a +`CARD-2K1 \<one>\<^sub>M & \<one>\<^sub>M inTARSKIR2 cfCARD-5K1 nextcardCARD-1K2 a"
            using A11 A5 A9 A10 card_5_th_16 card_1_th_4 sorry
          then have "nextcardCARD-1K2 a c=ORDINAL1R1 cfCARD-5K1 nextcardCARD-1K2 a"
            using A11 A5 A9 A10 A17 card_1_th_4 card_2_th_76 sorry
          thus "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
            using A12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_24:
" for a be AlephCARD-5M1 holds omegaORDINAL1K4 c=MEMBEREDR6 cfCARD-5K1 a"
proof-
  have " for a be AlephCARD-5M1 holds omegaORDINAL1K4 c=MEMBEREDR6 cfCARD-5K1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    have A1: "a is-cofinal-withORDINAL2R2 cfCARD-5K1 a"
      using card_5_def_1 sorry
    then have "cfCARD-5K1 a <>HIDDENR2 {}XBOOLE-0K1"
      using ordinal2_th_50 sorry
    then have A2: "{}XBOOLE-0K1 inTARSKIR2 cfCARD-5K1 a"
      using ordinal3_th_8 sorry
    have "cfCARD-5K1 a be limit-ordinalORDINAL1V4"
      using A1 ordinal4_th_38 sorry
    thus "omegaORDINAL1K4 c=MEMBEREDR6 cfCARD-5K1 a"
      using A2 ordinal1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_25:
" for n be NatNAT-1M1 holds cfCARD-5K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds cfCARD-5K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6 & cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "succORDINAL1K1 n is-cofinal-withORDINAL2R2 \<one>\<^sub>M"
      using ordinal3_th_73 sorry
    have "cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M & SegmORDINAL1K6 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 succORDINAL1K1 (SegmORDINAL1K6 n)"
      using nat_1_th_38 sorry
    then have "cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) c=ORDINAL1R1 \<one>\<^sub>M"
      using A1 card_5_def_1 sorry
    then have A2: "cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M or (cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6 & {}XBOOLE-0K1 c=MEMBEREDR6 n) & n inTARSKIR2 succORDINAL1K1 n"
      using ordinal1_th_6 ordinal3_th_16 sorry
    have "cfCARD-5K1 (0NUMBERSK6) c=ORDINAL1R1 0NUMBERSK6 & 0NUMBERSK6 c=ORDINAL1R1 cfCARD-5K1 (0NUMBERSK6)"
      using card_5_def_1 sorry
    thus "cfCARD-5K1 (0NUMBERSK6) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have "cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) is-cofinal-withORDINAL2R2 cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M)"
      using card_5_def_1 sorry
    thus "cfCARD-5K1 cardCARD-1K4 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 ordinal2_th_50 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_26:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X c=TARSKIR1 M & cardCARD-1K1 X inTARSKIR2 cfCARD-5K1 M implies supORDINAL2K3 X inTARSKIR2 M & unionTARSKIK3 X inTARSKIR2 M"
proof-
  have " for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X c=TARSKIR1 M & cardCARD-1K1 X inTARSKIR2 cfCARD-5K1 M implies supORDINAL2K3 X inTARSKIR2 M & unionTARSKIK3 X inTARSKIR2 M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    assume A1: "X c=TARSKIR1 M"
      and A2: "cardCARD-1K1 X inTARSKIR2 cfCARD-5K1 M"
    let ?A = "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
    have A3: "cardCARD-1K1 ?A =XBOOLE-0R4 cardCARD-1K1 X"
      using A1 card_5_th_7 sorry
    obtain N where
      [ty]:"N be CardinalCARD-1M1" and 
      A4: "N c=ORDINAL1R1 cardCARD-1K1 ?A"and A5: "?A is-cofinal-withORDINAL2R2 N"and " for C be OrdinalORDINAL1M3 holds ?A is-cofinal-withORDINAL2R2 C implies N c=ORDINAL1R1 C"
      using card_5_th_9 sorry
    have "supORDINAL2K3 X is-cofinal-withORDINAL2R2 ?A"
      using A1 card_5_th_6 sorry
    then have A6: "supORDINAL2K3 X is-cofinal-withORDINAL2R2 N"
      using A5 ordinal4_th_37 sorry
    have A7: "supORDINAL2K3 X =XBOOLE-0R4 M implies  False "
    proof(rule impI)
      assume "supORDINAL2K3 X =XBOOLE-0R4 M"
      then have "cfCARD-5K1 M c=ORDINAL1R1 N"
        using A6 card_5_def_1 sorry
      thus " False "
        using A2 A3 A4 card_1_th_4 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be OrdinalORDINAL1M3"
      using A1 sorry
    then obtain A where 
      [ty]:"A be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ADef:"A = unionTARSKIK3 X"
      using ordinal1_th_23 sorry
    have A8: "supORDINAL2K3 M =XBOOLE-0R4 M"
      using ordinal2_th_18 sorry
    have "supORDINAL2K3 X c=ORDINAL1R1 supORDINAL2K3 M"
      using A1 ordinal2_th_22 sorry
    then have A9: "supORDINAL2K3 X c<XBOOLE-0R2 M"
      using A8 A7 sorry
    thus "supORDINAL2K3 X inTARSKIR2 M"
      using ordinal1_th_11 sorry
    have "A c=ORDINAL1R1 supORDINAL2K3 X"
    proof-
      have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 A implies x inTARSKIR2 supORDINAL2K3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be OrdinalORDINAL1M3"
        assume "x inTARSKIR2 A"
        then obtain Y where
          [ty]:"Y be setHIDDENM2" and 
          A10: "x inTARSKIR2 Y"and A11: "Y inTARSKIR2 X"
          using tarski_def_4 sorry
        have 
          [ty]:"Y be OrdinalORDINAL1M3"
          using A1 A11 sorry
        have "Y inTARSKIR2 supORDINAL2K3 X"
          using A11 ordinal2_th_19 sorry
        then have "Y c=ORDINAL1R1 supORDINAL2K3 X"
          using ordinal1_def_2 sorry
        thus "x inTARSKIR2 supORDINAL2K3 X"
          using A10 sorry
      qed "sorry"
      thus "A c=ORDINAL1R1 supORDINAL2K3 X"
        using ordinal1_def_5 sorry
    qed
    thus "unionTARSKIK3 X inTARSKIR2 M"
      using A9 ordinal1_th_11 ordinal1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_27:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for phi be Ordinal-SequenceORDINAL2M1 holds (domRELAT-1K1 phi =XBOOLE-0R4 M & rngFUNCT-1K2 phi c=TARSKIR1 N) & M inTARSKIR2 cfCARD-5K1 N implies supORDINAL2K4 phi inTARSKIR2 N & UnionCARD-3K3 phi inTARSKIR2 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  for phi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 phi =XBOOLE-0R4 M & (rngFUNCT-1K2 phi c=TARSKIR1 N & M inTARSKIR2 cfCARD-5K1 N) implies supORDINAL2K4 phi inTARSKIR2 N & UnionCARD-3K3 phi inTARSKIR2 N"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    fix phi assume [ty]: "phi be Ordinal-SequenceORDINAL2M1"
    assume A1: "domRELAT-1K1 phi =XBOOLE-0R4 M"
      and A2: "rngFUNCT-1K2 phi c=TARSKIR1 N"
      and A3: "M inTARSKIR2 cfCARD-5K1 N"
    have "cardCARD-1K1 (rngFUNCT-1K2 phi) c=ORDINAL1R1 cardCARD-1K1 M"
      using A1 card_1_th_12 sorry
    then have "cardCARD-1K1 (rngFUNCT-1K2 phi) inTARSKIR2 cfCARD-5K1 N"
      using A3 ordinal1_th_12 sorry
    thus "supORDINAL2K4 phi inTARSKIR2 N & UnionCARD-3K3 phi inTARSKIR2 N"
      using A2 card_5_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_cl_10:
  mlet "a be AlephCARD-5M1"
"cluster cfCARD-5K1 a as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "cfCARD-5K1 a be infiniteFINSET-1V2"
    using card_5_th_17 card_5_th_24 sorry
qed "sorry"

mtheorem card_5_th_28:
" for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies a be limit-cardinalCARD-1V2"
proof-
  have " for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies a be limit-cardinalCARD-1V2"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    assume A1: "cfCARD-5K1 a inTARSKIR2 a"
    have "( ex M be CardinalCARD-1M1 st a =XBOOLE-0R4 nextcardCARD-1K2 M) implies  False "
    proof(rule impI)
      assume Given: " ex M be CardinalCARD-1M1 st a =XBOOLE-0R4 nextcardCARD-1K2 M"
      then obtain M where
        [ty]:"M be CardinalCARD-1M1" and 
        A2: "a =XBOOLE-0R4 nextcardCARD-1K2 M"
         sorry
      have "cfCARD-5K1 a c=ORDINAL1R1 M"
        using A1 A2 card_3_th_91 sorry
      then have 
        [ty]:"M be AlephCARD-5M1"
         sorry
      have "nextcardCARD-1K2 M inTARSKIR2 nextcardCARD-1K2 M"
        using A1 A2 card_5_th_23 sorry
      thus " False "
         sorry
    qed
    thus "a be limit-cardinalCARD-1V2"
      using card_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_29:
" for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies ( ex xi be Ordinal-SequenceORDINAL2M1 st ((((domRELAT-1K1 xi =XBOOLE-0R4 cfCARD-5K1 a & rngFUNCT-1K2 xi c=TARSKIR1 a) & xi be increasingORDINAL2V2) & a =XBOOLE-0R4 supORDINAL2K4 xi) & xi be Cardinal-FunctionCARD-3M1) &  not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 xi)"
proof-
  have " for a be AlephCARD-5M1 holds cfCARD-5K1 a inTARSKIR2 a implies ( ex tVar17 be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 tVar17 =XBOOLE-0R4 cfCARD-5K1 a & (rngFUNCT-1K2 tVar17 c=TARSKIR1 a & (tVar17 be increasingORDINAL2V2 & ((a =XBOOLE-0R4 supORDINAL2K4 tVar17 & tVar17 be Cardinal-FunctionCARD-3M1) &  not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 tVar17))))"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    have "a is-cofinal-withORDINAL2R2 cfCARD-5K1 a"
      using card_5_def_1 sorry
    then obtain xi where
      [ty]:"xi be Ordinal-SequenceORDINAL2M1" and 
      A1: "domRELAT-1K1 xi =XBOOLE-0R4 cfCARD-5K1 a"and A2: "rngFUNCT-1K2 xi c=TARSKIR1 a"and "xi be increasingORDINAL2V2"and A3: "a =XBOOLE-0R4 supORDINAL2K4 xi"
       sorry
    let ?f = "\<lambda>Lamb1. nextcardCARD-1K2 (xi .FUNCT-1K1 domRELAT-1K1 Lamb1) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 Lamb1"
    obtain phi where
      [ty]:"phi be SequenceORDINAL1M4" and 
      A4: "domRELAT-1K1 phi =XBOOLE-0R4 cfCARD-5K1 a & ( for A be OrdinalORDINAL1M3 holds  for psi be SequenceORDINAL1M4 holds A inTARSKIR2 cfCARD-5K1 a & psi =FUNCT-1R1 phi  |RELAT-1K8 A implies phi .FUNCT-1K1 A =XBOOLE-0R4 ?f(psi))"
      using ordinal1_sch_4 sorry
    have "phi be Ordinal-yieldingORDINAL2V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 phi implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 phi)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 rngFUNCT-1K2 phi"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A6: "y inHIDDENR3 domRELAT-1K1 phi"and A7: "x =HIDDENR1 phi .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be OrdinalORDINAL1M3"
          using A6 sorry
        have "y c=ORDINAL1R1 domRELAT-1K1 phi"
          using A6 ordinal1_def_2 sorry
        then have "domRELAT-1K1 (phi  |RELAT-1K8 y) =XBOOLE-0R4 y"
          using relat_1_th_62 sorry
        then have "x =HIDDENR1 nextcardCARD-1K2 (xi .FUNCT-1K1 y) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 y)"
          using A4 A6 A7 sorry
        thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 phi)"
          using A5 ordinal2_th_19 sorry
      qed "sorry"
      then have "rngRELAT-1K2 phi c=TARSKIR1 supORDINAL2K3 (rngFUNCT-1K2 phi)"
        using tarski_def_3 sorry
      thus "phi be Ordinal-yieldingORDINAL2V1"
        using bexI[of _ "supORDINAL2K3 (rngFUNCT-1K2 phi)"] ordinal2_def_4 sorry
    qed
    then have 
      [ty]:"phi be Ordinal-SequenceORDINAL2M1"
       sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 cfCARD-5K1 a implies phi .FUNCT-1K1 Lamb1 inTARSKIR2 a"
    assume "cfCARD-5K1 a inTARSKIR2 a"
    then have A8: "a be limit-cardinalCARD-1V2"
      using card_5_th_28 sorry
    have A9: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B inTARSKIR2 cfCARD-5K1 a implies phi .FUNCT-1K1 B inTARSKIR2 a)) implies (A inTARSKIR2 cfCARD-5K1 a implies phi .FUNCT-1K1 A inTARSKIR2 a)"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A10: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)"
      show "A inTARSKIR2 cfCARD-5K1 a implies phi .FUNCT-1K1 A inTARSKIR2 a"
      proof(rule impI)
        assume A11: "A inTARSKIR2 cfCARD-5K1 a"
        then have A12: "cardCARD-1K1 A inTARSKIR2 cfCARD-5K1 a"
          using card_1_th_9 sorry
        have "A c=ORDINAL1R1 domRELAT-1K1 phi"
          using A4 A11 ordinal1_def_2 sorry
        then have A13: "domRELAT-1K1 (phi  |RELAT-1K8 A) =XBOOLE-0R4 A"
          using relat_1_th_62 sorry
        then have "phi .FUNCT-1K1 A =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 A) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 A)"
          using A4 A11 sorry
        then have A14: "phi .FUNCT-1K1 A =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 A) or phi .FUNCT-1K1 A =XBOOLE-0R4 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 A)"
          using ordinal3_th_12 sorry
        have A15: "rngFUNCT-1K2 (phi  |RELAT-1K8 A) c=TARSKIR1 a"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (phi  |RELAT-1K8 A) implies x inHIDDENR3 a"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (phi  |RELAT-1K8 A)"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A16: "y inHIDDENR3 domRELAT-1K1 (phi  |RELAT-1K8 A)"and A17: "x =HIDDENR1 (phi  |RELAT-1K8 A).FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A16 sorry
            have "x =HIDDENR1 phi .FUNCT-1K1 y & y inTARSKIR2 cfCARD-5K1 a"
              using A11 A13 A16 A17 funct_1_th_47 ordinal1_th_10 sorry
            thus "x inHIDDENR3 a"
              using A10 A13 A16 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (phi  |RELAT-1K8 A) c=TARSKIR1 a"
            using tarski_def_3 sorry
        qed
        have "(phi  |RELAT-1K8 A).:FUNCT-1K5 A =XBOOLE-0R4 rngFUNCT-1K2 (phi  |RELAT-1K8 A)"
          using A13 relat_1_th_113 sorry
        then have "cardCARD-1K1 (rngFUNCT-1K2 (phi  |RELAT-1K8 A)) inTARSKIR2 cfCARD-5K1 a"
          using A12 card_1_th_67 ordinal1_th_12 sorry
        then have "supORDINAL2K3 (rngFUNCT-1K2 (phi  |RELAT-1K8 A)) inTARSKIR2 a"
          using A15 card_5_th_26 sorry
        then have "cardCARD-1K1 supORDINAL2K4 (phi  |RELAT-1K8 A) inTARSKIR2 a"
          using card_1_th_9 sorry
        then have A18: "nextcardCARD-1K2 (cardCARD-1K1 supORDINAL2K4 (phi  |RELAT-1K8 A)) c=ORDINAL1R1 a"
          using card_3_th_90 sorry
        have "xi .FUNCT-1K1 A inTARSKIR2 rngFUNCT-1K2 xi"
          using A1 A11 funct_1_def_3 sorry
        then have "cardCARD-1K1 (xi .FUNCT-1K1 A) inTARSKIR2 a"
          using A2 card_1_th_9 sorry
        then have A19: "nextcardCARD-1K2 (cardCARD-1K1 (xi .FUNCT-1K1 A)) c=ORDINAL1R1 a"
          using card_3_th_90 sorry
        have A20: "nextcardCARD-1K2 (cardCARD-1K1 supORDINAL2K4 (phi  |RELAT-1K8 A)) <>HIDDENR2 a & nextcardCARD-1K2 (cardCARD-1K1 supORDINAL2K4 (phi  |RELAT-1K8 A)) =XBOOLE-0R4 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 A)"
          using A8 card_5_th_1 sorry
        have "a <>HIDDENR2 nextcardCARD-1K2 (cardCARD-1K1 (xi .FUNCT-1K1 A)) & nextcardCARD-1K2 (cardCARD-1K1 (xi .FUNCT-1K1 A)) =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 A)"
          using A8 card_5_th_1 sorry
        thus "phi .FUNCT-1K1 A inTARSKIR2 a"
          using A19 A18 A20 A14 card_1_th_3 sorry
      qed
    qed "sorry"
    have A21: " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal1_sch_2 A9 sorry
    have A22: "rngFUNCT-1K2 phi c=TARSKIR1 a"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 phi implies x inHIDDENR3 a"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 phi"
        then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 phi & x =HIDDENR1 phi .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        thus "x inHIDDENR3 a"
          using A4 A21 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 phi c=TARSKIR1 a"
        using tarski_def_3 sorry
    qed
    show " ex tVar17 be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 tVar17 =XBOOLE-0R4 cfCARD-5K1 a & (rngFUNCT-1K2 tVar17 c=TARSKIR1 a & (tVar17 be increasingORDINAL2V2 & ((a =XBOOLE-0R4 supORDINAL2K4 tVar17 & tVar17 be Cardinal-FunctionCARD-3M1) &  not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 tVar17)))"
    proof(rule bexI[of _ "phi"],rule conjMI,rule conjMI,rule conjMI)
      show "domRELAT-1K1 phi =XBOOLE-0R4 cfCARD-5K1 a"
        using A4 sorry
      show "rngFUNCT-1K2 phi c=TARSKIR1 a"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 phi implies x inHIDDENR3 a"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 phi"
          then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 phi & x =HIDDENR1 phi .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          thus "x inHIDDENR3 a"
            using A4 A21 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 phi c=TARSKIR1 a"
          using tarski_def_3 sorry
      qed
      show "phi be increasingORDINAL2V2"
      proof-
        have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 phi implies phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 B"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix A assume [ty]: "A be OrdinalORDINAL1M3"
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume A23: "A inTARSKIR2 B"
            and A24: "B inTARSKIR2 domRELAT-1K1 phi"
          obtain C where 
            [ty]:"C be OrdinalORDINAL1M3" and CDef:"C = phi .FUNCT-1K1 A"
             sorry
          have "A inTARSKIR2 domRELAT-1K1 phi"
            using A23 A24 ordinal1_th_10 sorry
          then have "C inTARSKIR2 rngFUNCT-1K2 (phi  |RELAT-1K8 B)"
            using A23 funct_1_th_50 sorry
          then have A25: "C inTARSKIR2 supORDINAL2K4 (phi  |RELAT-1K8 B)"
            using ordinal2_th_19 sorry
          have "supORDINAL2K4 (phi  |RELAT-1K8 B) inTARSKIR2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 B)"
            using card_1_th_18 sorry
          then have A26: "C inTARSKIR2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 B)"
            using A25 ordinal1_th_10 sorry
          have "phi .FUNCT-1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 domRELAT-1K1 (phi  |RELAT-1K8 B)) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 B)"
            using A4 A24 sorry
          thus "phi .FUNCT-1K1 A inTARSKIR2 phi .FUNCT-1K1 B"
            using A26 xboole_0_def_3 sorry
        qed "sorry"
        thus "phi be increasingORDINAL2V2"
          using ordinal2_def_12 sorry
      qed
      have "a c=ORDINAL1R1 supORDINAL2K4 phi & (supORDINAL2K4 phi c=ORDINAL1R1 a & (phi be Cardinal-FunctionCARD-3M1 & (0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 phi implies  False )))"
      proof(rule conjMI,rule conjMI,rule conjMI,rule impI)
        show "a c=ORDINAL1R1 supORDINAL2K4 phi"
        proof-
          have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 a implies x inTARSKIR2 supORDINAL2K4 phi"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be OrdinalORDINAL1M3"
            assume "x inTARSKIR2 a"
            then have 
              [ty]:"x be ElementSUBSET-1M1-of a"
               sorry
            obtain A where
              [ty]:"A be OrdinalORDINAL1M3" and 
              A27: "A inTARSKIR2 rngFUNCT-1K2 xi"and A28: "x c=ORDINAL1R1 A"
              using A3 ordinal2_th_21 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A29: "y inHIDDENR3 domRELAT-1K1 xi"and A30: "A =XBOOLE-0R4 xi .FUNCT-1K1 y"
              using A27 funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A29 sorry
            have "y c=ORDINAL1R1 cfCARD-5K1 a"
              using A1 A29 ordinal1_def_2 sorry
            then have "domRELAT-1K1 (phi  |RELAT-1K8 y) =XBOOLE-0R4 y"
              using A4 relat_1_th_62 sorry
            then have "A inTARSKIR2 nextcardCARD-1K2 A & phi .FUNCT-1K1 y =XBOOLE-0R4 nextcardCARD-1K2 A \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 y)"
              using A1 A4 A29 A30 card_1_th_18 sorry
            then have "A inTARSKIR2 phi .FUNCT-1K1 y"
              using xboole_0_def_3 sorry
            then have A31: "A c=ORDINAL1R1 phi .FUNCT-1K1 y"
              using ordinal1_def_2 sorry
            have "phi .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 phi"
              using A1 A4 A29 funct_1_def_3 sorry
            then have "phi .FUNCT-1K1 y inTARSKIR2 supORDINAL2K4 phi"
              using ordinal2_th_19 sorry
            thus "x inTARSKIR2 supORDINAL2K4 phi"
              using A28 A31 ordinal1_th_12 xboole_1_th_1 sorry
          qed "sorry"
          thus "a c=ORDINAL1R1 supORDINAL2K4 phi"
            using ordinal1_def_5 sorry
        qed
        have "supORDINAL2K3 a =XBOOLE-0R4 a"
          using ordinal2_th_18 sorry
        thus "supORDINAL2K4 phi c=ORDINAL1R1 a"
          using A22 ordinal2_th_22 sorry
        have "phi be Cardinal-yieldingCARD-3V1"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 phi implies phi .FUNCT-1K1 y be setHIDDENM2"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A32: "y inHIDDENR3 domRELAT-1K1 phi"
            then have 
              [ty]:"y be OrdinalORDINAL1M3"
               sorry
            have "y c=ORDINAL1R1 domRELAT-1K1 phi"
              using A32 ordinal1_def_2 sorry
            then have "domRELAT-1K1 (phi  |RELAT-1K8 y) =XBOOLE-0R4 y"
              using relat_1_th_62 sorry
            then have "phi .FUNCT-1K1 y =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 y) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 y)"
              using A4 A32 sorry
            thus "phi .FUNCT-1K1 y be setHIDDENM2"
              using ordinal3_th_12 sorry
          qed "sorry"
          thus "phi be Cardinal-yieldingCARD-3V1"
            using card_3_def_1 sorry
        qed
        thus "phi be Cardinal-FunctionCARD-3M1"
           sorry
        assume "0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 phi"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A33: "x inHIDDENR3 domRELAT-1K1 phi"and A34: "0NUMBERSK6 =XBOOLE-0R4 phi .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"x be OrdinalORDINAL1M3"
          using A33 sorry
        have "x c=ORDINAL1R1 domRELAT-1K1 phi"
          using A33 ordinal1_def_2 sorry
        then have "domRELAT-1K1 (phi  |RELAT-1K8 x) =XBOOLE-0R4 x"
          using relat_1_th_62 sorry
        then have "0NUMBERSK6 =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 x) \\/XBOOLE-0K2 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 x)"
          using A4 A33 A34 sorry
        then have "0NUMBERSK6 =XBOOLE-0R4 nextcardCARD-1K2 (xi .FUNCT-1K1 x) or 0NUMBERSK6 =XBOOLE-0R4 nextcardCARD-1K2 supORDINAL2K4 (phi  |RELAT-1K8 x)"
           sorry
        thus " False "
          using card_1_th_15 sorry
      qed
      thus "(a =XBOOLE-0R4 supORDINAL2K4 phi & phi be Cardinal-FunctionCARD-3M1) &  not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 phi"
        using xboole_0_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_30:
" for a be AlephCARD-5M1 holds omegaORDINAL1K4 be regularCARD-5V1 & nextcardCARD-1K2 a be regularCARD-5V1"
  using card_5_th_22 card_5_th_23 sorry

(*begin*)
reserve a, b for "AlephCARD-5M1"
mtheorem card_5_th_31:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a c=ORDINAL1R1 b implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b)"
proof-
  have " for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a c=ORDINAL1R1 b implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    fix b assume [ty]: "b be AlephCARD-5M1"
    have A1: "cardCARD-1K1 (boolZFMISC-1K1 a) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,cardCARD-1K1 a)"
      using card_2_th_31 sorry
    have "cardCARD-1K1 a =XBOOLE-0R4 a & cardCARD-1K1 a inTARSKIR2 cardCARD-1K1 (boolZFMISC-1K1 a)"
      using card_1_th_14 sorry
    then have A2: "expCARD-2K3(a,b) c=ORDINAL1R1 expCARD-2K3(expCARD-2K3(\<two>\<^sub>M,a),b)"
      using A1 card_2_th_92 sorry
    assume "a c=ORDINAL1R1 b"
    then have A3: "expCARD-2K3(expCARD-2K3(\<two>\<^sub>M,a),b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,a *`CARD-2K2 b) & a *`CARD-2K2 b =XBOOLE-0R4 b"
      using card_5_th_18 card_2_th_30 sorry
    have "\<two>\<^sub>M inTARSKIR2 a"
      using card_5_lm_2 card_5_th_16 sorry
    then have "expCARD-2K3(\<two>\<^sub>M,b) c=ORDINAL1R1 expCARD-2K3(a,b)"
      using card_2_th_92 sorry
    thus "expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b)"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_32:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
proof-
  have " for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    fix b assume [ty]: "b be AlephCARD-5M1"
    have "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
    proof-
      show "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
      proof-
        have cases: "a inTARSKIR2 b or b c=ORDINAL1R1 a"
          using card_1_th_4 sorry
        have case1: "a inTARSKIR2 b implies expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
        proof(rule impI)
          assume A1: "a inTARSKIR2 b"
          then have "a c=ORDINAL1R1 b"
            using card_1_th_3 sorry
          then have A2: "expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b)"
            using card_5_th_31 sorry
          have "nextcardCARD-1K2 a c=ORDINAL1R1 b"
            using A1 card_3_th_90 sorry
          then have "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 expCARD-2K3(\<two>\<^sub>M,b) & nextcardCARD-1K2 a inTARSKIR2 expCARD-2K3(\<two>\<^sub>M,b)"
            using card_5_th_14 card_5_th_31 ordinal1_th_12 sorry
          thus "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
            using A2 card_5_th_18 sorry
        qed
        have case2: "b c=ORDINAL1R1 a implies expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
        proof(rule impI)
          assume A3: "b c=ORDINAL1R1 a"
          let ?f = "\<lambda>Lamb1. FuncsFUNCT-2K1(b,Lamb1)"
          obtain phi where
            [ty]:"phi be SequenceORDINAL1M4" and 
            A4: "domRELAT-1K1 phi =XBOOLE-0R4 nextcardCARD-1K2 a & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 nextcardCARD-1K2 a implies phi .FUNCT-1K1 A =XBOOLE-0R4 ?f(A))"
            using ordinal2_sch_2 sorry
          have A5: "cfCARD-5K1 nextcardCARD-1K2 a =XBOOLE-0R4 nextcardCARD-1K2 a"
            using card_5_th_23 sorry
          have A6: "b inTARSKIR2 nextcardCARD-1K2 a"
            using A3 card_3_th_91 sorry
          have "FuncsFUNCT-2K9(b,nextcardCARD-1K2 a) c=TARSKIR1 UnionCARD-3K3 phi"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(b,nextcardCARD-1K2 a) implies x inHIDDENR3 UnionCARD-3K3 phi"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 FuncsFUNCT-2K9(b,nextcardCARD-1K2 a)"
              then obtain f where
                [ty]:"f be FunctionFUNCT-1M1" and 
                A7: "x =HIDDENR1 f"and A8: "domRELAT-1K1 f =XBOOLE-0R4 b"and A9: "rngFUNCT-1K2 f c=TARSKIR1 nextcardCARD-1K2 a"
                using funct_2_def_2 sorry
              have 
                [ty]:"f be SequenceORDINAL1M4"
                using A8 ordinal1_def_7 sorry
              have 
                [ty]:"f be Ordinal-SequenceORDINAL2M1"
                using A9 ordinal2_def_4 sorry
              have "supORDINAL2K4 f inTARSKIR2 nextcardCARD-1K2 a"
                using A6 A5 A8 A9 card_5_th_27 sorry
              then have A10: "phi .FUNCT-1K1 supORDINAL2K4 f inTARSKIR2 rngFUNCT-1K2 phi"
                using A4 funct_1_def_3 sorry
              have "rngFUNCT-1K2 f c=TARSKIR1 supORDINAL2K4 f"
                using ordinal2_th_49 sorry
              then have A11: "f inTARSKIR2 FuncsFUNCT-2K1(b,supORDINAL2K4 f)"
                using A8 funct_2_def_2 sorry
              have "phi .FUNCT-1K1 supORDINAL2K4 f =XBOOLE-0R4 FuncsFUNCT-2K1(b,supORDINAL2K4 f)"
                using A6 A5 A4 A8 A9 card_5_th_27 sorry
              thus "x inHIDDENR3 UnionCARD-3K3 phi"
                using A7 A11 A10 tarski_def_4 sorry
            qed "sorry"
            thus "FuncsFUNCT-2K9(b,nextcardCARD-1K2 a) c=TARSKIR1 UnionCARD-3K3 phi"
              using tarski_def_3 sorry
          qed
          then have A12: "cardCARD-1K1 (FuncsFUNCT-2K9(b,nextcardCARD-1K2 a)) c=ORDINAL1R1 cardCARD-1K1 (UnionCARD-3K3 phi)"
            using card_1_th_11 sorry
          have "cardCARD-1K1 (FuncsFUNCT-2K9(b,nextcardCARD-1K2 a)) =XBOOLE-0R4 expCARD-2K3(nextcardCARD-1K2 a,b) & cardCARD-1K1 (UnionCARD-3K3 phi) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 phi)"
            using card_2_def_3 card_3_th_39 sorry
          then have A13: "expCARD-2K3(nextcardCARD-1K2 a,b) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 phi)"
            using A12 sorry
          have "a inTARSKIR2 nextcardCARD-1K2 a"
            using card_1_th_18 sorry
          then have A14: "(expCARD-2K3(nextcardCARD-1K2 a,b))*`CARD-2K2 (expCARD-2K3(nextcardCARD-1K2 a,b)) =XBOOLE-0R4 expCARD-2K3(nextcardCARD-1K2 a,b) & expCARD-2K3(a,b) c=ORDINAL1R1 expCARD-2K3(nextcardCARD-1K2 a,b)"
            using card_2_th_92 card_4_th_15 sorry
          have "expCARD-2K3(nextcardCARD-1K2 a,\<one>\<^sub>M) =XBOOLE-0R4 nextcardCARD-1K2 a & \<one>\<^sub>M inTARSKIR2 b"
            using card_5_lm_1 card_5_th_16 card_2_th_27 sorry
          then have "nextcardCARD-1K2 a c=ORDINAL1R1 expCARD-2K3(nextcardCARD-1K2 a,b)"
            using card_2_th_92 sorry
          then have A15: "(expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a c=ORDINAL1R1 expCARD-2K3(nextcardCARD-1K2 a,b)"
            using A14 card_2_th_90 sorry
          have A16: " for x be objectHIDDENM1 holds x inHIDDENR3 nextcardCARD-1K2 a implies CardCARD-3K1 phi .FUNCT-1K1 x c=TARSKIR1 (nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b)).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain xx where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
              using tarski_th_1 sorry
            have A17: "cardCARD-1K1 (cardCARD-1K1 xx) =XBOOLE-0R4 cardCARD-1K1 xx & cardCARD-1K1 b =XBOOLE-0R4 cardCARD-1K1 b"
               sorry
            assume A18: "x inHIDDENR3 nextcardCARD-1K2 a"
            then obtain x9 where 
              [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
               sorry
            have A19: "phi .FUNCT-1K1 x9 =XBOOLE-0R4 FuncsFUNCT-2K1(b,x9)"
              using A4 A18 sorry
            have "cardCARD-1K1 xx inTARSKIR2 nextcardCARD-1K2 a"
              using A18 card_1_th_8 ordinal1_th_12 sorry
            then have "cardCARD-1K1 xx c=ORDINAL1R1 a"
              using card_3_th_91 sorry
            then have "FuncsFUNCT-2K1(b,cardCARD-1K1 xx) c=TARSKIR1 FuncsFUNCT-2K9(b,a)"
              using funct_5_th_56 sorry
            then have A20: "cardCARD-1K1 (FuncsFUNCT-2K1(b,cardCARD-1K1 xx)) c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K9(b,a))"
              using card_1_th_11 sorry
            have A21: "cardCARD-1K1 (FuncsFUNCT-2K9(b,a)) =XBOOLE-0R4 expCARD-2K3(a,b)"
              using card_2_def_3 sorry
            have "(nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b)).FUNCT-1K1 x =XBOOLE-0R4 expCARD-2K3(a,b) & CardCARD-3K1 phi .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (phi .FUNCT-1K1 x)"
              using A4 A18 card_3_def_2 funcop_1_th_7 sorry
            thus "CardCARD-3K1 phi .FUNCT-1K1 x c=TARSKIR1 (nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b)).FUNCT-1K1 x"
              using A19 A17 A20 A21 funct_5_th_61 sorry
          qed "sorry"
          have "domRELAT-1K1 (CardCARD-3K1 phi) =XBOOLE-0R4 domRELAT-1K1 phi & domRELAT-1K1 (nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b)) =XBOOLE-0R4 nextcardCARD-1K2 a"
            using card_3_def_2 funcop_1_th_13 sorry
          then have A22: "SumCARD-3K6 (CardCARD-3K1 phi) c=ORDINAL1R1 SumCARD-3K6 (nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b))"
            using A4 A16 card_3_th_30 sorry
          have "SumCARD-3K6 (nextcardCARD-1K2 a -->FUNCOP-1K7 expCARD-2K3(a,b)) =XBOOLE-0R4 nextcardCARD-1K2 a *`CARD-2K2 (expCARD-2K3(a,b))"
            using card_2_th_65 sorry
          then have "expCARD-2K3(nextcardCARD-1K2 a,b) c=ORDINAL1R1 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
            using A13 A22 sorry
          thus "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
            using A15 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "expCARD-2K3(nextcardCARD-1K2 a,b) =XBOOLE-0R4 (expCARD-2K3(a,b))*`CARD-2K2 nextcardCARD-1K2 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_33:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
proof-
  have " for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    fix b assume [ty]: "b be AlephCARD-5M1"
    let ?X = "{c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
    let ?f = "?X -->FUNCOP-1K7 expCARD-2K3(a,b)"
    have "?X c=TARSKIR1 a"
    proof-
      have "{c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } c=TARSKIR1 a"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } implies x inHIDDENR3 a"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex c be ElementSUBSET-1M1-of a st x =HIDDENR1 c & c be CardinalCARD-1M1"
             sorry
          thus "x inHIDDENR3 a"
             sorry
        qed "sorry"
        thus "{c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } c=TARSKIR1 a"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A1: "?f c=RELAT-1R2 a -->FUNCOP-1K7 expCARD-2K3(a,b)"
      using funct_4_th_4 sorry
    have "SumCARD-3K6 (a -->FUNCOP-1K7 expCARD-2K3(a,b)) =XBOOLE-0R4 a *`CARD-2K2 (expCARD-2K3(a,b))"
      using card_2_th_65 sorry
    then have A2: "SumCARD-3K6 ?f c=ORDINAL1R1 a *`CARD-2K2 (expCARD-2K3(a,b))"
      using A1 card_3_th_33 sorry
    have A3: "domRELAT-1K1 ?f =XBOOLE-0R4 ?X & domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) =XBOOLE-0R4 ?X"
    proof-
      have "domRELAT-1K1 (({c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 })-->FUNCOP-1K7 expCARD-2K3(a,b)) =XBOOLE-0R4 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } & domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) =XBOOLE-0R4 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
      proof(rule conjMI)
        show "domRELAT-1K1 (({c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 })-->FUNCOP-1K7 expCARD-2K3(a,b)) =XBOOLE-0R4 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
          using funcop_1_th_13 sorry
        have "domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) c=TARSKIR1 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } & {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } c=TARSKIR1 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
        proof(rule conjMI)
          show "domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) c=TARSKIR1 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) implies x inHIDDENR3 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
              then have "x inHIDDENR3 a & x be CardinalCARD-1M1"
                using card_5_def_2 sorry
              thus "x inHIDDENR3 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
                 sorry
            qed "sorry"
            thus "domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) c=TARSKIR1 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } implies x inHIDDENR3 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?X"
            then have " ex c be ElementSUBSET-1M1-of a st x =HIDDENR1 c & c be CardinalCARD-1M1"
               sorry
            thus "x inHIDDENR3 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
              using card_5_def_2 sorry
          qed "sorry"
          thus "{c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } c=TARSKIR1 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
            using tarski_def_3 sorry
        qed
        thus "domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) =XBOOLE-0R4 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "\<one>\<^sub>M inTARSKIR2 b & expCARD-2K3(a,\<one>\<^sub>M) =XBOOLE-0R4 a"
      using card_5_lm_1 card_5_th_16 card_2_th_27 sorry
    then have "a c=ORDINAL1R1 expCARD-2K3(a,b)"
      using card_2_th_93 sorry
    then have A4: "a *`CARD-2K2 (expCARD-2K3(a,b)) =XBOOLE-0R4 expCARD-2K3(a,b)"
      using card_5_th_18 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 } implies (b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 x c=TARSKIR1 (({c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 })-->FUNCOP-1K7 expCARD-2K3(a,b)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A5: "x inHIDDENR3 ?X"
      then obtain c where
        [ty]:"c be ElementSUBSET-1M1-of a" and 
        A6: "x =HIDDENR1 c"and A7: "c be CardinalCARD-1M1"
         sorry
      have 
        [ty]:"c be CardinalCARD-1M1"
        using A7 sorry
      have A8: "?f .FUNCT-1K1 x =XBOOLE-0R4 expCARD-2K3(a,b)"
        using A5 funcop_1_th_7 sorry
      have "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 x =XBOOLE-0R4 expCARD-2K3(c,b)"
        using A6 card_5_def_2 sorry
      thus "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 x c=TARSKIR1 (({c where c be ElementSUBSET-1M1-of a : c be CardinalCARD-1M1 })-->FUNCOP-1K7 expCARD-2K3(a,b)).FUNCT-1K1 x"
        using A8 card_2_th_93 sorry
    qed "sorry"
    then have "SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 SumCARD-3K6 ?f"
      using A3 card_3_th_30 sorry
    thus "SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
      using A2 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_34:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a be limit-cardinalCARD-1V2 & b inTARSKIR2 cfCARD-5K1 a implies expCARD-2K3(a,b) =XBOOLE-0R4 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
proof-
  have " for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds a be limit-cardinalCARD-1V2 & b inTARSKIR2 cfCARD-5K1 a implies expCARD-2K3(a,b) =XBOOLE-0R4 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    fix b assume [ty]: "b be AlephCARD-5M1"
    assume A1: "a be limit-cardinalCARD-1V2"
      and A2: "b inTARSKIR2 cfCARD-5K1 a"
    let ?f = "\<lambda>Lamb1. FuncsFUNCT-2K1(b,Lamb1)"
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A3: "domRELAT-1K1 L =XBOOLE-0R4 a & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 a implies L .FUNCT-1K1 A =XBOOLE-0R4 ?f(A))"
      using ordinal2_sch_2 sorry
    have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 a implies CardCARD-3K1 L .FUNCT-1K1 x c=TARSKIR1 (a -->FUNCOP-1K7 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A5: "cardCARD-1K1 (UnionCARD-3K3 (b -powerfunc-ofCARD-5K2 a)) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
        using card_3_th_40 sorry
      assume A6: "x inHIDDENR3 a"
      then obtain x9 where 
        [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
         sorry
      let ?m = "cardCARD-1K1 x9"
      have A7: "?m inTARSKIR2 a"
        using A6 card_1_th_8 ordinal1_th_12 sorry
      then have "?m inTARSKIR2 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
        using card_5_def_2 sorry
      then have A8: "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 cardCARD-1K1 x9 inTARSKIR2 rngFUNCT-1K2 (b -powerfunc-ofCARD-5K2 a)"
        using funct_1_def_3 sorry
      have "(x9,?m)are-equipotentWELLORD2R2"
        using card_1_def_2 sorry
      then have A9: "cardCARD-1K1 (FuncsFUNCT-2K1(b,x9)) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K1(b,cardCARD-1K1 x9))"
        using funct_5_th_60 sorry
      have "L .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(b,x9) & CardCARD-3K1 L .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (L .FUNCT-1K1 x)"
        using A3 A6 card_3_def_2 sorry
      then have A10: "CardCARD-3K1 L .FUNCT-1K1 x =XBOOLE-0R4 expCARD-2K3(?m,b)"
        using A9 card_2_def_3 sorry
      have "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 cardCARD-1K1 x9 =XBOOLE-0R4 expCARD-2K3(cardCARD-1K1 x9,b)"
        using A7 card_5_def_2 sorry
      then have "cardCARD-1K1 (expCARD-2K3(cardCARD-1K1 x9,b)) c=ORDINAL1R1 cardCARD-1K1 (UnionCARD-3K3 (b -powerfunc-ofCARD-5K2 a))"
        using A8 card_1_th_11 zfmisc_1_th_74 sorry
      then have A11: "cardCARD-1K1 (expCARD-2K3(cardCARD-1K1 x9,b)) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
        using A5 sorry
      show "CardCARD-3K1 L .FUNCT-1K1 x c=TARSKIR1 (a -->FUNCOP-1K7 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)).FUNCT-1K1 x"
        using A6 A10 A11 funcop_1_th_7 sorry
    qed "sorry"
    have "domRELAT-1K1 (a -->FUNCOP-1K7 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)) =XBOOLE-0R4 a & domRELAT-1K1 (CardCARD-3K1 L) =XBOOLE-0R4 domRELAT-1K1 L"
      using card_3_def_2 funcop_1_th_13 sorry
    then have A12: "SumCARD-3K6 (CardCARD-3K1 L) c=ORDINAL1R1 SumCARD-3K6 (a -->FUNCOP-1K7 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a))"
      using A3 A4 card_3_th_30 sorry
    have "a c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
    proof-
      have " for x be OrdinalORDINAL1M3 holds x inTARSKIR2 a implies x inTARSKIR2 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be OrdinalORDINAL1M3"
        obtain xx where 
          [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
           sorry
        assume A13: "x inTARSKIR2 a"
        obtain x9 where 
          [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
           sorry
        let ?m = "cardCARD-1K1 x9"
        have "?m inTARSKIR2 a"
          using A13 card_1_th_8 ordinal1_th_12 sorry
        then have A14: "nextcardCARD-1K2 ?m c=ORDINAL1R1 a"
          using card_3_th_90 sorry
        have "nextcardCARD-1K2 ?m <>HIDDENR2 a"
          using A1 sorry
        then have A15: "nextcardCARD-1K2 ?m inTARSKIR2 a"
          using A14 card_1_th_3 sorry
        then have "nextcardCARD-1K2 ?m inTARSKIR2 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
          using card_5_def_2 sorry
        then have A16: "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 nextcardCARD-1K2 ?m inTARSKIR2 rngFUNCT-1K2 (b -powerfunc-ofCARD-5K2 a)"
          using funct_1_def_3 sorry
        have "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 nextcardCARD-1K2 ?m =XBOOLE-0R4 expCARD-2K3(nextcardCARD-1K2 ?m,b)"
          using A15 card_5_def_2 sorry
        then have A17: "cardCARD-1K1 (expCARD-2K3(nextcardCARD-1K2 ?m,b)) c=ORDINAL1R1 cardCARD-1K1 (UnionCARD-3K3 (b -powerfunc-ofCARD-5K2 a))"
          using A16 card_1_th_11 zfmisc_1_th_74 sorry
        have A18: "nextcardCARD-1K2 ?m c=ORDINAL1R1 expCARD-2K3(nextcardCARD-1K2 ?m,b)"
          using card_5_th_20 sorry
        have "cardCARD-1K1 xx =XBOOLE-0R4 cardCARD-1K1 (cardCARD-1K1 xx)"
           sorry
        then have A19: "x9 inTARSKIR2 nextcardCARD-1K2 x9 & nextcardCARD-1K2 (cardCARD-1K1 xx) =XBOOLE-0R4 nextcardCARD-1K2 xx"
          using card_1_th_18 card_3_th_88 sorry
        have "cardCARD-1K1 (expCARD-2K3(nextcardCARD-1K2 ?m,b)) =XBOOLE-0R4 expCARD-2K3(nextcardCARD-1K2 ?m,b) & cardCARD-1K1 (UnionCARD-3K3 (b -powerfunc-ofCARD-5K2 a)) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
          using card_3_th_40 sorry
        then have "expCARD-2K3(nextcardCARD-1K2 ?m,b) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
          using A17 sorry
        then have "nextcardCARD-1K2 (cardCARD-1K1 xx) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
          using A18 sorry
        thus "x inTARSKIR2 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
          using A19 sorry
      qed "sorry"
      thus "a c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
        using ordinal1_def_5 sorry
    qed
    then have A20: "a *`CARD-2K2 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) =XBOOLE-0R4 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      using card_5_th_18 sorry
    have "FuncsFUNCT-2K9(b,a) c=TARSKIR1 UnionCARD-3K3 L"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(b,a) implies x inHIDDENR3 UnionCARD-3K3 L"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 FuncsFUNCT-2K9(b,a)"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A21: "x =HIDDENR1 f"and A22: "domRELAT-1K1 f =XBOOLE-0R4 b"and A23: "rngFUNCT-1K2 f c=TARSKIR1 a"
          using funct_2_def_2 sorry
        have 
          [ty]:"f be SequenceORDINAL1M4"
          using A22 ordinal1_def_7 sorry
        have 
          [ty]:"f be Ordinal-SequenceORDINAL2M1"
          using A23 ordinal2_def_4 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 supORDINAL2K4 f"
          using ordinal2_th_49 sorry
        then have A24: "x inHIDDENR3 FuncsFUNCT-2K1(b,supORDINAL2K4 f)"
          using A21 A22 funct_2_def_2 sorry
        have "supORDINAL2K4 f inTARSKIR2 a"
          using A2 A22 A23 card_5_th_27 sorry
        then have A25: "L .FUNCT-1K1 supORDINAL2K4 f inTARSKIR2 rngFUNCT-1K2 L"
          using A3 funct_1_def_3 sorry
        have "L .FUNCT-1K1 supORDINAL2K4 f =XBOOLE-0R4 FuncsFUNCT-2K1(b,supORDINAL2K4 f)"
          using A2 A3 A22 A23 card_5_th_27 sorry
        thus "x inHIDDENR3 UnionCARD-3K3 L"
          using A24 A25 tarski_def_4 sorry
      qed "sorry"
      thus "FuncsFUNCT-2K9(b,a) c=TARSKIR1 UnionCARD-3K3 L"
        using tarski_def_3 sorry
    qed
    then have A26: "cardCARD-1K1 (FuncsFUNCT-2K9(b,a)) c=ORDINAL1R1 cardCARD-1K1 (UnionCARD-3K3 L)"
      using card_1_th_11 sorry
    have "cardCARD-1K1 (UnionCARD-3K3 L) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 L)"
      using card_3_th_39 sorry
    then have "cardCARD-1K1 (FuncsFUNCT-2K9(b,a)) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 L)"
      using A26 sorry
    then have A27: "expCARD-2K3(a,b) c=ORDINAL1R1 SumCARD-3K6 (CardCARD-3K1 L)"
      using card_2_def_3 sorry
    have A28: "SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
      using card_5_th_33 sorry
    have "SumCARD-3K6 (a -->FUNCOP-1K7 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)) =XBOOLE-0R4 a *`CARD-2K2 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      using card_2_th_65 sorry
    then have "expCARD-2K3(a,b) c=ORDINAL1R1 a *`CARD-2K2 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      using A27 A12 sorry
    thus "expCARD-2K3(a,b) =XBOOLE-0R4 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      using A28 A20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_35:
" for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds cfCARD-5K1 a c=ORDINAL1R1 b & b inTARSKIR2 a implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
proof-
  have " for a be AlephCARD-5M1 holds  for b be AlephCARD-5M1 holds cfCARD-5K1 a c=ORDINAL1R1 b & b inTARSKIR2 a implies expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be AlephCARD-5M1"
    fix b assume [ty]: "b be AlephCARD-5M1"
    assume A1: "cfCARD-5K1 a c=ORDINAL1R1 b"
      and A2: "b inTARSKIR2 a"
    obtain phi where
      [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
      A3: "domRELAT-1K1 phi =XBOOLE-0R4 cfCARD-5K1 a"and A4: "rngFUNCT-1K2 phi c=TARSKIR1 a"and "phi be increasingORDINAL2V2"and A5: "a =XBOOLE-0R4 supORDINAL2K4 phi"and A6: "phi be Cardinal-FunctionCARD-3M1"and A7: " not 0NUMBERSK6 inTARSKIR2 rngFUNCT-1K2 phi"
      using A1 A2 card_5_th_29 ordinal1_th_12 sorry
    let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  ex g be FunctionFUNCT-1M1 st  ex h be FunctionFUNCT-1M1 st ((((g =HIDDENR1 Lamb1 & h =HIDDENR1 Lamb2) & domRELAT-1K1 g =XBOOLE-0R4 b) & rngFUNCT-1K2 g c=TARSKIR1 a) & domRELAT-1K1 h =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds y inHIDDENR3 cfCARD-5K1 a implies ( ex fx be FunctionFUNCT-1M1 st (h .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y implies fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) & ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))"
    have A8: " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(b,a) implies ( ex x1 be objectHIDDENM1 st ?R(x,x1))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(b,a) implies ( ex tVar20 be objectHIDDENM1 st  ex tVar21 be FunctionFUNCT-1M1 st  ex tVar22 be FunctionFUNCT-1M1 st ((((tVar21 =HIDDENR1 x & tVar22 =HIDDENR1 tVar22) & domRELAT-1K1 tVar21 =XBOOLE-0R4 b) & rngFUNCT-1K2 tVar21 c=TARSKIR1 a) & domRELAT-1K1 tVar22 =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 cfCARD-5K1 a & ( for fx be FunctionFUNCT-1M1 holds  not ((tVar22 .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 tVar21 .FUNCT-1K1 z) &  not ( not tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)))))))))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 FuncsFUNCT-2K9(b,a)"
        then obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A9: "(x =HIDDENR1 g & domRELAT-1K1 g =XBOOLE-0R4 b) & rngFUNCT-1K2 g c=TARSKIR1 a"
          using funct_2_def_2 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex fx be FunctionFUNCT-1M1 st (Lamb2 =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 Lamb1 ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 Lamb1 implies fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) & ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 Lamb1 implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))"
        have A10: " for y be objectHIDDENM1 holds y inHIDDENR3 cfCARD-5K1 a implies ( ex x2 be objectHIDDENM1 st ?P(y,x2))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 cfCARD-5K1 a implies ( ex tVar18 be objectHIDDENM1 st  ex tVar19 be FunctionFUNCT-1M1 st ([TARSKIK4 tVar19,phi .FUNCT-1K1 y ] =HIDDENR1 [TARSKIK4 tVar19,phi .FUNCT-1K1 y ] & domRELAT-1K1 tVar19 =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)))))"
          proof(rule ballI,rule impI)
            let ?g = "\<lambda>Lamb1. 0NUMBERSK6"
            let ?f = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 cfCARD-5K1 a"
            let ?C = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1 inTARSKIR2 phi .FUNCT-1K1 y"
            obtain fx where
              [ty]:"fx be FunctionFUNCT-1M1" and 
              A11: "domRELAT-1K1 fx =XBOOLE-0R4 b & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (?C(z) implies fx .FUNCT-1K1 z =XBOOLE-0R4 ?f(z)) & ( not ?C(z) implies fx .FUNCT-1K1 z =XBOOLE-0R4 ?g(z)))"
              using partfun1_sch_1 sorry
            show " ex tVar18 be objectHIDDENM1 st  ex tVar19 be FunctionFUNCT-1M1 st ([TARSKIK4 tVar19,phi .FUNCT-1K1 y ] =HIDDENR1 [TARSKIK4 tVar19,phi .FUNCT-1K1 y ] & domRELAT-1K1 tVar19 =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))"
            proof(rule bexI[of _ "[TARSKIK4 fx,phi .FUNCT-1K1 y ]"])
              show " ex tVar19 be FunctionFUNCT-1M1 st ([TARSKIK4 tVar19,phi .FUNCT-1K1 y ] =HIDDENR1 [TARSKIK4 tVar19,phi .FUNCT-1K1 y ] & domRELAT-1K1 tVar19 =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not tVar19 .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))"
              proof(rule bexI[of _ "fx"])
                show "([TARSKIK4 fx,phi .FUNCT-1K1 y ] =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))"
                  using A11 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A12: "domRELAT-1K1 h =XBOOLE-0R4 cfCARD-5K1 a & ( for y be objectHIDDENM1 holds y inHIDDENR3 cfCARD-5K1 a implies ?P(y,h .FUNCT-1K1 y))"
          using classes1_sch_1 A10 sorry
        show " ex tVar20 be objectHIDDENM1 st  ex tVar21 be FunctionFUNCT-1M1 st  ex tVar22 be FunctionFUNCT-1M1 st ((((tVar21 =HIDDENR1 x & tVar22 =HIDDENR1 tVar22) & domRELAT-1K1 tVar21 =XBOOLE-0R4 b) & rngFUNCT-1K2 tVar21 c=TARSKIR1 a) & domRELAT-1K1 tVar22 =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 cfCARD-5K1 a & ( for fx be FunctionFUNCT-1M1 holds  not ((tVar22 .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 tVar21 .FUNCT-1K1 z) &  not ( not tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))))))"
        proof(rule bexI[of _ "h"])
          show " ex tVar21 be FunctionFUNCT-1M1 st  ex tVar22 be FunctionFUNCT-1M1 st ((((tVar21 =HIDDENR1 x & tVar22 =HIDDENR1 tVar22) & domRELAT-1K1 tVar21 =XBOOLE-0R4 b) & rngFUNCT-1K2 tVar21 c=TARSKIR1 a) & domRELAT-1K1 tVar22 =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 cfCARD-5K1 a & ( for fx be FunctionFUNCT-1M1 holds  not ((tVar22 .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 tVar21 .FUNCT-1K1 z) &  not ( not tVar21 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))))))"
          proof(rule bexI[of _ "g"])
            show " ex tVar22 be FunctionFUNCT-1M1 st ((((g =HIDDENR1 x & tVar22 =HIDDENR1 tVar22) & domRELAT-1K1 g =XBOOLE-0R4 b) & rngFUNCT-1K2 g c=TARSKIR1 a) & domRELAT-1K1 tVar22 =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 cfCARD-5K1 a & ( for fx be FunctionFUNCT-1M1 holds  not ((tVar22 .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))))))"
            proof(rule bexI[of _ "h"])
              show "((((g =HIDDENR1 x & h =HIDDENR1 h) & domRELAT-1K1 g =XBOOLE-0R4 b) & rngFUNCT-1K2 g c=TARSKIR1 a) & domRELAT-1K1 h =XBOOLE-0R4 cfCARD-5K1 a) & ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 cfCARD-5K1 a & ( for fx be FunctionFUNCT-1M1 holds  not ((h .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds  not (z inHIDDENR3 b &  not ( not (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) &  not ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y &  not fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6))))))))"
                using A9 A12 sorry
            qed "sorry"
          qed "sorry"
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A13: "domRELAT-1K1 f =XBOOLE-0R4 FuncsFUNCT-2K9(b,a) & ( for x be objectHIDDENM1 holds x inHIDDENR3 FuncsFUNCT-2K9(b,a) implies ?R(x,f .FUNCT-1K1 x))"
      using classes1_sch_1 A8 sorry
    let ?f = "\<lambda>Lamb1. FuncsFUNCT-2K1(b,Lamb1)"
    obtain F where
      [ty]:"F be FunctionFUNCT-1M1" and 
      A14: "domRELAT-1K1 F =XBOOLE-0R4 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) & ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a) implies F .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_5 sorry
    have A15: "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A16: "x inHIDDENR3 domRELAT-1K1 f"and A17: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        obtain g h where
          [ty]:"g be FunctionFUNCT-1M1" "h be FunctionFUNCT-1M1" and 
          "g =HIDDENR1 x"and A18: "h =XBOOLE-0R4 f .FUNCT-1K1 x"and "domRELAT-1K1 g =XBOOLE-0R4 b"and "rngFUNCT-1K2 g c=TARSKIR1 a"and A19: "domRELAT-1K1 h =XBOOLE-0R4 cfCARD-5K1 a"and A20: " for y be objectHIDDENM1 holds y inHIDDENR3 cfCARD-5K1 a implies ( ex fx be FunctionFUNCT-1M1 st (h .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 y ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y implies fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) & ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 y implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)))"
          using A13 A16 sorry
        have "rngFUNCT-1K2 h c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 F"
        proof-
          have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 rngFUNCT-1K2 h implies x1 inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F"
          proof(rule ballI,rule impI)
            fix x1 assume [ty]: "x1 be objectHIDDENM1"
            assume "x1 inHIDDENR3 rngFUNCT-1K2 h"
            then obtain x2 where
              [ty]:"x2 be objectHIDDENM1" and 
              A21: "x2 inHIDDENR3 domRELAT-1K1 h"and A22: "x1 =HIDDENR1 h .FUNCT-1K1 x2"
              using funct_1_def_3 sorry
            obtain fx where
              [ty]:"fx be FunctionFUNCT-1M1" and 
              A23: "x1 =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 x2 ]"and A24: "domRELAT-1K1 fx =XBOOLE-0R4 b"and A25: " for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies fx .FUNCT-1K1 z =XBOOLE-0R4 g .FUNCT-1K1 z) & ( not g .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)"
              using A19 A20 A21 A22 sorry
            have "rngFUNCT-1K2 fx c=TARSKIR1 phi .FUNCT-1K1 x2"
            proof-
              have 
                [ty]:"x2 be OrdinalORDINAL1M3"
                using A19 A21 sorry
              have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 fx implies z inHIDDENR3 phi .FUNCT-1K1 x2"
              proof(rule ballI,rule impI)
                fix z assume [ty]: "z be objectHIDDENM1"
                obtain A where 
                  [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = phi .FUNCT-1K1 x2"
                   sorry
                assume "z inHIDDENR3 rngFUNCT-1K2 fx"
                then obtain z9 where
                  [ty]:"z9 be objectHIDDENM1" and 
                  A26: "z9 inHIDDENR3 domRELAT-1K1 fx & z =HIDDENR1 fx .FUNCT-1K1 z9"
                  using funct_1_def_3 sorry
                have A27: "z =HIDDENR1 g .FUNCT-1K1 z9 & g .FUNCT-1K1 z9 inTARSKIR2 phi .FUNCT-1K1 x2 or z =HIDDENR1 0NUMBERSK6"
                  using A24 A25 A26 sorry
                have "A <>HIDDENR2 0NUMBERSK6"
                  using A3 A7 A19 A21 funct_1_def_3 sorry
                thus "z inHIDDENR3 phi .FUNCT-1K1 x2"
                  using A27 ordinal3_th_8 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 fx c=TARSKIR1 phi .FUNCT-1K1 x2"
                using tarski_def_3 sorry
            qed
            then have A28: "fx inTARSKIR2 FuncsFUNCT-2K1(b,phi .FUNCT-1K1 x2)"
              using A24 funct_2_def_2 sorry
            have A29: "[TARSKIK4 fx,phi .FUNCT-1K1 x2 ] `1XTUPLE-0K1 =HIDDENR1 fx & [TARSKIK4 fx,phi .FUNCT-1K1 x2 ] `2XTUPLE-0K2 =HIDDENR1 phi .FUNCT-1K1 x2"
               sorry
            have "phi .FUNCT-1K1 x2 inTARSKIR2 rngFUNCT-1K2 phi & phi .FUNCT-1K1 x2 be CardinalCARD-1M1"
              using A3 A6 A19 A21 card_3_def_1 funct_1_def_3 sorry
            then have A30: "phi .FUNCT-1K1 x2 inTARSKIR2 domRELAT-1K1 (b -powerfunc-ofCARD-5K2 a)"
              using A4 card_5_def_2 sorry
            then have "F .FUNCT-1K1 (phi .FUNCT-1K1 x2) =XBOOLE-0R4 FuncsFUNCT-2K1(b,phi .FUNCT-1K1 x2)"
              using A14 sorry
            thus "x1 inHIDDENR3 UnionCARD-3K3 disjoinCARD-3K2 F"
              using A14 A23 A28 A30 A29 card_3_th_22 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 h c=TARSKIR1 UnionCARD-3K3 disjoinCARD-3K2 F"
            using tarski_def_3 sorry
        qed
        thus "y inHIDDENR3 FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)"
          using A17 A18 A19 funct_2_def_2 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)"
        using tarski_def_3 sorry
    qed
    have "cardCARD-1K1 (cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F)) =XBOOLE-0R4 cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F) & cardCARD-1K1 (cfCARD-5K1 a) =XBOOLE-0R4 cfCARD-5K1 a"
       sorry
    then have A31: "cardCARD-1K1 (FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)) =HIDDENR1 cardCARD-1K1 (FuncsFUNCT-2K1(cfCARD-5K1 a,cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F)))"
      using funct_5_th_61 sorry
    also have "... = expCARD-2K3(cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F),cfCARD-5K1 a)"
      using card_2_def_3 sorry
    finally have "cardCARD-1K1 (FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F)) =HIDDENR1 expCARD-2K3(cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F),cfCARD-5K1 a)"
       sorry
    have A32: "domRELAT-1K1 (CardCARD-3K1 F) =XBOOLE-0R4 domRELAT-1K1 F"
      using card_3_def_2 sorry
    have A33: "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y) implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A34: "x inHIDDENR3 domRELAT-1K1 f"
          and A35: "y inHIDDENR3 domRELAT-1K1 f"
          and A36: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        obtain g1 h1 where
          [ty]:"g1 be FunctionFUNCT-1M1" "h1 be FunctionFUNCT-1M1" and 
          A37: "g1 =HIDDENR1 x"and A38: "h1 =XBOOLE-0R4 f .FUNCT-1K1 x"and A39: "domRELAT-1K1 g1 =XBOOLE-0R4 b"and A40: "rngFUNCT-1K2 g1 c=TARSKIR1 a"and "domRELAT-1K1 h1 =XBOOLE-0R4 cfCARD-5K1 a"and A41: " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 cfCARD-5K1 a implies ( ex fx be FunctionFUNCT-1M1 st (h1 .FUNCT-1K1 x1 =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 x1 ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g1 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x1 implies fx .FUNCT-1K1 z =XBOOLE-0R4 g1 .FUNCT-1K1 z) & ( not g1 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x1 implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)))"
          using A13 A34 sorry
        obtain g2 h2 where
          [ty]:"g2 be FunctionFUNCT-1M1" "h2 be FunctionFUNCT-1M1" and 
          A42: "g2 =HIDDENR1 y"and A43: "h2 =XBOOLE-0R4 f .FUNCT-1K1 y"and A44: "domRELAT-1K1 g2 =XBOOLE-0R4 b"and A45: "rngFUNCT-1K2 g2 c=TARSKIR1 a"and "domRELAT-1K1 h2 =XBOOLE-0R4 cfCARD-5K1 a"and A46: " for x2 be objectHIDDENM1 holds x2 inHIDDENR3 cfCARD-5K1 a implies ( ex fx be FunctionFUNCT-1M1 st (h2 .FUNCT-1K1 x2 =HIDDENR1 [TARSKIK4 fx,phi .FUNCT-1K1 x2 ] & domRELAT-1K1 fx =XBOOLE-0R4 b) & ( for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g2 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies fx .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z) & ( not g2 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies fx .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)))"
          using A13 A35 sorry
        have " for x1 be objectHIDDENM1 holds x1 inHIDDENR3 b implies g1 .FUNCT-1K1 x1 =XBOOLE-0R4 g2 .FUNCT-1K1 x1"
        proof(rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          assume "x1 inHIDDENR3 b"
          then obtain X where 
            [ty]:"X be ElementSUBSET-1M1-of b" and XDef:"X = x1"
             sorry
          have "g1 .FUNCT-1K1 X inTARSKIR2 rngFUNCT-1K2 g1 & g2 .FUNCT-1K1 X inTARSKIR2 rngFUNCT-1K2 g2"
            using A39 A44 funct_1_def_3 sorry
          then obtain A1 A2 where 
            [ty]:"A1 be ElementSUBSET-1M1-of a" and A1Def:"A1 = g1 .FUNCT-1K1 x1" and
            [ty]:"A2 be ElementSUBSET-1M1-of a" and A2Def:"A2 = g2 .FUNCT-1K1 x1"
            using A40 A45 sorry
          let ?A = "A1 \\/XBOOLE-0K2 A2"
          have "?A =XBOOLE-0R4 A1 or ?A =XBOOLE-0R4 A2"
            using ordinal3_th_12 sorry
          then have "succORDINAL1K1 ?A inTARSKIR2 a"
            using ordinal1_th_28 sorry
          then obtain B where
            [ty]:"B be OrdinalORDINAL1M3" and 
            A47: "B inTARSKIR2 rngFUNCT-1K2 phi"and A48: "succORDINAL1K1 ?A c=ORDINAL1R1 B"
            using A5 ordinal2_th_21 sorry
          obtain x2 where
            [ty]:"x2 be objectHIDDENM1" and 
            A49: "x2 inHIDDENR3 domRELAT-1K1 phi"and A50: "B =XBOOLE-0R4 phi .FUNCT-1K1 x2"
            using A47 funct_1_def_3 sorry
          have A51: "?A inTARSKIR2 succORDINAL1K1 ?A"
            using ordinal1_th_6 sorry
          then have A52: "A2 inTARSKIR2 B"
            using A48 ordinal1_th_12 xboole_1_th_7 sorry
          obtain f1 where
            [ty]:"f1 be FunctionFUNCT-1M1" and 
            A53: "h1 .FUNCT-1K1 x2 =HIDDENR1 [TARSKIK4 f1,phi .FUNCT-1K1 x2 ]"and "domRELAT-1K1 f1 =XBOOLE-0R4 b"and A54: " for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g1 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies f1 .FUNCT-1K1 z =XBOOLE-0R4 g1 .FUNCT-1K1 z) & ( not g1 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies f1 .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)"
            using A3 A41 A49 sorry
          have "A1 inTARSKIR2 B"
            using A48 A51 ordinal1_th_12 xboole_1_th_7 sorry
          then have A55: "f1 .FUNCT-1K1 X =XBOOLE-0R4 g1 .FUNCT-1K1 x1"
            using A50 A54 sorry
          obtain f2 where
            [ty]:"f2 be FunctionFUNCT-1M1" and 
            A56: "h2 .FUNCT-1K1 x2 =HIDDENR1 [TARSKIK4 f2,phi .FUNCT-1K1 x2 ]"and "domRELAT-1K1 f2 =XBOOLE-0R4 b"and A57: " for z be objectHIDDENM1 holds z inHIDDENR3 b implies (g2 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies f2 .FUNCT-1K1 z =XBOOLE-0R4 g2 .FUNCT-1K1 z) & ( not g2 .FUNCT-1K1 z inTARSKIR2 phi .FUNCT-1K1 x2 implies f2 .FUNCT-1K1 z =XBOOLE-0R4 0NUMBERSK6)"
            using A3 A46 A49 sorry
          have "f1 =FUNCT-1R1 f2"
            using A36 A38 A43 A53 A56 xtuple_0_th_1 sorry
          thus "g1 .FUNCT-1K1 x1 =XBOOLE-0R4 g2 .FUNCT-1K1 x1"
            using A50 A57 A52 A55 sorry
        qed "sorry"
        thus "x =HIDDENR1 y"
          using A37 A39 A42 A44 funct_1_th_2 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    have A58: "domRELAT-1K1 (disjoinCARD-3K2 F) =XBOOLE-0R4 domRELAT-1K1 F"
      using card_3_def_3 sorry
    have A59: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies CardCARD-3K1 (disjoinCARD-3K2 F) .FUNCT-1K1 x =XBOOLE-0R4 CardCARD-3K1 F .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A60: "x inHIDDENR3 domRELAT-1K1 F"
      then have A61: "disjoinCARD-3K2 F .FUNCT-1K1 x =XBOOLE-0R4 [:ZFMISC-1K2 F .FUNCT-1K1 x,{TARSKIK1 x} :]"
        using card_3_def_3 sorry
      have "CardCARD-3K1 F .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (F .FUNCT-1K1 x) & CardCARD-3K1 (disjoinCARD-3K2 F) .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (disjoinCARD-3K2 F .FUNCT-1K1 x)"
        using A58 A60 card_3_def_2 sorry
      thus "CardCARD-3K1 (disjoinCARD-3K2 F) .FUNCT-1K1 x =XBOOLE-0R4 CardCARD-3K1 F .FUNCT-1K1 x"
        using A61 card_1_th_69 sorry
    qed "sorry"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 F implies CardCARD-3K1 F .FUNCT-1K1 x =XBOOLE-0R4 (b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A62: "x inHIDDENR3 domRELAT-1K1 F"
      then obtain M where 
        [ty]:"M be CardinalCARD-1M1" and MDef:"M = x"
        using A14 card_5_def_2 sorry
      have "M inTARSKIR2 a"
        using A14 A62 card_5_def_2 sorry
      then have A63: "(b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 M =XBOOLE-0R4 expCARD-2K3(M,b)"
        using card_5_def_2 sorry
      obtain xx where 
        [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
        using tarski_th_1 sorry
      have "CardCARD-3K1 F .FUNCT-1K1 x =XBOOLE-0R4 cardCARD-1K1 (F .FUNCT-1K1 x) & F .FUNCT-1K1 x =XBOOLE-0R4 FuncsFUNCT-2K1(b,xx)"
        using A14 A62 card_3_def_2 sorry
      thus "CardCARD-3K1 F .FUNCT-1K1 x =XBOOLE-0R4 (b -powerfunc-ofCARD-5K2 a).FUNCT-1K1 x"
        using A63 card_2_def_3 sorry
    qed "sorry"
    then have A64: "CardCARD-3K1 F =FUNCT-1R1 b -powerfunc-ofCARD-5K2 a"
      using A14 A32 sorry
    have "domRELAT-1K1 (CardCARD-3K1 (disjoinCARD-3K2 F)) =XBOOLE-0R4 domRELAT-1K1 (disjoinCARD-3K2 F)"
      using card_3_def_2 sorry
    then have "CardCARD-3K1 F =FUNCT-1R1 CardCARD-3K1 (disjoinCARD-3K2 F)"
      using A58 A32 A59 sorry
    then have "cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F) c=ORDINAL1R1 SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a)"
      using A64 card_3_th_39 sorry
    then have A65: "expCARD-2K3(cardCARD-1K1 (UnionCARD-3K3 disjoinCARD-3K2 F),cfCARD-5K1 a) c=ORDINAL1R1 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
      using card_2_th_93 sorry
    have "expCARD-2K3(a,b) =XBOOLE-0R4 cardCARD-1K1 (FuncsFUNCT-2K9(b,a))"
      using card_2_def_3 sorry
    then have "expCARD-2K3(a,b) c=ORDINAL1R1 cardCARD-1K1 (FuncsFUNCT-2K1(cfCARD-5K1 a,UnionCARD-3K3 disjoinCARD-3K2 F))"
      using A13 A33 A15 card_1_th_10 sorry
    then have A66: "expCARD-2K3(expCARD-2K3(a,b),cfCARD-5K1 a) =XBOOLE-0R4 expCARD-2K3(a,b *`CARD-2K2 (cfCARD-5K1 a)) & expCARD-2K3(a,b) c=ORDINAL1R1 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
      using A31 A65 card_2_th_30 sorry
    have "SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a) c=ORDINAL1R1 expCARD-2K3(a,b)"
      using card_5_th_33 sorry
    then have A67: "expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a) c=ORDINAL1R1 expCARD-2K3(expCARD-2K3(a,b),cfCARD-5K1 a)"
      using card_2_th_93 sorry
    have "b *`CARD-2K2 (cfCARD-5K1 a) =XBOOLE-0R4 b"
      using A1 card_5_th_18 sorry
    thus "expCARD-2K3(a,b) =XBOOLE-0R4 expCARD-2K3(SumCARD-3K6 (b -powerfunc-ofCARD-5K2 a),cfCARD-5K1 a)"
      using A67 A66 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve O for "OrdinalORDINAL1M3"
reserve F for "SubsetSUBSET-1M2-of omegaORDINAL1K4"
mlemma card_5_lm_4:
" for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X be finiteFINSET-1V1"
proof-
  have " for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X be finiteFINSET-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix O assume [ty]: "O be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume "X c=TARSKIR1 O"
    then have "RelInclWELLORD2K1 X be well-orderingWELLORD1V2"
      using wellord2_th_8 sorry
    then have "(RelInclWELLORD2K1 X,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X))are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X be finiteFINSET-1V1"
      using card_3_th_105 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_36:
" for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X =XBOOLE-0R4 cardCARD-1K4 X"
proof-
  have " for O be OrdinalORDINAL1M3 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds X c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 X =XBOOLE-0R4 cardCARD-1K4 X"
  proof(rule ballI,rule ballI,rule impI)
    fix O assume [ty]: "O be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A1: "X c=TARSKIR1 O"
    then have "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X be finiteFINSET-1V1"
      using card_5_lm_4 sorry
    then obtain o where 
      [ty]:"o be NatNAT-1M1" and oDef:"o = order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"
       sorry
    have "cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X)"
      using A1 card_5_th_7 sorry
    then have "o =XBOOLE-0R4 cardCARD-1K4 X"
       sorry
    thus "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X =XBOOLE-0R4 cardCARD-1K4 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_37:
" for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds {TARSKIK1 x} c=TARSKIR1 O implies order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds  not ({TARSKIK1 x} c=TARSKIR1 O &  not order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix O assume [ty]: "O be OrdinalORDINAL1M3"
    have "cardCARD-1K4 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
      using card_2_th_42 sorry
    thus " not ({TARSKIK1 x} c=TARSKIR1 O &  not order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M)"
      using card_5_th_36 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_th_38:
" for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds {TARSKIK1 x} c=TARSKIR1 O implies canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x}),RelInclWELLORD2K1 {TARSKIK1 x}) =FUNCT-1R1 (0NUMBERSK6).-->FUNCOP-1K17 x"
proof-
  have " for x be objectHIDDENM1 holds  for O be OrdinalORDINAL1M3 holds {TARSKIK1 x} c=TARSKIR1 O implies canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x}),RelInclWELLORD2K1 {TARSKIK1 x}) =FUNCT-1R1 (0NUMBERSK6).-->FUNCOP-1K17 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix O assume [ty]: "O be OrdinalORDINAL1M3"
    let ?X = "{TARSKIK1 x}"
    let ?R = "RelInclWELLORD2K1 ?X"
    let ?C = "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 ?R),?R)"
    have A1: "RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
      using wellord2_th_22 sorry
    assume A2: "?X c=TARSKIR1 O"
    then have A3: "order-type-ofWELLORD2K2 ?R =XBOOLE-0R4 {TARSKIK1 0NUMBERSK6 }"
      using card_5_th_37 card_1_th_49 sorry
    have "?R be well-orderingWELLORD1V2"
      using A2 wellord2_th_8 sorry
    then have "(?R,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 ?R))are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    then have A4: "(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 ?R),?R)are-isomorphicWELLORD1R4"
      using wellord1_th_40 sorry
    have "RelInclWELLORD2K1 (order-type-ofWELLORD2K2 ?R) be well-orderingWELLORD1V2"
      using wellord2_th_8 sorry
    then have A5: "?C is-isomorphism-ofWELLORD1R3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 ?R),?R)"
      using A4 wellord1_def_9 sorry
    then have A6: "rngFUNCT-1K2 (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 },?R)) =HIDDENR1 fieldRELAT-1K3 ?R"
      using A3 wellord1_def_7 sorry
    also have "... = ?X"
      using wellord2_def_1 sorry
    finally have "rngFUNCT-1K2 (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 },?R)) =HIDDENR1 ?X"
       sorry
    have "domRELAT-1K1 (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 },?R)) =HIDDENR1 fieldRELAT-1K3 (RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 })"
      using A5 A3 wellord1_def_7 sorry
    also have "... = {TARSKIK1 0NUMBERSK6 }"
      using A1 relat_1_th_173 sorry
    finally have "domRELAT-1K1 (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 {TARSKIK1 0NUMBERSK6 },?R)) =HIDDENR1 {TARSKIK1 0NUMBERSK6 }"
       sorry
    thus "canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 {TARSKIK1 x}),RelInclWELLORD2K1 {TARSKIK1 x}) =FUNCT-1R1 (0NUMBERSK6).-->FUNCOP-1K17 x"
      using A3 A6 funct_4_th_112 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_5_cl_11:
  mlet "O be OrdinalORDINAL1M3", "X be SubsetSUBSET-1M2-of O", "n be setHIDDENM2"
"cluster (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
  proof-
    obtain phi where
      [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
      A1: "phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)"and "phi be increasingORDINAL2V2"and "domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"and "rngFUNCT-1K2 phi =XBOOLE-0R4 X"
      using card_5_th_5 sorry
    show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
    proof-
      have cases: "n inTARSKIR2 domRELAT-1K1 phi or  not n inTARSKIR2 domRELAT-1K1 phi"
         sorry
      have case1: "n inTARSKIR2 domRELAT-1K1 phi implies (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
      proof(rule impI)
        assume "n inTARSKIR2 domRELAT-1K1 phi"
        show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
          using A1 sorry
      qed
      have case2: " not n inTARSKIR2 domRELAT-1K1 phi implies (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
      proof(rule impI)
        assume " not n inTARSKIR2 domRELAT-1K1 phi"
        show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be ordinalORDINAL1V3"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem card_5_cl_12:
  mlet "X be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "n be setHIDDENM2"
"cluster (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
  proof-
    have "X c=MEMBEREDR6 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have 
      [ty]:"X be SubsetSUBSET-1M2-of NATNUMBERSK1"
       sorry
    obtain phi where
      [ty]:"phi be Ordinal-SequenceORDINAL2M1" and 
      A1: "phi =FUNCT-1R1 canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)"and "phi be increasingORDINAL2V2"and "domRELAT-1K1 phi =XBOOLE-0R4 order-type-ofWELLORD2K2 RelInclWELLORD2K1 X"and A2: "rngFUNCT-1K2 phi =XBOOLE-0R4 X"
      using card_5_th_5 sorry
    show "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
    proof-
      have cases: "n inTARSKIR2 domRELAT-1K1 phi or  not n inTARSKIR2 domRELAT-1K1 phi"
         sorry
      have case1: "n inTARSKIR2 domRELAT-1K1 phi implies (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
      proof(rule impI)
        assume A3: "n inTARSKIR2 domRELAT-1K1 phi"
        have "phi .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 phi"
          using A3 funct_1_def_3 sorry
        thus "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
          using A1 A2 sorry
      qed
      have case2: " not n inTARSKIR2 domRELAT-1K1 phi implies (canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
      proof(rule impI)
        assume " not n inTARSKIR2 domRELAT-1K1 phi"
        thus "(canonical-isomorphism-ofWELLORD1K3(RelInclWELLORD2K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 X),RelInclWELLORD2K1 X)).FUNCT-1K1 n be naturalORDINAL1V7"
          using A1 funct_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem card_5_th_39:
" for F be SubsetSUBSET-1M2-of omegaORDINAL1K4 holds cardCARD-1K1 F c=ORDINAL1R1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 F"
proof-
  have " for F be SubsetSUBSET-1M2-of omegaORDINAL1K4 holds cardCARD-1K1 F c=ORDINAL1R1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 F"
  proof(rule ballI)
    fix F assume [ty]: "F be SubsetSUBSET-1M2-of omegaORDINAL1K4"
    have "cardCARD-1K1 F =XBOOLE-0R4 cardCARD-1K1 (order-type-ofWELLORD2K2 RelInclWELLORD2K1 F)"
      using card_5_th_7 sorry
    thus "cardCARD-1K1 F c=ORDINAL1R1 order-type-ofWELLORD2K2 RelInclWELLORD2K1 F"
      using card_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
