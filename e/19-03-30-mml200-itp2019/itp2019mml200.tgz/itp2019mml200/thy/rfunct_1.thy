theory rfunct_1
  imports funct_3 seq_2 partfun2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "objectHIDDENM1"
reserve X, Y for "setHIDDENM2"
reserve C for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c for "ElementSUBSET-1M1-of C"
reserve f, f1, f2, f3, g, g1 for "complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
reserve r, p for "ComplexXCMPLX-0M1"
mlemma rfunct_1_lm_1:
"(-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
   sorry

mdef rfunct_1_def_1 (" _ '/RFUNCT-1K1  _ " [164,164]164 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 /RFUNCT-1K1 f2 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
      proof-
        let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 (f2 .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
        have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))) implies f =HIDDENR1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f assume [ty]: "f be FunctionFUNCT-1M1"
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
          and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
          and A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
          and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
            using A2 sorry
          also have "... = g .FUNCT-1K1 x"
            using A1 A3 A4 A5 sorry
          finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "f =HIDDENR1 g"
          using A1 A3 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rfunct_1_cl_1:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /RFUNCT-1K1 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be complex-valuedVALUED-0V5"
  proof-
    have "f1 /RFUNCT-1K1 f2 be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f2) implies (f1 /RFUNCT-1K1 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?F = "f1 /RFUNCT-1K1 f2"
        assume "x inHIDDENR3 domRELAT-1K1 ?F"
        then have "?F .FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        thus "(f1 /RFUNCT-1K1 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "f1 /RFUNCT-1K1 f2 be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_2:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 /RFUNCT-1K1 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be real-valuedVALUED-0V7"
  proof-
    have "f1 /RFUNCT-1K1 f2 be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f2) implies (f1 /RFUNCT-1K1 f2).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?F = "f1 /RFUNCT-1K1 f2"
        assume "x inHIDDENR3 domRELAT-1K1 ?F"
        then have "?F .FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x *XCMPLX-0K3 (f2 .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_1 sorry
        thus "(f1 /RFUNCT-1K1 f2).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "f1 /RFUNCT-1K1 f2 be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax RFUNCT_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-1K2\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f1 /RFUNCT-1K2\<^bsub>(C,D)\<^esub> f2" \<rightharpoonup> "f1 /RFUNCT-1K1 f2"

mtheorem rfunct_1_add_1:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D)", "f2 be PartFuncPARTFUN1M1-of(C,D)"
"cluster f1 /RFUNCT-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    let ?F = "f1 /RFUNCT-1K1 f2"
    have A1: "rngFUNCT-1K2 ?F c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_0_def_1 sorry
    have "domRELAT-1K1 ?F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> (domRELSET-1K1\<^bsub>(C)\<^esub> f2 \\SUBSET-1K7\<^bsub>(C)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    thus "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using A1 relset_1_th_4 sorry
  qed
qed "sorry"

syntax RFUNCT_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-1K3\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "f1 /RFUNCT-1K3\<^bsub>(C,D)\<^esub> f2" \<rightharpoonup> "f1 /RFUNCT-1K1 f2"

mtheorem rfunct_1_add_2:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D)", "f2 be PartFuncPARTFUN1M1-of(C,D)"
"cluster f1 /RFUNCT-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    let ?F = "f1 /RFUNCT-1K2\<^bsub>(C,D)\<^esub> f2"
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?F c=MEMBEREDR3 REALNUMBERSK2"
      using valued_0_def_3 sorry
    then have "?F be PartFuncPARTFUN1M1-of(domRELSET-1K1\<^bsub>(C)\<^esub> ?F,REALNUMBERSK2)"
      using relset_1_th_4 sorry
    thus "f1 /RFUNCT-1K1 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_5 sorry
  qed
qed "sorry"

mdef rfunct_1_def_2 (" _ ^RFUNCT-1K4" [164]164 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f ^RFUNCT-1K4 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
      proof-
        let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
        have " ex h be FunctionFUNCT-1M1 st domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies h .FUNCT-1K1 x =HIDDENR1 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
    proof-
      have " for h be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))) implies h =HIDDENR1 g"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix h assume [ty]: "h be FunctionFUNCT-1M1"
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
          and A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 h"
          then have "h .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
            using A2 sorry
          also have "... = g .FUNCT-1K1 x"
            using A1 A3 A4 A5 sorry
          finally show "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "h =HIDDENR1 g"
          using A1 A3 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rfunct_1_cl_3:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f ^RFUNCT-1K4 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be complex-valuedVALUED-0V5"
  proof-
    have "f ^RFUNCT-1K4 be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4) implies (f ^RFUNCT-1K4).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?F = "f ^RFUNCT-1K4"
        assume "x inHIDDENR3 domRELAT-1K1 ?F"
        then have "?F .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_2 sorry
        thus "(f ^RFUNCT-1K4).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "f ^RFUNCT-1K4 be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_4:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f ^RFUNCT-1K4 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be real-valuedVALUED-0V7"
  proof-
    have "f ^RFUNCT-1K4 be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4) implies (f ^RFUNCT-1K4).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        let ?F = "f ^RFUNCT-1K4"
        assume "x inHIDDENR3 domRELAT-1K1 ?F"
        then have "?F .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using rfunct_1_def_2 sorry
        thus "(f ^RFUNCT-1K4).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "f ^RFUNCT-1K4 be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax RFUNCT_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-1K5\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "f ^RFUNCT-1K5\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^RFUNCT-1K4"

mtheorem rfunct_1_add_3:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^RFUNCT-1K4 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    let ?F = "f ^RFUNCT-1K4"
    have A1: "rngFUNCT-1K2 ?F c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_0_def_1 sorry
    have "domRELAT-1K1 ?F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,D)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    thus "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using A1 relset_1_th_4 sorry
  qed
qed "sorry"

syntax RFUNCT_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-1K6\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "f ^RFUNCT-1K6\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^RFUNCT-1K4"

mtheorem rfunct_1_add_4:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^RFUNCT-1K4 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    let ?F = "f ^RFUNCT-1K5\<^bsub>(C,D)\<^esub>"
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> ?F c=MEMBEREDR3 REALNUMBERSK2"
      using valued_0_def_3 sorry
    then have "?F be PartFuncPARTFUN1M1-of(domRELSET-1K1\<^bsub>(C)\<^esub> ?F,REALNUMBERSK2)"
      using relset_1_th_4 sorry
    thus "f ^RFUNCT-1K4 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_5 sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_1:
" for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (g ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 g & domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (g ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 g & domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule conjMI)
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "domRELAT-1K1 (g ^RFUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    thus "domRELAT-1K1 (g ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 g"
       sorry
    show "domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) =XBOOLE-0R4 domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_2:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
    proof(rule conjMI)
      show "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          then have " not x inHIDDENR3 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_5 sorry
          then have " not (f1 (#)VALUED-1K19 f2).FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A1 funct_1_def_7 sorry
          then have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using tarski_def_1 sorry
          then have A2: "f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using valued_1_th_5 sorry
          then have "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
             sorry
          then have " not f2 .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
          then have A3: " not x inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          have "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
            using A1 sorry
          then have A4: "x inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
            using valued_1_def_4 sorry
          then have "x inHIDDENR3 domRELAT-1K1 f2"
            using xboole_0_def_4 sorry
          then have A5: "x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A3 xboole_0_def_5 sorry
          have "f1 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using A2 sorry
          then have " not f1 .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
          then have A6: " not x inHIDDENR3 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          have "x inHIDDENR3 domRELAT-1K1 f1"
            using A4 xboole_0_def_4 sorry
          then have "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A6 xboole_0_def_5 sorry
          thus "x inHIDDENR3 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
            using A5 xboole_0_def_4 sorry
        qed "sorry"
        thus "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
          using tarski_def_3 sorry
      qed
      show "(domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) implies x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A7: "x inHIDDENR3 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
          then have "x inHIDDENR3 domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_4 sorry
          then have " not x inHIDDENR3 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_5 sorry
          then have " not f2 .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A7 funct_1_def_7 sorry
          then have A8: "f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using tarski_def_1 sorry
          have A9: "x inHIDDENR3 domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A7 xboole_0_def_4 sorry
          then have " not x inHIDDENR3 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using xboole_0_def_5 sorry
          then have " not f1 .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A9 funct_1_def_7 sorry
          then have "f1 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using tarski_def_1 sorry
          then have "f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using A8 sorry
          then have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
            using valued_1_th_5 sorry
          then have " not (f1 (#)VALUED-1K19 f2).FUNCT-1K1 x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
          then have A10: " not x inHIDDENR3 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using funct_1_def_7 sorry
          have "x inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
            using A7 A9 xboole_0_def_4 sorry
          then have "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
            using valued_1_def_4 sorry
          thus "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
            using A10 xboole_0_def_5 sorry
        qed "sorry"
        thus "(domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_3 sorry
      qed
    qed
    thus "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds c inTARSKIR2 domRELAT-1K1 (f ^RFUNCT-1K4) implies f .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds c inTARSKIR2 domRELAT-1K1 (f ^RFUNCT-1K4) & f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    assume A1: "c inTARSKIR2 domRELAT-1K1 (f ^RFUNCT-1K4)"
      and A2: "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
    have A3: "c inTARSKIR2 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using A1 rfunct_1_def_2 sorry
    then have A4: " not c inTARSKIR2 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_5 sorry
    have " False "
    proof-
      show " False "
      proof-
        have cases: " not c inTARSKIR2 domRELAT-1K1 f or  not f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A4 funct_1_def_7 sorry
        have case1: " not c inTARSKIR2 domRELAT-1K1 f implies  False "
        proof(rule impI)
          assume " not c inTARSKIR2 domRELAT-1K1 f"
          thus " False "
            using A3 sorry
        qed
        have case2: " not f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 } implies  False "
        proof(rule impI)
          assume " not f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          thus " False "
            using A2 tarski_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_4:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    let ?x = "the ElementSUBSET-1M1-of (f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
    assume A1: "(f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "?x inTARSKIR2 domRELAT-1K1 (f ^RFUNCT-1K4)"
      using funct_1_def_7 sorry
    then have A3: "?x inTARSKIR2 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    then have " not ?x inTARSKIR2 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_5 sorry
    then have A4: " not f .FUNCT-1K1 ?x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
      using A3 funct_1_def_7 sorry
    have "(f ^RFUNCT-1K4).FUNCT-1K1 ?x inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
      using A1 funct_1_def_7 sorry
    then have "(f ^RFUNCT-1K4).FUNCT-1K1 ?x =COMPLEX1R1 0NUMBERSK6"
      using tarski_def_1 sorry
    then have "(f .FUNCT-1K1 ?x)\<inverse>XCMPLX-0K5 =COMPLEX1R1 0NUMBERSK6"
      using A2 rfunct_1_def_2 sorry
    thus " False "
      using A4 tarski_def_1 xcmplx_1_th_202 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_5:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } & (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have " for c be objectHIDDENM1 holds (c inHIDDENR3 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & (c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      obtain cc where 
        [ty]:"cc be objectHIDDENM1" and ccDef:"cc = c"
         sorry
      show "c inHIDDENR3 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof(rule impI)
        assume A1: "c inHIDDENR3 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        then have "absVALUED-1K57 f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        then have "absVALUED-1K57 f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 cc.| =COMPLEX1R1 0NUMBERSK6"
          using valued_1_th_18 sorry
        then have "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using complex1_th_45 sorry
        then have A2: "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f"
          using A1 funct_1_def_7 sorry
        then have "c inHIDDENR3 domRELAT-1K1 f"
          using valued_1_def_11 sorry
        thus "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A2 funct_1_def_7 sorry
      qed
      assume A3: "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      then have "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      then have "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      then have " |.COMPLEX1K10 f .FUNCT-1K1 cc.| =COMPLEX1R1 0NUMBERSK6"
        using absvalue_th_2 sorry
      then have "absVALUED-1K57 f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using valued_1_th_18 sorry
      then have A4: "absVALUED-1K57 f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      have "c inHIDDENR3 domRELAT-1K1 f"
        using A3 funct_1_def_7 sorry
      then have "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f"
        using valued_1_def_11 sorry
      thus "c inHIDDENR3 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using A4 funct_1_def_7 sorry
    qed "sorry"
    thus "absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using tarski_th_2 sorry
    have " for c be objectHIDDENM1 holds (c inHIDDENR3 (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & (c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      obtain cc where 
        [ty]:"cc be objectHIDDENM1" and ccDef:"cc = c"
         sorry
      show "c inHIDDENR3 (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof(rule impI)
        assume A5: "c inHIDDENR3 (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        then have "(-VALUED-1K32 f).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        then have "(-VALUED-1K32 f).FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        then have "-XCMPLX-0K4 (-XCMPLX-0K4 f .FUNCT-1K1 cc) =COMPLEX1R1 -REAL-1K1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
          using valued_1_th_8 sorry
        then have A6: "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have "c inHIDDENR3 domRELAT-1K1 (-VALUED-1K32 f)"
          using A5 funct_1_def_7 sorry
        then have "c inHIDDENR3 domRELAT-1K1 f"
          using valued_1_th_8 sorry
        thus "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A6 funct_1_def_7 sorry
      qed
      assume A7: "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      then have "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      then have "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      then have "(-VALUED-1K32 f).FUNCT-1K1 c =COMPLEX1R1 -REAL-1K1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
        using valued_1_th_8 sorry
      then have A8: "(-VALUED-1K32 f).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      have "c inHIDDENR3 domRELAT-1K1 f"
        using A7 funct_1_def_7 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (-VALUED-1K32 f)"
        using valued_1_th_8 sorry
      thus "c inHIDDENR3 (-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "(-VALUED-1K32 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_6:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
  proof(rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (f ^RFUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    have "domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (f ^RFUNCT-1K4) \\SUBSET-1K6 (f ^RFUNCT-1K4)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 (f ^RFUNCT-1K4) \\SUBSET-1K6 {}XBOOLE-0K1"
      using rfunct_1_th_4 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (f ^RFUNCT-1K4)"
      using A1 xboole_1_th_28 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
      using relat_1_th_61 sorry
    finally show "domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_7:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    have " for c be objectHIDDENM1 holds (c inHIDDENR3 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }) & (c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
    proof(rule ballI,rule conjMI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      obtain cc where 
        [ty]:"cc be objectHIDDENM1" and ccDef:"cc = c"
         sorry
      show "c inHIDDENR3 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } implies c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      proof(rule impI)
        assume A2: "c inHIDDENR3 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        then have A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
          using funct_1_def_7 sorry
        have "(r (#)VALUED-1K25 f).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A2 funct_1_def_7 sorry
        then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        then have "r *XCMPLX-0K3 f .FUNCT-1K1 cc =COMPLEX1R1 0NUMBERSK6"
          using A3 valued_1_def_5 sorry
        then have "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using A1 sorry
        then have A4: "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have "c inHIDDENR3 domRELAT-1K1 f"
          using A3 valued_1_def_5 sorry
        thus "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A4 funct_1_def_7 sorry
      qed
      assume A5: "c inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      then have "f .FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      then have "f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      then have A6: "r *XCMPLX-0K3 f .FUNCT-1K1 cc =COMPLEX1R1 0NUMBERSK6"
         sorry
      have A7: "c inHIDDENR3 domRELAT-1K1 f"
        using A5 funct_1_def_7 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        using valued_1_def_5 sorry
      then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using A6 valued_1_def_5 sorry
      then have A8: "(r (#)VALUED-1K25 f).FUNCT-1K1 c inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      have "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        using A7 valued_1_def_5 sorry
      thus "c inHIDDENR3 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_8:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)+VALUED-1K1 f3 =FUNCT-1R1 f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)+VALUED-1K1 f3 =FUNCT-1R1 f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f1 +VALUED-1K1 f2)+VALUED-1K1 f3) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 (f1 +VALUED-1K1 (f2 +VALUED-1K1 f3))"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 ((f1 +VALUED-1K1 f2)+VALUED-1K1 f3) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 (f2 +VALUED-1K1 f3))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2)+VALUED-1K1 f3) implies ((f1 +VALUED-1K1 f2)+VALUED-1K1 f3).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2)+VALUED-1K1 f3)"
      then have "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using valued_1_def_1 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
        using A1 A2 valued_1_def_1 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
        using xboole_0_def_4 sorry
      have "((f1 +VALUED-1K1 f2)+VALUED-1K1 f3).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2).FUNCT-1K1 c +XCMPLX-0K2 f3 .FUNCT-1K1 c"
        using A2 valued_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)+XCMPLX-0K2 f3 .FUNCT-1K1 c"
        using A3 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 (f2 .FUNCT-1K1 c +XCMPLX-0K2 f3 .FUNCT-1K1 c)"
         sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 (f2 +VALUED-1K1 f3).FUNCT-1K1 c"
        using A4 valued_1_def_1 sorry
      also have "... = (f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c"
        using A1 A2 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K1 f2)+VALUED-1K1 f3).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K1 f2)+VALUED-1K1 f3 =FUNCT-1R1 f1 +VALUED-1K1 (f2 +VALUED-1K1 f3)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_9:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3) implies ((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3)"
      have "((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)*XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c)"
         sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 (#)VALUED-1K19 f3)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3))"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3))"
       sorry
    thus "(f1 (#)VALUED-1K19 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 (f2 (#)VALUED-1K19 f3)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_10:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 (domRELAT-1K1 f3 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_def_1 sorry
    also have "... = ((domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = ((domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3) /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3) /\\XBOOLE-0K3 domRELAT-1K1 (f2 (#)VALUED-1K19 f3)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 ((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3) implies ((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3)"
      then have "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using valued_1_def_4 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using xboole_0_def_4 sorry
      have "((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2).FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)*XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using A3 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
         sorry
      also have "... = (f1 (#)VALUED-1K19 f3).FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 f3).FUNCT-1K1 c +XCMPLX-0K2 (f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
        using A1 A2 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K1 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 +VALUED-1K1 f2 (#)VALUED-1K19 f3"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_11:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f3 (#)VALUED-1K19 (f1 +VALUED-1K1 f2) =FUNCT-1R1 f3 (#)VALUED-1K19 f1 +VALUED-1K1 f3 (#)VALUED-1K19 f2"
  using rfunct_1_th_10 sorry

mtheorem rfunct_1_th_12:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 (r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 (r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 ((r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2)"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) =HIDDENR1 domRELAT-1K1 ((r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) implies (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 ((r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2))"
      then have "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A1 valued_1_def_4 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1)"
        using xboole_0_def_4 sorry
      have "(r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
        using valued_1_th_5 sorry
      also have "... = (r *XCMPLX-0K3 f1 .FUNCT-1K1 c)*XCMPLX-0K3 f2 .FUNCT-1K1 c"
         sorry
      also have "... = (r (#)VALUED-1K25 f1).FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A3 valued_1_def_5 sorry
      also have "... = ((r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "(r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 ((r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 (r (#)VALUED-1K25 f1)(#)VALUED-1K19 f2"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_13:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2))"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)) implies (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2))"
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using A1 valued_1_def_4 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using xboole_0_def_4 sorry
      have "(r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
        using valued_1_th_5 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (r *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
         sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (r (#)VALUED-1K25 f2).FUNCT-1K1 c"
        using A3 valued_1_def_5 sorry
      also have "... = (f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "(r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2)).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 f1 (#)VALUED-1K19 (r (#)VALUED-1K25 f2)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_14:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 (domRELAT-1K1 f3 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_th_12 sorry
    also have "... = ((domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = ((domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f3)/\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3) /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3) /\\XBOOLE-0K3 domRELAT-1K1 (f2 (#)VALUED-1K19 f3)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3)"
      using valued_1_th_12 sorry
    finally have "domRELAT-1K1 ((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3) implies ((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3)"
      then have "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using valued_1_def_4 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
        using xboole_0_def_4 sorry
      have "((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 -VALUED-1K47 f2).FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c)*XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using A3 valued_1_th_13 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
         sorry
      also have "... = (f1 (#)VALUED-1K19 f3).FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c *XCMPLX-0K3 f3 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 f3).FUNCT-1K1 c -XCMPLX-0K6 (f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
        using A1 A2 valued_1_th_13 sorry
      finally show "((f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f1 -VALUED-1K47 f2)(#)VALUED-1K19 f3 =FUNCT-1R1 f1 (#)VALUED-1K19 f3 -VALUED-1K47 f2 (#)VALUED-1K19 f3"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_15:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f3 (#)VALUED-1K19 f1 -VALUED-1K47 f3 (#)VALUED-1K19 f2 =FUNCT-1R1 f3 (#)VALUED-1K19 (f1 -VALUED-1K47 f2)"
  using rfunct_1_th_14 sorry

mtheorem rfunct_1_th_16:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 +VALUED-1K1 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 +VALUED-1K1 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 (r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 (r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)) implies (r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 +VALUED-1K1 f2))"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using valued_1_def_5 sorry
      have A4: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using A1 A2 valued_1_def_1 sorry
      then have A5: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1)"
        using xboole_0_def_4 sorry
      have A6: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using A4 xboole_0_def_4 sorry
      have "(r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 (f1 +VALUED-1K1 f2).FUNCT-1K1 c"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)"
        using A3 valued_1_def_1 sorry
      also have "... = r *XCMPLX-0K3 f1 .FUNCT-1K1 c +XCMPLX-0K2 r *XCMPLX-0K3 f2 .FUNCT-1K1 c"
         sorry
      also have "... = (r (#)VALUED-1K25 f1).FUNCT-1K1 c +XCMPLX-0K2 r *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A5 valued_1_def_5 sorry
      also have "... = (r (#)VALUED-1K25 f1).FUNCT-1K1 c +XCMPLX-0K2 (r (#)VALUED-1K25 f2).FUNCT-1K1 c"
        using A6 valued_1_def_5 sorry
      also have "... = (r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
        using A1 A2 valued_1_def_1 sorry
      finally show "(r (#)VALUED-1K25 (f1 +VALUED-1K1 f2)).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 (f1 +VALUED-1K1 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 +VALUED-1K1 r (#)VALUED-1K25 f2"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_17:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds  for p be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K25 f =FUNCT-1R1 r (#)VALUED-1K25 (p (#)VALUED-1K25 f)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds  for p be ComplexXCMPLX-0M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K25 f =FUNCT-1R1 r (#)VALUED-1K25 (p (#)VALUED-1K25 f)"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix p assume [ty]: "p be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 ((r *XCMPLX-0K3 p)(#)VALUED-1K25 f) =HIDDENR1 domRELAT-1K1 f"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (p (#)VALUED-1K25 f)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 (p (#)VALUED-1K25 f))"
      using valued_1_def_5 sorry
    finally have "domRELAT-1K1 ((r *XCMPLX-0K3 p)(#)VALUED-1K25 f) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 (p (#)VALUED-1K25 f))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((r *XCMPLX-0K3 p)(#)VALUED-1K25 f) implies ((r *XCMPLX-0K3 p)(#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 (p (#)VALUED-1K25 f)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((r *XCMPLX-0K3 p)(#)VALUED-1K25 f)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (p (#)VALUED-1K25 f)"
        using A1 valued_1_def_5 sorry
      have "((r *XCMPLX-0K3 p)(#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 (r *XCMPLX-0K3 p)*XCMPLX-0K3 f .FUNCT-1K1 c"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (p *XCMPLX-0K3 f .FUNCT-1K1 c)"
         sorry
      also have "... = r *XCMPLX-0K3 (p (#)VALUED-1K25 f).FUNCT-1K1 c"
        using A3 valued_1_def_5 sorry
      also have "... = (r (#)VALUED-1K25 (p (#)VALUED-1K25 f)).FUNCT-1K1 c"
        using A1 A2 valued_1_def_5 sorry
      finally show "((r *XCMPLX-0K3 p)(#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 (p (#)VALUED-1K25 f)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(r *XCMPLX-0K3 p)(#)VALUED-1K25 f =FUNCT-1R1 r (#)VALUED-1K25 (p (#)VALUED-1K25 f)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_18:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 -VALUED-1K47 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (f1 -VALUED-1K47 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 (r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)) =HIDDENR1 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2)"
      using valued_1_th_12 sorry
    finally have "domRELAT-1K1 (r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)) implies (r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 (f1 -VALUED-1K47 f2))"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
        using valued_1_def_5 sorry
      have A4: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1) /\\XBOOLE-0K3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using A1 A2 valued_1_th_12 sorry
      then have A5: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f1)"
        using xboole_0_def_4 sorry
      have A6: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f2)"
        using A4 xboole_0_def_4 sorry
      have "(r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 (f1 -VALUED-1K47 f2).FUNCT-1K1 c"
        using A2 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c)"
        using A3 valued_1_th_13 sorry
      also have "... = r *XCMPLX-0K3 f1 .FUNCT-1K1 c -XCMPLX-0K6 r *XCMPLX-0K3 f2 .FUNCT-1K1 c"
         sorry
      also have "... = (r (#)VALUED-1K25 f1).FUNCT-1K1 c -XCMPLX-0K6 r *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A5 valued_1_def_5 sorry
      also have "... = (r (#)VALUED-1K25 f1).FUNCT-1K1 c -XCMPLX-0K6 (r (#)VALUED-1K25 f2).FUNCT-1K1 c"
        using A6 valued_1_def_5 sorry
      also have "... = (r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
        using A1 A2 valued_1_th_13 sorry
      finally show "(r (#)VALUED-1K25 (f1 -VALUED-1K47 f2)).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 (f1 -VALUED-1K47 f2) =FUNCT-1R1 r (#)VALUED-1K25 f1 -VALUED-1K47 r (#)VALUED-1K25 f2"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_19:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 f2 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 f2 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f1"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 (f2 -VALUED-1K47 f1)"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1))"
      using valued_1_def_5 sorry
    finally have "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) implies (f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      have A2: "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f1"
        using valued_1_th_12 sorry
      also have "... = domRELAT-1K1 (f2 -VALUED-1K47 f1)"
        using valued_1_th_12 sorry
      finally have "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 (f2 -VALUED-1K47 f1)"
         sorry
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A3: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
      have "(f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
        using A3 valued_1_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (f2 .FUNCT-1K1 c -XCMPLX-0K6 f1 .FUNCT-1K1 c)"
         sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (f2 -VALUED-1K47 f1).FUNCT-1K1 c"
        using A3 A2 valued_1_th_13 sorry
      also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)).FUNCT-1K1 c"
        using A1 A3 valued_1_def_5 sorry
      finally show "(f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K47 f2 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f2 -VALUED-1K47 f1)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_20:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 +VALUED-1K1 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)-VALUED-1K47 f3"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 +VALUED-1K1 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)-VALUED-1K47 f3"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 ((f1 -VALUED-1K47 f2)-VALUED-1K47 f3)"
      using valued_1_th_12 sorry
    finally have "domRELAT-1K1 (f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)) =HIDDENR1 domRELAT-1K1 ((f1 -VALUED-1K47 f2)-VALUED-1K47 f3)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)) implies (f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 -VALUED-1K47 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 (f2 +VALUED-1K1 f3))"
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
        using valued_1_th_12 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f2 +VALUED-1K1 f3)"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using A1 A2 valued_1_th_12 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
        using xboole_0_def_4 sorry
      have "(f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 (f2 +VALUED-1K1 f3).FUNCT-1K1 c"
        using A2 valued_1_th_13 sorry
      also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 (f2 .FUNCT-1K1 c +XCMPLX-0K2 f3 .FUNCT-1K1 c)"
        using A3 valued_1_def_1 sorry
      also have "... = (f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c)-XCMPLX-0K6 f3 .FUNCT-1K1 c"
         sorry
      also have "... = (f1 -VALUED-1K47 f2).FUNCT-1K1 c -XCMPLX-0K6 f3 .FUNCT-1K1 c"
        using A4 valued_1_th_13 sorry
      also have "... = ((f1 -VALUED-1K47 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
        using A1 A2 valued_1_th_13 sorry
      finally show "(f1 -VALUED-1K47 (f2 +VALUED-1K1 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 -VALUED-1K47 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K47 (f2 +VALUED-1K1 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)-VALUED-1K47 f3"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_21:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds \<one>\<^sub>M (#)VALUED-1K25 f =FUNCT-1R1 f"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds \<one>\<^sub>M (#)VALUED-1K25 f =FUNCT-1R1 f"
  proof(rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (\<one>\<^sub>M (#)VALUED-1K25 f) implies (\<one>\<^sub>M (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 domRELAT-1K1 (\<one>\<^sub>M (#)VALUED-1K25 f)"
      then have "(\<one>\<^sub>M (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 f .FUNCT-1K1 c"
        using valued_1_def_5 sorry
      also have "... = f .FUNCT-1K1 c"
         sorry
      finally show "(\<one>\<^sub>M (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (\<one>\<^sub>M (#)VALUED-1K25 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using valued_1_def_5 sorry
    thus "\<one>\<^sub>M (#)VALUED-1K25 f =FUNCT-1R1 f"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_22:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)+VALUED-1K1 f3"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 -VALUED-1K47 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)+VALUED-1K1 f3"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_th_12 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_th_12 sorry
    also have "... = domRELAT-1K1 ((f1 -VALUED-1K47 f2)+VALUED-1K1 f3)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 (f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)) =HIDDENR1 domRELAT-1K1 ((f1 -VALUED-1K47 f2)+VALUED-1K1 f3)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)) implies (f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 -VALUED-1K47 f2)+VALUED-1K1 f3).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 (f2 -VALUED-1K47 f3))"
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
        using valued_1_th_12 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using A1 A2 valued_1_def_1 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
        using xboole_0_def_4 sorry
      have "(f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 (f2 -VALUED-1K47 f3).FUNCT-1K1 c"
        using A2 valued_1_th_13 sorry
      also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 (f2 .FUNCT-1K1 c -XCMPLX-0K6 f3 .FUNCT-1K1 c)"
        using A3 valued_1_th_13 sorry
      also have "... = (f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c)+XCMPLX-0K2 f3 .FUNCT-1K1 c"
         sorry
      also have "... = (f1 -VALUED-1K47 f2).FUNCT-1K1 c +XCMPLX-0K2 f3 .FUNCT-1K1 c"
        using A4 valued_1_th_13 sorry
      also have "... = ((f1 -VALUED-1K47 f2)+VALUED-1K1 f3).FUNCT-1K1 c"
        using A1 A2 valued_1_def_1 sorry
      finally show "(f1 -VALUED-1K47 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 -VALUED-1K47 f2)+VALUED-1K1 f3).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K47 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 -VALUED-1K47 f2)+VALUED-1K1 f3"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_23:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 +VALUED-1K1 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 +VALUED-1K1 f2)-VALUED-1K47 f3"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 +VALUED-1K1 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 +VALUED-1K1 f2)-VALUED-1K47 f3"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f3 assume [ty]: "f3 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f3)"
      using valued_1_th_12 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 domRELAT-1K1 f3"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 ((f1 +VALUED-1K1 f2)-VALUED-1K47 f3)"
      using valued_1_th_12 sorry
    finally have "domRELAT-1K1 (f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)) =HIDDENR1 domRELAT-1K1 ((f1 +VALUED-1K1 f2)-VALUED-1K47 f3)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)) implies (f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 +VALUED-1K1 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 (f2 -VALUED-1K47 f3))"
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
        using valued_1_def_1 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f2 -VALUED-1K47 f3)"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 domRELAT-1K1 f3"
        using A1 A2 valued_1_th_12 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using xboole_0_def_4 sorry
      have "(f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c +XCMPLX-0K2 (f2 -VALUED-1K47 f3).FUNCT-1K1 c"
        using A2 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 (f2 .FUNCT-1K1 c -XCMPLX-0K6 f3 .FUNCT-1K1 c)"
        using A3 valued_1_th_13 sorry
      also have "... = (f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)-XCMPLX-0K6 f3 .FUNCT-1K1 c"
         sorry
      also have "... = (f1 +VALUED-1K1 f2).FUNCT-1K1 c -XCMPLX-0K6 f3 .FUNCT-1K1 c"
        using A4 valued_1_def_1 sorry
      also have "... = ((f1 +VALUED-1K1 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
        using A1 A2 valued_1_th_13 sorry
      finally show "(f1 +VALUED-1K1 (f2 -VALUED-1K47 f3)).FUNCT-1K1 c =HIDDENR1 ((f1 +VALUED-1K1 f2)-VALUED-1K47 f3).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K1 (f2 -VALUED-1K47 f3) =FUNCT-1R1 (f1 +VALUED-1K1 f2)-VALUED-1K47 f3"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_24:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 (f1 (#)VALUED-1K19 f2) implies absVALUED-1K57 (f1 (#)VALUED-1K19 f2) .FUNCT-1K1 c =HIDDENR1 (absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 (f1 (#)VALUED-1K19 f2)"
      have "absVALUED-1K57 (f1 (#)VALUED-1K19 f2) .FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c .|"
        using valued_1_th_5 sorry
      also have "... = ( |.COMPLEX1K10 f1 .FUNCT-1K1 c.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 c.|)"
        using complex1_th_65 sorry
      also have "... = absVALUED-1K57 f1 .FUNCT-1K1 c *XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 c.|)"
        using valued_1_th_18 sorry
      also have "... = absVALUED-1K57 f1 .FUNCT-1K1 c *XCMPLX-0K3 absVALUED-1K57 f2 .FUNCT-1K1 c"
        using valued_1_th_18 sorry
      also have "... = (absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "absVALUED-1K57 (f1 (#)VALUED-1K19 f2) .FUNCT-1K1 c =HIDDENR1 (absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 absVALUED-1K57 f2"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 absVALUED-1K57 f1 /\\XBOOLE-0K3 domRELAT-1K1 absVALUED-1K57 f2"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 (absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2)"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =HIDDENR1 domRELAT-1K1 (absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2)"
       sorry
    thus "absVALUED-1K57 (f1 (#)VALUED-1K19 f2) =FUNCT-1R1 absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 f2"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_25:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds absVALUED-1K57 (r (#)VALUED-1K25 f) =FUNCT-1R1 ( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds absVALUED-1K57 (r (#)VALUED-1K25 f) =FUNCT-1R1 ( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: "domRELAT-1K1 absVALUED-1K57 (r (#)VALUED-1K25 f) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f)"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 f"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 absVALUED-1K57 f"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f)"
      using valued_1_def_5 sorry
    finally have "domRELAT-1K1 absVALUED-1K57 (r (#)VALUED-1K25 f) =HIDDENR1 domRELAT-1K1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 (r (#)VALUED-1K25 f) implies absVALUED-1K57 (r (#)VALUED-1K25 f) .FUNCT-1K1 c =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 (r (#)VALUED-1K25 f)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        using valued_1_def_11 sorry
      have "absVALUED-1K57 (r (#)VALUED-1K25 f) .FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 (r (#)VALUED-1K25 f).FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 f .FUNCT-1K1 c .|"
        using A3 valued_1_def_5 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 absVALUED-1K57 f .FUNCT-1K1 c"
        using valued_1_th_18 sorry
      also have "... = (( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f).FUNCT-1K1 c"
        using A1 A2 valued_1_def_5 sorry
      finally show "absVALUED-1K57 (r (#)VALUED-1K25 f) .FUNCT-1K1 c =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "absVALUED-1K57 (r (#)VALUED-1K25 f) =FUNCT-1R1 ( |.COMPLEX1K10 r.|)(#)VALUED-1K25 absVALUED-1K57 f"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_26:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)^RFUNCT-1K4 =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f ^RFUNCT-1K4)^RFUNCT-1K4 =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)"
  proof(rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4))"
      using rfunct_1_th_6 sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4) implies ((f ^RFUNCT-1K4)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f ^RFUNCT-1K4)^RFUNCT-1K4)"
      then have "c inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using A1 relat_1_th_61 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      have "((f ^RFUNCT-1K4)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 ((f ^RFUNCT-1K4).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A2 rfunct_1_def_2 sorry
      also have "... = ((f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
        using A3 rfunct_1_def_2 sorry
      also have "... = (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
        using A1 A2 funct_1_th_47 sorry
      finally show "((f ^RFUNCT-1K4)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f ^RFUNCT-1K4)^RFUNCT-1K4 =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (f ^RFUNCT-1K4)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_27:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)^RFUNCT-1K4 =FUNCT-1R1 (f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2)^RFUNCT-1K4 =FUNCT-1R1 (f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) \\SUBSET-1K6 (f1 (#)VALUED-1K19 f2)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = (domRELAT-1K1 f1 \\SUBSET-1K6 f1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_th_2 sorry
    also have "... = domRELAT-1K1 (f1 ^RFUNCT-1K4) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f2)\<^esub> (domRELAT-1K1 f2 \\SUBSET-1K6 f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 (f1 ^RFUNCT-1K4) /\\XBOOLE-0K3 domRELAT-1K1 (f2 ^RFUNCT-1K4)"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 ((f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4))"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 ((f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4) implies ((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 ((f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 ^RFUNCT-1K4) /\\XBOOLE-0K3 domRELAT-1K1 (f2 ^RFUNCT-1K4)"
        using A1 valued_1_def_4 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f1 ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      have A5: "c inHIDDENR3 domRELAT-1K1 (f2 ^RFUNCT-1K4)"
        using A3 xboole_0_def_4 sorry
      have "((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 ((f1 (#)VALUED-1K19 f2).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A2 rfunct_1_def_2 sorry
      also have "... = (f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using valued_1_th_5 sorry
      also have "... = (f1 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = (f1 ^RFUNCT-1K4).FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A4 rfunct_1_def_2 sorry
      also have "... = (f1 ^RFUNCT-1K4).FUNCT-1K1 c *XCMPLX-0K3 (f2 ^RFUNCT-1K4).FUNCT-1K1 c"
        using A5 rfunct_1_def_2 sorry
      also have "... = ((f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "((f1 (#)VALUED-1K19 f2)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 ((f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f1 (#)VALUED-1K19 f2)^RFUNCT-1K4 =FUNCT-1R1 (f1 ^RFUNCT-1K4)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_28:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)^RFUNCT-1K4 =FUNCT-1R1 r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies (r (#)VALUED-1K25 f)^RFUNCT-1K4 =FUNCT-1R1 r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    have A2: "domRELAT-1K1 ((r (#)VALUED-1K25 f)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f) \\SUBSET-1K6 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f) \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using A1 rfunct_1_th_7 sorry
    also have "... = domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (f ^RFUNCT-1K4)"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4))"
      using valued_1_def_5 sorry
    finally have "domRELAT-1K1 ((r (#)VALUED-1K25 f)^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((r (#)VALUED-1K25 f)^RFUNCT-1K4) implies ((r (#)VALUED-1K25 f)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A3: "c inHIDDENR3 domRELAT-1K1 ((r (#)VALUED-1K25 f)^RFUNCT-1K4)"
      then have A4: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) \\SUBSET-1K6 (r (#)VALUED-1K25 f)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      have A5: "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using A2 A3 valued_1_def_5 sorry
      have "((r (#)VALUED-1K25 f)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 ((r (#)VALUED-1K25 f).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A3 rfunct_1_def_2 sorry
      also have "... = (r *XCMPLX-0K3 f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A4 valued_1_def_5 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f ^RFUNCT-1K4).FUNCT-1K1 c"
        using A5 rfunct_1_def_2 sorry
      also have "... = (r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
        using A2 A3 valued_1_def_5 sorry
      finally show "((r (#)VALUED-1K25 f)^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K25 f)^RFUNCT-1K4 =FUNCT-1R1 r \<inverse>XCMPLX-0K5 (#)VALUED-1K25 (f ^RFUNCT-1K4)"
      using A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_29:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (-VALUED-1K32 f)^RFUNCT-1K4 =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (f ^RFUNCT-1K4)"
  using rfunct_1_lm_1 rfunct_1_th_28 sorry

mtheorem rfunct_1_th_30:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f ^RFUNCT-1K4 =FUNCT-1R1 absVALUED-1K57 (f ^RFUNCT-1K4)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f ^RFUNCT-1K4 =FUNCT-1R1 absVALUED-1K57 (f ^RFUNCT-1K4)"
  proof(rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 (absVALUED-1K57 f ^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 absVALUED-1K57 f \\SUBSET-1K6 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 f \\SUBSET-1K6 absVALUED-1K57 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using rfunct_1_th_5 sorry
    also have "... = domRELAT-1K1 (f ^RFUNCT-1K4)"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 absVALUED-1K57 (f ^RFUNCT-1K4)"
      using valued_1_def_11 sorry
    finally have "domRELAT-1K1 (absVALUED-1K57 f ^RFUNCT-1K4) =HIDDENR1 domRELAT-1K1 absVALUED-1K57 (f ^RFUNCT-1K4)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (absVALUED-1K57 f ^RFUNCT-1K4) implies (absVALUED-1K57 f ^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 absVALUED-1K57 (f ^RFUNCT-1K4) .FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (absVALUED-1K57 f ^RFUNCT-1K4)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using A1 valued_1_def_11 sorry
      have "(absVALUED-1K57 f ^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 (absVALUED-1K57 f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A2 rfunct_1_def_2 sorry
      also have "... = ( |.COMPLEX1K10 f .FUNCT-1K1 c.|)\<inverse>XCMPLX-0K5"
        using valued_1_th_18 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
        using xcmplx_1_th_215 sorry
      also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 f .FUNCT-1K1 c .|"
        using complex1_th_80 sorry
      also have "... =  |.COMPLEX1K10 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5.|"
        using xcmplx_1_th_215 sorry
      also have "... =  |.COMPLEX1K10 (f ^RFUNCT-1K4).FUNCT-1K1 c.|"
        using A3 rfunct_1_def_2 sorry
      also have "... = absVALUED-1K57 (f ^RFUNCT-1K4) .FUNCT-1K1 c"
        using valued_1_th_18 sorry
      finally show "(absVALUED-1K57 f ^RFUNCT-1K4).FUNCT-1K1 c =HIDDENR1 absVALUED-1K57 (f ^RFUNCT-1K4) .FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "absVALUED-1K57 f ^RFUNCT-1K4 =FUNCT-1R1 absVALUED-1K57 (f ^RFUNCT-1K4)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_31:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f /RFUNCT-1K1 g =FUNCT-1R1 f (#)VALUED-1K19 (g ^RFUNCT-1K4)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f /RFUNCT-1K1 g =FUNCT-1R1 f (#)VALUED-1K19 (g ^RFUNCT-1K4)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f /RFUNCT-1K1 g) implies (f /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 (f /RFUNCT-1K1 g)"
      then have "c inHIDDENR3 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
        using rfunct_1_def_1 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using rfunct_1_def_2 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      have "(f /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 f .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A2 rfunct_1_def_1 sorry
      also have "... = f .FUNCT-1K1 c *XCMPLX-0K3 (g ^RFUNCT-1K4).FUNCT-1K1 c"
        using A3 rfunct_1_def_2 sorry
      also have "... = (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "(f /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (f /RFUNCT-1K1 g) =HIDDENR1 domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 (f (#)VALUED-1K19 (g ^RFUNCT-1K4))"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 (f /RFUNCT-1K1 g) =HIDDENR1 domRELAT-1K1 (f (#)VALUED-1K19 (g ^RFUNCT-1K4))"
       sorry
    thus "f /RFUNCT-1K1 g =FUNCT-1R1 f (#)VALUED-1K19 (g ^RFUNCT-1K4)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_32:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (g /RFUNCT-1K1 f) =FUNCT-1R1 (r (#)VALUED-1K25 g)/RFUNCT-1K1 f"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds r (#)VALUED-1K25 (g /RFUNCT-1K1 f) =HIDDENR1 (r (#)VALUED-1K25 g)/RFUNCT-1K1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have "r (#)VALUED-1K25 (g /RFUNCT-1K1 f) =HIDDENR1 r (#)VALUED-1K25 (g (#)VALUED-1K19 (f ^RFUNCT-1K4))"
      using rfunct_1_th_31 sorry
    also have "... = (r (#)VALUED-1K25 g)(#)VALUED-1K19 (f ^RFUNCT-1K4)"
      using rfunct_1_th_12 sorry
    also have "... = (r (#)VALUED-1K25 g)/RFUNCT-1K1 f"
      using rfunct_1_th_31 sorry
    finally show "r (#)VALUED-1K25 (g /RFUNCT-1K1 f) =HIDDENR1 (r (#)VALUED-1K25 g)/RFUNCT-1K1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_33:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 g) =HIDDENR1 domRELAT-1K1 (f /RFUNCT-1K1 g) /\\XBOOLE-0K3 domRELAT-1K1 g"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g"
      using rfunct_1_def_1 sorry
    also have "... = domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 (domRELAT-1K1 (g ^RFUNCT-1K4) /\\XBOOLE-0K3 domRELAT-1K1 g)"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
      using rfunct_1_th_1 xboole_1_th_28 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4))"
      using relat_1_th_61 sorry
    finally have "domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 g) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4))"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 g) implies ((f /RFUNCT-1K1 g)(#)VALUED-1K19 g).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 g)"
      then have "c inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using A1 relat_1_th_61 sorry
      then have A3: "c inHIDDENR3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      then have A4: "g .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
        using rfunct_1_th_3 sorry
      have "((f /RFUNCT-1K1 g)(#)VALUED-1K19 g).FUNCT-1K1 c =HIDDENR1 (f /RFUNCT-1K1 g).FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c"
        using rfunct_1_th_31 sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 (g ^RFUNCT-1K4).FUNCT-1K1 c)*XCMPLX-0K3 g .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 g .FUNCT-1K1 c"
        using A3 rfunct_1_def_2 sorry
      also have "... = f .FUNCT-1K1 c *XCMPLX-0K3 ((g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 g .FUNCT-1K1 c)"
         sorry
      also have "... = f .FUNCT-1K1 c *XCMPLX-0K3 \<one>\<^sub>M"
        using A4 xcmplx_0_def_7 sorry
      also have "... = (f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
        using A1 A2 funct_1_th_47 sorry
      finally show "((f /RFUNCT-1K1 g)(#)VALUED-1K19 g).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f /RFUNCT-1K1 g)(#)VALUED-1K19 g =FUNCT-1R1 f  |RELAT-1K8 domRELAT-1K1 (g ^RFUNCT-1K4)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_34:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g1 assume [ty]: "g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)) implies ((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)).FUNCT-1K1 c =HIDDENR1 ((f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1))"
      have "((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)).FUNCT-1K1 c =HIDDENR1 (f /RFUNCT-1K1 g).FUNCT-1K1 c *XCMPLX-0K3 (f1 /RFUNCT-1K1 g1).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c *XCMPLX-0K3 (f1 /RFUNCT-1K1 g1).FUNCT-1K1 c"
        using rfunct_1_th_31 sorry
      also have "... = (f (#)VALUED-1K19 (g ^RFUNCT-1K4)).FUNCT-1K1 c *XCMPLX-0K3 (f1 (#)VALUED-1K19 (g1 ^RFUNCT-1K4)).FUNCT-1K1 c"
        using rfunct_1_th_31 sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 (g ^RFUNCT-1K4).FUNCT-1K1 c)*XCMPLX-0K3 (f1 (#)VALUED-1K19 (g1 ^RFUNCT-1K4)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 (g ^RFUNCT-1K4).FUNCT-1K1 c)*XCMPLX-0K3 (f1 .FUNCT-1K1 c *XCMPLX-0K3 (g1 ^RFUNCT-1K4).FUNCT-1K1 c)"
        using valued_1_th_5 sorry
      also have "... = f .FUNCT-1K1 c *XCMPLX-0K3 (f1 .FUNCT-1K1 c *XCMPLX-0K3 ((g ^RFUNCT-1K4).FUNCT-1K1 c *XCMPLX-0K3 (g1 ^RFUNCT-1K4).FUNCT-1K1 c))"
         sorry
      also have "... = f .FUNCT-1K1 c *XCMPLX-0K3 (f1 .FUNCT-1K1 c *XCMPLX-0K3 ((g ^RFUNCT-1K4)(#)VALUED-1K19 (g1 ^RFUNCT-1K4)).FUNCT-1K1 c)"
        using valued_1_th_5 sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 f1 .FUNCT-1K1 c)*XCMPLX-0K3 ((g ^RFUNCT-1K4)(#)VALUED-1K19 (g1 ^RFUNCT-1K4)).FUNCT-1K1 c"
         sorry
      also have "... = (f .FUNCT-1K1 c *XCMPLX-0K3 f1 .FUNCT-1K1 c)*XCMPLX-0K3 ((g (#)VALUED-1K19 g1)^RFUNCT-1K4).FUNCT-1K1 c"
        using rfunct_1_th_27 sorry
      also have "... = (f (#)VALUED-1K19 f1).FUNCT-1K1 c *XCMPLX-0K3 ((g (#)VALUED-1K19 g1)^RFUNCT-1K4).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = ((f (#)VALUED-1K19 f1)(#)VALUED-1K19 ((g (#)VALUED-1K19 g1)^RFUNCT-1K4)).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = ((f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)).FUNCT-1K1 c"
        using rfunct_1_th_31 sorry
      finally show "((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)).FUNCT-1K1 c =HIDDENR1 ((f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)) =HIDDENR1 domRELAT-1K1 (f /RFUNCT-1K1 g) /\\XBOOLE-0K3 domRELAT-1K1 (f1 /RFUNCT-1K1 g1)"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 (f1 /RFUNCT-1K1 g1)"
      using rfunct_1_def_1 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 g1 \\SUBSET-1K6 g1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using rfunct_1_def_1 sorry
    also have "... = domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> ((domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 g1 \\SUBSET-1K6 g1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> ((domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 g1 \\SUBSET-1K6 g1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f1)/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> ((domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 g1 \\SUBSET-1K6 g1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f (#)VALUED-1K19 f1) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> ((domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g1)\<^esub> (domRELAT-1K1 g1 \\SUBSET-1K6 g1 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f (#)VALUED-1K19 f1) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (g (#)VALUED-1K19 g1))\<^esub> (domRELAT-1K1 (g (#)VALUED-1K19 g1) \\SUBSET-1K6 (g (#)VALUED-1K19 g1)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_th_2 sorry
    also have "... = domRELAT-1K1 ((f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1))"
      using rfunct_1_def_1 sorry
    finally have "domRELAT-1K1 ((f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1)) =HIDDENR1 domRELAT-1K1 ((f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1))"
       sorry
    thus "(f /RFUNCT-1K1 g)(#)VALUED-1K19 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 f1)/RFUNCT-1K1 (g (#)VALUED-1K19 g1)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_35:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 /RFUNCT-1K1 f2)^RFUNCT-1K4 =FUNCT-1R1 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 /RFUNCT-1K1 f2)^RFUNCT-1K4 =HIDDENR1 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "(f1 /RFUNCT-1K1 f2)^RFUNCT-1K4 =HIDDENR1 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4))^RFUNCT-1K4"
      using rfunct_1_th_31 sorry
    also have "... = (f1 ^RFUNCT-1K4)(#)VALUED-1K19 ((f2 ^RFUNCT-1K4)^RFUNCT-1K4)"
      using rfunct_1_th_27 sorry
    also have "... = f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) (#)VALUED-1K19 (f1 ^RFUNCT-1K4)"
      using rfunct_1_th_26 sorry
    also have "... = f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1"
      using rfunct_1_th_31 sorry
    finally show "(f1 /RFUNCT-1K1 f2)^RFUNCT-1K4 =HIDDENR1 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_36:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g (#)VALUED-1K19 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 (g (#)VALUED-1K19 f1)/RFUNCT-1K1 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g (#)VALUED-1K19 (f1 /RFUNCT-1K1 f2) =HIDDENR1 (g (#)VALUED-1K19 f1)/RFUNCT-1K1 f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "g (#)VALUED-1K19 (f1 /RFUNCT-1K1 f2) =HIDDENR1 g (#)VALUED-1K19 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4))"
      using rfunct_1_th_31 sorry
    also have "... = (g (#)VALUED-1K19 f1)(#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
      using rfunct_1_th_9 sorry
    also have "... = (g (#)VALUED-1K19 f1)/RFUNCT-1K1 f2"
      using rfunct_1_th_31 sorry
    finally show "g (#)VALUED-1K19 (f1 /RFUNCT-1K1 f2) =HIDDENR1 (g (#)VALUED-1K19 f1)/RFUNCT-1K1 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_37:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g /RFUNCT-1K1 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 (g (#)VALUED-1K19 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4))/RFUNCT-1K1 f1"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds g /RFUNCT-1K1 (f1 /RFUNCT-1K1 f2) =HIDDENR1 (g (#)VALUED-1K19 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4))/RFUNCT-1K1 f1"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "g /RFUNCT-1K1 (f1 /RFUNCT-1K1 f2) =HIDDENR1 g (#)VALUED-1K19 ((f1 /RFUNCT-1K1 f2)^RFUNCT-1K4)"
      using rfunct_1_th_31 sorry
    also have "... = g (#)VALUED-1K19 (f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4) /RFUNCT-1K1 f1)"
      using rfunct_1_th_35 sorry
    also have "... = (g (#)VALUED-1K19 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4))/RFUNCT-1K1 f1"
      using rfunct_1_th_36 sorry
    finally show "g /RFUNCT-1K1 (f1 /RFUNCT-1K1 f2) =HIDDENR1 (g (#)VALUED-1K19 f2  |RELAT-1K8 domRELAT-1K1 (f2 ^RFUNCT-1K4))/RFUNCT-1K1 f1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_38:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 f /RFUNCT-1K1 g =FUNCT-1R1 (-VALUED-1K32 f)/RFUNCT-1K1 g & f /RFUNCT-1K1 (-VALUED-1K32 g) =FUNCT-1R1 -VALUED-1K32 f /RFUNCT-1K1 g"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 f /RFUNCT-1K1 g =FUNCT-1R1 (-VALUED-1K32 f)/RFUNCT-1K1 g & f /RFUNCT-1K1 (-VALUED-1K32 g) =HIDDENR1 -VALUED-1K32 f /RFUNCT-1K1 g"
  proof(rule ballI,rule ballI,rule conjMI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    show "-VALUED-1K32 f /RFUNCT-1K1 g =FUNCT-1R1 (-VALUED-1K32 f)/RFUNCT-1K1 g"
      using rfunct_1_th_32 sorry
    have "f /RFUNCT-1K1 (-VALUED-1K32 g) =HIDDENR1 f (#)VALUED-1K19 ((-VALUED-1K32 g)^RFUNCT-1K4)"
      using rfunct_1_th_31 sorry
    also have "... = f (#)VALUED-1K19 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 (g ^RFUNCT-1K4))"
      using rfunct_1_lm_1 rfunct_1_th_28 sorry
    also have "... = -VALUED-1K32 f (#)VALUED-1K19 (g ^RFUNCT-1K4)"
      using rfunct_1_th_13 sorry
    also have "... = -VALUED-1K32 f /RFUNCT-1K1 g"
      using rfunct_1_th_31 sorry
    finally show "f /RFUNCT-1K1 (-VALUED-1K32 g) =HIDDENR1 -VALUED-1K32 f /RFUNCT-1K1 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_39:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 f2 /RFUNCT-1K1 f =FUNCT-1R1 (f1 +VALUED-1K1 f2)/RFUNCT-1K1 f & f1 /RFUNCT-1K1 f -VALUED-1K47 f2 /RFUNCT-1K1 f =FUNCT-1R1 (f1 -VALUED-1K47 f2)/RFUNCT-1K1 f"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 f2 /RFUNCT-1K1 f =HIDDENR1 (f1 +VALUED-1K1 f2)/RFUNCT-1K1 f & f1 /RFUNCT-1K1 f -VALUED-1K47 f2 /RFUNCT-1K1 f =HIDDENR1 (f1 -VALUED-1K47 f2)/RFUNCT-1K1 f"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "f1 /RFUNCT-1K1 f +VALUED-1K1 f2 /RFUNCT-1K1 f =HIDDENR1 f1 (#)VALUED-1K19 (f ^RFUNCT-1K4) +VALUED-1K1 f2 /RFUNCT-1K1 f"
      using rfunct_1_th_31 sorry
    also have "... = f1 (#)VALUED-1K19 (f ^RFUNCT-1K4) +VALUED-1K1 f2 (#)VALUED-1K19 (f ^RFUNCT-1K4)"
      using rfunct_1_th_31 sorry
    also have "... = (f1 +VALUED-1K1 f2)(#)VALUED-1K19 (f ^RFUNCT-1K4)"
      using rfunct_1_th_10 sorry
    also have "... = (f1 +VALUED-1K1 f2)/RFUNCT-1K1 f"
      using rfunct_1_th_31 sorry
    finally show "f1 /RFUNCT-1K1 f +VALUED-1K1 f2 /RFUNCT-1K1 f =HIDDENR1 (f1 +VALUED-1K1 f2)/RFUNCT-1K1 f"
       sorry
    have "f1 /RFUNCT-1K1 f -VALUED-1K47 f2 /RFUNCT-1K1 f =HIDDENR1 f1 (#)VALUED-1K19 (f ^RFUNCT-1K4) -VALUED-1K47 f2 /RFUNCT-1K1 f"
      using rfunct_1_th_31 sorry
    also have "... = f1 (#)VALUED-1K19 (f ^RFUNCT-1K4) -VALUED-1K47 f2 (#)VALUED-1K19 (f ^RFUNCT-1K4)"
      using rfunct_1_th_31 sorry
    also have "... = (f1 -VALUED-1K47 f2)(#)VALUED-1K19 (f ^RFUNCT-1K4)"
      using rfunct_1_th_14 sorry
    also have "... = (f1 -VALUED-1K47 f2)/RFUNCT-1K1 f"
      using rfunct_1_th_31 sorry
    finally show "f1 /RFUNCT-1K1 f -VALUED-1K47 f2 /RFUNCT-1K1 f =HIDDENR1 (f1 -VALUED-1K47 f2)/RFUNCT-1K1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_40:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g1 assume [ty]: "g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g) implies (f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      have A2: "domRELAT-1K1 (g ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 g"
        using rfunct_1_th_1 sorry
      assume A3: "c inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g)"
      then have A4: "c inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f) /\\XBOOLE-0K3 domRELAT-1K1 (g1 /RFUNCT-1K1 g)"
        using valued_1_def_1 sorry
      then have A5: "c inHIDDENR3 domRELAT-1K1 (f1 /RFUNCT-1K1 f)"
        using xboole_0_def_4 sorry
      have A6: "c inHIDDENR3 domRELAT-1K1 (g1 /RFUNCT-1K1 g)"
        using A4 xboole_0_def_4 sorry
      have A7: "domRELAT-1K1 (f ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 f"
        using rfunct_1_th_1 sorry
      have A8: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 (f ^RFUNCT-1K4)) /\\XBOOLE-0K3 domRELAT-1K1 (g1 /RFUNCT-1K1 g)"
        using A4 rfunct_1_th_31 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 (f ^RFUNCT-1K4))"
        using xboole_0_def_4 sorry
      then have A9: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using valued_1_def_4 sorry
      then have A10: "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      then have A11: "f .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
        using rfunct_1_th_3 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 (f ^RFUNCT-1K4)) /\\XBOOLE-0K3 domRELAT-1K1 (g1 (#)VALUED-1K19 (g ^RFUNCT-1K4))"
        using A8 rfunct_1_th_31 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (g1 (#)VALUED-1K19 (g ^RFUNCT-1K4))"
        using xboole_0_def_4 sorry
      then have A12: "c inHIDDENR3 domRELAT-1K1 g1 /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using valued_1_def_4 sorry
      then have A13: "c inHIDDENR3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      then have A14: "g .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
        using rfunct_1_th_3 sorry
      have "c inHIDDENR3 domRELAT-1K1 g1"
        using A12 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 g1 /\\XBOOLE-0K3 domRELAT-1K1 f"
        using A10 A7 xboole_0_def_4 sorry
      then have A15: "c inHIDDENR3 domRELAT-1K1 (g1 (#)VALUED-1K19 f)"
        using valued_1_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 f1"
        using A9 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 g"
        using A13 A2 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 g)"
        using valued_1_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\XBOOLE-0K3 domRELAT-1K1 (g1 (#)VALUED-1K19 f)"
        using A15 xboole_0_def_4 sorry
      then have A16: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)"
        using valued_1_def_1 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4) /\\XBOOLE-0K3 domRELAT-1K1 (g ^RFUNCT-1K4)"
        using A10 A13 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 ((f ^RFUNCT-1K4)(#)VALUED-1K19 (g ^RFUNCT-1K4))"
        using valued_1_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 ((f (#)VALUED-1K19 g)^RFUNCT-1K4)"
        using rfunct_1_th_27 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f) /\\XBOOLE-0K3 domRELAT-1K1 ((f (#)VALUED-1K19 g)^RFUNCT-1K4)"
        using A16 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)(#)VALUED-1K19 ((f (#)VALUED-1K19 g)^RFUNCT-1K4))"
        using valued_1_def_4 sorry
      then have A17: "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g))"
        using rfunct_1_th_31 sorry
      have "(f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 (f1 /RFUNCT-1K1 f).FUNCT-1K1 c +XCMPLX-0K2 (g1 /RFUNCT-1K1 g).FUNCT-1K1 c"
        using A3 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 /RFUNCT-1K1 g).FUNCT-1K1 c"
        using A5 rfunct_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 (g1 .FUNCT-1K1 c *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A6 rfunct_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 ((g .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
        using A14 xcmplx_0_def_7 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c *XCMPLX-0K3 ((g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 ((f .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
        using A11 xcmplx_0_def_7 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c *XCMPLX-0K3 f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 ((f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))"
        using xcmplx_1_th_204 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
        using xcmplx_1_th_204 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (g .FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5) +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
        using valued_1_th_5 sorry
      also have "... = (f1 .FUNCT-1K1 c *XCMPLX-0K3 g .FUNCT-1K1 c)*XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 g1 .FUNCT-1K1 c *XCMPLX-0K3 (f .FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 g).FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 .FUNCT-1K1 c *XCMPLX-0K3 f .FUNCT-1K1 c)*XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using valued_1_th_5 sorry
      also have "... = (f1 (#)VALUED-1K19 g).FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5 +XCMPLX-0K2 (g1 (#)VALUED-1K19 f).FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using valued_1_th_5 sorry
      also have "... = ((f1 (#)VALUED-1K19 g).FUNCT-1K1 c +XCMPLX-0K2 (g1 (#)VALUED-1K19 f).FUNCT-1K1 c)*XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
         sorry
      also have "... = (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f).FUNCT-1K1 c *XCMPLX-0K3 ((f (#)VALUED-1K19 g).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A16 valued_1_def_1 sorry
      also have "... = ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)).FUNCT-1K1 c"
        using A17 rfunct_1_def_1 sorry
      finally show "(f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g).FUNCT-1K1 c =HIDDENR1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g) =HIDDENR1 domRELAT-1K1 (f1 /RFUNCT-1K1 f) /\\XBOOLE-0K3 domRELAT-1K1 (g1 /RFUNCT-1K1 g)"
      using valued_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 f)\<^esub> domRELAT-1K1 (g1 /RFUNCT-1K1 g)"
      using rfunct_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using rfunct_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using rfunct_1_th_1 sorry
    also have "... = ((domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 f)\<^esub> domRELAT-1K1 f1)/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g1)"
      using rfunct_1_th_1 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g1))"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g1)"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (((domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 g)/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g1)"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 g)\<^esub> domRELAT-1K1 g1)"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 f)\<^esub> (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 f)\<^esub> domRELAT-1K1 f)/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 f /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g1 /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 g1 /\\XBOOLE-0K3 domRELAT-1K1 f)/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 (g1 (#)VALUED-1K19 f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 (g1 (#)VALUED-1K19 f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })))"
      using xboole_1_th_16 sorry
    also have "... = (domRELAT-1K1 (f1 (#)VALUED-1K19 g) /\\XBOOLE-0K3 domRELAT-1K1 (g1 (#)VALUED-1K19 f))/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> ((domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K9\<^bsub>(domRELAT-1K1 g)\<^esub> (domRELAT-1K1 g \\SUBSET-1K6 g \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }))"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f) /\\SUBSET-1K9\<^bsub>(domRELAT-1K1 (f (#)VALUED-1K19 g))\<^esub> (domRELAT-1K1 (f (#)VALUED-1K19 g) \\SUBSET-1K6 (f (#)VALUED-1K19 g)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_th_2 sorry
    also have "... = domRELAT-1K1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g))"
      using rfunct_1_def_1 sorry
    finally have "domRELAT-1K1 (f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g) =HIDDENR1 domRELAT-1K1 ((f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g))"
       sorry
    thus "f1 /RFUNCT-1K1 f +VALUED-1K1 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g +VALUED-1K1 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_41:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)/RFUNCT-1K1 (f1 /RFUNCT-1K1 g1) =FUNCT-1R1 (f (#)VALUED-1K19 g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4))/RFUNCT-1K1 (g (#)VALUED-1K19 f1)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f /RFUNCT-1K1 g)/RFUNCT-1K1 (f1 /RFUNCT-1K1 g1) =HIDDENR1 (f (#)VALUED-1K19 g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4))/RFUNCT-1K1 (g (#)VALUED-1K19 f1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g1 assume [ty]: "g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "(f /RFUNCT-1K1 g)/RFUNCT-1K1 (f1 /RFUNCT-1K1 g1) =HIDDENR1 (f /RFUNCT-1K1 g)(#)VALUED-1K19 ((f1 /RFUNCT-1K1 g1)^RFUNCT-1K4)"
      using rfunct_1_th_31 sorry
    also have "... = (f /RFUNCT-1K1 g)(#)VALUED-1K19 (g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4) /RFUNCT-1K1 f1)"
      using rfunct_1_th_35 sorry
    also have "... = (f (#)VALUED-1K19 g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4))/RFUNCT-1K1 (g (#)VALUED-1K19 f1)"
      using rfunct_1_th_34 sorry
    finally show "(f /RFUNCT-1K1 g)/RFUNCT-1K1 (f1 /RFUNCT-1K1 g1) =HIDDENR1 (f (#)VALUED-1K19 g1  |RELAT-1K8 domRELAT-1K1 (g1 ^RFUNCT-1K4))/RFUNCT-1K1 (g (#)VALUED-1K19 f1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_42:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f -VALUED-1K47 g1 /RFUNCT-1K1 g =FUNCT-1R1 (f1 (#)VALUED-1K19 g -VALUED-1K47 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 /RFUNCT-1K1 f -VALUED-1K47 g1 /RFUNCT-1K1 g =HIDDENR1 (f1 (#)VALUED-1K19 g -VALUED-1K47 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix g1 assume [ty]: "g1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "f1 /RFUNCT-1K1 f -VALUED-1K47 g1 /RFUNCT-1K1 g =HIDDENR1 f1 /RFUNCT-1K1 f +VALUED-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 g1)/RFUNCT-1K1 g"
      using rfunct_1_th_32 sorry
    also have "... = (f1 (#)VALUED-1K19 g +VALUED-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 g1)(#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
      using rfunct_1_th_40 sorry
    also have "... = (f1 (#)VALUED-1K19 g -VALUED-1K47 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
      using rfunct_1_th_12 sorry
    finally show "f1 /RFUNCT-1K1 f -VALUED-1K47 g1 /RFUNCT-1K1 g =HIDDENR1 (f1 (#)VALUED-1K19 g -VALUED-1K47 g1 (#)VALUED-1K19 f)/RFUNCT-1K1 (f (#)VALUED-1K19 g)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_43:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 /RFUNCT-1K1 f2) =FUNCT-1R1 absVALUED-1K57 f1 /RFUNCT-1K1 absVALUED-1K57 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 (f1 /RFUNCT-1K1 f2) =HIDDENR1 absVALUED-1K57 f1 /RFUNCT-1K1 absVALUED-1K57 f2"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "absVALUED-1K57 (f1 /RFUNCT-1K1 f2) =HIDDENR1 absVALUED-1K57 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4))"
      using rfunct_1_th_31 sorry
    also have "... = absVALUED-1K57 f1 (#)VALUED-1K19 absVALUED-1K57 (f2 ^RFUNCT-1K4)"
      using rfunct_1_th_24 sorry
    also have "... = absVALUED-1K57 f1 (#)VALUED-1K19 (absVALUED-1K57 f2 ^RFUNCT-1K4)"
      using rfunct_1_th_30 sorry
    also have "... = absVALUED-1K57 f1 /RFUNCT-1K1 absVALUED-1K57 f2"
      using rfunct_1_th_31 sorry
    finally show "absVALUED-1K57 (f1 /RFUNCT-1K1 f2) =HIDDENR1 absVALUED-1K57 f1 /RFUNCT-1K1 absVALUED-1K57 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_44:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X & (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2) & (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 +VALUED-1K1 f2  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X & ((f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2 & (f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 +VALUED-1K1 f2  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) implies ((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A4: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A5: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using A3 xboole_0_def_4 sorry
      then have A6: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_1 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2 /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A7: "c inHIDDENR3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "c inHIDDENR3 domRELAT-1K1 f1"
        using A6 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A8: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using A7 xboole_0_def_4 sorry
      then have A9: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2).FUNCT-1K1 c"
        using A2 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A5 valued_1_def_1 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A8 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c +XCMPLX-0K2 (f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A7 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A9 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 X)"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 X))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 ((domRELAT-1K1 f2 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X))"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X)"
       sorry
    thus "(f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2  |RELAT-1K8 X"
      using A1 funct_1_th_2 sorry
    have A10: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) implies ((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X +VALUED-1K1 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A11: "c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X)"
      then have A12: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A13: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A14: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using A12 xboole_0_def_4 sorry
      then have A15: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_1 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 X"
        using A13 xboole_0_def_4 sorry
      then have A16: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "c inHIDDENR3 domRELAT-1K1 f2"
        using A15 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using A16 xboole_0_def_4 sorry
      then have A17: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2).FUNCT-1K1 c"
        using A11 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A14 valued_1_def_1 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A16 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X +VALUED-1K1 f2).FUNCT-1K1 c"
        using A17 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X +VALUED-1K1 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 X"
      using valued_1_def_1 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 domRELAT-1K1 f2"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1  |RELAT-1K8 X +VALUED-1K1 f2)"
       sorry
    thus "(f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X +VALUED-1K1 f2"
      using A10 funct_1_th_2 sorry
    have A18: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) implies ((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A19: "c inHIDDENR3 domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X)"
      then have A20: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A21: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A22: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        using A20 xboole_0_def_4 sorry
      then have A23: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_1 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2 /\\XBOOLE-0K3 X"
        using A21 xboole_0_def_4 sorry
      then have A24: "c inHIDDENR3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "c inHIDDENR3 domRELAT-1K1 f1"
        using A23 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using A24 xboole_0_def_4 sorry
      then have A25: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2  |RELAT-1K8 X)"
        using valued_1_def_1 sorry
      have "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2).FUNCT-1K1 c"
        using A19 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A22 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 (f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A24 funct_1_th_47 sorry
      also have "... = (f1 +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A25 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K1 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 +VALUED-1K1 f2  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 X"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1 +VALUED-1K1 f2  |RELAT-1K8 X)"
      using valued_1_def_1 sorry
    finally have "domRELAT-1K1 ((f1 +VALUED-1K1 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 +VALUED-1K1 f2  |RELAT-1K8 X)"
       sorry
    thus "(f1 +VALUED-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 +VALUED-1K1 f2  |RELAT-1K8 X"
      using A18 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_45:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X & (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2) & (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1 (#)VALUED-1K19 f2  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X & ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2 & (f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1 (#)VALUED-1K19 f2  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) implies ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A4: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        using A3 xboole_0_def_4 sorry
      then have A5: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A6: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "c inHIDDENR3 domRELAT-1K1 f2"
        using A5 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2 /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A7: "c inHIDDENR3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using A2 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A6 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c *XCMPLX-0K3 (f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A7 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 X)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 X))"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 ((domRELAT-1K1 f2 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X))"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X)"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X)"
       sorry
    thus "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2  |RELAT-1K8 X"
      using A1 funct_1_th_2 sorry
    have A8: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) implies ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A9: "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X)"
      then have A10: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_4 sorry
      then have A11: "c inHIDDENR3 domRELAT-1K1 f1"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 X"
        using A10 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 X"
        using A11 xboole_0_def_4 sorry
      then have A12: "c inHIDDENR3 domRELAT-1K1 (f1  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using A9 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = (f1  |RELAT-1K8 X).FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A12 funct_1_th_47 sorry
      also have "... = (f1  |RELAT-1K8 X (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 X"
      using valued_1_def_4 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 domRELAT-1K1 f2"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X) /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2)"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1  |RELAT-1K8 X (#)VALUED-1K19 f2)"
       sorry
    thus "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X (#)VALUED-1K19 f2"
      using A8 funct_1_th_2 sorry
    have A13: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) implies ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A14: "c inHIDDENR3 domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X)"
      then have A15: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        using xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
        using valued_1_def_4 sorry
      then have A16: "c inHIDDENR3 domRELAT-1K1 f2"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 X"
        using A15 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f2 /\\XBOOLE-0K3 X"
        using A16 xboole_0_def_4 sorry
      then have A17: "c inHIDDENR3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c"
        using A14 funct_1_th_47 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using A17 funct_1_th_47 sorry
      also have "... = (f1 (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
        using valued_1_th_5 sorry
      finally show "((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f1 (#)VALUED-1K19 f2  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2)/\\XBOOLE-0K3 X"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 (domRELAT-1K1 f2 /\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f1 (#)VALUED-1K19 f2  |RELAT-1K8 X)"
      using valued_1_def_4 sorry
    finally have "domRELAT-1K1 ((f1 (#)VALUED-1K19 f2) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f1 (#)VALUED-1K19 f2  |RELAT-1K8 X)"
       sorry
    thus "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 X =FUNCT-1R1 f1 (#)VALUED-1K19 f2  |RELAT-1K8 X"
      using A13 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_46:
" for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((-VALUED-1K32 f) |RELAT-1K8 X =FUNCT-1R1 -VALUED-1K32 f  |RELAT-1K8 X & (f ^RFUNCT-1K4) |RELAT-1K8 X =FUNCT-1R1 f  |RELAT-1K8 X ^RFUNCT-1K4) & absVALUED-1K57 f  |RELAT-1K8 X =FUNCT-1R1 absVALUED-1K57 (f  |RELAT-1K8 X)"
proof-
  have " for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (-VALUED-1K32 f) |RELAT-1K8 X =FUNCT-1R1 -VALUED-1K32 f  |RELAT-1K8 X & ((f ^RFUNCT-1K4) |RELAT-1K8 X =FUNCT-1R1 f  |RELAT-1K8 X ^RFUNCT-1K4 & absVALUED-1K57 f  |RELAT-1K8 X =FUNCT-1R1 absVALUED-1K57 (f  |RELAT-1K8 X))"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((-VALUED-1K32 f) |RELAT-1K8 X) implies ((-VALUED-1K32 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (-VALUED-1K32 f  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((-VALUED-1K32 f) |RELAT-1K8 X)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (-VALUED-1K32 f) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have "c inHIDDENR3 domRELAT-1K1 (-VALUED-1K32 f)"
        using xboole_0_def_4 sorry
      then have A4: "c inHIDDENR3 domRELAT-1K1 f"
        using valued_1_th_8 sorry
      have "c inHIDDENR3 X"
        using A3 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A5: "c inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "((-VALUED-1K32 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (-VALUED-1K32 f).FUNCT-1K1 c"
        using A2 funct_1_th_47 sorry
      also have "... = -XCMPLX-0K4 f .FUNCT-1K1 c"
        using valued_1_th_8 sorry
      also have "... = -XCMPLX-0K4 (f  |RELAT-1K8 X).FUNCT-1K1 c"
        using A5 funct_1_th_47 sorry
      also have "... = (-VALUED-1K32 f  |RELAT-1K8 X).FUNCT-1K1 c"
        using valued_1_th_8 sorry
      finally show "((-VALUED-1K32 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (-VALUED-1K32 f  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((-VALUED-1K32 f) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (-VALUED-1K32 f) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using valued_1_th_8 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (-VALUED-1K32 f  |RELAT-1K8 X)"
      using valued_1_th_8 sorry
    finally have "domRELAT-1K1 ((-VALUED-1K32 f) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (-VALUED-1K32 f  |RELAT-1K8 X)"
       sorry
    thus "(-VALUED-1K32 f) |RELAT-1K8 X =FUNCT-1R1 -VALUED-1K32 f  |RELAT-1K8 X"
      using A1 funct_1_th_2 sorry
    have A6: "domRELAT-1K1 ((f ^RFUNCT-1K4) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f ^RFUNCT-1K4) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = (domRELAT-1K1 f \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })/\\SUBSET-1K8\<^bsub>(domRELAT-1K1 f)\<^esub> X"
      using rfunct_1_def_2 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 X \\SUBSET-1K6 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 } /\\XBOOLE-0K3 X"
      using xboole_1_th_50 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X) \\SUBSET-1K6 X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X) \\SUBSET-1K6 (f  |RELAT-1K8 X)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using funct_1_th_70 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X ^RFUNCT-1K4)"
      using rfunct_1_def_2 sorry
    finally have "domRELAT-1K1 ((f ^RFUNCT-1K4) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (f  |RELAT-1K8 X ^RFUNCT-1K4)"
       sorry
    have A7: "domRELAT-1K1 (f  |RELAT-1K8 X ^RFUNCT-1K4) c=TARSKIR1 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using rfunct_1_th_1 sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((f ^RFUNCT-1K4) |RELAT-1K8 X) implies ((f ^RFUNCT-1K4) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 X ^RFUNCT-1K4).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A8: "c inHIDDENR3 domRELAT-1K1 ((f ^RFUNCT-1K4) |RELAT-1K8 X)"
      then have "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A9: "c inHIDDENR3 domRELAT-1K1 (f ^RFUNCT-1K4)"
        using xboole_0_def_4 sorry
      have "((f ^RFUNCT-1K4) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f ^RFUNCT-1K4).FUNCT-1K1 c"
        using A8 funct_1_th_47 sorry
      also have "... = (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A9 rfunct_1_def_2 sorry
      also have "... = ((f  |RELAT-1K8 X).FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A7 A6 A8 funct_1_th_47 sorry
      also have "... = (f  |RELAT-1K8 X ^RFUNCT-1K4).FUNCT-1K1 c"
        using A6 A8 rfunct_1_def_2 sorry
      finally show "((f ^RFUNCT-1K4) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (f  |RELAT-1K8 X ^RFUNCT-1K4).FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "(f ^RFUNCT-1K4) |RELAT-1K8 X =FUNCT-1R1 f  |RELAT-1K8 X ^RFUNCT-1K4"
      using A6 funct_1_th_2 sorry
    have A10: "domRELAT-1K1 (absVALUED-1K57 f  |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 absVALUED-1K57 f /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using valued_1_def_11 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 absVALUED-1K57 (f  |RELAT-1K8 X)"
      using valued_1_def_11 sorry
    finally have "domRELAT-1K1 (absVALUED-1K57 f  |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 absVALUED-1K57 (f  |RELAT-1K8 X)"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (absVALUED-1K57 f  |RELAT-1K8 X) implies (absVALUED-1K57 f  |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 absVALUED-1K57 (f  |RELAT-1K8 X) .FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A11: "c inHIDDENR3 domRELAT-1K1 (absVALUED-1K57 f  |RELAT-1K8 X)"
      then have A12: "c inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
        using A10 valued_1_def_11 sorry
      have "(absVALUED-1K57 f  |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 absVALUED-1K57 f .FUNCT-1K1 c"
        using A11 funct_1_th_47 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (f  |RELAT-1K8 X).FUNCT-1K1 c.|"
        using A12 funct_1_th_47 sorry
      also have "... = absVALUED-1K57 (f  |RELAT-1K8 X) .FUNCT-1K1 c"
        using valued_1_th_18 sorry
      finally show "(absVALUED-1K57 f  |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 absVALUED-1K57 (f  |RELAT-1K8 X) .FUNCT-1K1 c"
         sorry
    qed "sorry"
    thus "absVALUED-1K57 f  |RELAT-1K8 X =FUNCT-1R1 absVALUED-1K57 (f  |RELAT-1K8 X)"
      using A10 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_47:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2  |RELAT-1K8 X & (f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2) & (f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1 -VALUED-1K47 f2  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X -VALUED-1K47 f2  |RELAT-1K8 X & ((f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2 & (f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1 -VALUED-1K47 f2  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "(f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X +VALUED-1K1 (-VALUED-1K32 f2) |RELAT-1K8 X"
      using rfunct_1_th_44 sorry
    also have "... = f1  |RELAT-1K8 X -VALUED-1K47 f2  |RELAT-1K8 X"
      using rfunct_1_th_46 sorry
    finally show "(f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X -VALUED-1K47 f2  |RELAT-1K8 X"
       sorry
    show "(f1 -VALUED-1K47 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X -VALUED-1K47 f2"
      using rfunct_1_th_44 sorry
    have "(f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1 +VALUED-1K1 (-VALUED-1K32 f2) |RELAT-1K8 X"
      using rfunct_1_th_44 sorry
    also have "... = f1 -VALUED-1K47 f2  |RELAT-1K8 X"
      using rfunct_1_th_46 sorry
    finally show "(f1 -VALUED-1K47 f2) |RELAT-1K8 X =HIDDENR1 f1 -VALUED-1K47 f2  |RELAT-1K8 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_48:
" for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds ((f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2  |RELAT-1K8 X & (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2) & (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =FUNCT-1R1 f1 /RFUNCT-1K1 f2  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2  |RELAT-1K8 X & ((f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2 & (f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1 /RFUNCT-1K1 f2  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4)) |RELAT-1K8 X"
      using rfunct_1_th_31 sorry
    also have "... = f1  |RELAT-1K8 X (#)VALUED-1K19 (f2 ^RFUNCT-1K4) |RELAT-1K8 X"
      using rfunct_1_th_45 sorry
    also have "... = f1  |RELAT-1K8 X (#)VALUED-1K19 (f2  |RELAT-1K8 X ^RFUNCT-1K4)"
      using rfunct_1_th_46 sorry
    also have "... = f1  |RELAT-1K8 X /RFUNCT-1K1 f2  |RELAT-1K8 X"
      using rfunct_1_th_31 sorry
    finally show "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2  |RELAT-1K8 X"
       sorry
    have "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4)) |RELAT-1K8 X"
      using rfunct_1_th_31 sorry
    also have "... = f1  |RELAT-1K8 X (#)VALUED-1K19 (f2 ^RFUNCT-1K4)"
      using rfunct_1_th_45 sorry
    also have "... = f1  |RELAT-1K8 X /RFUNCT-1K1 f2"
      using rfunct_1_th_31 sorry
    finally show "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1  |RELAT-1K8 X /RFUNCT-1K1 f2"
       sorry
    have "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 (f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4)) |RELAT-1K8 X"
      using rfunct_1_th_31 sorry
    also have "... = f1 (#)VALUED-1K19 (f2 ^RFUNCT-1K4) |RELAT-1K8 X"
      using rfunct_1_th_45 sorry
    also have "... = f1 (#)VALUED-1K19 (f2  |RELAT-1K8 X ^RFUNCT-1K4)"
      using rfunct_1_th_46 sorry
    also have "... = f1 /RFUNCT-1K1 f2  |RELAT-1K8 X"
      using rfunct_1_th_31 sorry
    finally show "(f1 /RFUNCT-1K1 f2) |RELAT-1K8 X =HIDDENR1 f1 /RFUNCT-1K1 f2  |RELAT-1K8 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_49:
" for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K25 f) |RELAT-1K8 X =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds (r (#)VALUED-1K25 f) |RELAT-1K8 X =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 X"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 ((r (#)VALUED-1K25 f) |RELAT-1K8 X) implies ((r (#)VALUED-1K25 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f  |RELAT-1K8 X).FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A2: "c inHIDDENR3 domRELAT-1K1 ((r (#)VALUED-1K25 f) |RELAT-1K8 X)"
      then have A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A4: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have A5: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        using A3 xboole_0_def_4 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f"
        using valued_1_def_5 sorry
      then have "c inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A6: "c inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      then have A7: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f  |RELAT-1K8 X)"
        using valued_1_def_5 sorry
      have "((r (#)VALUED-1K25 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f).FUNCT-1K1 c"
        using A2 funct_1_th_47 sorry
      also have "... = r *XCMPLX-0K3 f .FUNCT-1K1 c"
        using A5 valued_1_def_5 sorry
      also have "... = r *XCMPLX-0K3 (f  |RELAT-1K8 X).FUNCT-1K1 c"
        using A6 funct_1_th_47 sorry
      also have "... = (r (#)VALUED-1K25 f  |RELAT-1K8 X).FUNCT-1K1 c"
        using A7 valued_1_def_5 sorry
      finally show "((r (#)VALUED-1K25 f) |RELAT-1K8 X).FUNCT-1K1 c =HIDDENR1 (r (#)VALUED-1K25 f  |RELAT-1K8 X).FUNCT-1K1 c"
         sorry
    qed "sorry"
    have "domRELAT-1K1 ((r (#)VALUED-1K25 f) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using valued_1_def_5 sorry
    also have "... = domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    also have "... = domRELAT-1K1 (r (#)VALUED-1K25 f  |RELAT-1K8 X)"
      using valued_1_def_5 sorry
    finally have "domRELAT-1K1 ((r (#)VALUED-1K25 f) |RELAT-1K8 X) =HIDDENR1 domRELAT-1K1 (r (#)VALUED-1K25 f  |RELAT-1K8 X)"
       sorry
    thus "(r (#)VALUED-1K25 f) |RELAT-1K8 X =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 X"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve r, r1, r2, p for "RealXREAL-0M1"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
mtheorem rfunct_1_th_50:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)) & (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule conjMI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
           sorry
        assume "f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
           sorry
        then have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
          using valued_1_def_1 sorry
        then have A2: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using xboole_1_th_17 sorry
        have Cut1530: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
          using A1 xboole_1_th_17 sorry
        have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        proof-
          show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
            using A2 Cut1530 sorry
        qed
        thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using partfun1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
      proof(rule conjMI,rule impI)
        show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
           sorry
        assume "f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
           sorry
        then have A3: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
          using valued_1_th_12 sorry
        then have A4: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
          using xboole_1_th_17 sorry
        have Cut1542: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
          using A3 xboole_1_th_17 sorry
        have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        proof-
          show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
            using A4 Cut1542 sorry
        qed
        thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using partfun1_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
       sorry
    assume "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    then have A5: "domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
      using valued_1_def_4 sorry
    then have A6: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using xboole_1_th_17 sorry
    have Cut1552: "C c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
      using A5 xboole_1_th_17 sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
    proof-
      show "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using A6 Cut1552 sorry
    qed
    thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_51:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_5 sorry

mtheorem rfunct_1_th_52:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff -VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using rfunct_1_th_51 sorry

mtheorem rfunct_1_th_53:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  using valued_1_def_11 sorry

mtheorem rfunct_1_th_54:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    show "f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof(rule impI,rule conjMI)
      assume "f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      then have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 C"
         sorry
      have "f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 C"
         sorry
      then have "f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A1 rfunct_1_def_2 sorry
      thus "f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_1_th_38 sorry
      then have Cut1578: "C =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> {}XBOOLE-0K1"
        using A1 rfunct_1_def_2 sorry
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C"
      proof-
        show "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C"
          using Cut1578 sorry
      qed
      thus "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        using partfun1_def_2 sorry
    qed
    assume A2: "f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A3: "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =HIDDENR1 C"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f \\SUBSET-1K7\<^bsub>(C)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      also have "... = C"
        using A2 A3 sorry
      finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) =HIDDENR1 C"
         sorry
    qed
    thus "f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using partfun1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_55:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> iff f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) & (f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & (f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    show "(f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    proof-
      have "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & (f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>) implies f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      proof(rule impMI ,rule impMI ,rule impI)
        assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          and A2: "f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
          and A3: "f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
        have "f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using A2 A3 rfunct_1_th_54 sorry
        then have "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using A1 sorry
        thus "f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
          using rfunct_1_th_31 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have A4: "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using rfunct_1_th_31 sorry
    thus "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using rfunct_1_th_50 sorry
    have "f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A4 rfunct_1_th_50 sorry
    thus "f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using rfunct_1_th_54 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_56:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies ((f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c & (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c & ((f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      and A2: "f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    have "f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 A2 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
      using valued_1_def_1 sorry
    have "f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 A2 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
      using valued_1_th_13 sorry
    show "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
      using valued_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_57:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    assume "f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    then have "r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
       sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 C"
       sorry
    thus "(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
      using valued_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_58:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 -XCMPLX-0K4 f .FUNCT-1K1 c & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
  using valued_1_th_8 valued_1_th_18 sorry

mtheorem rfunct_1_th_59:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub>).FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
  using rfunct_1_def_2 sorry

mtheorem rfunct_1_th_60:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub> & f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub> implies (f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    assume A1: "f1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      and A2: "f2 ^RFUNCT-1K6\<^bsub>(C,REALNUMBERSK2)\<^esub> be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    have A3: "f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A2 rfunct_1_th_54 sorry
    have "f2 \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      using A2 rfunct_1_th_54 sorry
    then have "f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2 be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
      using A1 A3 rfunct_1_th_55 sorry
    then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 C"
       sorry
    thus "(f1 /RFUNCT-1K3\<^bsub>(C,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =COMPLEX1R1 f1 .FUNCT-1K1 c *XCMPLX-0K3 (f2 .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
      using rfunct_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RFUNCT_1K7("chiRFUNCT-1K7'( _ , _ ')" [0,0]228) where
  "chiRFUNCT-1K7(X,C) \<equiv> chiFUNCT-3K4(X,C)"

mtheorem rfunct_1_add_5:
  mlet "X be setHIDDENM2", "C be setHIDDENM2"
"cluster chiFUNCT-3K4(X,C) as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "chiFUNCT-3K4(X,C) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>({TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })\<^esub> (chiFUNCT-3K5(X,C)) implies x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A1: "rngRELSET-1K2\<^bsub>({TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M })\<^esub> (chiFUNCT-3K5(X,C)) c=MEMBEREDR6 REALNUMBERSK2"
       sorry
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (chiFUNCT-3K5(X,C)) =XBOOLE-0R4 C"
      using funct_3_def_3 sorry
    thus "chiFUNCT-3K4(X,C) be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using A1 relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_5:
  mlet "X be setHIDDENM2", "C be setHIDDENM2"
"cluster chiRFUNCT-1K7(X,C) as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 chiRFUNCT-1K7(X,C) implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using funct_3_def_3 sorry
qed "sorry"

mtheorem rfunct_1_th_61:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C) iff domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C & ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6))"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C) implies domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C & ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6))) & (domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C & ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6)) implies f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    show "f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C) implies domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C & ( for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6))"
      using funct_3_def_3 sorry
    assume A1: "domRELSET-1K1\<^bsub>(C)\<^esub> f =XBOOLE-0R4 C"
      and A2: " for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M) & ( not c inTARSKIR2 X implies f .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 C implies (x inHIDDENR3 X implies f .FUNCT-1K1 x =COMPLEX1R1 \<one>\<^sub>M) & ( not x inHIDDENR3 X implies f .FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6)"
      using A2 sorry
    thus "f =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X,C)"
      using A1 funct_3_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_62:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds chiRFUNCT-1K7(X,C) be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
   sorry

mtheorem rfunct_1_th_63:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_64:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  not c inTARSKIR2 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_65:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 C \\SUBSET-1K6 X iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds (c inTARSKIR2 C \\SUBSET-1K6 X implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6) & (chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 implies c inTARSKIR2 C \\SUBSET-1K6 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    show "c inTARSKIR2 C \\SUBSET-1K6 X implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
    proof(rule impI)
      assume "c inTARSKIR2 C \\SUBSET-1K6 X"
      then have " not c inTARSKIR2 X"
        using xboole_0_def_5 sorry
      thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using rfunct_1_th_61 sorry
    qed
    assume "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
    then have " not c inTARSKIR2 X"
      using rfunct_1_th_61 sorry
    thus "c inTARSKIR2 C \\SUBSET-1K6 X"
      using xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_66:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds chiRFUNCT-1K7(C,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_67:
" for X be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds chiRFUNCT-1K7(X,C) .FUNCT-1K1 c <>HIDDENR2 \<one>\<^sub>M iff chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
  using rfunct_1_th_61 sorry

mtheorem rfunct_1_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds X missesXBOOLE-0R1 Y implies chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not (X missesXBOOLE-0R1 Y &  not chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C)"
    proof(rule impI)
      assume A1: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      have A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) implies (chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)).FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C))"
        have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
        proof-
          show "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
          proof-
            have cases: "c inTARSKIR2 X or  not c inTARSKIR2 X"
               sorry
            have case1: "c inTARSKIR2 X implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
            proof(rule impI)
              assume A4: "c inTARSKIR2 X"
              then have " not c inTARSKIR2 Y"
                using A1 xboole_0_def_4 sorry
              then have A5: "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                using rfunct_1_th_61 sorry
              have A6: "c inTARSKIR2 X \\/XBOOLE-0K2 Y"
                using A4 xboole_0_def_3 sorry
              have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
                using A4 rfunct_1_th_61 sorry
              thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                using A5 A6 rfunct_1_th_61 sorry
            qed
            have case2: " not c inTARSKIR2 X implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
            proof(rule impI)
              assume A7: " not c inTARSKIR2 X"
              then have A8: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                using rfunct_1_th_61 sorry
              have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
              proof-
                show "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                proof-
                  have cases: "c inTARSKIR2 Y or  not c inTARSKIR2 Y"
                     sorry
                  have case1: "c inTARSKIR2 Y implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                  proof(rule impI)
                    assume A9: "c inTARSKIR2 Y"
                    then have A10: "c inTARSKIR2 X \\/XBOOLE-0K2 Y"
                      using xboole_0_def_3 sorry
                    have "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
                      using A9 rfunct_1_th_61 sorry
                    thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                      using A8 A10 rfunct_1_th_61 sorry
                  qed
                  have case2: " not c inTARSKIR2 Y implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                  proof(rule impI)
                    assume A11: " not c inTARSKIR2 Y"
                    then have A12: " not c inTARSKIR2 X \\/XBOOLE-0K2 Y"
                      using A7 xboole_0_def_3 sorry
                    have "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                      using A11 rfunct_1_th_61 sorry
                    thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                      using A8 A12 rfunct_1_th_61 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c +XCMPLX-0K2 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "(chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)).FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C) .FUNCT-1K1 c"
          using A3 valued_1_def_1 sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(Y,C))"
        using valued_1_def_1 sorry
      also have "... = C /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(Y,C))"
        using rfunct_1_th_61 sorry
      also have "... = C /\\XBOOLE-0K3 C"
        using rfunct_1_th_61 sorry
      also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C))"
        using rfunct_1_th_61 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C))"
         sorry
      thus "chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C)"
        using A2 partfun1_th_5 sorry
    qed
    thus " not (X missesXBOOLE-0R1 Y &  not chiRFUNCT-1K7(X,C) +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X \\/XBOOLE-0K2 Y,C))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_69:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    have A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) implies (chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)).FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C))"
      have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
      proof-
        show "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
        proof-
          have cases: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 or chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
          proof(rule impI)
            assume A2: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
            have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
            proof-
              show "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
              proof-
                have cases: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 or chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                  using A2 sorry
                have case1: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
                proof(rule impI)
                  assume "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                  then have " not c inTARSKIR2 X"
                    using rfunct_1_th_61 sorry
                  then have " not c inTARSKIR2 X /\\XBOOLE-0K3 Y"
                    using xboole_0_def_4 sorry
                  thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
                    using A2 rfunct_1_th_61 sorry
                qed
                have case2: "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
                proof(rule impI)
                  assume "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
                  then have " not c inTARSKIR2 Y"
                    using rfunct_1_th_61 sorry
                  then have " not c inTARSKIR2 X /\\XBOOLE-0K3 Y"
                    using xboole_0_def_4 sorry
                  thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
                    using A2 rfunct_1_th_61 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
               sorry
          qed
          have case2: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6 implies chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
          proof(rule impI)
            assume A3: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
            then have A4: "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
               sorry
            then have A5: "chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
              using rfunct_1_th_67 sorry
            have A6: "c inTARSKIR2 Y"
              using A4 rfunct_1_th_61 sorry
            have A7: "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c <>HIDDENR2 0NUMBERSK6"
              using A3 sorry
            then have "c inTARSKIR2 X"
              using rfunct_1_th_61 sorry
            then have A8: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
              using A6 xboole_0_def_4 sorry
            have "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c =COMPLEX1R1 \<one>\<^sub>M"
              using A7 rfunct_1_th_67 sorry
            thus "chiRFUNCT-1K7(X,C) .FUNCT-1K1 c *XCMPLX-0K3 chiRFUNCT-1K7(Y,C) .FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
              using A5 A8 rfunct_1_th_61 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)).FUNCT-1K1 c =COMPLEX1R1 chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C) .FUNCT-1K1 c"
        using valued_1_th_5 sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C)) /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(Y,C))"
      using valued_1_def_4 sorry
    also have "... = C /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(Y,C))"
      using rfunct_1_th_61 sorry
    also have "... = C /\\XBOOLE-0K3 C"
      using rfunct_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C))"
      using rfunct_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C)) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> (chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C))"
       sorry
    thus "chiRFUNCT-1K7(X,C) (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(Y,C) =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> chiRFUNCT-1K7(X /\\XBOOLE-0K3 Y,C)"
      using A1 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f for "real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
mtheorem rfunct_1_th_70:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r)"
proof-
  have " for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r)) & (( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r) implies f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r)"
    proof-
      have " not (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & ( for r be RealXREAL-0M1 holds  not ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f &  not f .FUNCT-1K1 c <=XXREAL-0R1 r))))"
      proof-
        have "( ex r be RealXREAL-0M1 st  for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies (f  |RELAT-1K8 Y).FUNCT-1K1 p <XXREAL-0R3 r) implies ( ex tVar1 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 tVar1)"
        proof(rule impI)
          assume Given: " ex r be RealXREAL-0M1 st  for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies (f  |RELAT-1K8 Y).FUNCT-1K1 p <XXREAL-0R3 r"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A1: " for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies (f  |RELAT-1K8 Y).FUNCT-1K1 p <XXREAL-0R3 r"
             sorry
          show " ex tVar1 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 tVar1"
          proof(rule bexI[of _ "r"],rule ballI,rule impI)
            fix c assume [ty]: "c be objectHIDDENM1"
            assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
            then have A2: "c inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
              using relat_1_th_61 sorry
            then have "(f  |RELAT-1K8 Y).FUNCT-1K1 c <XXREAL-0R3 r"
              using A1 sorry
            thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
              using A2 funct_1_th_47 sorry
          qed "sorry"
        qed
        thus " not (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & ( for r be RealXREAL-0M1 holds  not ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f &  not f .FUNCT-1K1 c <=XXREAL-0R1 r))))"
          using seq_2_def_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
       sorry
    obtain r1 where 
      [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = r +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    have " for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies  not r1 <=XXREAL-0R1 (f  |RELAT-1K8 Y).FUNCT-1K1 p"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be objectHIDDENM1"
      assume A4: "p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
      then have "p inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
        using relat_1_th_61 sorry
      then have "f .FUNCT-1K1 p <=XXREAL-0R1 r"
        using A3 sorry
      then have A5: "(f  |RELAT-1K8 Y).FUNCT-1K1 p <=XXREAL-0R1 r"
        using A4 funct_1_th_47 sorry
      have "r <XXREAL-0R3 r1"
        using xreal_1_th_29 sorry
      thus " not r1 <=XXREAL-0R1 (f  |RELAT-1K8 Y).FUNCT-1K1 p"
        using A5 xxreal_0_th_2 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
      using bexI[of _ "r1"] seq_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_71:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c)"
proof-
  have " for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c)) & (( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c) implies f  |RELAT-1K8 Y be bounded-belowSEQ-2V2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c)"
    proof-
      have " not (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & ( for r be RealXREAL-0M1 holds  not ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f &  not r <=XXREAL-0R1 f .FUNCT-1K1 c))))"
      proof-
        have "( ex r be RealXREAL-0M1 st  for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies r <XXREAL-0R3 (f  |RELAT-1K8 Y).FUNCT-1K1 p) implies ( ex tVar3 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies tVar3 <=XXREAL-0R1 f .FUNCT-1K1 c)"
        proof(rule impI)
          assume Given: " ex r be RealXREAL-0M1 st  for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies r <XXREAL-0R3 (f  |RELAT-1K8 Y).FUNCT-1K1 p"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A1: " for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies r <XXREAL-0R3 (f  |RELAT-1K8 Y).FUNCT-1K1 p"
             sorry
          show " ex tVar3 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies tVar3 <=XXREAL-0R1 f .FUNCT-1K1 c"
          proof(rule bexI[of _ "r"],rule ballI,rule impI)
            fix c assume [ty]: "c be objectHIDDENM1"
            assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
            then have A2: "c inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
              using relat_1_th_61 sorry
            then have "r <XXREAL-0R3 (f  |RELAT-1K8 Y).FUNCT-1K1 c"
              using A1 sorry
            thus "r <=XXREAL-0R1 f .FUNCT-1K1 c"
              using A2 funct_1_th_47 sorry
          qed "sorry"
        qed
        thus " not (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & ( for r be RealXREAL-0M1 holds  not ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f &  not r <=XXREAL-0R1 f .FUNCT-1K1 c))))"
          using seq_2_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
       sorry
    obtain r1 where 
      [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = r -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    have " for p be objectHIDDENM1 holds p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y) implies  not (f  |RELAT-1K8 Y).FUNCT-1K1 p <=XXREAL-0R1 r1"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be objectHIDDENM1"
      assume A4: "p inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 Y)"
      then have "p inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
        using relat_1_th_61 sorry
      then have "r <=XXREAL-0R1 f .FUNCT-1K1 p"
        using A3 sorry
      then have A5: "r <=XXREAL-0R1 (f  |RELAT-1K8 Y).FUNCT-1K1 p"
        using A4 funct_1_th_47 sorry
      have "r1 <XXREAL-0R3 r"
        using xreal_1_th_44 sorry
      thus " not (f  |RELAT-1K8 Y).FUNCT-1K1 p <=XXREAL-0R1 r1"
        using A5 xxreal_0_th_2 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
      using bexI[of _ "r1"] seq_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_72:
" for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be boundedSEQ-2V6 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
proof-
  have " for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f be boundedSEQ-2V6 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)) & (( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r) implies f be boundedSEQ-2V6)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f be boundedSEQ-2V6 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
    proof-
      have "f be boundedSEQ-2V6 implies ( ex g be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g)"
      proof(rule impI)
        assume A1: "f be boundedSEQ-2V6"
        then obtain r1 where
          [ty]:"r1 be RealXREAL-0M1" and 
          A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c <XXREAL-0R3 r1"
          using seq_2_def_1 sorry
        obtain r2 where
          [ty]:"r2 be RealXREAL-0M1" and 
          A3: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies r2 <XXREAL-0R3 f .FUNCT-1K1 c"
          using A1 seq_2_def_2 sorry
        obtain g where 
          [ty]:"g be setHIDDENM2" and gDef:"g =  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
           sorry
        show " ex g be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g"
        proof(rule bexI[of _ "g"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A4: "c inHIDDENR3 domRELAT-1K1 f"
          have A5: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
            using complex1_th_46 sorry
          have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 sorry
          then have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using A2 A4 xxreal_0_th_2 sorry
          then have A6: "f .FUNCT-1K1 c +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
            using A5 xreal_1_th_7 sorry
          have A7: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using complex1_th_46 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
            using absvalue_th_4 sorry
          then have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A3 A4 xxreal_0_th_2 sorry
          then have A8: "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 f .FUNCT-1K1 c"
            using A7 xreal_1_th_7 sorry
          have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) =COMPLEX1R1 -XCMPLX-0K4 g"
             sorry
          thus " |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g"
            using A6 A8 absvalue_th_5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A9: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
       sorry
    have "f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2"
    proof(rule conjMI)
      show "f be bounded-aboveSEQ-2V1"
      proof-
        have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  not r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 f .FUNCT-1K1 c"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "c inHIDDENR3 domRELAT-1K1 f"
          then have A10: " |.COMPLEX1K10 f .FUNCT-1K1 c.| <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
            using A9 xreal_1_th_39 sorry
          have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
            using absvalue_th_4 sorry
          thus " not r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A10 xxreal_0_th_2 sorry
        qed "sorry"
        thus "f be bounded-aboveSEQ-2V1"
          using bexI[of _ "r +XCMPLX-0K2 \<one>\<^sub>M"] seq_2_def_1 sorry
      qed
      have " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  not f .FUNCT-1K1 c <=XXREAL-0R1 -XCMPLX-0K4 (r +XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 domRELAT-1K1 f"
        then have " |.COMPLEX1K10 f .FUNCT-1K1 c.| <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M"
          using A9 xreal_1_th_39 sorry
        then have A11: "-XCMPLX-0K4 (r +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 -XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
          using xreal_1_th_24 sorry
        have "-XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 f .FUNCT-1K1 c"
          using absvalue_th_4 sorry
        thus " not f .FUNCT-1K1 c <=XXREAL-0R1 -XCMPLX-0K4 (r +XCMPLX-0K2 \<one>\<^sub>M)"
          using A11 xxreal_0_th_2 sorry
      qed "sorry"
      thus "f be bounded-belowSEQ-2V2"
        using bexI[of _ "-XCMPLX-0K4 (r +XCMPLX-0K2 \<one>\<^sub>M)"] seq_2_def_2 sorry
    qed
    thus "f be boundedSEQ-2V6"
      using seq_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_73:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 iff ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
proof-
  have " for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be boundedSEQ-2V6 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)) & (( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r) implies f  |RELAT-1K8 Y be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show "f  |RELAT-1K8 Y be boundedSEQ-2V6 implies ( ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r)"
    proof-
      have "f  |RELAT-1K8 Y be boundedSEQ-2V6 implies ( ex g be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g)"
      proof(rule impI)
        assume A1: "f  |RELAT-1K8 Y be boundedSEQ-2V6"
        then obtain r1 where
          [ty]:"r1 be RealXREAL-0M1" and 
          A2: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r1"
          using rfunct_1_th_70 sorry
        obtain r2 where
          [ty]:"r2 be RealXREAL-0M1" and 
          A3: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
          using A1 rfunct_1_th_71 sorry
        obtain g where 
          [ty]:"g be setHIDDENM2" and gDef:"g =  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
           sorry
        show " ex g be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g"
        proof(rule bexI[of _ "g"],rule ballI,rule impI)
          have A4: "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 sorry
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A5: "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
          have "f .FUNCT-1K1 c <=XXREAL-0R1 r1"
            using A2 A5 sorry
          then have A6: "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using A4 xxreal_0_th_2 sorry
          have A7: "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
            using absvalue_th_4 sorry
          have "r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A3 A5 sorry
          then have A8: "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A7 xxreal_0_th_2 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using complex1_th_46 sorry
          then have A9: "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 f .FUNCT-1K1 c"
            using A8 xreal_1_th_7 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
            using complex1_th_46 sorry
          then have A10: "f .FUNCT-1K1 c +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
            using A6 xreal_1_th_7 sorry
          have "(-XCMPLX-0K4  |.COMPLEX1K10 r1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 r2.|) =COMPLEX1R1 -XCMPLX-0K4 g"
             sorry
          thus " |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 g"
            using A10 A9 absvalue_th_5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A11: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
       sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies -XCMPLX-0K4 r <=XXREAL-0R1 f .FUNCT-1K1 c"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
      then have " |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
        using A11 sorry
      then have A12: "-XCMPLX-0K4 r <=XXREAL-0R1 -XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using xreal_1_th_24 sorry
      have "-XCMPLX-0K4  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 f .FUNCT-1K1 c"
        using absvalue_th_4 sorry
      thus "-XCMPLX-0K4 r <=XXREAL-0R1 f .FUNCT-1K1 c"
        using A12 xxreal_0_th_2 sorry
    qed "sorry"
    then have A13: "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
      using rfunct_1_th_71 sorry
    have " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
      then have A14: " |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r"
        using A11 sorry
      have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using absvalue_th_4 sorry
      thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
        using A14 xxreal_0_th_2 sorry
    qed "sorry"
    then have "f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
      using rfunct_1_th_70 sorry
    thus "f  |RELAT-1K8 Y be boundedSEQ-2V6"
      using A13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_74:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1) & (Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 Y be bounded-belowSEQ-2V2)) & (Y c=TARSKIR1 X & f  |RELAT-1K8 X be boundedSEQ-2V6 implies f  |RELAT-1K8 Y be boundedSEQ-2V6)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1) & ((Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 Y be bounded-belowSEQ-2V2) & (Y c=TARSKIR1 X & f  |RELAT-1K8 X be boundedSEQ-2V6 implies f  |RELAT-1K8 Y be boundedSEQ-2V6))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    show A1: "Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
    proof(rule impMI ,rule impI)
      assume A2: "Y c=TARSKIR1 X"
        and A3: "f  |RELAT-1K8 X be bounded-aboveSEQ-2V1"
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A4: " for c be objectHIDDENM1 holds c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
        using A3 rfunct_1_th_70 sorry
      have " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
      proof-
        show " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A5: "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
          then have A6: "c inHIDDENR3 domRELAT-1K1 f"
            using xboole_0_def_4 sorry
          have "c inHIDDENR3 Y"
            using A5 xboole_0_def_4 sorry
          then have "c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
            using A2 A6 xboole_0_def_4 sorry
          thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
            using A4 sorry
        qed "sorry"
      qed
      thus "f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
        using rfunct_1_th_70 sorry
    qed
    show A7: "Y c=TARSKIR1 X & f  |RELAT-1K8 X be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
    proof(rule impMI ,rule impI)
      assume A8: "Y c=TARSKIR1 X"
        and A9: "f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A10: " for c be objectHIDDENM1 holds c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
        using A9 rfunct_1_th_71 sorry
      have " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
      proof-
        show " ex r be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A11: "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
          then have A12: "c inHIDDENR3 domRELAT-1K1 f"
            using xboole_0_def_4 sorry
          have "c inHIDDENR3 Y"
            using A11 xboole_0_def_4 sorry
          then have "c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
            using A8 A12 xboole_0_def_4 sorry
          thus "r <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A10 sorry
        qed "sorry"
      qed
      thus "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
        using rfunct_1_th_71 sorry
    qed
    assume A13: "Y c=TARSKIR1 X"
      and A14: "f  |RELAT-1K8 X be boundedSEQ-2V6"
    show "f  |RELAT-1K8 Y be boundedSEQ-2V6"
      using A1 A7 A13 A14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_75:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 X be bounded-aboveSEQ-2V1"
      and A2: "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for c be objectHIDDENM1 holds c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r1"
      using A1 rfunct_1_th_70 sorry
    have Cut2069: " for c be objectHIDDENM1 holds c inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r1"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be objectHIDDENM1"
      assume A4: "c inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 domRELAT-1K1 f"
      then have "c inHIDDENR3 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A5: "c inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have "c inHIDDENR3 domRELAT-1K1 f"
        using A4 xboole_0_def_4 sorry
      then have "c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
        using A5 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 c <=XXREAL-0R1 r1"
        using A3 sorry
    qed "sorry"
    have "f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2"
    proof(rule conjMI)
      show "f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1"
        using rfunct_1_th_70 Cut2069 sorry
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A6: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
        using A2 rfunct_1_th_71 sorry
      have " for c be objectHIDDENM1 holds c inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
      proof(rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A7: "c inHIDDENR3 (X /\\XBOOLE-0K3 Y)/\\XBOOLE-0K3 domRELAT-1K1 f"
        then have "c inHIDDENR3 X /\\XBOOLE-0K3 Y"
          using xboole_0_def_4 sorry
        then have A8: "c inHIDDENR3 Y"
          using xboole_0_def_4 sorry
        have "c inHIDDENR3 domRELAT-1K1 f"
          using A7 xboole_0_def_4 sorry
        then have "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
          using A8 xboole_0_def_4 sorry
        thus "r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
          using A6 sorry
      qed "sorry"
      thus "f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2"
        using rfunct_1_th_71 sorry
    qed
    thus "f  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using seq_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_cl_6:
"cluster constantFUNCT-1V5 also-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it be constantFUNCT-1V5 implies it be boundedSEQ-2V6"
  proof-
    have " for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f be constantFUNCT-1V5 implies f be boundedSEQ-2V6"
    proof(rule ballI)
      fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
      show "f be constantFUNCT-1V5 implies f be boundedSEQ-2V6"
      proof-
        have cases: "f be emptyXBOOLE-0V1 or  not f be emptyXBOOLE-0V1"
           sorry
        have case1: "f be emptyXBOOLE-0V1 implies (f be constantFUNCT-1V5 implies f be boundedSEQ-2V6)"
        proof(rule impI,rule impI)
          assume A1: "f be emptyXBOOLE-0V1"
          obtain z where 
            [ty]:"z be RealXREAL-0M1" and zDef:"z = 0NUMBERSK6"
             sorry
          assume "f be constantFUNCT-1V5"
          have "f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2"
          proof(rule conjMI)
            show "f be bounded-aboveSEQ-2V1"
            proof-
              have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f & z <=XXREAL-0R1 f .FUNCT-1K1 x)"
              proof(rule ballI)
                fix x assume [ty]: "x be objectHIDDENM1"
                show " not (x inHIDDENR3 domRELAT-1K1 f & z <=XXREAL-0R1 f .FUNCT-1K1 x)"
                  using A1 sorry
              qed "sorry"
              thus "f be bounded-aboveSEQ-2V1"
                using bexI[of _ "z"] seq_2_def_1 sorry
            qed
            have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x <=XXREAL-0R1 z)"
            proof(rule ballI)
              fix x assume [ty]: "x be objectHIDDENM1"
              show " not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x <=XXREAL-0R1 z)"
                using A1 sorry
            qed "sorry"
            thus "f be bounded-belowSEQ-2V2"
              using bexI[of _ "z"] seq_2_def_2 sorry
          qed
          thus "f be boundedSEQ-2V6"
            using seq_2_def_8 sorry
        qed
        have case2: " not f be emptyXBOOLE-0V1 implies (f be constantFUNCT-1V5 implies f be boundedSEQ-2V6)"
        proof(rule impI,rule impI)
          assume A2: " not f be emptyXBOOLE-0V1"
          assume "f be constantFUNCT-1V5"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A3: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =COMPLEX1R1 r"
            using A2 valued_0_th_15 sorry
          have "f be bounded-aboveSEQ-2V1 & f be bounded-belowSEQ-2V2"
          proof(rule conjMI)
            show "f be bounded-aboveSEQ-2V1"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies  not r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 f .FUNCT-1K1 y"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 domRELAT-1K1 f"
                then have "f .FUNCT-1K1 y =COMPLEX1R1 r"
                  using A3 sorry
                thus " not r +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 f .FUNCT-1K1 y"
                  using xreal_1_th_39 sorry
              qed "sorry"
              thus "f be bounded-aboveSEQ-2V1"
                using bexI[of _ "r +XCMPLX-0K2 \<one>\<^sub>M"] seq_2_def_1 sorry
            qed
            have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies  not f .FUNCT-1K1 y <=XXREAL-0R1 r -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume "y inHIDDENR3 domRELAT-1K1 f"
              then have "f .FUNCT-1K1 y =COMPLEX1R1 r"
                using A3 sorry
              thus " not f .FUNCT-1K1 y <=XXREAL-0R1 r -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_231 sorry
            qed "sorry"
            thus "f be bounded-belowSEQ-2V2"
              using bexI[of _ "r -XCMPLX-0K6 \<one>\<^sub>M"] seq_2_def_2 sorry
          qed
          thus "f be boundedSEQ-2V6"
            using seq_2_def_8 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_76:
" for X be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds X missesXBOOLE-0R1 domRELAT-1K1 f implies f  |RELAT-1K8 X be boundedSEQ-2V6"
proof-
  have " for X be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (X missesXBOOLE-0R1 domRELAT-1K1 f &  not f  |RELAT-1K8 X be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    have "X /\\XBOOLE-0K3 domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1 implies f  |RELAT-1K8 X be boundedSEQ-2V6"
    proof(rule impI)
      assume "X /\\XBOOLE-0K3 domRELAT-1K1 f =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "domRELAT-1K1 (f  |RELAT-1K8 X) =XBOOLE-0R4 {}XBOOLE-0K1"
        using relat_1_th_61 sorry
      then have "f  |RELAT-1K8 X =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      thus "f  |RELAT-1K8 X be boundedSEQ-2V6"
         sorry
    qed
    thus " not (X missesXBOOLE-0R1 domRELAT-1K1 f &  not f  |RELAT-1K8 X be boundedSEQ-2V6)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_77:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
proof-
  have " for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    obtain p1 where 
      [ty]:"p1 be RealXREAL-0M1" and p1Def:"p1 = 0NUMBERSK6"
       sorry
    let ?r = "0NUMBERSK6"
    have Cut2153: " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 ((0NUMBERSK6)(#)VALUED-1K25 f) implies ((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c <=XXREAL-0R1 p"
    proof-
      obtain p where 
        [ty]:"p be RealXREAL-0M1" and pDef:"p = p1"
         sorry
      show " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 ((0NUMBERSK6)(#)VALUED-1K25 f) implies ((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c <=XXREAL-0R1 p"
      proof(rule bexI[of _ "p"],rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 (?r (#)VALUED-1K25 f)"
        then have A1: "c inHIDDENR3 domRELAT-1K1 (?r (#)VALUED-1K25 f)"
          using xboole_0_def_4 sorry
        have "?r *XCMPLX-0K3 f .FUNCT-1K1 c <=XXREAL-0R1 0NUMBERSK6"
           sorry
        thus "((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c <=XXREAL-0R1 p"
          using A1 valued_1_def_5 sorry
      qed "sorry"
    qed
    have "((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & ((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
    proof(rule conjMI)
      show "((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
        using rfunct_1_th_70 Cut2153 sorry
      have " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 ((0NUMBERSK6)(#)VALUED-1K25 f) implies p <=XXREAL-0R1 ((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c"
      proof-
        obtain p where 
          [ty]:"p be RealXREAL-0M1" and pDef:"p = p1"
           sorry
        show " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 ((0NUMBERSK6)(#)VALUED-1K25 f) implies p <=XXREAL-0R1 ((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c"
        proof(rule bexI[of _ "p"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 (?r (#)VALUED-1K25 f)"
          then have A2: "c inHIDDENR3 domRELAT-1K1 (?r (#)VALUED-1K25 f)"
            using xboole_0_def_4 sorry
          have "0NUMBERSK6 <=XXREAL-0R1 ?r *XCMPLX-0K3 f .FUNCT-1K1 c"
             sorry
          thus "p <=XXREAL-0R1 ((0NUMBERSK6)(#)VALUED-1K25 f).FUNCT-1K1 c"
            using A2 valued_1_def_5 sorry
        qed "sorry"
      qed
      thus "((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
        using rfunct_1_th_71 sorry
    qed
    thus "((0NUMBERSK6)(#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
      using seq_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_cl_7:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f  |RELAT-1K8 X implies it be bounded-aboveSEQ-2V1"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f  |RELAT-1K8 X &  not VarFor1 be bounded-aboveSEQ-2V1)"
    proof-
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 y <XXREAL-0R3 r"
        using seq_2_def_1 sorry
      have "f  |RELAT-1K8 X be bounded-aboveSEQ-2V1"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies  not r <=XXREAL-0R1 (f  |RELAT-1K8 X).FUNCT-1K1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A2: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
          then have "y inHIDDENR3 domRELAT-1K1 f"
            using relat_1_th_57 sorry
          then have "f .FUNCT-1K1 y <XXREAL-0R3 r"
            using A1 sorry
          thus " not r <=XXREAL-0R1 (f  |RELAT-1K8 X).FUNCT-1K1 y"
            using A2 funct_1_th_47 sorry
        qed "sorry"
        thus "f  |RELAT-1K8 X be bounded-aboveSEQ-2V1"
          using bexI[of _ "r"] seq_2_def_1 sorry
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f  |RELAT-1K8 X &  not VarFor1 be bounded-aboveSEQ-2V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_8:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f  |RELAT-1K8 X implies it be bounded-belowSEQ-2V2"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f  |RELAT-1K8 X &  not VarFor1 be bounded-belowSEQ-2V2)"
    proof-
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f implies r <XXREAL-0R3 f .FUNCT-1K1 y"
        using seq_2_def_2 sorry
      have "f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies  not (f  |RELAT-1K8 X).FUNCT-1K1 y <=XXREAL-0R1 r"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A2: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
          then have "y inHIDDENR3 domRELAT-1K1 f"
            using relat_1_th_57 sorry
          then have "r <XXREAL-0R3 f .FUNCT-1K1 y"
            using A1 sorry
          thus " not (f  |RELAT-1K8 X).FUNCT-1K1 y <=XXREAL-0R1 r"
            using A2 funct_1_th_47 sorry
        qed "sorry"
        thus "f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
          using bexI[of _ "r"] seq_2_def_2 sorry
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f  |RELAT-1K8 X &  not VarFor1 be bounded-belowSEQ-2V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_9:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-aboveSEQ-2V1"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-aboveSEQ-2V1)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c <XXREAL-0R3 r1"
        using seq_2_def_1 sorry
      have " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|) +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
        proof(rule bexI[of _ "p"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          have A2: "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 sorry
          assume A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
          then have "c inHIDDENR3 domRELAT-1K1 f"
            using valued_1_def_5 sorry
          then have "f .FUNCT-1K1 c <XXREAL-0R3  |.COMPLEX1K10 r1.|"
            using A1 A2 xxreal_0_th_2 sorry
          then have "r *XCMPLX-0K3 f .FUNCT-1K1 c <=XXREAL-0R1 ( |.COMPLEX1K10 r1.|)*XCMPLX-0K3 r"
            using xreal_1_th_64 sorry
          then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c <=XXREAL-0R1 ( |.COMPLEX1K10 r1.|)*XCMPLX-0K3 r"
            using A3 valued_1_def_5 sorry
          thus "(r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
            using xreal_1_th_39 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-aboveSEQ-2V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_10:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non negativeXXREAL-0V3\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-belowSEQ-2V2"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-belowSEQ-2V2)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies r1 <XXREAL-0R3 f .FUNCT-1K1 c"
        using seq_2_def_2 sorry
      have " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c >XXREAL-0R4 p"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = r *XCMPLX-0K3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|) -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        show " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c >XXREAL-0R4 p"
        proof(rule bexI[of _ "p"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          have A2: "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1"
            using absvalue_th_4 sorry
          assume A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
          then have "c inHIDDENR3 domRELAT-1K1 f"
            using valued_1_def_5 sorry
          then have "f .FUNCT-1K1 c >=XXREAL-0R2 -XCMPLX-0K4  |.COMPLEX1K10 r1.|"
            using A1 A2 xxreal_0_th_2 sorry
          then have "r *XCMPLX-0K3 f .FUNCT-1K1 c >=XXREAL-0R2 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)*XCMPLX-0K3 r"
            using xreal_1_th_64 sorry
          then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c >=XXREAL-0R2 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)*XCMPLX-0K3 r"
            using A3 valued_1_def_5 sorry
          thus "(r (#)VALUED-1K25 f).FUNCT-1K1 c >XXREAL-0R4 p"
            using xreal_1_th_231 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-belowSEQ-2V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_11:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-belowSEQ-2V2"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-belowSEQ-2V2)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c <XXREAL-0R3 r1"
        using seq_2_def_1 sorry
      have " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies p <XXREAL-0R3 (r (#)VALUED-1K25 f).FUNCT-1K1 c"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|) -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        show " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies p <XXREAL-0R3 (r (#)VALUED-1K25 f).FUNCT-1K1 c"
        proof(rule bexI[of _ "p"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          have A2: "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using absvalue_th_4 sorry
          assume A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
          then have "c inHIDDENR3 domRELAT-1K1 f"
            using valued_1_def_5 sorry
          then have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
            using A1 A2 xxreal_0_th_2 sorry
          then have "r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|) <=XXREAL-0R1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
            using xreal_1_th_65 sorry
          then have "r *XCMPLX-0K3 ( |.COMPLEX1K10 r1.|) <=XXREAL-0R1 (r (#)VALUED-1K25 f).FUNCT-1K1 c"
            using A3 valued_1_def_5 sorry
          thus "p <XXREAL-0R3 (r (#)VALUED-1K25 f).FUNCT-1K1 c"
            using xreal_1_th_231 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-belowSEQ-2V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_12:
  mlet "f be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be  non positiveXXREAL-0V2\<bar>RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 r (#)VALUED-1K25 f implies it be bounded-aboveSEQ-2V1"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-aboveSEQ-2V1)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies r1 <XXREAL-0R3 f .FUNCT-1K1 c"
        using seq_2_def_2 sorry
      have " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = r *XCMPLX-0K3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|) +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex p be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
        proof(rule bexI[of _ "p"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          have A2: "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1"
            using absvalue_th_4 sorry
          assume A3: "c inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
          then have "c inHIDDENR3 domRELAT-1K1 f"
            using valued_1_def_5 sorry
          then have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 f .FUNCT-1K1 c"
            using A1 A2 xxreal_0_th_2 sorry
          then have "r *XCMPLX-0K3 f .FUNCT-1K1 c <=XXREAL-0R1 r *XCMPLX-0K3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)"
            using xreal_1_th_65 sorry
          then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c <=XXREAL-0R1 r *XCMPLX-0K3 (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)"
            using A3 valued_1_def_5 sorry
          thus "(r (#)VALUED-1K25 f).FUNCT-1K1 c <XXREAL-0R3 p"
            using xreal_1_th_39 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K25 f &  not VarFor1 be bounded-aboveSEQ-2V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_78:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1) & (f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not ((f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & 0NUMBERSK6 <=XXREAL-0R1 r) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1) &  not ((f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & r <=XXREAL-0R1 0NUMBERSK6) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    have "(r (#)VALUED-1K25 f) |RELAT-1K8 Y =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 Y"
      using rfunct_1_th_49 sorry
    thus " not ((f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & 0NUMBERSK6 <=XXREAL-0R1 r) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1) &  not ((f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & r <=XXREAL-0R1 0NUMBERSK6) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_79:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & 0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2) & (f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1)"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not ((f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & 0NUMBERSK6 <=XXREAL-0R1 r) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2) &  not ((f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & r <=XXREAL-0R1 0NUMBERSK6) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    have "(r (#)VALUED-1K25 f) |RELAT-1K8 Y =FUNCT-1R1 r (#)VALUED-1K25 f  |RELAT-1K8 Y"
      using rfunct_1_th_49 sorry
    thus " not ((f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & 0NUMBERSK6 <=XXREAL-0R1 r) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2) &  not ((f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 & r <=XXREAL-0R1 0NUMBERSK6) &  not (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_80:
" for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
proof-
  have " for Y be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 Y be boundedSEQ-2V6"
    show "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 r or r <=XXREAL-0R1 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 r implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
      proof(rule impI)
        assume A2: "0NUMBERSK6 <=XXREAL-0R1 r"
        have "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
        proof(rule conjMI)
          show "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
            using A1 rfunct_1_th_78 A2 sorry
          show "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
            using A1 A2 rfunct_1_th_79 sorry
        qed
        thus "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
          using seq_2_def_8 sorry
      qed
      have case2: "r <=XXREAL-0R1 0NUMBERSK6 implies (r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
      proof(rule impI)
        assume A3: "r <=XXREAL-0R1 0NUMBERSK6"
        have "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1 & (r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
        proof(rule conjMI)
          show "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
            using A1 rfunct_1_th_79 A3 sorry
          show "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be bounded-belowSEQ-2V2"
            using A1 A3 rfunct_1_th_78 sorry
        qed
        thus "(r (#)VALUED-1K25 f) |RELAT-1K8 Y be boundedSEQ-2V6"
          using seq_2_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_cl_13:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster absVALUED-1K57 f as-term-is bounded-belowSEQ-2V2"
proof
(*coherence*)
  show "absVALUED-1K57 f be bounded-belowSEQ-2V2"
  proof-
    have " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f implies p <XXREAL-0R3 absVALUED-1K57 f .FUNCT-1K1 c"
    proof-
      obtain p where 
        [ty]:"p be RealXREAL-0M1" and pDef:"p = -XCMPLX-0K4 \<one>\<^sub>M"
         sorry
      show " ex p be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f implies p <XXREAL-0R3 absVALUED-1K57 f .FUNCT-1K1 c"
      proof(rule bexI[of _ "p"],rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f"
        have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
          using complex1_th_46 sorry
        thus "p <XXREAL-0R3 absVALUED-1K57 f .FUNCT-1K1 c"
          using valued_1_th_18 sorry
      qed "sorry"
    qed
    thus "absVALUED-1K57 f be bounded-belowSEQ-2V2"
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_81:
" for X be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds absVALUED-1K57 f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
   sorry

mtheorem rfunct_1_cl_14:
  mlet "f be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster absVALUED-1K57 f as-term-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 absVALUED-1K57 f implies it be boundedSEQ-2V6"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 absVALUED-1K57 f &  not VarFor1 be boundedCOMSEQ-2V1)"
    proof-
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies  |.COMPLEX1K10 f .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
        using rfunct_1_th_72 sorry
      have " ex r1 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f implies  |.COMPLEX1K10 absVALUED-1K57 f .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
      proof-
        show " ex r1 be RealXREAL-0M1 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f implies  |.COMPLEX1K10 absVALUED-1K57 f .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
        proof(rule bexI[of _ "r1"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "c inHIDDENR3 domRELAT-1K1 absVALUED-1K57 f"
          then have "c inHIDDENR3 domRELAT-1K1 f"
            using valued_1_def_11 sorry
          then have " |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 c.| .| <=XXREAL-0R1 r1"
            using A1 sorry
          thus " |.COMPLEX1K10 absVALUED-1K57 f .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
            using valued_1_th_18 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 absVALUED-1K57 f &  not VarFor1 be boundedCOMSEQ-2V1)"
        using rfunct_1_th_72 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_15:
  mlet "f be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 -VALUED-1K32 f implies it be bounded-belowSEQ-2V2"
     sorry
qed "sorry"

mtheorem rfunct_1_th_82:
" for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies absVALUED-1K57 f  |RELAT-1K8 Y be boundedSEQ-2V6 & (-VALUED-1K32 f) |RELAT-1K8 Y be boundedSEQ-2V6"
proof-
  have " for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 Y be boundedSEQ-2V6 implies absVALUED-1K57 f  |RELAT-1K8 Y be boundedSEQ-2V6 & (-VALUED-1K32 f) |RELAT-1K8 Y be boundedSEQ-2V6"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 Y be boundedSEQ-2V6"
    have "absVALUED-1K57 f  |RELAT-1K8 Y =FUNCT-1R1 absVALUED-1K57 (f  |RELAT-1K8 Y)"
      using rfunct_1_th_46 sorry
    thus "absVALUED-1K57 f  |RELAT-1K8 Y be boundedSEQ-2V6"
      using A1 sorry
    show "(-VALUED-1K32 f) |RELAT-1K8 Y be boundedSEQ-2V6"
      using A1 rfunct_1_th_80 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve f1, f2 for "real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
mtheorem rfunct_1_cl_16:
  mlet "f1 be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be bounded-aboveSEQ-2V1\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is bounded-aboveSEQ-2V1 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 +VALUED-1K1 f2 implies it be bounded-aboveSEQ-2V1"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K1 f2 &  not VarFor1 be bounded-aboveSEQ-2V1)"
    proof-
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f2 implies f2 .FUNCT-1K1 c <XXREAL-0R3 r2"
        using seq_2_def_1 sorry
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 c <XXREAL-0R3 r1"
        using seq_2_def_1 sorry
      have " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 c <XXREAL-0R3 r"
      proof-
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 r2"
           sorry
        show " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 c <XXREAL-0R3 r"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
          then have A4: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
            using valued_1_def_1 sorry
          then have "c inHIDDENR3 domRELAT-1K1 f1"
            using xboole_0_def_4 sorry
          then have A5: "f1 .FUNCT-1K1 c <XXREAL-0R3 r1"
            using A2 sorry
          have "c inHIDDENR3 domRELAT-1K1 f2"
            using A4 xboole_0_def_4 sorry
          then have "f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c <XXREAL-0R3 r"
            using A1 A5 xreal_1_th_8 sorry
          thus "(f1 +VALUED-1K1 f2).FUNCT-1K1 c <XXREAL-0R3 r"
            using A3 valued_1_def_1 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K1 f2 &  not VarFor1 be bounded-aboveSEQ-2V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_17:
  mlet "f1 be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be bounded-belowSEQ-2V2\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is bounded-belowSEQ-2V2 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 +VALUED-1K1 f2 implies it be bounded-belowSEQ-2V2"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K1 f2 &  not VarFor1 be bounded-belowSEQ-2V2)"
    proof-
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f2 implies f2 .FUNCT-1K1 c >XXREAL-0R4 r2"
        using seq_2_def_2 sorry
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f1 implies f1 .FUNCT-1K1 c >XXREAL-0R4 r1"
        using seq_2_def_2 sorry
      have " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 c >XXREAL-0R4 r"
      proof-
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = r1 +XCMPLX-0K2 r2"
           sorry
        show " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 c >XXREAL-0R4 r"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          assume A3: "c inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
          then have A4: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
            using valued_1_def_1 sorry
          then have "c inHIDDENR3 domRELAT-1K1 f1"
            using xboole_0_def_4 sorry
          then have A5: "f1 .FUNCT-1K1 c >XXREAL-0R4 r1"
            using A2 sorry
          have "c inHIDDENR3 domRELAT-1K1 f2"
            using A4 xboole_0_def_4 sorry
          then have "f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c >XXREAL-0R4 r"
            using A1 A5 xreal_1_th_8 sorry
          thus "(f1 +VALUED-1K1 f2).FUNCT-1K1 c >XXREAL-0R4 r"
            using A3 valued_1_def_1 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K1 f2 &  not VarFor1 be bounded-belowSEQ-2V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_83:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ((f1  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f2  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f2  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6 implies (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds ( not ((f1  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f2  |RELAT-1K8 Y be bounded-aboveSEQ-2V1) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) &  not ((f1  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f2  |RELAT-1K8 Y be bounded-belowSEQ-2V2) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) &  not ((f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    have "(f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =HIDDENR1 f1  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) +VALUED-1K1 f2  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
      using rfunct_1_th_44 sorry
    also have "... = f1  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) +VALUED-1K1 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
      using relat_1_th_71 sorry
    also have "... = (f1  |RELAT-1K8 X) |RELAT-1K8 Y +VALUED-1K1 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
      using relat_1_th_71 sorry
    finally have "(f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =HIDDENR1 (f1  |RELAT-1K8 X) |RELAT-1K8 Y +VALUED-1K1 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
       sorry
    thus "( not ((f1  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f2  |RELAT-1K8 Y be bounded-aboveSEQ-2V1) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) &  not ((f1  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f2  |RELAT-1K8 Y be bounded-belowSEQ-2V2) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) &  not ((f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6) &  not (f1 +VALUED-1K1 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_cl_18:
  mlet "f1 be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be boundedSEQ-2V6\<bar>real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is boundedSEQ-2V6 for real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 (#)VALUED-1K19 f2 implies it be boundedSEQ-2V6"
  proof-
    have " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K19 f2 &  not VarFor1 be boundedCOMSEQ-2V1)"
    proof-
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A1: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 c.| <=XXREAL-0R1 r2"
        using rfunct_1_th_72 sorry
      obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f1 implies  |.COMPLEX1K10 f1 .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
        using rfunct_1_th_72 sorry
      have " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c.| <=XXREAL-0R1 r"
      proof-
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = r1 *XCMPLX-0K3 r2"
           sorry
        show " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c.| <=XXREAL-0R1 r"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix c assume [ty]: "c be objectHIDDENM1"
          have A3: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f2 .FUNCT-1K1 c.|"
            using complex1_th_46 sorry
          assume "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
          then have A4: "c inHIDDENR3 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
            using valued_1_def_4 sorry
          then have "c inHIDDENR3 domRELAT-1K1 f1"
            using xboole_0_def_4 sorry
          then have A5: " |.COMPLEX1K10 f1 .FUNCT-1K1 c.| <=XXREAL-0R1 r1"
            using A2 sorry
          have "c inHIDDENR3 domRELAT-1K1 f2"
            using A4 xboole_0_def_4 sorry
          then have A6: " |.COMPLEX1K10 f2 .FUNCT-1K1 c.| <=XXREAL-0R1 r2"
            using A1 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 c.|"
            using complex1_th_46 sorry
          then have "( |.COMPLEX1K10 f1 .FUNCT-1K1 c.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 c.|) <=XXREAL-0R1 r"
            using A5 A6 A3 xreal_1_th_66 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c .| <=XXREAL-0R1 r"
            using complex1_th_65 sorry
          thus " |.COMPLEX1K10 (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c.| <=XXREAL-0R1 r"
            using valued_1_th_5 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K19 f2 &  not VarFor1 be boundedCOMSEQ-2V1)"
        using rfunct_1_th_72 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_84:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6 implies (f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f1 -VALUED-1K47 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f1  |RELAT-1K8 X be boundedSEQ-2V6 & f2  |RELAT-1K8 Y be boundedSEQ-2V6 implies (f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f1 -VALUED-1K47 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f1 assume [ty]: "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f1  |RELAT-1K8 X be boundedSEQ-2V6"
      and A2: "f2  |RELAT-1K8 Y be boundedSEQ-2V6"
    have "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =HIDDENR1 f1  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) (#)VALUED-1K19 f2  |RELAT-1K8 (X /\\XBOOLE-0K3 Y)"
      using rfunct_1_th_45 sorry
    also have "... = f1  |RELAT-1K8 (X /\\XBOOLE-0K3 Y) (#)VALUED-1K19 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
      using relat_1_th_71 sorry
    also have "... = (f1  |RELAT-1K8 X) |RELAT-1K8 Y (#)VALUED-1K19 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
      using relat_1_th_71 sorry
    finally have "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) =HIDDENR1 (f1  |RELAT-1K8 X) |RELAT-1K8 Y (#)VALUED-1K19 (f2  |RELAT-1K8 Y) |RELAT-1K8 X"
       sorry
    thus "(f1 (#)VALUED-1K19 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using A1 A2 sorry
    have "(-VALUED-1K32 f2) |RELAT-1K8 Y be boundedSEQ-2V6"
      using A2 rfunct_1_th_82 sorry
    thus "(f1 -VALUED-1K47 f2) |RELAT-1K8 (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using A1 rfunct_1_th_83 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_85:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-aboveSEQ-2V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-aboveSEQ-2V1 & f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-aboveSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 X be bounded-aboveSEQ-2V1"
      and A2: "f  |RELAT-1K8 Y be bounded-aboveSEQ-2V1"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for c be objectHIDDENM1 holds c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r1"
      using A1 rfunct_1_th_70 sorry
    obtain r2 where
      [ty]:"r2 be RealXREAL-0M1" and 
      A4: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r2"
      using A2 rfunct_1_th_70 sorry
    have " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
    proof-
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r =  |.COMPLEX1K10 r1.| +XCMPLX-0K2  |.COMPLEX1K10 r2.|"
         sorry
      show " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
      proof(rule bexI[of _ "r"],rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A5: "c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f"
        then have A6: "c inHIDDENR3 domRELAT-1K1 f"
          using xboole_0_def_4 sorry
        have A7: "c inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using A5 xboole_0_def_4 sorry
        have "f .FUNCT-1K1 c <=XXREAL-0R1 r"
        proof-
          show "f .FUNCT-1K1 c <=XXREAL-0R1 r"
          proof-
            have cases: "c inHIDDENR3 X or c inHIDDENR3 Y"
              using A7 xboole_0_def_3 sorry
            have case1: "c inHIDDENR3 X implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
            proof(rule impI)
              assume "c inHIDDENR3 X"
              then have "c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
                using A6 xboole_0_def_4 sorry
              then have A8: "f .FUNCT-1K1 c <=XXREAL-0R1 r1"
                using A3 sorry
              have A9: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
                using complex1_th_46 sorry
              have "r1 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
                using absvalue_th_4 sorry
              then have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
                using A8 xxreal_0_th_2 sorry
              then have "f .FUNCT-1K1 c +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 r"
                using A9 xreal_1_th_7 sorry
              thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
                 sorry
            qed
            have case2: "c inHIDDENR3 Y implies f .FUNCT-1K1 c <=XXREAL-0R1 r"
            proof(rule impI)
              assume "c inHIDDENR3 Y"
              then have "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
                using A6 xboole_0_def_4 sorry
              then have A10: "f .FUNCT-1K1 c <=XXREAL-0R1 r2"
                using A4 sorry
              have A11: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
                using complex1_th_46 sorry
              have "r2 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
                using absvalue_th_4 sorry
              then have "f .FUNCT-1K1 c <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
                using A10 xxreal_0_th_2 sorry
              then have "0NUMBERSK6 +XCMPLX-0K2 f .FUNCT-1K1 c <=XXREAL-0R1 r"
                using A11 xreal_1_th_7 sorry
              thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "f .FUNCT-1K1 c <=XXREAL-0R1 r"
           sorry
      qed "sorry"
    qed
    thus "f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-aboveSEQ-2V1"
      using rfunct_1_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_86:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-belowSEQ-2V2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be bounded-belowSEQ-2V2 & f  |RELAT-1K8 Y be bounded-belowSEQ-2V2 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-belowSEQ-2V2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
    assume A1: "f  |RELAT-1K8 X be bounded-belowSEQ-2V2"
      and A2: "f  |RELAT-1K8 Y be bounded-belowSEQ-2V2"
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A3: " for c be objectHIDDENM1 holds c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f implies r1 <=XXREAL-0R1 f .FUNCT-1K1 c"
      using A1 rfunct_1_th_71 sorry
    obtain r2 where
      [ty]:"r2 be RealXREAL-0M1" and 
      A4: " for c be objectHIDDENM1 holds c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f implies r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
      using A2 rfunct_1_th_71 sorry
    have " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
    proof-
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = (-XCMPLX-0K4  |.COMPLEX1K10 r1.|)-XCMPLX-0K6  |.COMPLEX1K10 r2.|"
         sorry
      show " ex r be setHIDDENM2 st  for c be objectHIDDENM1 holds c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
      proof(rule bexI[of _ "r"],rule ballI,rule impI)
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A5: "c inHIDDENR3 (X \\/XBOOLE-0K2 Y)/\\XBOOLE-0K3 domRELAT-1K1 f"
        then have A6: "c inHIDDENR3 domRELAT-1K1 f"
          using xboole_0_def_4 sorry
        have A7: "c inHIDDENR3 X \\/XBOOLE-0K2 Y"
          using A5 xboole_0_def_4 sorry
        have "r <=XXREAL-0R1 f .FUNCT-1K1 c"
        proof-
          show "r <=XXREAL-0R1 f .FUNCT-1K1 c"
          proof-
            have cases: "c inHIDDENR3 X or c inHIDDENR3 Y"
              using A7 xboole_0_def_3 sorry
            have case1: "c inHIDDENR3 X implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
            proof(rule impI)
              assume "c inHIDDENR3 X"
              then have "c inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
                using A6 xboole_0_def_4 sorry
              then have A8: "r1 <=XXREAL-0R1 f .FUNCT-1K1 c"
                using A3 sorry
              have A9: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r2.|"
                using complex1_th_46 sorry
              have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 r1"
                using absvalue_th_4 sorry
              then have "-XCMPLX-0K4  |.COMPLEX1K10 r1.| <=XXREAL-0R1 f .FUNCT-1K1 c"
                using A8 xxreal_0_th_2 sorry
              then have "r <=XXREAL-0R1 f .FUNCT-1K1 c -XCMPLX-0K6 0NUMBERSK6"
                using A9 xreal_1_th_13 sorry
              thus "r <=XXREAL-0R1 f .FUNCT-1K1 c"
                 sorry
            qed
            have case2: "c inHIDDENR3 Y implies r <=XXREAL-0R1 f .FUNCT-1K1 c"
            proof(rule impI)
              assume "c inHIDDENR3 Y"
              then have "c inHIDDENR3 Y /\\XBOOLE-0K3 domRELAT-1K1 f"
                using A6 xboole_0_def_4 sorry
              then have A10: "r2 <=XXREAL-0R1 f .FUNCT-1K1 c"
                using A4 sorry
              have A11: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 r1.|"
                using complex1_th_46 sorry
              have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 r2"
                using absvalue_th_4 sorry
              then have "-XCMPLX-0K4  |.COMPLEX1K10 r2.| <=XXREAL-0R1 f .FUNCT-1K1 c"
                using A10 xxreal_0_th_2 sorry
              then have "(-XCMPLX-0K4  |.COMPLEX1K10 r2.|)-XCMPLX-0K6  |.COMPLEX1K10 r1.| <=XXREAL-0R1 f .FUNCT-1K1 c -XCMPLX-0K6 0NUMBERSK6"
                using A11 xreal_1_th_13 sorry
              thus "r <=XXREAL-0R1 f .FUNCT-1K1 c"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "r <=XXREAL-0R1 f .FUNCT-1K1 c"
           sorry
      qed "sorry"
    qed
    thus "f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be bounded-belowSEQ-2V2"
      using rfunct_1_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_87:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds f  |RELAT-1K8 X be boundedSEQ-2V6 & f  |RELAT-1K8 Y be boundedSEQ-2V6 implies f  |RELAT-1K8 (X \\/XBOOLE-0K2 Y) be boundedSEQ-2V6"
  using rfunct_1_th_85 rfunct_1_th_86 sorry

reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
mtheorem rfunct_1_cl_19:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
  proof-
    obtain r2 where
      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies f2 .FUNCT-1K1 c =COMPLEX1R1 r2"
      using partfun2_def_1 sorry
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 .FUNCT-1K1 c =COMPLEX1R1 r1"
      using partfun2_def_1 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 +REAL-1K3 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A3: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A4: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have A5: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      have A6: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A4 xboole_0_def_4 sorry
      have "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A3 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 r2"
        using A1 A6 sorry
      also have "... = r1 +REAL-1K3 r2"
        using A2 A5 sorry
      finally show "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 +REAL-1K3 r2"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_20:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
  proof-
    obtain r2 where
      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A7: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies f2 .FUNCT-1K1 c =COMPLEX1R1 r2"
      using partfun2_def_1 sorry
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A8: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 .FUNCT-1K1 c =COMPLEX1R1 r1"
      using partfun2_def_1 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 -REAL-1K5 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A10: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_th_12 sorry
      then have A11: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      have A12: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A10 xboole_0_def_4 sorry
      have "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
        using A9 valued_1_th_13 sorry
      also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 r2"
        using A7 A12 sorry
      also have "... = r1 -REAL-1K5 r2"
        using A8 A11 sorry
      finally show "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 -REAL-1K5 r2"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_21:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "f2 be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
  proof-
    obtain r2 where
      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A13: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies f2 .FUNCT-1K1 c =COMPLEX1R1 r2"
      using partfun2_def_1 sorry
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A14: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 .FUNCT-1K1 c =COMPLEX1R1 r1"
      using partfun2_def_1 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 *REAL-1K4 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A15: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_4 sorry
      then have A17: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      have A18: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A16 xboole_0_def_4 sorry
      have "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A15 valued_1_def_4 sorry
      also have "... = f1 .FUNCT-1K1 c *XCMPLX-0K3 r2"
        using A13 A18 sorry
      also have "... = r1 *REAL-1K4 r2"
        using A14 A17 sorry
      finally show "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 *REAL-1K4 r2"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_88:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies ((f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be constantFUNCT-1V5 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & ((f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5 & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    assume A1: "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be constantFUNCT-1V5"
      and A2: "f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1 implies f1 .FUNCT-1K1 c =COMPLEX1R1 r1"
      using A1 partfun2_th_57 sorry
    obtain r2 where
      [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A4: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 implies f2 .FUNCT-1K1 c =COMPLEX1R1 r2"
      using A2 partfun2_th_57 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 +REAL-1K3 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A5: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A6: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A7: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A8: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A5 xboole_0_def_4 sorry
      then have A9: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have A10: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A7 xboole_0_def_4 sorry
      have A11: "c inTARSKIR2 Y"
        using A6 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A9 xboole_0_def_4 sorry
      then have A12: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A11 xboole_0_def_4 sorry
      have "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A8 valued_1_def_1 sorry
      also have "... = r1 +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A3 A10 sorry
      also have "... = r1 +REAL-1K3 r2"
        using A4 A12 sorry
      finally show "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 +REAL-1K3 r2"
         sorry
    qed "sorry"
    thus "(f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using partfun2_th_57 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 -REAL-1K5 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A13: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A14: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      then have A15: "c inTARSKIR2 X"
        using xboole_0_def_4 sorry
      have A16: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A13 xboole_0_def_4 sorry
      then have A17: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_th_12 sorry
      then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      then have A18: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A15 xboole_0_def_4 sorry
      have A19: "c inTARSKIR2 Y"
        using A14 xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A17 xboole_0_def_4 sorry
      then have A20: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A19 xboole_0_def_4 sorry
      have "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
        using A16 valued_1_th_13 sorry
      also have "... = r1 -XCMPLX-0K6 f2 .FUNCT-1K1 c"
        using A3 A18 sorry
      also have "... = r1 -REAL-1K5 r2"
        using A4 A20 sorry
      finally show "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 -REAL-1K5 r2"
         sorry
    qed "sorry"
    thus "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using partfun2_th_57 sorry
    have " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 *REAL-1K4 r2"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
      assume A21: "c inTARSKIR2 (X /\\XBOOLE-0K3 Y)/\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      then have A22: "c inTARSKIR2 X /\\XBOOLE-0K3 Y"
        using xboole_0_def_4 sorry
      have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A21 xboole_0_def_4 sorry
      then have A23: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using valued_1_def_4 sorry
      then have A24: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using xboole_0_def_4 sorry
      have A25: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A23 xboole_0_def_4 sorry
      have "c inTARSKIR2 Y"
        using A22 xboole_0_def_4 sorry
      then have A26: "c inTARSKIR2 Y /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
        using A25 xboole_0_def_4 sorry
      have "c inTARSKIR2 X"
        using A22 xboole_0_def_4 sorry
      then have A27: "c inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f1"
        using A24 xboole_0_def_4 sorry
      have "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using valued_1_th_5 sorry
      also have "... = r1 *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A3 A27 sorry
      also have "... = r1 *REAL-1K4 r2"
        using A4 A26 sorry
      finally show "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 r1 *REAL-1K4 r2"
         sorry
    qed "sorry"
    thus "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be constantFUNCT-1V5"
      using partfun2_th_57 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_cl_22:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster -VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
  proof-
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =COMPLEX1R1 r"
      using partfun2_def_1 sorry
    have " ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 p"
    proof-
      obtain p where 
        [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2" and pDef:"p = -REAL-1K1 r"
         sorry
      show " ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 p"
      proof(rule bexI[of _ "p"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f)"
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using valued_1_th_8 sorry
        then have "-XCMPLX-0K4 f .FUNCT-1K1 c =COMPLEX1R1 p"
          using A1 sorry
        thus "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 p"
          using valued_1_th_8 sorry
      qed "sorry"
    qed
    thus "-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_23:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
"cluster absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
  proof-
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =COMPLEX1R1 r"
      using partfun2_def_1 sorry
    have " ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 c =COMPLEX1R1 p"
    proof-
      obtain p where 
        [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2" and pDef:"p =  |.COMPLEX1K10 r.|"
        using xreal_0_def_1 sorry
      show " ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f implies absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 c =COMPLEX1R1 p"
      proof(rule bexI[of _ "p"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f"
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using valued_1_def_11 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 c.| =COMPLEX1R1 p"
          using A2 sorry
        thus "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 c =COMPLEX1R1 p"
          using valued_1_th_18 sorry
      qed "sorry"
    qed
    thus "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_cl_24:
  mlet "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)", "p be RealXREAL-0M1"
"cluster p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f as-term-is constantFUNCT-1V5"
proof
(*coherence*)
  show "p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
  proof-
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A3: " for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f implies f .FUNCT-1K1 c =COMPLEX1R1 r"
      using partfun2_def_1 sorry
    have " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) implies (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r1"
    proof-
      obtain r1 where 
        [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and r1Def:"r1 = p *XCMPLX-0K3 r"
        using xreal_0_def_1 sorry
      show " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) implies (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r1"
      proof(rule bexI[of _ "r1"],rule ballI,rule impI)
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f)"
        then have "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using valued_1_def_5 sorry
        then have "p *XCMPLX-0K3 f .FUNCT-1K1 c =COMPLEX1R1 r1"
          using A3 sorry
        thus "(p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 c =COMPLEX1R1 r1"
          using valued_1_th_6 sorry
      qed "sorry"
    qed
    thus "p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f be constantFUNCT-1V5"
      using partfun2_def_1 sorry
  qed
qed "sorry"

mtheorem rfunct_1_th_89:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    have "(p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y"
      using rfunct_1_th_49 sorry
    thus " not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not (p (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_90:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    have "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y"
      using rfunct_1_th_46 sorry
    thus " not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_91:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    have "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y =RELSET-1R2\<^bsub>(C,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y)"
      using rfunct_1_th_46 sorry
    thus " not (f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 &  not absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_92:
" for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (( for r be RealXREAL-0M1 holds (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6) & (-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6) & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
proof-
  have " for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies ( for r be RealXREAL-0M1 holds (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6) & ((-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6 & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    show " for r be RealXREAL-0M1 holds (r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
    proof(rule ballI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have "(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
        using A1 rfunct_1_th_89 sorry
      thus "(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
         sorry
    qed "sorry"
    have "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      using A1 rfunct_1_th_90 sorry
    thus "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
       sorry
    have "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      using A1 rfunct_1_th_91 sorry
    thus "absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be boundedSEQ-2V6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_1_th_93:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 +VALUED-1K3\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
  using rfunct_1_th_83 sorry

mtheorem rfunct_1_th_94:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2)) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies ((f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f2 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6) & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1) & ((f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2) & (f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & ((f2 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6 & (f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule conjMI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    show "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1"
    proof(rule impMI ,rule impI)
      assume A1: "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-aboveSEQ-2V1"
        and A2: "f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      have "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
        using A2 rfunct_1_th_90 sorry
      thus "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-aboveSEQ-2V1"
        using A1 rfunct_1_th_83 sorry
    qed
    show "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2 & f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5 implies (f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2"
    proof(rule impMI ,rule impI)
      assume A3: "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be bounded-belowSEQ-2V2"
        and A4: "f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      have "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
        using A4 rfunct_1_th_90 sorry
      thus "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be bounded-belowSEQ-2V2"
        using A3 rfunct_1_th_83 sorry
    qed
    assume A5: "f1  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> X be boundedSEQ-2V6"
      and A6: "f2  |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
    have "(-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> Y be constantFUNCT-1V5"
      using A6 rfunct_1_th_90 sorry
    thus "(f1 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using A5 rfunct_1_th_83 sorry
    show "(f2 -VALUED-1K49\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using A5 A6 rfunct_1_th_84 sorry
    show "(f1 (#)VALUED-1K21\<^bsub>(C,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(C,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 Y) be boundedSEQ-2V6"
      using A5 A6 rfunct_1_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
