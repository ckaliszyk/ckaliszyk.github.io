theory seq_4
  imports xxreal_2 seqm_3 member_1 rvsum_1 axioms fraenkel
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, k, k1, m, m1, n1, n2, l for "NatNAT-1M1"
reserve r, r1, r2, p, p1, g, g1, g2, s, s1, s2, t for "RealXREAL-0M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve Nseq for "increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve X, Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
mtheorem seq_4_th_1:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <XXREAL-0R3 p) implies ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 g & g <=XXREAL-0R1 p)"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <XXREAL-0R3 p) implies ( ex tVar1 be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not ((r inHIDDENR3 X & p inHIDDENR3 Y) &  not (r <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 p)))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <XXREAL-0R3 p"
    then have " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 p"
       sorry
    then obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A1: " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 g & g <=XXREAL-0R1 p"
      using axioms_th_1 sorry
    have 
      [ty]:"g be RealXREAL-0M1"
       sorry
    show " ex tVar1 be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not ((r inHIDDENR3 X & p inHIDDENR3 Y) &  not (r <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 p))"
    proof(rule bexI[of _ "g"])
      show " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  not ((r inHIDDENR3 X & p inHIDDENR3 Y) &  not (r <=XXREAL-0R1 g & g <=XXREAL-0R1 p))"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_2:
" for p be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (0NUMBERSK6 <XXREAL-0R3 p & ( ex r be RealXREAL-0M1 st r inHIDDENR3 X)) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r +XCMPLX-0K2 p inTARSKIR2 X) implies ( for g be RealXREAL-0M1 holds  ex r be RealXREAL-0M1 st r inHIDDENR3 X & g <XXREAL-0R3 r)"
proof-
  have " for p be RealXREAL-0M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds 0NUMBERSK6 <XXREAL-0R3 p & (( ex r be RealXREAL-0M1 st r inHIDDENR3 X) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r +XCMPLX-0K2 p inTARSKIR2 X) & ( ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g <XXREAL-0R3 r))) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
      and A2: " ex r be RealXREAL-0M1 st r inHIDDENR3 X"
      and A3: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r +XCMPLX-0K2 p inTARSKIR2 X"
      and A4: " ex g be RealXREAL-0M1 st  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g <XXREAL-0R3 r"
    let ?X = "\<lambda>Lamb1.  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not Lamb1 <XXREAL-0R3 r"
    obtain Y where
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A5: " for p1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds p1 inTARSKIR2 Y iff ?X(p1)"
      using subset_1_sch_3 sorry
    have " for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds r inHIDDENR3 X & p1 inHIDDENR3 Y implies r <XXREAL-0R3 p1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      fix p1 assume [ty]: "p1 be RealXREAL-0M1"
      assume A6: "r inHIDDENR3 X"
        and A7: "p1 inHIDDENR3 Y"
      have "r +XCMPLX-0K2 p inTARSKIR2 X"
        using A3 A6 sorry
      then have A8: "r +XCMPLX-0K2 p <=XXREAL-0R1 p1"
        using A5 A7 sorry
      have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 p"
        using A1 xreal_1_th_8 sorry
      thus "r <XXREAL-0R3 p1"
        using A8 xxreal_0_th_2 sorry
    qed "sorry"
    then obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A9: " for r be RealXREAL-0M1 holds  for p1 be RealXREAL-0M1 holds r inHIDDENR3 X & p1 inHIDDENR3 Y implies r <=XXREAL-0R1 g2 & g2 <=XXREAL-0R1 p1"
      using seq_4_th_1 sorry
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A10: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g1 <XXREAL-0R3 r"
      using A4 sorry
    have "g1 inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A11: "g1 inHIDDENR3 Y"
      using A10 A5 sorry
    obtain g2p where 
      [ty]:"g2p be ElementSUBSET-1M1-of REALNUMBERSK2" and g2pDef:"g2p = g2 -XCMPLX-0K6 p"
      using xreal_0_def_1 sorry
    have A12: " not g2 -XCMPLX-0K6 p inTARSKIR2 Y implies  False "
    proof(rule impI)
      assume " not g2 -XCMPLX-0K6 p inTARSKIR2 Y"
      then have " not ?X(g2p)"
        using A5 sorry
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A13: "r1 inHIDDENR3 X & g2p <XXREAL-0R3 r1"
         sorry
      have "(g2 -XCMPLX-0K6 p)+XCMPLX-0K2 p <XXREAL-0R3 r1 +XCMPLX-0K2 p & r1 +XCMPLX-0K2 p inTARSKIR2 X"
        using A3 A13 xreal_1_th_6 sorry
      thus " False "
        using A11 A9 sorry
    qed
    have "-XCMPLX-0K4 p <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
      using A1 sorry
    then have "g2 +XCMPLX-0K2 (-XCMPLX-0K4 p) <XXREAL-0R3 g2 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_6 sorry
    thus " False "
      using A2 A9 A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_3:
" for r be RealXREAL-0M1 holds  ex n be NatNAT-1M1 st r <XXREAL-0R3 n"
proof-
  have " for r be RealXREAL-0M1 holds  ex tVar2 be NatNAT-1M1 st  not r <XXREAL-0R3 tVar2"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 NATNUMBERSK1 implies r +XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
      using axioms_th_2 sorry
    then obtain p where
      [ty]:"p be RealXREAL-0M1" and 
      A1: "p inHIDDENR3 NATNUMBERSK1"and A2: "r <XXREAL-0R3 p"
      using seq_4_th_2 numbers_th_19 sorry
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: "n1 =COMPLEX1R1 p"
      using A1 sorry
    show " ex tVar2 be NatNAT-1M1 st  not r <XXREAL-0R3 tVar2"
    proof(rule bexI[of _ "n1"])
      show " not r <XXREAL-0R3 n1"
        using A2 A3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_4:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5 iff ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s))"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X be real-boundedXXREAL-2V5 implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s))) & (( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s)) implies X be real-boundedXXREAL-2V5)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    show "X be real-boundedXXREAL-2V5 implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s))"
    proof-
      have "X be real-boundedXXREAL-2V5 implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not  |.COMPLEX1K10 r.| <XXREAL-0R3 s))"
      proof(rule impI)
        assume A1: "X be real-boundedXXREAL-2V5"
        then obtain s1 where
          [ty]:"s1 be RealXREAL-0M1" and 
          A2: "s1 be UpperBoundXXREAL-2M1-of X"
          using xxreal_2_def_10 sorry
        have A3: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 s1"
          using A2 xxreal_2_def_1 sorry
        obtain s2 where
          [ty]:"s2 be RealXREAL-0M1" and 
          A4: "s2 be LowerBoundXXREAL-2M2-of X"
          using A1 xxreal_2_def_9 sorry
        have A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies s2 <=XXREAL-0R1 r"
          using A4 xxreal_2_def_2 sorry
        obtain s where 
          [ty]:"s be setHIDDENM2" and sDef:"s = ( |.COMPLEX1K10 s1.| +XCMPLX-0K2  |.COMPLEX1K10 s2.|)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not  |.COMPLEX1K10 r.| <XXREAL-0R3 s)"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impI)
          have A6: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 s1.|"
            using complex1_th_46 sorry
          have A7: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 s2.|"
            using complex1_th_46 sorry
          thus "0NUMBERSK6 <XXREAL-0R3 s"
            using A6 sorry
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume A8: "r inHIDDENR3 X"
          have "s1 <=XXREAL-0R1  |.COMPLEX1K10 s1.| & r <=XXREAL-0R1 s1"
            using A3 A8 absvalue_th_4 sorry
          then have "r <=XXREAL-0R1  |.COMPLEX1K10 s1.|"
            using xxreal_0_th_2 sorry
          then have "r +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 s1.| +XCMPLX-0K2  |.COMPLEX1K10 s2.|"
            using A7 xreal_1_th_7 sorry
          then have A9: "r <XXREAL-0R3 s"
            using xreal_1_th_8 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 s2.| <=XXREAL-0R1 s2 & s2 <=XXREAL-0R1 r"
            using A5 A8 absvalue_th_4 sorry
          then have "-XCMPLX-0K4  |.COMPLEX1K10 s2.| <=XXREAL-0R1 r"
            using xxreal_0_th_2 sorry
          then have "(-XCMPLX-0K4  |.COMPLEX1K10 s1.|)+XCMPLX-0K2 (-XCMPLX-0K4  |.COMPLEX1K10 s2.|) <=XXREAL-0R1 0NUMBERSK6 +XCMPLX-0K2 r"
            using A6 xreal_1_th_7 sorry
          then have A10: "((-XCMPLX-0K4  |.COMPLEX1K10 s1.|)-XCMPLX-0K6  |.COMPLEX1K10 s2.|)+XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 r +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          have "((-XCMPLX-0K4  |.COMPLEX1K10 s1.|)-XCMPLX-0K6  |.COMPLEX1K10 s2.|)-XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 -XCMPLX-0K4 (( |.COMPLEX1K10 s1.| +XCMPLX-0K2  |.COMPLEX1K10 s2.|)+XCMPLX-0K2 \<one>\<^sub>M)"
             sorry
          thus " not  |.COMPLEX1K10 r.| <XXREAL-0R3 s"
            using A9 A10 seq_2_th_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s)"
    then obtain s where
      [ty]:"s be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 s"and A11: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  |.COMPLEX1K10 r.| <XXREAL-0R3 s"
       sorry
    have "X be bounded-belowXXREAL-2V3 & X be bounded-aboveXXREAL-2V4"
    proof(rule conjMI)
      show "X be bounded-belowXXREAL-2V3"
      proof-
        have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 X implies -XCMPLX-0K4 s <=XXREAL-0R1 r"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be ExtRealXXREAL-0M1"
          assume A12: "r inHIDDENR3 X"
          then have 
            [ty]:"r be RealXREAL-0M1"
             sorry
          have " |.COMPLEX1K10 r.| <XXREAL-0R3 s"
            using A11 A12 sorry
          then have A13: "-XCMPLX-0K4 s <XXREAL-0R3 -XCMPLX-0K4  |.COMPLEX1K10 r.|"
            using xreal_1_th_24 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 r.| <=XXREAL-0R1 r"
            using absvalue_th_4 sorry
          thus "-XCMPLX-0K4 s <=XXREAL-0R1 r"
            using A13 xxreal_0_th_2 sorry
        qed "sorry"
        then have "-XCMPLX-0K4 s be LowerBoundXXREAL-2M2-of X"
          using xxreal_2_def_2 sorry
        thus "X be bounded-belowXXREAL-2V3"
          using bexI[of _ "-XCMPLX-0K4 s"] xxreal_2_def_9 sorry
      qed
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 s"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume A14: "r inHIDDENR3 X"
        then have 
          [ty]:"r be RealXREAL-0M1"
           sorry
        have "r <=XXREAL-0R1  |.COMPLEX1K10 r.|"
          using absvalue_th_4 sorry
        thus "r <=XXREAL-0R1 s"
          using A11 A14 xxreal_0_th_2 sorry
      qed "sorry"
      then have "s be UpperBoundXXREAL-2M1-of X"
        using xxreal_2_def_1 sorry
      thus "X be bounded-aboveXXREAL-2V4"
        using bexI[of _ "s"] xxreal_2_def_10 sorry
    qed
    thus "X be real-boundedXXREAL-2V5"
      using xxreal_2_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SEQ_4K1("{SEQ-4K1  _ }" [0]356) where
  "{SEQ-4K1 r} \<equiv> {TARSKIK1 r}"

mtheorem seq_4_add_1:
  mlet "r be RealXREAL-0M1"
"cluster {TARSKIK1 r} as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "{TARSKIK1 r} be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have "{TARSKIK1 r} c=MEMBEREDR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    thus "{TARSKIK1 r} be SubsetSUBSET-1M2-of REALNUMBERSK2"
       sorry
  qed
qed "sorry"

mtheorem seq_4_th_5:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g -XCMPLX-0K6 s <XXREAL-0R3 r)))"
proof-
  have " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1 & X be bounded-aboveXXREAL-2V4 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <=XXREAL-0R1 g)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g -XCMPLX-0K6 s <XXREAL-0R3 r)))))"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    assume A1: "X be  non emptyXBOOLE-0V1"
      and A2: "X be bounded-aboveXXREAL-2V4"
    obtain p1 where
      [ty]:"p1 be RealXREAL-0M1" and 
      A3: "p1 be UpperBoundXXREAL-2M1-of X"
      using A2 sorry
    have A4: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 p1"
      using A3 xxreal_2_def_1 sorry
    let ?X = "\<lambda>Lamb1.  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 Lamb1"
    obtain Y where
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A5: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 Y iff ?X(p)"
      using subset_1_sch_3 sorry
    have "X be SubsetSUBSET-1M2-of REALNUMBERSK2 & ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 p)"
      using A5 membered_th_3 sorry
    then obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A6: " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 Y implies r <=XXREAL-0R1 g1 & g1 <=XXREAL-0R1 p"
      using axioms_th_1 sorry
    have 
      [ty]:"g1 be RealXREAL-0M1"
       sorry
    obtain g where 
      [ty]:"g be RealXREAL-0M1" and gDef:"g = g1"
       sorry
    show " ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <=XXREAL-0R1 g)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g -XCMPLX-0K6 s <XXREAL-0R3 r))))"
    proof(rule bexI[of _ "g"])
      have A7: " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X"
        using A1 sorry
      have A8: "( ex s1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s1 & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g -XCMPLX-0K6 s1 <XXREAL-0R3 r)) implies  False "
      proof(rule impI)
        assume Given: " ex s1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s1 & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g -XCMPLX-0K6 s1 <XXREAL-0R3 r)"
        then obtain s1 where
          [ty]:"s1 be RealXREAL-0M1" and 
          A9: "0NUMBERSK6 <XXREAL-0R3 s1"and A10: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not g -XCMPLX-0K6 s1 <XXREAL-0R3 r"
           sorry
        obtain gs1 where 
          [ty]:"gs1 be ElementSUBSET-1M1-of REALNUMBERSK2" and gs1Def:"gs1 = g -XCMPLX-0K6 s1"
          using xreal_0_def_1 sorry
        have "gs1 inTARSKIR2 Y"
          using A5 A10 sorry
        then have "g <=XXREAL-0R1 g -XCMPLX-0K6 s1"
          using A7 A6 sorry
        then have "g -XCMPLX-0K6 (g -XCMPLX-0K6 s1) <=XXREAL-0R1 (g -XCMPLX-0K6 s1)-XCMPLX-0K6 (g -XCMPLX-0K6 s1)"
          using xreal_1_th_9 sorry
        thus " False "
          using A9 sorry
      qed
      have "p1 inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      then have "p1 inHIDDENR3 Y"
        using A4 A5 sorry
      thus "( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <=XXREAL-0R1 g)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g -XCMPLX-0K6 s <XXREAL-0R3 r))))"
        using A6 A8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_6:
" for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ((( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g1) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g1 -XCMPLX-0K6 s <XXREAL-0R3 r))) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g2)) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g2 -XCMPLX-0K6 s <XXREAL-0R3 r)) implies g1 =COMPLEX1R1 g2"
proof-
  have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g1) & (( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g1 -XCMPLX-0K6 s <XXREAL-0R3 r)) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g2) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g2 -XCMPLX-0K6 s <XXREAL-0R3 r)))) implies g1 =COMPLEX1R1 g2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix g1 assume [ty]: "g1 be RealXREAL-0M1"
    fix g2 assume [ty]: "g2 be RealXREAL-0M1"
    fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    assume A1: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g1"
      and A2: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g1 -XCMPLX-0K6 s <XXREAL-0R3 r)"
      and A3: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 g2"
      and A4: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & g2 -XCMPLX-0K6 s <XXREAL-0R3 r)"
    have A5: "g2 <XXREAL-0R3 g1 implies  False "
    proof(rule impI)
      assume "g2 <XXREAL-0R3 g1"
      then have " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X & g1 -XCMPLX-0K6 (g1 -XCMPLX-0K6 g2) <XXREAL-0R3 r1"
        using A2 xreal_1_th_50 sorry
      thus " False "
        using A3 sorry
    qed
    have "g1 <XXREAL-0R3 g2 implies  False "
    proof(rule impI)
      assume "g1 <XXREAL-0R3 g2"
      then have " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X & g2 -XCMPLX-0K6 (g2 -XCMPLX-0K6 g1) <XXREAL-0R3 r1"
        using A4 xreal_1_th_50 sorry
      thus " False "
        using A1 sorry
    qed
    thus "g1 =COMPLEX1R1 g2"
      using A5 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_7:
" for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g +XCMPLX-0K2 s)))"
proof-
  have " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1 & X be bounded-belowXXREAL-2V3 implies ( ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g <=XXREAL-0R1 r)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <XXREAL-0R3 g +XCMPLX-0K2 s)))))"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    assume A1: "X be  non emptyXBOOLE-0V1"
      and A2: "X be bounded-belowXXREAL-2V3"
    have A3: " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X"
      using A1 sorry
    obtain p1 where
      [ty]:"p1 be RealXREAL-0M1" and 
      A4: "p1 be LowerBoundXXREAL-2M2-of X"
      using A2 sorry
    have A5: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies p1 <=XXREAL-0R1 r"
      using A4 xxreal_2_def_2 sorry
    have 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using membered_th_3 sorry
    let ?X = "\<lambda>Lamb1.  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies Lamb1 <=XXREAL-0R1 r"
    obtain Y where
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A6: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 Y iff ?X(p)"
      using subset_1_sch_3 sorry
    have " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds p inHIDDENR3 Y & r inHIDDENR3 X implies p <=XXREAL-0R1 r"
      using A6 sorry
    then obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A7: " for p be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds p inHIDDENR3 Y & r inHIDDENR3 X implies p <=XXREAL-0R1 g1 & g1 <=XXREAL-0R1 r"
      using axioms_th_1 sorry
    have 
      [ty]:"g1 be RealXREAL-0M1"
       sorry
    obtain g where 
      [ty]:"g be RealXREAL-0M1" and gDef:"g = g1"
       sorry
    show " ex g be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g <=XXREAL-0R1 r)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <XXREAL-0R3 g +XCMPLX-0K2 s))))"
    proof(rule bexI[of _ "g"])
      have A8: "( ex s1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s1 & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not r <XXREAL-0R3 g +XCMPLX-0K2 s1)) implies  False "
      proof(rule impI)
        assume Given: " ex s1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s1 & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not r <XXREAL-0R3 g +XCMPLX-0K2 s1)"
        then obtain s1 where
          [ty]:"s1 be RealXREAL-0M1" and 
          A9: "0NUMBERSK6 <XXREAL-0R3 s1"and A10: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies  not r <XXREAL-0R3 g +XCMPLX-0K2 s1"
           sorry
        obtain gs1 where 
          [ty]:"gs1 be ElementSUBSET-1M1-of REALNUMBERSK2" and gs1Def:"gs1 = g +XCMPLX-0K2 s1"
          using xreal_0_def_1 sorry
        have "gs1 inTARSKIR2 Y"
          using A6 A10 sorry
        then have "g +XCMPLX-0K2 s1 <=XXREAL-0R1 g"
          using A3 A7 sorry
        then have "(g +XCMPLX-0K2 s1)-XCMPLX-0K6 g <=XXREAL-0R1 g -XCMPLX-0K6 g"
          using xreal_1_th_9 sorry
        thus " False "
          using A9 sorry
      qed
      have "p1 inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      then have "p1 inHIDDENR3 Y"
        using A5 A6 sorry
      thus "( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not g <=XXREAL-0R1 r)) & ( for s be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 s & ( for r be RealXREAL-0M1 holds  not (r inHIDDENR3 X &  not r <XXREAL-0R3 g +XCMPLX-0K2 s))))"
        using A7 A8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_8:
" for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ((( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g1 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g1 +XCMPLX-0K2 s))) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g2 <=XXREAL-0R1 r)) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g2 +XCMPLX-0K2 s)) implies g1 =COMPLEX1R1 g2"
proof-
  have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds  for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g1 <=XXREAL-0R1 r) & (( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g1 +XCMPLX-0K2 s)) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g2 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g2 +XCMPLX-0K2 s)))) implies g1 =COMPLEX1R1 g2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix g1 assume [ty]: "g1 be RealXREAL-0M1"
    fix g2 assume [ty]: "g2 be RealXREAL-0M1"
    fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    assume A1: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g1 <=XXREAL-0R1 r"
      and A2: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g1 +XCMPLX-0K2 s)"
      and A3: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies g2 <=XXREAL-0R1 r"
      and A4: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 g2 +XCMPLX-0K2 s)"
    have A5: "g2 <XXREAL-0R3 g1 implies  False "
    proof(rule impI)
      assume "g2 <XXREAL-0R3 g1"
      then have " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X & r1 <XXREAL-0R3 g2 +XCMPLX-0K2 (g1 -XCMPLX-0K6 g2)"
        using A4 xreal_1_th_50 sorry
      thus " False "
        using A1 sorry
    qed
    have "g1 <XXREAL-0R3 g2 implies  False "
    proof(rule impI)
      assume "g1 <XXREAL-0R3 g2"
      then have " ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 X & r1 <XXREAL-0R3 g1 +XCMPLX-0K2 (g2 -XCMPLX-0K6 g1)"
        using A2 xreal_1_th_50 sorry
      thus " False "
        using A3 sorry
    qed
    thus "g1 =COMPLEX1R1 g2"
      using A5 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_1 ("upper-boundSEQ-4K2  _ " [228]228 ) where
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"assume X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 func upper-boundSEQ-4K2 X \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it -XCMPLX-0K6 s <XXREAL-0R3 r))"
proof-
  (*existence*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it -XCMPLX-0K6 s <XXREAL-0R3 r)))"
    proof(rule impI)
      assume Assume: "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4"
      have A1: "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it -XCMPLX-0K6 s <XXREAL-0R3 r))"
        using A1 seq_4_th_5 sorry
    qed
  (*uniqueness*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it1) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it1 -XCMPLX-0K6 s <XXREAL-0R3 r))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it2) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it2 -XCMPLX-0K6 s <XXREAL-0R3 r))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4"
      have A1: "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it1) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it1 -XCMPLX-0K6 s <XXREAL-0R3 r))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r <=XXREAL-0R1 it2) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & it2 -XCMPLX-0K6 s <XXREAL-0R3 r))) implies it1 =HIDDENR1 it2"
        using seq_4_th_6 sorry
    qed
qed "sorry"

mdef seq_4_def_2 ("lower-boundSEQ-4K3  _ " [228]228 ) where
  mlet "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"assume X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 func lower-boundSEQ-4K3 X \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it +XCMPLX-0K2 s))"
proof-
  (*existence*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it +XCMPLX-0K2 s)))"
    proof(rule impI)
      assume Assume: "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3"
      have A1: "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it +XCMPLX-0K2 s))"
        using A1 seq_4_th_7 sorry
    qed
  (*uniqueness*)
    show "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it1 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it1 +XCMPLX-0K2 s))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it2 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it2 +XCMPLX-0K2 s))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3"
      have A1: "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it1 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it1 +XCMPLX-0K2 s))) & (( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies it2 <=XXREAL-0R1 r) & ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 it2 +XCMPLX-0K2 s))) implies it1 =HIDDENR1 it2"
        using seq_4_th_8 sorry
    qed
qed "sorry"

mlemma seq_4_lm_1:
" for r be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t) implies r =COMPLEX1R1 lower-boundSEQ-4K3 X"
proof-
  have " for r be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t) implies r =COMPLEX1R1 lower-boundSEQ-4K3 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    assume A1: " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r"
      and A2: " for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t"
    have A3: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies  not ( for t be RealXREAL-0M1 holds t inHIDDENR3 X implies t >=XXREAL-0R2 r +XCMPLX-0K2 s)"
      using A2 xreal_1_th_29 sorry
    have "X be bounded-belowXXREAL-2V3"
    proof-
      have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 X implies r <=XXREAL-0R1 s"
      proof(rule ballI,rule impI)
        fix s assume [ty]: "s be ExtRealXXREAL-0M1"
        assume "s inHIDDENR3 X"
        thus "r <=XXREAL-0R1 s"
          using A1 sorry
      qed "sorry"
      then have "r be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "r"] xxreal_2_def_9 sorry
    qed
    thus "r =COMPLEX1R1 lower-boundSEQ-4K3 X"
      using A1 A3 seq_4_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_2:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies r <=XXREAL-0R1 t) implies r =COMPLEX1R1 upper-boundSEQ-4K2 X"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r"
    and A2: " for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies r <=XXREAL-0R1 t"
  have A3: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies (( for t be RealXREAL-0M1 holds t inHIDDENR3 X implies r -XCMPLX-0K6 s >=XXREAL-0R2 t) implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    assume A4: "0NUMBERSK6 <XXREAL-0R3 s"
    assume " for t be RealXREAL-0M1 holds t inHIDDENR3 X implies r -XCMPLX-0K6 s >=XXREAL-0R2 t"
    then have "r <=XXREAL-0R1 r -XCMPLX-0K6 s"
      using A2 sorry
    then have "r +XCMPLX-0K2 s <=XXREAL-0R1 r"
      using xreal_1_th_19 sorry
    thus " False "
      using A4 xreal_1_th_29 sorry
  qed "sorry"
  have "X be bounded-aboveXXREAL-2V4"
  proof-
    have " for s be ExtRealXXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume "s inHIDDENR3 X"
      thus "s <=XXREAL-0R1 r"
        using A1 sorry
    qed "sorry"
    then have "r be UpperBoundXXREAL-2M1-of X"
      using xxreal_2_def_1 sorry
    thus "X be bounded-aboveXXREAL-2V4"
      using bexI[of _ "r"] xxreal_2_def_10 sorry
  qed
  thus "r =COMPLEX1R1 upper-boundSEQ-4K2 X"
    using A1 A3 seq_4_def_1 sorry
qed "sorry"

mtheorem seq_4_ident_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"identify lower-boundSEQ-4K3 X with infXXREAL-2K2 X"
proof
(*compatibility*)
  show "lower-boundSEQ-4K3 X =HIDDENR1 infXXREAL-2K2 X"
  proof-
    have A1: " for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies infXXREAL-2K2 X >=XXREAL-0R2 t"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be RealXREAL-0M1"
      assume " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t"
      then have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies t <=XXREAL-0R1 x"
         sorry
      then have "t be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "infXXREAL-2K2 X >=XXREAL-0R2 t"
        using xxreal_2_def_4 sorry
    qed "sorry"
    have " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 infXXREAL-2K2 X"
      using xxreal_2_th_3 sorry
    thus "lower-boundSEQ-4K3 X =HIDDENR1 infXXREAL-2K2 X"
      using A1 seq_4_lm_1 sorry
  qed
qed "sorry"

mtheorem seq_4_ident_2:
  mlet "X be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"identify upper-boundSEQ-4K2 X with supXXREAL-2K1 X"
proof
(*compatibility*)
  show "upper-boundSEQ-4K2 X =HIDDENR1 supXXREAL-2K1 X"
  proof-
    have A1: " for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies t >=XXREAL-0R2 s) implies t >=XXREAL-0R2 supXXREAL-2K1 X"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be RealXREAL-0M1"
      assume " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies t >=XXREAL-0R2 s"
      then have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 t"
         sorry
      then have "t be UpperBoundXXREAL-2M1-of X"
        using xxreal_2_def_1 sorry
      thus "t >=XXREAL-0R2 supXXREAL-2K1 X"
        using xxreal_2_def_3 sorry
    qed "sorry"
    have " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 supXXREAL-2K1 X"
      using xxreal_2_th_4 sorry
    thus "upper-boundSEQ-4K2 X =HIDDENR1 supXXREAL-2K1 X"
      using A1 seq_4_lm_2 sorry
  qed
qed "sorry"

mtheorem seq_4_th_9:
" for r be RealXREAL-0M1 holds lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 r & upper-boundSEQ-4K2 {SEQ-4K1 r} =COMPLEX1R1 r"
  using xxreal_2_th_11 xxreal_2_th_13 sorry

mtheorem seq_4_th_10:
" for r be RealXREAL-0M1 holds lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 upper-boundSEQ-4K2 {SEQ-4K1 r}"
proof-
  have " for r be RealXREAL-0M1 holds lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 upper-boundSEQ-4K2 {SEQ-4K1 r}"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 r"
      using xxreal_2_th_13 sorry
    thus "lower-boundSEQ-4K3 {SEQ-4K1 r} =COMPLEX1R1 upper-boundSEQ-4K2 {SEQ-4K1 r}"
      using xxreal_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_11:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1 implies lower-boundSEQ-4K3 X <=XXREAL-0R1 upper-boundSEQ-4K2 X"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1 implies lower-boundSEQ-4K3 X <=XXREAL-0R1 upper-boundSEQ-4K2 X"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume "X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1"
    then have 
      [ty]:"X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
       sorry
    have "lower-boundSEQ-4K3 X <=XXREAL-0R1 upper-boundSEQ-4K2 X"
      using xxreal_2_th_40 sorry
    thus "lower-boundSEQ-4K3 X <=XXREAL-0R1 upper-boundSEQ-4K2 X"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_12:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar> non emptyXBOOLE-0V1 implies (( ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r) iff lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X)"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5 & X be  non emptyXBOOLE-0V1 implies (( ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r) implies lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X) & (lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X & ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 X implies p =COMPLEX1R1 r) implies  False )"
  proof(rule ballI,rule impMI ,rule impI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be real-boundedXXREAL-2V5"
      and A2: "X be  non emptyXBOOLE-0V1"
    show "( ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r) implies lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
    proof-
      have "( ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r) implies  not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
      proof(rule impI)
        assume Given: " ex r be RealXREAL-0M1 st  ex p be RealXREAL-0M1 st (r inHIDDENR3 X & p inHIDDENR3 X) & p <>HIDDENR2 r"
        then obtain r p where
          [ty]:"r be RealXREAL-0M1" "p be RealXREAL-0M1" and 
          A3: "r inHIDDENR3 X"and A4: "p inHIDDENR3 X"and A5: "p <>HIDDENR2 r"
           sorry
        have A6: "r <XXREAL-0R3 p implies  not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
        proof(rule impI)
          assume A7: "r <XXREAL-0R3 p"
          have "lower-boundSEQ-4K3 X <=XXREAL-0R1 r"
            using A1 A3 seq_4_def_2 sorry
          then have A8: "lower-boundSEQ-4K3 X <XXREAL-0R3 p"
            using A7 xxreal_0_th_2 sorry
          have "p <=XXREAL-0R1 upper-boundSEQ-4K2 X"
            using A1 A4 seq_4_def_1 sorry
          thus " not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
            using A8 xxreal_0_th_2 sorry
        qed
        have "p <XXREAL-0R3 r implies  not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
        proof(rule impI)
          assume A9: "p <XXREAL-0R3 r"
          have "lower-boundSEQ-4K3 X <=XXREAL-0R1 p"
            using A1 A4 seq_4_def_2 sorry
          then have A10: "lower-boundSEQ-4K3 X <XXREAL-0R3 r"
            using A9 xxreal_0_th_2 sorry
          have "r <=XXREAL-0R1 upper-boundSEQ-4K2 X"
            using A1 A3 seq_4_def_1 sorry
          thus " not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
            using A10 xxreal_0_th_2 sorry
        qed
        thus " not lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
          using A5 A6 xxreal_0_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    obtain r where
      [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A11: "r inTARSKIR2 X"
      using A2 sorry
    assume A12: "lower-boundSEQ-4K3 X <XXREAL-0R3 upper-boundSEQ-4K2 X"
      and A13: " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 X & p inHIDDENR3 X implies p =COMPLEX1R1 r"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x =HIDDENR1 r"
      using A13 A11 sorry
    then have "X =MEMBEREDR9 {SEQ-4K1 r}"
      using tarski_def_1 sorry
    thus " False "
      using A12 seq_4_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_13:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be convergentSEQ-2V5"
    then obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
       sorry
    have 
      [ty]:"g1 be RealXREAL-0M1"
       sorry
    obtain g where 
      [ty]:"g be objectHIDDENM1" and gDef:"g =  |.COMPLEX1K10 g1.|"
       sorry
    have " ex g be objectHIDDENM1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m -XCMPLX-0K6 g .|)"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A1 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        have " |.COMPLEX1K10 g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1) .|"
           sorry
        also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .|"
          using complex1_th_52 sorry
        finally have " |.COMPLEX1K10 g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .|"
           sorry
        then have "g -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .|"
          using complex1_th_59 sorry
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6 g <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| & -XCMPLX-0K4  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <=XXREAL-0R1 -XCMPLX-0K4 (g -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)"
          using complex1_th_59 xreal_1_th_24 sorry
        then have " |.COMPLEX1K10  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6 g .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .|"
          using absvalue_th_5 sorry
        then have A3: " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .|"
          using seq_1_th_12 sorry
        assume "n <=XXREAL-0R1 m"
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
          using A2 sorry
        thus " not p <=XXREAL-0R1  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_cl_1:
  mlet "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1"
"cluster absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq implies it be convergentSEQ-2V5"
    using seq_4_th_13 sorry
qed "sorry"

mtheorem seq_4_th_14:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limSEQ-2K1 seq .|"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limSEQ-2K1 seq .|"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A1 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        have " |.COMPLEX1K10 limSEQ-2K1 seq -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq) .|"
           sorry
        also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .|"
          using complex1_th_52 sorry
        finally have " |.COMPLEX1K10 limSEQ-2K1 seq -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m .| =HIDDENR1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .|"
           sorry
        then have " |.COMPLEX1K10 limSEQ-2K1 seq .| -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .|"
          using complex1_th_59 sorry
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| & -XCMPLX-0K4  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <=XXREAL-0R1 -XCMPLX-0K4 ( |.COMPLEX1K10 limSEQ-2K1 seq .| -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|)"
          using complex1_th_59 xreal_1_th_24 sorry
        then have " |.COMPLEX1K10  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .|"
          using absvalue_th_5 sorry
        then have A3: " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .|"
          using seq_1_th_12 sorry
        assume "n <=XXREAL-0R1 m"
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A2 sorry
        thus " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6  |.COMPLEX1K10 limSEQ-2K1 seq .| .| <XXREAL-0R3 p"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1  |.COMPLEX1K10 limSEQ-2K1 seq .|"
      using A1 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_15:
" for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6 implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6 implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq =COMPLEX1R1 0NUMBERSK6"
    have A3: " for n be NatNAT-1M1 holds (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "-XCMPLX-0K4  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.| <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using absvalue_th_4 sorry
      then have A4: "-REAL-1K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_12 sorry
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
        using absvalue_th_4 sorry
      thus "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A4 seq_1_th_10 seq_1_th_12 sorry
    qed "sorry"
    have A5: "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq be convergentSEQ-2V5 & limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq"
      using A1 seq_2_th_10 sorry
    thus "seq be convergentSEQ-2V5"
      using A1 A2 A3 seq_2_th_19 sorry
    show "limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A5 A3 seq_2_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_16:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies seq1 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies seq1 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
      and A2: "seq be convergentSEQ-2V5"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A2 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A3 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "n <=XXREAL-0R1 m"
        obtain Nseq where
          [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
          A6: "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
          using A1 valued_0_def_17 sorry
        have "m <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have A7: "n <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using A5 xxreal_0_th_2 sorry
        have "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m)"
          using A6 funct_2_th_15 sorry
        thus " not p <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
          using A4 A7 sorry
      qed "sorry"
    qed "sorry"
    thus "seq1 be convergentSEQ-2V5"
      using bexI[of _ "g1"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_17:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq be convergentSEQ-2V5 implies limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
      and A2: "seq be convergentSEQ-2V5"
    obtain Nseq where
      [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A3: "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
      using A1 valued_0_def_17 sorry
    have A4: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A2 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
         sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A6: "n <=XXREAL-0R1 m"
        have "m <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have A7: "n <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using A6 xxreal_0_th_2 sorry
        have "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m)"
          using A3 funct_2_th_15 sorry
        thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
          using A5 A7 sorry
      qed "sorry"
    qed "sorry"
    have "seq1 be convergentSEQ-2V5"
      using A1 A2 seq_4_th_16 sorry
    thus "limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
      using A4 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_18:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 be convergentSEQ-2V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies seq1 be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
      using A1 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A4: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A2 sorry
    obtain g where 
      [ty]:"g be RealXREAL-0M1" and gDef:"g = g1"
       sorry
    have " ex g be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies  not ( for VarFor1 be setHIDDENM2 holds  not ( for VarFor2 be setHIDDENM2 holds  not (VarFor1 <=XXREAL-0R1 VarFor2 & p <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 VarFor2 -XCMPLX-0K6 g .|)))"
    proof(rule bexI[of _ "g"],rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A5: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A3 sorry
      have A6: "n1 <=XXREAL-0R1 k implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A7: "n1 <=XXREAL-0R1 k"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = k"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A8: "n <=XXREAL-0R1 m"
          then have "n1 <=XXREAL-0R1 m"
            using A7 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
            using A5 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A4 A8 sorry
        qed "sorry"
      qed
      have "k <=XXREAL-0R1 n1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A9: "k <=XXREAL-0R1 n1"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A10: "n <=XXREAL-0R1 m"
          then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            using A4 A9 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g .| <XXREAL-0R3 p"
            using A5 A10 sorry
        qed "sorry"
      qed
      thus " not ( for VarFor1 be setHIDDENM2 holds  not ( for VarFor2 be setHIDDENM2 holds  not (VarFor1 <=XXREAL-0R1 VarFor2 & p <=XXREAL-0R1  |.COMPLEX1K10 seq1 .FUNCT-1K1 VarFor2 -XCMPLX-0K6 g .|)))"
        using A6 sorry
    qed "sorry"
    thus "seq1 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_19:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & ( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq1"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies (( ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq1)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
    assume Given: " ex k be NatNAT-1M1 st  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A2: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    have A3: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A4: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A1 seq_2_def_7 sorry
      have A5: "n1 <=XXREAL-0R1 k implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A6: "n1 <=XXREAL-0R1 k"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = k"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A7: "n <=XXREAL-0R1 m"
          then have "n1 <=XXREAL-0R1 m"
            using A6 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
            using A4 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
            using A2 A7 sorry
        qed "sorry"
      qed
      have "k <=XXREAL-0R1 n1 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p)"
      proof(rule impI)
        assume A8: "k <=XXREAL-0R1 n1"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A9: "n <=XXREAL-0R1 m"
          then have "seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            using A2 A8 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
            using A4 A9 sorry
        qed "sorry"
      qed
      thus " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 seq .| <XXREAL-0R3 p"
        using A5 sorry
    qed "sorry"
    have "seq1 be convergentSEQ-2V5"
      using A1 A2 seq_4_th_18 sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 seq1"
      using A3 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_cl_2:
  mlet "seq be convergentSEQ-2V5\<bar>Real-SequenceSEQ-1M1", "k be NatNAT-1M1"
"cluster seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k as-term-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it =HIDDENR1 seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k implies it be convergentSEQ-2V5"
    using seq_4_th_16 sorry
qed "sorry"

mtheorem seq_4_th_20:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 implies limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 limSEQ-2K1 seq"
  using seq_4_th_17 sorry

mtheorem seq_4_th_21:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies seq be convergentSEQ-2V5"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies seq be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
    then obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A1: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p)"
       sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
        using A1 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A3: "n <=XXREAL-0R1 m"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A4: "m =COMPLEX1R1 (n1 +XCMPLX-0K2 k)+XCMPLX-0K2 l"
          using nat_1_th_10 sorry
        have 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m -XCMPLX-0K6 k =COMPLEX1R1 ((n1 +NAT-1K1 l)+XCMPLX-0K2 k)+XCMPLX-0K2 (-XCMPLX-0K4 k)"
          using A4 sorry
        then obtain m1 where
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A5: "m1 =COMPLEX1R1 m -XCMPLX-0K6 k"
           sorry
        have " not n1 <=XXREAL-0R1 m1 implies  False "
        proof(rule impI)
          assume " not n1 <=XXREAL-0R1 m1"
          then have "m1 +XCMPLX-0K2 k <XXREAL-0R3 n1 +XCMPLX-0K2 k"
            using xreal_1_th_6 sorry
          thus " False "
            using A3 A5 sorry
        qed
        then have A6: " |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m1 -XCMPLX-0K6 g1 .| <XXREAL-0R3 p"
          using A2 sorry
        have "m1 +XCMPLX-0K2 k =COMPLEX1R1 m"
          using A5 sorry
        thus " not p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
          using A6 nat_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentSEQ-2V5"
      using bexI[of _ "g1"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_22:
" for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
proof-
  have " for k be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5 implies limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
    have A2: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 p"
        using A1 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 k"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A4: "n <=XXREAL-0R1 m"
        then obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A5: "m =COMPLEX1R1 (n1 +XCMPLX-0K2 k)+XCMPLX-0K2 l"
          using nat_1_th_10 sorry
        have 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "m -XCMPLX-0K6 k =COMPLEX1R1 ((n1 +NAT-1K1 l)+XCMPLX-0K2 k)+XCMPLX-0K2 (-XCMPLX-0K4 k)"
          using A5 sorry
        then obtain m1 where
          [ty]:"m1 be NatNAT-1M1" and 
          A6: "m1 =COMPLEX1R1 m -XCMPLX-0K6 k"
           sorry
        have " not n1 <=XXREAL-0R1 m1 implies  False "
        proof(rule impI)
          assume " not n1 <=XXREAL-0R1 m1"
          then have "m1 +XCMPLX-0K2 k <XXREAL-0R3 n1 +XCMPLX-0K2 k"
            using xreal_1_th_6 sorry
          thus " False "
            using A4 A6 sorry
        qed
        then have A7: " |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m1 -XCMPLX-0K6 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 p"
          using A3 sorry
        have "m1 +XCMPLX-0K2 k =COMPLEX1R1 m"
          using A6 sorry
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .| <XXREAL-0R3 p"
          using A7 nat_1_def_3 sorry
      qed "sorry"
    qed "sorry"
    have "seq be convergentSEQ-2V5"
      using A1 seq_4_th_21 sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 limSEQ-2K1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      using A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_23:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9)"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A3: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.|"
      using A1 A2 seq_2_th_16 sorry
    obtain k where 
      [ty]:"k be NatNAT-1M1" and kDef:"k = n1"
       sorry
    show " ex k be NatNAT-1M1 st seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9"
    proof(rule bexI[of _ "k"])
      have " for n be NatNAT-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "0NUMBERSK6 +XCMPLX-0K2 k <=XXREAL-0R1 n +XCMPLX-0K2 k"
          using xreal_1_th_7 sorry
        then have "( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +XCMPLX-0K2 k).|"
          using A3 sorry
        then have A4: "( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n.|"
          using nat_1_def_3 sorry
        have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 seq .|"
          using A2 complex1_th_47 sorry
        then have "(0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ( |.COMPLEX1K10 limSEQ-2K1 seq .|)/XCMPLX-0K7 \<two>\<^sub>M"
           sorry
        thus "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <>HIDDENR2 0NUMBERSK6"
          using A4 absvalue_th_2 sorry
      qed "sorry"
      thus "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9"
        using seq_1_th_5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_24:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex seq1 be Real-SequenceSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( ex tVar25 be Real-SequenceSEQ-1M1 st tVar25 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & tVar25 be non-zeroORDINAL1V9)"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
    then obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A1: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9"
      using seq_4_th_23 sorry
    show " ex tVar25 be Real-SequenceSEQ-1M1 st tVar25 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & tVar25 be non-zeroORDINAL1V9"
    proof(rule bexI[of _ "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"])
      show "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_25:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 & (r inHIDDENR3 rngRVSUM-1K1 seq or ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) implies limSEQ-2K1 seq =COMPLEX1R1 r"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 implies (r inHIDDENR3 rngRVSUM-1K1 seq or ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r) implies limSEQ-2K1 seq =COMPLEX1R1 r)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be constantVALUED-0V15"
    then obtain r1 where
      [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "rngRVSUM-1K1 seq =MEMBEREDR9 {SEQ-4K1 r1}"
      using funct_2_th_111 sorry
    have A3: "r inHIDDENR3 rngRVSUM-1K1 seq implies  not ( not ( not r inHIDDENR3 rngRVSUM-1K1 seq & ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) &  not limSEQ-2K1 seq =COMPLEX1R1 r)"
    proof(rule impI)
      assume A4: "r inHIDDENR3 rngRVSUM-1K1 seq"
      obtain r2 where
        [ty]:"r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A5: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r2"
        using A1 valued_0_def_18 sorry
      have A6: "r =COMPLEX1R1 r1"
        using A4 A2 tarski_def_1 sorry
      obtain zz where 
        [ty]:"zz be NatNAT-1M1" and zzDef:"zz = 0NUMBERSK6"
         sorry
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A7: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = zz"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          have "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
            using funct_2_def_1 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m inTARSKIR2 rngRVSUM-1K1 seq"
            using funct_1_def_3 sorry
          then have "r2 inTARSKIR2 rngRVSUM-1K1 seq"
            using A5 sorry
          then have "r2 =COMPLEX1R1 r"
            using A2 A6 tarski_def_1 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 r"
            using A5 sorry
          thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 r .| <XXREAL-0R3 p"
            using A7 absvalue_th_2 sorry
        qed "sorry"
      qed "sorry"
      thus " not ( not ( not r inHIDDENR3 rngRVSUM-1K1 seq & ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) &  not limSEQ-2K1 seq =COMPLEX1R1 r)"
        using A1 seq_2_def_7 sorry
    qed
    have A8: "( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r) implies  not ( not ( not r inHIDDENR3 rngRVSUM-1K1 seq & ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) &  not limSEQ-2K1 seq =COMPLEX1R1 r)"
    proof(rule impI)
      assume A9: " ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A10: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r"
        using A9 sorry
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
        using funct_2_def_1 sorry
      thus " not ( not ( not r inHIDDENR3 rngRVSUM-1K1 seq & ( for n be NatNAT-1M1 holds  not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)) &  not limSEQ-2K1 seq =COMPLEX1R1 r)"
        using A3 A10 funct_1_def_3 sorry
    qed
    assume "r inHIDDENR3 rngRVSUM-1K1 seq or ( ex n be NatNAT-1M1 st seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r)"
    thus "limSEQ-2K1 seq =COMPLEX1R1 r"
      using A3 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_26:
" for seq be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 implies ( for n be NatNAT-1M1 holds limSEQ-2K1 seq =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
  using seq_4_th_25 sorry

mtheorem seq_4_th_27:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limSEQ-2K1 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6 implies ( for seq1 be Real-SequenceSEQ-1M1 holds seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be non-zeroORDINAL1V9 implies limSEQ-2K1 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5)"
  proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5"
      and A2: "limSEQ-2K1 seq <>HIDDENR2 0NUMBERSK6"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A3: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
      and A4: "seq1 be non-zeroORDINAL1V9"
    have "limSEQ-2K1 seq1 =COMPLEX1R1 limSEQ-2K1 seq"
      using A1 A3 seq_4_th_17 sorry
    thus "limSEQ-2K1 seq1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 seq)\<inverse>XCMPLX-0K5"
      using A1 A2 A3 A4 seq_4_th_16 seq_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 3*)
mlemma seq_4_lm_3:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar27 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar27 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A0: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 p"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "n >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 p -XCMPLX-0K6 r"
      using seq_4_th_3 sorry
    show " ex tVar27 be NatNAT-1M1 st  for m be NatNAT-1M1 holds tVar27 <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
    proof(rule bexI[of _ "n"],rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A2: "n <=XXREAL-0R1 m"
      have B0: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r)"
        using A0 sorry
      have "\<one>\<^sub>M /XCMPLX-0K7 p -XCMPLX-0K6 r <XXREAL-0R3 m"
        using A3 A2 xxreal_0_th_2 sorry
      then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 p -XCMPLX-0K6 r)+XCMPLX-0K2 r <XXREAL-0R3 m +XCMPLX-0K2 r"
        using xreal_1_th_8 sorry
      then have "(p \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 >XXREAL-0R4 (m +XCMPLX-0K2 r)\<inverse>XCMPLX-0K5"
        using A1 xreal_1_th_88 sorry
      then have B1: "\<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r) <XXREAL-0R3 p"
         sorry
      have B2: "-XCMPLX-0K4 p <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
        using A1 sorry
      have "0NUMBERSK6 <=XXREAL-0R1 m +XCMPLX-0K2 r"
        using A1 A4 sorry
      then have "-XCMPLX-0K4 p <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (m +XCMPLX-0K2 r)"
        using B2 sorry
      thus " not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        using B0 B1 seq_2_th_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_4:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A0: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar29 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar29 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|))"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A2: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        using A0 seq_4_lm_3 sorry
      show " ex tVar29 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar29 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|)"
      proof(rule bexI[of _ "n"])
        show " for VarFor1 be setHIDDENM2 holds  not (n <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|)"
          using A2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentSEQ-2V5"
      using bexI[of _ "0NUMBERSK6"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_5:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
    then have A2: "seq be convergentSEQ-2V5"
      using seq_4_lm_4 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p)"
      using A1 seq_4_lm_3 sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      using A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_31:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
    obtain r1 where 
      [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = r"
       sorry
    let ?U = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +XCMPLX-0K2 r1)"
    obtain seq1 where
      [ty]:"seq1 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 g *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = g *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 r))"
        using A3 sorry
      also have "... = g *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (n +XCMPLX-0K2 r)\<inverse>XCMPLX-0K5)"
         sorry
      also have "... = g /XCMPLX-0K7 (n +XCMPLX-0K2 r)"
         sorry
      also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      finally show "(g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    have A5: "g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
      using A3 seq_4_lm_4 seq_2_th_7 sorry
    have "limSEQ-2K1 (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 g *XCMPLX-0K3 (limSEQ-2K1 seq1)"
      using A3 seq_4_lm_4 seq_2_th_8 sorry
    also have "... = g *XCMPLX-0K3 (0NUMBERSK6)"
      using A3 seq_4_lm_5 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "limSEQ-2K1 (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 0NUMBERSK6"
       sorry
    thus "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      using A5 A4 funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 3*)
mlemma seq_4_lm_6:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)"
    fix p assume [ty]: "p be RealXREAL-0M1"
    obtain k1 where
      [ty]:"k1 be NatNAT-1M1" and 
      A3: "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 k1"
      using seq_4_th_3 sorry
    assume A4: "0NUMBERSK6 <XXREAL-0R3 p"
    then have A5: "k1 >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    then have "k1 >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
      using nat_1_th_13 sorry
    then have "k1 <=XXREAL-0R1 k1 *XCMPLX-0K3 k1"
      using xreal_1_th_151 sorry
    then have A6: "k1 +XCMPLX-0K2 r <=XXREAL-0R1 k1 *XCMPLX-0K3 k1 +XCMPLX-0K2 r"
      using xreal_1_th_6 sorry
    obtain n where 
      [ty]:"n be NatNAT-1M1" and nDef:"n = k1"
       sorry
    show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
    proof(rule bexI[of _ "n"],rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A7: "n <=XXREAL-0R1 m"
      have "n *XCMPLX-0K3 n <=XXREAL-0R1 m *XCMPLX-0K3 m"
        using A7 xreal_1_th_66 sorry
      then have A8: "n *XCMPLX-0K3 n +XCMPLX-0K2 r <=XXREAL-0R1 m *XCMPLX-0K3 m +XCMPLX-0K2 r"
        using xreal_1_th_6 sorry
      have "p \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 k1 +XCMPLX-0K2 r"
        using A1 A3 xreal_1_th_8 sorry
      then have "p \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 k1 *XCMPLX-0K3 k1 +XCMPLX-0K2 r"
        using A6 xxreal_0_th_2 sorry
      then have "\<one>\<^sub>M /XCMPLX-0K7 (k1 *XCMPLX-0K3 k1 +XCMPLX-0K2 r) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 p \<inverse>XCMPLX-0K5"
        using A4 xreal_1_th_76 sorry
      then have A9: "\<one>\<^sub>M /XCMPLX-0K7 (k1 *XCMPLX-0K3 k1 +XCMPLX-0K2 r) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (p \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
         sorry
      have "0NUMBERSK6 <XXREAL-0R3 n ^2SQUARE-1K1"
        using A5 sorry
      then have "\<one>\<^sub>M /XCMPLX-0K7 (m *XCMPLX-0K3 m +XCMPLX-0K2 r) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)"
        using A1 A8 xreal_1_th_118 sorry
      then have A10: "\<one>\<^sub>M /XCMPLX-0K7 (m *XCMPLX-0K3 m +XCMPLX-0K2 r) <XXREAL-0R3 p"
        using A9 xxreal_0_th_2 sorry
      have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (m *XCMPLX-0K3 m +XCMPLX-0K2 r)"
        using A2 sorry
      thus " not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        using A1 A10 absvalue_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_7:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex tVar32 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar32 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|))"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 p"
      then obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A3: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
        using A1 A2 seq_4_lm_6 sorry
      show " ex tVar32 be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not (tVar32 <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|)"
      proof(rule bexI[of _ "n"])
        show " for VarFor1 be setHIDDENM2 holds  not (n <=XXREAL-0R1 VarFor1 & p <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 VarFor1 -XCMPLX-0K6 0NUMBERSK6 .|)"
          using A3 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentSEQ-2V5"
      using bexI[of _ "0NUMBERSK6"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_8:
" for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)"
    have A3: "seq be convergentSEQ-2V5"
      using A1 A2 seq_4_lm_7 sorry
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p)"
      using A1 A2 seq_4_lm_6 sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      using A3 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_35:
" for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for r be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 r & ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
      and A2: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 g /XCMPLX-0K7 (n *XCMPLX-0K3 n +XCMPLX-0K2 r)"
    obtain r1 where 
      [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = r"
       sorry
    let ?U = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 *XCMPLX-0K3 Lamb1 +XCMPLX-0K2 r1)"
    obtain seq1 where
      [ty]:"seq1 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 g *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using seq_1_th_9 sorry
      also have "... = g *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (n *NAT-1K2 n +XCMPLX-0K2 r))"
        using A3 sorry
      also have "... = g *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (n *NAT-1K2 n +XCMPLX-0K2 r)\<inverse>XCMPLX-0K5)"
         sorry
      also have "... = g /XCMPLX-0K7 (n *NAT-1K2 n +XCMPLX-0K2 r)"
         sorry
      also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 sorry
      finally show "(g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    have A5: "g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1 be convergentSEQ-2V5"
      using A1 A3 seq_4_lm_7 seq_2_th_7 sorry
    have "limSEQ-2K1 (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 g *XCMPLX-0K3 (limSEQ-2K1 seq1)"
      using A1 A3 seq_4_lm_7 seq_2_th_8 sorry
    also have "... = g *XCMPLX-0K3 (0NUMBERSK6)"
      using A1 A3 seq_4_lm_8 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "limSEQ-2K1 (g (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 0NUMBERSK6"
       sorry
    thus "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 0NUMBERSK6"
      using A5 A4 funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_cl_3:
"cluster non-decreasingSEQM-3V3\<bar>bounded-aboveSEQ-2V3 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be non-decreasingSEQM-3V3\<bar>bounded-aboveSEQ-2V3 implies it be convergentSEQ-2V5"
  proof-
    have " for seq be Real-SequenceSEQ-1M1 holds seq be non-decreasingSEQM-3V3 & seq be bounded-aboveSEQ-2V3 implies seq be convergentSEQ-2V5"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A1: "seq be non-decreasingSEQM-3V3"
        and A2: "seq be bounded-aboveSEQ-2V3"
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A3: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 r2"
        using A2 sorry
      let ?X = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st Lamb1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      obtain X where
        [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
        A4: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 X iff ?X(p)"
        using subset_1_sch_3 sorry
      have A5: " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies p <=XXREAL-0R1 r"
      proof-
        obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = r2"
           sorry
        show " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies p <=XXREAL-0R1 r"
        proof(rule bexI[of _ "r"],rule ballI,rule impI)
          fix p assume [ty]: "p be RealXREAL-0M1"
          assume "p inHIDDENR3 X"
          then have " ex n1 be NatNAT-1M1 st p =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1"
            using A4 sorry
          thus "p <=XXREAL-0R1 r"
            using A3 sorry
        qed "sorry"
      qed
      have A6: "( ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies p <=XXREAL-0R1 r) implies X be bounded-aboveXXREAL-2V4"
      proof(rule impI)
        assume Given: " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies p <=XXREAL-0R1 r"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A7: " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies p <=XXREAL-0R1 r"
           sorry
        have " for p be ExtRealXXREAL-0M1 holds  not (p inHIDDENR3 X &  not p <=XXREAL-0R1 r)"
        proof(rule ballI)
          fix p assume [ty]: "p be ExtRealXXREAL-0M1"
          show " not (p inHIDDENR3 X &  not p <=XXREAL-0R1 r)"
            using A7 sorry
        qed "sorry"
        then have "r be UpperBoundXXREAL-2M1-of X"
          using xxreal_2_def_1 sorry
        thus "X be bounded-aboveXXREAL-2V4"
          using bexI[of _ "r"] xxreal_2_def_10 sorry
      qed
      obtain g where 
        [ty]:"g be RealXREAL-0M1" and gDef:"g = upper-boundSEQ-4K2 X"
         sorry
      have " ex g be RealXREAL-0M1 st  for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|)"
      proof(rule bexI[of _ "g"],rule ballI,rule impI)
        fix s assume [ty]: "s be RealXREAL-0M1"
        assume A8: "0NUMBERSK6 <XXREAL-0R3 s"
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) inTARSKIR2 X"
          using A4 sorry
        then obtain p1 where
          [ty]:"p1 be RealXREAL-0M1" and 
          A9: "p1 inHIDDENR3 X"and A10: "upper-boundSEQ-4K2 X -XCMPLX-0K6 s <XXREAL-0R3 p1"
          using A6 A8 seq_4_def_1 sorry
        obtain n1 where
          [ty]:"n1 be NatNAT-1M1" and 
          A11: "p1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1"
          using A4 A9 sorry
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            using A1 seqm_3_th_6 sorry
          then have "g +XCMPLX-0K2 (-XCMPLX-0K4 s) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            using A10 A11 xxreal_0_th_2 sorry
          then have A12: "-XCMPLX-0K4 s <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g"
            using xreal_1_th_20 sorry
          have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m inTARSKIR2 X"
            using A4 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 g"
            using A6 A5 seq_4_def_1 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 g +XCMPLX-0K2 s"
            using A8 xreal_1_th_8 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g <XXREAL-0R3 s"
            using xreal_1_th_19 sorry
          thus " not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
            using A12 seq_2_th_1 sorry
        qed "sorry"
      qed "sorry"
      thus "seq be convergentSEQ-2V5"
        using seq_2_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_cl_4:
"cluster non-increasingSEQM-3V4\<bar>bounded-belowSEQ-2V4 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be non-increasingSEQM-3V4\<bar>bounded-belowSEQ-2V4 implies it be convergentSEQ-2V5"
  proof-
    have " for seq be Real-SequenceSEQ-1M1 holds seq be non-increasingSEQM-3V4 & seq be bounded-belowSEQ-2V4 implies seq be convergentSEQ-2V5"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A1: "seq be non-increasingSEQM-3V4"
        and A2: "seq be bounded-belowSEQ-2V4"
      let ?X = "\<lambda>Lamb1.  ex n be NatNAT-1M1 st Lamb1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      obtain X where
        [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
        A3: " for p be ElementSUBSET-1M1-of REALNUMBERSK2 holds p inTARSKIR2 X iff ?X(p)"
        using subset_1_sch_3 sorry
      obtain g where 
        [ty]:"g be RealXREAL-0M1" and gDef:"g = lower-boundSEQ-4K3 X"
         sorry
      have " ex g be RealXREAL-0M1 st  for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|)"
      proof(rule bexI[of _ "g"],rule ballI,rule impI)
        fix s assume [ty]: "s be RealXREAL-0M1"
        assume A4: "0NUMBERSK6 <XXREAL-0R3 s"
        have A5: "( ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies r <=XXREAL-0R1 p) implies X be bounded-belowXXREAL-2V3"
        proof(rule impI)
          assume Given: " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies r <=XXREAL-0R1 p"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A6: " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies r <=XXREAL-0R1 p"
             sorry
          have " for p be ExtRealXXREAL-0M1 holds  not (p inHIDDENR3 X &  not r <=XXREAL-0R1 p)"
          proof(rule ballI)
            fix p assume [ty]: "p be ExtRealXXREAL-0M1"
            show " not (p inHIDDENR3 X &  not r <=XXREAL-0R1 p)"
              using A6 sorry
          qed "sorry"
          then have "r be LowerBoundXXREAL-2M2-of X"
            using xxreal_2_def_2 sorry
          thus "X be bounded-belowXXREAL-2V3"
            using bexI[of _ "r"] xxreal_2_def_9 sorry
        qed
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) inTARSKIR2 X"
          using A3 sorry
        then obtain p1 where
          [ty]:"p1 be RealXREAL-0M1" and 
          A7: "p1 inHIDDENR3 X"and A8: "p1 <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 s"
          using A5 A4 seq_4_def_2 sorry
        obtain n1 where
          [ty]:"n1 be NatNAT-1M1" and 
          A9: "p1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1"
          using A3 A7 sorry
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          obtain r1 where
            [ty]:"r1 be RealXREAL-0M1" and 
            A10: " for n be NatNAT-1M1 holds r1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A2 sorry
          have A11: " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies r <=XXREAL-0R1 p"
          proof-
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = r1"
               sorry
            show " ex r be RealXREAL-0M1 st  for p be RealXREAL-0M1 holds p inHIDDENR3 X implies r <=XXREAL-0R1 p"
            proof(rule bexI[of _ "r"],rule ballI,rule impI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              assume "p inHIDDENR3 X"
              then have " ex n1 be NatNAT-1M1 st p =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1"
                using A3 sorry
              thus "r <=XXREAL-0R1 p"
                using A10 sorry
            qed "sorry"
          qed
          have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m inTARSKIR2 X"
            using A3 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 g <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
            using A5 A11 seq_4_def_2 sorry
          then have A12: "0NUMBERSK6 <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g"
            using xreal_1_th_19 sorry
          assume "n <=XXREAL-0R1 m"
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 seqm_3_th_8 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <XXREAL-0R3 g +XCMPLX-0K2 s"
            using A8 A9 xxreal_0_th_2 sorry
          then have A13: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g <XXREAL-0R3 s"
            using xreal_1_th_19 sorry
          have "-XCMPLX-0K4 s <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
            using A4 sorry
          thus " not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g .|"
            using A13 A12 seq_2_th_1 sorry
        qed "sorry"
      qed "sorry"
      thus "seq be convergentSEQ-2V5"
        using seq_2_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_cl_5:
"cluster monotoneSEQM-3V5\<bar>boundedSEQ-2V6 also-is convergentSEQ-2V5 for Real-SequenceSEQ-1M1"
proof
(*coherence*)
  show " for it be Real-SequenceSEQ-1M1 holds it be monotoneSEQM-3V5\<bar>boundedSEQ-2V6 implies it be convergentSEQ-2V5"
  proof-
    have " for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 & seq be boundedSEQ-2V6 implies seq be convergentSEQ-2V5"
    proof(rule ballI,rule impMI ,rule impI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      assume A1: "seq be monotoneSEQM-3V5"
        and A2: "seq be boundedSEQ-2V6"
      have A3: "seq be non-increasingSEQM-3V4 implies seq be convergentSEQ-2V5"
        using A2 sorry
      have "seq be non-decreasingSEQM-3V3 implies seq be convergentSEQ-2V5"
        using A2 sorry
      thus "seq be convergentSEQ-2V5"
        using A1 A3 seqm_3_def_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_th_36:
" for seq be Real-SequenceSEQ-1M1 holds seq be monotoneSEQM-3V5 & seq be boundedSEQ-2V6 implies seq be convergentSEQ-2V5"
   sorry

mtheorem seq_4_th_37:
" for seq be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq be non-decreasingSEQM-3V3 implies ( for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 limSEQ-2K1 seq)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be bounded-aboveSEQ-2V3 & seq be non-decreasingSEQM-3V3 implies ( for m be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 limSEQ-2K1 seq)"
  proof(rule ballI,rule impMI ,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-aboveSEQ-2V3"
      and A2: "seq be non-decreasingSEQM-3V3"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?seq1 = "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    let ?U = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +XCMPLX-0K2 m)"
    obtain seq2 where
      [ty]:"seq2 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have A4: " for n be NatNAT-1M1 holds (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +XCMPLX-0K2 n)"
        using A3 funcop_1_th_7 sorry
      thus "(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 seqm_3_th_5 sorry
    qed "sorry"
    have "?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using funcop_1_th_7 sorry
    then have A5: "limSEQ-2K1 ?seq1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using seq_4_th_25 sorry
    have " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using A3 sorry
    then have A6: "seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using nat_1_def_3 sorry
    then have "limSEQ-2K1 seq2 =COMPLEX1R1 limSEQ-2K1 seq"
      using A1 A2 seq_4_th_17 sorry
    thus "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 limSEQ-2K1 seq"
      using A1 A2 A5 A6 A4 seq_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_38:
" for seq be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq be non-increasingSEQM-3V4 implies ( for n be NatNAT-1M1 holds limSEQ-2K1 seq <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be bounded-belowSEQ-2V4 & seq be non-increasingSEQM-3V4 implies ( for m be NatNAT-1M1 holds limSEQ-2K1 seq <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m)"
  proof(rule ballI,rule impMI ,rule impI,rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be bounded-belowSEQ-2V4"
      and A2: "seq be non-increasingSEQM-3V4"
    fix m assume [ty]: "m be NatNAT-1M1"
    let ?seq1 = "NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    let ?U = "\<lambda>Lamb1. seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Lamb1 +XCMPLX-0K2 m)"
    obtain seq2 where
      [ty]:"seq2 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using seq_1_sch_1 sorry
    have A4: " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m & seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (m +XCMPLX-0K2 n)"
        using A3 funcop_1_th_7 sorry
      thus "seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(REALNUMBERSK2)\<^esub> seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using A2 seqm_3_th_7 sorry
    qed "sorry"
    have "?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using funcop_1_th_7 sorry
    then have A5: "limSEQ-2K1 ?seq1 =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using seq_4_th_25 sorry
    have " for n be NatNAT-1M1 holds seq2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?U(n)"
      using A3 sorry
    then have A6: "seq2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using nat_1_def_3 sorry
    then have "limSEQ-2K1 seq2 =COMPLEX1R1 limSEQ-2K1 seq"
      using A1 A2 seq_4_th_17 sorry
    thus "limSEQ-2K1 seq <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
      using A1 A2 A5 A6 A4 seq_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_39:
" for seq be Real-SequenceSEQ-1M1 holds  ex Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  not ( for Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  not seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1.  for m be NatNAT-1M1 holds Lamb1 <XXREAL-0R3 m implies seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
    obtain XN where
      [ty]:"XN be SubsetSUBSET-1M2-of NATNUMBERSK1" and 
      A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 XN iff ?X(n)"
      using subset_1_sch_3 sorry
    have A2: "( ex k1 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n inTARSKIR2 XN implies n <=XXREAL-0R1 k1) implies ( ex Nseq1 be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1 be monotoneSEQM-3V5)"
    proof(rule impI)
      assume Given: " ex k1 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n inTARSKIR2 XN implies n <=XXREAL-0R1 k1"
      then obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A3: " for n be NatNAT-1M1 holds n inTARSKIR2 XN implies n <=XXREAL-0R1 k1"
         sorry
      let ?seq1 = "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)"
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds k =XBOOLE-0R4 Lamb2 & l =XBOOLE-0R4 Lamb3 implies (k <XXREAL-0R3 l & ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) & ( for m be NatNAT-1M1 holds k <XXREAL-0R3 m & ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies l <=XXREAL-0R1 m)"
      have A4: " for k be NatNAT-1M1 holds k1 <XXREAL-0R3 k implies ( ex n be NatNAT-1M1 st k <XXREAL-0R3 n & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have A5: "k inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        assume "k1 <XXREAL-0R3 k"
        then have " not k inTARSKIR2 XN"
          using A3 sorry
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A6: "k <XXREAL-0R3 m"and A7: " not seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m"
          using A1 A5 sorry
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = m"
           sorry
        show " ex n be NatNAT-1M1 st k <XXREAL-0R3 n & seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        proof(rule bexI[of _ "n"],rule conjMI)
          show "k <XXREAL-0R3 n"
            using A6 sorry
          show "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using A7 sorry
        qed "sorry"
      qed "sorry"
      have A8: " for k be NatNAT-1M1 holds  ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st k <XXREAL-0R3 l & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
      proof(rule ballI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have "0NUMBERSK6 +XCMPLX-0K2 k1 <XXREAL-0R3 (k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k1"
          using xreal_1_th_8 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A9: "(k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k1 <XXREAL-0R3 n"and A10: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k1)"
          using A4 sorry
        obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A11: "n =COMPLEX1R1 ((k +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k1)+XCMPLX-0K2 m"
          using A9 nat_1_th_10 sorry
        have 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "n -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 k1) =COMPLEX1R1 (k +XCMPLX-0K2 0NUMBERSK6)+NAT-1K1 m"
          using A11 sorry
        then obtain n1 where
          [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A12: "n1 =COMPLEX1R1 n -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 k1)"
           sorry
        have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k1))"
          using A10 sorry
        then have A13: "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using nat_1_def_3 sorry
        obtain l where 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n1"
           sorry
        show " ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st k <XXREAL-0R3 l & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
        proof(rule bexI[of _ "l"],rule conjMI)
          have " not k <XXREAL-0R3 l implies  False "
          proof(rule impI)
            assume " not k <XXREAL-0R3 l"
            then have "(n -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 k1))+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k1) <=XXREAL-0R1 k +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k1)"
              using A12 xreal_1_th_6 sorry
            thus " False "
              using A9 sorry
          qed
          thus "k <XXREAL-0R3 l"
             sorry
          have "n =COMPLEX1R1 l +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 k1)"
            using A12 sorry
          thus "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
            using A13 nat_1_def_3 sorry
        qed "sorry"
      qed "sorry"
      have A14: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar43 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar43 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for k be NatNAT-1M1 holds  for lc be NatNAT-1M1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 tVar43 implies (k <XXREAL-0R3 lc & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> lc <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) & ( for m be NatNAT-1M1 holds k <XXREAL-0R3 m & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies lc <=XXREAL-0R1 m))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          let ?X = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x"
          have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
            using A8 sorry
          then have A15: " ex n be NatNAT-1M1 st ?X(n)"
             sorry
          have " ex l be NatNAT-1M1 st ?X(l) & ( for m be NatNAT-1M1 holds ?X(m) implies l <=XXREAL-0R1 m)"
            using nat_1_sch_5 A15 sorry
          then obtain l where
            [ty]:"l be NatNAT-1M1" and 
            A16: "(x <XXREAL-0R3 l & ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> l <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x) & ( for m be NatNAT-1M1 holds x <XXREAL-0R3 m & ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> x implies l <=XXREAL-0R1 m)"
             sorry
          show " ex tVar43 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar43 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for k be NatNAT-1M1 holds  for lc be NatNAT-1M1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 tVar43 implies (k <XXREAL-0R3 lc & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> lc <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) & ( for m be NatNAT-1M1 holds k <XXREAL-0R3 m & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies lc <=XXREAL-0R1 m))"
          proof(rule bexI[of _ "l"])
            have "l inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for k be NatNAT-1M1 holds  for lc be NatNAT-1M1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 l implies (k <XXREAL-0R3 lc & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> lc <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) & ( for m be NatNAT-1M1 holds k <XXREAL-0R3 m & (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m <=XXREAL-0R1 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +XCMPLX-0K2 k1)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies lc <=XXREAL-0R1 m))"
              using A16 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of NATNUMBERSK1" and 
        "f .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"and A17: " for n be NatNAT-1M1 holds ?P(n,f .RECDEF-1K1 n,f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using recdef_1_sch_2 A14 sorry
      have A18: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f =MEMBEREDR12 NATNUMBERSK1"
        using funct_2_def_1 sorry
      have "rngRVSUM-1K1 f c=MEMBEREDR6 REALNUMBERSK2"
         sorry
      then have 
        [ty]:"f be Real-SequenceSEQ-1M1"
        using A18 relset_1_th_4 sorry
      have " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using A17 sorry
      then have 
        [ty]:"f be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
        using seqm_3_def_6 sorry
      obtain Nseq where
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
        A19: "?seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using valued_0_def_17 sorry
      obtain Nseq1 where 
        [ty]:"Nseq1 be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and Nseq1Def:"Nseq1 = Nseq *VALUED-0K2\<^bsub>(NATNUMBERSK1)\<^esub> f"
         sorry
      show " ex Nseq1 be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1 be monotoneSEQM-3V5"
      proof(rule bexI[of _ "Nseq1"])
        have " for n be NatNAT-1M1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A20: "n inTARSKIR2 NATNUMBERSK1 & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (f .RECDEF-1K1 n)"
            using A17 sorry
          then have "(?seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> f).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 ?seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (f .RECDEF-1K1 n)"
            using funct_2_th_15 sorry
          then have "((seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> f).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 (?seq1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> f).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A19 funct_2_th_15 A20 sorry
          then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 ((seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq)*VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> f).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A19 relat_1_th_36 sorry
          thus "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using relat_1_th_36 sorry
        qed "sorry"
        then have "seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1 be non-increasingSEQM-3V4"
           sorry
        thus "seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq1 be monotoneSEQM-3V5"
          using seqm_3_def_5 sorry
      qed "sorry"
    qed
    have "( for l be NatNAT-1M1 holds  ex n be NatNAT-1M1 st n inTARSKIR2 XN &  not n <=XXREAL-0R1 l) implies ( ex Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5)"
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for l be ElementSUBSET-1M1-of NATNUMBERSK1 holds k =XBOOLE-0R4 Lamb2 & l =XBOOLE-0R4 Lamb3 implies (l inTARSKIR2 XN & k <XXREAL-0R3 l) & ( for m be NatNAT-1M1 holds m inTARSKIR2 XN & k <XXREAL-0R3 m implies l <=XXREAL-0R1 m)"
      assume A21: " for l be NatNAT-1M1 holds  ex n be NatNAT-1M1 st n inTARSKIR2 XN &  not n <=XXREAL-0R1 l"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A22: "n1 inTARSKIR2 XN"and " not n1 <=XXREAL-0R1 0NUMBERSK6"
         sorry
      obtain O9 where 
        [ty]:"O9 be ElementSUBSET-1M1-of NATNUMBERSK1" and O9Def:"O9 = n1"
        using ordinal1_def_12 sorry
      have A23: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar45 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for lc be ElementSUBSET-1M1-of NATNUMBERSK1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 tVar45 implies (lc inTARSKIR2 XN & k <XXREAL-0R3 lc) & ( for m be NatNAT-1M1 holds m inTARSKIR2 XN & k <XXREAL-0R3 m implies lc <=XXREAL-0R1 m)"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 XN & x <XXREAL-0R3 Lamb1"
          have " ex n be NatNAT-1M1 st ?X(n)"
            using A21 sorry
          then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?X(n)"
             sorry
          then have A24: " ex n be NatNAT-1M1 st ?X(n)"
             sorry
          have " ex l be NatNAT-1M1 st ?X(l) & ( for m be NatNAT-1M1 holds ?X(m) implies l <=XXREAL-0R1 m)"
            using nat_1_sch_5 A24 sorry
          then obtain l where
            [ty]:"l be NatNAT-1M1" and 
            A25: "(l inTARSKIR2 XN & x <XXREAL-0R3 l) & ( for m be NatNAT-1M1 holds m inTARSKIR2 XN & x <XXREAL-0R3 m implies l <=XXREAL-0R1 m)"
             sorry
          have 
            [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          show " ex tVar45 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for lc be ElementSUBSET-1M1-of NATNUMBERSK1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 tVar45 implies (lc inTARSKIR2 XN & k <XXREAL-0R3 lc) & ( for m be NatNAT-1M1 holds m inTARSKIR2 XN & k <XXREAL-0R3 m implies lc <=XXREAL-0R1 m)"
          proof(rule bexI[of _ "l"])
            show " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for lc be ElementSUBSET-1M1-of NATNUMBERSK1 holds k =XBOOLE-0R4 x & lc =XBOOLE-0R4 l implies (lc inTARSKIR2 XN & k <XXREAL-0R3 lc) & ( for m be NatNAT-1M1 holds m inTARSKIR2 XN & k <XXREAL-0R3 m implies lc <=XXREAL-0R1 m)"
              using A25 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of NATNUMBERSK1" and 
        A26: "f .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 O9"and A27: " for n be NatNAT-1M1 holds ?P(n,f .RECDEF-1K1 n,f .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using recdef_1_sch_2 A23 sorry
      have A28: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f =MEMBEREDR12 NATNUMBERSK1"
        using funct_2_def_1 sorry
      have "rngRVSUM-1K1 f c=MEMBEREDR6 REALNUMBERSK2"
         sorry
      then have 
        [ty]:"f be Real-SequenceSEQ-1M1"
        using A28 relset_1_th_4 sorry
      have A29: " for n be NatNAT-1M1 holds n be ElementSUBSET-1M1-of NATNUMBERSK1 & f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have A30: " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1 & f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A29 sorry
        thus "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A27 sorry
      qed "sorry"
      have A31: " for n be NatNAT-1M1 holds  for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 XN"
      proof(rule ballI)
        let ?X = "\<lambda>Lamb1. f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 inTARSKIR2 XN"
        fix n assume [ty]: "n be NatNAT-1M1"
        have A32: " for k be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k inTARSKIR2 XN implies f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 XN"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume "?X(k)"
          have "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k be ElementSUBSET-1M1-of NATNUMBERSK1 & f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
            using A29 sorry
          thus "f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 XN"
            using A27 sorry
        qed "sorry"
        have A33: "?X(0NUMBERSK6)"
          using A22 A26 sorry
        show " for n be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n inTARSKIR2 XN"
          using nat_1_sch_2 A33 A32 sorry
      qed "sorry"
      have 
        [ty]:"f be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
        using A30 seqm_3_def_6 sorry
      obtain Nseq where 
        [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and NseqDef:"Nseq = f"
         sorry
      show " ex Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5"
      proof(rule bexI[of _ "Nseq"])
        have " for n be NatNAT-1M1 holds (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A34: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "Nseq .RECDEF-1K1 n inTARSKIR2 XN & Nseq .RECDEF-1K1 n <XXREAL-0R3 Nseq .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A31 A30 sorry
          then have "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 n) <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using A1 sorry
          then have "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
            using funct_2_th_15 A34 sorry
          thus "(seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_th_15 sorry
        qed "sorry"
        then have "seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be increasingSEQM-3V1"
           sorry
        thus "seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5"
          using seqm_3_def_5 sorry
      qed "sorry"
    qed
    thus " not ( for Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1 holds  not seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Bolzano-Weierstrass Theorem (1 dimension)*)
mtheorem seq_4_th_40:
" for seq be Real-SequenceSEQ-1M1 holds seq be boundedSEQ-2V6 implies ( ex seq1 be Real-SequenceSEQ-1M1 st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be convergentSEQ-2V5)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be boundedSEQ-2V6 implies ( ex seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be convergentSEQ-2V5)"
  proof(rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be boundedSEQ-2V6"
    obtain Nseq where
      [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A2: "seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq be monotoneSEQM-3V5"
      using seq_4_th_39 sorry
    obtain seq1 where 
      [ty]:"seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq" and seq1Def:"seq1 = seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
       sorry
    show " ex seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq st seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq & seq1 be convergentSEQ-2V5"
    proof(rule bexI[of _ "seq1"],rule conjMI)
      show "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"
         sorry
      show "seq1 be convergentSEQ-2V5"
        using A1 A2 seq_4_th_36 seqm_3_th_29 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Cauchy sequence*)
mtheorem seq_4_th_41:
" for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 iff ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds (seq be convergentSEQ-2V5 implies ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s))) & (( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s)) implies seq be convergentSEQ-2V5)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    show "seq be convergentSEQ-2V5 implies ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s))"
    proof-
      have "seq be convergentSEQ-2V5 implies ( for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s))"
      proof(rule impI,rule ballI,rule impI)
        assume "seq be convergentSEQ-2V5"
        then obtain g1 where
          [ty]:"g1 be RealXREAL-0M1" and 
          A1: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s)"
           sorry
        fix s assume [ty]: "s be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 s"
        then obtain n1 where
          [ty]:"n1 be NatNAT-1M1" and 
          A2: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
          using A1 sorry
        obtain n where 
          [ty]:"n be NatNAT-1M1" and nDef:"n = n1"
           sorry
        show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s"
        proof(rule bexI[of _ "n"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "n <=XXREAL-0R1 m"
          then have A3: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
            using A2 sorry
          have A4: " |.COMPLEX1K10 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1)+XCMPLX-0K2 (g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| +XCMPLX-0K2  |.COMPLEX1K10 g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .|"
            using complex1_th_56 sorry
          have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
            using A2 sorry
          then have " |.COMPLEX1K10 -XCMPLX-0K4 (g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
             sorry
          then have " |.COMPLEX1K10 g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M"
            using complex1_th_52 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| +XCMPLX-0K2  |.COMPLEX1K10 g1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<two>\<^sub>M"
            using A3 xreal_1_th_8 sorry
          thus " not  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s"
            using A4 xxreal_0_th_2 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A5: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n .| <XXREAL-0R3 s)"
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 .| <XXREAL-0R3 \<one>\<^sub>M"
       sorry
    obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A7: "0NUMBERSK6 <XXREAL-0R3 r1"and A8: " for m be NatNAT-1M1 holds m <=XXREAL-0R1 n1 implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r1"
      using seq_2_th_4 sorry
    have " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r)"
    proof-
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = (r1 +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.|)+XCMPLX-0K2 \<one>\<^sub>M"
         sorry
      show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI)
        have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r1 +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.|"
          using A7 complex1_th_46 xreal_1_th_8 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 r"
           sorry
        fix m assume [ty]: "m be NatNAT-1M1"
        have A9: "n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r"
        proof(rule impI)
          assume "n1 <=XXREAL-0R1 m"
          then have A10: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 .| <XXREAL-0R3 \<one>\<^sub>M"
            using A6 sorry
          have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1 .|"
            using complex1_th_59 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.| <XXREAL-0R3 \<one>\<^sub>M"
            using A10 xxreal_0_th_2 sorry
          then have "( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| -XCMPLX-0K6  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.|)+XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.| <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.|"
            using xreal_1_th_6 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r1 +XCMPLX-0K2 ( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.| +XCMPLX-0K2 \<one>\<^sub>M)"
            using A7 xreal_1_th_8 sorry
          thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r"
             sorry
        qed
        have "m <=XXREAL-0R1 n1 implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r"
        proof(rule impI)
          assume "m <=XXREAL-0R1 n1"
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r1"
            using A8 sorry
          then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r1 +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n1.|"
            using complex1_th_46 xreal_1_th_8 sorry
          thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r"
            using xreal_1_th_8 sorry
        qed
        thus " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m.| <XXREAL-0R3 r"
          using A9 sorry
      qed "sorry"
    qed
    then have "seq be boundedSEQ-2V6"
      using seq_2_th_3 sorry
    then obtain seq1 where
      [ty]:"seq1 be Real-SequenceSEQ-1M1" and 
      A11: "seq1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of seq"and A12: "seq1 be convergentSEQ-2V5"
      using seq_4_th_40 sorry
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A13: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s)"
      using A12 sorry
    have " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be RealXREAL-0M1"
      assume A14: "0NUMBERSK6 <XXREAL-0R3 s"
      then obtain n1 where
        [ty]:"n1 be NatNAT-1M1" and 
        A15: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
        using A13 sorry
      obtain n2 where
        [ty]:"n2 be NatNAT-1M1" and 
        A16: " for m be NatNAT-1M1 holds n2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
        using A5 A14 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = n1 +XCMPLX-0K2 n2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A17: "n <=XXREAL-0R1 m"
        obtain Nseq where
          [ty]:"Nseq be increasingSEQM-3V1\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
          A18: "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
          using A11 valued_0_def_17 sorry
        have A19: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "n1 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have "n1 <=XXREAL-0R1 m"
          using A17 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 (seq *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A18 A15 sorry
        then have A20: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) -XCMPLX-0K6 g1 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
          using funct_2_th_15 A19 sorry
        have "n2 <=XXREAL-0R1 n"
          using nat_1_th_12 sorry
        then have A21: "n2 <=XXREAL-0R1 m"
          using A17 xxreal_0_th_2 sorry
        have "m <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using seqm_3_th_14 sorry
        then have "n2 <=XXREAL-0R1 Nseq .RECDEF-1K1 m"
          using A21 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A16 sorry
        then have " |.COMPLEX1K10 -REAL-1K1 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m)) .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
           sorry
        then have A22: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
          using complex1_th_52 sorry
        have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A16 A21 sorry
        then have A23: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A22 xreal_1_th_8 sorry
        have " |.COMPLEX1K10 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2)+REAL-1K3 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m)) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n2 -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .|"
          using complex1_th_56 sorry
        then have " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .| <XXREAL-0R3 s /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A23 xxreal_0_th_2 sorry
        then have A24: " |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) -XCMPLX-0K6 g1 .| <XXREAL-0R3 (s /XCMPLX-0K7 \<three>\<^sub>M +XCMPLX-0K2 s /XCMPLX-0K7 \<three>\<^sub>M)+XCMPLX-0K2 s /XCMPLX-0K7 \<three>\<^sub>M"
          using A20 xreal_1_th_8 sorry
        have " |.COMPLEX1K10 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m))+XCMPLX-0K2 (seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) -XCMPLX-0K6 g1) .| <=XXREAL-0R1  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> m -REAL-1K5 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) .| +XCMPLX-0K2  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (Nseq .RECDEF-1K1 m) -XCMPLX-0K6 g1 .|"
          using complex1_th_56 sorry
        thus " not s <=XXREAL-0R1  |.COMPLEX1K10 seq .FUNCT-1K1 m -XCMPLX-0K6 g1 .|"
          using A24 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "seq be convergentSEQ-2V5"
      using bexI[of _ "g1"] seq_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_42:
" for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentSEQ-2V5 implies ((limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limSEQ-2K1 seq1 & limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limSEQ-2K1 seq1) & limSEQ-2K1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =COMPLEX1R1 limSEQ-2K1 seq1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)) & limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =COMPLEX1R1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limSEQ-2K1 seq1)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds  for seq1 be Real-SequenceSEQ-1M1 holds seq be constantVALUED-0V15 & seq1 be convergentSEQ-2V5 implies limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limSEQ-2K1 seq1 & (limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limSEQ-2K1 seq1 & (limSEQ-2K1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 limSEQ-2K1 seq1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) & limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limSEQ-2K1 seq1)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
    assume A1: "seq be constantVALUED-0V15"
      and A2: "seq1 be convergentSEQ-2V5"
    have "limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 limSEQ-2K1 seq +XCMPLX-0K2 limSEQ-2K1 seq1"
      using A1 A2 seq_2_th_6 sorry
    also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limSEQ-2K1 seq1"
      using A1 seq_4_th_25 sorry
    finally show "limSEQ-2K1 (seq +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 limSEQ-2K1 seq1"
       sorry
    have "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 limSEQ-2K1 seq -XCMPLX-0K6 limSEQ-2K1 seq1"
      using A1 A2 seq_2_th_12 sorry
    also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limSEQ-2K1 seq1"
      using A1 seq_4_th_25 sorry
    finally show "limSEQ-2K1 (seq -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 limSEQ-2K1 seq1"
       sorry
    have "limSEQ-2K1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 limSEQ-2K1 seq1 -XCMPLX-0K6 limSEQ-2K1 seq"
      using A1 A2 seq_2_th_12 sorry
    also have "... = limSEQ-2K1 seq1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using A1 seq_4_th_25 sorry
    finally show "limSEQ-2K1 (seq1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq) =HIDDENR1 limSEQ-2K1 seq1 -XCMPLX-0K6 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    have "limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 seq1)"
      using A1 A2 seq_2_th_15 sorry
    also have "... = seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limSEQ-2K1 seq1)"
      using A1 seq_4_th_25 sorry
    finally show "limSEQ-2K1 (seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1) =HIDDENR1 seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (limSEQ-2K1 seq1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem seq_4_th_43:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 t"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies (lower-boundSEQ-4K3 X <XXREAL-0R3 t implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    let ?r = "lower-boundSEQ-4K3 X"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t"
    let ?s = "t -XCMPLX-0K6 ?r"
    assume "?r <XXREAL-0R3 t"
    then have A2: "?s >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_50 sorry
    have "X be bounded-belowXXREAL-2V3"
    proof-
      have " for s be ExtRealXXREAL-0M1 holds  not (s inHIDDENR3 X &  not t <=XXREAL-0R1 s)"
      proof(rule ballI)
        fix s assume [ty]: "s be ExtRealXXREAL-0M1"
        show " not (s inHIDDENR3 X &  not t <=XXREAL-0R1 s)"
          using A1 sorry
      qed "sorry"
      then have "t be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "t"] xxreal_2_def_9 sorry
    qed
    then have " ex t9 be RealXREAL-0M1 st t9 inHIDDENR3 X & t9 <XXREAL-0R3 ?r +XCMPLX-0K2 ?s"
      using A2 seq_4_def_2 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_44:
" for r be RealXREAL-0M1 holds  for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s >=XXREAL-0R2 t) implies r >=XXREAL-0R2 t) implies r =COMPLEX1R1 lower-boundSEQ-4K3 X"
  using seq_4_lm_1 sorry

mtheorem seq_4_th_45:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies upper-boundSEQ-4K2 X <=XXREAL-0R1 t"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies (upper-boundSEQ-4K2 X >XXREAL-0R4 t implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?r = "upper-boundSEQ-4K2 X"
    fix t assume [ty]: "t be RealXREAL-0M1"
    assume A1: " for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t"
    let ?s = "?r -XCMPLX-0K6 t"
    assume "?r >XXREAL-0R4 t"
    then have A2: "?s >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_50 sorry
    have "X be bounded-aboveXXREAL-2V4"
    proof-
      have " for s be ExtRealXXREAL-0M1 holds  not (s inHIDDENR3 X &  not s <=XXREAL-0R1 t)"
      proof(rule ballI)
        fix s assume [ty]: "s be ExtRealXXREAL-0M1"
        show " not (s inHIDDENR3 X &  not s <=XXREAL-0R1 t)"
          using A1 sorry
      qed "sorry"
      then have "t be UpperBoundXXREAL-2M1-of X"
        using xxreal_2_def_1 sorry
      thus "X be bounded-aboveXXREAL-2V4"
        using bexI[of _ "t"] xxreal_2_def_10 sorry
    qed
    then have " ex t9 be RealXREAL-0M1 st t9 inHIDDENR3 X & ?r -XCMPLX-0K6 ?s <XXREAL-0R3 t9"
      using A2 seq_4_def_1 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_46:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for r be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 r) & ( for t be RealXREAL-0M1 holds ( for s be RealXREAL-0M1 holds s inHIDDENR3 X implies s <=XXREAL-0R1 t) implies r <=XXREAL-0R1 t) implies r =COMPLEX1R1 upper-boundSEQ-4K2 X"
  using seq_4_lm_2 sorry

mtheorem seq_4_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 Y & Y be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 Y <=XXREAL-0R1 lower-boundSEQ-4K3 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
  assume "X c=MEMBEREDR3 Y & Y be bounded-belowXXREAL-2V3"
  then have " for t be RealXREAL-0M1 holds t inHIDDENR3 X implies t >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
    using seq_4_def_2 sorry
  thus "lower-boundSEQ-4K3 Y <=XXREAL-0R1 lower-boundSEQ-4K3 X"
    using seq_4_th_43 sorry
qed "sorry"

mtheorem seq_4_th_48:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  for Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X c=MEMBEREDR3 Y & Y be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 X <=XXREAL-0R1 upper-boundSEQ-4K2 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
  assume "X c=MEMBEREDR3 Y & Y be bounded-aboveXXREAL-2V4"
  then have " for t be RealXREAL-0M1 holds t inHIDDENR3 X implies t <=XXREAL-0R1 upper-boundSEQ-4K2 Y"
    using seq_4_def_1 sorry
  thus "upper-boundSEQ-4K2 X <=XXREAL-0R1 upper-boundSEQ-4K2 Y"
    using seq_4_th_45 sorry
qed "sorry"

abbreviation(input) SEQ_4K4("minSEQ-4K4  _ " [228]228) where
  "minSEQ-4K4 A \<equiv> infXXREAL-2K2 A"

mtheorem seq_4_add_2:
  mlet "A be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster infXXREAL-2K2 A as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "infXXREAL-2K2 A be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

(*begin*)
reserve k, n for "NatNAT-1M1"
reserve r, r9, r1, r2 for "RealXREAL-0M1"
reserve c, c9, c1, c2, c3 for "ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
mtheorem seq_4_th_49:
"0cCOMPLEX1K6 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
  using binop_2_th_1 setwiseo_th_14 sorry

mtheorem seq_4_th_50:
"compcomplexBINOP-2K1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
proof-
  have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c,compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3) & addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c,c) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)"
  proof(rule ballI,rule conjMI)
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c,compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 c +XCMPLX-0K2 compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c"
      using binop_2_def_3 sorry
    also have "... = c +XCMPLX-0K2 (-XCMPLX-0K4 c)"
      using binop_2_def_1 sorry
    also have "... = the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)"
      using binop_2_th_1 sorry
    finally show "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c,compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)"
       sorry
    have "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c,c) =HIDDENR1 compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c +XCMPLX-0K2 c"
      using binop_2_def_3 sorry
    also have "... = (-XCMPLX-0K4 c)+XCMPLX-0K2 c"
      using binop_2_def_1 sorry
    also have "... = the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)"
      using binop_2_th_1 sorry
    finally show "addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c,c) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (addcomplexBINOP-2K3)"
       sorry
  qed "sorry"
  thus "compcomplexBINOP-2K1 is-an-inverseOp-wrtFINSEQOPR1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
    using finseqop_def_1 sorry
qed

mtheorem seq_4_th_51:
"addcomplexBINOP-2K3 be having-an-inverseOpFINSEQOPV1\<^bsub>(COMPLEXNUMBERSK3)\<^esub>"
  using seq_4_th_50 sorry

mtheorem seq_4_th_52:
"the-inverseOp-wrtFINSEQOPK5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3 =FUNCT-2R2\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> compcomplexBINOP-2K1"
  using seq_4_th_50 seq_4_th_51 finseqop_def_3 sorry

abbreviation(input) SEQ_4K5("diffcomplexSEQ-4K5" 228) where
  "diffcomplexSEQ-4K5 \<equiv> diffcomplexBINOP-2K4"

mtheorem seq_4_def_3:
"redefine func diffcomplexSEQ-4K5 \<rightarrow> ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3 :]) equals
  addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :],COMPLEXNUMBERSK3 :]) holds it =HIDDENR1 diffcomplexSEQ-4K5 iff it =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)"
  proof-
    have " for b be BinOpBINOP-1M2-of COMPLEXNUMBERSK3 holds  not (b =HIDDENR1 diffcomplexBINOP-2K4 &  not b =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)) &  not (b =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1) &  not b =HIDDENR1 diffcomplexBINOP-2K4)"
    proof(rule ballI)
      fix b assume [ty]: "b be BinOpBINOP-1M2-of COMPLEXNUMBERSK3"
      have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds diffcomplexBINOP-2K4 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 (addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)).BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2)"
      proof(rule ballI,rule ballI)
        fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        have "diffcomplexBINOP-2K4 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 c1 -XCMPLX-0K6 c2"
          using binop_2_def_4 sorry
        also have "... = c1 +XCMPLX-0K2 (-XCMPLX-0K4 c2)"
           sorry
        also have "... = addcomplexBINOP-2K3 .BINOP-1K1(c1,-XCMPLX-0K4 c2)"
          using binop_2_def_3 sorry
        also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c2)"
          using binop_2_def_1 sorry
        also have "... = (addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)).BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2)"
          using finseqop_th_82 sorry
        finally show "diffcomplexBINOP-2K4 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2) =HIDDENR1 (addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)).BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2)"
           sorry
      qed "sorry"
      thus " not (b =HIDDENR1 diffcomplexBINOP-2K4 &  not b =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1)) &  not (b =HIDDENR1 addcomplexBINOP-2K3 *FINSEQOPK7\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(idPARTFUN1K6 (COMPLEXNUMBERSK3),compcomplexBINOP-2K1) &  not b =HIDDENR1 diffcomplexBINOP-2K4)"
        using binop_1_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_th_53:
"1rCOMPLEX1K7 is-a-unity-wrtBINOP-1R3\<^bsub>(COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5"
  using binop_2_th_6 setwiseo_th_14 sorry

mtheorem seq_4_th_54:
"multcomplexBINOP-2K5 is-distributive-wrtBINOP-1R6\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
proof-
  have " for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3)) & multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c3 assume [ty]: "c3 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K1(c1,c2 +XCMPLX-0K2 c3)"
      using binop_2_def_3 sorry
    also have "... = c1 *XCMPLX-0K3 (c2 +XCMPLX-0K2 c3)"
      using binop_2_def_5 sorry
    also have "... = c1 *XCMPLX-0K3 c2 +XCMPLX-0K2 c1 *XCMPLX-0K3 c3"
       sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K1(c1 *XCMPLX-0K3 c2,c1 *XCMPLX-0K3 c3)"
      using binop_2_def_3 sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K1(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c1 *XCMPLX-0K3 c3)"
      using binop_2_def_5 sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3))"
      using binop_2_def_5 sorry
    finally show "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3)) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3))"
       sorry
    have "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3) =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K1(c1 +XCMPLX-0K2 c2,c3)"
      using binop_2_def_3 sorry
    also have "... = (c1 +XCMPLX-0K2 c2)*XCMPLX-0K3 c3"
      using binop_2_def_5 sorry
    also have "... = c1 *XCMPLX-0K3 c3 +XCMPLX-0K2 c2 *XCMPLX-0K3 c3"
       sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K1(c1 *XCMPLX-0K3 c3,c2 *XCMPLX-0K3 c3)"
      using binop_2_def_3 sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K1(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3),c2 *XCMPLX-0K3 c3)"
      using binop_2_def_5 sorry
    also have "... = addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3))"
      using binop_2_def_5 sorry
    finally show "multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),c3) =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c3),multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c2,c3))"
       sorry
  qed "sorry"
  thus "multcomplexBINOP-2K5 is-distributive-wrtBINOP-1R6\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
    using binop_1_th_11 sorry
qed

mdef seq_4_def_4 (" _ multcomplexSEQ-4K6" [228]228 ) where
  mlet "c be ComplexXCMPLX-0M1"
"func c multcomplexSEQ-4K6 \<rightarrow> UnOpBINOP-1M1-of COMPLEXNUMBERSK3 equals
  multcomplexBINOP-2K5 [;]FUNCOP-1K5(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))"
proof-
  (*coherence*)
    show "multcomplexBINOP-2K5 [;]FUNCOP-1K5(c,idPARTFUN1K6 (COMPLEXNUMBERSK3)) be UnOpBINOP-1M1-of COMPLEXNUMBERSK3"
    proof-
      obtain c9 where 
        [ty]:"c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c9Def:"c9 = c"
        using xcmplx_0_def_2 sorry
      have "multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c9,idPARTFUN1K6 (COMPLEXNUMBERSK3)) be UnOpBINOP-1M1-of COMPLEXNUMBERSK3"
         sorry
      thus "multcomplexBINOP-2K5 [;]FUNCOP-1K5(c,idPARTFUN1K6 (COMPLEXNUMBERSK3)) be UnOpBINOP-1M1-of COMPLEXNUMBERSK3"
         sorry
    qed
qed "sorry"

mlemma seq_4_lm_9:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds (multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))).FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =COMPLEX1R1 c *XCMPLX-0K3 c9"
proof-
  have " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds (multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))).FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =HIDDENR1 c *XCMPLX-0K3 c9"
  proof(rule ballI,rule ballI)
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c9 assume [ty]: "c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have "(multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))).FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =HIDDENR1 multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3) .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9)"
      using funcop_1_th_53 sorry
    also have "... = multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c,c9)"
       sorry
    also have "... = c *XCMPLX-0K3 c9"
      using binop_2_def_5 sorry
    finally show "(multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c,idPARTFUN1K6 (COMPLEXNUMBERSK3))).FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =HIDDENR1 c *XCMPLX-0K3 c9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_55:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds c multcomplexSEQ-4K6 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9 =COMPLEX1R1 c *XCMPLX-0K3 c9"
  using seq_4_lm_9 sorry

mtheorem seq_4_th_56:
" for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds c multcomplexSEQ-4K6 is-distributive-wrtBINOP-1R12\<^bsub>(COMPLEXNUMBERSK3)\<^esub> addcomplexBINOP-2K3"
  using seq_4_th_54 finseqop_th_54 sorry

mdef seq_4_def_5 ("abscomplexSEQ-4K7" 228 ) where
"func abscomplexSEQ-4K7 \<rightarrow> FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) means
  \<lambda>it.  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) st  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|"
    proof-
      have " ex tVar54 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) st  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds tVar54 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =HIDDENR1  |.COMPLEX1K10 c.|"
      proof-
        let ?F = "\<lambda>Lamb1. InSUBSET-1K10( |.COMPLEX1K10 Lamb1.|,REALNUMBERSK2)"
        obtain F where
          [ty]:"F be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2)" and 
          A1: " for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds F .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1 ?F(c)"
          using funct_2_sch_4 sorry
        show " ex tVar54 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) st  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds tVar54 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =HIDDENR1  |.COMPLEX1K10 c.|"
        proof(rule bexI[of _ "F"],rule ballI)
          fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          have "F .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =HIDDENR1 InSUBSET-1K10( |.COMPLEX1K10 c.|,REALNUMBERSK2)"
            using A1 sorry
          also have "... =  |.COMPLEX1K10 c.|"
             sorry
          finally show "F .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =HIDDENR1  |.COMPLEX1K10 c.|"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(COMPLEXNUMBERSK3,REALNUMBERSK2) holds ( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|) & ( for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it2 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c =COMPLEX1R1  |.COMPLEX1K10 c.|) implies it1 =HIDDENR1 it2"
      using binop_2_sch_1 sorry
qed "sorry"

reserve z, z1, z2 for "FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
abbreviation(input) SEQ_4K8(" _ +SEQ-4K8  _ " [132,132]132) where
  "z1 +SEQ-4K8 z2 \<equiv> z1 +VALUED-1K1 z2"

mtheorem seq_4_def_6:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func z1 +SEQ-4K8 z2 \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z1 +SEQ-4K8 z2 iff it =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
  proof-
    have " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z1 +VALUED-1K1 z2 &  not VarFor1 =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)) &  not (VarFor1 =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2) &  not VarFor1 =HIDDENR1 z1 +VALUED-1K1 z2)"
    proof-
      let ?g = "addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
      have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :])\<^esub> (addcomplexBINOP-2K3) =RELAT-1R1 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :]"
        using funct_2_def_1 sorry
      then have "[:ZFMISC-1K2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1,rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 :] c=RELAT-1R2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :])\<^esub> (addcomplexBINOP-2K3)"
        using zfmisc_1_th_96 sorry
      then have A1: "domFINSEQ-1K5 (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) =MEMBEREDR12 domFINSEQ-1K5 z1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domFINSEQ-1K5 z2 & domFINSEQ-1K5 ?g =MEMBEREDR12 domFINSEQ-1K5 z1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domFINSEQ-1K5 z2"
        using funcop_1_th_69 valued_1_def_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) implies (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 (addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domFINSEQ-1K5 (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2)"
        then have "(z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 z1 .FUNCT-1K1 x +XCMPLX-0K2 z2 .FUNCT-1K1 x"
          using valued_1_def_1 sorry
        also have "... = addcomplexBINOP-2K3 .BINOP-1K1(z1 .FUNCT-1K1 x,z2 .FUNCT-1K1 x)"
          using binop_2_def_3 sorry
        also have "... = (addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
          using A1 A2 funcop_1_th_22 sorry
        finally show "(z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 (addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z1 +VALUED-1K1 z2 &  not VarFor1 =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)) &  not (VarFor1 =HIDDENR1 addcomplexBINOP-2K3 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2) &  not VarFor1 =HIDDENR1 z1 +VALUED-1K1 z2)"
        using A1 funct_1_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_add_3:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster z1 +VALUED-1K1 z2 as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z1 +VALUED-1K1 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  proof-
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
    proof-
      show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (z1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
         sorry
    qed
    thus "z1 +VALUED-1K1 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

abbreviation(input) SEQ_4K9(" _ -SEQ-4K9  _ " [132,132]132) where
  "z1 -SEQ-4K9 z2 \<equiv> z1 -VALUED-1K47 z2"

mtheorem seq_4_def_7:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func z1 -SEQ-4K9 z2 \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 z1 -SEQ-4K9 z2 iff it =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
  proof-
    have " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z1 -VALUED-1K47 z2 &  not VarFor1 =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)) &  not (VarFor1 =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2) &  not VarFor1 =HIDDENR1 z1 -VALUED-1K47 z2)"
    proof-
      let ?g = "diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)"
      have "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :])\<^esub> (diffcomplexSEQ-4K5) =RELAT-1R1 [:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :]"
        using funct_2_def_1 sorry
      then have "[:ZFMISC-1K2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z1,rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z2 :] c=RELAT-1R2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 COMPLEXNUMBERSK3,COMPLEXNUMBERSK3 :])\<^esub> (diffcomplexSEQ-4K5)"
        using zfmisc_1_th_96 sorry
      then have A3: "domFINSEQ-1K5 ?g =MEMBEREDR12 domFINSEQ-1K5 z1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domFINSEQ-1K5 z2"
        using funcop_1_th_69 sorry
      have A4: "domFINSEQ-1K5 (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) =MEMBEREDR12 domFINSEQ-1K5 z1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domFINSEQ-1K5 z2"
        using valued_1_th_12 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) implies (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 (diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 domFINSEQ-1K5 (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2)"
        then have "(z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 z1 .FUNCT-1K1 x -XCMPLX-0K6 z2 .FUNCT-1K1 x"
          using valued_1_th_13 sorry
        also have "... = diffcomplexSEQ-4K5 .BINOP-1K1(z1 .FUNCT-1K1 x,z2 .FUNCT-1K1 x)"
          using binop_2_def_4 sorry
        also have "... = (diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
          using A4 A3 A5 funcop_1_th_22 sorry
        finally show "(z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2).FUNCT-1K1 x =HIDDENR1 (diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 z1 -VALUED-1K47 z2 &  not VarFor1 =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2)) &  not (VarFor1 =HIDDENR1 diffcomplexSEQ-4K5 .:FINSEQOPK1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(z1,z2) &  not VarFor1 =HIDDENR1 z1 -VALUED-1K47 z2)"
        using A3 funct_1_th_2 valued_1_th_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_add_4:
  mlet "z1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster z1 -VALUED-1K47 z2 as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "z1 -VALUED-1K47 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  proof-
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
    proof-
      show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (z1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
         sorry
    qed
    thus "z1 -VALUED-1K47 z2 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

abbreviation(input) SEQ_4K10("-SEQ-4K10  _ " [132]132) where
  "-SEQ-4K10 z \<equiv> -VALUED-1K32 z"

mtheorem seq_4_def_8:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func -SEQ-4K10 z \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 -SEQ-4K10 z iff it =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
  proof-
    have " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 -VALUED-1K32 z &  not VarFor1 =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) &  not (VarFor1 =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z &  not VarFor1 =HIDDENR1 -VALUED-1K32 z)"
    proof-
      let ?g = "compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (compcomplexBINOP-2K1) =MEMBEREDR7 COMPLEXNUMBERSK3"
        using funct_2_def_1 sorry
      then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (compcomplexBINOP-2K1)"
         sorry
      then have A1: "domFINSEQ-1K5 ?g =MEMBEREDR12 domFINSEQ-1K5 z"
        using relat_1_th_27 sorry
      have A2: "domFINSEQ-1K5 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) =MEMBEREDR12 domFINSEQ-1K5 z"
        using valued_1_th_8 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) implies (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 (compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 domFINSEQ-1K5 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z)"
        have "(-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 z .FUNCT-1K1 x"
          using valued_1_th_8 sorry
        also have "... = compcomplexBINOP-2K1 .FUNCT-1K1 (z .FUNCT-1K1 x)"
          using binop_2_def_1 sorry
        also have "... = (compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
          using A2 A1 A3 funct_1_th_12 sorry
        finally show "(-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 (compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 -VALUED-1K32 z &  not VarFor1 =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) &  not (VarFor1 =HIDDENR1 compcomplexBINOP-2K1 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z &  not VarFor1 =HIDDENR1 -VALUED-1K32 z)"
        using A1 funct_1_th_2 valued_1_th_8 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_add_5:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster -VALUED-1K32 z as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "-VALUED-1K32 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  proof-
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) c=MEMBEREDR1 COMPLEXNUMBERSK3"
    proof-
      show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) c=MEMBEREDR1 COMPLEXNUMBERSK3"
         sorry
    qed
    thus "-VALUED-1K32 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

abbreviation(input) SEQ_4K11(" _ *SEQ-4K11  _ " [164,164]164) where
  "c *SEQ-4K11 z \<equiv> c (#)VALUED-1K25 z"

abbreviation(input) SEQ_4K12(" _ *SEQ-4K12  _ " [164,164]164) where
  "c *SEQ-4K12 z \<equiv> c (#)VALUED-1K25 z"

mtheorem seq_4_def_9:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "c be ComplexXCMPLX-0M1"
"redefine func c *SEQ-4K12 z \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds it =HIDDENR1 c *SEQ-4K12 z iff it =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
  proof-
    have " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 c (#)VALUED-1K25 z &  not VarFor1 =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) &  not (VarFor1 =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z &  not VarFor1 =HIDDENR1 c (#)VALUED-1K25 z)"
    proof-
      let ?g = "c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c multcomplexSEQ-4K6) =MEMBEREDR7 COMPLEXNUMBERSK3"
        using funct_2_def_1 sorry
      then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c multcomplexSEQ-4K6)"
         sorry
      then have A1: "domFINSEQ-1K5 (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) =MEMBEREDR12 domFINSEQ-1K5 z & domFINSEQ-1K5 ?g =MEMBEREDR12 domFINSEQ-1K5 z"
        using relat_1_th_27 valued_1_def_5 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) implies (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 (c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domFINSEQ-1K5 (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z)"
        have A3: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 & z .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        have "(c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 c *XCMPLX-0K3 z .FUNCT-1K1 x"
          using valued_1_th_6 sorry
        also have "... = c multcomplexSEQ-4K6 .FUNCT-1K1 (z .FUNCT-1K1 x)"
          using A3 seq_4_lm_9 sorry
        also have "... = (c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
          using A1 A2 funct_1_th_12 sorry
        finally show "(c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x =HIDDENR1 (c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " for VarFor1 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 holds  not (VarFor1 =HIDDENR1 c (#)VALUED-1K25 z &  not VarFor1 =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z) &  not (VarFor1 =HIDDENR1 c multcomplexSEQ-4K6 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z &  not VarFor1 =HIDDENR1 c (#)VALUED-1K25 z)"
        using A1 funct_1_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_add_6:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3", "c be ComplexXCMPLX-0M1"
"cluster c (#)VALUED-1K25 z as-term-is FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "c (#)VALUED-1K25 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
  proof-
    have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) c=MEMBEREDR1 COMPLEXNUMBERSK3"
    proof-
      show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (c (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z) c=MEMBEREDR1 COMPLEXNUMBERSK3"
         sorry
    qed
    thus "c (#)VALUED-1K25 z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

abbreviation(input) SEQ_4K13("absSEQ-4K13  _ " [250]250) where
  "absSEQ-4K13 z \<equiv>  |.VALUED-1K56 z.|"

mtheorem seq_4_def_10:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"redefine func absSEQ-4K13 z \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 equals
  abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z"
proof
(*compatibility*)
  show " for it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds it =HIDDENR1 absSEQ-4K13 z iff it =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z"
  proof-
    have " for VarFor1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  not (VarFor1 =HIDDENR1  |.VALUED-1K56 z.| &  not VarFor1 =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z) &  not (VarFor1 =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z &  not VarFor1 =HIDDENR1  |.VALUED-1K56 z.|)"
    proof-
      let ?g = "abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z"
      have "domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (abscomplexSEQ-4K7) =MEMBEREDR7 COMPLEXNUMBERSK3"
        using funct_2_def_1 sorry
      then have "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR1 domRELSET-1K1\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (abscomplexSEQ-4K7)"
         sorry
      then have A1: "domFINSEQ-1K5 absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z =MEMBEREDR12 domFINSEQ-1K5 z & domFINSEQ-1K5 ?g =MEMBEREDR12 domFINSEQ-1K5 z"
        using relat_1_th_27 valued_1_def_11 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z implies absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z .FUNCT-1K1 x =HIDDENR1 (abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 domFINSEQ-1K5 absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z"
        have A3: "z .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
        have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z .FUNCT-1K1 x =HIDDENR1  |.COMPLEX1K10 z .FUNCT-1K1 x.|"
          using valued_1_th_18 sorry
        also have "... = abscomplexSEQ-4K7 .FUNCT-1K1 (z .FUNCT-1K1 x)"
          using A3 seq_4_def_5 sorry
        also have "... = (abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z).FUNCT-1K1 x"
          using A1 A2 funct_1_th_12 sorry
        finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z .FUNCT-1K1 x =HIDDENR1 (abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z).FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " for VarFor1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  not (VarFor1 =HIDDENR1  |.VALUED-1K56 z.| &  not VarFor1 =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z) &  not (VarFor1 =HIDDENR1 abscomplexSEQ-4K7 *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> z &  not VarFor1 =HIDDENR1  |.VALUED-1K56 z.|)"
        using A1 funct_1_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_add_7:
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"cluster  |.VALUED-1K56 z.| as-term-is FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
proof
(*coherence*)
  show " |.VALUED-1K56 z.| be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
  proof-
    have "rngRVSUM-1K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR3 REALNUMBERSK2"
    proof-
      show "rngRVSUM-1K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR3 REALNUMBERSK2"
         sorry
    qed
    thus " |.VALUED-1K56 z.| be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_1_def_4 sorry
  qed
qed "sorry"

mdef seq_4_def_11 ("COMPLEXSEQ-4K14  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func COMPLEXSEQ-4K14 n \<rightarrow> FinSequenceSetFINSEQ-2M1-of COMPLEXNUMBERSK3 equals
  n -tuples-onFINSEQ-2K4 (COMPLEXNUMBERSK3)"
proof-
  (*coherence*)
    show "n -tuples-onFINSEQ-2K4 (COMPLEXNUMBERSK3) be FinSequenceSetFINSEQ-2M1-of COMPLEXNUMBERSK3"
       sorry
qed "sorry"

mtheorem seq_4_cl_6:
  mlet "n be NatNAT-1M1"
"cluster COMPLEXSEQ-4K14 n as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "COMPLEXSEQ-4K14 n be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

reserve x, z, z1, z2, z3 for "ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
reserve A, B for "SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
mlemma seq_4_lm_10:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds domFINSEQ-1K5 z =MEMBEREDR12 SegFINSEQ-1K2 n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds domFINSEQ-1K5 z =MEMBEREDR12 SegFINSEQ-1K2 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "lenFINSEQ-1K4 z =COMPLEX1R1 n"
      using card_1_def_7 sorry
    thus "domFINSEQ-1K5 z =MEMBEREDR12 SegFINSEQ-1K2 n"
      using finseq_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_57:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n implies z .FUNCT-1K1 k inTARSKIR2 COMPLEXNUMBERSK3"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  not (k inTARSKIR2 SegFINSEQ-1K2 n &  not z .FUNCT-1K1 k inTARSKIR2 COMPLEXNUMBERSK3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "lenFINSEQ-1K4 z =COMPLEX1R1 n"
      using card_1_def_7 sorry
    then have "SegFINSEQ-1K2 n =MEMBEREDR12 domFINSEQ-1K5 z"
      using finseq_1_def_3 sorry
    thus " not (k inTARSKIR2 SegFINSEQ-1K2 n &  not z .FUNCT-1K1 k inTARSKIR2 COMPLEXNUMBERSK3)"
      using finseq_2_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax SEQ_4K15 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +SEQ-4K15\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2" \<rightharpoonup> "z1 +VALUED-1K1 z2"

mtheorem seq_4_add_8:
  mlet "n be NatNAT-1M1", "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster z1 +VALUED-1K1 z2 as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "z1 +VALUED-1K1 z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem seq_4_th_58:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (k inTARSKIR2 SegFINSEQ-1K2 n & c1 =COMPLEX1R1 z1 .FUNCT-1K1 k) & c2 =COMPLEX1R1 z2 .FUNCT-1K1 k implies (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =COMPLEX1R1 c1 +XCMPLX-0K2 c2"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & (c1 =COMPLEX1R1 z1 .FUNCT-1K1 k & c2 =COMPLEX1R1 z2 .FUNCT-1K1 k) implies (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 c1 +XCMPLX-0K2 c2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "k inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "c1 =COMPLEX1R1 z1 .FUNCT-1K1 k & c2 =COMPLEX1R1 z2 .FUNCT-1K1 k"
    have "k inTARSKIR2 domFINSEQ-1K5 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)"
      using A1 seq_4_lm_10 sorry
    then have "(z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2)"
      using A2 funcop_1_th_22 sorry
    also have "... = c1 +XCMPLX-0K2 c2"
      using binop_2_def_3 sorry
    finally show "(z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 c1 +XCMPLX-0K2 c2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_12 ("0cSEQ-4K16  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func 0cSEQ-4K16 n \<rightarrow> FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3 equals
  n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
proof-
  (*coherence*)
    show "n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6 be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
       sorry
qed "sorry"

abbreviation(input) SEQ_4K17("0cSEQ-4K17  _ " [228]228) where
  "0cSEQ-4K17 n \<equiv> 0cSEQ-4K16 n"

mtheorem seq_4_add_9:
  mlet "n be NatNAT-1M1"
"cluster 0cSEQ-4K16 n as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "0cSEQ-4K16 n be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
     sorry
qed "sorry"

mtheorem seq_4_th_59:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 z & z =FINSEQ-1R1 0cSEQ-4K17 n +SEQ-4K15\<^bsub>(n)\<^esub> z"
  using binop_2_th_1 finseqop_th_56 sorry

syntax SEQ_4K18 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("-SEQ-4K18\<^bsub>'( _ ')\<^esub>  _ " [0,132]132)
translations "-SEQ-4K18\<^bsub>(n)\<^esub> z" \<rightharpoonup> "-VALUED-1K32 z"

mtheorem seq_4_add_10:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster -VALUED-1K32 z as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "-VALUED-1K32 z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_60:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies (-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =COMPLEX1R1 -XCMPLX-0K4 c"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies (-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 -XCMPLX-0K4 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "k inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "c =COMPLEX1R1 z .FUNCT-1K1 k"
    have "k inTARSKIR2 domFINSEQ-1K5 (-SEQ-4K18\<^bsub>(n)\<^esub> z)"
      using A1 seq_4_lm_10 sorry
    then have "(-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c"
      using A2 funct_1_th_12 sorry
    also have "... = -XCMPLX-0K4 c"
      using binop_2_def_1 sorry
    finally show "(-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 -XCMPLX-0K4 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_11:
" for n be NatNAT-1M1 holds -SEQ-4K18\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 0cSEQ-4K17 n"
proof-
  have " for n be NatNAT-1M1 holds -SEQ-4K18\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 0cSEQ-4K17 n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "-SEQ-4K18\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> compcomplexBINOP-2K1 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6"
      using finseqop_th_16 sorry
    also have "... = n  |->FINSEQ-2K2 (-XCMPLX-0K4 0cCOMPLEX1K6)"
      using binop_2_def_1 sorry
    also have "... = 0cSEQ-4K17 n"
       sorry
    finally show "-SEQ-4K18\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 0cSEQ-4K17 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_61:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 0cSEQ-4K17 n & (-SEQ-4K18\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
  using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry

mtheorem seq_4_th_62:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n implies z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2 & z2 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z1"
  using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_74 sorry

(*\$CT*)
mtheorem seq_4_th_64:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2 implies z1 =FINSEQ-1R1 z2"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2 implies z1 =HIDDENR1 z2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume "-SEQ-4K18\<^bsub>(n)\<^esub> z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z2"
    then have "z1 =HIDDENR1 -SEQ-4K18\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
       sorry
    also have "... = z2"
       sorry
    finally show "z1 =HIDDENR1 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_12:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z implies z1 =FINSEQ-1R1 z2"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z implies z1 =FINSEQ-1R1 z2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume "z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z"
    then have "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z)) =FINSEQ-1R1 (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z)"
      using finseqop_th_28 sorry
    then have A1: "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z)) =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> (z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z))"
      using finseqop_th_28 sorry
    have "z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 0cSEQ-4K17 n"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    then have "z1 =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n"
      using A1 binop_2_th_1 finseqop_th_56 sorry
    thus "z1 =FINSEQ-1R1 z2"
      using binop_2_th_1 finseqop_th_56 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_65:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z2 +SEQ-4K15\<^bsub>(n)\<^esub> z or z1 +SEQ-4K15\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z +SEQ-4K15\<^bsub>(n)\<^esub> z2 implies z1 =FINSEQ-1R1 z2"
  using seq_4_lm_12 sorry

mtheorem seq_4_th_66:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "(z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)) =HIDDENR1 ((z2 +SEQ-4K15\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z1))+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using finseqop_th_28 sorry
    also have "... = (z2 +SEQ-4K15\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z1)))+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using finseqop_th_28 sorry
    also have "... = (z2 +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    also have "... = z2 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using binop_2_th_1 finseqop_th_56 sorry
    also have "... = 0cSEQ-4K17 n"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    finally have "(z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)) =HIDDENR1 0cSEQ-4K17 n"
       sorry
    thus "-SEQ-4K18\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax SEQ_4K19 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -SEQ-4K19\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2" \<rightharpoonup> "z1 -VALUED-1K47 z2"

mtheorem seq_4_add_11:
  mlet "n be NatNAT-1M1", "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster z1 -VALUED-1K47 z2 as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "z1 -VALUED-1K47 z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_120 sorry
qed "sorry"

mtheorem seq_4_th_67:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n implies (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =COMPLEX1R1 z1 .FUNCT-1K1 k -XCMPLX-0K6 z2 .FUNCT-1K1 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n implies (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 z1 .FUNCT-1K1 k -XCMPLX-0K6 z2 .FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "k inTARSKIR2 SegFINSEQ-1K2 n"
    let ?c1 = "z1 .FUNCT-1K1 k"
    let ?c2 = "z2 .FUNCT-1K1 k"
    have "k inTARSKIR2 domFINSEQ-1K5 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)"
      using A1 seq_4_lm_10 sorry
    then have "(z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 diffcomplexSEQ-4K5 .BINOP-1K1(z1 .FUNCT-1K1 k,z2 .FUNCT-1K1 k)"
      using funcop_1_th_22 sorry
    also have "... = z1 .FUNCT-1K1 k -XCMPLX-0K6 z2 .FUNCT-1K1 k"
      using binop_2_def_4 sorry
    finally show "(z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k =HIDDENR1 z1 .FUNCT-1K1 k -XCMPLX-0K6 z2 .FUNCT-1K1 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_68:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =FINSEQ-1R1 z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 z"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z -SEQ-4K19\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 z +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n"
      using seq_4_lm_11 sorry
    also have "... = z"
      using binop_2_th_1 finseqop_th_56 sorry
    finally show "z -SEQ-4K19\<^bsub>(n)\<^esub> 0cSEQ-4K17 n =HIDDENR1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_69:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cSEQ-4K17 n -SEQ-4K19\<^bsub>(n)\<^esub> z =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cSEQ-4K17 n -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "0cSEQ-4K17 n -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 0cSEQ-4K17 n +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z)"
       sorry
    also have "... = -SEQ-4K18\<^bsub>(n)\<^esub> z"
      using binop_2_th_1 finseqop_th_56 sorry
    finally show "0cSEQ-4K17 n -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_70:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2"
   sorry

mtheorem seq_4_th_71:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "-SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2))"
      using seq_4_th_66 sorry
    also have "... = z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1"
       sorry
    finally show "-SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_72:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds -SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "-SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2))"
      using seq_4_th_66 sorry
    also have "... = (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
       sorry
    finally show "-SEQ-4K18\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2) =HIDDENR1 (-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_73:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 0cSEQ-4K17 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 z +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z)"
       sorry
    also have "... = 0cSEQ-4K17 n"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    finally show "z -SEQ-4K19\<^bsub>(n)\<^esub> z =HIDDENR1 0cSEQ-4K17 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_74:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n implies z1 =FINSEQ-1R1 z2"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n implies z1 =FINSEQ-1R1 z2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume "z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n"
    then have "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 0cSEQ-4K17 n"
       sorry
    then have "z1 =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2)"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_74 sorry
    thus "z1 =FINSEQ-1R1 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_75:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3 =FINSEQ-1R1 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z3)"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3 =HIDDENR1 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z3 assume [ty]: "z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "(z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3 =HIDDENR1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2))+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z3)"
       sorry
    also have "... = z1 +SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z3))"
      using finseqop_th_28 sorry
    also have "... = z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z3)"
      using seq_4_th_66 sorry
    finally show "(z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3 =HIDDENR1 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> z3)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_76:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z3 assume [ty]: "z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z3))"
       sorry
    also have "... = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z3)"
      using finseqop_th_28 sorry
    also have "... = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3"
       sorry
    finally show "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_77:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =FINSEQ-1R1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z3 assume [ty]: "z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3)"
      using seq_4_th_72 sorry
    also have "... = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z2))+SEQ-4K15\<^bsub>(n)\<^esub> z3"
      using finseqop_th_28 sorry
    also have "... = (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3"
       sorry
    finally show "z1 -SEQ-4K19\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z3) =HIDDENR1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_78:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z3 =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z3)-SEQ-4K19\<^bsub>(n)\<^esub> z2"
  using seq_4_th_76 sorry

mtheorem seq_4_th_79:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =HIDDENR1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 =HIDDENR1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n"
      using binop_2_th_1 finseqop_th_56 sorry
    also have "... = z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z -SEQ-4K19\<^bsub>(n)\<^esub> z)"
      using seq_4_th_73 sorry
    also have "... = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z"
      using seq_4_th_76 sorry
    finally show "z1 =HIDDENR1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_80:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) =FINSEQ-1R1 z2"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) =HIDDENR1 z2"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) =HIDDENR1 (z2 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z1))+SEQ-4K15\<^bsub>(n)\<^esub> z1"
       sorry
    also have "... = z2 +SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z1)+SEQ-4K15\<^bsub>(n)\<^esub> z1)"
      using finseqop_th_28 sorry
    also have "... = z2 +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    also have "... = z2"
      using binop_2_th_1 finseqop_th_56 sorry
    finally show "z1 +SEQ-4K15\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) =HIDDENR1 z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_81:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =FINSEQ-1R1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 =HIDDENR1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 =HIDDENR1 z1 +SEQ-4K15\<^bsub>(n)\<^esub> 0cSEQ-4K17 n"
      using binop_2_th_1 finseqop_th_56 sorry
    also have "... = z1 +SEQ-4K15\<^bsub>(n)\<^esub> ((-SEQ-4K18\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z)"
      using seq_4_th_51 seq_4_th_52 binop_2_th_1 finseqop_th_73 sorry
    also have "... = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z))+SEQ-4K15\<^bsub>(n)\<^esub> z"
      using finseqop_th_28 sorry
    also have "... = (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z"
       sorry
    finally show "z1 =HIDDENR1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax SEQ_4K20 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *SEQ-4K20\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164)
translations "c *SEQ-4K20\<^bsub>(n)\<^esub> z" \<rightharpoonup> "c (#)VALUED-1K25 z"

mtheorem seq_4_add_12:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"cluster c (#)VALUED-1K25 z as-term-is ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
proof
(*coherence*)
  show "c (#)VALUED-1K25 z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_82:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c9 =COMPLEX1R1 z .FUNCT-1K1 k implies (c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =COMPLEX1R1 c *XCMPLX-0K3 c9"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c9 =COMPLEX1R1 z .FUNCT-1K1 k implies (c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 c *XCMPLX-0K3 c9"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c9 assume [ty]: "c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "k inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "c9 =COMPLEX1R1 z .FUNCT-1K1 k"
    have "k inTARSKIR2 domFINSEQ-1K5 (c *SEQ-4K20\<^bsub>(n)\<^esub> z)"
      using A1 seq_4_lm_10 sorry
    then have "(c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 c multcomplexSEQ-4K6 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> c9"
      using A2 funct_1_th_12 sorry
    also have "... = c *XCMPLX-0K3 c9"
      using seq_4_lm_9 sorry
    finally show "(c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 k =HIDDENR1 c *XCMPLX-0K3 c9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_83:
" for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds c1 *SEQ-4K20\<^bsub>(n)\<^esub> (c2 *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 (c1 *XCMPLX-0K3 c2)*SEQ-4K12 z"
proof-
  have " for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (c1 *XCMPLX-0K3 c2)*SEQ-4K12 z =HIDDENR1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> (c2 *SEQ-4K20\<^bsub>(n)\<^esub> z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "(c1 *XCMPLX-0K3 c2)*SEQ-4K12 z =HIDDENR1 multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),idPARTFUN1K6 (COMPLEXNUMBERSK3)) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using binop_2_def_5 sorry
    also have "... = multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c1,multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c2,idPARTFUN1K6 (COMPLEXNUMBERSK3))) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using funcop_1_th_62 sorry
    also have "... = (multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c1,idPARTFUN1K6 (COMPLEXNUMBERSK3)) *PARTFUN1K1\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c2,idPARTFUN1K6 (COMPLEXNUMBERSK3)))*FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using funcop_1_th_55 sorry
    also have "... = c1 *SEQ-4K20\<^bsub>(n)\<^esub> (c2 *SEQ-4K20\<^bsub>(n)\<^esub> z)"
      using relat_1_th_36 sorry
    finally show "(c1 *XCMPLX-0K3 c2)*SEQ-4K12 z =HIDDENR1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> (c2 *SEQ-4K20\<^bsub>(n)\<^esub> z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_84:
" for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (c1 +XCMPLX-0K2 c2)*SEQ-4K12 z =FINSEQ-1R1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> z +SEQ-4K15\<^bsub>(n)\<^esub> c2 *SEQ-4K20\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (c1 +XCMPLX-0K2 c2)*SEQ-4K12 z =HIDDENR1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> z +SEQ-4K15\<^bsub>(n)\<^esub> c2 *SEQ-4K20\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    let ?c1M = "multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c1,idPARTFUN1K6 (COMPLEXNUMBERSK3))"
    let ?c2M = "multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c2,idPARTFUN1K6 (COMPLEXNUMBERSK3))"
    have "(c1 +XCMPLX-0K2 c2)*SEQ-4K12 z =HIDDENR1 multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(addcomplexBINOP-2K3 .BINOP-1K4\<^bsub>(COMPLEXNUMBERSK3)\<^esub>(c1,c2),idPARTFUN1K6 (COMPLEXNUMBERSK3)) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using binop_2_def_3 sorry
    also have "... = addcomplexBINOP-2K3 .:FUNCOP-1K6\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c1,idPARTFUN1K6 (COMPLEXNUMBERSK3)),multcomplexBINOP-2K5 [;]FUNCOP-1K10\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(c2,idPARTFUN1K6 (COMPLEXNUMBERSK3))) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using seq_4_th_54 finseqop_th_35 sorry
    also have "... = c1 *SEQ-4K20\<^bsub>(n)\<^esub> z +SEQ-4K15\<^bsub>(n)\<^esub> c2 *SEQ-4K20\<^bsub>(n)\<^esub> z"
      using funcop_1_th_25 sorry
    finally show "(c1 +XCMPLX-0K2 c2)*SEQ-4K12 z =HIDDENR1 c1 *SEQ-4K20\<^bsub>(n)\<^esub> z +SEQ-4K15\<^bsub>(n)\<^esub> c2 *SEQ-4K20\<^bsub>(n)\<^esub> z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_85:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds c *SEQ-4K20\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) =FINSEQ-1R1 c *SEQ-4K20\<^bsub>(n)\<^esub> z1 +SEQ-4K15\<^bsub>(n)\<^esub> c *SEQ-4K20\<^bsub>(n)\<^esub> z2"
  using seq_4_th_54 finseqop_th_51 finseqop_th_54 sorry

mtheorem seq_4_th_86:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 1rCOMPLEX1K7 *SEQ-4K20\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 1rCOMPLEX1K7 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 z"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR1 COMPLEXNUMBERSK3"
       sorry
    have "1rCOMPLEX1K7 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 idPARTFUN1K6 (COMPLEXNUMBERSK3) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z"
      using binop_2_th_6 finseqop_th_44 sorry
    also have "... = z"
      using A1 relat_1_th_53 sorry
    finally show "1rCOMPLEX1K7 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 z"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_87:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cCOMPLEX1K6 *SEQ-4K20\<^bsub>(n)\<^esub> z =FINSEQ-1R1 0cSEQ-4K17 n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0cCOMPLEX1K6 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 0cSEQ-4K17 n"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have A1: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> z c=MEMBEREDR1 COMPLEXNUMBERSK3"
       sorry
    have "0cCOMPLEX1K6 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 multcomplexBINOP-2K5 [;]FINSEQOPK3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(0cCOMPLEX1K6,idPARTFUN1K6 (COMPLEXNUMBERSK3) *FINSEQOPK4\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> z)"
      using funcop_1_th_34 sorry
    also have "... = multcomplexBINOP-2K5 [;]FINSEQOPK3\<^bsub>(COMPLEXNUMBERSK3,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub>(0cCOMPLEX1K6,z)"
      using A1 relat_1_th_53 sorry
    also have "... = 0cSEQ-4K17 n"
      using seq_4_th_51 seq_4_th_54 binop_2_th_1 finseqop_th_76 sorry
    finally show "0cCOMPLEX1K6 *SEQ-4K20\<^bsub>(n)\<^esub> z =HIDDENR1 0cSEQ-4K17 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_88:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds (-XCMPLX-0K4 1rCOMPLEX1K7)*SEQ-4K12 z =FINSEQ-1R1 -SEQ-4K18\<^bsub>(n)\<^esub> z"
   sorry

syntax SEQ_4K21 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("absSEQ-4K21\<^bsub>'( _ ')\<^esub>  _ " [0,250]250)
translations "absSEQ-4K21\<^bsub>(n)\<^esub> z" \<rightharpoonup> " |.VALUED-1K56 z.|"

mtheorem seq_4_add_13:
  mlet "n be NatNAT-1M1", "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
"cluster  |.VALUED-1K56 z.| as-term-is ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
proof
(*coherence*)
  show " |.VALUED-1K56 z.| be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of n -tuples-onFINSEQ-2K4 REALNUMBERSK2"
    using finseq_2_th_113 sorry
qed "sorry"

mtheorem seq_4_th_89:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 k =COMPLEX1R1  |.COMPLEX1K10 c.|"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds k inTARSKIR2 SegFINSEQ-1K2 n & c =COMPLEX1R1 z .FUNCT-1K1 k implies absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 k =HIDDENR1  |.COMPLEX1K10 c.|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "k inTARSKIR2 SegFINSEQ-1K2 n"
      and A2: "c =COMPLEX1R1 z .FUNCT-1K1 k"
    have "lenFINSEQ-1K4 absSEQ-4K21\<^bsub>(n)\<^esub> z =COMPLEX1R1 n"
      using card_1_def_7 sorry
    then have "k inTARSKIR2 domFINSEQ-1K5 absSEQ-4K21\<^bsub>(n)\<^esub> z"
      using A1 finseq_1_def_3 sorry
    then have "absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 k =HIDDENR1 abscomplexSEQ-4K7 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> c"
      using A2 funct_1_th_12 sorry
    also have "... =  |.COMPLEX1K10 c.|"
      using seq_4_def_5 sorry
    finally show "absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 k =HIDDENR1  |.COMPLEX1K10 c.|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_90:
" for n be NatNAT-1M1 holds absSEQ-4K21\<^bsub>(n)\<^esub> (0cSEQ-4K17 n) =FINSEQ-1R1 n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
proof-
  have " for n be NatNAT-1M1 holds absSEQ-4K21\<^bsub>(n)\<^esub> (0cSEQ-4K17 n) =HIDDENR1 n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "absSEQ-4K21\<^bsub>(n)\<^esub> (0cSEQ-4K17 n) =HIDDENR1 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> abscomplexSEQ-4K7 .FUNCT-2K3\<^bsub>(COMPLEXNUMBERSK3,REALNUMBERSK2)\<^esub> 0cCOMPLEX1K6"
      using finseqop_th_16 sorry
    also have "... = n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
      using seq_4_def_5 complex1_th_44 sorry
    finally show "absSEQ-4K21\<^bsub>(n)\<^esub> (0cSEQ-4K17 n) =HIDDENR1 n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_91:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 absSEQ-4K21\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 absSEQ-4K21\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 n implies absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1 absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A1: "j inTARSKIR2 SegFINSEQ-1K2 n"
      then obtain c c9 where 
        [ty]:"c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and cDef:"c = z .FUNCT-1K1 j" and
        [ty]:"c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c9Def:"c9 = (-SEQ-4K18\<^bsub>(n)\<^esub> z).FUNCT-1K1 j"
        using seq_4_th_57 sorry
      have "absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1  |.COMPLEX1K10 c9.|"
        using A1 seq_4_th_89 sorry
      also have "... =  |.COMPLEX1K10 -XCMPLX-0K4 c .|"
        using A1 seq_4_th_60 sorry
      also have "... =  |.COMPLEX1K10 c.|"
        using complex1_th_52 sorry
      also have "... = absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 j"
        using A1 seq_4_th_89 sorry
      finally show "absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1 absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 j"
         sorry
    qed "sorry"
    thus "absSEQ-4K21\<^bsub>(n)\<^esub> (-SEQ-4K18\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 absSEQ-4K21\<^bsub>(n)\<^esub> z"
      using finseq_2_th_119 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_92:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 ( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z"
proof-
  have " for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 ( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 n implies absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1 (( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      obtain w where 
        [ty]:"w be ElementSUBSET-1M1-of NATNUMBERSK1" and wDef:"w = j"
        using ordinal1_def_12 sorry
      assume A1: "j inTARSKIR2 SegFINSEQ-1K2 n"
      then obtain c9 cc where 
        [ty]:"c9 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c9Def:"c9 = z .FUNCT-1K1 j" and
        [ty]:"cc be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ccDef:"cc = (c *SEQ-4K20\<^bsub>(n)\<^esub> z).FUNCT-1K1 j"
        using seq_4_th_57 sorry
      obtain ac where 
        [ty]:"ac be RealXREAL-0M1" and acDef:"ac = absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 w"
         sorry
      have "absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1  |.COMPLEX1K10 cc.|"
        using A1 seq_4_th_89 sorry
      also have "... =  |.COMPLEX1K10 c *XCMPLX-0K3 c9 .|"
        using A1 seq_4_th_82 sorry
      also have "... = ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.COMPLEX1K10 c9.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ac"
        using A1 seq_4_th_89 sorry
      also have "... = (( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z).FUNCT-1K1 j"
        using rvsum_1_th_45 sorry
      finally show "absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) .FUNCT-1K1 j =HIDDENR1 (( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z).FUNCT-1K1 j"
         sorry
    qed "sorry"
    thus "absSEQ-4K21\<^bsub>(n)\<^esub> (c *SEQ-4K20\<^bsub>(n)\<^esub> z) =FINSEQ-1R1 ( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z"
      using finseq_2_th_119 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_13 (" |.SEQ-4K22  _ .|" [0]164 ) where
  mlet "z be FinSequenceFINSEQ-1M3-of COMPLEXNUMBERSK3"
"func  |.SEQ-4K22 z.| \<rightarrow> RealXREAL-0M1 equals
  sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K15 absSEQ-4K13 z))"
proof-
  (*coherence*)
    show "sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K15 absSEQ-4K13 z)) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem seq_4_th_93:
" for n be NatNAT-1M1 holds  |.SEQ-4K22 0cSEQ-4K17 n.| =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  |.SEQ-4K22 0cSEQ-4K17 n.| =HIDDENR1 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have " |.SEQ-4K22 0cSEQ-4K17 n.| =HIDDENR1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K15 (n  |->FINSEQ-2K2 (0NUMBERSK6))))"
      using seq_4_th_90 sorry
    also have "... = sqrtSQUARE-1K3 (SumRVSUM-1K20 (n  |->FINSEQ-2K2 (0NUMBERSK6)^2SQUARE-1K1))"
      using rvsum_1_th_56 sorry
    also have "... = sqrtSQUARE-1K3 (n *XCMPLX-0K3 (0NUMBERSK6))"
      using rvsum_1_th_80 sorry
    also have "... = 0NUMBERSK6"
      using square_1_th_17 sorry
    finally show " |.SEQ-4K22 0cSEQ-4K17 n.| =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_94:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| =COMPLEX1R1 0NUMBERSK6 implies z =FINSEQ-1R1 0cSEQ-4K17 n"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| =COMPLEX1R1 0NUMBERSK6 implies z =FINSEQ-1R1 0cSEQ-4K17 n"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: " |.SEQ-4K22 z.| =COMPLEX1R1 0NUMBERSK6"
    have " for j be NatNAT-1M1 holds j inTARSKIR2 SegFINSEQ-1K2 n implies z .FUNCT-1K1 j =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A2: "j inTARSKIR2 SegFINSEQ-1K2 n"
      then obtain c where 
        [ty]:"c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and cDef:"c = z .FUNCT-1K1 j"
        using seq_4_th_57 sorry
      have "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z)"
        using rvsum_1_th_86 sorry
      then have "absSEQ-4K21\<^bsub>(n)\<^esub> z .FUNCT-1K1 j =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)).RECDEF-1K1 j"
        using A1 rvsum_1_th_91 square_1_th_24 sorry
      then have " |.COMPLEX1K10 c.| =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (0NUMBERSK6)).RECDEF-1K1 j"
        using A2 seq_4_th_89 sorry
      then have "c =COMPLEX1R1 0cCOMPLEX1K6"
        using complex1_th_45 sorry
      thus "z .FUNCT-1K1 j =COMPLEX1R1 (n  |->FINSEQ-2K5\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 0cCOMPLEX1K6).FUNCT-1K1 j"
         sorry
    qed "sorry"
    thus "z =FINSEQ-1R1 0cSEQ-4K17 n"
      using finseq_2_th_119 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_95:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <=XXREAL-0R1  |.SEQ-4K22 z.|"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <=XXREAL-0R1  |.SEQ-4K22 z.|"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z)"
      using rvsum_1_th_86 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1  |.SEQ-4K22 z.|"
      using square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_96:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 -SEQ-4K18\<^bsub>(n)\<^esub> z .| =COMPLEX1R1  |.SEQ-4K22 z.|"
  using seq_4_th_91 sorry

mtheorem seq_4_th_97:
" for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 c *SEQ-4K20\<^bsub>(n)\<^esub> z .| =COMPLEX1R1 ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.SEQ-4K22 z.|)"
proof-
  have " for n be NatNAT-1M1 holds  for c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 c *SEQ-4K20\<^bsub>(n)\<^esub> z .| =HIDDENR1 ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.SEQ-4K22 z.|)"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 ( |.COMPLEX1K10 c.|)^2SQUARE-1K1 & 0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z)"
      using rvsum_1_th_86 xreal_1_th_63 sorry
    have " |.SEQ-4K22 c *SEQ-4K20\<^bsub>(n)\<^esub> z .| =HIDDENR1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> (( |.COMPLEX1K10 c.|)*RVSUM-1K13\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z)))"
      using seq_4_th_92 sorry
    also have "... = sqrtSQUARE-1K3 (SumRVSUM-1K22 (( |.COMPLEX1K10 c.|)^2SQUARE-1K1 *RVSUM-1K13\<^bsub>(n)\<^esub> sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z))"
      using rvsum_1_th_58 sorry
    also have "... = sqrtSQUARE-1K3 (( |.COMPLEX1K10 c.|)^2SQUARE-1K1 *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z))"
      using rvsum_1_th_87 sorry
    also have "... = sqrtSQUARE-1K3 ( |.COMPLEX1K10 c.|)^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z))"
      using A1 square_1_th_29 sorry
    also have "... = ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.SEQ-4K22 z.|)"
      using complex1_th_46 square_1_th_22 sorry
    finally show " |.SEQ-4K22 c *SEQ-4K20\<^bsub>(n)\<^esub> z .| =HIDDENR1 ( |.COMPLEX1K10 c.|)*XCMPLX-0K3 ( |.SEQ-4K22 z.|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_98:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have A1: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2))"
      using rvsum_1_th_86 sorry
    have A2: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1)"
      using rvsum_1_th_86 sorry
    then have A3: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1))"
      using square_1_def_2 sorry
    have A4: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 n implies 0NUMBERSK6 <=XXREAL-0R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      let ?r = "mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
      assume A5: "k inTARSKIR2 SegFINSEQ-1K2 n"
      then obtain c1 c2 where 
        [ty]:"c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c1Def:"c1 = z1 .FUNCT-1K1 k" and
        [ty]:"c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c2Def:"c2 = z2 .FUNCT-1K1 k"
        using seq_4_th_57 sorry
      have "absSEQ-4K21\<^bsub>(n)\<^esub> z1 .FUNCT-1K1 k =COMPLEX1R1  |.COMPLEX1K10 c1.| & absSEQ-4K21\<^bsub>(n)\<^esub> z2 .FUNCT-1K1 k =COMPLEX1R1  |.COMPLEX1K10 c2.|"
        using A5 seq_4_th_89 sorry
      then have A6: "?r =COMPLEX1R1 ( |.COMPLEX1K10 c1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 c2.|)"
        using rvsum_1_th_60 sorry
      have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 c1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 c2.|"
        using complex1_th_46 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
        using A6 sorry
    qed "sorry"
    have "0NUMBERSK6 <=XXREAL-0R1 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    then have A7: "sqrtSQUARE-1K3 (SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))"
      using rvsum_1_th_92 square_1_th_26 sorry
    have "lenFINSEQ-1K4 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) =COMPLEX1R1 n"
      using card_1_def_7 sorry
    then have "domFINSEQ-1K5 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) =MEMBEREDR12 SegFINSEQ-1K2 n"
      using finseq_1_def_3 sorry
    then have "SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))"
      using A4 A7 rvsum_1_th_84 square_1_th_22 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))"
      using xreal_1_th_64 sorry
    then have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))"
      using xreal_1_th_7 sorry
    then have A8: "(SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) <=XXREAL-0R1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using xreal_1_th_7 sorry
    have A9: " for k be NatNAT-1M1 holds k inTARSKIR2 SegFINSEQ-1K2 n implies sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k <=XXREAL-0R1 sqrRVSUM-1K16\<^bsub>(n)\<^esub> (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      let ?r2 = "sqrRVSUM-1K16\<^bsub>(n)\<^esub> (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
      have "lenFINSEQ-1K4 (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) =COMPLEX1R1 n"
        using card_1_def_7 sorry
      then have A10: "domFINSEQ-1K5 (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) =MEMBEREDR12 SegFINSEQ-1K2 n"
        using finseq_1_def_3 sorry
      assume A11: "k inTARSKIR2 SegFINSEQ-1K2 n"
      then obtain c12 where 
        [ty]:"c12 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c12Def:"c12 = (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k"
        using seq_4_th_57 sorry
      obtain abs912 where 
        [ty]:"abs912 be RealXREAL-0M1" and abs912Def:"abs912 = absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
         sorry
      have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 c12.|"
        using complex1_th_46 sorry
      then have A12: "0NUMBERSK6 <=XXREAL-0R1 abs912"
        using A11 seq_4_th_89 sorry
      obtain abs1 abs2 where 
        [ty]:"abs1 be RealXREAL-0M1" and abs1Def:"abs1 = absSEQ-4K21\<^bsub>(n)\<^esub> z1 .FUNCT-1K1 k" and
        [ty]:"abs2 be RealXREAL-0M1" and abs2Def:"abs2 = absSEQ-4K21\<^bsub>(n)\<^esub> z2 .FUNCT-1K1 k"
         sorry
      obtain c1 c2 where 
        [ty]:"c1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c1Def:"c1 = z1 .FUNCT-1K1 k" and
        [ty]:"c2 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and c2Def:"c2 = z2 .FUNCT-1K1 k"
        using A11 seq_4_th_57 sorry
      obtain abs12 where 
        [ty]:"abs12 be RealXREAL-0M1" and abs12Def:"abs12 = (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2).FUNCT-1K1 k"
         sorry
      have " |.COMPLEX1K10 c1 +XCMPLX-0K2 c2 .| <=XXREAL-0R1  |.COMPLEX1K10 c1.| +XCMPLX-0K2  |.COMPLEX1K10 c2.|"
        using complex1_th_56 sorry
      then have " |.COMPLEX1K10 c12.| <=XXREAL-0R1  |.COMPLEX1K10 c1.| +XCMPLX-0K2  |.COMPLEX1K10 c2.|"
        using A11 seq_4_th_58 sorry
      then have " |.COMPLEX1K10 c12.| <=XXREAL-0R1  |.COMPLEX1K10 c1.| +XCMPLX-0K2 abs2"
        using A11 seq_4_th_89 sorry
      then have " |.COMPLEX1K10 c12.| <=XXREAL-0R1 abs1 +XCMPLX-0K2 abs2"
        using A11 seq_4_th_89 sorry
      then have " |.COMPLEX1K10 c12.| <=XXREAL-0R1 abs12"
        using A11 A10 valued_1_def_1 sorry
      then have "abs912 <=XXREAL-0R1 abs12"
        using A11 seq_4_th_89 sorry
      then have "abs912 ^2SQUARE-1K1 <=XXREAL-0R1 abs12 ^2SQUARE-1K1"
        using A12 square_1_th_15 sorry
      then have "abs912 ^2SQUARE-1K1 <=XXREAL-0R1 ?r2"
        using valued_1_th_11 sorry
      thus "sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k <=XXREAL-0R1 sqrRVSUM-1K16\<^bsub>(n)\<^esub> (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2) .FUNCT-1K1 k"
        using valued_1_th_11 sorry
    qed "sorry"
    have A13: "0NUMBERSK6 <=XXREAL-0R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using rvsum_1_th_86 sorry
    then have A14: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))"
      using square_1_def_2 sorry
    have A15: "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) =COMPLEX1R1 (sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1)))^2SQUARE-1K1"
      using A2 square_1_def_2 sorry
    have A16: "(sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)))^2SQUARE-1K1 =COMPLEX1R1 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using A13 square_1_def_2 sorry
    have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)) =HIDDENR1 SumRVSUM-1K22 ((sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> \<two>\<^sub>M *RVSUM-1K13\<^bsub>(n)\<^esub> mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2))+RVSUM-1K6\<^bsub>(n)\<^esub> sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using rvsum_1_th_68 sorry
    also have "... = SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> \<two>\<^sub>M *RVSUM-1K13\<^bsub>(n)\<^esub> mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)) +XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using rvsum_1_th_89 sorry
    also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 SumRVSUM-1K22 (\<two>\<^sub>M *RVSUM-1K13\<^bsub>(n)\<^esub> mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using rvsum_1_th_89 sorry
    also have "... = (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using rvsum_1_th_87 sorry
    finally have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> (absSEQ-4K21\<^bsub>(n)\<^esub> z1 +RVSUM-1K6\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)) =HIDDENR1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
       sorry
    then have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 SumRVSUM-1K22 (mltRVSUM-1K19\<^bsub>(n)\<^esub>(absSEQ-4K21\<^bsub>(n)\<^esub> z1,absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using A9 rvsum_1_th_82 sorry
    then have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) *XCMPLX-0K3 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using A8 xxreal_0_th_2 sorry
    then have "SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)) <=XXREAL-0R1 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1)) *XCMPLX-0K3 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2))))+XCMPLX-0K2 SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)"
      using A2 A13 square_1_th_29 sorry
    then have "sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2))) <=XXREAL-0R1 sqrtSQUARE-1K3 (sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z1)) +XCMPLX-0K2 sqrtSQUARE-1K3 (SumRVSUM-1K22 (sqrRVSUM-1K16\<^bsub>(n)\<^esub> absSEQ-4K21\<^bsub>(n)\<^esub> z2)))^2SQUARE-1K1"
      using A15 A16 A1 square_1_th_26 sorry
    thus " |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
      using A3 A14 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_99:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 -SEQ-4K18\<^bsub>(n)\<^esub> z2 .|"
      using seq_4_th_98 sorry
    thus " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1.| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
      using seq_4_th_91 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_100:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 =FINSEQ-1R1 (z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2)-SEQ-4K19\<^bsub>(n)\<^esub> z2"
      using seq_4_th_79 sorry
    then have " |.SEQ-4K22 z1.| <=XXREAL-0R1  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
      using seq_4_th_99 sorry
    thus " |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 +SEQ-4K15\<^bsub>(n)\<^esub> z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_101:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have "z1 =FINSEQ-1R1 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2)+SEQ-4K15\<^bsub>(n)\<^esub> z2"
      using seq_4_th_81 sorry
    then have " |.SEQ-4K22 z1.| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| +XCMPLX-0K2  |.SEQ-4K22 z2.|"
      using seq_4_th_98 sorry
    thus " |.SEQ-4K22 z1.| -XCMPLX-0K6  |.SEQ-4K22 z2.| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_102:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6 iff z1 =FINSEQ-1R1 z2"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =FINSEQ-1R1 z2) & (z1 =FINSEQ-1R1 z2 implies  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    show " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6 implies z1 =FINSEQ-1R1 z2"
    proof(rule impI)
      assume " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6"
      then have "z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n"
        using seq_4_th_94 sorry
      thus "z1 =FINSEQ-1R1 z2"
        using seq_4_th_74 sorry
    qed
    assume "z1 =FINSEQ-1R1 z2"
    then have "z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 =FINSEQ-1R1 0cSEQ-4K17 n"
      using seq_4_th_73 sorry
    thus " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1 0NUMBERSK6"
      using seq_4_th_93 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_103:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 <>HIDDENR2 z2 implies 0NUMBERSK6 <XXREAL-0R3  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z1 <>HIDDENR2 z2 implies  not 0NUMBERSK6 <XXREAL-0R3  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume "z1 <>HIDDENR2 z2"
    then have "0NUMBERSK6 <>HIDDENR2  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
      using seq_4_th_102 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
      using seq_4_th_95 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_104:
" for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =COMPLEX1R1  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|"
proof-
  have " for n be NatNAT-1M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =HIDDENR1  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =HIDDENR1  |.SEQ-4K22 -SEQ-4K18\<^bsub>(n)\<^esub> (z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1) .|"
      using seq_4_th_71 sorry
    also have "... =  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|"
      using seq_4_th_91 sorry
    finally show " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =HIDDENR1  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_105:
" for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .| +XCMPLX-0K2  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
proof-
  have " for n be NatNAT-1M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .| +XCMPLX-0K2  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z2 assume [ty]: "z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =HIDDENR1  |.SEQ-4K22 ((z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
      using seq_4_th_81 sorry
    also have "... =  |.SEQ-4K22 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> (z -SEQ-4K19\<^bsub>(n)\<^esub> z2) .|"
      using seq_4_th_76 sorry
    finally have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| =HIDDENR1  |.SEQ-4K22 (z1 -SEQ-4K19\<^bsub>(n)\<^esub> z)+SEQ-4K15\<^bsub>(n)\<^esub> (z -SEQ-4K19\<^bsub>(n)\<^esub> z2) .|"
       sorry
    thus " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| <=XXREAL-0R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .| +XCMPLX-0K2  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z2 .|"
      using seq_4_th_98 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_14 ("openSEQ-4V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "n be NatNAT-1M1"
"attr openSEQ-4V1\<^bsub>(n)\<^esub> for SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n means
  (\<lambda>A.  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)))"..

mdef seq_4_def_15 ("closedSEQ-4V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "n be NatNAT-1M1"
"attr closedSEQ-4V2\<^bsub>(n)\<^esub> for SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n means
  (\<lambda>A.  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A)"..

mtheorem seq_4_th_106:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 {}XBOOLE-0K1 implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
   sorry

mtheorem seq_4_th_107:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 COMPLEXSEQ-4K14 n implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 COMPLEXSEQ-4K14 n implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A1: "A =XBOOLE-0R4 COMPLEXSEQ-4K14 n"
    have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies ( ex tVar55 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar55 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar55 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      assume "x inTARSKIR2 A"
      obtain j where 
        [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
        using numbers_th_19 sorry
      show " ex tVar55 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar55 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar55 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)"
      proof(rule bexI[of _ "j"],rule conjMI,rule ballI,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 j"
           sorry
        fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume " |.SEQ-4K22 z.| <XXREAL-0R3 j"
        show "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
          using A1 sorry
      qed "sorry"
    qed "sorry"
    thus "A be openSEQ-4V1\<^bsub>(n)\<^esub>"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_108:
" for n be NatNAT-1M1 holds  for AA be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n holds ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>) implies ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 unionTARSKIK3 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>)"
proof-
  have " for n be NatNAT-1M1 holds  for AA be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n holds ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>) implies ( for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A =XBOOLE-0R4 unionTARSKIK3 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix AA assume [ty]: "AA be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n"
    assume A1: " for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 AA implies A be openSEQ-4V1\<^bsub>(n)\<^esub>"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A2: "A =XBOOLE-0R4 unionTARSKIK3 AA"
    have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies ( ex tVar56 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar56 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar56 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      assume "x inTARSKIR2 A"
      then obtain B where
        [ty]:"B be setHIDDENM2" and 
        A3: "x inTARSKIR2 B"and A4: "B inTARSKIR2 AA"
        using A2 tarski_def_4 sorry
      have 
        [ty]:"B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
        using A4 sorry
      have "B be openSEQ-4V1\<^bsub>(n)\<^esub>"
        using A1 A4 sorry
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A5: "0NUMBERSK6 <XXREAL-0R3 r"and A6: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 B"
        using A3 sorry
      show " ex tVar56 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar56 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar56 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 r"
          using A5 sorry
        fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume " |.SEQ-4K22 z.| <XXREAL-0R3 r"
        then have "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 B"
          using A6 sorry
        thus "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
          using A2 A4 tarski_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "A be openSEQ-4V1\<^bsub>(n)\<^esub>"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_109:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A be openSEQ-4V1\<^bsub>(n)\<^esub> & B be openSEQ-4V1\<^bsub>(n)\<^esub> implies ( for C be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds C =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> B implies C be openSEQ-4V1\<^bsub>(n)\<^esub>)"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A be openSEQ-4V1\<^bsub>(n)\<^esub> & B be openSEQ-4V1\<^bsub>(n)\<^esub> implies ( for C be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds C =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> B implies C be openSEQ-4V1\<^bsub>(n)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A1: "A be openSEQ-4V1\<^bsub>(n)\<^esub>"
      and A2: "B be openSEQ-4V1\<^bsub>(n)\<^esub>"
    fix C assume [ty]: "C be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A3: "C =XBOOLE-0R4 A /\\SUBSET-1K9\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> B"
    have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 C implies ( ex tVar57 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar57 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar57 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 C))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      assume A4: "x inTARSKIR2 C"
      then have "x inTARSKIR2 A"
        using A3 xboole_0_def_4 sorry
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A5: "0NUMBERSK6 <XXREAL-0R3 r1"and A6: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r1 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
        using A1 sorry
      have "x inTARSKIR2 B"
        using A3 A4 xboole_0_def_4 sorry
      then obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A7: "0NUMBERSK6 <XXREAL-0R3 r2"and A8: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r2 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 B"
        using A2 sorry
      show " ex tVar57 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar57 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar57 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 C)"
      proof(rule bexI[of _ "minXXREAL-0K4(r1,r2)"],rule conjMI,rule ballI,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 minXXREAL-0K4(r1,r2)"
          using A5 A7 xxreal_0_th_15 sorry
        fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume A9: " |.SEQ-4K22 z.| <XXREAL-0R3 minXXREAL-0K4(r1,r2)"
        have "minXXREAL-0K4(r1,r2) <=XXREAL-0R1 r2"
          using xxreal_0_th_17 sorry
        then have " |.SEQ-4K22 z.| <XXREAL-0R3 r2"
          using A9 xxreal_0_th_2 sorry
        then have A10: "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 B"
          using A8 sorry
        have "minXXREAL-0K4(r1,r2) <=XXREAL-0R1 r1"
          using xxreal_0_th_17 sorry
        then have " |.SEQ-4K22 z.| <XXREAL-0R3 r1"
          using A9 xxreal_0_th_2 sorry
        then have "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
          using A6 sorry
        thus "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 C"
          using A3 A10 xboole_0_def_4 sorry
      qed "sorry"
    qed "sorry"
    thus "C be openSEQ-4V1\<^bsub>(n)\<^esub>"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_16 ("BallSEQ-4K23\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "r be RealXREAL-0M1"
"func BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) \<rightarrow> SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n equals
  {z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r }"
proof-
  (*coherence*)
    show "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    proof-
      have "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  not  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
      proof-
        let ?P = "\<lambda>Lamb1.  |.SEQ-4K22 Lamb1 -SEQ-4K9 x .| <XXREAL-0R3 r"
        have "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) } c=TARSKIR1 COMPLEXSEQ-4K14 n"
          using fraenkel_sch_10 sorry
        thus "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  not  |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem seq_4_th_110:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) iff  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  not (z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) &  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r) &  not ( not  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r &  not z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have A1: "z inTARSKIR2 {z2 where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  |.SEQ-4K22 z2 -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r } iff ( ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st z =FINSEQ-1R1 z1 &  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r)"
       sorry
    have " |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> x .| =COMPLEX1R1  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .|"
      using seq_4_th_104 sorry
    thus " not (z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r) &  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r) &  not ( not  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| <XXREAL-0R3 r &  not z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_111:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r implies x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r)"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r implies x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    have " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> x .| =COMPLEX1R1 0NUMBERSK6"
      using seq_4_th_102 sorry
    thus "x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(x,r)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_112:
" for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
proof-
  have " for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1) implies ( ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1)))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      assume "x inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1)"
      then have A1: " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r1"
        using seq_4_th_110 sorry
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = r1 -XCMPLX-0K6  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
         sorry
      show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1))"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 r"
          using A1 xreal_1_th_50 sorry
        fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume " |.SEQ-4K22 z.| <XXREAL-0R3 r"
        then have A2: " |.SEQ-4K22 z.| +XCMPLX-0K2  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| <XXREAL-0R3 r +XCMPLX-0K2  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
          using xreal_1_th_6 sorry
        have "(z1 -SEQ-4K19\<^bsub>(n)\<^esub> x)-SEQ-4K19\<^bsub>(n)\<^esub> z =FINSEQ-1R1 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (x +SEQ-4K15\<^bsub>(n)\<^esub> z)"
          using seq_4_th_75 sorry
        then have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (x +SEQ-4K15\<^bsub>(n)\<^esub> z) .| <=XXREAL-0R1  |.SEQ-4K22 z.| +XCMPLX-0K2  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
          using seq_4_th_99 sorry
        then have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> (x +SEQ-4K15\<^bsub>(n)\<^esub> z) .| <XXREAL-0R3 r +XCMPLX-0K2  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
          using A2 xxreal_0_th_2 sorry
        thus "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1)"
          using seq_4_th_110 sorry
      qed "sorry"
    qed "sorry"
    thus "BallSEQ-4K23\<^bsub>(n)\<^esub>(z1,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_17 ("distSEQ-4K24\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
"func distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
    proof-
      have " ex L be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
      proof-
        let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
        let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
        obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) }"
          using domain_1_sch_8 sorry
        have A1: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z) =COMPLEX1R1 ?g(z)"
           sorry
        have A2: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
          using fraenkel_sch_5 A1 sorry
        obtain L where 
          [ty]:"L be RealXREAL-0M1" and LDef:"L = lower-boundSEQ-4K3 X"
           sorry
        show " ex L be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
        proof(rule bexI[of _ "L"])
          show " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies it2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies it1 =HIDDENR1 it2"
    proof-
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies r1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies r2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies r1 =HIDDENR1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies r1 =COMPLEX1R1 lower-boundSEQ-4K3 X"
          and A4: " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : z inTARSKIR2 A } implies r2 =COMPLEX1R1 lower-boundSEQ-4K3 X"
        let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
        let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
        obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) }"
          using domain_1_sch_8 sorry
        have A1: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z) =COMPLEX1R1 ?g(z)"
           sorry
        have A2: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
          using fraenkel_sch_5 A1 sorry
        have "r1 =COMPLEX1R1 lower-boundSEQ-4K3 X"
          using A3 A2 sorry
        thus "r1 =HIDDENR1 r2"
          using A4 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef seq_4_def_18 ("BallSEQ-4K25\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n", "r be RealXREAL-0M1"
"func BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) \<rightarrow> SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n equals
  {z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r }"
proof-
  (*coherence*)
    show "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    proof-
      have "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  not distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
      proof-
        let ?P = "\<lambda>Lamb1. distSEQ-4K24\<^bsub>(n)\<^esub>(Lamb1,A) <XXREAL-0R3 r"
        have "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) } c=TARSKIR1 COMPLEXSEQ-4K14 n"
          using fraenkel_sch_10 sorry
        thus "{z where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n :  not distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r } be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem seq_4_th_113:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds X <>HIDDENR2 {}XBOOLE-0K1 & ( for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 X implies r <=XXREAL-0R1 r9) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 r"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    and A2: " for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 X implies r <=XXREAL-0R1 r9"
  have " for r9 be ExtRealXXREAL-0M1 holds r9 inHIDDENR3 X implies r <=XXREAL-0R1 r9"
    using A2 sorry
  then have "r be LowerBoundXXREAL-2M2-of X"
    using xxreal_2_def_2 sorry
  then have A3: "X be bounded-belowXXREAL-2V3"
     sorry
  have " for r9 be RealXREAL-0M1 holds r9 >XXREAL-0R4 0NUMBERSK6 implies lower-boundSEQ-4K3 X +XCMPLX-0K2 r9 >=XXREAL-0R2 r"
  proof(rule ballI,rule impI)
    fix r9 assume [ty]: "r9 be RealXREAL-0M1"
    assume "r9 >XXREAL-0R4 0NUMBERSK6"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A4: "r1 inHIDDENR3 X"and A5: "r1 <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 r9"
      using A1 A3 seq_4_def_2 sorry
    have "r <=XXREAL-0R1 r1"
      using A2 A4 sorry
    thus "lower-boundSEQ-4K3 X +XCMPLX-0K2 r9 >=XXREAL-0R2 r"
      using A5 xxreal_0_th_2 sorry
  qed "sorry"
  thus "lower-boundSEQ-4K3 X >=XXREAL-0R2 r"
    using xreal_1_th_41 sorry
qed "sorry"

mtheorem seq_4_th_114:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
    let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
    let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) }"
      using domain_1_sch_8 sorry
    have A1: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z) =COMPLEX1R1 ?g(z)"
       sorry
    have A2: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
      using fraenkel_sch_5 A1 sorry
    assume "A <>HIDDENR2 {}XBOOLE-0K1"
    then obtain z1 where
      [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A3: "z1 inTARSKIR2 A"
      using subset_1_th_4 sorry
    have A4: " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z1 .| inHIDDENR3 X"
      using A3 A2 sorry
    have A5: " for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 X implies r9 >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix r9 assume [ty]: "r9 be RealXREAL-0M1"
      assume "r9 inHIDDENR3 X"
      then have " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r9 =COMPLEX1R1 ?f(z) & z inTARSKIR2 A"
         sorry
      thus "r9 >=XXREAL-0R2 0NUMBERSK6"
        using seq_4_th_95 sorry
    qed "sorry"
    have "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 lower-boundSEQ-4K3 X"
      using seq_4_def_17 A2 sorry
    thus "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 0NUMBERSK6"
      using A4 A5 seq_4_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_115:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <=XXREAL-0R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2  |.SEQ-4K22 z.|"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <=XXREAL-0R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2  |.SEQ-4K22 z.|"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
    let ?g = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
    let ?h = "\<lambda>Lamb1.  |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
    obtain Y where 
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and YDef:"Y = {?g(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) }"
      using domain_1_sch_8 sorry
    let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
    let ?f1 = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
    have A1: " for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?h(z1) =COMPLEX1R1 ?g(z1)"
       sorry
    have A2: "{?h(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
      using fraenkel_sch_5 A1 sorry
    have A3: " for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z1) =COMPLEX1R1 ?f1(z1)"
       sorry
    have A4: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?f1(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
      using fraenkel_sch_5 A3 sorry
    have A5: "Y be bounded-belowXXREAL-2V3"
    proof-
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 Y implies 0NUMBERSK6 <=XXREAL-0R1 r"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 Y"
        then have " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =HIDDENR1  |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z1 .| & z1 inTARSKIR2 A"
          using A2 sorry
        thus "0NUMBERSK6 <=XXREAL-0R1 r"
          using seq_4_th_95 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of Y"
        using xxreal_2_def_2 sorry
      thus "Y be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) }"
      using domain_1_sch_8 sorry
    assume "A <>HIDDENR2 {}XBOOLE-0K1"
    then obtain z2 where
      [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A6: "z2 inTARSKIR2 A"
      using subset_1_th_4 sorry
    have A7: "distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) =COMPLEX1R1 lower-boundSEQ-4K3 Y"
      using seq_4_def_17 A2 sorry
    have A8: " for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 X implies r9 >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) -XCMPLX-0K6  |.SEQ-4K22 z.|"
    proof(rule ballI,rule impI)
      fix r9 assume [ty]: "r9 be RealXREAL-0M1"
      assume "r9 inHIDDENR3 X"
      then obtain z3 where
        [ty]:"z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
        A9: "r9 =COMPLEX1R1  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z3 .|"and A10: "z3 inTARSKIR2 A"
        using A4 sorry
      have " |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z3 .| =COMPLEX1R1  |.SEQ-4K22 (x -SEQ-4K19\<^bsub>(n)\<^esub> z3)+SEQ-4K15\<^bsub>(n)\<^esub> z .|"
        using seq_4_th_76 sorry
      then have A11: " |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z3 .| <=XXREAL-0R1 r9 +XCMPLX-0K2  |.SEQ-4K22 z.|"
        using A9 seq_4_th_98 sorry
      have " |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z3 .| inHIDDENR3 Y"
        using A10 A2 sorry
      then have " |.SEQ-4K22 (x +SEQ-4K15\<^bsub>(n)\<^esub> z)-SEQ-4K19\<^bsub>(n)\<^esub> z3 .| >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A)"
        using A7 A5 seq_4_def_2 sorry
      then have "r9 +XCMPLX-0K2  |.SEQ-4K22 z.| >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A)"
        using A11 xxreal_0_th_2 sorry
      thus "r9 >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) -XCMPLX-0K6  |.SEQ-4K22 z.|"
        using xreal_1_th_20 sorry
    qed "sorry"
    have A12: " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| inHIDDENR3 X"
      using A6 A4 sorry
    have "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 lower-boundSEQ-4K3 X"
      using seq_4_def_17 A4 sorry
    then have "distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) -XCMPLX-0K6  |.SEQ-4K22 z.| <=XXREAL-0R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A)"
      using A12 A8 seq_4_th_113 sorry
    thus "distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <=XXREAL-0R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2  |.SEQ-4K22 z.|"
      using xreal_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_116:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
    let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
    let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) }"
      using domain_1_sch_8 sorry
    have A1: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z) =COMPLEX1R1 ?g(z)"
       sorry
    have A2: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
      using fraenkel_sch_5 A1 sorry
    assume A3: "x inTARSKIR2 A"
    then have A4: " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> x .| inHIDDENR3 X"
      using A2 sorry
    have A5: " for r1 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r1 implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 r1)"
    proof(rule ballI,rule impI)
      obtain r where 
        [ty]:"r be RealXREAL-0M1" and rDef:"r =  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
         sorry
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      assume A6: "0NUMBERSK6 <XXREAL-0R3 r1"
      show " ex r be RealXREAL-0M1 st r inHIDDENR3 X & r <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 r1"
      proof(rule bexI[of _ "r"],rule conjMI)
        show "r inHIDDENR3 X"
          using A3 A2 sorry
        show "r <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 r1"
          using A6 seq_4_th_102 sorry
      qed "sorry"
    qed "sorry"
    have A7: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies 0NUMBERSK6 <=XXREAL-0R1 r"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "r inHIDDENR3 X"
      then have " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =COMPLEX1R1  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| & z inTARSKIR2 A"
        using A2 sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 r"
        using seq_4_th_95 sorry
    qed "sorry"
    have A8: "X be bounded-belowXXREAL-2V3"
    proof-
      have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not 0NUMBERSK6 <=XXREAL-0R1 x)"
      proof(rule ballI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        show " not (x inHIDDENR3 X &  not 0NUMBERSK6 <=XXREAL-0R1 x)"
          using A7 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    have "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =HIDDENR1 lower-boundSEQ-4K3 X"
      using seq_4_def_17 A2 sorry
    also have "... = 0NUMBERSK6"
      using A4 A7 A8 A5 seq_4_def_2 sorry
    finally show "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_117:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds ( not x inTARSKIR2 A & A <>HIDDENR2 {}XBOOLE-0K1) & A be closedSEQ-4V2\<^bsub>(n)\<^esub> implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  not ((( not x inTARSKIR2 A &  not A <>HIDDENR2 {}XBOOLE-0K1) & A be closedSEQ-4V2\<^bsub>(n)\<^esub>) & distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    have " not x inTARSKIR2 A & (A <>HIDDENR2 {}XBOOLE-0K1 & (( for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A) & distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) <=XXREAL-0R1 0NUMBERSK6)) implies  False "
    proof(rule impMI ,rule impMI ,rule impMI ,rule impI)
      assume A1: " not x inTARSKIR2 A"
        and A2: "A <>HIDDENR2 {}XBOOLE-0K1"
        and A3: " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A"
        and A4: "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) <=XXREAL-0R1 0NUMBERSK6"
      have A5: "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 0NUMBERSK6"
        using A2 A4 seq_4_th_114 sorry
      have " for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)"
      proof(rule ballI,rule impI)
        let ?f = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
        let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
        have A6: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z) =COMPLEX1R1 ?g(z)"
           sorry
        have A7: "{?f(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1) } =XBOOLE-0R4 {?g(z2) where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z2) }"
          using fraenkel_sch_5 A6 sorry
        obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z) }"
          using domain_1_sch_8 sorry
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A8: "r >XXREAL-0R4 0NUMBERSK6"
        obtain z where
          [ty]:"z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A9: "z inTARSKIR2 A"
          using A2 subset_1_th_4 sorry
        have A10: "X be bounded-belowXXREAL-2V3"
        proof-
          have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 X implies 0NUMBERSK6 <=XXREAL-0R1 r"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be ExtRealXXREAL-0M1"
            assume "r inHIDDENR3 X"
            then have " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =HIDDENR1  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| & z inTARSKIR2 A"
              using A7 sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 r"
              using seq_4_th_95 sorry
          qed "sorry"
          then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
            using xxreal_2_def_2 sorry
          thus "X be bounded-belowXXREAL-2V3"
            using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
        qed
        have A11: " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| inHIDDENR3 X"
          using A9 A7 sorry
        have "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 lower-boundSEQ-4K3 X & 0NUMBERSK6 +XCMPLX-0K2 r =COMPLEX1R1 r"
          using seq_4_def_17 A7 sorry
        then obtain r9 where
          [ty]:"r9 be RealXREAL-0M1" and 
          A12: "r9 inHIDDENR3 X"and A13: "r9 <XXREAL-0R3 r"
          using A5 A8 A11 A10 seq_4_def_2 sorry
        obtain z1 where
          [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A14: "r9 =COMPLEX1R1  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z1 .| & z1 inTARSKIR2 A"
          using A12 A7 sorry
        obtain z where 
          [ty]:"z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and zDef:"z = z1 -SEQ-4K19\<^bsub>(n)\<^esub> x"
           sorry
        show " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
        proof(rule bexI[of _ "z"])
          show " |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
            using A13 A14 seq_4_th_80 seq_4_th_104 sorry
        qed "sorry"
      qed "sorry"
      thus " False "
        using A1 A3 sorry
    qed
    thus " not ((( not x inTARSKIR2 A &  not A <>HIDDENR2 {}XBOOLE-0K1) & A be closedSEQ-4V2\<^bsub>(n)\<^esub>) & distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >XXREAL-0R4 0NUMBERSK6)"
      using seq_4_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_118:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(z1,A)"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(z1,A))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix z1 assume [ty]: "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    have "x +SEQ-4K15\<^bsub>(n)\<^esub> (z1 -SEQ-4K19\<^bsub>(n)\<^esub> x) =FINSEQ-1R1 z1"
      using seq_4_th_80 sorry
    thus " not ( not A <>HIDDENR2 {}XBOOLE-0K1 &  not  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) >=XXREAL-0R2 distSEQ-4K24\<^bsub>(n)\<^esub>(z1,A))"
      using seq_4_th_115 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_119:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) iff distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  not (z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) & distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r) &  not ( not distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r &  not z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    have "z inTARSKIR2 {z2 where z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : distSEQ-4K24\<^bsub>(n)\<^esub>(z2,A) <XXREAL-0R3 r } iff ( ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st z =FINSEQ-1R1 z1 & distSEQ-4K24\<^bsub>(n)\<^esub>(z1,A) <XXREAL-0R3 r)"
       sorry
    thus " not (z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r) & distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r) &  not ( not distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) <XXREAL-0R3 r &  not z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_120:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r & x inTARSKIR2 A implies x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r & x inTARSKIR2 A implies x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
      and A2: "x inTARSKIR2 A"
    have "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) =COMPLEX1R1 0NUMBERSK6"
      using A2 seq_4_th_116 sorry
    thus "x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_121:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds 0NUMBERSK6 <XXREAL-0R3 r implies A c=TARSKIR1 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r)"
  using seq_4_th_120 sorry

mtheorem seq_4_th_122:
" for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
proof-
  have " for n be NatNAT-1M1 holds  for r1 be RealXREAL-0M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 implies BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r1 assume [ty]: "r1 be RealXREAL-0M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
    have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1) implies ( ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1)))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      assume "x inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1)"
      then have A2: "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) <XXREAL-0R3 r1"
        using seq_4_th_119 sorry
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = r1 -XCMPLX-0K6 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A)"
         sorry
      show " ex r be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1))"
      proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 r"
          using A2 xreal_1_th_50 sorry
        fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume " |.SEQ-4K22 z.| <XXREAL-0R3 r"
        then have A3: " |.SEQ-4K22 z.| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) <XXREAL-0R3 r +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A)"
          using xreal_1_th_6 sorry
        have "distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <=XXREAL-0R1  |.SEQ-4K22 z.| +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A)"
          using A1 seq_4_th_115 sorry
        then have "distSEQ-4K24\<^bsub>(n)\<^esub>(x +SEQ-4K15\<^bsub>(n)\<^esub> z,A) <XXREAL-0R3 r +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A)"
          using A3 xxreal_0_th_2 sorry
        thus "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1)"
           sorry
      qed "sorry"
    qed "sorry"
    thus "BallSEQ-4K25\<^bsub>(n)\<^esub>(A,r1) be openSEQ-4V1\<^bsub>(n)\<^esub>"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_19 ("distSEQ-4K26\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be NatNAT-1M1", "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n", "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
"func distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
proof-
  (*existence*)
    show " ex it be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it =COMPLEX1R1 lower-boundSEQ-4K3 X"
    proof-
      have " ex L be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
      proof-
        let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10( |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|,REALNUMBERSK2)"
        let ?g = "\<lambda>Lamb1. \<lambda>Lamb2.  |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 A & Lamb2 inTARSKIR2 B"
        obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(x,z) where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(x,z) }"
          using domain_1_sch_9 sorry
        have A1: " for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z1,z2) =COMPLEX1R1 ?g(z1,z2)"
           sorry
        have A2: "{?f(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) } =XBOOLE-0R4 {?g(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) }"
          using fraenkel_sch_7 A1 sorry
        obtain L where 
          [ty]:"L be RealXREAL-0M1" and LDef:"L = lower-boundSEQ-4K3 X"
           sorry
        show " ex L be RealXREAL-0M1 st  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
        proof(rule bexI[of _ "L"])
          show " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } &  not L =COMPLEX1R1 lower-boundSEQ-4K3 X)"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies it2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies it1 =HIDDENR1 it2"
    proof-
      have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies r1 =COMPLEX1R1 lower-boundSEQ-4K3 X) & ( for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies r2 =COMPLEX1R1 lower-boundSEQ-4K3 X) implies r1 =HIDDENR1 r2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix r1 assume [ty]: "r1 be RealXREAL-0M1"
        fix r2 assume [ty]: "r2 be RealXREAL-0M1"
        assume A3: " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies r1 =COMPLEX1R1 lower-boundSEQ-4K3 X"
          and A4: " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X =XBOOLE-0R4 { |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z .| where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : x inTARSKIR2 A & z inTARSKIR2 B } implies r2 =COMPLEX1R1 lower-boundSEQ-4K3 X"
        let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10( |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|,REALNUMBERSK2)"
        let ?g = "\<lambda>Lamb1. \<lambda>Lamb2.  |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 A & Lamb2 inTARSKIR2 B"
        obtain X where 
          [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(x,z) where x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(x,z) }"
          using domain_1_sch_9 sorry
        have A1: " for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z1,z2) =COMPLEX1R1 ?g(z1,z2)"
           sorry
        have A2: "{?f(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) } =XBOOLE-0R4 {?g(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) }"
          using fraenkel_sch_7 A1 sorry
        have "r1 =COMPLEX1R1 lower-boundSEQ-4K3 X"
          using A3 A2 sorry
        thus "r1 =HIDDENR1 r2"
          using A4 A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem seq_4_th_123:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies X ++MEMBER-1K9 Y <>HIDDENR2 {}XBOOLE-0K1"
   sorry

mtheorem seq_4_th_124:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 & Y be bounded-belowXXREAL-2V3 implies X ++MEMBER-1K9 Y be bounded-belowXXREAL-2V3"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be bounded-belowXXREAL-2V3 implies (Y be bounded-belowXXREAL-2V3 implies X ++MEMBER-1K9 Y be bounded-belowXXREAL-2V3)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume "X be bounded-belowXXREAL-2V3"
    then obtain r1 where
      [ty]:"r1 be RealXREAL-0M1" and 
      A1: "r1 be LowerBoundXXREAL-2M2-of X"
       sorry
    have A2: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r1 <=XXREAL-0R1 r"
      using A1 xxreal_2_def_2 sorry
    assume "Y be bounded-belowXXREAL-2V3"
    then obtain r2 where
      [ty]:"r2 be RealXREAL-0M1" and 
      A3: "r2 be LowerBoundXXREAL-2M2-of Y"
       sorry
    have A4: " for r be RealXREAL-0M1 holds r inHIDDENR3 Y implies r2 <=XXREAL-0R1 r"
      using A3 xxreal_2_def_2 sorry
    have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 X ++MEMBER-1K9 Y implies r1 +XCMPLX-0K2 r2 <=XXREAL-0R1 r"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be ExtRealXXREAL-0M1"
      assume "r inHIDDENR3 X ++MEMBER-1K9 Y"
      then have "r inHIDDENR3 {r22 +XCMPLX-0K2 r12 where r22 be ComplexXCMPLX-0M1, r12 be ComplexXCMPLX-0M1 : r22 inHIDDENR3 X & r12 inHIDDENR3 Y }"
        using member_1_def_6 sorry
      then obtain r22 r12 where
        [ty]:"r22 be ComplexXCMPLX-0M1" "r12 be ComplexXCMPLX-0M1" and 
        A5: "r =HIDDENR1 r22 +XCMPLX-0K2 r12"and A6: "r22 inHIDDENR3 X"and A7: "r12 inHIDDENR3 Y"
         sorry
      obtain r9 r99 where 
        [ty]:"r9 be RealXREAL-0M1" and r9Def:"r9 = r22" and
        [ty]:"r99 be RealXREAL-0M1" and r99Def:"r99 = r12"
        using A6 A7 sorry
      have A8: "r2 <=XXREAL-0R1 r99"
        using A4 A7 sorry
      have "r1 <=XXREAL-0R1 r9"
        using A2 A6 sorry
      thus "r1 +XCMPLX-0K2 r2 <=XXREAL-0R1 r"
        using A5 A8 xreal_1_th_7 sorry
    qed "sorry"
    then have "r1 +XCMPLX-0K2 r2 be LowerBoundXXREAL-2M2-of X ++MEMBER-1K9 Y"
      using xxreal_2_def_2 sorry
    thus "X ++MEMBER-1K9 Y be bounded-belowXXREAL-2V3"
      using bexI[of _ "r1 +XCMPLX-0K2 r2"] xxreal_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_125:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((X <>HIDDENR2 {}XBOOLE-0K1 & X be bounded-belowXXREAL-2V3) & Y <>HIDDENR2 {}XBOOLE-0K1) & Y be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 (X ++MEMBER-1K9 Y) =COMPLEX1R1 lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & (X be bounded-belowXXREAL-2V3 & (Y <>HIDDENR2 {}XBOOLE-0K1 & Y be bounded-belowXXREAL-2V3)) implies lower-boundSEQ-4K3 (X ++MEMBER-1K9 Y) =COMPLEX1R1 lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X be bounded-belowXXREAL-2V3"
      and A3: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A4: "Y be bounded-belowXXREAL-2V3"
    have A5: " for r9 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r9 implies ( ex r be RealXREAL-0M1 st r inHIDDENR3 X ++MEMBER-1K9 Y & r <XXREAL-0R3 (lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y)+XCMPLX-0K2 r9)"
    proof(rule ballI,rule impI)
      fix r9 assume [ty]: "r9 be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 r9"
      then have A6: "r9 /XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
         sorry
      then obtain r1 where
        [ty]:"r1 be RealXREAL-0M1" and 
        A7: "r1 inHIDDENR3 X"and A8: "r1 <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 r9 /XCMPLX-0K7 \<two>\<^sub>M"
        using A1 A2 seq_4_def_2 sorry
      obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A9: "r2 inHIDDENR3 Y"and A10: "r2 <XXREAL-0R3 lower-boundSEQ-4K3 Y +XCMPLX-0K2 r9 /XCMPLX-0K7 \<two>\<^sub>M"
        using A3 A4 A6 seq_4_def_2 sorry
      obtain r where 
        [ty]:"r be RealXREAL-0M1" and rDef:"r = r1 +XCMPLX-0K2 r2"
         sorry
      show " ex r be RealXREAL-0M1 st r inHIDDENR3 X ++MEMBER-1K9 Y & r <XXREAL-0R3 (lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y)+XCMPLX-0K2 r9"
      proof(rule bexI[of _ "r"],rule conjMI)
        show "r inHIDDENR3 X ++MEMBER-1K9 Y"
          using A7 A9 member_1_th_46 sorry
        have "(lower-boundSEQ-4K3 X +XCMPLX-0K2 r9 /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (lower-boundSEQ-4K3 Y +XCMPLX-0K2 r9 /XCMPLX-0K7 \<two>\<^sub>M) =COMPLEX1R1 (lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y)+XCMPLX-0K2 r9"
           sorry
        thus "r <XXREAL-0R3 (lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y)+XCMPLX-0K2 r9"
          using A8 A10 xreal_1_th_8 sorry
      qed "sorry"
    qed "sorry"
    have A11: " for r be RealXREAL-0M1 holds r inHIDDENR3 X ++MEMBER-1K9 Y implies lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y <=XXREAL-0R1 r"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "r inHIDDENR3 X ++MEMBER-1K9 Y"
      then have "r inHIDDENR3 {r22 +XCMPLX-0K2 r12 where r22 be ComplexXCMPLX-0M1, r12 be ComplexXCMPLX-0M1 : r22 inHIDDENR3 X & r12 inHIDDENR3 Y }"
        using member_1_def_6 sorry
      then obtain r11 r22 where
        [ty]:"r11 be ComplexXCMPLX-0M1" "r22 be ComplexXCMPLX-0M1" and 
        A12: "r =COMPLEX1R1 r11 +XCMPLX-0K2 r22"and A13: "r11 inHIDDENR3 X & r22 inHIDDENR3 Y"
         sorry
      obtain r1 r2 where 
        [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = r11" and
        [ty]:"r2 be RealXREAL-0M1" and r2Def:"r2 = r22"
        using A13 sorry
      have "r1 >=XXREAL-0R2 lower-boundSEQ-4K3 X & r2 >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
        using A2 A4 A13 seq_4_def_2 sorry
      thus "lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y <=XXREAL-0R1 r"
        using A12 xreal_1_th_7 sorry
    qed "sorry"
    have "X ++MEMBER-1K9 Y <>HIDDENR2 {}XBOOLE-0K1 & X ++MEMBER-1K9 Y be bounded-belowXXREAL-2V3"
      using A1 A2 A3 A4 seq_4_th_124 sorry
    thus "lower-boundSEQ-4K3 (X ++MEMBER-1K9 Y) =COMPLEX1R1 lower-boundSEQ-4K3 X +XCMPLX-0K2 lower-boundSEQ-4K3 Y"
      using A11 A5 seq_4_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_126:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Y be bounded-belowXXREAL-2V3 & X <>HIDDENR2 {}XBOOLE-0K1) & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 Y & r1 <=XXREAL-0R1 r)) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Y be bounded-belowXXREAL-2V3 & (X <>HIDDENR2 {}XBOOLE-0K1 & ( for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 Y & r1 <=XXREAL-0R1 r))) implies lower-boundSEQ-4K3 X >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Y be bounded-belowXXREAL-2V3"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A3: " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 Y & r1 <=XXREAL-0R1 r)"
    have " for r1 be RealXREAL-0M1 holds r1 inHIDDENR3 X implies r1 >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      assume "r1 inHIDDENR3 X"
      then obtain r2 where
        [ty]:"r2 be RealXREAL-0M1" and 
        A4: "r2 inHIDDENR3 Y"and A5: "r2 <=XXREAL-0R1 r1"
        using A3 sorry
      have "lower-boundSEQ-4K3 Y <=XXREAL-0R1 r2"
        using A1 A4 seq_4_def_2 sorry
      thus "r1 >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
        using A5 xxreal_0_th_2 sorry
    qed "sorry"
    thus "lower-boundSEQ-4K3 X >=XXREAL-0R2 lower-boundSEQ-4K3 Y"
      using A2 seq_4_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_127:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 A & Lamb2 inTARSKIR2 B"
    let ?f = "\<lambda>Lamb1. \<lambda>Lamb2.  |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|"
    let ?g = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10( |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|,REALNUMBERSK2)"
    have A1: " for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z1,z2) =COMPLEX1R1 ?g(z1,z2)"
       sorry
    have A2: "{?f(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) } =XBOOLE-0R4 {?g(z1,z2) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z2) }"
      using fraenkel_sch_7 A1 sorry
    obtain Z where 
      [ty]:"Z be SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = {?g(z1,z) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z) }"
      using domain_1_sch_9 sorry
    assume A3: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A4: "B <>HIDDENR2 {}XBOOLE-0K1"
    obtain z1 where
      [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A5: "z1 inTARSKIR2 A"
      using A3 subset_1_th_4 sorry
    have A6: " for r9 be RealXREAL-0M1 holds r9 inHIDDENR3 Z implies r9 >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix r9 assume [ty]: "r9 be RealXREAL-0M1"
      assume "r9 inHIDDENR3 Z"
      then have " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r9 =COMPLEX1R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .| & z1 inTARSKIR2 A) & z inTARSKIR2 B"
        using A2 sorry
      thus "r9 >=XXREAL-0R2 0NUMBERSK6"
        using seq_4_th_95 sorry
    qed "sorry"
    obtain z2 where
      [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A7: "z2 inTARSKIR2 B"
      using A4 subset_1_th_4 sorry
    have A8: "distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 lower-boundSEQ-4K3 Z"
      using seq_4_def_19 A2 sorry
    have " |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| inHIDDENR3 Z"
      using A5 A7 A2 sorry
    thus "distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) >=XXREAL-0R2 0NUMBERSK6"
      using A8 A6 seq_4_th_113 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_128:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 distSEQ-4K26\<^bsub>(n)\<^esub>(B,A)"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 distSEQ-4K26\<^bsub>(n)\<^esub>(B,A)"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 B & Lamb2 inTARSKIR2 A"
    let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10( |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|,REALNUMBERSK2)"
    let ?f1 = "\<lambda>Lamb1. \<lambda>Lamb2.  |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|"
    obtain Y where 
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and YDef:"Y = {?f(z,z1) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?R(z,z1) }"
      using domain_1_sch_9 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 A & Lamb2 inTARSKIR2 B"
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?f(z1,z) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z) }"
      using domain_1_sch_9 sorry
    have A1: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X iff r inTARSKIR2 Y"
    proof(rule ballI)
      fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
      have A2: "( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|,REALNUMBERSK2) & z inTARSKIR2 B) & z1 inTARSKIR2 A) implies ( ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .|,REALNUMBERSK2) & z1 inTARSKIR2 A) & z inTARSKIR2 B)"
      proof(rule impI)
        assume Given: " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 ?f(z,z1) & z inTARSKIR2 B) & z1 inTARSKIR2 A"
        then obtain z z1 where
          [ty]:"z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" "z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A3: "(r =COMPLEX1R1 ?f(z,z1) & z inTARSKIR2 B) & z1 inTARSKIR2 A"
           sorry
        show " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .|,REALNUMBERSK2) & z1 inTARSKIR2 A) & z inTARSKIR2 B"
        proof(rule bexI[of _ "z1"])
          show " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .|,REALNUMBERSK2) & z1 inTARSKIR2 A) & z inTARSKIR2 B"
          proof(rule bexI[of _ "z"])
            show "(r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .|,REALNUMBERSK2) & z1 inTARSKIR2 A) & z inTARSKIR2 B"
              using A3 seq_4_th_104 sorry
          qed "sorry"
        qed "sorry"
      qed
      have "( ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> z .|,REALNUMBERSK2) & z1 inTARSKIR2 A) & z inTARSKIR2 B) implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|,REALNUMBERSK2) & z inTARSKIR2 B) & z1 inTARSKIR2 A)"
      proof(rule impI)
        assume Given: " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 ?f(z1,z) & z1 inTARSKIR2 A) & z inTARSKIR2 B"
        then obtain z1 z where
          [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A4: "(r =COMPLEX1R1 ?f(z1,z) & z1 inTARSKIR2 A) & z inTARSKIR2 B"
           sorry
        show " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|,REALNUMBERSK2) & z inTARSKIR2 B) & z1 inTARSKIR2 A"
        proof(rule bexI[of _ "z"])
          show " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st (r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|,REALNUMBERSK2) & z inTARSKIR2 B) & z1 inTARSKIR2 A"
          proof(rule bexI[of _ "z1"])
            show "(r =COMPLEX1R1 InSUBSET-1K10( |.SEQ-4K22 z -SEQ-4K19\<^bsub>(n)\<^esub> z1 .|,REALNUMBERSK2) & z inTARSKIR2 B) & z1 inTARSKIR2 A"
              using A4 seq_4_th_104 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus "r inTARSKIR2 X iff r inTARSKIR2 Y"
        using A2 sorry
    qed "sorry"
    have A5: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z,z1) =COMPLEX1R1 ?f1(z,z1)"
       sorry
    have A6: "{?f(z,z1) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?R(z,z1) } =XBOOLE-0R4 {?f1(z,z1) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?R(z,z1) }"
      using fraenkel_sch_7 A5 sorry
    have "{?f(z1,z) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z) } =XBOOLE-0R4 {?f1(z1,z) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z) }"
      using fraenkel_sch_7 A5 sorry
    then have "distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 lower-boundSEQ-4K3 X & distSEQ-4K26\<^bsub>(n)\<^esub>(B,A) =COMPLEX1R1 lower-boundSEQ-4K3 Y"
      using seq_4_def_19 A6 sorry
    thus "distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 distSEQ-4K26\<^bsub>(n)\<^esub>(B,A)"
      using A1 subset_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_129:
" for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,B) >=XXREAL-0R2 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
proof-
  have " for n be NatNAT-1M1 holds  for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A <>HIDDENR2 {}XBOOLE-0K1 & B <>HIDDENR2 {}XBOOLE-0K1 implies distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,B) >=XXREAL-0R2 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    let ?Y = "\<lambda>Lamb1. Lamb1 inTARSKIR2 B"
    let ?g = "\<lambda>Lamb1.  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|"
    let ?g1 = "\<lambda>Lamb1. InSUBSET-1K10( |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> Lamb1 .|,REALNUMBERSK2)"
    obtain Y where 
      [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and YDef:"Y = {?g1(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?Y(z) }"
      using domain_1_sch_8 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inTARSKIR2 A & Lamb2 inTARSKIR2 B"
    let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
    let ?f = "\<lambda>Lamb1. \<lambda>Lamb2. InSUBSET-1K10( |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|,REALNUMBERSK2)"
    let ?f1 = "\<lambda>Lamb1. \<lambda>Lamb2.  |.SEQ-4K22 Lamb1 -SEQ-4K19\<^bsub>(n)\<^esub> Lamb2 .|"
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = {?g1(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?X(z) }"
      using domain_1_sch_8 sorry
    assume A1: "A <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "B <>HIDDENR2 {}XBOOLE-0K1"
    obtain z2 where
      [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A3: "z2 inTARSKIR2 B"
      using A2 subset_1_th_4 sorry
    have A4: "Y <>HIDDENR2 {}XBOOLE-0K1 & Y be bounded-belowXXREAL-2V3"
    proof(rule conjMI)
      have "?g1(z2) inTARSKIR2 Y"
        using A3 sorry
      thus "Y <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 Y implies 0NUMBERSK6 <=XXREAL-0R1 r"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 Y"
        then have " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =HIDDENR1 ?g1(z1) & z1 inTARSKIR2 B"
           sorry
        thus "0NUMBERSK6 <=XXREAL-0R1 r"
          using seq_4_th_95 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of Y"
        using xxreal_2_def_2 sorry
      thus "Y be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    have A5: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?g1(z) =COMPLEX1R1 ?g(z)"
       sorry
    have A6: "{?g1(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?Y(z) } =XBOOLE-0R4 {?g(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?Y(z1) }"
      using fraenkel_sch_5 A5 sorry
    have "{?g1(z) where z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?X(z) } =XBOOLE-0R4 {?g(z1) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?X(z1) }"
      using fraenkel_sch_5 A5 sorry
    then have A7: "lower-boundSEQ-4K3 X =COMPLEX1R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) & lower-boundSEQ-4K3 Y =COMPLEX1R1 distSEQ-4K24\<^bsub>(n)\<^esub>(x,B)"
      using seq_4_def_17 A6 sorry
    have A8: "?g1(z2) inTARSKIR2 Y"
      using A3 sorry
    obtain Z where 
      [ty]:"Z be SubsetSUBSET-1M2-of REALNUMBERSK2" and ZDef:"Z = {?f(z1,z) where z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z1,z) }"
      using domain_1_sch_9 sorry
    obtain z1 where
      [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
      A9: "z1 inTARSKIR2 A"
      using A1 subset_1_th_4 sorry
    have "X ++MEMBER-1K9 Y c=MEMBEREDR3 REALNUMBERSK2"
      using membered_th_3 sorry
    then obtain XY where 
      [ty]:"XY be SubsetSUBSET-1M2-of REALNUMBERSK2" and XYDef:"XY = X ++MEMBER-1K9 Y"
       sorry
    have A10: " for r be RealXREAL-0M1 holds r inHIDDENR3 XY implies ( ex r1 be RealXREAL-0M1 st r1 inHIDDENR3 Z & r1 <=XXREAL-0R1 r)"
    proof-
      have " for r be RealXREAL-0M1 holds r inHIDDENR3 XY implies ( ex r3 be ElementSUBSET-1M1-of REALNUMBERSK2 st r3 inTARSKIR2 Z & r3 <=XXREAL-0R1 r)"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "r inHIDDENR3 XY"
        then have "r inHIDDENR3 {r2 +XCMPLX-0K2 r1 where r2 be ComplexXCMPLX-0M1, r1 be ComplexXCMPLX-0M1 : r2 inHIDDENR3 X & r1 inHIDDENR3 Y }"
          using member_1_def_6 sorry
        then obtain r2 r1 where
          [ty]:"r2 be ComplexXCMPLX-0M1" "r1 be ComplexXCMPLX-0M1" and 
          A11: "r =COMPLEX1R1 r2 +XCMPLX-0K2 r1"and A12: "r2 inHIDDENR3 X"and A13: "r1 inHIDDENR3 Y"
           sorry
        obtain z2 where
          [ty]:"z2 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A14: "r1 =COMPLEX1R1 ?g1(z2) & z2 inTARSKIR2 B"
          using A13 sorry
        obtain z1 where
          [ty]:"z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
          A15: "r2 =COMPLEX1R1 ?g1(z1)"and A16: "z1 inTARSKIR2 A"
          using A12 sorry
        obtain r3 where 
          [ty]:"r3 be ElementSUBSET-1M1-of REALNUMBERSK2" and r3Def:"r3 = ?f(z1,z2)"
           sorry
        show " ex r3 be ElementSUBSET-1M1-of REALNUMBERSK2 st r3 inTARSKIR2 Z & r3 <=XXREAL-0R1 r"
        proof(rule bexI[of _ "r3"])
          have "r2 =COMPLEX1R1  |.SEQ-4K22 z1 -SEQ-4K19\<^bsub>(n)\<^esub> x .|"
            using A15 seq_4_th_104 sorry
          thus "r3 inTARSKIR2 Z & r3 <=XXREAL-0R1 r"
            using A11 A16 A14 seq_4_th_105 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A17: "Z be bounded-belowXXREAL-2V3"
    proof-
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 Z implies 0NUMBERSK6 <=XXREAL-0R1 r"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 Z"
        then have " ex z1 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =HIDDENR1 ?f(z1,z) & ?P(z1,z)"
           sorry
        thus "0NUMBERSK6 <=XXREAL-0R1 r"
          using seq_4_th_95 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of Z"
        using xxreal_2_def_2 sorry
      thus "Z be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    have A18: "X <>HIDDENR2 {}XBOOLE-0K1 & X be bounded-belowXXREAL-2V3"
    proof(rule conjMI)
      have "?g1(z1) inTARSKIR2 X"
        using A9 sorry
      thus "X <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 X implies 0NUMBERSK6 <=XXREAL-0R1 r"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 X"
        then have " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st r =HIDDENR1 ?g1(z) & z inTARSKIR2 A"
           sorry
        thus "0NUMBERSK6 <=XXREAL-0R1 r"
          using seq_4_th_95 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    have A19: " for z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ?f(z3,z) =COMPLEX1R1 ?f1(z3,z)"
       sorry
    have "{?f(z3,z) where z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z3,z) } =XBOOLE-0R4 {?f1(z3,z) where z3 be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n, z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n : ?P(z3,z) }"
      using fraenkel_sch_7 A19 sorry
    then have A20: "lower-boundSEQ-4K3 Z =COMPLEX1R1 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
      using seq_4_def_19 sorry
    have "?g1(z1) inTARSKIR2 X"
      using A9 sorry
    then have " |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z1 .| +XCMPLX-0K2  |.SEQ-4K22 x -SEQ-4K19\<^bsub>(n)\<^esub> z2 .| inTARSKIR2 X ++MEMBER-1K9 Y"
      using A8 member_1_th_46 sorry
    then have "XY <>HIDDENR2 {}XBOOLE-0K1"
       sorry
    then have "lower-boundSEQ-4K3 XY >=XXREAL-0R2 lower-boundSEQ-4K3 Z"
      using A17 A10 seq_4_th_126 sorry
    thus "distSEQ-4K24\<^bsub>(n)\<^esub>(x,A) +XCMPLX-0K2 distSEQ-4K24\<^bsub>(n)\<^esub>(x,B) >=XXREAL-0R2 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
      using A18 A4 A7 A20 seq_4_th_125 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_130:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A meetsXBOOLE-0R5 B implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A meetsXBOOLE-0R5 B implies distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    assume "A meetsXBOOLE-0R5 B"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A1: "z inHIDDENR3 A"and A2: "z inHIDDENR3 B"
      using xboole_0_th_3 sorry
    have 
      [ty]:"z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
      using A1 sorry
    have "distSEQ-4K24\<^bsub>(n)\<^esub>(z,A) =COMPLEX1R1 0NUMBERSK6 & distSEQ-4K24\<^bsub>(n)\<^esub>(z,B) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 seq_4_th_116 sorry
    then have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 >=XXREAL-0R2 distSEQ-4K26\<^bsub>(n)\<^esub>(A,B)"
      using A1 A2 seq_4_th_129 sorry
    thus "distSEQ-4K26\<^bsub>(n)\<^esub>(A,B) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 seq_4_th_127 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef seq_4_def_20 ("ComplexOpenSetsSEQ-4K27  _ " [164]164 ) where
  mlet "n be NatNAT-1M1"
"func ComplexOpenSetsSEQ-4K27 n \<rightarrow> Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n equals
  {A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> }"
proof-
  (*coherence*)
    show "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n"
    proof-
      let ?S = "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> }"
      have "?S c=TARSKIR1 boolZFMISC-1K1 (COMPLEXSEQ-4K14 n)"
      proof-
        have "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } c=TARSKIR1 boolZFMISC-1K1 (COMPLEXSEQ-4K14 n)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } implies x inHIDDENR3 boolZFMISC-1K1 (COMPLEXSEQ-4K14 n)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?S"
            then have " ex A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n st x =HIDDENR1 A & A be openSEQ-4V1\<^bsub>(n)\<^esub>"
               sorry
            thus "x inHIDDENR3 boolZFMISC-1K1 (COMPLEXSEQ-4K14 n)"
               sorry
          qed "sorry"
          thus "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } c=TARSKIR1 boolZFMISC-1K1 (COMPLEXSEQ-4K14 n)"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "{A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } be Subset-FamilySETFAM-1M1-of COMPLEXSEQ-4K14 n"
         sorry
    qed
qed "sorry"

mtheorem seq_4_th_131:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A inTARSKIR2 ComplexOpenSetsSEQ-4K27 n iff A be openSEQ-4V1\<^bsub>(n)\<^esub>"
proof-
  have " for n be NatNAT-1M1 holds  for B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds  not (B inTARSKIR2 ComplexOpenSetsSEQ-4K27 n &  not B be openSEQ-4V1\<^bsub>(n)\<^esub>) &  not (B be openSEQ-4V1\<^bsub>(n)\<^esub> &  not B inTARSKIR2 ComplexOpenSetsSEQ-4K27 n)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix B assume [ty]: "B be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    have "B inTARSKIR2 {A where A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n : A be openSEQ-4V1\<^bsub>(n)\<^esub> } iff ( ex C be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n st B =XBOOLE-0R4 C & C be openSEQ-4V1\<^bsub>(n)\<^esub>)"
       sorry
    thus " not (B inTARSKIR2 ComplexOpenSetsSEQ-4K27 n &  not B be openSEQ-4V1\<^bsub>(n)\<^esub>) &  not (B be openSEQ-4V1\<^bsub>(n)\<^esub> &  not B inTARSKIR2 ComplexOpenSetsSEQ-4K27 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_132:
" for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds A be closedSEQ-4V2\<^bsub>(n)\<^esub> iff A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>"
proof-
  have " for n be NatNAT-1M1 holds  for A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n holds (A be closedSEQ-4V2\<^bsub>(n)\<^esub> implies A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>) &  not (A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub> &  not A be closedSEQ-4V2\<^bsub>(n)\<^esub>)"
  proof(rule ballI,rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of COMPLEXSEQ-4K14 n"
    show "A be closedSEQ-4V2\<^bsub>(n)\<^esub> implies A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>"
    proof-
      have " not (A be closedSEQ-4V2\<^bsub>(n)\<^esub> &  not A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>)"
      proof-
        have "( for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A) implies A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>"
        proof(rule impI)
          assume A1: " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A"
          have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> implies ( ex tVar77 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar77 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar77 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
            assume "x inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>"
            then have " not x inTARSKIR2 A"
              using xboole_0_def_5 sorry
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A2: "r >XXREAL-0R4 0NUMBERSK6"and A3: " for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies  not x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
              using A1 sorry
            show " ex tVar77 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar77 & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 tVar77 implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>)"
            proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule impI)
              show "0NUMBERSK6 <XXREAL-0R3 r"
                using A2 sorry
              fix z assume [ty]: "z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
              assume " |.SEQ-4K22 z.| <XXREAL-0R3 r"
              thus "x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>"
                using A3 subset_1_th_29 sorry
            qed "sorry"
          qed "sorry"
          thus "A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>"
            using seq_4_def_14 sorry
        qed
        thus " not (A be closedSEQ-4V2\<^bsub>(n)\<^esub> &  not A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub>)"
          using seq_4_def_15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>))) implies A be closedSEQ-4V2\<^bsub>(n)\<^esub>"
    proof(rule impI)
      assume A4: " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds x inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds  |.SEQ-4K22 z.| <XXREAL-0R3 r implies x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>))"
      have " for x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n holds ( for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)) implies x inTARSKIR2 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n"
        assume A5: " for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A)"
        have " for r be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 implies ( ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r &  not x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>)"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "r >XXREAL-0R4 0NUMBERSK6"
          then obtain z where
            [ty]:"z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n" and 
            A6: " |.SEQ-4K22 z.| <XXREAL-0R3 r & x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A"
            using A5 sorry
          show " ex z be ElementFINSEQ-2M2\<^bsub>(COMPLEXNUMBERSK3)\<^esub>-of COMPLEXSEQ-4K14 n st  |.SEQ-4K22 z.| <XXREAL-0R3 r &  not x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>"
          proof(rule bexI[of _ "z"])
            show " |.SEQ-4K22 z.| <XXREAL-0R3 r &  not x +SEQ-4K15\<^bsub>(n)\<^esub> z inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>"
              using A6 xboole_0_def_5 sorry
          qed "sorry"
        qed "sorry"
        then have " not x inTARSKIR2 A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub>"
          using A4 sorry
        thus "x inTARSKIR2 A"
          using subset_1_th_29 sorry
      qed "sorry"
      thus "A be closedSEQ-4V2\<^bsub>(n)\<^esub>"
        using seq_4_def_15 sorry
    qed
    thus " not (A `SUBSET-1K3\<^bsub>(COMPLEXSEQ-4K14 n)\<^esub> be openSEQ-4V1\<^bsub>(n)\<^esub> &  not A be closedSEQ-4V2\<^bsub>(n)\<^esub>)"
      using seq_4_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve v, v1, v2 for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
reserve n, m, k for "NatNAT-1M1"
mlemma seq_4_lm_13:
" for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 0NUMBERSK6 implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
   sorry

mlemma seq_4_lm_14:
" for n be NatNAT-1M1 holds ( for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R) implies ( for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R)"
proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: " for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
  fix R assume [ty]: "R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  assume A2: "R <>HIDDENR2 {}XBOOLE-0K1"
    and A3: "cardCARD-1K4 R =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
  have "R be bounded-aboveXXREAL-2V4 & (upper-boundSEQ-4K2 R inHIDDENR3 R & (R be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 R inHIDDENR3 R))"
  proof-
    show "R be bounded-aboveXXREAL-2V4 & (upper-boundSEQ-4K2 R inHIDDENR3 R & (R be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 R inHIDDENR3 R))"
    proof-
      have cases: "n =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "n =COMPLEX1R1 0NUMBERSK6 implies R be bounded-aboveXXREAL-2V4 & (upper-boundSEQ-4K2 R inHIDDENR3 R & (R be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 R inHIDDENR3 R))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI)
        assume A4: "n =COMPLEX1R1 0NUMBERSK6"
        show "R be bounded-aboveXXREAL-2V4"
           sorry
        obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "R =XBOOLE-0R4 {TARSKIK1 x}"
          using A3 A4 card_2_th_42 sorry
        have "x inHIDDENR3 R"
          using A5 tarski_def_1 sorry
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = x"
           sorry
        have "upper-boundSEQ-4K2 R =COMPLEX1R1 r"
          using A5 seq_4_th_9 sorry
        thus "upper-boundSEQ-4K2 R inHIDDENR3 R"
          using A5 tarski_def_1 sorry
        show "R be bounded-belowXXREAL-2V3"
           sorry
        have "lower-boundSEQ-4K3 R =COMPLEX1R1 r"
          using A5 seq_4_th_9 sorry
        thus "lower-boundSEQ-4K3 R inHIDDENR3 R"
          using A5 tarski_def_1 sorry
      qed
      have case2: "n <>HIDDENR2 0NUMBERSK6 implies R be bounded-aboveXXREAL-2V4 & (upper-boundSEQ-4K2 R inHIDDENR3 R & (R be bounded-belowXXREAL-2V3 & lower-boundSEQ-4K3 R inHIDDENR3 R))"
      proof(rule impI,rule conjMI,rule conjMI,rule conjMI)
        assume A6: "n <>HIDDENR2 0NUMBERSK6"
        let ?x = "the ElementSUBSET-1M1-of R"
        obtain x where 
          [ty]:"x be RealXREAL-0M1" and xDef:"x = ?x"
           sorry
        obtain X where 
          [ty]:"X be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = R \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 x}"
           sorry
        let ?u = "upper-boundSEQ-4K2 X"
        let ?m = "maxXXREAL-0K5(x,?u)"
        let ?l = "lower-boundSEQ-4K3 X"
        let ?mi = "minXXREAL-0K4(x,?l)"
        have "{SEQ-4K1 x} c=MEMBEREDR3 R"
          using A2 zfmisc_1_th_31 sorry
        then have "cardCARD-1K4 (R \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 x}) =COMPLEX1R1 cardCARD-1K4 R -XCMPLX-0K6 cardCARD-1K4 {SEQ-4K1 x}"
          using card_2_th_44 sorry
        then have A7: "cardCARD-1K4 X =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A3 card_1_th_30 sorry
        also have "... = n"
           sorry
        finally have "cardCARD-1K4 X =HIDDENR1 n"
           sorry
        then have A8: "upper-boundSEQ-4K2 X inHIDDENR3 X"
          using A1 A6 card_1_th_27 sorry
        have A9: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s)"
        proof(rule ballI,rule impI)
          obtain s where 
            [ty]:"s be RealXREAL-0M1" and sDef:"s = ?m"
             sorry
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume A10: "0NUMBERSK6 <XXREAL-0R3 r"
          show " ex s be RealXREAL-0M1 st s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
          proof(rule bexI[of _ "s"])
            have "s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
            proof-
              show "s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
              proof-
                have cases: "?m =COMPLEX1R1 x or ?m =COMPLEX1R1 ?u"
                  using xxreal_0_th_16 sorry
                have case1: "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) =COMPLEX1R1 x implies s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
                proof(rule impI,rule conjMI)
                  assume "?m =COMPLEX1R1 x"
                  thus "s inHIDDENR3 R"
                    using A2 sorry
                  show "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
                    using A10 xreal_1_th_44 sorry
                qed
                have case2: "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) =COMPLEX1R1 upper-boundSEQ-4K2 X implies s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
                proof(rule impI,rule conjMI)
                  assume "?m =COMPLEX1R1 ?u"
                  thus "s inHIDDENR3 R"
                    using A8 xboole_0_def_5 sorry
                  show "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
                    using A10 xreal_1_th_44 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "s inHIDDENR3 R & maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) -XCMPLX-0K6 r <XXREAL-0R3 s"
               sorry
          qed "sorry"
        qed "sorry"
        have A11: "lower-boundSEQ-4K3 X inHIDDENR3 X"
          using A1 A6 A7 card_1_th_27 sorry
        have A12: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r)"
        proof(rule ballI,rule impI)
          obtain s where 
            [ty]:"s be RealXREAL-0M1" and sDef:"s = ?mi"
             sorry
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume A13: "0NUMBERSK6 <XXREAL-0R3 r"
          show " ex s be RealXREAL-0M1 st s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
          proof(rule bexI[of _ "s"])
            have "s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
            proof-
              show "s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
              proof-
                have cases: "?mi =COMPLEX1R1 x or ?mi =COMPLEX1R1 ?l"
                  using xxreal_0_th_15 sorry
                have case1: "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) =COMPLEX1R1 x implies s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
                proof(rule impI,rule conjMI)
                  assume "?mi =COMPLEX1R1 x"
                  thus "s inHIDDENR3 R"
                    using A2 sorry
                  show "s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
                    using A13 xreal_1_th_29 sorry
                qed
                have case2: "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) =COMPLEX1R1 lower-boundSEQ-4K3 X implies s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
                proof(rule impI,rule conjMI)
                  assume "?mi =COMPLEX1R1 ?l"
                  thus "s inHIDDENR3 R"
                    using A11 xboole_0_def_5 sorry
                  show "s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
                    using A13 xreal_1_th_29 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "s inHIDDENR3 R & s <XXREAL-0R3 minXXREAL-0K4(x,lower-boundSEQ-4K3 X) +XCMPLX-0K2 r"
               sorry
          qed "sorry"
        qed "sorry"
        show "R be bounded-aboveXXREAL-2V4"
           sorry
        have A14: "?u <=XXREAL-0R1 ?m"
          using xxreal_0_th_25 sorry
        have A15: " for s be RealXREAL-0M1 holds s inHIDDENR3 R implies s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A16: "s inHIDDENR3 R"
          have "s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
          proof-
            show "s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
            proof-
              have cases: "s =COMPLEX1R1 x or s <>HIDDENR2 x"
                 sorry
              have case1: "s =COMPLEX1R1 x implies s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
              proof(rule impI)
                assume "s =COMPLEX1R1 x"
                thus "s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
                  using xxreal_0_th_25 sorry
              qed
              have case2: "s <>HIDDENR2 x implies s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
              proof(rule impI)
                assume "s <>HIDDENR2 x"
                then have " not s inHIDDENR3 {SEQ-4K1 x}"
                  using tarski_def_1 sorry
                then have "s inHIDDENR3 X"
                  using A16 xboole_0_def_5 sorry
                then have "s <=XXREAL-0R1 ?u"
                  using seq_4_def_1 sorry
                thus "s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
                  using A14 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "s <=XXREAL-0R1 maxXXREAL-0K5(x,upper-boundSEQ-4K2 X)"
             sorry
        qed "sorry"
        have "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
        proof-
          show "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
          proof-
            have cases: "?m =COMPLEX1R1 x or ?m =COMPLEX1R1 ?u"
              using xxreal_0_th_16 sorry
            have case1: "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) =COMPLEX1R1 x implies maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
            proof(rule impI)
              assume "?m =COMPLEX1R1 x"
              thus "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
                using A2 sorry
            qed
            have case2: "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) =COMPLEX1R1 upper-boundSEQ-4K2 X implies maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
            proof(rule impI)
              assume "?m =COMPLEX1R1 ?u"
              thus "maxXXREAL-0K5(x,upper-boundSEQ-4K2 X) inHIDDENR3 R"
                using A8 xboole_0_def_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "upper-boundSEQ-4K2 R inHIDDENR3 R"
          using A15 A9 seq_4_def_1 sorry
        show "R be bounded-belowXXREAL-2V3"
           sorry
        have A17: "?mi <=XXREAL-0R1 ?l"
          using xxreal_0_th_17 sorry
        have A18: " for s be RealXREAL-0M1 holds s inHIDDENR3 R implies minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A19: "s inHIDDENR3 R"
          have "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
          proof-
            show "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
            proof-
              have cases: "s =COMPLEX1R1 x or s <>HIDDENR2 x"
                 sorry
              have case1: "s =COMPLEX1R1 x implies minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
              proof(rule impI)
                assume "s =COMPLEX1R1 x"
                thus "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
                  using xxreal_0_th_17 sorry
              qed
              have case2: "s <>HIDDENR2 x implies minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
              proof(rule impI)
                assume "s <>HIDDENR2 x"
                then have " not s inHIDDENR3 {SEQ-4K1 x}"
                  using tarski_def_1 sorry
                then have "s inHIDDENR3 X"
                  using A19 xboole_0_def_5 sorry
                then have "?l <=XXREAL-0R1 s"
                  using seq_4_def_2 sorry
                thus "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
                  using A17 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) <=XXREAL-0R1 s"
             sorry
        qed "sorry"
        have "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
        proof-
          show "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
          proof-
            have cases: "?mi =COMPLEX1R1 x or ?mi =COMPLEX1R1 ?l"
              using xxreal_0_th_15 sorry
            have case1: "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) =COMPLEX1R1 x implies minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
            proof(rule impI)
              assume "?mi =COMPLEX1R1 x"
              thus "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
                using A2 sorry
            qed
            have case2: "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) =COMPLEX1R1 lower-boundSEQ-4K3 X implies minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
            proof(rule impI)
              assume "?mi =COMPLEX1R1 ?l"
              thus "minXXREAL-0K4(x,lower-boundSEQ-4K3 X) inHIDDENR3 R"
                using A11 xboole_0_def_5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "lower-boundSEQ-4K3 R inHIDDENR3 R"
          using A18 A12 seq_4_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
     sorry
qed "sorry"

mlemma seq_4_lm_15:
" for n be NatNAT-1M1 holds  for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 R =COMPLEX1R1 n implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
  using nat_1_sch_2 seq_4_lm_13 seq_4_lm_14 sorry

mtheorem seq_4_th_133:
" for R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds R <>HIDDENR2 {}XBOOLE-0K1 implies ((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
proof(rule ballI,rule impI)
  fix R assume [ty]: "R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  assume A1: "R <>HIDDENR2 {}XBOOLE-0K1"
  have " for Rc be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Rc <>HIDDENR2 {}XBOOLE-0K1 & cardCARD-1K4 Rc =COMPLEX1R1 cardCARD-1K4 R implies ((Rc be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 Rc inHIDDENR3 Rc) & Rc be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 Rc inHIDDENR3 Rc"
    using seq_4_lm_15 sorry
  thus "((R be bounded-aboveXXREAL-2V4 & upper-boundSEQ-4K2 R inHIDDENR3 R) & R be bounded-belowXXREAL-2V3) & lower-boundSEQ-4K3 R inHIDDENR3 R"
    using A1 sorry
qed "sorry"

mtheorem seq_4_th_134:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f iff n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
proof-
  have " for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) &  not ((n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) &  not (\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f))"
  proof(rule ballI,rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    show "\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
    proof(rule impMI ,rule impI)
      assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
        and A2: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A2 nat_1_th_11 xxreal_0_th_2 sorry
      thus "n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using A1 A2 finseq_3_th_25 sorry
    qed
    show " not ((n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) &  not (\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f))"
      using finseq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_135:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f iff (n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
proof-
  have " for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds (\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies (n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & (n inTARSKIR2 domFINSEQ-1K5 f & (n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) implies \<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    show "\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies (n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
    proof(rule impMI ,rule impI)
      assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
        and A2: "n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_11 sorry
      then have A3: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M & n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A2 nat_1_th_11 xxreal_0_th_2 sorry
      have "n <=XXREAL-0R1 n +NAT-1K1 \<two>\<^sub>M"
        using nat_1_th_11 sorry
      then have "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<two>\<^sub>M & n <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A1 A2 xxreal_0_th_2 sorry
      thus "(n inTARSKIR2 domFINSEQ-1K5 f & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f) & n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using A1 A2 A3 finseq_3_th_25 sorry
    qed
    assume A4: "n inTARSKIR2 domFINSEQ-1K5 f"
      and "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      and A5: "n +NAT-1K1 \<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
    show "\<one>\<^sub>M <=XXREAL-0R1 n & n +NAT-1K1 \<two>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A4 A5 finseq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_136:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f2 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 lenFINSEQ-1K4 f1) =XBOOLE-0R4 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of D holds  for f2 be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 f2 implies (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 lenFINSEQ-1K4 f1) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of D"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of D"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 f2"
    have A3: "lenFINSEQ-1K4 f1 <XXREAL-0R3 n +NAT-1K1 lenFINSEQ-1K4 f1"
      using A1 nat_1_th_19 sorry
    have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2) =COMPLEX1R1 lenFINSEQ-1K4 f1 +NAT-1K1 lenFINSEQ-1K4 f2"
      using finseq_1_th_22 sorry
    then have A4: "n +NAT-1K1 lenFINSEQ-1K4 f1 <=XXREAL-0R1 lenFINSEQ-1K4 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)"
      using A2 xreal_1_th_6 sorry
    have "n +NAT-1K1 lenFINSEQ-1K4 f1 >=XXREAL-0R2 n"
      using nat_1_th_11 sorry
    then have "n +NAT-1K1 lenFINSEQ-1K4 f1 >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
    then have "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 lenFINSEQ-1K4 f1) =HIDDENR1 (f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2).FUNCT-1K1 (n +NAT-1K1 lenFINSEQ-1K4 f1)"
      using A4 finseq_4_th_15 sorry
    also have "... = f2 .FUNCT-1K1 ((n +NAT-1K1 lenFINSEQ-1K4 f1)-XCMPLX-0K6 lenFINSEQ-1K4 f1)"
      using A3 A4 finseq_1_th_24 sorry
    also have "... = f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
      using A1 A2 finseq_4_th_15 sorry
    finally show "(f1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> f2)/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 lenFINSEQ-1K4 f1) =HIDDENR1 f2 /.PARTFUN1K7\<^bsub>(D)\<^esub> n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_137:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <=XXREAL-0R1 m implies v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m)"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <=XXREAL-0R1 m implies v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A1: "v be increasingVALUED-0V9"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A2: "n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v"
      and A3: "n <=XXREAL-0R1 m"
    have "v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
    proof-
      show "v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
      proof-
        have cases: "n =COMPLEX1R1 m or n <>HIDDENR2 m"
           sorry
        have case1: "n =COMPLEX1R1 m implies v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
        proof(rule impI)
          assume "n =COMPLEX1R1 m"
          thus "v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
             sorry
        qed
        have case2: "n <>HIDDENR2 m implies v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
        proof(rule impI)
          assume "n <>HIDDENR2 m"
          then have "n <XXREAL-0R3 m"
            using A3 xxreal_0_th_1 sorry
          thus "v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
            using A1 A2 seqm_3_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "v .FUNCT-1K1 n <=XXREAL-0R1 v .FUNCT-1K1 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_138:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <>HIDDENR2 m implies v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m)"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds v be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v) & n <>HIDDENR2 m implies  not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A1: "v be increasingVALUED-0V9"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A2: "n inTARSKIR2 domFINSEQ-1K5 v & m inTARSKIR2 domFINSEQ-1K5 v"
      and A3: "n <>HIDDENR2 m"
    have " not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
    proof-
      show " not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
      proof-
        have cases: "n <XXREAL-0R3 m or n >XXREAL-0R4 m"
          using A3 xxreal_0_th_1 sorry
        have case1: "n <XXREAL-0R3 m implies  not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
        proof(rule impI)
          assume "n <XXREAL-0R3 m"
          thus " not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
            using A1 A2 seqm_3_def_1 sorry
        qed
        have case2: "n >XXREAL-0R4 m implies  not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
        proof(rule impI)
          assume "n >XXREAL-0R4 m"
          thus " not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
            using A1 A2 seqm_3_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not v .FUNCT-1K1 n <>HIDDENR2 v .FUNCT-1K1 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem seq_4_th_139:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds v be increasingVALUED-0V9 & v1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> v  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n implies v1 be increasingVALUED-0V9"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds v be increasingVALUED-0V9 & v1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> v  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n implies v1 be increasingVALUED-0V9"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "v be increasingVALUED-0V9"
      and A2: "v1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> v  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n"
    have "v1 be increasingVALUED-0V9"
    proof-
      show "v1 be increasingVALUED-0V9"
      proof-
        have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 v or lenFINSEQ-1K4 v <=XXREAL-0R1 n"
           sorry
        have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 v implies v1 be increasingVALUED-0V9"
        proof(rule impI)
          assume "n <=XXREAL-0R1 lenFINSEQ-1K4 v"
          then have "SegFINSEQ-1K2 n c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 v)"
            using finseq_1_th_5 sorry
          then have A3: "SegFINSEQ-1K2 n c=MEMBEREDR6 domFINSEQ-1K5 v"
            using finseq_1_def_3 sorry
          then have "SegFINSEQ-1K2 n =MEMBEREDR12 domFINSEQ-1K5 v /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
            using xboole_1_th_28 sorry
          then have A4: "domFINSEQ-1K5 v1 =MEMBEREDR12 SegFINSEQ-1K2 n"
            using A2 relat_1_th_61 sorry
          have " for m be NatNAT-1M1 holds  for k be NatNAT-1M1 holds (m inTARSKIR2 domFINSEQ-1K5 v1 & k inTARSKIR2 domFINSEQ-1K5 v1) & m <XXREAL-0R3 k implies v1 .FUNCT-1K1 m <XXREAL-0R3 v1 .FUNCT-1K1 k"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A5: "m inTARSKIR2 domFINSEQ-1K5 v1 & k inTARSKIR2 domFINSEQ-1K5 v1"
              and A6: "m <XXREAL-0R3 k"
            let ?r = "v1 .FUNCT-1K1 m"
            let ?s = "v1 .FUNCT-1K1 k"
            have "?r =COMPLEX1R1 v .FUNCT-1K1 m & ?s =COMPLEX1R1 v .FUNCT-1K1 k"
              using A2 A5 funct_1_th_47 sorry
            thus "v1 .FUNCT-1K1 m <XXREAL-0R3 v1 .FUNCT-1K1 k"
              using A1 A3 A4 A5 A6 seqm_3_def_1 sorry
          qed "sorry"
          thus "v1 be increasingVALUED-0V9"
            using seqm_3_def_1 sorry
        qed
        have case2: "lenFINSEQ-1K4 v <=XXREAL-0R1 n implies v1 be increasingVALUED-0V9"
        proof(rule impI)
          assume "lenFINSEQ-1K4 v <=XXREAL-0R1 n"
          thus "v1 be increasingVALUED-0V9"
            using A1 A2 finseq_2_th_20 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "v1 be increasingVALUED-0V9"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_16:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 0NUMBERSK6 implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)"
proof-
  have " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 0NUMBERSK6 implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & (lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v) & v1 be increasingVALUED-0V9))"
  proof(rule ballI,rule impI)
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume "cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 0NUMBERSK6"
    then have A1: "rngRVSUM-1K1 v =MEMBEREDR9 {}XBOOLE-0K1"
       sorry
    obtain v1 where 
      [ty]:"v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and v1Def:"v1 = v"
       sorry
    show " ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & (lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v) & v1 be increasingVALUED-0V9)"
    proof(rule bexI[of _ "v1"],rule conjMI,rule conjMI)
      show "rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v"
         sorry
      show "lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
        using A1 relat_1_th_41 sorry
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (n inTARSKIR2 domFINSEQ-1K5 v1 & m inTARSKIR2 domFINSEQ-1K5 v1) & n <XXREAL-0R3 m implies v1 .FUNCT-1K1 n <XXREAL-0R3 v1 .FUNCT-1K1 m"
        using A1 relat_1_th_38 relat_1_th_41 sorry
      thus "v1 be increasingVALUED-0V9"
        using seqm_3_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_17:
" for n be NatNAT-1M1 holds ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)) implies ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9))"
proof-
  have " for n be NatNAT-1M1 holds ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)) implies ( for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies  not ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  not ((rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: " for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)"
    fix v assume [ty]: "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A2: "cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
    have " ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 v1 =HIDDENR1 rngRVSUM-1K1 v & (lenFINSEQ-1K4 v1 =HIDDENR1 cardCARD-1K4 (rngRVSUM-1K1 v) & v1 be increasingVALUED-0V9)"
    proof-
      obtain R where 
        [ty]:"R be finiteFINSET-1V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2" and RDef:"R = rngRVSUM-1K1 v"
         sorry
      let ?u = "upper-boundSEQ-4K2 R"
      let ?X = "R \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 ?u}"
      let ?f = "?X  |`RELSET-1K6\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> v"
      have "SeqFINSEQ-1K16 ?f =FUNCT-1R1 ?f *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f) & rngRVSUM-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f)) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f"
        using finseq_1_th_50 sorry
      then have A3: "rngFUNCT-1K2 (SeqFINSEQ-1K16 ?f) =HIDDENR1 rngRVSUM-1K1 ?f"
        using relat_1_th_28 sorry
      also have "... = ?X"
        using relat_1_th_89 xboole_1_th_36 sorry
      finally have "rngFUNCT-1K2 (SeqFINSEQ-1K16 ?f) =HIDDENR1 ?X"
         sorry
      then obtain f1 where 
        [ty]:"f1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and f1Def:"f1 = SeqFINSEQ-1K16 ?f"
        using finseq_1_def_4 sorry
      obtain X where 
        [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
         sorry
      have "upper-boundSEQ-4K2 R inHIDDENR3 R"
        using A2 seq_4_th_133 card_1_th_27 sorry
      then have A4: "{SEQ-4K1 ?u} c=MEMBEREDR3 R"
        using zfmisc_1_th_31 sorry
      then have A5: "cardCARD-1K4 X =COMPLEX1R1 cardCARD-1K4 R -XCMPLX-0K6 cardCARD-1K4 {SEQ-4K1 ?u}"
        using card_2_th_44 sorry
      have A6: "cardCARD-1K4 {SEQ-4K1 ?u} =COMPLEX1R1 \<one>\<^sub>M"
        using card_1_th_30 sorry
      then obtain v2 where
        [ty]:"v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and 
        A7: "rngRVSUM-1K1 v2 =MEMBEREDR9 rngRVSUM-1K1 f1"and A8: "lenFINSEQ-1K4 v2 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 f1)"and A9: "v2 be increasingVALUED-0V9"
        using A1 A2 A3 A5 sorry
      obtain uu where 
        [ty]:"uu be ElementSUBSET-1M1-of REALNUMBERSK2" and uuDef:"uu = ?u"
        using xreal_0_def_1 sorry
      obtain v1 where 
        [ty]:"v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and v1Def:"v1 = v2 ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> uu*>)"
         sorry
      show " ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 v1 =HIDDENR1 rngRVSUM-1K1 v & (lenFINSEQ-1K4 v1 =HIDDENR1 cardCARD-1K4 (rngRVSUM-1K1 v) & v1 be increasingVALUED-0V9)"
      proof(rule bexI[of _ "v1"],rule conjMI,rule conjMI)
        have "rngRVSUM-1K1 v1 =HIDDENR1 X \\/XBOOLE-0K2 rngRVSUM-1K1 (<*FINSEQ-1K10 upper-boundSEQ-4K2 R*>)"
          using A3 A7 finseq_1_th_31 sorry
        also have "... = (rngRVSUM-1K1 v \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 R })\\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 R }"
          using finseq_1_th_39 sorry
        also have "... = rngRVSUM-1K1 v \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 R }"
          using xboole_1_th_39 sorry
        also have "... = rngRVSUM-1K1 v"
          using A4 xboole_1_th_12 sorry
        finally show "rngRVSUM-1K1 v1 =HIDDENR1 rngRVSUM-1K1 v"
           sorry
        have A10: "lenFINSEQ-1K4 v1 =HIDDENR1 n +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 upper-boundSEQ-4K2 R*>)"
          using A2 A3 A5 A6 A8 finseq_1_th_22 sorry
        also have "... = cardCARD-1K4 (rngRVSUM-1K1 v)"
          using A2 finseq_1_th_39 sorry
        finally show "lenFINSEQ-1K4 v1 =HIDDENR1 cardCARD-1K4 (rngRVSUM-1K1 v)"
           sorry
        have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 v1 & (m inTARSKIR2 domFINSEQ-1K5 v1 & k <XXREAL-0R3 m) implies v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A11: "k inTARSKIR2 domFINSEQ-1K5 v1"
            and A12: "m inTARSKIR2 domFINSEQ-1K5 v1"
            and A13: "k <XXREAL-0R3 m"
          have A14: "\<one>\<^sub>M <=XXREAL-0R1 m"
            using A12 finseq_3_th_25 sorry
          have A15: "m <=XXREAL-0R1 lenFINSEQ-1K4 v1"
            using A12 finseq_3_th_25 sorry
          let ?r = "v1 .FUNCT-1K1 k"
          let ?s = "v1 .FUNCT-1K1 m"
          have A16: "\<one>\<^sub>M <=XXREAL-0R1 k"
            using A11 finseq_3_th_25 sorry
          have A17: "k <=XXREAL-0R1 lenFINSEQ-1K4 v1"
            using A11 finseq_3_th_25 sorry
          have "v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
          proof-
            show "v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
            proof-
              have cases: "m =COMPLEX1R1 lenFINSEQ-1K4 v1 or m <>HIDDENR2 lenFINSEQ-1K4 v1"
                 sorry
              have case1: "m =COMPLEX1R1 lenFINSEQ-1K4 v1 implies v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
              proof(rule impI)
                assume A18: "m =COMPLEX1R1 lenFINSEQ-1K4 v1"
                have "k <XXREAL-0R3 lenFINSEQ-1K4 v1"
                  using A13 A15 xxreal_0_th_2 sorry
                then have "k <=XXREAL-0R1 lenFINSEQ-1K4 v2"
                  using A2 A3 A5 A6 A8 A10 nat_1_th_13 sorry
                then have A19: "k inTARSKIR2 domFINSEQ-1K5 v2"
                  using A16 finseq_3_th_25 sorry
                then have "?r =COMPLEX1R1 v2 .FUNCT-1K1 k"
                  using finseq_1_def_7 sorry
                then have A20: "?r inTARSKIR2 rngRVSUM-1K1 v2"
                  using A19 funct_1_def_3 sorry
                then have "?r inTARSKIR2 R"
                  using A3 A7 xboole_0_def_5 sorry
                then have A21: "?r <=XXREAL-0R1 ?u"
                  using seq_4_def_1 sorry
                have " not ?r inTARSKIR2 {SEQ-4K1 ?u}"
                  using A3 A7 A20 xboole_0_def_5 sorry
                then have A22: "?r <>HIDDENR2 ?u"
                  using tarski_def_1 sorry
                have "?s =COMPLEX1R1 ?u"
                  using A2 A3 A5 A6 A8 A10 A18 finseq_1_th_42 sorry
                thus "v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
                  using A21 A22 xxreal_0_th_1 sorry
              qed
              have case2: "m <>HIDDENR2 lenFINSEQ-1K4 v1 implies v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
              proof(rule impI)
                assume "m <>HIDDENR2 lenFINSEQ-1K4 v1"
                then have "m <XXREAL-0R3 lenFINSEQ-1K4 v1"
                  using A15 xxreal_0_th_1 sorry
                then have "m <=XXREAL-0R1 lenFINSEQ-1K4 v2"
                  using A2 A3 A5 A6 A8 A10 nat_1_th_13 sorry
                then have A23: "m inTARSKIR2 domFINSEQ-1K5 v2"
                  using A14 finseq_3_th_25 sorry
                then have A24: "?s =COMPLEX1R1 v2 .FUNCT-1K1 m"
                  using finseq_1_def_7 sorry
                have "k <XXREAL-0R3 lenFINSEQ-1K4 v1"
                  using A13 A17 A15 xxreal_0_th_1 sorry
                then have "k <=XXREAL-0R1 lenFINSEQ-1K4 v2"
                  using A2 A3 A5 A6 A8 A10 nat_1_th_13 sorry
                then have A25: "k inTARSKIR2 domFINSEQ-1K5 v2"
                  using A16 finseq_3_th_25 sorry
                then have "?r =COMPLEX1R1 v2 .FUNCT-1K1 k"
                  using finseq_1_def_7 sorry
                thus "v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
                  using A9 A13 A25 A23 A24 seqm_3_def_1 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "v1 .FUNCT-1K1 k <XXREAL-0R3 v1 .FUNCT-1K1 m"
             sorry
        qed "sorry"
        thus "v1 be increasingVALUED-0V9"
          using seqm_3_def_1 sorry
      qed "sorry"
    qed
    thus " not ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  not ((rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_18:
" for n be NatNAT-1M1 holds  for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds cardCARD-1K4 (rngRVSUM-1K1 v) =COMPLEX1R1 n implies ( ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9)"
  using nat_1_sch_2 seq_4_lm_16 seq_4_lm_17 sorry

mtheorem seq_4_th_140:
" for v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  ex v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & v1 be increasingVALUED-0V9"
  using seq_4_lm_18 sorry

mlemma seq_4_lm_19:
" for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 0NUMBERSK6 & lenFINSEQ-1K4 v2 =COMPLEX1R1 0NUMBERSK6) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
proof-
  have " for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 v1 =COMPLEX1R1 0NUMBERSK6 & (lenFINSEQ-1K4 v2 =COMPLEX1R1 0NUMBERSK6 & (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2 & (v1 be increasingVALUED-0V9 & v2 be increasingVALUED-0V9))) implies v1 =FINSEQ-1R1 v2"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A1: "lenFINSEQ-1K4 v1 =COMPLEX1R1 0NUMBERSK6"
      and A2: "lenFINSEQ-1K4 v2 =COMPLEX1R1 0NUMBERSK6"
      and "rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2"
      and "v1 be increasingVALUED-0V9"
      and "v2 be increasingVALUED-0V9"
    have "v1 =FINSEQ-1R1 {}XBOOLE-0K1"
      using A1 sorry
    thus "v1 =FINSEQ-1R1 v2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_20:
" for n be NatNAT-1M1 holds ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2) implies ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 v2 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2)"
proof-
  have " for n be NatNAT-1M1 holds ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2) implies ( for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 v1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & (lenFINSEQ-1K4 v2 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & (rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2 & (v1 be increasingVALUED-0V9 & v2 be increasingVALUED-0V9))) implies v1 =FINSEQ-1R1 v2)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: " for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
    fix v1 assume [ty]: "v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    fix v2 assume [ty]: "v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A2: "lenFINSEQ-1K4 v1 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      and A3: "lenFINSEQ-1K4 v2 =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      and A4: "rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2"
      and A5: "v1 be increasingVALUED-0V9"
      and A6: "v2 be increasingVALUED-0V9"
    obtain X where 
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = rngRVSUM-1K1 v1"
       sorry
    let ?u = "upper-boundSEQ-4K2 X"
    have "X <>HIDDENR2 {}XBOOLE-0K1"
      using A2 card_1_th_27 relat_1_th_41 sorry
    then have A7: "upper-boundSEQ-4K2 X inHIDDENR3 X"
      using seq_4_th_133 sorry
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A8: "m inTARSKIR2 domFINSEQ-1K5 v2"and A9: "v2 .FUNCT-1K1 m =COMPLEX1R1 ?u"
      using A4 finseq_2_th_10 sorry
    have 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A10: "m <=XXREAL-0R1 lenFINSEQ-1K4 v2"
      using A8 finseq_3_th_25 sorry
    have A11: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have "SegFINSEQ-1K2 n c=MEMBEREDR6 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_5 sorry
    then have A12: "SegFINSEQ-1K2 n =MEMBEREDR12 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 n"
      using xboole_1_th_28 sorry
    have "domFINSEQ-1K5 v2 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 v2)"
      using finseq_1_def_3 sorry
    then have A13: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (v2  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n) =MEMBEREDR12 SegFINSEQ-1K2 n"
      using A3 A12 relat_1_th_61 sorry
    have "domFINSEQ-1K5 v1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 v1)"
      using finseq_1_def_3 sorry
    then have A14: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (v1  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n) =MEMBEREDR12 SegFINSEQ-1K2 n"
      using A2 A12 relat_1_th_61 sorry
    then obtain f1 f2 where 
      [ty]:"f1 be FinSequenceFINSEQ-1M1" and f1Def:"f1 = v1  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n" and
      [ty]:"f2 be FinSequenceFINSEQ-1M1" and f2Def:"f2 = v2  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> SegFINSEQ-1K2 n"
      using A13 finseq_1_def_2 sorry
    have "rngFUNCT-1K2 f2 c=TARSKIR1 rngRVSUM-1K1 v2"
      using relat_1_th_70 sorry
    then have A15: "rngFUNCT-1K2 f2 c=TARSKIR1 REALNUMBERSK2"
      using xboole_1_th_1 sorry
    have "rngFUNCT-1K2 f1 c=TARSKIR1 rngRVSUM-1K1 v1"
      using relat_1_th_70 sorry
    then have "rngFUNCT-1K2 f1 c=TARSKIR1 REALNUMBERSK2"
      using xboole_1_th_1 sorry
    then have 
      [ty]:"f1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and
      [ty]:"f2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using A15 finseq_1_def_4 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A16: "k inTARSKIR2 domFINSEQ-1K5 v1"and A17: "v1 .FUNCT-1K1 k =COMPLEX1R1 ?u"
      using A7 finseq_2_th_10 sorry
    have 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A18: "k <=XXREAL-0R1 lenFINSEQ-1K4 v1"
      using A16 finseq_3_th_25 sorry
    have A19: "\<one>\<^sub>M <=XXREAL-0R1 k"
      using A16 finseq_3_th_25 sorry
    have A20: "k <>HIDDENR2 lenFINSEQ-1K4 v1 implies  False "
    proof(rule impI)
      assume "k <>HIDDENR2 lenFINSEQ-1K4 v1"
      then have "k <XXREAL-0R3 lenFINSEQ-1K4 v1"
        using A18 xxreal_0_th_1 sorry
      then have A21: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 v1"
        using nat_1_th_13 sorry
      obtain s where 
        [ty]:"s be RealXREAL-0M1" and sDef:"s = v1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A22: "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
        using A19 nat_1_th_13 sorry
      then have A23: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v1"
        using A21 finseq_3_th_25 sorry
      then have "v1 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRVSUM-1K1 v1"
        using funct_1_def_3 sorry
      then have "s <=XXREAL-0R1 ?u"
        using seq_4_def_1 sorry
      thus " False "
        using A5 A16 A17 A23 A22 seqm_3_def_1 sorry
    qed
    have A24: "\<one>\<^sub>M <=XXREAL-0R1 m"
      using A8 finseq_3_th_25 sorry
    have A25: "m <>HIDDENR2 lenFINSEQ-1K4 v2 implies  False "
    proof(rule impI)
      assume "m <>HIDDENR2 lenFINSEQ-1K4 v2"
      then have "m <XXREAL-0R3 lenFINSEQ-1K4 v2"
        using A10 xxreal_0_th_1 sorry
      then have A26: "m +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 v2"
        using nat_1_th_13 sorry
      obtain s where 
        [ty]:"s be RealXREAL-0M1" and sDef:"s = v2 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
         sorry
      have A27: "m <XXREAL-0R3 m +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      have "\<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
        using A24 nat_1_th_13 sorry
      then have A28: "m +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 v2"
        using A26 finseq_3_th_25 sorry
      then have "v2 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRVSUM-1K1 v2"
        using funct_1_def_3 sorry
      then have "s <=XXREAL-0R1 ?u"
        using A4 seq_4_def_1 sorry
      thus " False "
        using A6 A8 A9 A28 A27 seqm_3_def_1 sorry
    qed
    have "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have A29: "lenFINSEQ-1K4 f1 =COMPLEX1R1 n"
      using A14 finseq_1_def_3 sorry
    then have A30: "domFINSEQ-1K5 f1 c=MEMBEREDR6 domFINSEQ-1K5 v1"
      using A2 A11 finseq_3_th_30 sorry
    have A31: "rngRVSUM-1K1 f1 =MEMBEREDR9 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 ?u}"
    proof-
      have "rngRVSUM-1K1 f1 =MEMBEREDR9 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
      proof-
        have "rngRVSUM-1K1 f1 c=MEMBEREDR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } & rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } c=TARSKIR1 rngRVSUM-1K1 f1"
        proof(rule conjMI)
          show "rngRVSUM-1K1 f1 c=MEMBEREDR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 f1 implies x inHIDDENR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngRVSUM-1K1 f1"
              then obtain i where
                [ty]:"i be NatNAT-1M1" and 
                A32: "i inTARSKIR2 domFINSEQ-1K5 f1"and A33: "f1 .FUNCT-1K1 i =HIDDENR1 x"
                using finseq_2_th_10 sorry
              have A34: "x =HIDDENR1 v1 .FUNCT-1K1 i"
                using A32 A33 funct_1_th_47 sorry
              have A35: "v1 .FUNCT-1K1 i inTARSKIR2 rngRVSUM-1K1 v1"
                using A30 A32 funct_1_def_3 sorry
              have "i <=XXREAL-0R1 n"
                using A14 A32 finseq_1_th_1 sorry
              then have "i <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              then have "x <>HIDDENR2 ?u"
                using A2 A5 A16 A17 A20 A30 A32 A34 seq_4_th_138 sorry
              then have " not x inHIDDENR3 {SEQ-4K1 ?u}"
                using tarski_def_1 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
                using A34 A35 xboole_0_def_5 sorry
            qed "sorry"
            thus "rngRVSUM-1K1 f1 c=MEMBEREDR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } implies x inHIDDENR3 rngRVSUM-1K1 f1"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A36: "x inHIDDENR3 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 ?u}"
            then have "x inHIDDENR3 rngRVSUM-1K1 v1"
              using xboole_0_def_5 sorry
            then obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A37: "i inTARSKIR2 domFINSEQ-1K5 v1"and A38: "v1 .FUNCT-1K1 i =HIDDENR1 x"
              using finseq_2_th_10 sorry
            have A39: "i <=XXREAL-0R1 lenFINSEQ-1K4 v1"
              using A37 finseq_3_th_25 sorry
            have " not x inHIDDENR3 {SEQ-4K1 ?u}"
              using A36 xboole_0_def_5 sorry
            then have "i <>HIDDENR2 lenFINSEQ-1K4 v1"
              using A17 A20 A38 tarski_def_1 sorry
            then have "i <XXREAL-0R3 lenFINSEQ-1K4 v1"
              using A39 xxreal_0_th_1 sorry
            then have A40: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1"
              using A2 A29 nat_1_th_13 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 i"
              using A37 finseq_3_th_25 sorry
            then have A41: "i inTARSKIR2 domFINSEQ-1K5 f1"
              using A40 finseq_3_th_25 sorry
            then have "f1 .FUNCT-1K1 i inTARSKIR2 rngRVSUM-1K1 f1"
              using funct_1_def_3 sorry
            thus "x inHIDDENR3 rngRVSUM-1K1 f1"
              using A38 A41 funct_1_th_47 sorry
          qed "sorry"
          thus "rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } c=TARSKIR1 rngRVSUM-1K1 f1"
            using tarski_def_3 sorry
        qed
        thus "rngRVSUM-1K1 f1 =MEMBEREDR9 rngRVSUM-1K1 v1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A42: "domFINSEQ-1K5 v1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 v1)"
      using finseq_1_def_3 sorry
    have A43: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 v1 implies (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A44: "i inTARSKIR2 domFINSEQ-1K5 v1"
      then have A45: "\<one>\<^sub>M <=XXREAL-0R1 i"
        using A42 finseq_1_th_1 sorry
      have A46: "i <=XXREAL-0R1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
        using A2 A29 A42 A44 finseq_1_th_1 sorry
      have "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
      proof-
        show "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
        proof-
          have cases: "i =COMPLEX1R1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M or i <>HIDDENR2 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
             sorry
          have case1: "i =COMPLEX1R1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M implies (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
          proof(rule impI)
            assume "i =COMPLEX1R1 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
            thus "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
              using A2 A17 A20 A29 finseq_1_th_42 sorry
          qed
          have case2: "i <>HIDDENR2 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M implies (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 v1 .FUNCT-1K1 i"
          proof(rule impI)
            assume "i <>HIDDENR2 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
            then have "i <XXREAL-0R3 lenFINSEQ-1K4 f1 +NAT-1K1 \<one>\<^sub>M"
              using A46 xxreal_0_th_1 sorry
            then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f1"
              using nat_1_th_13 sorry
            then have A47: "i inTARSKIR2 domFINSEQ-1K5 f1"
              using A14 A29 A45 sorry
            then have "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 f1 .FUNCT-1K1 i"
              using finseq_1_def_7 sorry
            also have "... = v1 .FUNCT-1K1 i"
              using A47 funct_1_th_47 sorry
            finally show "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 v1 .FUNCT-1K1 i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v1 .FUNCT-1K1 i"
         sorry
    qed "sorry"
    have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 ?u*>)) =HIDDENR1 n +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 ?u*>)"
      using A29 finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 v1"
      using A2 finseq_1_th_39 sorry
    finally have "lenFINSEQ-1K4 (f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 ?u*>)) =HIDDENR1 lenFINSEQ-1K4 v1"
       sorry
    then have A48: "v1 =FINSEQ-1R1 f1 ^FINSEQ-1K8 (<*FINSEQ-1K10 ?u*>)"
      using A43 finseq_2_th_9 sorry
    have "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have A49: "lenFINSEQ-1K4 f2 =COMPLEX1R1 n"
      using A13 finseq_1_def_3 sorry
    then have A50: "lenFINSEQ-1K4 (f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 ?u*>)) =HIDDENR1 n +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K10 ?u*>)"
      using finseq_1_th_22 sorry
    also have "... = lenFINSEQ-1K4 v2"
      using A3 finseq_1_th_39 sorry
    finally have "lenFINSEQ-1K4 (f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 ?u*>)) =HIDDENR1 lenFINSEQ-1K4 v2"
       sorry
    have A51: "domFINSEQ-1K5 f2 c=MEMBEREDR6 domFINSEQ-1K5 v2"
      using A3 A11 A49 finseq_3_th_30 sorry
    have A52: "rngRVSUM-1K1 f2 =MEMBEREDR9 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 ?u}"
    proof-
      have "rngRVSUM-1K1 f2 =MEMBEREDR9 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
      proof-
        have "rngRVSUM-1K1 f2 c=MEMBEREDR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } & rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } c=TARSKIR1 rngRVSUM-1K1 f2"
        proof(rule conjMI)
          show "rngRVSUM-1K1 f2 c=MEMBEREDR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 f2 implies x inHIDDENR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngRVSUM-1K1 f2"
              then obtain i where
                [ty]:"i be NatNAT-1M1" and 
                A53: "i inTARSKIR2 domFINSEQ-1K5 f2"and A54: "f2 .FUNCT-1K1 i =HIDDENR1 x"
                using finseq_2_th_10 sorry
              have A55: "x =HIDDENR1 v2 .FUNCT-1K1 i"
                using A53 A54 funct_1_th_47 sorry
              have A56: "v2 .FUNCT-1K1 i inTARSKIR2 rngRVSUM-1K1 v2"
                using A51 A53 funct_1_def_3 sorry
              have "i <=XXREAL-0R1 n"
                using A13 A53 finseq_1_th_1 sorry
              then have "i <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              then have "x <>HIDDENR2 ?u"
                using A3 A6 A8 A9 A25 A51 A53 A55 seq_4_th_138 sorry
              then have " not x inHIDDENR3 {SEQ-4K1 ?u}"
                using tarski_def_1 sorry
              thus "x inHIDDENR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
                using A55 A56 xboole_0_def_5 sorry
            qed "sorry"
            thus "rngRVSUM-1K1 f2 c=MEMBEREDR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
              using tarski_def_3 sorry
          qed
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } implies x inHIDDENR3 rngRVSUM-1K1 f2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A57: "x inHIDDENR3 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 ?u}"
            then have "x inHIDDENR3 rngRVSUM-1K1 v2"
              using xboole_0_def_5 sorry
            then obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A58: "i inTARSKIR2 domFINSEQ-1K5 v2"and A59: "v2 .FUNCT-1K1 i =HIDDENR1 x"
              using finseq_2_th_10 sorry
            have A60: "i <=XXREAL-0R1 lenFINSEQ-1K4 v2"
              using A58 finseq_3_th_25 sorry
            have " not x inHIDDENR3 {SEQ-4K1 ?u}"
              using A57 xboole_0_def_5 sorry
            then have "i <>HIDDENR2 lenFINSEQ-1K4 v2"
              using A9 A25 A59 tarski_def_1 sorry
            then have "i <XXREAL-0R3 lenFINSEQ-1K4 v2"
              using A60 xxreal_0_th_1 sorry
            then have A61: "i <=XXREAL-0R1 lenFINSEQ-1K4 f2"
              using A3 A49 nat_1_th_13 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 i"
              using A58 finseq_3_th_25 sorry
            then have A62: "i inTARSKIR2 domFINSEQ-1K5 f2"
              using A61 finseq_3_th_25 sorry
            then have "f2 .FUNCT-1K1 i inTARSKIR2 rngRVSUM-1K1 f2"
              using funct_1_def_3 sorry
            thus "x inHIDDENR3 rngRVSUM-1K1 f2"
              using A59 A62 funct_1_th_47 sorry
          qed "sorry"
          thus "rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X } c=TARSKIR1 rngRVSUM-1K1 f2"
            using tarski_def_3 sorry
        qed
        thus "rngRVSUM-1K1 f2 =MEMBEREDR9 rngRVSUM-1K1 v2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 upper-boundSEQ-4K2 X }"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A63: "domFINSEQ-1K5 v2 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 v2)"
      using finseq_1_def_3 sorry
    have A64: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 v2 implies (f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A65: "i inTARSKIR2 domFINSEQ-1K5 v2"
      then have A66: "\<one>\<^sub>M <=XXREAL-0R1 i"
        using A63 finseq_1_th_1 sorry
      have A67: "i <=XXREAL-0R1 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M"
        using A3 A49 A63 A65 finseq_1_th_1 sorry
      have "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
      proof-
        show "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
        proof-
          have cases: "i =COMPLEX1R1 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M or i <>HIDDENR2 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M"
             sorry
          have case1: "i =COMPLEX1R1 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M implies (f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
          proof(rule impI)
            assume "i =COMPLEX1R1 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M"
            thus "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
              using A3 A9 A25 A49 finseq_1_th_42 sorry
          qed
          have case2: "i <>HIDDENR2 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M implies (f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 v2 .FUNCT-1K1 i"
          proof(rule impI)
            assume "i <>HIDDENR2 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M"
            then have "i <XXREAL-0R3 lenFINSEQ-1K4 f2 +NAT-1K1 \<one>\<^sub>M"
              using A67 xxreal_0_th_1 sorry
            then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f2"
              using nat_1_th_13 sorry
            then have A68: "i inTARSKIR2 domFINSEQ-1K5 f2"
              using A13 A49 A66 sorry
            then have "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 f2 .FUNCT-1K1 i"
              using finseq_1_def_7 sorry
            also have "... = v2 .FUNCT-1K1 i"
              using A68 funct_1_th_47 sorry
            finally show "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =HIDDENR1 v2 .FUNCT-1K1 i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(f2 ^FINSEQ-1K8 (<*FINSEQ-1K10 upper-boundSEQ-4K2 X*>)).FUNCT-1K1 i =COMPLEX1R1 v2 .FUNCT-1K1 i"
         sorry
    qed "sorry"
    have "f1 be increasingVALUED-0V9 & f2 be increasingVALUED-0V9"
      using A5 A6 seq_4_th_139 sorry
    then have "f1 =FINSEQ-1R1 f2"
      using A1 A4 A29 A49 A31 A52 sorry
    thus "v1 =FINSEQ-1R1 v2"
      using A48 A50 A64 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma seq_4_lm_21:
" for n be NatNAT-1M1 holds  for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (((lenFINSEQ-1K4 v1 =COMPLEX1R1 n & lenFINSEQ-1K4 v2 =COMPLEX1R1 n) & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
  using nat_1_sch_2 seq_4_lm_19 seq_4_lm_20 sorry

mtheorem seq_4_th_141:
" for v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for v2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds ((lenFINSEQ-1K4 v1 =COMPLEX1R1 lenFINSEQ-1K4 v2 & rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v2) & v1 be increasingVALUED-0V9) & v2 be increasingVALUED-0V9 implies v1 =FINSEQ-1R1 v2"
  using seq_4_lm_21 sorry

mdef seq_4_def_21 ("IncrSEQ-4K28  _ " [228]228 ) where
  mlet "v be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"func IncrSEQ-4K28 v \<rightarrow> increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. rngRVSUM-1K1 it =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
proof-
  (*existence*)
    show " ex it be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 it =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
    proof-
      have " ex tVar83 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 tVar83 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 tVar83 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
      proof-
        obtain v1 where
          [ty]:"v1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and 
          A1: "rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"and A2: "v1 be increasingVALUED-0V9"
          using seq_4_lm_18 sorry
        have 
          [ty]:"v1 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
          using A2 sorry
        show " ex tVar83 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st rngRVSUM-1K1 tVar83 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 tVar83 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
        proof(rule bexI[of _ "v1"])
          show "rngRVSUM-1K1 v1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 v1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be increasingVALUED-0V9\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (rngRVSUM-1K1 it1 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it1 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) & (rngRVSUM-1K1 it2 =MEMBEREDR9 rngRVSUM-1K1 v & lenFINSEQ-1K4 it2 =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)) implies it1 =HIDDENR1 it2"
      using seq_4_lm_21 sorry
qed "sorry"

mtheorem seq_4_cl_7:
  mlet "v be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"cluster IncrSEQ-4K28 v as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "IncrSEQ-4K28 v be  non emptyXBOOLE-0V1"
  proof-
    have "IncrSEQ-4K28 v be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      have A1: "lenFINSEQ-1K4 (IncrSEQ-4K28 v) =COMPLEX1R1 cardCARD-1K4 (rngRVSUM-1K1 v)"
        using seq_4_def_21 sorry
      assume "IncrSEQ-4K28 v be emptyXBOOLE-0V1"
      then have "rngRVSUM-1K1 v =MEMBEREDR9 {}XBOOLE-0K1"
        using A1 sorry
      thus " False "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_cl_8:
"cluster  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3"
  proof-
    have " ex tVar84 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar84 be  non emptyXBOOLE-0V1 & (tVar84 be bounded-aboveXXREAL-2V4 & tVar84 be bounded-belowXXREAL-2V3)"
    proof-
      obtain A where 
        [ty]:"A be SubsetSUBSET-1M2-of REALNUMBERSK2" and ADef:"A = {SEQ-4K1 0NUMBERSK6 }"
         sorry
      show " ex tVar84 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar84 be  non emptyXBOOLE-0V1 & (tVar84 be bounded-aboveXXREAL-2V4 & tVar84 be bounded-belowXXREAL-2V3)"
      proof(rule bexI[of _ "A"],rule conjMI,rule conjMI)
        show "A be  non emptyXBOOLE-0V1"
           sorry
        show "A be bounded-aboveXXREAL-2V4"
           sorry
        have " for t be ExtRealXXREAL-0M1 holds t inHIDDENR3 A implies 0NUMBERSK6 <=XXREAL-0R1 t"
        proof(rule ballI,rule impI)
          fix t assume [ty]: "t be ExtRealXXREAL-0M1"
          assume "t inHIDDENR3 A"
          thus "0NUMBERSK6 <=XXREAL-0R1 t"
             sorry
        qed "sorry"
        then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_def_2 sorry
        thus "A be bounded-belowXXREAL-2V3"
          using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem seq_4_th_142:
" for A be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for B be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds lower-boundSEQ-4K3 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>bounded-belowXXREAL-2V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  let ?r = "minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
  have A1: "?r <=XXREAL-0R1 lower-boundSEQ-4K3 B"
    using xxreal_0_th_17 sorry
  have A2: " for r1 be RealXREAL-0M1 holds ( for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t >=XXREAL-0R2 r1) implies ?r >=XXREAL-0R2 r1"
  proof-
    have " for r1 be RealXREAL-0M1 holds ( for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t >=XXREAL-0R2 r1) implies minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B) >=XXREAL-0R2 r1"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      assume A3: " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t >=XXREAL-0R2 r1"
      have " for t be RealXREAL-0M1 holds t inHIDDENR3 B implies t >=XXREAL-0R2 r1"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be RealXREAL-0M1"
        assume "t inHIDDENR3 B"
        then have "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
          using xboole_0_def_3 sorry
        thus "t >=XXREAL-0R2 r1"
          using A3 sorry
      qed "sorry"
      then have A4: "lower-boundSEQ-4K3 B >=XXREAL-0R2 r1"
        using seq_4_th_43 sorry
      have " for t be RealXREAL-0M1 holds t inHIDDENR3 A implies t >=XXREAL-0R2 r1"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be RealXREAL-0M1"
        assume "t inHIDDENR3 A"
        then have "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
          using xboole_0_def_3 sorry
        thus "t >=XXREAL-0R2 r1"
          using A3 sorry
      qed "sorry"
      then have "lower-boundSEQ-4K3 A >=XXREAL-0R2 r1"
        using seq_4_th_43 sorry
      thus "minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B) >=XXREAL-0R2 r1"
        using A4 xxreal_0_th_20 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A5: "?r <=XXREAL-0R1 lower-boundSEQ-4K3 A"
    using xxreal_0_th_17 sorry
  have " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t >=XXREAL-0R2 ?r"
  proof-
    have " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t >=XXREAL-0R2 minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be RealXREAL-0M1"
      assume "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
      then have "t inHIDDENR3 A or t inHIDDENR3 B"
        using xboole_0_def_3 sorry
      then have "lower-boundSEQ-4K3 A <=XXREAL-0R1 t or lower-boundSEQ-4K3 B <=XXREAL-0R1 t"
        using seq_4_def_2 sorry
      thus "t >=XXREAL-0R2 minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
        using A5 A1 xxreal_0_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "lower-boundSEQ-4K3 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 minXXREAL-0K4(lower-boundSEQ-4K3 A,lower-boundSEQ-4K3 B)"
    using A2 seq_4_th_44 sorry
qed "sorry"

mtheorem seq_4_th_143:
" for A be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for B be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds upper-boundSEQ-4K2 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>bounded-aboveXXREAL-2V4\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  let ?r = "maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
  have A1: "?r >=XXREAL-0R2 upper-boundSEQ-4K2 B"
    using xxreal_0_th_25 sorry
  have A2: " for r1 be RealXREAL-0M1 holds ( for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t <=XXREAL-0R1 r1) implies ?r <=XXREAL-0R1 r1"
  proof-
    have " for r1 be RealXREAL-0M1 holds ( for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t <=XXREAL-0R1 r1) implies maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B) <=XXREAL-0R1 r1"
    proof(rule ballI,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      assume A3: " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t <=XXREAL-0R1 r1"
      have " for t be RealXREAL-0M1 holds t inHIDDENR3 B implies t <=XXREAL-0R1 r1"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be RealXREAL-0M1"
        assume "t inHIDDENR3 B"
        then have "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
          using xboole_0_def_3 sorry
        thus "t <=XXREAL-0R1 r1"
          using A3 sorry
      qed "sorry"
      then have A4: "upper-boundSEQ-4K2 B <=XXREAL-0R1 r1"
        using seq_4_th_45 sorry
      have " for t be RealXREAL-0M1 holds t inHIDDENR3 A implies t <=XXREAL-0R1 r1"
      proof(rule ballI,rule impI)
        fix t assume [ty]: "t be RealXREAL-0M1"
        assume "t inHIDDENR3 A"
        then have "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
          using xboole_0_def_3 sorry
        thus "t <=XXREAL-0R1 r1"
          using A3 sorry
      qed "sorry"
      then have "upper-boundSEQ-4K2 A <=XXREAL-0R1 r1"
        using seq_4_th_45 sorry
      thus "maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B) <=XXREAL-0R1 r1"
        using A4 xxreal_0_th_28 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A5: "?r >=XXREAL-0R2 upper-boundSEQ-4K2 A"
    using xxreal_0_th_25 sorry
  have " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t <=XXREAL-0R1 ?r"
  proof-
    have " for t be RealXREAL-0M1 holds t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B implies t <=XXREAL-0R1 maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
    proof(rule ballI,rule impI)
      fix t assume [ty]: "t be RealXREAL-0M1"
      assume "t inHIDDENR3 A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B"
      then have "t inHIDDENR3 A or t inHIDDENR3 B"
        using xboole_0_def_3 sorry
      then have "upper-boundSEQ-4K2 A >=XXREAL-0R2 t or upper-boundSEQ-4K2 B >=XXREAL-0R2 t"
        using seq_4_def_1 sorry
      thus "t <=XXREAL-0R1 maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
        using A5 A1 xxreal_0_th_2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "upper-boundSEQ-4K2 (A \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> B) =COMPLEX1R1 maxXXREAL-0K5(upper-boundSEQ-4K2 A,upper-boundSEQ-4K2 B)"
    using A2 seq_4_th_46 sorry
qed "sorry"

mtheorem seq_4_th_144:
" for R be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r0 be RealXREAL-0M1 holds ( for r be RealXREAL-0M1 holds r inHIDDENR3 R implies r <=XXREAL-0R1 r0) implies upper-boundSEQ-4K2 R <=XXREAL-0R1 r0"
proof(rule ballI,rule ballI,rule impI)
  fix R assume [ty]: "R be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix r0 assume [ty]: "r0 be RealXREAL-0M1"
  assume A1: " for r be RealXREAL-0M1 holds r inHIDDENR3 R implies r <=XXREAL-0R1 r0"
  then have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 R implies r <=XXREAL-0R1 r0"
     sorry
  then have "r0 be UpperBoundXXREAL-2M1-of R"
    using xxreal_2_def_1 sorry
  then have A2: "R be bounded-aboveXXREAL-2V4"
     sorry
  have "upper-boundSEQ-4K2 R >XXREAL-0R4 r0 implies  False "
  proof(rule impI)
    let ?r1 = "upper-boundSEQ-4K2 R -XCMPLX-0K6 r0"
    assume "upper-boundSEQ-4K2 R >XXREAL-0R4 r0"
    then have "?r1 >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_50 sorry
    then have " ex r be RealXREAL-0M1 st r inHIDDENR3 R & upper-boundSEQ-4K2 R -XCMPLX-0K6 ?r1 <XXREAL-0R3 r"
      using A2 seq_4_def_1 sorry
    thus " False "
      using A1 sorry
  qed
  thus "upper-boundSEQ-4K2 R <=XXREAL-0R1 r0"
     sorry
qed "sorry"

end
