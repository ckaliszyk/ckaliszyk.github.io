theory boole
  imports xboole_0
begin
(*begin*)
mtheorem boole_th_1:
" for X be setHIDDENM2 holds X \\/XBOOLE-0K2 {}XBOOLE-0K1 =XBOOLE-0R4 X"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "X \\/XBOOLE-0K2 {}XBOOLE-0K1 c=TARSKIR1 X & X c=TARSKIR1 X \\/XBOOLE-0K2 {}XBOOLE-0K1"
  proof(rule conjMI)
    show "X \\/XBOOLE-0K2 {}XBOOLE-0K1 c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 {}XBOOLE-0K1 implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\/XBOOLE-0K2 {}XBOOLE-0K1"
        then have "x inHIDDENR3 X or x inHIDDENR3 {}XBOOLE-0K1"
          using xboole_0_def_3 sorry
        thus "x inHIDDENR3 X"
          using xboole_0_def_1 sorry
      qed "sorry"
      thus "X \\/XBOOLE-0K2 {}XBOOLE-0K1 c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X \\/XBOOLE-0K2 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 X"
      thus "x inHIDDENR3 X \\/XBOOLE-0K2 {}XBOOLE-0K1"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X c=TARSKIR1 X \\/XBOOLE-0K2 {}XBOOLE-0K1"
      using tarski_def_3 sorry
  qed
  thus "X \\/XBOOLE-0K2 {}XBOOLE-0K1 =XBOOLE-0R4 X"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem boole_th_2:
" for X be setHIDDENM2 holds X /\\XBOOLE-0K3 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "X /\\XBOOLE-0K3 {}XBOOLE-0K1 c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 X /\\XBOOLE-0K3 {}XBOOLE-0K1"
  proof(rule conjMI)
    show "X /\\XBOOLE-0K3 {}XBOOLE-0K1 c=TARSKIR1 {}XBOOLE-0K1"
      using xboole_0_def_4 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {}XBOOLE-0K1 implies x inHIDDENR3 X /\\XBOOLE-0K3 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {}XBOOLE-0K1"
      thus "x inHIDDENR3 X /\\XBOOLE-0K3 {}XBOOLE-0K1"
        using xboole_0_def_1 sorry
    qed "sorry"
    thus "{}XBOOLE-0K1 c=TARSKIR1 X /\\XBOOLE-0K3 {}XBOOLE-0K1"
      using tarski_def_3 sorry
  qed
  thus "X /\\XBOOLE-0K3 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem boole_th_3:
" for X be setHIDDENM2 holds X \\XBOOLE-0K4 {}XBOOLE-0K1 =XBOOLE-0R4 X"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "X \\XBOOLE-0K4 {}XBOOLE-0K1 c=TARSKIR1 X & X c=TARSKIR1 X \\XBOOLE-0K4 {}XBOOLE-0K1"
  proof(rule conjMI)
    show "X \\XBOOLE-0K4 {}XBOOLE-0K1 c=TARSKIR1 X"
      using xboole_0_def_5 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X \\XBOOLE-0K4 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: " not x inHIDDENR3 {}XBOOLE-0K1"
        using xboole_0_def_1 sorry
      assume "x inHIDDENR3 X"
      thus "x inHIDDENR3 X \\XBOOLE-0K4 {}XBOOLE-0K1"
        using A1 xboole_0_def_5 sorry
    qed "sorry"
    thus "X c=TARSKIR1 X \\XBOOLE-0K4 {}XBOOLE-0K1"
      using tarski_def_3 sorry
  qed
  thus "X \\XBOOLE-0K4 {}XBOOLE-0K1 =XBOOLE-0R4 X"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem boole_th_4:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "{}XBOOLE-0K1 \\XBOOLE-0K4 X c=TARSKIR1 {}XBOOLE-0K1 & {}XBOOLE-0K1 c=TARSKIR1 {}XBOOLE-0K1 \\XBOOLE-0K4 X"
  proof(rule conjMI)
    show "{}XBOOLE-0K1 \\XBOOLE-0K4 X c=TARSKIR1 {}XBOOLE-0K1"
      using xboole_0_def_5 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {}XBOOLE-0K1 implies x inHIDDENR3 {}XBOOLE-0K1 \\XBOOLE-0K4 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 {}XBOOLE-0K1"
      thus "x inHIDDENR3 {}XBOOLE-0K1 \\XBOOLE-0K4 X"
        using xboole_0_def_1 sorry
    qed "sorry"
    thus "{}XBOOLE-0K1 c=TARSKIR1 {}XBOOLE-0K1 \\XBOOLE-0K4 X"
      using tarski_def_3 sorry
  qed
  thus "{}XBOOLE-0K1 \\XBOOLE-0K4 X =XBOOLE-0R4 {}XBOOLE-0K1"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem boole_th_5:
" for X be setHIDDENM2 holds X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 =XBOOLE-0R4 X"
proof(rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  have "X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 c=TARSKIR1 X & X c=TARSKIR1 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1"
  proof(rule conjMI)
    show "X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1"
        then have A1: "x inHIDDENR3 X \\XBOOLE-0K4 {}XBOOLE-0K1 or x inHIDDENR3 {}XBOOLE-0K1 \\XBOOLE-0K4 X"
          using xboole_0_def_3 sorry
        show "x inHIDDENR3 X"
        proof-
          have cases: "x inHIDDENR3 X &  not x inHIDDENR3 {}XBOOLE-0K1 or x inHIDDENR3 {}XBOOLE-0K1 &  not x inHIDDENR3 X"
            using A1 xboole_0_def_5 sorry
          have case1: "x inHIDDENR3 X &  not x inHIDDENR3 {}XBOOLE-0K1 implies x inHIDDENR3 X"
          proof(rule impI)
            assume "x inHIDDENR3 X &  not x inHIDDENR3 {}XBOOLE-0K1"
            thus "x inHIDDENR3 X"
               sorry
          qed
          have case2: "x inHIDDENR3 {}XBOOLE-0K1 &  not x inHIDDENR3 X implies x inHIDDENR3 X"
          proof(rule impI)
            assume "x inHIDDENR3 {}XBOOLE-0K1 &  not x inHIDDENR3 X"
            thus "x inHIDDENR3 X"
              using xboole_0_def_1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A2: " not x inHIDDENR3 {}XBOOLE-0K1"
        using xboole_0_def_1 sorry
      assume "x inHIDDENR3 X"
      then have "x inHIDDENR3 X \\XBOOLE-0K4 {}XBOOLE-0K1"
        using A2 xboole_0_def_5 sorry
      thus "x inHIDDENR3 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "X c=TARSKIR1 X \\+\\XBOOLE-0K5 {}XBOOLE-0K1"
      using tarski_def_3 sorry
  qed
  thus "X \\+\\XBOOLE-0K5 {}XBOOLE-0K1 =XBOOLE-0R4 X"
    using xboole_0_def_10 sorry
qed "sorry"

reserve x, X for "setHIDDENM2"
mlemma boole_lm_1:
" for X be setHIDDENM2 holds X be emptyXBOOLE-0V1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  not (X be emptyXBOOLE-0V1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X) implies X =XBOOLE-0R4 {}XBOOLE-0K1"
    proof(rule impI)
      assume " not ( ex x be objectHIDDENM1 st x inHIDDENR3 X)"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 {}XBOOLE-0K1 iff x inHIDDENR3 X"
        using xboole_0_def_1 sorry
      thus "X =XBOOLE-0R4 {}XBOOLE-0K1"
        using tarski_th_2 sorry
    qed
    thus " not (X be emptyXBOOLE-0V1 &  not X =XBOOLE-0R4 {}XBOOLE-0K1)"
      using xboole_0_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem boole_th_6:
" for X be setHIDDENM2 holds X be emptyXBOOLE-0V1 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  using boole_lm_1 sorry

mtheorem boole_th_7:
" for x be setHIDDENM2 holds  for X be setHIDDENM2 holds x inTARSKIR2 X implies X be  non emptyXBOOLE-0V1"
  using xboole_0_def_1 sorry

mtheorem boole_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be emptyXBOOLE-0V1 & X <>HIDDENR2 Y implies Y be  non emptyXBOOLE-0V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X be emptyXBOOLE-0V1 & X <>HIDDENR2 Y implies  not Y be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X be emptyXBOOLE-0V1"
      and A2: "X <>HIDDENR2 Y"
    have "X =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 boole_lm_1 sorry
    thus " not Y be emptyXBOOLE-0V1"
      using A2 boole_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
