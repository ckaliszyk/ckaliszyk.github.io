theory funct_1
  imports relat_1 setfam_1
begin
(*begin*)
reserve X, X1, X2, Y, Y1, Y2 for "setHIDDENM2"
reserve p, x, x1, x2, y, y1, y2, z, z1, z2 for "objectHIDDENM1"
mdef funct_1_def_1 ("Function-likeFUNCT-1V1" 70 ) where
"attr Function-likeFUNCT-1V1 for setHIDDENM2 means
  (\<lambda>X.  for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 X & [TARSKIK4 x,y2 ] inHIDDENR3 X implies y1 =HIDDENR1 y2)"..

mtheorem funct_1_cl_1:
"cluster emptyXBOOLE-0V1 also-is Function-likeFUNCT-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be Function-likeFUNCT-1V1"
     sorry
qed "sorry"

mtheorem funct_1_cl_2:
"cluster Function-likeFUNCT-1V1 for RelationRELAT-1M1"
proof
(*existence*)
  show " ex it be RelationRELAT-1M1 st it be Function-likeFUNCT-1V1"
  proof-
    have " ex tVar1 be RelationRELAT-1M1 st tVar1 be Function-likeFUNCT-1V1"
    proof-
      show " ex tVar1 be RelationRELAT-1M1 st tVar1 be Function-likeFUNCT-1V1"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be Function-likeFUNCT-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax FUNCT_1M1 :: "Ty" ("FunctionFUNCT-1M1" 70)
translations "FunctionFUNCT-1M1" \<rightharpoonup> "Function-likeFUNCT-1V1\<bar>RelationRELAT-1M1"

mtheorem funct_1_cl_3:
  mlet "a be objectHIDDENM1", "b be objectHIDDENM1"
"cluster {TARSKIK1 [TARSKIK4 a,b ] } as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "{TARSKIK1 [TARSKIK4 a,b ] } be Function-likeFUNCT-1V1"
  proof-
    let ?X = "{TARSKIK1 [TARSKIK4 a,b ] }"
    have A1: "[:ZFMISC-1K2 {TARSKIK1 a},{TARSKIK1 b} :] =RELAT-1R1 ?X"
      using zfmisc_1_th_29 sorry
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 ?X & [TARSKIK4 x,y2 ] inHIDDENR3 ?X implies y1 =HIDDENR1 y2"
    proof-
      have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 a,b ] } & [TARSKIK4 x,y2 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 a,b ] } implies y1 =HIDDENR1 y2"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y1 assume [ty]: "y1 be objectHIDDENM1"
        fix y2 assume [ty]: "y2 be objectHIDDENM1"
        assume A2: "[TARSKIK4 x,y1 ] inHIDDENR3 ?X"
          and A3: "[TARSKIK4 x,y2 ] inHIDDENR3 ?X"
        have "y1 =HIDDENR1 b"
          using A1 A2 zfmisc_1_th_28 sorry
        thus "y1 =HIDDENR1 y2"
          using A1 A3 zfmisc_1_th_28 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "{TARSKIK1 [TARSKIK4 a,b ] } be Function-likeFUNCT-1V1"
       sorry
  qed
qed "sorry"

reserve f, g, g1, g2, h for "FunctionFUNCT-1M1"
reserve R, S for "RelationRELAT-1M1"
theorem funct_1_sch_1:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds Pp2(x,y1) & Pp2(x,y2) implies y1 =HIDDENR1 y2"
  shows " ex f be FunctionFUNCT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f iff x inHIDDENR3 Af0 & Pp2(x,y)"
  proof-
    have " ex tVar2 be FunctionFUNCT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar2 implies x inHIDDENR3 Af0 & Pp2(x,y)) & (x inHIDDENR3 Af0 & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
    proof-
      obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A2: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff ( ex x be objectHIDDENM1 st x inHIDDENR3 Af0 & Pp2(x,y))"
        using tarski_sch_1 A1 sorry
      let ?R = "\<lambda>Lamb1.  ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 Lamb1 & Pp2(x,y)"
      obtain F where
        [ty]:"F be setHIDDENM2" and 
        A3: " for p be objectHIDDENM1 holds p inHIDDENR3 F iff p inHIDDENR3 [:ZFMISC-1K2 Af0,Y :] & ?R(p)"
        using xboole_0_sch_1 sorry
      have "( for p be objectHIDDENM1 holds p inHIDDENR3 F implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)) & ( for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 F implies ([TARSKIK4 x,y2 ] inHIDDENR3 F implies y1 =HIDDENR1 y2))"
      proof(rule conjMI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
        show " for p be objectHIDDENM1 holds p inHIDDENR3 F implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p)"
        proof-
          have " for p be objectHIDDENM1 holds  not (p inHIDDENR3 F & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 p))"
          proof(rule ballI)
            fix p assume [ty]: "p be objectHIDDENM1"
            have "p inHIDDENR3 F implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st [TARSKIK4 x,y ] =HIDDENR1 p & Pp2(x,y))"
              using A3 sorry
            thus " not (p inHIDDENR3 F & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] =HIDDENR1 p))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y1 assume [ty]: "y1 be objectHIDDENM1"
        fix y2 assume [ty]: "y2 be objectHIDDENM1"
        assume "[TARSKIK4 x,y1 ] inHIDDENR3 F"
        then obtain x1 z1 where
          [ty]:"x1 be objectHIDDENM1" "z1 be objectHIDDENM1" and 
          A4: "[TARSKIK4 x1,z1 ] =HIDDENR1 [TARSKIK4 x,y1 ]"and A5: "Pp2(x1,z1)"
          using A3 sorry
        have A6: "x =HIDDENR1 x1 & z1 =HIDDENR1 y1"
          using A4 xtuple_0_th_1 sorry
        assume "[TARSKIK4 x,y2 ] inHIDDENR3 F"
        then obtain x2 z2 where
          [ty]:"x2 be objectHIDDENM1" "z2 be objectHIDDENM1" and 
          A7: "[TARSKIK4 x2,z2 ] =HIDDENR1 [TARSKIK4 x,y2 ]"and A8: "Pp2(x2,z2)"
          using A3 sorry
        have "x =HIDDENR1 x2 & z2 =HIDDENR1 y2"
          using A7 xtuple_0_th_1 sorry
        thus "y1 =HIDDENR1 y2"
          using A1 A5 A8 A6 sorry
      qed "sorry"
      then obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = F"
        using funct_1_def_1 relat_1_def_1 sorry
      show " ex tVar2 be FunctionFUNCT-1M1 st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 tVar2 implies x inHIDDENR3 Af0 & Pp2(x,y)) & (x inHIDDENR3 Af0 & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 tVar2)"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "[TARSKIK4 x,y ] inHIDDENR3 f implies x inHIDDENR3 Af0 & Pp2(x,y)"
        proof(rule impI,rule conjMI)
          assume A9: "[TARSKIK4 x,y ] inHIDDENR3 f"
          then obtain x1 y1 where
            [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
            A10: "[TARSKIK4 x1,y1 ] =HIDDENR1 [TARSKIK4 x,y ]"and A11: "Pp2(x1,y1)"
            using A3 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Y :]"
            using A3 A9 sorry
          thus "x inHIDDENR3 Af0"
            using zfmisc_1_th_87 sorry
          have "x1 =HIDDENR1 x"
            using A10 xtuple_0_th_1 sorry
          thus "Pp2(x,y)"
            using A10 A11 xtuple_0_th_1 sorry
        qed
        assume A12: "x inHIDDENR3 Af0"
          and A13: "Pp2(x,y)"
        have "y inHIDDENR3 Y"
          using A2 A12 A13 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Af0,Y :]"
          using A12 zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A3 A13 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef funct_1_def_2 (" _ .FUNCT-1K1  _ " [200,200]200 ) where
  mlet "f be FunctionFUNCT-1M1", "x be objectHIDDENM1"
"func f .FUNCT-1K1 x \<rightarrow> setHIDDENM2 means
  \<lambda>it. [TARSKIK4 x,it ] inHIDDENR3 f if x inHIDDENR3 domRELAT-1K1 f otherwise \<lambda>it. it =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  (*existence*)
    show "(x inHIDDENR3 domRELAT-1K1 f implies ( ex it be setHIDDENM2 st [TARSKIK4 x,it ] inHIDDENR3 f)) & ( not x inHIDDENR3 domRELAT-1K1 f implies ( ex it be setHIDDENM2 st it =XBOOLE-0R4 {}XBOOLE-0K1))"
    proof-
      have "(x inHIDDENR3 domRELAT-1K1 f implies ( ex y be setHIDDENM2 st [TARSKIK4 x,y ] inHIDDENR3 f)) &  not ( not x inHIDDENR3 domRELAT-1K1 f & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 =XBOOLE-0R4 {}XBOOLE-0K1))"
      proof(rule conjMI)
        show "x inHIDDENR3 domRELAT-1K1 f implies ( ex y be setHIDDENM2 st [TARSKIK4 x,y ] inHIDDENR3 f)"
        proof(rule impI)
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A1: "[TARSKIK4 x,y ] inHIDDENR3 f"
            using xtuple_0_def_12 sorry
          have 
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          show " ex y be setHIDDENM2 st [TARSKIK4 x,y ] inHIDDENR3 f"
          proof(rule bexI[of _ "y"])
            show "[TARSKIK4 x,y ] inHIDDENR3 f"
              using A1 sorry
          qed "sorry"
        qed
        show " not ( not x inHIDDENR3 domRELAT-1K1 f & ( for VarFor1 be setHIDDENM2 holds  not VarFor1 =XBOOLE-0R4 {}XBOOLE-0K1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds (x inHIDDENR3 domRELAT-1K1 f implies ([TARSKIK4 x,it1 ] inHIDDENR3 f & [TARSKIK4 x,it2 ] inHIDDENR3 f implies it1 =HIDDENR1 it2)) & ( not x inHIDDENR3 domRELAT-1K1 f implies (it1 =XBOOLE-0R4 {}XBOOLE-0K1 & it2 =XBOOLE-0R4 {}XBOOLE-0K1 implies it1 =HIDDENR1 it2))"
      using funct_1_def_1 sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem funct_1_th_1:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds [TARSKIK4 x,y ] inHIDDENR3 f iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds ([TARSKIK4 x,y ] inHIDDENR3 f implies x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) &  not ((x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) &  not [TARSKIK4 x,y ] inHIDDENR3 f)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "[TARSKIK4 x,y ] inHIDDENR3 f implies x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
    proof(rule impI,rule conjMI)
      assume A1: "[TARSKIK4 x,y ] inHIDDENR3 f"
      thus A2: "x inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      have 
        [ty]:"y be setHIDDENM2"
        using tarski_th_1 sorry
      have "y =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A1 funct_1_def_2 A2 sorry
      thus "y =HIDDENR1 f .FUNCT-1K1 x"
         sorry
    qed
    show " not ((x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) &  not [TARSKIK4 x,y ] inHIDDENR3 f)"
      using funct_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_2:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f =RELAT-1R1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f =RELAT-1R1 g"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g) & ([TARSKIK4 x,y ] inHIDDENR3 g implies [TARSKIK4 x,y ] inHIDDENR3 f)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g"
      proof(rule impI)
        assume A3: "[TARSKIK4 x,y ] inHIDDENR3 f"
        then have A4: "x inHIDDENR3 domRELAT-1K1 f"
          using xtuple_0_def_12 sorry
        have 
          [ty]:"y be setHIDDENM2"
          using tarski_th_1 sorry
        have "f .FUNCT-1K1 x =XBOOLE-0R4 y"
          using A3 funct_1_def_2 A4 sorry
        then have "g .FUNCT-1K1 x =XBOOLE-0R4 y"
          using A2 A4 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 g"
          using A1 A4 funct_1_def_2 sorry
      qed
      assume A5: "[TARSKIK4 x,y ] inHIDDENR3 g"
      then have A6: "x inHIDDENR3 domRELAT-1K1 g"
        using xtuple_0_def_12 sorry
      have 
        [ty]:"y be setHIDDENM2"
        using tarski_th_1 sorry
      have "g .FUNCT-1K1 x =XBOOLE-0R4 y"
        using A5 funct_1_def_2 A6 sorry
      then have "f .FUNCT-1K1 x =XBOOLE-0R4 y"
        using A1 A2 A6 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 f"
        using A1 A6 funct_1_def_2 sorry
    qed "sorry"
    thus "f =RELAT-1R1 g"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1K2("rngFUNCT-1K2  _ " [228]228) where
  "rngFUNCT-1K2 f \<equiv> rngRELAT-1K2 f"

mtheorem funct_1_def_3:
  mlet "f be FunctionFUNCT-1M1"
"redefine func rngFUNCT-1K2 f \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 rngFUNCT-1K2 f iff ( for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x))"
  proof-
    have " for Y be setHIDDENM2 holds (Y =XBOOLE-0R4 rngRELAT-1K2 f implies ( for y be objectHIDDENM1 holds (y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 Y))) & (( for y be objectHIDDENM1 holds y inHIDDENR3 Y iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) implies Y =HIDDENR1 rngRELAT-1K2 f)"
    proof(rule ballI,rule conjMI,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      show "Y =XBOOLE-0R4 rngRELAT-1K2 f implies ( for y be objectHIDDENM1 holds (y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 Y))"
      proof(rule impI,rule ballI,rule conjMI,rule impI)
        assume A1: "Y =XBOOLE-0R4 rngRELAT-1K2 f"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
        proof(rule impI)
          assume "y inHIDDENR3 Y"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 f"
            using A1 xtuple_0_def_13 sorry
          show " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          proof(rule bexI[of _ "x"])
            show "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
              using A2 funct_1_th_1 sorry
          qed "sorry"
        qed
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
           sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A3 funct_1_def_2 sorry
        thus "y inHIDDENR3 Y"
          using A1 xtuple_0_def_13 sorry
      qed "sorry"
      assume A4: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
      have "( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngRELAT-1K2 f) & rngRELAT-1K2 f c=TARSKIR1 Y"
      proof(rule conjMI)
        show " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngRELAT-1K2 f"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 Y"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A5: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
            using A4 sorry
          have "[TARSKIK4 x,y ] inHIDDENR3 f"
            using A5 funct_1_def_2 sorry
          thus "y inHIDDENR3 rngRELAT-1K2 f"
            using xtuple_0_def_13 sorry
        qed "sorry"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 f implies y inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngRELAT-1K2 f"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A6: "[TARSKIK4 x,y ] inHIDDENR3 f"
            using xtuple_0_def_13 sorry
          have "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
            using A6 funct_1_th_1 sorry
          thus "y inHIDDENR3 Y"
            using A4 sorry
        qed "sorry"
        thus "rngRELAT-1K2 f c=TARSKIR1 Y"
          using tarski_def_3 sorry
      qed
      thus "Y =HIDDENR1 rngRELAT-1K2 f"
        using tarski_def_3 xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_3:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
  using funct_1_def_3 sorry

mtheorem funct_1_th_4:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} implies rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x} implies rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x}"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f iff y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }) & (y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x } implies y inHIDDENR3 rngFUNCT-1K2 f)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
        proof(rule impI)
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A2: "z inHIDDENR3 domRELAT-1K1 f"and A3: "y =HIDDENR1 f .FUNCT-1K1 z"
            using funct_1_def_3 sorry
          have "z =HIDDENR1 x"
            using A1 A2 tarski_def_1 sorry
          thus "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
            using A3 tarski_def_1 sorry
        qed
        assume "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
        then have A4: "y =HIDDENR1 f .FUNCT-1K1 x"
          using tarski_def_1 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A1 tarski_def_1 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 f"
          using A4 funct_1_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem funct_1_sch_2:
  fixes Af0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Af0 & Pp2(x,y1)) & Pp2(x,y2) implies y1 =HIDDENR1 y2" and
   A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st Pp2(x,y))"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp2(x,f .FUNCT-1K1 x))"
  proof-
    have " ex tVar5 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar5 =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp2(x,tVar5 .FUNCT-1K1 x))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inHIDDENR3 Af0 & Pp2(Lamb1,Lamb2)"
      have A3: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ?R(x,y1) & ?R(x,y2) implies y1 =HIDDENR1 y2"
        using A1 sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f iff x inHIDDENR3 Af0 & ?R(x,y)"
        using funct_1_sch_1 A3 sorry
      show " ex tVar5 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar5 =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp2(x,tVar5 .FUNCT-1K1 x))"
      proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f iff x inHIDDENR3 Af0"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 Af0) & (x inHIDDENR3 Af0 implies x inHIDDENR3 domRELAT-1K1 f)"
          proof(rule ballI,rule conjMI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            show "x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 Af0"
            proof(rule impI)
              assume "x inHIDDENR3 domRELAT-1K1 f"
              then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f"
                using xtuple_0_def_12 sorry
              thus "x inHIDDENR3 Af0"
                using A4 sorry
            qed
            assume A5: "x inHIDDENR3 Af0"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A6: "Pp2(x,y)"
              using A2 sorry
            have "[TARSKIK4 x,y ] inHIDDENR3 f"
              using A4 A5 A6 sorry
            thus "x inHIDDENR3 domRELAT-1K1 f"
              using xtuple_0_def_12 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus A7: "domRELAT-1K1 f =XBOOLE-0R4 Af0"
          using tarski_th_2 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A8: "x inHIDDENR3 Af0"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A9: "Pp2(x,y)"
          using A2 sorry
        have 
          [ty]:"y be setHIDDENM2"
          using tarski_th_1 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A4 A8 A9 sorry
        thus "Pp2(x,f .FUNCT-1K1 x)"
          using A7 A8 A9 funct_1_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem funct_1_sch_3:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
    have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
       sorry
    have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Af0 & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
       sorry
    show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =HIDDENR1 Ff1(x))"
      using funct_1_sch_2 A2 A1 sorry
  qed

mtheorem funct_1_th_5:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( for y be objectHIDDENM1 holds  ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 y})"
proof-
  have " for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( for y be objectHIDDENM1 holds  ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 X & rngFUNCT-1K2 tVar6 =XBOOLE-0R4 {TARSKIK1 y})"
  proof(rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    fix y assume [ty]: "y be objectHIDDENM1"
    let ?F = "\<lambda>Lamb1. y"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 ?F(x)"
      using funct_1_sch_3 sorry
    show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 X & rngFUNCT-1K2 tVar6 =XBOOLE-0R4 {TARSKIK1 y}"
    proof(rule bexI[of _ "f"],rule conjMI)
      show "domRELAT-1K1 f =XBOOLE-0R4 X"
        using A2 sorry
      have " for y1 be objectHIDDENM1 holds y1 inHIDDENR3 rngFUNCT-1K2 f iff y1 =HIDDENR1 y"
      proof-
        have " for y1 be objectHIDDENM1 holds  not (y1 inHIDDENR3 rngFUNCT-1K2 f &  not y1 =HIDDENR1 y) &  not (y1 =HIDDENR1 y &  not y1 inHIDDENR3 rngFUNCT-1K2 f)"
        proof(rule ballI)
          fix y1 assume [ty]: "y1 be objectHIDDENM1"
          have A4: "y1 =HIDDENR1 y implies y1 inHIDDENR3 rngFUNCT-1K2 f"
          proof(rule impI)
            let ?x = "the ElementSUBSET-1M1-of X"
            assume A5: "y1 =HIDDENR1 y"
            have "f .FUNCT-1K1 ?x =HIDDENR1 y"
              using A1 A3 sorry
            thus "y1 inHIDDENR3 rngFUNCT-1K2 f"
              using A1 A2 A5 funct_1_def_3 sorry
          qed
          have "y1 inHIDDENR3 rngFUNCT-1K2 f implies y1 =HIDDENR1 y"
          proof(rule impI)
            assume "y1 inHIDDENR3 rngFUNCT-1K2 f"
            then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y1 =HIDDENR1 f .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            thus "y1 =HIDDENR1 y"
              using A2 A3 sorry
          qed
          thus " not (y1 inHIDDENR3 rngFUNCT-1K2 f &  not y1 =HIDDENR1 y) &  not (y1 =HIDDENR1 y &  not y1 inHIDDENR3 rngFUNCT-1K2 f)"
            using A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 y}"
        using tarski_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_6:
" for X be setHIDDENM2 holds ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies f =RELAT-1R1 g) implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds ( for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies f =RELAT-1R1 g) implies ( not X =XBOOLE-0R4 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?F = "\<lambda>Lamb1. {}XBOOLE-0K1"
    assume A1: " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X implies f =RELAT-1R1 g"
    let ?x = "the ElementSUBSET-1M1-of X"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)"
      using funct_1_sch_3 sorry
    assume A4: " not X =XBOOLE-0R4 {}XBOOLE-0K1"
    then have A5: "f .FUNCT-1K1 ?x =XBOOLE-0R4 {}XBOOLE-0K1"
      using A3 sorry
    let ?F = "\<lambda>Lamb1. {TARSKIK1 {}XBOOLE-0K1 }"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A6: "domRELAT-1K1 g =XBOOLE-0R4 X"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)"
      using funct_1_sch_3 sorry
    have "g .FUNCT-1K1 ?x =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
      using A4 A7 sorry
    thus " False "
      using A1 A2 A6 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_7:
" for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 y}) & rngFUNCT-1K2 g =XBOOLE-0R4 {TARSKIK1 y} implies f =RELAT-1R1 g"
proof-
  have " for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & (rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 y} & rngFUNCT-1K2 g =XBOOLE-0R4 {TARSKIK1 y}) implies f =RELAT-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 y}"
      and A3: "rngFUNCT-1K2 g =XBOOLE-0R4 {TARSKIK1 y}"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A4: "x inHIDDENR3 domRELAT-1K1 f"
        then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
          using funct_1_def_3 sorry
        then have A5: "f .FUNCT-1K1 x =HIDDENR1 y"
          using A2 tarski_def_1 sorry
        have "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
          using A1 A4 funct_1_def_3 sorry
        thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using A3 A5 tarski_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f =RELAT-1R1 g"
      using A1 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex f be FunctionFUNCT-1M1 st X =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 f c=TARSKIR1 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1 implies  not ( for f be FunctionFUNCT-1M1 holds  not (X =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 f c=TARSKIR1 Y))"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
    have A2: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)"
    proof(rule impI)
      let ?y = "the ElementSUBSET-1M1-of Y"
      let ?F = "\<lambda>Lamb1. ?y"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 X"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)"
        using funct_1_sch_3 sorry
      assume "X <>HIDDENR2 {}XBOOLE-0K1"
      then have A5: "?y inTARSKIR2 Y"
        using A1 sorry
      show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
      proof(rule bexI[of _ "f"],rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 X"
          using A3 sorry
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngFUNCT-1K2 f"
          then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & z =HIDDENR1 f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          thus "z inHIDDENR3 Y"
            using A5 A3 A4 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 f c=TARSKIR1 Y"
           sorry
      qed "sorry"
    qed
    have "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=RELAT-1R2 Y)"
    proof(rule impI)
      assume A6: "X =XBOOLE-0R4 {}XBOOLE-0K1"
      obtain f where 
        [ty]:"f be setHIDDENM2" and fDef:"f = {}XBOOLE-0K1"
         sorry
      show " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=RELAT-1R2 Y"
      proof(rule bexI[of _ "f"],rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 X"
          using A6 sorry
        show "rngFUNCT-1K2 f c=RELAT-1R2 Y"
           sorry
      qed "sorry"
    qed
    thus " not ( for f be FunctionFUNCT-1M1 holds  not (X =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 f c=TARSKIR1 Y))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_9:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) implies Y c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) implies Y c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngFUNCT-1K2 f"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Y"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        using A1 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 rngFUNCT-1K2 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1K3(" _ *FUNCT-1K3  _ " [164,164]164) where
  "g *FUNCT-1K3 f \<equiv> f *RELAT-1K6 g"

mtheorem funct_1_cl_4:
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"cluster g *FUNCT-1K3 f as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "g *FUNCT-1K3 f be Function-likeFUNCT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 g *FUNCT-1K3 f implies ([TARSKIK4 x,y2 ] inHIDDENR3 g *FUNCT-1K3 f implies y1 =HIDDENR1 y2)"
    proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume "[TARSKIK4 x,y1 ] inHIDDENR3 g *FUNCT-1K3 f"
      then obtain z1 where
        [ty]:"z1 be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,z1 ] inHIDDENR3 f"and A2: "[TARSKIK4 z1,y1 ] inHIDDENR3 g"
        using relat_1_def_8 sorry
      assume "[TARSKIK4 x,y2 ] inHIDDENR3 g *FUNCT-1K3 f"
      then obtain z2 where
        [ty]:"z2 be objectHIDDENM1" and 
        A3: "[TARSKIK4 x,z2 ] inHIDDENR3 f"and A4: "[TARSKIK4 z2,y2 ] inHIDDENR3 g"
        using relat_1_def_8 sorry
      have "z1 =HIDDENR1 z2"
        using A1 A3 funct_1_def_1 sorry
      thus "y1 =HIDDENR1 y2"
        using A2 A4 funct_1_def_1 sorry
    qed "sorry"
    thus "g *FUNCT-1K3 f be Function-likeFUNCT-1V1"
      using funct_1_def_1 sorry
  qed
qed "sorry"

mtheorem funct_1_th_10:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)) implies h =RELAT-1R1 g *FUNCT-1K3 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)) implies h =RELAT-1R1 g *FUNCT-1K3 f"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 h implies ( ex y1 be objectHIDDENM1 st [TARSKIK4 x,y1 ] inHIDDENR3 f & [TARSKIK4 y1,y ] inHIDDENR3 g)) & (( ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 f & [TARSKIK4 z,y ] inHIDDENR3 g) implies [TARSKIK4 x,y ] inHIDDENR3 h)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 h implies ( ex y1 be objectHIDDENM1 st [TARSKIK4 x,y1 ] inHIDDENR3 f & [TARSKIK4 y1,y ] inHIDDENR3 g)"
      proof(rule impI)
        assume A3: "[TARSKIK4 x,y ] inHIDDENR3 h"
        then have A4: "x inHIDDENR3 domRELAT-1K1 h"
          using xtuple_0_def_12 sorry
        then have A5: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using A1 sorry
        obtain y1 where 
          [ty]:"y1 be objectHIDDENM1" and y1Def:"y1 = f .FUNCT-1K1 x"
           sorry
        show " ex y1 be objectHIDDENM1 st [TARSKIK4 x,y1 ] inHIDDENR3 f & [TARSKIK4 y1,y ] inHIDDENR3 g"
        proof(rule bexI[of _ "y1"],rule conjMI)
          have "x inHIDDENR3 domRELAT-1K1 f"
            using A1 A4 sorry
          thus "[TARSKIK4 x,y1 ] inHIDDENR3 f"
            using funct_1_def_2 sorry
          obtain yy where 
            [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
            using tarski_th_1 sorry
          have "yy =HIDDENR1 h .FUNCT-1K1 x"
            using A3 A4 funct_1_def_2 sorry
          also have "... = g .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A2 A4 sorry
          finally have "yy =HIDDENR1 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
             sorry
          thus "[TARSKIK4 y1,y ] inHIDDENR3 g"
            using A5 funct_1_def_2 sorry
        qed "sorry"
      qed
      assume Given: " ex z be objectHIDDENM1 st [TARSKIK4 x,z ] inHIDDENR3 f & [TARSKIK4 z,y ] inHIDDENR3 g"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A6: "[TARSKIK4 x,z ] inHIDDENR3 f"and A7: "[TARSKIK4 z,y ] inHIDDENR3 g"
         sorry
      have A8: "x inHIDDENR3 domRELAT-1K1 f"
        using A6 xtuple_0_def_12 sorry
      have 
        [ty]:"z be setHIDDENM2"
        using tarski_th_1 sorry
      have A9: "z =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A6 funct_1_def_2 A8 sorry
      have A10: "z inTARSKIR2 domRELAT-1K1 g"
        using A7 xtuple_0_def_12 sorry
      then have A11: "x inHIDDENR3 domRELAT-1K1 h"
        using A1 A8 A9 sorry
      obtain yy where 
        [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
        using tarski_th_1 sorry
      have "yy =XBOOLE-0R4 g .FUNCT-1K1 z"
        using A7 A10 funct_1_def_2 sorry
      then have "y =HIDDENR1 h .FUNCT-1K1 x"
        using A2 A9 A11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 h"
        using A11 funct_1_def_2 sorry
    qed "sorry"
    thus "h =RELAT-1R1 g *FUNCT-1K3 f"
      using relat_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_11:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g) & (x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    let ?h = "g *FUNCT-1K3 f"
    show "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
    proof(rule impI,rule conjMI)
      assume "x inHIDDENR3 domRELAT-1K1 ?h"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "[TARSKIK4 x,y ] inHIDDENR3 ?h"
        using xtuple_0_def_12 sorry
      obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,z ] inHIDDENR3 f"and A3: "[TARSKIK4 z,y ] inHIDDENR3 g"
        using A1 relat_1_def_8 sorry
      have 
        [ty]:"z be setHIDDENM2"
        using tarski_th_1 sorry
      show "x inHIDDENR3 domRELAT-1K1 f"
        using A2 xtuple_0_def_12 sorry
      then have "z =XBOOLE-0R4 f .FUNCT-1K1 x"
        using A2 funct_1_def_2 sorry
      thus "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        using A3 xtuple_0_def_12 sorry
    qed
    assume A4: "x inHIDDENR3 domRELAT-1K1 f"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A5: "[TARSKIK4 x,z ] inHIDDENR3 f"
      using xtuple_0_def_12 sorry
    assume "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A6: "[TARSKIK4 f .FUNCT-1K1 x,y ] inHIDDENR3 g"
      using xtuple_0_def_12 sorry
    have 
      [ty]:"z be setHIDDENM2"
      using tarski_th_1 sorry
    have "z =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A4 A5 funct_1_def_2 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 ?h"
      using A5 A6 relat_1_def_8 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_12:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    let ?h = "g *FUNCT-1K3 f"
    assume A1: "x inHIDDENR3 domRELAT-1K1 ?h"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A2: "[TARSKIK4 x,y ] inHIDDENR3 ?h"
      using xtuple_0_def_12 sorry
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A3: "[TARSKIK4 x,z ] inHIDDENR3 f"and A4: "[TARSKIK4 z,y ] inHIDDENR3 g"
      using A2 relat_1_def_8 sorry
    have 
      [ty]:"z be setHIDDENM2" and
      [ty]:"y be setHIDDENM2"
      using tarski_th_1 sorry
    have "x inHIDDENR3 domRELAT-1K1 f"
      using A3 xtuple_0_def_12 sorry
    then have A5: "z =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A3 funct_1_def_2 sorry
    then have "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
      using A4 xtuple_0_def_12 sorry
    then have "y =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A4 A5 funct_1_def_2 sorry
    thus "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A1 A2 funct_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_13:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
    show "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
    proof-
      have cases: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g or  not f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
         sorry
      have case1: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
      proof(rule impI)
        assume "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        then have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using A1 funct_1_th_11 sorry
        thus "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using funct_1_th_12 sorry
      qed
      have case2: " not f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g implies (g *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
      proof(rule impI)
        assume A2: " not f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        then have " not x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using funct_1_th_11 sorry
        then have "(g *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
        also have "... = g .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A2 funct_1_def_2 sorry
        finally show "(g *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_14:
" for z be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds z inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f) implies z inHIDDENR3 rngFUNCT-1K2 g"
proof-
  have " for z be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds z inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f) implies z inHIDDENR3 rngFUNCT-1K2 g"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume "z inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"and A2: "z =HIDDENR1 (g *FUNCT-1K3 f).FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g & (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A1 funct_1_th_11 funct_1_th_12 sorry
    thus "z inHIDDENR3 rngFUNCT-1K2 g"
      using A2 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_15:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f implies rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f implies rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 domRELAT-1K1 g"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      thus "y inHIDDENR3 domRELAT-1K1 g"
        using A1 funct_1_th_11 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_16:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 Y & ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f implies g =RELAT-1R1 h) implies Y =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 Y & ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f implies g =RELAT-1R1 h) implies Y =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 Y"
      and A2: " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f implies g =RELAT-1R1 h"
    have "Y c=TARSKIR1 rngFUNCT-1K2 f"
    proof-
      let ?F = "\<lambda>Lamb1. {}XBOOLE-0K1"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y &  not y inHIDDENR3 rngFUNCT-1K2 f implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 Y"
          and A4: " not y inHIDDENR3 rngFUNCT-1K2 f"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 =HIDDENR1 y implies Lamb2 =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }) & (Lamb1 <>HIDDENR2 y implies Lamb2 =HIDDENR1 {}XBOOLE-0K1)"
        have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex y1 be objectHIDDENM1 st ?P(x,y1))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies  not ( for y1 be objectHIDDENM1 holds  not ((x =HIDDENR1 y implies y1 =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }) & (x <>HIDDENR2 y implies y1 =HIDDENR1 {}XBOOLE-0K1)))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            have "x =HIDDENR1 y implies  not ( for y1 be objectHIDDENM1 holds  not ?P(x,y1))"
               sorry
            thus " not ( for y1 be objectHIDDENM1 holds  not ((x =HIDDENR1 y implies y1 =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }) & (x <>HIDDENR2 y implies y1 =HIDDENR1 {}XBOOLE-0K1)))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A6: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Y & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
           sorry
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A7: "domRELAT-1K1 h =XBOOLE-0R4 Y"and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ?P(x,h .FUNCT-1K1 x)"
          using funct_1_sch_2 A6 A5 sorry
        have A9: "domRELAT-1K1 (h *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
          using A1 A7 relat_1_th_27 sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A10: "domRELAT-1K1 g =XBOOLE-0R4 Y"and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)"
          using funct_1_sch_3 sorry
        have A12: "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
          using A1 A10 relat_1_th_27 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 (h *FUNCT-1K3 f).FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 (h *FUNCT-1K3 f).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A13: "x inHIDDENR3 domRELAT-1K1 f"
            then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
              using funct_1_def_3 sorry
            then have A14: "g .FUNCT-1K1 (f .FUNCT-1K1 x) =XBOOLE-0R4 {}XBOOLE-0K1 & h .FUNCT-1K1 (f .FUNCT-1K1 x) =XBOOLE-0R4 {}XBOOLE-0K1"
              using A1 A4 A11 A8 sorry
            have "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
              using A12 A13 funct_1_th_12 sorry
            thus "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 (h *FUNCT-1K3 f).FUNCT-1K1 x"
              using A9 A13 A14 funct_1_th_12 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A15: "g =RELAT-1R1 h"
          using A2 A10 A7 A12 A9 funct_1_th_2 sorry
        have "g .FUNCT-1K1 y =XBOOLE-0R4 {}XBOOLE-0K1"
          using A3 A11 sorry
        thus " False "
          using A3 A8 A15 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "Y =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_5:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "idRELAT-1K7 X be Function-likeFUNCT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 idRELAT-1K7 X & [TARSKIK4 x,y2 ] inHIDDENR3 idRELAT-1K7 X implies y1 =HIDDENR1 y2"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume A1: "[TARSKIK4 x,y1 ] inHIDDENR3 idRELAT-1K7 X"
        and A2: "[TARSKIK4 x,y2 ] inHIDDENR3 idRELAT-1K7 X"
      have "x =HIDDENR1 y1"
        using A1 relat_1_def_10 sorry
      thus "y1 =HIDDENR1 y2"
        using A2 relat_1_def_10 sorry
    qed "sorry"
    thus "idRELAT-1K7 X be Function-likeFUNCT-1V1"
      using funct_1_def_1 sorry
  qed
qed "sorry"

mtheorem funct_1_th_17:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f =RELAT-1R1 idRELAT-1K7 X iff domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 x)"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (f =RELAT-1R1 idRELAT-1K7 X implies domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 x)) & (domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 x) implies f =RELAT-1R1 idRELAT-1K7 X)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f =RELAT-1R1 idRELAT-1K7 X implies domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 x)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "f =RELAT-1R1 idRELAT-1K7 X"
      thus A2: "domRELAT-1K1 f =XBOOLE-0R4 X"
         sorry
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 X"
      then have "[TARSKIK4 x,x ] inHIDDENR3 f"
        using A1 relat_1_def_10 sorry
      thus "f .FUNCT-1K1 x =HIDDENR1 x"
        using A2 A3 funct_1_def_2 sorry
    qed "sorry"
    assume A4: "domRELAT-1K1 f =XBOOLE-0R4 X"
      and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =HIDDENR1 x"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 f implies x inHIDDENR3 X & x =HIDDENR1 y) & (x inHIDDENR3 X implies (x =HIDDENR1 y implies [TARSKIK4 x,y ] inHIDDENR3 f))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 f implies x inHIDDENR3 X & x =HIDDENR1 y"
      proof(rule impI,rule conjMI)
        assume A6: "[TARSKIK4 x,y ] inHIDDENR3 f"
        thus A7: "x inHIDDENR3 X"
          using A4 funct_1_th_1 sorry
        have "y =HIDDENR1 f .FUNCT-1K1 x"
          using A6 funct_1_th_1 sorry
        thus "x =HIDDENR1 y"
          using A5 A7 sorry
      qed
      assume A8: "x inHIDDENR3 X"
      then have "f .FUNCT-1K1 x =HIDDENR1 x"
        using A5 sorry
      thus "x =HIDDENR1 y implies [TARSKIK4 x,y ] inHIDDENR3 f"
        using A4 A8 funct_1_th_1 sorry
    qed "sorry"
    thus "f =RELAT-1R1 idRELAT-1K7 X"
      using relat_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_18:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds x inHIDDENR3 X implies idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
  using funct_1_th_17 sorry

mtheorem funct_1_th_19:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) iff x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) &  not x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X) &  not (x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X &  not x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) iff x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X"
        proof-
          have "(x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) implies x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & (x inHIDDENR3 domRELAT-1K1 f implies (x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X)))"
          proof(rule conjMI,rule impI,rule impI)
            show "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) implies x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X"
            proof(rule impI)
              assume "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X)"
              then have A1: "x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & idRELAT-1K7 X .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
                using funct_1_th_11 sorry
              show "x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X"
                using A1 funct_1_th_17 sorry
            qed
            assume A2: "x inHIDDENR3 domRELAT-1K1 f"
            have A3: "domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X"
               sorry
            assume A4: "x inHIDDENR3 X"
            then have "idRELAT-1K7 X .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 f"
              using A2 funct_1_th_17 sorry
            thus "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X)"
              using A4 A3 funct_1_th_11 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus " not (x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) &  not x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X) &  not (x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X &  not x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X))"
          using xboole_0_def_4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "domRELAT-1K1 (f *FUNCT-1K3 idRELAT-1K7 X) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_20:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 idRELAT-1K7 X).FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 idRELAT-1K7 X).FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
    then have "x inHIDDENR3 X"
      using xboole_0_def_4 sorry
    then have "idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x & x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
      using funct_1_th_17 sorry
    thus "f .FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 idRELAT-1K7 X).FUNCT-1K1 x"
      using funct_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_21:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 Y *FUNCT-1K3 f) iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
proof-
  have " for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds  not (x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 Y *FUNCT-1K3 f) &  not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y)) &  not ((x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 Y *FUNCT-1K3 f))"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "domRELAT-1K1 (idRELAT-1K7 Y) =XBOOLE-0R4 Y"
       sorry
    thus " not (x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 Y *FUNCT-1K3 f) &  not (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y)) &  not ((x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) &  not x inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 Y *FUNCT-1K3 f))"
      using funct_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y =RELAT-1R1 idRELAT-1K7 (X /\\XBOOLE-0K3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y =RELAT-1R1 idRELAT-1K7 (X /\\XBOOLE-0K3 Y)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "domRELAT-1K1 (idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y) =HIDDENR1 domRELAT-1K1 (idRELAT-1K7 X) /\\XBOOLE-0K3 Y"
      using funct_1_th_19 sorry
    also have "... = X /\\XBOOLE-0K3 Y"
       sorry
    finally have "domRELAT-1K1 (idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y) =HIDDENR1 X /\\XBOOLE-0K3 Y"
       sorry
    have A2: " for z be objectHIDDENM1 holds z inHIDDENR3 X /\\XBOOLE-0K3 Y implies (idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y).FUNCT-1K1 z =XBOOLE-0R4 idRELAT-1K7 (X /\\XBOOLE-0K3 Y) .FUNCT-1K1 z"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 X /\\XBOOLE-0K3 Y implies (idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y).FUNCT-1K1 z =HIDDENR1 idRELAT-1K7 (X /\\XBOOLE-0K3 Y) .FUNCT-1K1 z"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume A3: "z inHIDDENR3 X /\\XBOOLE-0K3 Y"
        then have A4: "z inHIDDENR3 X"
          using xboole_0_def_4 sorry
        have A5: "z inHIDDENR3 Y"
          using A3 xboole_0_def_4 sorry
        have "(idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y).FUNCT-1K1 z =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 (idRELAT-1K7 Y .FUNCT-1K1 z)"
          using A1 A3 funct_1_th_12 sorry
        also have "... = idRELAT-1K7 X .FUNCT-1K1 z"
          using A5 funct_1_th_17 sorry
        also have "... = z"
          using A4 funct_1_th_17 sorry
        also have "... = idRELAT-1K7 (X /\\XBOOLE-0K3 Y) .FUNCT-1K1 z"
          using A3 funct_1_th_17 sorry
        finally show "(idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y).FUNCT-1K1 z =HIDDENR1 idRELAT-1K7 (X /\\XBOOLE-0K3 Y) .FUNCT-1K1 z"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 domRELAT-1K1 (idRELAT-1K7 (X /\\XBOOLE-0K3 Y))"
       sorry
    thus "idRELAT-1K7 X *FUNCT-1K3 idRELAT-1K7 Y =RELAT-1R1 idRELAT-1K7 (X /\\XBOOLE-0K3 Y)"
      using A1 A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_23:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g & g *FUNCT-1K3 f =RELAT-1R1 f implies g =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g)"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g & g *FUNCT-1K3 f =RELAT-1R1 f implies g =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A2: "g *FUNCT-1K3 f =RELAT-1R1 f"
    let ?X = "domRELAT-1K1 g"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 ?X implies g .FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =HIDDENR1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 ?X"
        then have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 y =HIDDENR1 x"
          using A1 funct_1_def_3 sorry
        thus "g .FUNCT-1K1 x =HIDDENR1 x"
          using A2 funct_1_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "g =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g)"
      using funct_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_1_def_4 ("one-to-oneFUNCT-1V2" 70 ) where
"attr one-to-oneFUNCT-1V2 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2)"..

mtheorem funct_1_th_24:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2 implies g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2 implies g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "g be one-to-oneFUNCT-1V2"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) & x2 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies ((g *FUNCT-1K3 f).FUNCT-1K1 x1 =XBOOLE-0R4 (g *FUNCT-1K3 f).FUNCT-1K1 x2 implies x1 =HIDDENR1 x2)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A3: "x1 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) & x2 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
      then have A4: "(g *FUNCT-1K3 f).FUNCT-1K1 x1 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x1) & (g *FUNCT-1K3 f).FUNCT-1K1 x2 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x2)"
        using funct_1_th_12 sorry
      have A5: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"
        using A3 funct_1_th_11 sorry
      assume A6: "(g *FUNCT-1K3 f).FUNCT-1K1 x1 =XBOOLE-0R4 (g *FUNCT-1K3 f).FUNCT-1K1 x2"
      have "f .FUNCT-1K1 x1 inTARSKIR2 domRELAT-1K1 g & f .FUNCT-1K1 x2 inTARSKIR2 domRELAT-1K1 g"
        using A3 funct_1_th_11 sorry
      then have "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        using A2 A4 A6 sorry
      thus "x1 =HIDDENR1 x2"
        using A1 A5 sorry
    qed "sorry"
    thus "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_25:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g implies f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
      and A2: "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A3: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"
        and A4: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
      have A5: "x1 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) & x2 inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
        using A2 A3 relat_1_th_27 sorry
      have "(g *FUNCT-1K3 f).FUNCT-1K1 x1 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x1) & (g *FUNCT-1K3 f).FUNCT-1K1 x2 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x2)"
        using A3 funct_1_th_13 sorry
      thus "x1 =HIDDENR1 x2"
        using A1 A4 A5 sorry
    qed "sorry"
    thus "f be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_26:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g implies f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g implies f be one-to-oneFUNCT-1V2 & ( not g be one-to-oneFUNCT-1V2 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
      and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g"
    have A3: "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A2 relat_1_th_27 sorry
    show "f be one-to-oneFUNCT-1V2"
      using A1 A2 funct_1_th_25 sorry
    assume " not g be one-to-oneFUNCT-1V2"
    then obtain y1 y2 where
      [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
      A4: "y1 inHIDDENR3 domRELAT-1K1 g"and A5: "y2 inHIDDENR3 domRELAT-1K1 g"and A6: "g .FUNCT-1K1 y1 =XBOOLE-0R4 g .FUNCT-1K1 y2 & y1 <>HIDDENR2 y2"
       sorry
    obtain x2 where
      [ty]:"x2 be objectHIDDENM1" and 
      A7: "x2 inHIDDENR3 domRELAT-1K1 f"and A8: "f .FUNCT-1K1 x2 =HIDDENR1 y2"
      using A2 A5 funct_1_def_3 sorry
    have A9: "(g *FUNCT-1K3 f).FUNCT-1K1 x2 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x2)"
      using A7 funct_1_th_13 sorry
    obtain x1 where
      [ty]:"x1 be objectHIDDENM1" and 
      A10: "x1 inHIDDENR3 domRELAT-1K1 f"and A11: "f .FUNCT-1K1 x1 =HIDDENR1 y1"
      using A2 A4 funct_1_def_3 sorry
    have "(g *FUNCT-1K3 f).FUNCT-1K1 x1 =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x1)"
      using A10 funct_1_th_13 sorry
    thus " False "
      using A1 A6 A10 A11 A7 A8 A3 A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_27:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h) & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h implies g =RELAT-1R1 h)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h) & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h implies g =RELAT-1R1 h)) & (( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h) & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h implies g =RELAT-1R1 h) implies f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h) & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h implies g =RELAT-1R1 h)"
    proof-
      have "f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h) implies g =RELAT-1R1 h)"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "f be one-to-oneFUNCT-1V2"
        fix g assume [ty]: "g be FunctionFUNCT-1M1"
        fix h assume [ty]: "h be FunctionFUNCT-1M1"
        assume A2: "rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f"
          and A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h"
          and A4: "f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 g"
            then have A6: "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g & h .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 h"
              using A3 funct_1_def_3 sorry
            have "(f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (g .FUNCT-1K1 x) & (f *FUNCT-1K3 h).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (h .FUNCT-1K1 x)"
              using A3 A5 funct_1_th_13 sorry
            thus "g .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 x"
              using A1 A2 A4 A6 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "g =RELAT-1R1 h"
          using A3 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A7: " for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f & rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f) & domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 h) & f *FUNCT-1K3 g =RELAT-1R1 f *FUNCT-1K3 h implies g =RELAT-1R1 h"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A8: "x1 inHIDDENR3 domRELAT-1K1 f"
          and A9: "x2 inHIDDENR3 domRELAT-1K1 f"
          and A10: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        let ?F = "\<lambda>Lamb1. x1"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A11: "domRELAT-1K1 g =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"and A12: " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies g .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          using funct_1_sch_3 sorry
        have A13: "{}XBOOLE-0K1 inTARSKIR2 {TARSKIK1 {}XBOOLE-0K1 }"
          using tarski_def_1 sorry
        then have A14: "g .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x1"
          using A12 sorry
        then have "rngFUNCT-1K2 g =XBOOLE-0R4 {TARSKIK1 x1}"
          using A11 funct_1_th_4 sorry
        then have A15: "rngFUNCT-1K2 g c=TARSKIR1 domRELAT-1K1 f"
          using A8 zfmisc_1_th_31 sorry
        then have A16: "domRELAT-1K1 (f *FUNCT-1K3 g) =XBOOLE-0R4 domRELAT-1K1 g"
          using relat_1_th_27 sorry
        let ?F = "\<lambda>Lamb1. x2"
        obtain h where
          [ty]:"h be FunctionFUNCT-1M1" and 
          A17: "domRELAT-1K1 h =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"and A18: " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 } implies h .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          using funct_1_sch_3 sorry
        have A19: "h .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 x2"
          using A18 A13 sorry
        then have "rngFUNCT-1K2 h =XBOOLE-0R4 {TARSKIK1 x2}"
          using A17 funct_1_th_4 sorry
        then have A20: "rngFUNCT-1K2 h c=TARSKIR1 domRELAT-1K1 f"
          using A9 zfmisc_1_th_31 sorry
        then have A21: "domRELAT-1K1 (f *FUNCT-1K3 h) =XBOOLE-0R4 domRELAT-1K1 h"
          using relat_1_th_27 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) implies (f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 h).FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g) implies (f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 h).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A22: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 g)"
            then have A23: "g .FUNCT-1K1 x =HIDDENR1 x1"
              using A11 A12 A16 sorry
            have "(f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (g .FUNCT-1K1 x) & (f *FUNCT-1K3 h).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (h .FUNCT-1K1 x)"
              using A11 A17 A16 A21 A22 funct_1_th_12 sorry
            thus "(f *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 h).FUNCT-1K1 x"
              using A10 A11 A18 A16 A22 A23 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "x1 =HIDDENR1 x2"
          using A7 A11 A17 A14 A19 A15 A20 A16 A21 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_28:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (((domRELAT-1K1 f =XBOOLE-0R4 X & domRELAT-1K1 g =XBOOLE-0R4 X) & rngFUNCT-1K2 g c=TARSKIR1 X) & f be one-to-oneFUNCT-1V2) & f *FUNCT-1K3 g =RELAT-1R1 f implies g =RELAT-1R1 idRELAT-1K7 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 X & (domRELAT-1K1 g =XBOOLE-0R4 X & ((rngFUNCT-1K2 g c=TARSKIR1 X & f be one-to-oneFUNCT-1V2) & f *FUNCT-1K3 g =RELAT-1R1 f)) implies g =RELAT-1R1 idRELAT-1K7 X"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 X"
      and A2: "domRELAT-1K1 g =XBOOLE-0R4 X"
      and A3: "rngFUNCT-1K2 g c=TARSKIR1 X & f be one-to-oneFUNCT-1V2"
      and A4: "f *FUNCT-1K3 g =RELAT-1R1 f"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =HIDDENR1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A5: "x inHIDDENR3 X"
        then have "g .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 (g .FUNCT-1K1 x)"
          using A2 A4 funct_1_def_3 funct_1_th_13 sorry
        thus "g .FUNCT-1K1 x =HIDDENR1 x"
          using A1 A3 A5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "g =RELAT-1R1 idRELAT-1K7 X"
      using A2 funct_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_29:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 rngFUNCT-1K2 g & g be one-to-oneFUNCT-1V2 implies domRELAT-1K1 g c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 rngFUNCT-1K2 g & g be one-to-oneFUNCT-1V2 implies domRELAT-1K1 g c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 rngFUNCT-1K2 g"
      and A2: "g be one-to-oneFUNCT-1V2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies y inHIDDENR3 rngFUNCT-1K2 f"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "y inHIDDENR3 domRELAT-1K1 g"
      then have "g .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
        using A1 funct_1_def_3 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"and A5: "g .FUNCT-1K1 y =XBOOLE-0R4 (g *FUNCT-1K3 f).FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 (f .FUNCT-1K1 x) & f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
        using A4 funct_1_th_11 funct_1_th_12 sorry
      then have A6: "y =HIDDENR1 f .FUNCT-1K1 x"
        using A2 A3 A5 sorry
      have "x inHIDDENR3 domRELAT-1K1 f"
        using A4 funct_1_th_11 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 f"
        using A6 funct_1_def_3 sorry
    qed "sorry"
    thus "domRELAT-1K1 g c=TARSKIR1 rngFUNCT-1K2 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_6:
  mlet "X be setHIDDENM2"
"cluster idRELAT-1K7 X as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "idRELAT-1K7 X be one-to-oneFUNCT-1V2"
  proof-
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & x2 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) implies  not (idRELAT-1K7 X .FUNCT-1K1 x1 =XBOOLE-0R4 idRELAT-1K7 X .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A1: "x1 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
        and A2: "x2 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
      have "x1 inHIDDENR3 X"
        using A1 sorry
      then have A3: "idRELAT-1K7 X .FUNCT-1K1 x1 =HIDDENR1 x1"
        using funct_1_th_17 sorry
      have "x2 inHIDDENR3 X"
        using A2 sorry
      thus " not (idRELAT-1K7 X .FUNCT-1K1 x1 =XBOOLE-0R4 idRELAT-1K7 X .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
        using A3 funct_1_th_17 sorry
    qed "sorry"
    thus "idRELAT-1K7 X be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem funct_1_th_31:
" for f be FunctionFUNCT-1M1 holds ( ex g be FunctionFUNCT-1M1 st g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( ex g be FunctionFUNCT-1M1 st g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)) implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume Given: " ex g be FunctionFUNCT-1M1 st g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)"
    then obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A1: "g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)"
       sorry
    have "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 sorry
    then have "rngFUNCT-1K2 f c=TARSKIR1 domRELAT-1K1 g"
      using funct_1_th_15 sorry
    thus "f be one-to-oneFUNCT-1V2"
      using A1 funct_1_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_7:
"cluster emptyXBOOLE-0V1 also-is one-to-oneFUNCT-1V2 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mtheorem funct_1_cl_8:
"cluster one-to-oneFUNCT-1V2 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be one-to-oneFUNCT-1V2"
  proof-
    have " ex tVar10 be FunctionFUNCT-1M1 st tVar10 be one-to-oneFUNCT-1V2"
    proof-
      show " ex tVar10 be FunctionFUNCT-1M1 st tVar10 be one-to-oneFUNCT-1V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be one-to-oneFUNCT-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_9:
  mlet "f be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster f ~RELAT-1K4 as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "f ~RELAT-1K4 be Function-likeFUNCT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f ~RELAT-1K4 & [TARSKIK4 x,y2 ] inHIDDENR3 f ~RELAT-1K4 implies y1 =HIDDENR1 y2"
    proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume A1: "[TARSKIK4 x,y1 ] inHIDDENR3 f ~RELAT-1K4"
        and A2: "[TARSKIK4 x,y2 ] inHIDDENR3 f ~RELAT-1K4"
      have A3: "[TARSKIK4 y2,x ] inHIDDENR3 f"
        using A2 relat_1_def_7 sorry
      then have A4: "y2 inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      have 
        [ty]:"x be setHIDDENM2"
        using tarski_th_1 sorry
      have A5: "x =XBOOLE-0R4 f .FUNCT-1K1 y2"
        using A3 funct_1_def_2 A4 sorry
      have A6: "[TARSKIK4 y1,x ] inHIDDENR3 f"
        using A1 relat_1_def_7 sorry
      then have A7: "y1 inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      then have "x =XBOOLE-0R4 f .FUNCT-1K1 y1"
        using A6 funct_1_def_2 sorry
      thus "y1 =HIDDENR1 y2"
        using A7 A4 A5 funct_1_def_4 sorry
    qed "sorry"
    thus "f ~RELAT-1K4 be Function-likeFUNCT-1V1"
      using funct_1_def_1 sorry
  qed
qed "sorry"

mdef funct_1_def_5 (" _ \<inverse>FUNCT-1K4" [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"assume f be one-to-oneFUNCT-1V2 func f \<inverse>FUNCT-1K4 \<rightarrow> FunctionFUNCT-1M1 equals
  f ~RELAT-1K4"
proof-
  (*coherence*)
    show "f be one-to-oneFUNCT-1V2 implies f ~RELAT-1K4 be FunctionFUNCT-1M1"
    proof(rule impI)
      assume Assume: "f be one-to-oneFUNCT-1V2"
      have A1: "f be one-to-oneFUNCT-1V2"
        using Assume sorry
      show "f ~RELAT-1K4 be FunctionFUNCT-1M1"
        using A1 sorry
    qed
qed "sorry"

mtheorem funct_1_th_32:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds g =RELAT-1R1 f \<inverse>FUNCT-1K4 iff domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x))"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies ( for g be FunctionFUNCT-1M1 holds (g =RELAT-1R1 f \<inverse>FUNCT-1K4 implies domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) & (domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4))"
  proof(rule ballI,rule impI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    show "g =RELAT-1R1 f \<inverse>FUNCT-1K4 implies domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
    proof-
      have "g =RELAT-1R1 f \<inverse>FUNCT-1K4 implies domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f & ( for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x) & (x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x implies y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y))"
      proof(rule impI,rule conjMI,rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
        assume "g =RELAT-1R1 f \<inverse>FUNCT-1K4"
        then have A2: "g =RELAT-1R1 f ~RELAT-1K4"
          using A1 funct_1_def_5 sorry
        thus "domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f"
          using relat_1_th_20 sorry
        fix y assume [ty]: "y be objectHIDDENM1"
        fix x assume [ty]: "x be objectHIDDENM1"
        show "y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y implies x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        proof(rule impMI ,rule impI,rule conjMI)
          assume A3: "y inHIDDENR3 rngFUNCT-1K2 f"
            and A4: "x =HIDDENR1 g .FUNCT-1K1 y"
          have 
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          have "y inTARSKIR2 domRELAT-1K1 g"
            using A2 A3 relat_1_th_20 sorry
          then have "[TARSKIK4 y,x ] inHIDDENR3 g"
            using A4 funct_1_def_2 sorry
          then have A5: "[TARSKIK4 x,y ] inHIDDENR3 f"
            using A2 relat_1_def_7 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f"
            using xtuple_0_def_12 sorry
          thus "y =HIDDENR1 f .FUNCT-1K1 x"
            using A5 funct_1_def_2 sorry
        qed
        assume "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        then have A6: "[TARSKIK4 x,y ] inHIDDENR3 f"
          using funct_1_def_2 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 f"
          using xtuple_0_def_13 sorry
        then have A7: "y inHIDDENR3 domRELAT-1K1 g"
          using A2 relat_1_th_20 sorry
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 g"
          using A2 A6 relat_1_def_7 sorry
        thus "x =HIDDENR1 g .FUNCT-1K1 y"
          using A7 funct_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: "domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 f"
      and A9: " for y be objectHIDDENM1 holds  for x be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f & x =HIDDENR1 g .FUNCT-1K1 y iff x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
    have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 g implies [TARSKIK4 a,b ] inHIDDENR3 f \<inverse>FUNCT-1K4) & ([TARSKIK4 a,b ] inHIDDENR3 f \<inverse>FUNCT-1K4 implies [TARSKIK4 a,b ] inHIDDENR3 g)"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      fix b assume [ty]: "b be objectHIDDENM1"
      show "[TARSKIK4 a,b ] inHIDDENR3 g implies [TARSKIK4 a,b ] inHIDDENR3 f \<inverse>FUNCT-1K4"
      proof(rule impI)
        assume A10: "[TARSKIK4 a,b ] inHIDDENR3 g"
        have 
          [ty]:"b be setHIDDENM2"
          using tarski_th_1 sorry
        have A11: "a inHIDDENR3 domRELAT-1K1 g"
          using xtuple_0_def_12 A10 sorry
        then have "b =XBOOLE-0R4 g .FUNCT-1K1 a"
          using A10 funct_1_def_2 sorry
        then have "b inTARSKIR2 domRELAT-1K1 f & a =HIDDENR1 f .FUNCT-1K1 b"
          using A8 A9 A11 sorry
        then have "[TARSKIK4 b,a ] inHIDDENR3 f"
          using funct_1_def_2 sorry
        then have "[TARSKIK4 a,b ] inHIDDENR3 f ~RELAT-1K4"
          using relat_1_def_7 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 f \<inverse>FUNCT-1K4"
          using A1 funct_1_def_5 sorry
      qed
      assume "[TARSKIK4 a,b ] inHIDDENR3 f \<inverse>FUNCT-1K4"
      then have "[TARSKIK4 a,b ] inHIDDENR3 f ~RELAT-1K4"
        using A1 funct_1_def_5 sorry
      then have A12: "[TARSKIK4 b,a ] inHIDDENR3 f"
        using relat_1_def_7 sorry
      then have A13: "b inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      have 
        [ty]:"a be setHIDDENM2"
        using tarski_th_1 sorry
      have "a =XBOOLE-0R4 f .FUNCT-1K1 b"
        using A12 funct_1_def_2 A13 sorry
      then have "a inTARSKIR2 rngFUNCT-1K2 f & b =HIDDENR1 g .FUNCT-1K1 a"
        using A9 A13 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 g"
        using A8 funct_1_def_2 sorry
    qed "sorry"
    thus "g =RELAT-1R1 f \<inverse>FUNCT-1K4"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_33:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4) & domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4) & domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "f be one-to-oneFUNCT-1V2"
    then have "f \<inverse>FUNCT-1K4 =RELAT-1R1 f ~RELAT-1K4"
      using funct_1_def_5 sorry
    thus "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4) & domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
      using relat_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_34:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & x inHIDDENR3 domRELAT-1K1 f implies x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) & x =HIDDENR1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (x inHIDDENR3 domRELAT-1K1 f implies x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) & x =HIDDENR1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    assume A2: "x inHIDDENR3 domRELAT-1K1 f"
    thus "x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x)"
      using A1 funct_1_th_32 sorry
    thus "x =HIDDENR1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x"
      using A2 funct_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_35:
" for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & y inHIDDENR3 rngFUNCT-1K2 f implies y =HIDDENR1 f .FUNCT-1K1 (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y) & y =HIDDENR1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 y"
proof-
  have " for y be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (y inHIDDENR3 rngFUNCT-1K2 f implies y =HIDDENR1 f .FUNCT-1K1 (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y) & y =HIDDENR1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 y)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    assume A2: "y inHIDDENR3 rngFUNCT-1K2 f"
    thus A3: "y =HIDDENR1 f .FUNCT-1K1 (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y)"
      using A1 funct_1_th_32 sorry
    have "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      using A1 funct_1_th_33 sorry
    thus "y =HIDDENR1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 y"
      using A2 A3 funct_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_36:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    then have A2: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      using funct_1_th_33 sorry
    then have "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
      using relat_1_th_28 sorry
    thus "domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f & rngFUNCT-1K2 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 A2 funct_1_th_33 relat_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_37:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    then have A2: "rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 f"
      using funct_1_th_33 sorry
    then have "domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      using relat_1_th_27 sorry
    thus "domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f & rngFUNCT-1K2 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 A2 funct_1_th_33 relat_1_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_38:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds ((f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 g) & rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies (f .FUNCT-1K1 x =HIDDENR1 y iff g .FUNCT-1K1 y =HIDDENR1 x)) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 g & (rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies (f .FUNCT-1K1 x =HIDDENR1 y iff g .FUNCT-1K1 y =HIDDENR1 x)))) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 g"
      and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g"
      and A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 g implies (f .FUNCT-1K1 x =HIDDENR1 y iff g .FUNCT-1K1 y =HIDDENR1 x)"
    have A5: " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A6: "y inHIDDENR3 domRELAT-1K1 g"
        then have A7: "g .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 f"
          using A2 funct_1_def_3 sorry
        then have "f .FUNCT-1K1 (g .FUNCT-1K1 y) =HIDDENR1 y"
          using A4 A6 sorry
        thus "g .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y"
          using A1 A7 funct_1_th_32 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      using A1 funct_1_th_32 sorry
    thus "g =RELAT-1R1 f \<inverse>FUNCT-1K4"
      using A3 A5 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_39:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f) & f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f)"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f) & f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f)"
  proof(rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) implies (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) implies (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f)"
        then have "x inHIDDENR3 domRELAT-1K1 f"
          using A1 funct_1_th_36 sorry
        thus "(f \<inverse>FUNCT-1K4 *FUNCT-1K3 f).FUNCT-1K1 x =HIDDENR1 x"
          using A1 funct_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) implies (f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) implies (f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 x =HIDDENR1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4)"
        then have "x inHIDDENR3 rngFUNCT-1K2 f"
          using A1 funct_1_th_37 sorry
        thus "(f *FUNCT-1K3 f \<inverse>FUNCT-1K4).FUNCT-1K1 x =HIDDENR1 x"
          using A1 funct_1_th_35 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 funct_1_th_36 sorry
    thus "f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)"
      using A2 funct_1_th_17 sorry
    have "domRELAT-1K1 (f *FUNCT-1K3 f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 funct_1_th_37 sorry
    thus "f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f)"
      using A3 funct_1_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_40:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K4 be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds y1 inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4) & y2 inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4) implies  not (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y1 =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y2 &  not y1 =HIDDENR1 y2)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume A2: "y1 inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
        and A3: "y2 inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      have "y1 inHIDDENR3 rngFUNCT-1K2 f"
        using A1 A2 funct_1_th_32 sorry
      then have A4: "y1 =HIDDENR1 f .FUNCT-1K1 (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y1)"
        using A1 funct_1_th_35 sorry
      have "y2 inHIDDENR3 rngFUNCT-1K2 f"
        using A1 A3 funct_1_th_32 sorry
      thus " not (f \<inverse>FUNCT-1K4 .FUNCT-1K1 y1 =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y2 &  not y1 =HIDDENR1 y2)"
        using A1 A4 funct_1_th_35 sorry
    qed "sorry"
    thus "f \<inverse>FUNCT-1K4 be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_10:
  mlet "f be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster f \<inverse>FUNCT-1K4 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f \<inverse>FUNCT-1K4 be one-to-oneFUNCT-1V2"
    using funct_1_th_40 sorry
qed "sorry"

mtheorem funct_1_cl_11:
  mlet "f be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1", "g be one-to-oneFUNCT-1V2\<bar>FunctionFUNCT-1M1"
"cluster g *FUNCT-1K3 f as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
    using funct_1_th_24 sorry
qed "sorry"

mlemma funct_1_lm_1:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g1 be FunctionFUNCT-1M1 holds  for g2 be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 g2 =XBOOLE-0R4 X & f *FUNCT-1K3 g2 =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g1)) & g1 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 X implies g1 =RELAT-1R1 g2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g1 be FunctionFUNCT-1M1 holds  for g2 be FunctionFUNCT-1M1 holds (rngFUNCT-1K2 g2 =XBOOLE-0R4 X & f *FUNCT-1K3 g2 =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g1)) & g1 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 X implies g1 =RELAT-1R1 g2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g1 assume [ty]: "g1 be FunctionFUNCT-1M1"
    fix g2 assume [ty]: "g2 be FunctionFUNCT-1M1"
    have A1: "g1 *FUNCT-1K3 (f *FUNCT-1K3 g2) =RELAT-1R1 (g1 *FUNCT-1K3 f)*FUNCT-1K3 g2 & g1 *FUNCT-1K3 idRELAT-1K7 (domRELAT-1K1 g1) =RELAT-1R1 g1"
      using relat_1_th_36 relat_1_th_51 sorry
    assume "(rngFUNCT-1K2 g2 =XBOOLE-0R4 X & f *FUNCT-1K3 g2 =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 g1)) & g1 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 X"
    thus "g1 =RELAT-1R1 g2"
      using A1 relat_1_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_41:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g) & g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & (rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g & g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 g & g *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f)"
    have "f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f) & rngFUNCT-1K2 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 domRELAT-1K1 f"
      using A1 funct_1_th_33 funct_1_th_39 sorry
    thus "g =RELAT-1R1 f \<inverse>FUNCT-1K4"
      using A2 funct_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_42:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (f be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 g =XBOOLE-0R4 domRELAT-1K1 f) & f *FUNCT-1K3 g =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & (rngFUNCT-1K2 g =XBOOLE-0R4 domRELAT-1K1 f & f *FUNCT-1K3 g =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f)) implies g =RELAT-1R1 f \<inverse>FUNCT-1K4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "rngFUNCT-1K2 g =XBOOLE-0R4 domRELAT-1K1 f & f *FUNCT-1K3 g =RELAT-1R1 idRELAT-1K7 (rngFUNCT-1K2 f)"
    have "f \<inverse>FUNCT-1K4 *FUNCT-1K3 f =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 f) & domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
      using A1 funct_1_th_33 funct_1_th_39 sorry
    thus "g =RELAT-1R1 f \<inverse>FUNCT-1K4"
      using A2 funct_1_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_43:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K4 =RELAT-1R1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K4 =RELAT-1R1 f"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    then have "rngFUNCT-1K2 f =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
      using funct_1_th_33 sorry
    then have A2: "f *FUNCT-1K3 f \<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (f \<inverse>FUNCT-1K4))"
      using A1 funct_1_th_39 sorry
    have "domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 (f \<inverse>FUNCT-1K4)"
      using A1 funct_1_th_33 sorry
    thus "(f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K4 =RELAT-1R1 f"
      using A1 A2 funct_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_44:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2 implies (g *FUNCT-1K3 f)\<inverse>FUNCT-1K4 =RELAT-1R1 f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 & g be one-to-oneFUNCT-1V2 implies (g *FUNCT-1K3 f)\<inverse>FUNCT-1K4 =RELAT-1R1 f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "g be one-to-oneFUNCT-1V2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f) iff y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f) implies y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)) & (y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4) implies y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f))"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f) implies y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
        proof(rule impI)
          assume "y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A3: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"and A4: "y =HIDDENR1 (g *FUNCT-1K3 f).FUNCT-1K1 x"
            using funct_1_def_3 sorry
          have A5: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
            using A3 funct_1_th_11 sorry
          have A6: "y =HIDDENR1 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A3 A4 funct_1_th_12 sorry
          then have "y inHIDDENR3 rngFUNCT-1K2 g"
            using A5 funct_1_def_3 sorry
          then have A7: "y inHIDDENR3 domRELAT-1K1 (g \<inverse>FUNCT-1K4)"
            using A2 funct_1_th_32 sorry
          have A8: "x inHIDDENR3 domRELAT-1K1 f"
            using A3 funct_1_th_11 sorry
          have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 (g .FUNCT-1K1 (f .FUNCT-1K1 x)) =HIDDENR1 (g \<inverse>FUNCT-1K4 *FUNCT-1K3 g).FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A5 funct_1_th_13 sorry
          also have "... = idRELAT-1K7 (domRELAT-1K1 g) .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A2 funct_1_th_39 sorry
          also have "... = f .FUNCT-1K1 x"
            using A5 funct_1_th_17 sorry
          finally have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 (g .FUNCT-1K1 (f .FUNCT-1K1 x)) =HIDDENR1 f .FUNCT-1K1 x"
             sorry
          then have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
            using A8 A6 funct_1_def_3 sorry
          then have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
            using A1 funct_1_th_32 sorry
          thus "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
            using A7 funct_1_th_11 sorry
        qed
        assume A9: "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
        then have "y inHIDDENR3 domRELAT-1K1 (g \<inverse>FUNCT-1K4)"
          using funct_1_th_11 sorry
        then have "y inHIDDENR3 rngFUNCT-1K2 g"
          using A2 funct_1_th_32 sorry
        then obtain z where
          [ty]:"z be objectHIDDENM1" and 
          A10: "z inHIDDENR3 domRELAT-1K1 g"and A11: "y =HIDDENR1 g .FUNCT-1K1 z"
          using funct_1_def_3 sorry
        have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
          using A9 funct_1_th_11 sorry
        then have "g \<inverse>FUNCT-1K4 .FUNCT-1K1 (g .FUNCT-1K1 z) inTARSKIR2 rngFUNCT-1K2 f"
          using A1 A11 funct_1_th_32 sorry
        then have "(g \<inverse>FUNCT-1K4 *FUNCT-1K3 g).FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
          using A10 funct_1_th_13 sorry
        then have "idRELAT-1K7 (domRELAT-1K1 g) .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
          using A2 funct_1_th_39 sorry
        then have "z inHIDDENR3 rngFUNCT-1K2 f"
          using A10 funct_1_th_17 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A12: "x inHIDDENR3 domRELAT-1K1 f & z =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) & y =HIDDENR1 (g *FUNCT-1K3 f).FUNCT-1K1 x"
          using A10 A11 A12 funct_1_th_11 funct_1_th_13 sorry
        thus "y inHIDDENR3 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
          using funct_1_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A13: "rngFUNCT-1K2 (g *FUNCT-1K3 f) =XBOOLE-0R4 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)) iff x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)) implies x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)) & (x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies x inHIDDENR3 domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)))"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)) implies x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
          using funct_1_th_11 sorry
        assume A14: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
        then have "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
          using funct_1_def_3 sorry
        thus "x inHIDDENR3 domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f))"
          using A13 A14 funct_1_th_11 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A15: "domRELAT-1K1 ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)) =XBOOLE-0R4 domRELAT-1K1 (g *FUNCT-1K3 f)"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f) implies ((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A16: "x inHIDDENR3 domRELAT-1K1 (g *FUNCT-1K3 f)"
        then have A17: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 g"
          using funct_1_th_11 sorry
        have "(g *FUNCT-1K3 f).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
          using A16 funct_1_def_3 sorry
        then have A18: "g .FUNCT-1K1 (f .FUNCT-1K1 x) inTARSKIR2 domRELAT-1K1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)"
          using A13 A16 funct_1_th_12 sorry
        have A19: "x inHIDDENR3 domRELAT-1K1 f"
          using A16 funct_1_th_11 sorry
        have "((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4).FUNCT-1K1 ((g *FUNCT-1K3 f).FUNCT-1K1 x)"
          using A15 A16 funct_1_th_12 sorry
        also have "... = (f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4).FUNCT-1K1 (g .FUNCT-1K1 (f .FUNCT-1K1 x))"
          using A16 funct_1_th_12 sorry
        also have "... = f \<inverse>FUNCT-1K4 .FUNCT-1K1 (g \<inverse>FUNCT-1K4 .FUNCT-1K1 (g .FUNCT-1K1 (f .FUNCT-1K1 x)))"
          using A18 funct_1_th_12 sorry
        also have "... = f \<inverse>FUNCT-1K4 .FUNCT-1K1 ((g \<inverse>FUNCT-1K4 *FUNCT-1K3 g).FUNCT-1K1 (f .FUNCT-1K1 x))"
          using A17 funct_1_th_13 sorry
        also have "... = f \<inverse>FUNCT-1K4 .FUNCT-1K1 (idRELAT-1K7 (domRELAT-1K1 g) .FUNCT-1K1 (f .FUNCT-1K1 x))"
          using A2 funct_1_th_39 sorry
        also have "... = f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A17 funct_1_th_17 sorry
        also have "... = x"
          using A1 A19 funct_1_th_34 sorry
        finally show "((f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f)).FUNCT-1K1 x =HIDDENR1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "(f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4)*FUNCT-1K3 (g *FUNCT-1K3 f) =RELAT-1R1 idRELAT-1K7 (domRELAT-1K1 (g *FUNCT-1K3 f))"
      using A15 funct_1_th_17 sorry
    thus "(g *FUNCT-1K3 f)\<inverse>FUNCT-1K4 =RELAT-1R1 f \<inverse>FUNCT-1K4 *FUNCT-1K3 g \<inverse>FUNCT-1K4"
      using A1 A2 A13 funct_1_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_45:
" for X be setHIDDENM2 holds (idRELAT-1K7 X)\<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 X"
proof-
  have " for X be setHIDDENM2 holds (idRELAT-1K7 X)\<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X"
       sorry
    then have A1: "(idRELAT-1K7 X)\<inverse>FUNCT-1K4 *FUNCT-1K3 idRELAT-1K7 X =RELAT-1R1 idRELAT-1K7 X"
      using funct_1_th_39 sorry
    have "domRELAT-1K1 ((idRELAT-1K7 X)\<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 (idRELAT-1K7 X) & rngFUNCT-1K2 (idRELAT-1K7 X) =XBOOLE-0R4 X"
      using funct_1_th_33 sorry
    thus "(idRELAT-1K7 X)\<inverse>FUNCT-1K4 =RELAT-1R1 idRELAT-1K7 X"
      using A1 funct_1_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_12:
  mlet "f be FunctionFUNCT-1M1", "X be setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "f  |RELAT-1K8 X be Function-likeFUNCT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 f  |RELAT-1K8 X & [TARSKIK4 x,y2 ] inHIDDENR3 f  |RELAT-1K8 X implies y1 =HIDDENR1 y2"
    proof(rule ballI,rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume "[TARSKIK4 x,y1 ] inHIDDENR3 f  |RELAT-1K8 X & [TARSKIK4 x,y2 ] inHIDDENR3 f  |RELAT-1K8 X"
      then have "[TARSKIK4 x,y1 ] inHIDDENR3 f & [TARSKIK4 x,y2 ] inHIDDENR3 f"
        using relat_1_def_11 sorry
      thus "y1 =HIDDENR1 y2"
        using funct_1_def_1 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 X be Function-likeFUNCT-1V1"
      using funct_1_def_1 sorry
  qed
qed "sorry"

mtheorem funct_1_th_46:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x) implies g =RELAT-1R1 f  |RELAT-1K8 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x) implies g =RELAT-1R1 f  |RELAT-1K8 X"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 g implies x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 f) & (x inHIDDENR3 X implies ([TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 g implies x inHIDDENR3 X & [TARSKIK4 x,y ] inHIDDENR3 f"
      proof(rule impI,rule conjMI)
        assume A3: "[TARSKIK4 x,y ] inHIDDENR3 g"
        then have A4: "x inHIDDENR3 domRELAT-1K1 g"
          using xtuple_0_def_12 sorry
        thus "x inHIDDENR3 X"
          using A1 xboole_0_def_4 sorry
        have A5: "x inHIDDENR3 domRELAT-1K1 f"
          using A1 A4 xboole_0_def_4 sorry
        obtain yy where 
          [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
          using tarski_th_1 sorry
        have "yy =HIDDENR1 g .FUNCT-1K1 x"
          using A3 A4 funct_1_def_2 sorry
        also have "... = f .FUNCT-1K1 x"
          using A2 A4 sorry
        finally have "yy =HIDDENR1 f .FUNCT-1K1 x"
           sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A5 funct_1_def_2 sorry
      qed
      assume A6: "x inHIDDENR3 X"
      assume A7: "[TARSKIK4 x,y ] inHIDDENR3 f"
      then have A8: "x inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      then have A9: "x inHIDDENR3 domRELAT-1K1 g"
        using A1 A6 xboole_0_def_4 sorry
      obtain yy where 
        [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
        using tarski_th_1 sorry
      have "yy =HIDDENR1 f .FUNCT-1K1 x"
        using A7 A8 funct_1_def_2 sorry
      also have "... = g .FUNCT-1K1 x"
        using A2 A9 sorry
      finally have "yy =HIDDENR1 g .FUNCT-1K1 x"
         sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 g"
        using A9 funct_1_def_2 sorry
    qed "sorry"
    thus "g =RELAT-1R1 f  |RELAT-1K8 X"
      using relat_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_47:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    let ?g = "f  |RELAT-1K8 X"
    assume A1: "x inHIDDENR3 domRELAT-1K1 ?g"
    have "domRELAT-1K1 ?g =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    then have A2: "x inHIDDENR3 domRELAT-1K1 f"
      using A1 xboole_0_def_4 sorry
    have "?g c=RELAT-1R2 f & [TARSKIK4 x,?g .FUNCT-1K1 x ] inHIDDENR3 ?g"
      using A1 funct_1_def_2 relat_1_th_59 sorry
    thus "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A2 funct_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_48:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
    then have "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    thus "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using funct_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_49:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 X implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 X implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 X"
    show "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    proof-
      have cases: "x inHIDDENR3 domRELAT-1K1 f or  not x inHIDDENR3 domRELAT-1K1 f"
         sorry
      have case1: "x inHIDDENR3 domRELAT-1K1 f implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 f"
        then have "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
          using A1 relat_1_th_57 sorry
        thus "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
          using funct_1_th_47 sorry
      qed
      have case2: " not x inHIDDENR3 domRELAT-1K1 f implies (f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
      proof(rule impI)
        assume A2: " not x inHIDDENR3 domRELAT-1K1 f"
        then have " not x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
          using relat_1_th_57 sorry
        then have "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
        also have "... = f .FUNCT-1K1 x"
          using A2 funct_1_def_2 sorry
        finally show "(f  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_50:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (f  |RELAT-1K8 X)"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X implies f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (f  |RELAT-1K8 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
      and A2: "x inHIDDENR3 X"
    have "x inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
      using A1 A2 xboole_0_def_4 sorry
    then have A3: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    have "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A2 funct_1_th_49 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (f  |RELAT-1K8 X)"
      using A3 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_51:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 Y implies (f  |RELAT-1K8 X) |RELAT-1K8 Y =RELAT-1R1 f  |RELAT-1K8 X & (f  |RELAT-1K8 Y) |RELAT-1K8 X =RELAT-1R1 f  |RELAT-1K8 X"
  using relat_1_th_73 relat_1_th_74 sorry

mtheorem funct_1_th_52:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f  |RELAT-1K8 X be one-to-oneFUNCT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f  |RELAT-1K8 X be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) & x2 inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies  not ((f  |RELAT-1K8 X).FUNCT-1K1 x1 =XBOOLE-0R4 (f  |RELAT-1K8 X).FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A2: "x1 inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
        and A3: "x2 inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      have "x1 inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
        using A2 relat_1_th_61 sorry
      then have A4: "x1 inHIDDENR3 domRELAT-1K1 f"
        using xboole_0_def_4 sorry
      have "x2 inHIDDENR3 domRELAT-1K1 f /\\XBOOLE-0K3 X"
        using A3 relat_1_th_61 sorry
      then have A5: "x2 inHIDDENR3 domRELAT-1K1 f"
        using xboole_0_def_4 sorry
      have "(f  |RELAT-1K8 X).FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x1 & (f  |RELAT-1K8 X).FUNCT-1K1 x2 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        using A2 A3 funct_1_th_47 sorry
      thus " not ((f  |RELAT-1K8 X).FUNCT-1K1 x1 =XBOOLE-0R4 (f  |RELAT-1K8 X).FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
        using A1 A4 A5 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 X be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_13:
  mlet "Y be setHIDDENM2", "f be FunctionFUNCT-1M1"
"cluster Y  |`RELAT-1K9 f as-term-is Function-likeFUNCT-1V1"
proof
(*coherence*)
  show "Y  |`RELAT-1K9 f be Function-likeFUNCT-1V1"
  proof-
    have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [TARSKIK4 x,y1 ] inHIDDENR3 Y  |`RELAT-1K9 f & [TARSKIK4 x,y2 ] inHIDDENR3 Y  |`RELAT-1K9 f implies y1 =HIDDENR1 y2"
    proof(rule ballI,rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume "[TARSKIK4 x,y1 ] inHIDDENR3 Y  |`RELAT-1K9 f & [TARSKIK4 x,y2 ] inHIDDENR3 Y  |`RELAT-1K9 f"
      then have "[TARSKIK4 x,y1 ] inHIDDENR3 f & [TARSKIK4 x,y2 ] inHIDDENR3 f"
        using relat_1_def_12 sorry
      thus "y1 =HIDDENR1 y2"
        using funct_1_def_1 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 f be Function-likeFUNCT-1V1"
      using funct_1_def_1 sorry
  qed
qed "sorry"

mtheorem funct_1_th_53:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds g =RELAT-1R1 Y  |`RELAT-1K9 f iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x)"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds (g =RELAT-1R1 Y  |`RELAT-1K9 f implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x inTARSKIR2 Y implies x inHIDDENR3 domRELAT-1K1 g))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x) implies g =RELAT-1R1 Y  |`RELAT-1K9 f)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    show "g =RELAT-1R1 Y  |`RELAT-1K9 f implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x inTARSKIR2 Y implies x inHIDDENR3 domRELAT-1K1 g))) & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "g =RELAT-1R1 Y  |`RELAT-1K9 f"
      show " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f implies (f .FUNCT-1K1 x inTARSKIR2 Y implies x inHIDDENR3 domRELAT-1K1 g))"
      proof(rule ballI,rule conjMI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
        proof(rule impI,rule conjMI)
          assume "x inHIDDENR3 domRELAT-1K1 g"
          then have A2: "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
            using funct_1_def_2 sorry
          then have A3: "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 f"
            using A1 relat_1_def_12 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f"
            using xtuple_0_def_12 sorry
          then have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
            using A3 funct_1_def_2 sorry
          thus "f .FUNCT-1K1 x inTARSKIR2 Y"
            using A1 A2 relat_1_def_12 sorry
        qed
        assume "x inHIDDENR3 domRELAT-1K1 f"
        then have A4: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
          using funct_1_def_2 sorry
        assume "f .FUNCT-1K1 x inTARSKIR2 Y"
        then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 g"
          using A1 A4 relat_1_def_12 sorry
        thus "x inHIDDENR3 domRELAT-1K1 g"
          using xtuple_0_def_12 sorry
      qed "sorry"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 g"
      then have "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
        using funct_1_def_2 sorry
      then have A5: "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 f"
        using A1 relat_1_def_12 sorry
      then have "x inHIDDENR3 domRELAT-1K1 f"
        using xtuple_0_def_12 sorry
      thus "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
        using A5 funct_1_def_2 sorry
    qed "sorry"
    assume A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
      and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 g implies y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 f) & (y inHIDDENR3 Y implies ([TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 g))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 g implies y inHIDDENR3 Y & [TARSKIK4 x,y ] inHIDDENR3 f"
      proof(rule impI,rule conjMI)
        assume A8: "[TARSKIK4 x,y ] inHIDDENR3 g"
        then have A9: "x inHIDDENR3 domRELAT-1K1 g"
          using xtuple_0_def_12 sorry
        obtain yy where 
          [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
          using tarski_th_1 sorry
        have A10: "yy =HIDDENR1 g .FUNCT-1K1 x"
          using A8 funct_1_def_2 A9 sorry
        also have "... = f .FUNCT-1K1 x"
          using A7 A9 sorry
        finally have "yy =HIDDENR1 f .FUNCT-1K1 x"
           sorry
        thus "y inHIDDENR3 Y"
          using A6 A9 sorry
        have "x inHIDDENR3 domRELAT-1K1 f"
          using A6 A9 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A10 funct_1_def_2 sorry
      qed
      assume A11: "y inHIDDENR3 Y"
      assume A12: "[TARSKIK4 x,y ] inHIDDENR3 f"
      then have A13: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_th_1 sorry
      have "x inHIDDENR3 domRELAT-1K1 f"
        using A12 xtuple_0_def_12 sorry
      then have A14: "x inHIDDENR3 domRELAT-1K1 g"
        using A6 A11 A13 sorry
      then have "y =HIDDENR1 g .FUNCT-1K1 x"
        using A7 A13 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 g"
        using A14 funct_1_def_2 sorry
    qed "sorry"
    thus "g =RELAT-1R1 Y  |`RELAT-1K9 f"
      using relat_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_54:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
  using funct_1_th_53 sorry

mtheorem funct_1_th_55:
" for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) implies (Y  |`RELAT-1K9 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
  using funct_1_th_53 sorry

mtheorem funct_1_th_56:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 (Y  |`RELAT-1K9 f) c=TARSKIR1 domRELAT-1K1 f"
  using funct_1_th_53 sorry

mtheorem funct_1_th_57:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 Y implies Y  |`RELAT-1K9 (X  |`RELAT-1K9 f) =RELAT-1R1 X  |`RELAT-1K9 f & X  |`RELAT-1K9 (Y  |`RELAT-1K9 f) =RELAT-1R1 X  |`RELAT-1K9 f"
  using relat_1_th_98 relat_1_th_99 sorry

mtheorem funct_1_th_58:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies Y  |`RELAT-1K9 f be one-to-oneFUNCT-1V2"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies Y  |`RELAT-1K9 f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) & x2 inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)) & (Y  |`RELAT-1K9 f).FUNCT-1K1 x1 =XBOOLE-0R4 (Y  |`RELAT-1K9 f).FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A2: "x1 inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f) & x2 inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"
        and A3: "(Y  |`RELAT-1K9 f).FUNCT-1K1 x1 =XBOOLE-0R4 (Y  |`RELAT-1K9 f).FUNCT-1K1 x2"
      have A4: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"
        using A2 funct_1_th_53 sorry
      have "(Y  |`RELAT-1K9 f).FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x1 & (Y  |`RELAT-1K9 f).FUNCT-1K1 x2 =XBOOLE-0R4 f .FUNCT-1K1 x2"
        using A2 funct_1_th_53 sorry
      thus "x1 =HIDDENR1 x2"
        using A1 A3 A4 sorry
    qed "sorry"
    thus "Y  |`RELAT-1K9 f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1K5(" _ .:FUNCT-1K5  _ " [200,200]200) where
  "f .:FUNCT-1K5 X \<equiv> f .:RELAT-1K10 X"

mtheorem funct_1_def_6:
  mlet "f be FunctionFUNCT-1M1", "X be setHIDDENM2"
"redefine func f .:FUNCT-1K5 X \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x)"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 f .:FUNCT-1K5 X iff ( for y be objectHIDDENM1 holds y inHIDDENR3 it iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x))"
  proof-
    have " for Y be setHIDDENM2 holds (Y =XBOOLE-0R4 f .:RELAT-1K10 X implies ( for y be objectHIDDENM1 holds (y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x))) & (( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 Y))) & (( for y be objectHIDDENM1 holds y inHIDDENR3 Y iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x)) implies Y =HIDDENR1 f .:RELAT-1K10 X)"
    proof(rule ballI,rule conjMI,rule impI)
      fix Y assume [ty]: "Y be setHIDDENM2"
      show "Y =XBOOLE-0R4 f .:RELAT-1K10 X implies ( for y be objectHIDDENM1 holds (y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x))) & (( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x) implies y inHIDDENR3 Y))"
      proof(rule impI,rule ballI,rule conjMI,rule impI)
        assume A1: "Y =XBOOLE-0R4 f .:RELAT-1K10 X"
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x))"
        proof(rule impI)
          assume "y inHIDDENR3 Y"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "[TARSKIK4 x,y ] inHIDDENR3 f"and A3: "x inHIDDENR3 X"
            using A1 relat_1_def_13 sorry
          have 
            [ty]:"x be objectHIDDENM1"
             sorry
          show " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x)"
          proof(rule bexI[of _ "x"],rule conjMI,rule conjMI)
            show A4: "x inHIDDENR3 domRELAT-1K1 f"
              using A2 xtuple_0_def_12 sorry
            obtain yy where 
              [ty]:"yy be setHIDDENM2" and yyDef:"yy = y"
              using tarski_th_1 sorry
            show "x inHIDDENR3 X"
              using A3 sorry
            have "yy =XBOOLE-0R4 f .FUNCT-1K1 x"
              using A2 A4 funct_1_def_2 sorry
            thus "y =HIDDENR1 f .FUNCT-1K1 x"
               sorry
          qed "sorry"
        qed
        assume Given: " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A5: "x inHIDDENR3 domRELAT-1K1 f"and A6: "x inHIDDENR3 X"and A7: "y =HIDDENR1 f .FUNCT-1K1 x"
           sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 f"
          using A5 A7 funct_1_def_2 sorry
        thus "y inHIDDENR3 Y"
          using A1 A6 relat_1_def_13 sorry
      qed "sorry"
      assume A8: " for y be objectHIDDENM1 holds y inHIDDENR3 Y iff ( ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 X) & y =HIDDENR1 f .FUNCT-1K1 x)"
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & x inHIDDENR3 X)) & (( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & x inHIDDENR3 X) implies y inHIDDENR3 Y)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & x inHIDDENR3 X)"
        proof(rule impI)
          assume "y inHIDDENR3 Y"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A9: "x inHIDDENR3 domRELAT-1K1 f"and A10: "x inHIDDENR3 X"and A11: "y =HIDDENR1 f .FUNCT-1K1 x"
            using A8 sorry
          have 
            [ty]:"x be objectHIDDENM1"
             sorry
          show " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & x inHIDDENR3 X"
          proof(rule bexI[of _ "x"],rule conjMI)
            show "[TARSKIK4 x,y ] inHIDDENR3 f"
              using A9 A11 funct_1_def_2 sorry
            show "x inHIDDENR3 X"
              using A10 sorry
          qed "sorry"
        qed
        assume Given: " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & x inHIDDENR3 X"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A12: "[TARSKIK4 x,y ] inHIDDENR3 f"and A13: "x inHIDDENR3 X"
           sorry
        have "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using A12 funct_1_th_1 sorry
        thus "y inHIDDENR3 Y"
          using A8 A13 sorry
      qed "sorry"
      thus "Y =HIDDENR1 f .:RELAT-1K10 X"
        using relat_1_def_13 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_59:
" for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
proof-
  have " for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 domRELAT-1K1 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x} iff y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x} implies y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }) & (y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x } implies y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x})"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x} implies y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
        proof(rule impI)
          assume "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x}"
          then obtain z where
            [ty]:"z be objectHIDDENM1" and 
            "z inHIDDENR3 domRELAT-1K1 f"and A2: "z inHIDDENR3 {TARSKIK1 x}"and A3: "y =HIDDENR1 f .FUNCT-1K1 z"
            using funct_1_def_6 sorry
          have "z =HIDDENR1 x"
            using A2 tarski_def_1 sorry
          thus "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
            using A3 tarski_def_1 sorry
        qed
        assume "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
        then have A4: "y =HIDDENR1 f .FUNCT-1K1 x"
          using tarski_def_1 sorry
        have "x inHIDDENR3 {TARSKIK1 x}"
          using tarski_def_1 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK1 x}"
          using A1 A4 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_60:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies f .:FUNCT-1K5 {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x1,f .FUNCT-1K1 x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies f .:FUNCT-1K5 {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x1,f .FUNCT-1K1 x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 } iff y =HIDDENR1 f .FUNCT-1K1 x1 or y =HIDDENR1 f .FUNCT-1K1 x2"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 } implies y =HIDDENR1 f .FUNCT-1K1 x1 or y =HIDDENR1 f .FUNCT-1K1 x2) & (y =HIDDENR1 f .FUNCT-1K1 x1 or y =HIDDENR1 f .FUNCT-1K1 x2 implies y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 })"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A2: "x1 inHIDDENR3 {TARSKIK2 x1,x2 } & x2 inHIDDENR3 {TARSKIK2 x1,x2 }"
          using tarski_def_2 sorry
        show "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 } implies y =HIDDENR1 f .FUNCT-1K1 x1 or y =HIDDENR1 f .FUNCT-1K1 x2"
        proof-
          have "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 } implies  not ( not y =HIDDENR1 f .FUNCT-1K1 x1 &  not y =HIDDENR1 f .FUNCT-1K1 x2)"
          proof(rule impI)
            assume "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 }"
            then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 {TARSKIK2 x1,x2 }) & y =HIDDENR1 f .FUNCT-1K1 x"
              using funct_1_def_6 sorry
            thus " not ( not y =HIDDENR1 f .FUNCT-1K1 x1 &  not y =HIDDENR1 f .FUNCT-1K1 x2)"
              using tarski_def_2 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        assume "y =HIDDENR1 f .FUNCT-1K1 x1 or y =HIDDENR1 f .FUNCT-1K1 x2"
        thus "y inHIDDENR3 f .:FUNCT-1K5 {TARSKIK2 x1,x2 }"
          using A1 A2 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f .:FUNCT-1K5 {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK2 f .FUNCT-1K1 x1,f .FUNCT-1K1 x2 }"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_61:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f).:FUNCT-1K5 X c=TARSKIR1 f .:FUNCT-1K5 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f).:FUNCT-1K5 X c=TARSKIR1 f .:FUNCT-1K5 X"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X implies y inHIDDENR3 f .:FUNCT-1K5 X"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"and A2: "x inHIDDENR3 X"and A3: "y =HIDDENR1 (Y  |`RELAT-1K9 f).FUNCT-1K1 x"
        using funct_1_def_6 sorry
      have "y =HIDDENR1 f .FUNCT-1K1 x & x inHIDDENR3 domRELAT-1K1 f"
        using A1 A3 funct_1_th_53 sorry
      thus "y inHIDDENR3 f .:FUNCT-1K5 X"
        using A2 funct_1_def_6 sorry
    qed "sorry"
    thus "(Y  |`RELAT-1K9 f).:FUNCT-1K5 X c=TARSKIR1 f .:FUNCT-1K5 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_62:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have A2: "f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2 c=TARSKIR1 f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2)"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2 implies y inHIDDENR3 f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A3: "y inHIDDENR3 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
        then have "y inHIDDENR3 f .:FUNCT-1K5 X1"
          using xboole_0_def_4 sorry
        then obtain x1 where
          [ty]:"x1 be objectHIDDENM1" and 
          A4: "x1 inHIDDENR3 domRELAT-1K1 f"and A5: "x1 inHIDDENR3 X1"and A6: "y =HIDDENR1 f .FUNCT-1K1 x1"
          using funct_1_def_6 sorry
        have "y inHIDDENR3 f .:FUNCT-1K5 X2"
          using A3 xboole_0_def_4 sorry
        then obtain x2 where
          [ty]:"x2 be objectHIDDENM1" and 
          A7: "x2 inHIDDENR3 domRELAT-1K1 f"and A8: "x2 inHIDDENR3 X2"and A9: "y =HIDDENR1 f .FUNCT-1K1 x2"
          using funct_1_def_6 sorry
        have "x1 =HIDDENR1 x2"
          using A1 A4 A6 A7 A9 sorry
        then have "x1 inHIDDENR3 X1 /\\XBOOLE-0K3 X2"
          using A5 A8 xboole_0_def_4 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2)"
          using A4 A6 funct_1_def_6 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2 c=TARSKIR1 f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2)"
        using tarski_def_3 sorry
    qed
    have "f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) c=TARSKIR1 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
      using relat_1_th_121 sorry
    thus "f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_63:
" for f be FunctionFUNCT-1M1 holds ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2) implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 /\\XBOOLE-0K3 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 /\\XBOOLE-0K3 f .:FUNCT-1K5 X2"
    have "( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st ((x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) & x1 <>HIDDENR2 x2) implies  False "
    proof(rule impI)
      assume Given: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st ((x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) & x1 <>HIDDENR2 x2"
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A2: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"and A3: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"and A4: "x1 <>HIDDENR2 x2"
         sorry
      have A5: "f .:FUNCT-1K5 ({TARSKIK1 x1} /\\XBOOLE-0K3 {TARSKIK1 x2}) =XBOOLE-0R4 f .:FUNCT-1K5 {TARSKIK1 x1} /\\XBOOLE-0K3 f .:FUNCT-1K5 {TARSKIK1 x2}"
        using A1 sorry
      have "{TARSKIK1 x1} missesSUBSET-1R1 {TARSKIK1 x2}"
        using A4 zfmisc_1_th_11 sorry
      then have A6: "{TARSKIK1 x1} /\\XBOOLE-0K3 {TARSKIK1 x2} =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have "ImRELAT-1K12(f,x1) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x1 } & ImRELAT-1K12(f,x2) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x2 }"
        using A2 funct_1_th_59 sorry
      thus " False "
        using A3 A6 A5 sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_64:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have A2: "f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) c=TARSKIR1 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) implies y inHIDDENR3 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2)"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 domRELAT-1K1 f"and A4: "x inHIDDENR3 X1 \\SUBSET-1K6 X2"and A5: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have A6: " not x inHIDDENR3 X2"
          using A4 xboole_0_def_5 sorry
        have A7: "y inHIDDENR3 f .:FUNCT-1K5 X2 implies  False "
        proof(rule impI)
          assume "y inHIDDENR3 f .:FUNCT-1K5 X2"
          then have " ex z be objectHIDDENM1 st (z inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 X2) & y =HIDDENR1 f .FUNCT-1K1 z"
            using funct_1_def_6 sorry
          thus " False "
            using A1 A3 A5 A6 sorry
        qed
        have "y inHIDDENR3 f .:FUNCT-1K5 X1"
          using A3 A4 A5 funct_1_def_6 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
          using A7 xboole_0_def_5 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) c=TARSKIR1 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
        using tarski_def_3 sorry
    qed
    have "f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2 c=TARSKIR1 f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2)"
      using relat_1_th_122 sorry
    thus "f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_65:
" for f be FunctionFUNCT-1M1 holds ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2) implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds f .:FUNCT-1K5 (X1 \\SUBSET-1K6 X2) =XBOOLE-0R4 f .:FUNCT-1K5 X1 \\SUBSET-1K6 f .:FUNCT-1K5 X2"
    have "( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st ((x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) & x1 <>HIDDENR2 x2) implies  False "
    proof(rule impI)
      assume Given: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st ((x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) & x1 <>HIDDENR2 x2"
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A2: "x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f"and A3: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"and A4: "x1 <>HIDDENR2 x2"
         sorry
      have A5: "f .:FUNCT-1K5 ({TARSKIK1 x1} \\SUBSET-1K6 {TARSKIK1 x2}) =XBOOLE-0R4 f .:FUNCT-1K5 {TARSKIK1 x1}"
        using A4 zfmisc_1_th_14 sorry
      have A6: "f .:FUNCT-1K5 ({TARSKIK1 x1} \\SUBSET-1K6 {TARSKIK1 x2}) =XBOOLE-0R4 f .:FUNCT-1K5 {TARSKIK1 x1} \\SUBSET-1K6 f .:FUNCT-1K5 {TARSKIK1 x2}"
        using A1 sorry
      have "ImRELAT-1K12(f,x1) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x1 } & ImRELAT-1K12(f,x2) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x2 }"
        using A2 funct_1_th_59 sorry
      thus " False "
        using A3 A5 A6 xboole_1_th_37 sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_66:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X missesXBOOLE-0R1 Y & f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 X missesXBOOLE-0R1 f .:FUNCT-1K5 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  not ((X missesXBOOLE-0R1 Y & f be one-to-oneFUNCT-1V2) &  not f .:FUNCT-1K5 X missesXBOOLE-0R1 f .:FUNCT-1K5 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 X missesXBOOLE-0R1 f .:FUNCT-1K5 Y"
    proof(rule impI)
      assume "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & f be one-to-oneFUNCT-1V2"
      then have "f .:FUNCT-1K5 (X /\\XBOOLE-0K3 Y) =XBOOLE-0R4 {}XBOOLE-0K1 & f .:FUNCT-1K5 (X /\\XBOOLE-0K3 Y) =XBOOLE-0R4 f .:FUNCT-1K5 X /\\XBOOLE-0K3 f .:FUNCT-1K5 Y"
        using funct_1_th_62 sorry
      thus "f .:FUNCT-1K5 X missesXBOOLE-0R1 f .:FUNCT-1K5 Y"
         sorry
    qed
    thus " not ((X missesXBOOLE-0R1 Y & f be one-to-oneFUNCT-1V2) &  not f .:FUNCT-1K5 X missesXBOOLE-0R1 f .:FUNCT-1K5 Y)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_67:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f).:FUNCT-1K5 X =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (Y  |`RELAT-1K9 f).:FUNCT-1K5 X =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X iff y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X implies y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X) & (y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X implies y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X implies y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
        proof(rule impI)
          assume "y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"and A2: "x inHIDDENR3 X"and A3: "y =HIDDENR1 (Y  |`RELAT-1K9 f).FUNCT-1K1 x"
            using funct_1_def_6 sorry
          have A4: "y =HIDDENR1 f .FUNCT-1K1 x"
            using A1 A3 funct_1_th_53 sorry
          then have A5: "y inHIDDENR3 Y"
            using A1 funct_1_th_53 sorry
          have "x inHIDDENR3 domRELAT-1K1 f"
            using A1 funct_1_th_53 sorry
          then have "y inHIDDENR3 f .:FUNCT-1K5 X"
            using A2 A4 funct_1_def_6 sorry
          thus "y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
            using A5 xboole_0_def_4 sorry
        qed
        assume A6: "y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
        then have "y inHIDDENR3 f .:FUNCT-1K5 X"
          using xboole_0_def_4 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A7: "x inHIDDENR3 domRELAT-1K1 f"and A8: "x inHIDDENR3 X"and A9: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have "y inHIDDENR3 Y"
          using A6 xboole_0_def_4 sorry
        then have A10: "x inHIDDENR3 domRELAT-1K1 (Y  |`RELAT-1K9 f)"
          using A7 A9 funct_1_th_53 sorry
        then have "(Y  |`RELAT-1K9 f).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
          using funct_1_th_53 sorry
        thus "y inHIDDENR3 (Y  |`RELAT-1K9 f).:FUNCT-1K5 X"
          using A8 A9 A10 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(Y  |`RELAT-1K9 f).:FUNCT-1K5 X =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1K6(" _ \<inverse>FUNCT-1K6  _ " [228,228]228) where
  "f \<inverse>FUNCT-1K6 Y \<equiv> f \<inverse>RELAT-1K11 Y"

mtheorem funct_1_def_7:
  mlet "f be FunctionFUNCT-1M1", "Y be setHIDDENM2"
"redefine func f \<inverse>FUNCT-1K6 Y \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
proof
(*compatibility*)
  show " for it be setHIDDENM2 holds it =HIDDENR1 f \<inverse>FUNCT-1K6 Y iff ( for x be objectHIDDENM1 holds x inHIDDENR3 it iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y)"
  proof-
    have " for X be setHIDDENM2 holds (X =XBOOLE-0R4 f \<inverse>RELAT-1K11 Y implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y implies x inHIDDENR3 X))) & (( for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) implies X =HIDDENR1 f \<inverse>RELAT-1K11 Y)"
    proof(rule ballI,rule conjMI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      show "X =XBOOLE-0R4 f \<inverse>RELAT-1K11 Y implies ( for x be objectHIDDENM1 holds (x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y) & (x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y implies x inHIDDENR3 X))"
      proof(rule impI,rule ballI,rule conjMI,rule impMI ,rule impI)
        assume A1: "X =XBOOLE-0R4 f \<inverse>RELAT-1K11 Y"
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
        proof(rule impI,rule conjMI)
          assume "x inHIDDENR3 X"
          then have A2: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y"
            using A1 relat_1_def_14 sorry
          thus "x inHIDDENR3 domRELAT-1K1 f"
            using xtuple_0_def_12 sorry
          show "f .FUNCT-1K1 x inTARSKIR2 Y"
            using A2 funct_1_th_1 sorry
        qed
        assume A3: "x inHIDDENR3 domRELAT-1K1 f"
          and A4: "f .FUNCT-1K1 x inTARSKIR2 Y"
        have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
          using A3 funct_1_th_1 sorry
        thus "x inHIDDENR3 X"
          using A1 A4 relat_1_def_14 sorry
      qed "sorry"
      assume A5: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x inTARSKIR2 Y"
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y)) & (( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y) implies x inHIDDENR3 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y)"
        proof(rule impI)
          assume A6: "x inHIDDENR3 X"
          obtain y where 
            [ty]:"y be objectHIDDENM1" and yDef:"y = f .FUNCT-1K1 x"
             sorry
          show " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y"
          proof(rule bexI[of _ "y"],rule conjMI)
            have "x inHIDDENR3 domRELAT-1K1 f"
              using A5 A6 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 f"
              using funct_1_def_2 sorry
            show "y inHIDDENR3 Y"
              using A5 A6 sorry
          qed "sorry"
        qed
        assume Given: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 f & y inHIDDENR3 Y"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A7: "[TARSKIK4 x,y ] inHIDDENR3 f"and A8: "y inHIDDENR3 Y"
           sorry
        have "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using A7 funct_1_th_1 sorry
        thus "x inHIDDENR3 X"
          using A5 A8 sorry
      qed "sorry"
      thus "X =HIDDENR1 f \<inverse>RELAT-1K11 Y"
        using relat_1_def_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_68:
" for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2"
proof-
  have " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) iff x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2) &  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2 &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have 
          [ty]:"x be setHIDDENM2"
          using tarski_th_1 sorry
        have A1: "x inTARSKIR2 f \<inverse>FUNCT-1K6 Y2 iff f .FUNCT-1K1 x inTARSKIR2 Y2 & x inTARSKIR2 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        have A2: "x inTARSKIR2 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) iff f .FUNCT-1K1 x inTARSKIR2 Y1 /\\XBOOLE-0K3 Y2 & x inTARSKIR2 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        have "x inTARSKIR2 f \<inverse>FUNCT-1K6 Y1 iff f .FUNCT-1K1 x inTARSKIR2 Y1 & x inTARSKIR2 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        then have "x inTARSKIR2 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) iff x inTARSKIR2 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2"
          using A1 A2 xboole_0_def_4 sorry
        thus " not (x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2) &  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2 &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f \<inverse>FUNCT-1K6 (Y1 /\\XBOOLE-0K3 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y2"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_69:
" for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2"
proof-
  have " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2"
  proof(rule ballI,rule ballI,rule ballI)
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) iff x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2) &  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2 &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A1: "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y2 iff f .FUNCT-1K1 x inTARSKIR2 Y2 & x inHIDDENR3 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        have A2: "x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) iff f .FUNCT-1K1 x inTARSKIR2 Y1 \\SUBSET-1K6 Y2 & x inHIDDENR3 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 iff f .FUNCT-1K1 x inTARSKIR2 Y1 & x inHIDDENR3 domRELAT-1K1 f"
          using funct_1_def_7 sorry
        thus " not (x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2) &  not (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2 &  not x inHIDDENR3 f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2))"
          using A1 A2 xboole_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f \<inverse>FUNCT-1K6 (Y1 \\SUBSET-1K6 Y2) =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y1 \\SUBSET-1K6 f \<inverse>FUNCT-1K6 Y2"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_70:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y implies x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y) & X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y c=TARSKIR1 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y implies x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y"
        then have A1: " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X & y inHIDDENR3 Y"
          using relat_1_def_14 sorry
        then have A2: "x inHIDDENR3 X"
          using relat_1_def_11 sorry
        have "R  |RELAT-1K8 X c=RELAT-1R2 R"
          using relat_1_th_59 sorry
        then have "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
          using A1 relat_1_def_14 sorry
        thus "x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
          using A2 xboole_0_def_4 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
        then have "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
          using xboole_0_def_4 sorry
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,y ] inHIDDENR3 R"and A5: "y inHIDDENR3 Y"
          using relat_1_def_14 sorry
        have "x inHIDDENR3 X"
          using A3 xboole_0_def_4 sorry
        then have "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 X"
          using A4 relat_1_def_11 sorry
        thus "x inHIDDENR3 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y"
          using A5 relat_1_def_14 sorry
      qed "sorry"
      thus "X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y c=TARSKIR1 (R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y"
        using tarski_def_3 sorry
    qed
    thus "(R  |RELAT-1K8 X)\<inverse>RELAT-1K11 Y =XBOOLE-0R4 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_71:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds A missesXBOOLE-0R1 B implies f \<inverse>FUNCT-1K6 A missesXBOOLE-0R1 f \<inverse>FUNCT-1K6 B"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix A assume [ty]: "A be setHIDDENM2"
  fix B assume [ty]: "B be setHIDDENM2"
  assume "A missesXBOOLE-0R1 B"
  then have "A /\\XBOOLE-0K3 B =XBOOLE-0R4 {}XBOOLE-0K1"
     sorry
  then have "{}XBOOLE-0K1 =HIDDENR1 f \<inverse>FUNCT-1K6 (A /\\XBOOLE-0K3 B)"
     sorry
  also have "... = f \<inverse>FUNCT-1K6 A /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 B"
    using funct_1_th_68 sorry
  finally have "{}XBOOLE-0K1 =HIDDENR1 f \<inverse>FUNCT-1K6 A /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 B"
     sorry
  thus "f \<inverse>FUNCT-1K6 A missesXBOOLE-0R1 f \<inverse>FUNCT-1K6 B"
     sorry
qed "sorry"

mtheorem funct_1_th_72:
" for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds y inHIDDENR3 rngRELAT-1K2 R iff R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds (y inHIDDENR3 rngRELAT-1K2 R implies R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1) & (R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1 implies y inHIDDENR3 rngRELAT-1K2 R)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    show "y inHIDDENR3 rngRELAT-1K2 R implies R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
    proof-
      have "y inHIDDENR3 rngRELAT-1K2 R implies  not R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
      proof(rule impI)
        assume "y inHIDDENR3 rngRELAT-1K2 R"
        then have A1: " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "y inHIDDENR3 {TARSKIK1 y}"
          using tarski_def_1 sorry
        thus " not R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
          using A1 relat_1_def_14 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A2: "x inHIDDENR3 R \<inverse>RELAT-1K11 {TARSKIK1 y}"
      using xboole_0_def_1 sorry
    obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A3: "[TARSKIK4 x,z ] inHIDDENR3 R"and A4: "z inHIDDENR3 {TARSKIK1 y}"
      using A2 relat_1_def_14 sorry
    have "z =HIDDENR1 y"
      using A4 tarski_def_1 sorry
    thus "y inHIDDENR3 rngRELAT-1K2 R"
      using A3 xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_73:
" for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1) implies Y c=TARSKIR1 rngRELAT-1K2 R"
proof-
  have " for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1) implies Y c=TARSKIR1 rngRELAT-1K2 R"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 rngRELAT-1K2 R"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 Y"
      then have "R \<inverse>RELAT-1K11 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
        using A1 sorry
      thus "y inHIDDENR3 rngRELAT-1K2 R"
        using funct_1_th_72 sorry
    qed "sorry"
    thus "Y c=TARSKIR1 rngRELAT-1K2 R"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_74:
" for f be FunctionFUNCT-1M1 holds ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})) iff f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds (( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})) implies f be one-to-oneFUNCT-1V2) & (f be one-to-oneFUNCT-1V2 implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar14 be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 tVar14})))"
  proof(rule ballI,rule conjMI,rule impI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})) implies f be one-to-oneFUNCT-1V2"
    proof(rule impI)
      assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})"
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f implies  not (f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A2: "x1 inHIDDENR3 domRELAT-1K1 f"
          and A3: "x2 inHIDDENR3 domRELAT-1K1 f"
        have "f .FUNCT-1K1 x1 inTARSKIR2 rngFUNCT-1K2 f"
          using A2 funct_1_def_3 sorry
        then obtain y1 where
          [ty]:"y1 be objectHIDDENM1" and 
          A4: "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x1 } =XBOOLE-0R4 {TARSKIK1 y1}"
          using A1 sorry
        have "f .FUNCT-1K1 x2 inTARSKIR2 rngFUNCT-1K2 f"
          using A3 funct_1_def_3 sorry
        then obtain y2 where
          [ty]:"y2 be objectHIDDENM1" and 
          A5: "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x2 } =XBOOLE-0R4 {TARSKIK1 y2}"
          using A1 sorry
        have "f .FUNCT-1K1 x1 inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x1 }"
          using tarski_def_1 sorry
        then have "x1 inHIDDENR3 {TARSKIK1 y1}"
          using A2 A4 funct_1_def_7 sorry
        then have A6: "y1 =HIDDENR1 x1"
          using tarski_def_1 sorry
        have "f .FUNCT-1K1 x2 inTARSKIR2 {TARSKIK1 f .FUNCT-1K1 x2 }"
          using tarski_def_1 sorry
        then have "x2 inHIDDENR3 {TARSKIK1 y2}"
          using A3 A5 funct_1_def_7 sorry
        thus " not (f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 &  not x1 =HIDDENR1 x2)"
          using A4 A5 A6 tarski_def_1 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    assume A7: "f be one-to-oneFUNCT-1V2"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "y inHIDDENR3 rngFUNCT-1K2 f"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A8: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
      using funct_1_def_3 sorry
    show " ex tVar14 be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 tVar14}"
    proof(rule bexI[of _ "x"])
      have " for z be objectHIDDENM1 holds z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y} iff z =HIDDENR1 x"
      proof-
        have " for z be objectHIDDENM1 holds (z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y} implies z =HIDDENR1 x) &  not (z =HIDDENR1 x &  not z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y})"
        proof(rule ballI,rule conjMI)
          fix z assume [ty]: "z be objectHIDDENM1"
          show "z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y} implies z =HIDDENR1 x"
          proof(rule impI)
            assume A9: "z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
            then have "f .FUNCT-1K1 z inTARSKIR2 {TARSKIK1 y}"
              using funct_1_def_7 sorry
            then have A10: "f .FUNCT-1K1 z =HIDDENR1 y"
              using tarski_def_1 sorry
            have "z inHIDDENR3 domRELAT-1K1 f"
              using A9 funct_1_def_7 sorry
            thus "z =HIDDENR1 x"
              using A7 A8 A10 sorry
          qed
          have "y inHIDDENR3 {TARSKIK1 y}"
            using tarski_def_1 sorry
          thus " not (z =HIDDENR1 x &  not z inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y})"
            using A8 funct_1_def_7 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
        using tarski_def_1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_75:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y implies y inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
      then have " ex x be objectHIDDENM1 st (x inHIDDENR3 domRELAT-1K1 f & x inHIDDENR3 f \<inverse>FUNCT-1K6 Y) & y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_6 sorry
      thus "y inHIDDENR3 Y"
        using funct_1_def_7 sorry
    qed "sorry"
    thus "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_76:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 domRELAT-1K1 R implies X c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X c=TARSKIR1 domRELAT-1K1 R implies X c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 R"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 X"
      then obtain Rx where
        [ty]:"Rx be objectHIDDENM1" and 
        A3: "[TARSKIK4 x,Rx ] inHIDDENR3 R"
        using A1 xtuple_0_def_12 sorry
      have "Rx inHIDDENR3 R .:RELAT-1K10 X"
        using A2 A3 relat_1_def_13 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X)"
        using A3 relat_1_def_14 sorry
    qed "sorry"
    thus "X c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_77:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y c=TARSKIR1 rngFUNCT-1K2 f implies f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "Y c=TARSKIR1 rngFUNCT-1K2 f"
    have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y & Y c=TARSKIR1 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
    proof(rule conjMI)
      show "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y"
        using funct_1_th_75 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A2: "y inHIDDENR3 Y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A3: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using A1 funct_1_def_3 sorry
        have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A2 A3 funct_1_def_7 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
          using A3 funct_1_def_6 sorry
      qed "sorry"
      thus "Y c=TARSKIR1 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
        using tarski_def_3 sorry
    qed
    thus "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_78:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f"
  proof(rule ballI,rule ballI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have Cut2066: "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y & f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 f .:FUNCT-1K5 domRELAT-1K1 f"
      using funct_1_th_75 relat_1_th_114 sorry
    have "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f & Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f c=TARSKIR1 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
    proof(rule conjMI)
      show "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y c=TARSKIR1 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f"
        using xboole_1_th_19 Cut2066 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f implies y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A1: "y inHIDDENR3 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f"
        then have "y inHIDDENR3 f .:FUNCT-1K5 domRELAT-1K1 f"
          using xboole_0_def_4 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 domRELAT-1K1 f"and "x inHIDDENR3 domRELAT-1K1 f"and A3: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have "y inHIDDENR3 Y"
          using A1 xboole_0_def_4 sorry
        then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A2 A3 funct_1_def_7 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
          using A2 A3 funct_1_def_6 sorry
      qed "sorry"
      thus "Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f c=TARSKIR1 f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y"
        using tarski_def_3 sorry
    qed
    thus "f .:FUNCT-1K5 f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 Y /\\XBOOLE-0K3 f .:FUNCT-1K5 domRELAT-1K1 f"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_79:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) c=TARSKIR1 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) c=TARSKIR1 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) implies y inHIDDENR3 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 f"and A2: "x inHIDDENR3 X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y"and A3: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_6 sorry
      have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
        using A2 xboole_0_def_4 sorry
      then have A4: "y inHIDDENR3 Y"
        using A3 funct_1_def_7 sorry
      have "x inHIDDENR3 X"
        using A2 xboole_0_def_4 sorry
      then have "y inHIDDENR3 f .:FUNCT-1K5 X"
        using A1 A3 funct_1_def_6 sorry
      thus "y inHIDDENR3 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
        using A4 xboole_0_def_4 sorry
    qed "sorry"
    thus "f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) c=TARSKIR1 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_80:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) =XBOOLE-0R4 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) =XBOOLE-0R4 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) c=TARSKIR1 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y & f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y c=TARSKIR1 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y)"
    proof(rule conjMI)
      show "f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) c=TARSKIR1 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
        using funct_1_th_79 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y implies y inHIDDENR3 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y)"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A1: "y inHIDDENR3 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
        then have "y inHIDDENR3 f .:FUNCT-1K5 X"
          using xboole_0_def_4 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "x inHIDDENR3 domRELAT-1K1 f"and A3: "x inHIDDENR3 X"and A4: "y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have "y inHIDDENR3 Y"
          using A1 xboole_0_def_4 sorry
        then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A2 A4 funct_1_def_7 sorry
        then have "x inHIDDENR3 X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y"
          using A3 xboole_0_def_4 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y)"
          using A2 A4 funct_1_def_6 sorry
      qed "sorry"
      thus "f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y c=TARSKIR1 f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y)"
        using tarski_def_3 sorry
    qed
    thus "f .:FUNCT-1K5 (X /\\XBOOLE-0K3 f \<inverse>FUNCT-1K6 Y) =XBOOLE-0R4 f .:FUNCT-1K5 X /\\XBOOLE-0K3 Y"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_81:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X /\\XBOOLE-0K3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X /\\XBOOLE-0K3 Y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y implies x inHIDDENR3 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X /\\XBOOLE-0K3 Y)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y"
      then have "x inHIDDENR3 R \<inverse>RELAT-1K11 Y"
        using xboole_0_def_4 sorry
      then obtain Rx where
        [ty]:"Rx be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,Rx ] inHIDDENR3 R"and A3: "Rx inHIDDENR3 Y"
        using relat_1_def_14 sorry
      have "x inHIDDENR3 X"
        using A1 xboole_0_def_4 sorry
      then have "Rx inHIDDENR3 R .:RELAT-1K10 X"
        using A2 relat_1_def_13 sorry
      then have "Rx inHIDDENR3 R .:RELAT-1K10 X /\\XBOOLE-0K3 Y"
        using A3 xboole_0_def_4 sorry
      thus "x inHIDDENR3 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X /\\XBOOLE-0K3 Y)"
        using A2 relat_1_def_14 sorry
    qed "sorry"
    thus "X /\\XBOOLE-0K3 R \<inverse>RELAT-1K11 Y c=TARSKIR1 R \<inverse>RELAT-1K11 (R .:RELAT-1K10 X /\\XBOOLE-0K3 Y)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_82:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) implies x inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
      then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
        using funct_1_def_7 sorry
      then have A3: " ex z be objectHIDDENM1 st (z inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 X) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 z"
        using funct_1_def_6 sorry
      have "x inHIDDENR3 domRELAT-1K1 f"
        using A2 funct_1_def_7 sorry
      thus "x inHIDDENR3 X"
        using A1 A3 sorry
    qed "sorry"
    thus "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_83:
" for f be FunctionFUNCT-1M1 holds ( for X be setHIDDENM2 holds f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X) implies f be one-to-oneFUNCT-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds ( for X be setHIDDENM2 holds f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X) implies f be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: " for X be setHIDDENM2 holds f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
    have "( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & (f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 & x1 <>HIDDENR2 x2)) implies  False "
    proof(rule impI)
      assume Given: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st (x1 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 domRELAT-1K1 f) & (f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 & x1 <>HIDDENR2 x2)"
      then obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A2: "x1 inHIDDENR3 domRELAT-1K1 f"and A3: "x2 inHIDDENR3 domRELAT-1K1 f"and A4: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2 & x1 <>HIDDENR2 x2"
         sorry
      have A5: "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 {TARSKIK1 x1}) c=TARSKIR1 {TARSKIK1 x1}"
        using A1 sorry
      have A6: "ImRELAT-1K12(f,x2) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x2 }"
        using A3 funct_1_th_59 sorry
      have A7: "ImRELAT-1K12(f,x1) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x1 }"
        using A2 funct_1_th_59 sorry
      have "f .FUNCT-1K1 x1 inTARSKIR2 rngFUNCT-1K2 f"
        using A2 funct_1_def_3 sorry
      then have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 {TARSKIK1 x1}) <>HIDDENR2 {}XBOOLE-0K1"
        using A7 funct_1_th_72 sorry
      then have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 {TARSKIK1 x1}) =XBOOLE-0R4 {TARSKIK1 x1}"
        using A5 zfmisc_1_th_33 sorry
      thus " False "
        using A1 A4 A7 A6 zfmisc_1_th_3 sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_84:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 X =XBOOLE-0R4 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f .:FUNCT-1K5 X =XBOOLE-0R4 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 X iff y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 f .:FUNCT-1K5 X implies y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X) & (y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X implies y inHIDDENR3 f .:FUNCT-1K5 X)"
      proof(rule ballI,rule conjMI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 f .:FUNCT-1K5 X implies y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
        proof(rule impI)
          assume "y inHIDDENR3 f .:FUNCT-1K5 X"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "x inHIDDENR3 domRELAT-1K1 f"and A3: "x inHIDDENR3 X"and A4: "y =HIDDENR1 f .FUNCT-1K1 x"
            using funct_1_def_6 sorry
          have "y inHIDDENR3 rngFUNCT-1K2 f"
            using A2 A4 funct_1_def_3 sorry
          then have A5: "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
            using A1 funct_1_th_32 sorry
          have "f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
            using A1 A2 funct_1_th_32 sorry
          thus "y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
            using A3 A4 A5 funct_1_def_7 sorry
        qed
        assume A6: "y inHIDDENR3 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
        then have A7: "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y inTARSKIR2 X"
          using funct_1_def_7 sorry
        have "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
          using A6 funct_1_def_7 sorry
        then have "y inHIDDENR3 rngFUNCT-1K2 f"
          using A1 funct_1_th_32 sorry
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A8: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        have "f \<inverse>FUNCT-1K4 .FUNCT-1K1 y =HIDDENR1 x"
          using A1 A8 funct_1_th_34 sorry
        thus "y inHIDDENR3 f .:FUNCT-1K5 X"
          using A7 A8 funct_1_def_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f .:FUNCT-1K5 X =XBOOLE-0R4 (f \<inverse>FUNCT-1K4)\<inverse>FUNCT-1K6 X"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_85:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>FUNCT-1K6 Y iff x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
    proof-
      have " for x be objectHIDDENM1 holds (x inHIDDENR3 f \<inverse>FUNCT-1K6 Y implies x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y) & (x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y implies x inHIDDENR3 f \<inverse>FUNCT-1K6 Y)"
      proof(rule ballI,rule conjMI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        show "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y implies x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
        proof(rule impI)
          assume A2: "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          then have A3: "f .FUNCT-1K1 x inTARSKIR2 Y"
            using funct_1_def_7 sorry
          have A4: "x inHIDDENR3 domRELAT-1K1 f"
            using A2 funct_1_def_7 sorry
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          then have A5: "f .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
            using A1 funct_1_th_32 sorry
          have "f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
            using A1 A4 funct_1_th_32 sorry
          thus "x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
            using A3 A5 funct_1_def_6 sorry
        qed
        assume "x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A6: "y inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"and A7: "y inHIDDENR3 Y"and A8: "x =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 y"
          using funct_1_def_6 sorry
        have "domRELAT-1K1 (f \<inverse>FUNCT-1K4) =XBOOLE-0R4 rngFUNCT-1K2 f"
          using A1 funct_1_th_32 sorry
        then have "y =HIDDENR1 f .FUNCT-1K1 x & x inHIDDENR3 domRELAT-1K1 f"
          using A1 A6 A8 funct_1_th_32 sorry
        thus "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
          using A7 funct_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f \<inverse>FUNCT-1K6 Y =XBOOLE-0R4 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 Y"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_86:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds ((Y =XBOOLE-0R4 rngFUNCT-1K2 f & domRELAT-1K1 g =XBOOLE-0R4 Y) & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f implies g =RELAT-1R1 h"
proof-
  have " for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds Y =XBOOLE-0R4 rngFUNCT-1K2 f & ((domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y) & g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f) implies g =RELAT-1R1 h"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "Y =XBOOLE-0R4 rngFUNCT-1K2 f"
      and A2: "domRELAT-1K1 g =XBOOLE-0R4 Y & domRELAT-1K1 h =XBOOLE-0R4 Y"
      and A3: "g *FUNCT-1K3 f =RELAT-1R1 h *FUNCT-1K3 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 y"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 y"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 Y"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A4: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
          using A1 funct_1_def_3 sorry
        have "(g *FUNCT-1K3 f).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
          using A4 funct_1_th_13 sorry
        thus "g .FUNCT-1K1 y =XBOOLE-0R4 h .FUNCT-1K1 y"
          using A3 A4 funct_1_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "g =RELAT-1R1 h"
      using A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_87:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (f .:FUNCT-1K5 X1 c=TARSKIR1 f .:FUNCT-1K5 X2 & X1 c=TARSKIR1 domRELAT-1K1 f) & f be one-to-oneFUNCT-1V2 implies X1 c=TARSKIR1 X2"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 X1 c=TARSKIR1 f .:FUNCT-1K5 X2 & (X1 c=TARSKIR1 domRELAT-1K1 f & f be one-to-oneFUNCT-1V2) implies X1 c=TARSKIR1 X2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f .:FUNCT-1K5 X1 c=TARSKIR1 f .:FUNCT-1K5 X2"
      and A2: "X1 c=TARSKIR1 domRELAT-1K1 f"
      and A3: "f be one-to-oneFUNCT-1V2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X1 implies x inHIDDENR3 X2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 X1"
      then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X1"
        using A2 funct_1_def_6 sorry
      then have " ex x2 be objectHIDDENM1 st (x2 inHIDDENR3 domRELAT-1K1 f & x2 inHIDDENR3 X2) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x2"
        using A1 funct_1_def_6 sorry
      thus "x inHIDDENR3 X2"
        using A2 A3 A4 sorry
    qed "sorry"
    thus "X1 c=TARSKIR1 X2"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_88:
" for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 Y1 c=TARSKIR1 f \<inverse>FUNCT-1K6 Y2 & Y1 c=TARSKIR1 rngFUNCT-1K2 f implies Y1 c=TARSKIR1 Y2"
proof-
  have " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f \<inverse>FUNCT-1K6 Y1 c=TARSKIR1 f \<inverse>FUNCT-1K6 Y2 & Y1 c=TARSKIR1 rngFUNCT-1K2 f implies Y1 c=TARSKIR1 Y2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "f \<inverse>FUNCT-1K6 Y1 c=TARSKIR1 f \<inverse>FUNCT-1K6 Y2"
      and A2: "Y1 c=TARSKIR1 rngFUNCT-1K2 f"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 Y1 implies y inHIDDENR3 Y2"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A3: "y inHIDDENR3 Y1"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELAT-1K1 f"and A5: "y =HIDDENR1 f .FUNCT-1K1 x"
        using A2 funct_1_def_3 sorry
      have "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y1"
        using A3 A4 A5 funct_1_def_7 sorry
      thus "y inHIDDENR3 Y2"
        using A1 A5 funct_1_def_7 sorry
    qed "sorry"
    thus "Y1 c=TARSKIR1 Y2"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_89:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not (f be one-to-oneFUNCT-1V2 &  not ( for y be objectHIDDENM1 holds  not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}))) &  not (( for y be objectHIDDENM1 holds  not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})) &  not f be one-to-oneFUNCT-1V2)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "( for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}) iff ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}))"
    proof-
      have "(( for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}) implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}))) & (( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})) implies ( for y be objectHIDDENM1 holds  not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})))"
      proof(rule conjMI,rule impI,rule ballI)
        show "( for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}) implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}))"
        proof-
          have "( for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}) implies ( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex tVar15 be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 tVar15}))"
          proof(rule impI,rule ballI,rule impI)
            assume A1: " for y be objectHIDDENM1 holds  ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
            fix y assume [ty]: "y be objectHIDDENM1"
            obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
              using A1 sorry
            assume "y inHIDDENR3 rngFUNCT-1K2 f"
            then obtain x1 where
              [ty]:"x1 be objectHIDDENM1" and 
              A3: "x1 inHIDDENR3 domRELAT-1K1 f"and A4: "y =HIDDENR1 f .FUNCT-1K1 x1"
              using funct_1_def_3 sorry
            show " ex tVar15 be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 tVar15}"
            proof(rule bexI[of _ "x"])
              have "f .FUNCT-1K1 x1 inTARSKIR2 {TARSKIK1 y}"
                using A4 tarski_def_1 sorry
              then have "f \<inverse>FUNCT-1K6 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
                using A3 funct_1_def_7 sorry
              thus "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
                using A2 zfmisc_1_th_33 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        assume A5: " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x})"
        fix y assume [ty]: "y be objectHIDDENM1"
        have A6: " not y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be setHIDDENM2 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})"
        proof(rule impI)
          let ?x = "the setHIDDENM2"
          assume A7: " not y inHIDDENR3 rngFUNCT-1K2 f"
          show " ex x be setHIDDENM2 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
          proof(rule bexI[of _ "x"])
            have "rngFUNCT-1K2 f missesXBOOLE-0R1 {TARSKIK1 y}"
              using A7 zfmisc_1_th_50 sorry
            then have "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {}XBOOLE-0K1"
              using relat_1_th_138 sorry
            thus "f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
               sorry
          qed "sorry"
        qed
        have "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})"
        proof(rule impI)
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A8: "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
            using A5 sorry
          show " ex x be objectHIDDENM1 st f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
          proof(rule bexI[of _ "x"])
            show "f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
              using A8 sorry
          qed "sorry"
        qed
        thus " not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " not (f be one-to-oneFUNCT-1V2 &  not ( for y be objectHIDDENM1 holds  not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}))) &  not (( for y be objectHIDDENM1 holds  not ( for x be objectHIDDENM1 holds  not f \<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x})) &  not f be one-to-oneFUNCT-1V2)"
      using funct_1_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_90:
" for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 S implies R \<inverse>RELAT-1K11 X c=TARSKIR1 (R *RELAT-1K6 S)\<inverse>RELAT-1K11 (S .:RELAT-1K10 X)"
proof-
  have " for X be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds  for S be RelationRELAT-1M1 holds rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 S implies R \<inverse>RELAT-1K11 X c=TARSKIR1 (R *RELAT-1K6 S)\<inverse>RELAT-1K11 (S .:RELAT-1K10 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix S assume [ty]: "S be RelationRELAT-1M1"
    assume A1: "rngRELAT-1K2 R c=TARSKIR1 domRELAT-1K1 S"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELAT-1K11 X implies x inHIDDENR3 (R *RELAT-1K6 S)\<inverse>RELAT-1K11 (S .:RELAT-1K10 X)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 R \<inverse>RELAT-1K11 X"
      then obtain Rx where
        [ty]:"Rx be objectHIDDENM1" and 
        A2: "[TARSKIK4 x,Rx ] inHIDDENR3 R"and A3: "Rx inHIDDENR3 X"
        using relat_1_def_14 sorry
      have "Rx inHIDDENR3 rngRELAT-1K2 R"
        using A2 xtuple_0_def_13 sorry
      then obtain SRx where
        [ty]:"SRx be objectHIDDENM1" and 
        A4: "[TARSKIK4 Rx,SRx ] inHIDDENR3 S"
        using A1 xtuple_0_def_12 sorry
      have "SRx inHIDDENR3 S .:RELAT-1K10 X & [TARSKIK4 x,SRx ] inHIDDENR3 R *RELAT-1K6 S"
        using A2 A3 A4 relat_1_def_8 relat_1_def_13 sorry
      thus "x inHIDDENR3 (R *RELAT-1K6 S)\<inverse>RELAT-1K11 (S .:RELAT-1K10 X)"
        using relat_1_def_14 sorry
    qed "sorry"
    thus "R \<inverse>RELAT-1K11 X c=TARSKIR1 (R *RELAT-1K6 S)\<inverse>RELAT-1K11 (S .:RELAT-1K10 X)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_91:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds (f \<inverse>FUNCT-1K6 X =XBOOLE-0R4 f \<inverse>FUNCT-1K6 Y & X c=TARSKIR1 rngFUNCT-1K2 f) & Y c=TARSKIR1 rngFUNCT-1K2 f implies X =XBOOLE-0R4 Y"
  using funct_1_th_88 sorry

(*begin*)
reserve A for "SubsetSUBSET-1M2-of X"
mtheorem funct_1_th_92:
" for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds idRELAT-1K7 X .:FUNCT-1K5 A =XBOOLE-0R4 A"
proof-
  have " for X be setHIDDENM2 holds  for A be SubsetSUBSET-1M2-of X holds idRELAT-1K7 X .:FUNCT-1K5 A =XBOOLE-0R4 A"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix A assume [ty]: "A be SubsetSUBSET-1M2-of X"
    have " for e be objectHIDDENM1 holds (e inHIDDENR3 A implies ( ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & u inHIDDENR3 A) & e =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 u)) & (( ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & u inHIDDENR3 A) & e =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 u) implies e inHIDDENR3 A)"
    proof(rule ballI,rule conjMI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      show "e inHIDDENR3 A implies ( ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & u inHIDDENR3 A) & e =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 u)"
      proof-
        have "e inHIDDENR3 A implies ( ex tVar18 be objectHIDDENM1 st tVar18 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & (tVar18 inHIDDENR3 A & tVar18 =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 tVar18))"
        proof(rule impI)
          assume A1: "e inHIDDENR3 A"
          show " ex tVar18 be objectHIDDENM1 st tVar18 inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & (tVar18 inHIDDENR3 A & tVar18 =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 tVar18)"
          proof(rule bexI[of _ "e"],rule conjMI,rule conjMI)
            show "e inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X)"
              using A1 sorry
            show "e inHIDDENR3 A"
              using A1 sorry
            show "e =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 e"
              using A1 funct_1_th_17 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      assume " ex u be objectHIDDENM1 st (u inHIDDENR3 domRELAT-1K1 (idRELAT-1K7 X) & u inHIDDENR3 A) & e =HIDDENR1 idRELAT-1K7 X .FUNCT-1K1 u"
      thus "e inHIDDENR3 A"
        using funct_1_th_17 sorry
    qed "sorry"
    thus "idRELAT-1K7 X .:FUNCT-1K5 A =XBOOLE-0R4 A"
      using funct_1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1V3("empty-yieldingFUNCT-1V3" 70) where
  "empty-yieldingFUNCT-1V3 \<equiv> empty-yieldingRELAT-1V3"

mtheorem funct_1_def_8:
  mlet "f be FunctionFUNCT-1M1"
"redefine attr empty-yieldingFUNCT-1V3 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1)"
proof
(*compatibility*)
  show " for f be FunctionFUNCT-1M1 holds f be empty-yieldingFUNCT-1V3 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be empty-yieldingFUNCT-1V3 iff ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1)"
    proof-
      have "(f be empty-yieldingRELAT-1V3 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1)) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1) implies f be empty-yieldingRELAT-1V3)"
      proof(rule conjMI,rule impI)
        show "f be empty-yieldingRELAT-1V3 implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1)"
        proof(rule impI,rule ballI,rule impI)
          assume A1: "f be empty-yieldingRELAT-1V3"
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELAT-1K1 f"
          then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
            using funct_1_def_3 sorry
          thus "f .FUNCT-1K1 x be emptyXBOOLE-0V1"
            using A1 relat_1_th_149 sorry
        qed "sorry"
        assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be emptyXBOOLE-0V1"
        have " for s be objectHIDDENM1 holds s inHIDDENR3 rngFUNCT-1K2 f implies s inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be objectHIDDENM1"
          assume "s inHIDDENR3 rngFUNCT-1K2 f"
          then have " ex e be objectHIDDENM1 st e inHIDDENR3 domRELAT-1K1 f & s =HIDDENR1 f .FUNCT-1K1 e"
            using funct_1_def_3 sorry
          then have "s =HIDDENR1 {}XBOOLE-0K1"
            using A2 sorry
          thus "s inHIDDENR3 {TARSKIK1 {}XBOOLE-0K1 }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "f be empty-yieldingRELAT-1V3"
          using tarski_def_3 relat_1_def_15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

abbreviation(input) FUNCT_1V4("non-emptyFUNCT-1V4" 70) where
  "non-emptyFUNCT-1V4 \<equiv> non-emptyRELAT-1V2"

mtheorem funct_1_def_9:
  mlet "F be FunctionFUNCT-1M1"
"redefine attr non-emptyFUNCT-1V4 for FunctionFUNCT-1M1 means
  (\<lambda>F.  for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1)"
proof
(*compatibility*)
  show " for F be FunctionFUNCT-1M1 holds F be non-emptyFUNCT-1V4 iff ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1)"
  proof(rule ballI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    show "F be non-emptyFUNCT-1V4 iff ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1)"
    proof-
      have "(F be non-emptyRELAT-1V2 implies ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1)) & (( for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1) implies F be non-emptyRELAT-1V2)"
      proof(rule conjMI,rule impI)
        show "F be non-emptyRELAT-1V2 implies ( for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1)"
          using funct_1_def_3 sorry
        assume A1: " for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 n be  non emptyXBOOLE-0V1"
        have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F implies  False "
        proof(rule impI)
          assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 F"
          then have " ex i be objectHIDDENM1 st i inHIDDENR3 domRELAT-1K1 F & F .FUNCT-1K1 i =XBOOLE-0R4 {}XBOOLE-0K1"
            using funct_1_def_3 sorry
          thus " False "
            using A1 sorry
        qed
        thus "F be non-emptyRELAT-1V2"
          using relat_1_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem funct_1_cl_14:
"cluster non-emptyFUNCT-1V4 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be non-emptyFUNCT-1V4"
  proof-
    have " ex tVar19 be FunctionFUNCT-1M1 st tVar19 be non-emptyFUNCT-1V4"
    proof-
      show " ex tVar19 be FunctionFUNCT-1M1 st tVar19 be non-emptyFUNCT-1V4"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) & {}XBOOLE-0K1 .FUNCT-1K1 x be emptyXBOOLE-0V1)"
        proof(rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show " not (x inHIDDENR3 domRELAT-1K1 ({}XBOOLE-0K1) & {}XBOOLE-0K1 .FUNCT-1K1 x be emptyXBOOLE-0V1)"
             sorry
        qed "sorry"
        thus "{}XBOOLE-0K1 be non-emptyFUNCT-1V4"
          using funct_1_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

theorem funct_1_sch_4:
  fixes Df0 Ff1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds f .FUNCT-1K1 d =HIDDENR1 Ff1(d))"
  proof-
    have " ex tVar20 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar20 =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds tVar20 .FUNCT-1K1 d =HIDDENR1 Ff1(d))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Df0 & ( for d be objectHIDDENM1 holds d inHIDDENR3 Df0 implies f .FUNCT-1K1 d =HIDDENR1 Ff1(d))"
        using funct_1_sch_3 sorry
      show " ex tVar20 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar20 =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds tVar20 .FUNCT-1K1 d =HIDDENR1 Ff1(d))"
      proof(rule bexI[of _ "f"])
        show "domRELAT-1K1 f =XBOOLE-0R4 Df0 & ( for d be ElementSUBSET-1M1-of Df0 holds f .FUNCT-1K1 d =HIDDENR1 Ff1(d))"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_1_cl_15:
  mlet "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-1M1"
"cluster rngFUNCT-1K2 f as-term-is with-non-empty-elementsSETFAM-1V1"
proof
(*coherence*)
  show "rngFUNCT-1K2 f be with-non-empty-elementsSETFAM-1V1"
  proof-
    have "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f implies  not  True "
    proof(rule impI)
      assume "{}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & {}XBOOLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      thus " not  True "
        using funct_1_def_9 sorry
    qed
    thus "rngFUNCT-1K2 f be with-non-empty-elementsSETFAM-1V1"
      using setfam_1_def_8 sorry
  qed
qed "sorry"

mdef funct_1_def_10 ("constantFUNCT-1V5" 70 ) where
"attr constantFUNCT-1V5 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y)"..

mtheorem funct_1_th_93:
" for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 A c=TARSKIR1 B implies A c=TARSKIR1 f \<inverse>FUNCT-1K6 B"
proof-
  have " for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds A c=TARSKIR1 domRELAT-1K1 f implies (f .:FUNCT-1K5 A c=TARSKIR1 B implies A c=TARSKIR1 f \<inverse>FUNCT-1K6 B)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "A c=TARSKIR1 domRELAT-1K1 f"
    then have A1: "A c=TARSKIR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 A)"
      using funct_1_th_76 sorry
    assume "f .:FUNCT-1K5 A c=TARSKIR1 B"
    then have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 A) c=TARSKIR1 f \<inverse>FUNCT-1K6 B"
      using relat_1_th_143 sorry
    thus "A c=TARSKIR1 f \<inverse>FUNCT-1K6 B"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_94:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f be one-to-oneFUNCT-1V2 implies f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) =XBOOLE-0R4 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f be one-to-oneFUNCT-1V2"
    have "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X & X c=TARSKIR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
    proof(rule conjMI)
      show "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) c=TARSKIR1 X"
        using A2 funct_1_th_82 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 X"
        then have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
          using A1 funct_1_def_6 sorry
        thus "x inHIDDENR3 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
          using A1 A3 funct_1_def_7 sorry
      qed "sorry"
      thus "X c=TARSKIR1 f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X)"
        using tarski_def_3 sorry
    qed
    thus "f \<inverse>FUNCT-1K6 (f .:FUNCT-1K5 X) =XBOOLE-0R4 X"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) FUNCT_1R1(" _ =FUNCT-1R1  _ " [50,50]50) where
  "f =FUNCT-1R1 g \<equiv> f =HIDDENR1 g"

mtheorem funct_1_def_11:
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"redefine pred f =FUNCT-1R1 g means
  domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
proof
(*compatibility*)
  show "f =FUNCT-1R1 g iff domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x)"
    using funct_1_th_2 sorry
qed "sorry"

mtheorem funct_1_cl_16:
"cluster non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar21 be FunctionFUNCT-1M1 st tVar21 be non-emptyFUNCT-1V4 &  not tVar21 be emptyXBOOLE-0V1"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } }"
        using funct_1_th_5 sorry
      show " ex tVar21 be FunctionFUNCT-1M1 st tVar21 be non-emptyFUNCT-1V4 &  not tVar21 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "f"],rule conjMI)
        have " not {}XBOOLE-0K1 inTARSKIR2 rngFUNCT-1K2 f"
          using A2 tarski_def_1 sorry
        thus "f be non-emptyFUNCT-1V4"
           sorry
        show " not f be emptyXBOOLE-0V1"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_17:
  mlet "a be non-emptyFUNCT-1V4\<bar> non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "i be ElementSUBSET-1M1-of domRELAT-1K1 a"
"cluster a .FUNCT-1K1 i as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "a .FUNCT-1K1 i be  non emptyXBOOLE-0V1"
  proof-
    have " not a .FUNCT-1K1 i be emptyXBOOLE-0V1"
    proof-
      have "a .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 a"
        using funct_1_def_3 sorry
      thus " not a .FUNCT-1K1 i be emptyXBOOLE-0V1"
        using relat_1_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_18:
  mlet "f be FunctionFUNCT-1M1"
"cluster note-that Function-likeFUNCT-1V1 for SubsetSUBSET-1M2-of f"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of f holds it be Function-likeFUNCT-1V1"
    using funct_1_def_1 sorry
qed "sorry"

mtheorem funct_1_th_95:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for D be setHIDDENM2 holds D c=TARSKIR1 domRELAT-1K1 f & D c=TARSKIR1 domRELAT-1K1 g implies (f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D iff ( for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x))"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for D be setHIDDENM2 holds D c=TARSKIR1 domRELAT-1K1 f & D c=TARSKIR1 domRELAT-1K1 g implies (f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D implies ( for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x)) & (( for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    assume A1: "D c=TARSKIR1 domRELAT-1K1 f"
      and A2: "D c=TARSKIR1 domRELAT-1K1 g"
    have A3: "domRELAT-1K1 (g  |RELAT-1K8 D) =HIDDENR1 domRELAT-1K1 g /\\XBOOLE-0K3 D"
      using relat_1_th_61 sorry
    also have "... = D"
      using A2 xboole_1_th_28 sorry
    finally have "domRELAT-1K1 (g  |RELAT-1K8 D) =HIDDENR1 D"
       sorry
    show "f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D implies ( for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x)"
    proof(rule impI)
      assume A4: "f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D"
      show " for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume A5: "x inTARSKIR2 D"
        then have "f .FUNCT-1K1 x =HIDDENR1 (g  |RELAT-1K8 D).FUNCT-1K1 x"
          using A4 funct_1_th_49 sorry
        also have "... = g .FUNCT-1K1 x"
          using A5 funct_1_th_49 sorry
        finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed "sorry"
    qed
    assume A6: " for x be setHIDDENM2 holds x inTARSKIR2 D implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
    have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 D implies (f  |RELAT-1K8 D).FUNCT-1K1 x =HIDDENR1 (g  |RELAT-1K8 D).FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A8: "x inHIDDENR3 D"
      then have "(f  |RELAT-1K8 D).FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_th_49 sorry
      also have "... = g .FUNCT-1K1 x"
        using A6 A8 sorry
      also have "... = (g  |RELAT-1K8 D).FUNCT-1K1 x"
        using A8 funct_1_th_49 sorry
      finally show "(f  |RELAT-1K8 D).FUNCT-1K1 x =HIDDENR1 (g  |RELAT-1K8 D).FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "domRELAT-1K1 (f  |RELAT-1K8 D) =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 D"
      using relat_1_th_61 sorry
    also have "... = D"
      using A1 xboole_1_th_28 sorry
    finally have "domRELAT-1K1 (f  |RELAT-1K8 D) =HIDDENR1 D"
       sorry
    thus "f  |RELAT-1K8 D =FUNCT-1R1 g  |RELAT-1K8 D"
      using A3 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_96:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for x be setHIDDENM2 holds x inTARSKIR2 X implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x) implies f  |RELAT-1K8 X =FUNCT-1R1 g  |RELAT-1K8 X"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  fix X assume [ty]: "X be setHIDDENM2"
  assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
    and A2: " for x be setHIDDENM2 holds x inTARSKIR2 X implies f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
  have A3: "domRELAT-1K1 (f  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 f /\\XBOOLE-0K3 X"
    using relat_1_th_61 sorry
  then have A4: "domRELAT-1K1 (f  |RELAT-1K8 X) =XBOOLE-0R4 domRELAT-1K1 (g  |RELAT-1K8 X)"
    using A1 relat_1_th_61 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X) implies (f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 (g  |RELAT-1K8 X).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A5: "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
    then have A6: "x inHIDDENR3 X"
      using A3 xboole_0_def_4 sorry
    have "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x & (g  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
      using A4 A5 funct_1_th_47 sorry
    thus "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 (g  |RELAT-1K8 X).FUNCT-1K1 x"
      using A2 A6 sorry
  qed "sorry"
  thus "f  |RELAT-1K8 X =FUNCT-1R1 g  |RELAT-1K8 X"
    using A4 sorry
qed "sorry"

mtheorem funct_1_th_97:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 X }"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 X }"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) implies x inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 X }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X})"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        A1: "y inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 X})"and A2: "x =HIDDENR1 (f  |RELAT-1K8 {TARSKIK1 X}).FUNCT-1K1 y"
        using funct_1_def_3 sorry
      have "domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 X}"
        using relat_1_th_58 sorry
      then have "y =HIDDENR1 X"
        using A1 tarski_def_1 sorry
      then have "x =HIDDENR1 f .FUNCT-1K1 X"
        using A1 A2 funct_1_th_47 sorry
      thus "x inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 X }"
        using tarski_def_1 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 X }"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_98:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X inTARSKIR2 domRELAT-1K1 f implies rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 X }"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X inTARSKIR2 domRELAT-1K1 f implies rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 X }"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have A1: "X inTARSKIR2 {TARSKIK1 X}"
      using tarski_def_1 sorry
    assume "X inTARSKIR2 domRELAT-1K1 f"
    then have A2: "X inTARSKIR2 domRELAT-1K1 (f  |RELAT-1K8 {TARSKIK1 X})"
      using A1 relat_1_th_57 sorry
    have "rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 X } & {TARSKIK1 f .FUNCT-1K1 X } c=TARSKIR1 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X})"
    proof(rule conjMI)
      show "rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) c=TARSKIR1 {TARSKIK1 f .FUNCT-1K1 X }"
        using funct_1_th_97 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 X } implies x inHIDDENR3 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X})"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 X }"
        then have "x =HIDDENR1 f .FUNCT-1K1 X"
          using tarski_def_1 sorry
        then have "x =HIDDENR1 (f  |RELAT-1K8 {TARSKIK1 X}).FUNCT-1K1 X"
          using A2 funct_1_th_47 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X})"
          using A2 funct_1_def_3 sorry
      qed "sorry"
      thus "{TARSKIK1 f .FUNCT-1K1 X } c=TARSKIR1 rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X})"
        using tarski_def_3 sorry
    qed
    thus "rngFUNCT-1K2 (f  |RELAT-1K8 {TARSKIK1 X}) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 X }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_19:
"cluster emptyXBOOLE-0V1 also-is constantFUNCT-1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be emptyXBOOLE-0V1 implies it be constantFUNCT-1V5"
     sorry
qed "sorry"

mtheorem funct_1_cl_20:
  mlet "f be constantFUNCT-1V5\<bar>FunctionFUNCT-1M1"
"cluster rngFUNCT-1K2 f as-term-is trivialSUBSET-1V2"
proof
(*coherence*)
  show "rngFUNCT-1K2 f be trivialSUBSET-1V2"
  proof-
    have "rngFUNCT-1K2 f be trivialZFMISC-1V1"
    proof-
      show "rngFUNCT-1K2 f be trivialZFMISC-1V1"
      proof-
        have cases: "f be emptyXBOOLE-0V1 or f <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "f be emptyXBOOLE-0V1 implies rngFUNCT-1K2 f be trivialZFMISC-1V1"
        proof(rule impI)
          assume "f be emptyXBOOLE-0V1"
          then obtain g where 
            [ty]:"g be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1" and gDef:"g = f"
             sorry
          have "rngFUNCT-1K2 g be emptyXBOOLE-0V1"
             sorry
          thus "rngFUNCT-1K2 f be trivialZFMISC-1V1"
             sorry
        qed
        have case2: "f <>HIDDENR2 {}XBOOLE-0K1 implies rngFUNCT-1K2 f be trivialZFMISC-1V1"
        proof(rule impI)
          assume "f <>HIDDENR2 {}XBOOLE-0K1"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A1: "x inHIDDENR3 domRELAT-1K1 f"
            using xboole_0_def_1 sorry
          have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x } iff ( ex z be objectHIDDENM1 st z inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 z)"
          proof-
            have " for y be objectHIDDENM1 holds (y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x } implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)) & (( ex z be objectHIDDENM1 st z inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 z) implies y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x })"
            proof(rule ballI,rule conjMI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              show "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x } implies ( ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x)"
              proof(rule impI)
                assume A2: "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
                have 
                  [ty]:"x be objectHIDDENM1"
                   sorry
                show " ex x be objectHIDDENM1 st x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
                proof(rule bexI[of _ "x"])
                  show "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
                    using A1 A2 tarski_def_1 sorry
                qed "sorry"
              qed
              assume Given: " ex z be objectHIDDENM1 st z inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 z"
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A3: "z inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 z"
                 sorry
              have "y =HIDDENR1 f .FUNCT-1K1 x"
                using A1 A3 funct_1_def_10 sorry
              thus "y inHIDDENR3 {TARSKIK1 f .FUNCT-1K1 x }"
                using tarski_def_1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus "rngFUNCT-1K2 f be trivialZFMISC-1V1"
            using funct_1_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_21:
"cluster  non constantFUNCT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non constantFUNCT-1V5"
  proof-
    have " ex tVar23 be FunctionFUNCT-1M1 st  not tVar23 be constantFUNCT-1V5"
    proof-
      let ?f = "{TARSKIK2 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ],[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] }"
      have "?f be Function-likeFUNCT-1V1"
      proof-
        have "{TARSKIK2 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ],[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] } be Function-likeFUNCT-1V1"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 {TARSKIK2 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ],[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] } & [TARSKIK4 x,z ] inHIDDENR3 {TARSKIK2 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ],[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] } implies y =HIDDENR1 z"
          proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A1: "[TARSKIK4 x,y ] inHIDDENR3 ?f"
              and A2: "[TARSKIK4 x,z ] inHIDDENR3 ?f"
            have "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] or [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ]"
              using A1 tarski_def_2 sorry
            then have A3: "x =HIDDENR1 {}XBOOLE-0K1 & y =HIDDENR1 {}XBOOLE-0K1 or x =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 } & y =HIDDENR1 {TARSKIK1 {}XBOOLE-0K1 }"
              using xtuple_0_th_1 sorry
            have "[TARSKIK4 x,z ] =HIDDENR1 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] or [TARSKIK4 x,z ] =HIDDENR1 [TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ]"
              using A2 tarski_def_2 sorry
            thus "y =HIDDENR1 z"
              using A3 xtuple_0_th_1 sorry
          qed "sorry"
          thus "{TARSKIK2 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ],[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] } be Function-likeFUNCT-1V1"
            using funct_1_def_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain f where 
        [ty]:"f be FunctionFUNCT-1M1" and fDef:"f = ?f"
         sorry
      show " ex tVar23 be FunctionFUNCT-1M1 st  not tVar23 be constantFUNCT-1V5"
      proof(rule bexI[of _ "f"])
        have " ex tVar25 be objectHIDDENM1 st ({}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 f & tVar25 inTARSKIR2 domRELAT-1K1 f) &  not f .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 tVar25"
        proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"],rule conjMI)
          have A4: "[TARSKIK4 {TARSKIK1 {}XBOOLE-0K1 },{TARSKIK1 {}XBOOLE-0K1 } ] inHIDDENR3 f"
            using tarski_def_2 sorry
          have A5: "[TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] inHIDDENR3 f"
            using tarski_def_2 sorry
          thus A6: "{}XBOOLE-0K1 inTARSKIR2 domRELAT-1K1 f & {TARSKIK1 {}XBOOLE-0K1 } inTARSKIR2 domRELAT-1K1 f"
            using A4 xtuple_0_def_12 sorry
          then have "f .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 {}XBOOLE-0K1"
            using A5 funct_1_def_2 sorry
          thus " not f .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 f .FUNCT-1K1 {TARSKIK1 {}XBOOLE-0K1 }"
            using A4 A6 funct_1_def_2 sorry
        qed "sorry"
        thus " not f be constantFUNCT-1V5"
          using bexI[of _ "{}XBOOLE-0K1"] funct_1_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_22:
  mlet "f be  non constantFUNCT-1V5\<bar>FunctionFUNCT-1M1"
"cluster rngFUNCT-1K2 f as-term-is  non trivialSUBSET-1V2"
proof
(*coherence*)
  show "rngFUNCT-1K2 f be  non trivialSUBSET-1V2"
  proof-
    have "rngFUNCT-1K2 f be trivialSUBSET-1V2 implies  not  True "
    proof(rule impI)
      assume A1: "rngFUNCT-1K2 f be trivialSUBSET-1V2"
      show " not  True "
      proof-
        have cases: "rngFUNCT-1K2 f be emptyXBOOLE-0V1 or rngFUNCT-1K2 f be  non emptyXBOOLE-0V1"
           sorry
        have case1: "rngFUNCT-1K2 f be emptyXBOOLE-0V1 implies  not  True "
        proof(rule impI)
          assume "rngFUNCT-1K2 f be emptyXBOOLE-0V1"
          then have 
            [ty]:"f be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1"
             sorry
          have "f be trivialSUBSET-1V2"
             sorry
          thus " not  True "
             sorry
        qed
        have case2: "rngFUNCT-1K2 f be  non emptyXBOOLE-0V1 implies  not  True "
        proof(rule impI)
          assume "rngFUNCT-1K2 f be  non emptyXBOOLE-0V1"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "x inHIDDENR3 rngFUNCT-1K2 f"
             sorry
          have "f be constantFUNCT-1V5"
          proof-
            have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds y inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 y =HIDDENR1 f .FUNCT-1K1 z"
            proof(rule ballI,rule ballI,rule impMI ,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              fix z assume [ty]: "z be objectHIDDENM1"
              assume A3: "y inHIDDENR3 domRELAT-1K1 f"
                and A4: "z inHIDDENR3 domRELAT-1K1 f"
              have A5: "f .FUNCT-1K1 z inTARSKIR2 rngFUNCT-1K2 f"
                using A4 funct_1_def_3 sorry
              have "f .FUNCT-1K1 y inTARSKIR2 rngFUNCT-1K2 f"
                using A3 funct_1_def_3 sorry
              then have "f .FUNCT-1K1 y =HIDDENR1 x"
                using A1 A2 sorry
              also have "... = f .FUNCT-1K1 z"
                using A1 A2 A5 sorry
              finally show "f .FUNCT-1K1 y =HIDDENR1 f .FUNCT-1K1 z"
                 sorry
            qed "sorry"
            thus "f be constantFUNCT-1V5"
              using funct_1_def_10 sorry
          qed
          thus " not  True "
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_23:
"cluster  non constantFUNCT-1V5 also-is  non trivialSUBSET-1V2 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be  non constantFUNCT-1V5 implies it be  non trivialSUBSET-1V2"
  proof-
    have " for f be FunctionFUNCT-1M1 holds f be  non constantFUNCT-1V5 implies  not f be trivialSUBSET-1V2"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be FunctionFUNCT-1M1"
      assume "f be  non constantFUNCT-1V5"
      then obtain n1 n2 where
        [ty]:"n1 be objectHIDDENM1" "n2 be objectHIDDENM1" and 
        A1: "n1 inHIDDENR3 domRELAT-1K1 f"and A2: "n2 inHIDDENR3 domRELAT-1K1 f"and A3: "f .FUNCT-1K1 n1 <>HIDDENR2 f .FUNCT-1K1 n2"
         sorry
      have 
        [ty]:"f be  non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1"
        using A1 sorry
      have "f be  non trivialSUBSET-1V2"
      proof-
        have " not f be trivialSUBSET-1V2"
        proof-
          obtain x y where 
            [ty]:"x be ElementSUBSET-1M1-of f" and xDef:"x = [TARSKIK4 n1,f .FUNCT-1K1 n1 ]" and
            [ty]:"y be ElementSUBSET-1M1-of f" and yDef:"y = [TARSKIK4 n2,f .FUNCT-1K1 n2 ]"
            using A1 A2 funct_1_th_1 sorry
          have " ex tVar27 be objectHIDDENM1 st (x inTARSKIR2 f & tVar27 inTARSKIR2 f) &  not x =HIDDENR1 tVar27"
          proof(rule bexI[of _ "y"],rule conjMI)
            show "x inTARSKIR2 f & y inTARSKIR2 f"
               sorry
            show " not x =HIDDENR1 y"
              using A3 xtuple_0_th_1 sorry
          qed "sorry"
          thus " not f be trivialSUBSET-1V2"
            using bexI[of _ "x"] zfmisc_1_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not f be trivialSUBSET-1V2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_24:
"cluster trivialSUBSET-1V2 also-is constantFUNCT-1V5 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be trivialSUBSET-1V2 implies it be constantFUNCT-1V5"
     sorry
qed "sorry"

mtheorem funct_1_th_99:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X =FUNCT-1R1 (G *FUNCT-1K3 F) |RELAT-1K8 X"
proof(rule ballI,rule ballI,rule ballI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix G assume [ty]: "G be FunctionFUNCT-1M1"
  fix X assume [ty]: "X be setHIDDENM2"
  let ?Y = "domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X)"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X) implies x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X)) & (x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X) implies x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X))"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X) implies x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X)"
    proof(rule impI)
      assume A1: "x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X)"
      then have A2: "x inHIDDENR3 domRELAT-1K1 (F  |RELAT-1K8 X)"
        using funct_1_th_11 sorry
      then have A3: "x inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 X"
        using relat_1_th_61 sorry
      then have A4: "x inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have "(F  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X))"
        using A1 funct_1_th_11 sorry
      then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X))"
        using A2 funct_1_th_47 sorry
      then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G /\\XBOOLE-0K3 F .:FUNCT-1K5 X"
        using relat_1_th_61 sorry
      then have A5: "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G"
        using xboole_0_def_4 sorry
      have "x inHIDDENR3 domRELAT-1K1 F"
        using A3 xboole_0_def_4 sorry
      then have "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
        using A5 funct_1_th_11 sorry
      then have "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F) /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      thus "x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X)"
        using relat_1_th_61 sorry
    qed
    assume "x inHIDDENR3 ?Y"
    then have A6: "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    then have A7: "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
      using xboole_0_def_4 sorry
    then have A8: "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G"
      using funct_1_th_11 sorry
    have A9: "x inHIDDENR3 X"
      using A6 xboole_0_def_4 sorry
    have "x inHIDDENR3 domRELAT-1K1 F"
      using A7 funct_1_th_11 sorry
    then have "x inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 X"
      using A9 xboole_0_def_4 sorry
    then have A10: "x inHIDDENR3 domRELAT-1K1 (F  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    have "x inHIDDENR3 domRELAT-1K1 F"
      using A7 funct_1_th_11 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 F .:FUNCT-1K5 X"
      using A9 funct_1_def_6 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G /\\XBOOLE-0K3 F .:FUNCT-1K5 X"
      using A8 xboole_0_def_4 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X))"
      using relat_1_th_61 sorry
    then have "(F  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X))"
      using A10 funct_1_th_47 sorry
    thus "x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X)"
      using A10 funct_1_th_11 sorry
  qed "sorry"
  then have A11: "?Y =XBOOLE-0R4 domRELAT-1K1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X)"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 X) implies (G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 ((G *FUNCT-1K3 F) |RELAT-1K8 X).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A12: "x inHIDDENR3 ?Y"
    then have A13: "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F) /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    then have "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
      using xboole_0_def_4 sorry
    then have A14: "x inHIDDENR3 domRELAT-1K1 F"
      using funct_1_th_11 sorry
    have A15: "x inHIDDENR3 X"
      using A13 xboole_0_def_4 sorry
    then have A16: "F .FUNCT-1K1 x inTARSKIR2 F .:FUNCT-1K5 X"
      using A14 funct_1_def_6 sorry
    have "(G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 (G  |RELAT-1K8 (F .:FUNCT-1K5 X)).FUNCT-1K1 ((F  |RELAT-1K8 X).FUNCT-1K1 x)"
      using A11 A12 funct_1_th_12 sorry
    also have "... = (G  |RELAT-1K8 (F .:FUNCT-1K5 X)).FUNCT-1K1 (F .FUNCT-1K1 x)"
      using A15 funct_1_th_49 sorry
    also have "... = G .FUNCT-1K1 (F .FUNCT-1K1 x)"
      using A16 funct_1_th_49 sorry
    also have "... = (G *FUNCT-1K3 F).FUNCT-1K1 x"
      using A14 funct_1_th_13 sorry
    also have "... = ((G *FUNCT-1K3 F) |RELAT-1K8 X).FUNCT-1K1 x"
      using A13 funct_1_th_48 sorry
    finally show "(G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 ((G *FUNCT-1K3 F) |RELAT-1K8 X).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus "G  |RELAT-1K8 (F .:FUNCT-1K5 X) *FUNCT-1K3 F  |RELAT-1K8 X =FUNCT-1R1 (G *FUNCT-1K3 F) |RELAT-1K8 X"
    using A11 sorry
qed "sorry"

mtheorem funct_1_th_100:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X =FUNCT-1R1 (G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix F assume [ty]: "F be FunctionFUNCT-1M1"
  fix G assume [ty]: "G be FunctionFUNCT-1M1"
  fix X assume [ty]: "X be setHIDDENM2"
  fix X1 assume [ty]: "X1 be setHIDDENM2"
  let ?Y = "domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X)"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)) implies x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X)) & (x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X) implies x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)))"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)) implies x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X)"
    proof(rule impI)
      assume "x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1))"
      then have A1: "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F) /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)"
        using relat_1_th_61 sorry
      then have A2: "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
        using xboole_0_def_4 sorry
      have A3: "x inHIDDENR3 X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1"
        using A1 xboole_0_def_4 sorry
      then have A4: "x inHIDDENR3 X"
        using xboole_0_def_4 sorry
      have "x inHIDDENR3 domRELAT-1K1 F"
        using A2 funct_1_th_11 sorry
      then have "x inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 X"
        using A4 xboole_0_def_4 sorry
      then have A5: "x inHIDDENR3 domRELAT-1K1 (F  |RELAT-1K8 X)"
        using relat_1_th_61 sorry
      have "x inHIDDENR3 F \<inverse>FUNCT-1K6 X1"
        using A3 xboole_0_def_4 sorry
      then have A6: "F .FUNCT-1K1 x inTARSKIR2 X1"
        using funct_1_def_7 sorry
      have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G"
        using A2 funct_1_th_11 sorry
      then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G /\\XBOOLE-0K3 X1"
        using A6 xboole_0_def_4 sorry
      then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
        using relat_1_th_61 sorry
      then have "(F  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
        using A5 funct_1_th_47 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X)"
        using A5 funct_1_th_11 sorry
    qed
    assume A7: "x inHIDDENR3 ?Y"
    then have A8: "x inHIDDENR3 domRELAT-1K1 (F  |RELAT-1K8 X)"
      using funct_1_th_11 sorry
    then have A9: "x inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    then have A10: "x inHIDDENR3 domRELAT-1K1 F"
      using xboole_0_def_4 sorry
    have A11: "x inHIDDENR3 X"
      using A9 xboole_0_def_4 sorry
    have "(F  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
      using A7 funct_1_th_11 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
      using A8 funct_1_th_47 sorry
    then have A12: "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G /\\XBOOLE-0K3 X1"
      using relat_1_th_61 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 X1"
      using xboole_0_def_4 sorry
    then have "x inHIDDENR3 F \<inverse>FUNCT-1K6 X1"
      using A10 funct_1_def_7 sorry
    then have A13: "x inHIDDENR3 X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1"
      using A11 xboole_0_def_4 sorry
    have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G"
      using A12 xboole_0_def_4 sorry
    then have "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
      using A10 funct_1_th_11 sorry
    then have "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F) /\\XBOOLE-0K3 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)"
      using A13 xboole_0_def_4 sorry
    thus "x inHIDDENR3 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1))"
      using relat_1_th_61 sorry
  qed "sorry"
  then have A14: "?Y =XBOOLE-0R4 domRELAT-1K1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1))"
    using tarski_th_2 sorry
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X) implies (G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A15: "x inHIDDENR3 ?Y"
    then have A16: "x inHIDDENR3 domRELAT-1K1 (F  |RELAT-1K8 X)"
      using funct_1_th_11 sorry
    then have A17: "x inHIDDENR3 domRELAT-1K1 F /\\XBOOLE-0K3 X"
      using relat_1_th_61 sorry
    then have A18: "x inHIDDENR3 domRELAT-1K1 F"
      using xboole_0_def_4 sorry
    have A19: "(F  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
      using A15 funct_1_th_11 sorry
    then have A20: "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
      using A16 funct_1_th_47 sorry
    have A21: "x inHIDDENR3 X"
      using A17 xboole_0_def_4 sorry
    have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 (G  |RELAT-1K8 X1)"
      using A16 A19 funct_1_th_47 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 domRELAT-1K1 G /\\XBOOLE-0K3 X1"
      using relat_1_th_61 sorry
    then have "F .FUNCT-1K1 x inTARSKIR2 X1"
      using xboole_0_def_4 sorry
    then have "x inHIDDENR3 F \<inverse>FUNCT-1K6 X1"
      using A18 funct_1_def_7 sorry
    then have A22: "x inHIDDENR3 X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1"
      using A21 xboole_0_def_4 sorry
    have "(G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 (G  |RELAT-1K8 X1).FUNCT-1K1 ((F  |RELAT-1K8 X).FUNCT-1K1 x)"
      using A15 funct_1_th_12 sorry
    also have "... = (G  |RELAT-1K8 X1).FUNCT-1K1 (F .FUNCT-1K1 x)"
      using A16 funct_1_th_47 sorry
    also have "... = G .FUNCT-1K1 (F .FUNCT-1K1 x)"
      using A20 funct_1_th_47 sorry
    also have "... = (G *FUNCT-1K3 F).FUNCT-1K1 x"
      using A18 funct_1_th_13 sorry
    also have "... = ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)).FUNCT-1K1 x"
      using A22 funct_1_th_49 sorry
    finally show "(G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X).FUNCT-1K1 x =HIDDENR1 ((G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus "G  |RELAT-1K8 X1 *FUNCT-1K3 F  |RELAT-1K8 X =FUNCT-1R1 (G *FUNCT-1K3 F) |RELAT-1K8 (X /\\XBOOLE-0K3 F \<inverse>FUNCT-1K6 X1)"
    using A14 sorry
qed "sorry"

mtheorem funct_1_th_101:
" for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F) iff X c=TARSKIR1 domRELAT-1K1 F & F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for G be FunctionFUNCT-1M1 holds  for X be setHIDDENM2 holds (X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F) implies X c=TARSKIR1 domRELAT-1K1 F & F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G) & (X c=TARSKIR1 domRELAT-1K1 F & F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G implies X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix G assume [ty]: "G be FunctionFUNCT-1M1"
    fix X assume [ty]: "X be setHIDDENM2"
    show "X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F) implies X c=TARSKIR1 domRELAT-1K1 F & F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G"
    proof(rule impI,rule conjMI)
      assume A1: "X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F)"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 F"
        using funct_1_th_11 sorry
      thus "X c=TARSKIR1 domRELAT-1K1 F"
         sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F .:FUNCT-1K5 X implies x inHIDDENR3 domRELAT-1K1 G"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 F .:FUNCT-1K5 X"
        then have " ex y be objectHIDDENM1 st (y inHIDDENR3 domRELAT-1K1 F & y inHIDDENR3 X) & x =HIDDENR1 F .FUNCT-1K1 y"
          using funct_1_def_6 sorry
        thus "x inHIDDENR3 domRELAT-1K1 G"
          using A1 funct_1_th_11 sorry
      qed "sorry"
      thus "F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G"
        using tarski_def_3 sorry
    qed
    assume A2: "X c=TARSKIR1 domRELAT-1K1 F"
      and A3: "F .:FUNCT-1K5 X c=TARSKIR1 domRELAT-1K1 G"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 X"
      then have "F .FUNCT-1K1 x inTARSKIR2 F .:FUNCT-1K5 X"
        using A2 funct_1_def_6 sorry
      thus "x inHIDDENR3 domRELAT-1K1 (G *FUNCT-1K3 F)"
        using A2 A3 A4 funct_1_th_11 sorry
    qed "sorry"
    thus "X c=TARSKIR1 domRELAT-1K1 (G *FUNCT-1K3 F)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef funct_1_def_12 ("the-value-ofFUNCT-1K7  _ " [164]164 ) where
  mlet "f be FunctionFUNCT-1M1"
"assume f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5 func the-value-ofFUNCT-1K7 f \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it =HIDDENR1 f .FUNCT-1K1 x"
proof-
  (*existence*)
    show "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5 implies ( ex it be objectHIDDENM1 st  ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it =HIDDENR1 f .FUNCT-1K1 x)"
    proof(rule impI)
      assume Assume: "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5"
      have A1: "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5"
        using Assume sorry
      show " ex it be objectHIDDENM1 st  ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it =HIDDENR1 f .FUNCT-1K1 x"
      proof-
        have " ex tVar28 be objectHIDDENM1 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f & tVar28 =HIDDENR1 f .FUNCT-1K1 x))"
        proof-
          obtain x1 where
            [ty]:"x1 be objectHIDDENM1" and 
            A2: "x1 inHIDDENR3 domRELAT-1K1 f"
            using A1 xboole_0_def_1 sorry
          show " ex tVar28 be objectHIDDENM1 st  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f & tVar28 =HIDDENR1 f .FUNCT-1K1 x))"
          proof(rule bexI[of _ "f .FUNCT-1K1 x1"])
            show " not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f & f .FUNCT-1K1 x1 =HIDDENR1 f .FUNCT-1K1 x))"
              using A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5 implies ( for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it1 =HIDDENR1 f .FUNCT-1K1 x) & ( ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it2 =HIDDENR1 f .FUNCT-1K1 x) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5"
      have A1: "f be  non emptyXBOOLE-0V1\<bar>constantFUNCT-1V5"
        using Assume sorry
      show " for it1 be objectHIDDENM1 holds  for it2 be objectHIDDENM1 holds ( ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it1 =HIDDENR1 f .FUNCT-1K1 x) & ( ex x be setHIDDENM2 st x inTARSKIR2 domRELAT-1K1 f & it2 =HIDDENR1 f .FUNCT-1K1 x) implies it1 =HIDDENR1 it2"
        using A1 sorry
    qed
qed "sorry"

mtheorem funct_1_cl_25:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
  proof-
    have " ex tVar29 be FunctionFUNCT-1M1 st tVar29 be X -definedRELAT-1V4 & tVar29 be Y -valuedRELAT-1V5"
    proof-
      show " ex tVar29 be FunctionFUNCT-1M1 st tVar29 be X -definedRELAT-1V4 & tVar29 be Y -valuedRELAT-1V5"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 X & rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 Y"
        proof-
          show "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 X & rngFUNCT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 Y"
             sorry
        qed
        thus "{}XBOOLE-0K1 be X -definedRELAT-1V4 & {}XBOOLE-0K1 be Y -valuedRELAT-1V5"
          using relat_1_def_18 relat_1_def_19 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_102:
" for X be setHIDDENM2 holds  for f be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix f assume [ty]: "f be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
  fix x assume [ty]: "x be setHIDDENM2"
  assume "x inTARSKIR2 domRELAT-1K1 f"
  then have A1: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
    using funct_1_def_3 sorry
  have "rngFUNCT-1K2 f c=TARSKIR1 X"
    using relat_1_def_19 sorry
  thus "f .FUNCT-1K1 x inTARSKIR2 X"
    using A1 sorry
qed "sorry"

mdef funct_1_def_13 ("functionalFUNCT-1V6" 70 ) where
"attr functionalFUNCT-1V6 for setHIDDENM2 means
  (\<lambda>IT.  for x be objectHIDDENM1 holds x inHIDDENR3 IT implies x be FunctionFUNCT-1M1)"..

mtheorem funct_1_cl_26:
"cluster emptyXBOOLE-0V1 also-is functionalFUNCT-1V6 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be functionalFUNCT-1V6"
     sorry
qed "sorry"

mtheorem funct_1_cl_27:
  mlet "f be FunctionFUNCT-1M1"
"cluster {TARSKIK1 f} as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "{TARSKIK1 f} be functionalFUNCT-1V6"
    using tarski_def_1 sorry
qed "sorry"

mtheorem funct_1_cl_28:
  mlet "f be FunctionFUNCT-1M1", "g be FunctionFUNCT-1M1"
"cluster {TARSKIK2 f,g } as-term-is functionalFUNCT-1V6"
proof
(*coherence*)
  show "{TARSKIK2 f,g } be functionalFUNCT-1V6"
    using tarski_def_2 sorry
qed "sorry"

mtheorem funct_1_cl_29:
"cluster  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6"
  proof-
    have " ex tVar30 be setHIDDENM2 st  not tVar30 be emptyXBOOLE-0V1 & tVar30 be functionalFUNCT-1V6"
    proof-
      show " ex tVar30 be setHIDDENM2 st  not tVar30 be emptyXBOOLE-0V1 & tVar30 be functionalFUNCT-1V6"
      proof(rule bexI[of _ "{TARSKIK1 {}XBOOLE-0K1 }"])
        show " not {TARSKIK1 {}XBOOLE-0K1 } be emptyXBOOLE-0V1 & {TARSKIK1 {}XBOOLE-0K1 } be functionalFUNCT-1V6"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_30:
  mlet "P be functionalFUNCT-1V6\<bar>setHIDDENM2"
"cluster note-that Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1 for ElementSUBSET-1M1-of P"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of P holds it be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
  proof-
    have " for x be ElementSUBSET-1M1-of P holds x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of P"
      show "x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
      proof-
        have cases: "P be emptyXBOOLE-0V1 or P be  non emptyXBOOLE-0V1"
           sorry
        have case1: "P be emptyXBOOLE-0V1 implies x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume "P be emptyXBOOLE-0V1"
          thus "x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
            using subset_1_def_1 sorry
        qed
        have case2: "P be  non emptyXBOOLE-0V1 implies x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume "P be  non emptyXBOOLE-0V1"
          thus "x be Function-likeFUNCT-1V1 & x be Relation-likeRELAT-1V1"
            using funct_1_def_13 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_31:
  mlet "A be functionalFUNCT-1V6\<bar>setHIDDENM2"
"cluster note-that functionalFUNCT-1V6 for SubsetSUBSET-1M2-of A"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of A holds it be functionalFUNCT-1V6"
     sorry
qed "sorry"

mdef funct_1_def_14 (" _ -compatibleFUNCT-1V7" [70]70 ) where
  mlet "g be FunctionFUNCT-1M1"
"attr g -compatibleFUNCT-1V7 for FunctionFUNCT-1M1 means
  (\<lambda>f.  for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 g .FUNCT-1K1 x)"..

mtheorem funct_1_th_103:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f be g -compatibleFUNCT-1V7 & domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g implies g be non-emptyFUNCT-1V4"
   sorry

mtheorem funct_1_th_104:
" for f be FunctionFUNCT-1M1 holds {}XBOOLE-0K1 be f -compatibleFUNCT-1V7"
   sorry

mtheorem funct_1_cl_32:
  mlet "I be setHIDDENM2", "f be FunctionFUNCT-1M1"
"cluster emptyXBOOLE-0V1\<bar>I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be emptyXBOOLE-0V1\<bar>I -definedRELAT-1V4\<bar>f -compatibleFUNCT-1V7"
  proof-
    have " ex tVar31 be FunctionFUNCT-1M1 st (tVar31 be emptyXBOOLE-0V1 & tVar31 be I -definedRELAT-1V4) & tVar31 be f -compatibleFUNCT-1V7"
    proof-
      show " ex tVar31 be FunctionFUNCT-1M1 st (tVar31 be emptyXBOOLE-0V1 & tVar31 be I -definedRELAT-1V4) & tVar31 be f -compatibleFUNCT-1V7"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "({}XBOOLE-0K1 be emptyXBOOLE-0V1 & {}XBOOLE-0K1 be I -definedRELAT-1V4) & {}XBOOLE-0K1 be f -compatibleFUNCT-1V7"
          using relat_1_th_171 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_cl_33:
  mlet "X be setHIDDENM2", "f be FunctionFUNCT-1M1", "g be f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1"
"cluster g  |RELAT-1K8 X as-term-is f -compatibleFUNCT-1V7"
proof
(*coherence*)
  show "g  |RELAT-1K8 X be f -compatibleFUNCT-1V7"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (g  |RELAT-1K8 X) implies (g  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "domRELAT-1K1 (g  |RELAT-1K8 X) c=TARSKIR1 domRELAT-1K1 g"
        using relat_1_th_60 sorry
      assume A2: "x inHIDDENR3 domRELAT-1K1 (g  |RELAT-1K8 X)"
      then have "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A1 funct_1_def_14 sorry
      thus "(g  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using A2 funct_1_th_47 sorry
    qed "sorry"
    thus "g  |RELAT-1K8 X be f -compatibleFUNCT-1V7"
      using funct_1_def_14 sorry
  qed
qed "sorry"

mtheorem funct_1_cl_34:
  mlet "I be setHIDDENM2"
"cluster non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be non-emptyFUNCT-1V4\<bar>I -definedRELAT-1V4"
  proof-
    have " ex tVar32 be FunctionFUNCT-1M1 st tVar32 be non-emptyFUNCT-1V4 & tVar32 be I -definedRELAT-1V4"
    proof-
      show " ex tVar32 be FunctionFUNCT-1M1 st tVar32 be non-emptyFUNCT-1V4 & tVar32 be I -definedRELAT-1V4"
      proof(rule bexI[of _ "{}XBOOLE-0K1"],rule conjMI)
        show "{}XBOOLE-0K1 be non-emptyFUNCT-1V4"
           sorry
        have "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 I"
        proof-
          show "domRELAT-1K1 ({}XBOOLE-0K1) c=RELAT-1R2 I"
             sorry
        qed
        thus "{}XBOOLE-0K1 be I -definedRELAT-1V4"
          using relat_1_def_18 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_105:
" for f be FunctionFUNCT-1M1 holds  for g be f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be f -compatibleFUNCT-1V7\<bar>FunctionFUNCT-1M1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies x inHIDDENR3 domRELAT-1K1 f"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 g"
      then have "g .FUNCT-1K1 x inTARSKIR2 f .FUNCT-1K1 x"
        using funct_1_def_14 sorry
      thus "x inHIDDENR3 domRELAT-1K1 f"
        using funct_1_def_2 sorry
    qed "sorry"
    thus "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_35:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"cluster f -compatibleFUNCT-1V7 also-is X -definedRELAT-1V4 for FunctionFUNCT-1M1"
proof
(*coherence*)
  show " for it be FunctionFUNCT-1M1 holds it be f -compatibleFUNCT-1V7 implies it be X -definedRELAT-1V4"
  proof-
    have " for g be FunctionFUNCT-1M1 holds g be f -compatibleFUNCT-1V7 implies g be X -definedRELAT-1V4"
    proof(rule ballI,rule impI)
      fix g assume [ty]: "g be FunctionFUNCT-1M1"
      assume "g be f -compatibleFUNCT-1V7"
      then have A1: "domRELAT-1K1 g c=TARSKIR1 domRELAT-1K1 f"
        using funct_1_th_105 sorry
      have Cut3112: "domRELAT-1K1 f c=TARSKIR1 X"
        using relat_1_def_18 sorry
      have "domRELAT-1K1 g c=TARSKIR1 X"
      proof-
        show "domRELAT-1K1 g c=TARSKIR1 X"
          using A1 Cut3112 sorry
      qed
      thus "g be X -definedRELAT-1V4"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_106:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
    assume "x inHIDDENR3 domRELAT-1K1 f"
    then have A1: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using funct_1_def_3 sorry
    have "rngFUNCT-1K2 f c=TARSKIR1 X"
      using relat_1_def_19 sorry
    thus "f .FUNCT-1K1 x be ElementSUBSET-1M1-of X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_107:
" for f be FunctionFUNCT-1M1 holds  for A be setHIDDENM2 holds f be one-to-oneFUNCT-1V2 & A c=TARSKIR1 domRELAT-1K1 f implies f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A) =XBOOLE-0R4 A"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix A assume [ty]: "A be setHIDDENM2"
  let ?B = "f .:FUNCT-1K5 A"
  assume A1: "f be one-to-oneFUNCT-1V2"
    and A2: "A c=TARSKIR1 domRELAT-1K1 f"
  have A3: "f \<inverse>FUNCT-1K4 .:FUNCT-1K5 ?B c=TARSKIR1 A"
  proof-
    have "f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A) c=TARSKIR1 A"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A) implies y inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 ?B"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          "x inHIDDENR3 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"and A4: "x inHIDDENR3 ?B"and A5: "y =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 x"
          using funct_1_def_6 sorry
        have " ex y2 be objectHIDDENM1 st (y2 inHIDDENR3 domRELAT-1K1 f & y2 inHIDDENR3 A) & x =HIDDENR1 f .FUNCT-1K1 y2"
          using A4 funct_1_def_6 sorry
        thus "y inHIDDENR3 A"
          using A1 A5 funct_1_th_32 sorry
      qed "sorry"
      thus "f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A) c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have "A c=TARSKIR1 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 ?B"
  proof-
    have "A c=TARSKIR1 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A6: "x inHIDDENR3 A"
        let ?y0 = "f .FUNCT-1K1 x"
        have A7: "f \<inverse>FUNCT-1K4 .FUNCT-1K1 ?y0 =HIDDENR1 x"
          using A1 A2 A6 funct_1_th_34 sorry
        have "?y0 inTARSKIR2 rngFUNCT-1K2 f"
          using A2 A6 funct_1_def_3 sorry
        then have A8: "?y0 inTARSKIR2 domRELAT-1K1 (f \<inverse>FUNCT-1K4)"
          using A1 funct_1_th_33 sorry
        have "?y0 inTARSKIR2 ?B"
          using A2 A6 funct_1_def_6 sorry
        thus "x inHIDDENR3 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A)"
          using A7 A8 funct_1_def_6 sorry
      qed "sorry"
      thus "A c=TARSKIR1 f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A)"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  thus "f \<inverse>FUNCT-1K4 .:FUNCT-1K5 (f .:FUNCT-1K5 A) =XBOOLE-0R4 A"
    using A3 sorry
qed "sorry"

mtheorem funct_1_cl_36:
  mlet "A be functionalFUNCT-1V6\<bar>setHIDDENM2", "x be objectHIDDENM1", "F be A -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster F .FUNCT-1K1 x as-term-is Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "F .FUNCT-1K1 x be Function-likeFUNCT-1V1\<bar>Relation-likeRELAT-1V1"
  proof-
    have "F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
    proof-
      show "F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
      proof-
        have cases: "x inHIDDENR3 domRELAT-1K1 F or  not x inHIDDENR3 domRELAT-1K1 F"
           sorry
        have case1: "x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume "x inHIDDENR3 domRELAT-1K1 F"
          then have A1: "F .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 F"
            using funct_1_def_3 sorry
          have "rngFUNCT-1K2 F c=TARSKIR1 A"
            using relat_1_def_19 sorry
          thus "F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
            using A1 sorry
        qed
        have case2: " not x inHIDDENR3 domRELAT-1K1 F implies F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
        proof(rule impI)
          assume " not x inHIDDENR3 domRELAT-1K1 F"
          thus "F .FUNCT-1K1 x be Function-likeFUNCT-1V1 & F .FUNCT-1K1 x be Relation-likeRELAT-1V1"
            using funct_1_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_108:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for f be FunctionFUNCT-1M1 holds x inHIDDENR3 X & x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "x inHIDDENR3 X"
      and A2: "x inHIDDENR3 domRELAT-1K1 f"
    have "x inHIDDENR3 X /\\XBOOLE-0K3 domRELAT-1K1 f"
      using A1 A2 xboole_0_def_4 sorry
    then have "x inHIDDENR3 domRELAT-1K1 (f  |RELAT-1K8 X)"
      using relat_1_th_61 sorry
    then have A3: "(f  |RELAT-1K8 X).FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 (f  |RELAT-1K8 X)"
      using funct_1_def_3 sorry
    have "(f  |RELAT-1K8 X).FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x"
      using A1 funct_1_th_49 sorry
    thus "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
      using A3 relat_1_th_115 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_109:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 & X c=TARSKIR1 domRELAT-1K1 f implies f .:FUNCT-1K5 X <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X <>HIDDENR2 {}XBOOLE-0K1 implies  not (X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X <>HIDDENR2 {}XBOOLE-0K1)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then have " ex x be objectHIDDENM1 st x inHIDDENR3 X"
      using xboole_0_def_1 sorry
    thus " not (X c=TARSKIR1 domRELAT-1K1 f & f .:FUNCT-1K5 X <>HIDDENR2 {}XBOOLE-0K1)"
      using funct_1_th_108 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_cl_37:
  mlet "f be  non trivialSUBSET-1V2\<bar>FunctionFUNCT-1M1"
"cluster domRELAT-1K1 f as-term-is  non trivialSUBSET-1V2"
proof
(*coherence*)
  show "domRELAT-1K1 f be  non trivialSUBSET-1V2"
  proof-
    have " not domRELAT-1K1 f be trivialZFMISC-1V1"
    proof-
      obtain u w where
        [ty]:"u be objectHIDDENM1" "w be objectHIDDENM1" and 
        A1: "u inHIDDENR3 f"and A2: "w inHIDDENR3 f"and A3: "u <>HIDDENR2 w"
        using zfmisc_1_def_10 sorry
      obtain u1 u2 where
        [ty]:"u1 be objectHIDDENM1" "u2 be objectHIDDENM1" and 
        A4: "u =HIDDENR1 [TARSKIK4 u1,u2 ]"
        using A1 relat_1_def_1 sorry
      obtain w1 w2 where
        [ty]:"w1 be objectHIDDENM1" "w2 be objectHIDDENM1" and 
        A5: "w =HIDDENR1 [TARSKIK4 w1,w2 ]"
        using A2 relat_1_def_1 sorry
      have " ex tVar34 be objectHIDDENM1 st (u1 inHIDDENR3 domRELAT-1K1 f & tVar34 inHIDDENR3 domRELAT-1K1 f) & u1 <>HIDDENR2 tVar34"
      proof(rule bexI[of _ "w1"],rule conjMI)
        show "u1 inHIDDENR3 domRELAT-1K1 f & w1 inHIDDENR3 domRELAT-1K1 f"
          using A4 A5 A1 A2 xtuple_0_def_12 sorry
        show "u1 <>HIDDENR2 w1"
          using A1 A2 A3 A4 A5 funct_1_def_1 sorry
      qed "sorry"
      thus " not domRELAT-1K1 f be trivialZFMISC-1V1"
        using bexI[of _ "u1"] zfmisc_1_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem funct_1_th_110:
" for B be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f =XBOOLE-0R4 unionTARSKIK3 B implies domRELAT-1K1 f =XBOOLE-0R4 unionTARSKIK3 ({domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  }) & rngFUNCT-1K2 f =XBOOLE-0R4 unionTARSKIK3 ({rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  })"
proof(rule ballI,rule ballI,rule impI,rule conjMI)
  fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>functionalFUNCT-1V6\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "f =XBOOLE-0R4 unionTARSKIK3 B"
  let ?X = "{domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  }"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f implies ( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  })) & (( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  }) implies x inHIDDENR3 domRELAT-1K1 f)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 domRELAT-1K1 f implies ( ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  })"
    proof(rule impI)
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then have "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
        using funct_1_th_1 sorry
      then obtain g where
        [ty]:"g be setHIDDENM2" and 
        A2: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 g"and A3: "g inTARSKIR2 B"
        using A1 tarski_def_4 sorry
      have 
        [ty]:"g be FunctionFUNCT-1M1"
        using A3 sorry
      obtain Z where 
        [ty]:"Z be setHIDDENM2" and ZDef:"Z = domRELAT-1K1 g"
         sorry
      show " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  }"
      proof(rule bexI[of _ "Z"])
        show "x inHIDDENR3 Z & Z inTARSKIR2 {domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  }"
          using A2 A3 funct_1_th_1 sorry
      qed "sorry"
    qed
    assume Given: " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 ?X"
    then obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A4: "x inHIDDENR3 Z"and A5: "Z inTARSKIR2 ?X"
       sorry
    obtain g where
      [ty]:"g be ElementSUBSET-1M1-of B" and 
      A6: "Z =XBOOLE-0R4 domRELAT-1K1 g"
      using A5 sorry
    have "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
      using A4 A6 funct_1_th_1 sorry
    then have "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 f"
      using A1 tarski_def_4 sorry
    thus "x inHIDDENR3 domRELAT-1K1 f"
      using funct_1_th_1 sorry
  qed "sorry"
  thus "domRELAT-1K1 f =XBOOLE-0R4 unionTARSKIK3 ({domRELAT-1K1 g where g be ElementSUBSET-1M1-of B :  True  })"
    using tarski_def_4 sorry
  let ?X = "{rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  }"
  have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies ( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  })) & (( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  }) implies y inHIDDENR3 rngFUNCT-1K2 f)"
  proof(rule ballI,rule conjMI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 rngFUNCT-1K2 f implies ( ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  })"
    proof(rule impI)
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A7: "x inHIDDENR3 domRELAT-1K1 f & y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "[TARSKIK4 x,y ] inHIDDENR3 f"
        using A7 funct_1_th_1 sorry
      then obtain g where
        [ty]:"g be setHIDDENM2" and 
        A8: "[TARSKIK4 x,y ] inHIDDENR3 g"and A9: "g inTARSKIR2 B"
        using A1 tarski_def_4 sorry
      have 
        [ty]:"g be FunctionFUNCT-1M1"
        using A9 sorry
      obtain Z where 
        [ty]:"Z be setHIDDENM2" and ZDef:"Z = rngFUNCT-1K2 g"
         sorry
      show " ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  }"
      proof(rule bexI[of _ "Z"])
        have "x inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 x"
          using A8 funct_1_th_1 sorry
        thus "y inHIDDENR3 Z & Z inTARSKIR2 {rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  }"
          using A9 funct_1_def_3 sorry
      qed "sorry"
    qed
    assume Given: " ex Z be setHIDDENM2 st y inHIDDENR3 Z & Z inTARSKIR2 ?X"
    then obtain Z where
      [ty]:"Z be setHIDDENM2" and 
      A10: "y inHIDDENR3 Z"and A11: "Z inTARSKIR2 ?X"
       sorry
    obtain g where
      [ty]:"g be ElementSUBSET-1M1-of B" and 
      A12: "Z =XBOOLE-0R4 rngFUNCT-1K2 g"
      using A11 sorry
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A13: "x inHIDDENR3 domRELAT-1K1 g & y =HIDDENR1 g .FUNCT-1K1 x"
      using A10 A12 funct_1_def_3 sorry
    have "[TARSKIK4 x,y ] inHIDDENR3 g"
      using A13 funct_1_th_1 sorry
    then have "[TARSKIK4 x,y ] inHIDDENR3 f"
      using A1 tarski_def_4 sorry
    thus "y inHIDDENR3 rngFUNCT-1K2 f"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 f =XBOOLE-0R4 unionTARSKIK3 ({rngFUNCT-1K2 g where g be ElementSUBSET-1M1-of B :  True  })"
    using tarski_def_4 sorry
qed "sorry"

theorem funct_1_sch_5:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for X be setHIDDENM2 holds X inTARSKIR2 Af0 implies f .FUNCT-1K1 X =HIDDENR1 Ff1(X))"
  proof-
    have " ex tVar37 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar37 =XBOOLE-0R4 Af0 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 Af0 &  not tVar37 .FUNCT-1K1 X =HIDDENR1 Ff1(X)))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =HIDDENR1 Ff1(Lamb1)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
         sorry
      have A2: " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (x inHIDDENR3 Af0 & ?P(x,y1)) & ?P(x,y2) implies y1 =HIDDENR1 y2"
         sorry
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ?P(x,f .FUNCT-1K1 x)"
        using funct_1_sch_2 A2 A1 sorry
      show " ex tVar37 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar37 =XBOOLE-0R4 Af0 & ( for X be setHIDDENM2 holds  not (X inTARSKIR2 Af0 &  not tVar37 .FUNCT-1K1 X =HIDDENR1 Ff1(X)))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 Af0"
          using A3 sorry
        show " for X be setHIDDENM2 holds  not (X inTARSKIR2 Af0 &  not f .FUNCT-1K1 X =HIDDENR1 Ff1(X))"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_1_th_111:
" for M be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1) implies ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 M & ( for X be setHIDDENM2 holds X inTARSKIR2 M implies f .FUNCT-1K1 X inTARSKIR2 X))"
proof-
  have " for M be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1) implies ( ex tVar38 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar38 =XBOOLE-0R4 M & ( for X be setHIDDENM2 holds X inTARSKIR2 M implies tVar38 .FUNCT-1K1 X inTARSKIR2 X))"
  proof(rule ballI,rule impI)
    fix M assume [ty]: "M be setHIDDENM2"
    assume A1: " for X be setHIDDENM2 holds X inTARSKIR2 M implies X <>HIDDENR2 {}XBOOLE-0K1"
    let ?F = "\<lambda>Lamb1. the ElementSUBSET-1M1-of Lamb1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "domRELAT-1K1 f =XBOOLE-0R4 M"and A3: " for X be setHIDDENM2 holds X inTARSKIR2 M implies f .FUNCT-1K1 X =XBOOLE-0R4 ?F(X)"
      using funct_1_sch_5 sorry
    show " ex tVar38 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar38 =XBOOLE-0R4 M & ( for X be setHIDDENM2 holds X inTARSKIR2 M implies tVar38 .FUNCT-1K1 X inTARSKIR2 X)"
    proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
      show "domRELAT-1K1 f =XBOOLE-0R4 M"
        using A2 sorry
      fix X assume [ty]: "X be setHIDDENM2"
      assume A4: "X inTARSKIR2 M"
      then have A5: "f .FUNCT-1K1 X =XBOOLE-0R4 the ElementSUBSET-1M1-of X"
        using A3 sorry
      have "X <>HIDDENR2 {}XBOOLE-0K1"
        using A1 A4 sorry
      thus "f .FUNCT-1K1 X inTARSKIR2 X"
        using A5 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem funct_1_sch_6:
  fixes Xf0 Yf0 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st y inHIDDENR3 Yf0 & Pp2(x,y))"
  shows " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 f c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,f .FUNCT-1K1 x))"
  proof-
    have " ex tVar39 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar39 =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 tVar39 c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar39 .FUNCT-1K1 x)))"
    proof-
      show " ex tVar39 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar39 =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 tVar39 c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar39 .FUNCT-1K1 x)))"
      proof-
        have cases: "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1 or Xf0 <>HIDDENR2 {}XBOOLE-0K1"
           sorry
        have case1: "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar39 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar39 =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 tVar39 c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar39 .FUNCT-1K1 x))))"
        proof(rule impI)
          assume A2: "Xf0 =XBOOLE-0R4 {}XBOOLE-0K1"
          show " ex tVar39 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar39 =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 tVar39 c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,tVar39 .FUNCT-1K1 x)))"
          proof(rule bexI[of _ "{}XBOOLE-0K1"])
            show "(domRELAT-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 Xf0 & rngFUNCT-1K2 ({}XBOOLE-0K1) c=TARSKIR1 Yf0) & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 Xf0 &  not Pp2(x,{}XBOOLE-0K1 .FUNCT-1K1 x)))"
              using A2 sorry
          qed "sorry"
        qed
        have case2: "Xf0 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & (rngFUNCT-1K2 f c=TARSKIR1 Yf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,f .FUNCT-1K1 x))))"
        proof(rule impI)
          assume A3: "Xf0 <>HIDDENR2 {}XBOOLE-0K1"
          let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex D2 be setHIDDENM2 st D2 =HIDDENR1 Lamb2 & ( for y be objectHIDDENM1 holds y inHIDDENR3 D2 iff y inHIDDENR3 Yf0 & Pp2(Lamb1,y))"
          have A4: " for e be objectHIDDENM1 holds  for u1 be objectHIDDENM1 holds  for u2 be objectHIDDENM1 holds (e inHIDDENR3 Xf0 & ?Q(e,u1)) & ?Q(e,u2) implies u1 =HIDDENR1 u2"
          proof-
            have " for e be objectHIDDENM1 holds  for u1 be objectHIDDENM1 holds  for u2 be objectHIDDENM1 holds e inHIDDENR3 Xf0 implies (( ex U1 be setHIDDENM2 st U1 =HIDDENR1 u1 & ( for y be objectHIDDENM1 holds y inHIDDENR3 U1 iff y inHIDDENR3 Yf0 & Pp2(e,y))) implies (( ex U2 be setHIDDENM2 st U2 =HIDDENR1 u2 & ( for y be objectHIDDENM1 holds y inHIDDENR3 U2 iff y inHIDDENR3 Yf0 & Pp2(e,y))) implies u1 =HIDDENR1 u2))"
            proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              fix u1 assume [ty]: "u1 be objectHIDDENM1"
              fix u2 assume [ty]: "u2 be objectHIDDENM1"
              assume "e inHIDDENR3 Xf0"
              assume Given: " ex U1 be setHIDDENM2 st U1 =HIDDENR1 u1 & ( for y be objectHIDDENM1 holds y inHIDDENR3 U1 iff y inHIDDENR3 Yf0 & Pp2(e,y))"
              then obtain U1 where
                [ty]:"U1 be setHIDDENM2" and 
                A5: "U1 =HIDDENR1 u1"and A6: " for y be objectHIDDENM1 holds y inHIDDENR3 U1 iff y inHIDDENR3 Yf0 & Pp2(e,y)"
                 sorry
              let ?A = "\<lambda>Lamb1. Lamb1 inHIDDENR3 Yf0 & Pp2(e,Lamb1)"
              have A7: " for x be objectHIDDENM1 holds x inHIDDENR3 U1 iff ?A(x)"
                using A6 sorry
              assume Given: " ex U2 be setHIDDENM2 st U2 =HIDDENR1 u2 & ( for y be objectHIDDENM1 holds y inHIDDENR3 U2 iff y inHIDDENR3 Yf0 & Pp2(e,y))"
              then obtain U2 where
                [ty]:"U2 be setHIDDENM2" and 
                A8: "U2 =HIDDENR1 u2"and A9: " for y be objectHIDDENM1 holds y inHIDDENR3 U2 iff y inHIDDENR3 Yf0 & Pp2(e,y)"
                 sorry
              have A10: " for x be objectHIDDENM1 holds x inHIDDENR3 U2 iff ?A(x)"
                using A9 sorry
              have "U1 =XBOOLE-0R4 U2"
                using xboole_0_sch_2 A7 A10 sorry
              thus "u1 =HIDDENR1 u2"
                using A5 A8 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A11: " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex y be objectHIDDENM1 st ?Q(x,y))"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ( ex tVar40 be objectHIDDENM1 st  ex D2 be setHIDDENM2 st D2 =HIDDENR1 tVar40 & ( for y be objectHIDDENM1 holds y inHIDDENR3 D2 iff y inHIDDENR3 Yf0 & Pp2(x,y)))"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 Xf0"
              let ?R = "\<lambda>Lamb1. Pp2(x,Lamb1)"
              obtain X where
                [ty]:"X be setHIDDENM2" and 
                A12: " for y be objectHIDDENM1 holds y inHIDDENR3 X iff y inHIDDENR3 Yf0 & ?R(y)"
                using xboole_0_sch_1 sorry
              show " ex tVar40 be objectHIDDENM1 st  ex D2 be setHIDDENM2 st D2 =HIDDENR1 tVar40 & ( for y be objectHIDDENM1 holds y inHIDDENR3 D2 iff y inHIDDENR3 Yf0 & Pp2(x,y))"
              proof(rule bexI[of _ "X"])
                show " ex D2 be setHIDDENM2 st D2 =HIDDENR1 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 D2 iff y inHIDDENR3 Yf0 & Pp2(x,y))"
                  using A12 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain G where
            [ty]:"G be FunctionFUNCT-1M1" and 
            A13: "domRELAT-1K1 G =XBOOLE-0R4 Xf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies ?Q(x,G .FUNCT-1K1 x))"
            using funct_1_sch_2 A4 A11 sorry
          obtain D where 
            [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and DDef:"D = rngFUNCT-1K2 G"
            using A13 A3 relat_1_th_42 sorry
          have " for X be setHIDDENM2 holds X inTARSKIR2 D implies X <>HIDDENR2 {}XBOOLE-0K1"
          proof(rule ballI,rule impI)
            fix X assume [ty]: "X be setHIDDENM2"
            assume "X inTARSKIR2 D"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A14: "x inHIDDENR3 domRELAT-1K1 G & X =XBOOLE-0R4 G .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A15: "y inHIDDENR3 Yf0 & Pp2(x,y)"
              using A1 A13 A14 sorry
            have "?Q(x,G .FUNCT-1K1 x)"
              using A13 A14 sorry
            then have "y inHIDDENR3 X"
              using A15 A14 sorry
            thus "X <>HIDDENR2 {}XBOOLE-0K1"
               sorry
          qed "sorry"
          then obtain F where
            [ty]:"F be FunctionFUNCT-1M1" and 
            A16: "domRELAT-1K1 F =XBOOLE-0R4 D"and A17: " for X be setHIDDENM2 holds X inTARSKIR2 D implies F .FUNCT-1K1 X inTARSKIR2 X"
            using funct_1_th_111 sorry
          have A18: "domRELAT-1K1 (F *FUNCT-1K3 G) =XBOOLE-0R4 Xf0"
            using A13 A16 relat_1_th_27 sorry
          obtain f where 
            [ty]:"f be setHIDDENM2" and fDef:"f = F *FUNCT-1K3 G"
             sorry
          show " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Xf0 & (rngFUNCT-1K2 f c=TARSKIR1 Yf0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Xf0 implies Pp2(x,f .FUNCT-1K1 x)))"
          proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule ballI,rule impI)
            show "domRELAT-1K1 f =XBOOLE-0R4 Xf0"
              using A13 A16 relat_1_th_27 sorry
            have "rngFUNCT-1K2 F c=TARSKIR1 Yf0"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 F implies x inHIDDENR3 Yf0"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 F"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A19: "y inHIDDENR3 domRELAT-1K1 F"and A20: "x =HIDDENR1 F .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                obtain z where
                  [ty]:"z be objectHIDDENM1" and 
                  A21: "z inHIDDENR3 domRELAT-1K1 G & y =HIDDENR1 G .FUNCT-1K1 z"
                  using A16 A19 funct_1_def_3 sorry
                have 
                  [ty]:"y be setHIDDENM2"
                  using tarski_th_1 sorry
                have A22: "x inHIDDENR3 y"
                  using A16 A17 A19 A20 sorry
                have "?Q(z,G .FUNCT-1K1 z)"
                  using A13 A21 sorry
                thus "x inHIDDENR3 Yf0"
                  using A21 A22 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 F c=TARSKIR1 Yf0"
                using tarski_def_3 sorry
            qed
            thus "rngFUNCT-1K2 f c=TARSKIR1 Yf0"
              using A16 relat_1_th_28 sorry
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A23: "x inHIDDENR3 Xf0"
            then have "f .FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 (G .FUNCT-1K1 x) & G .FUNCT-1K1 x inTARSKIR2 D"
              using A13 A18 funct_1_th_12 funct_1_def_3 sorry
            then have A24: "f .FUNCT-1K1 x inTARSKIR2 G .FUNCT-1K1 x"
              using A17 sorry
            have "?Q(x,G .FUNCT-1K1 x)"
              using A13 A23 sorry
            thus "Pp2(x,f .FUNCT-1K1 x)"
              using A24 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem funct_1_cl_38:
  mlet "f be empty-yieldingFUNCT-1V3\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be emptyXBOOLE-0V1"
  proof-
    have "x inHIDDENR3 domRELAT-1K1 f or  not x inHIDDENR3 domRELAT-1K1 f"
       sorry
    thus "f .FUNCT-1K1 x be emptyXBOOLE-0V1"
      using funct_1_def_2 funct_1_def_8 sorry
  qed
qed "sorry"

mtheorem funct_1_th_112:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds (f c=RELAT-1R2 h & g c=RELAT-1R2 h) & f missesXBOOLE-0R1 g implies domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds  for h be FunctionFUNCT-1M1 holds f c=RELAT-1R2 h & (g c=RELAT-1R2 h & f missesXBOOLE-0R1 g) implies domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    fix h assume [ty]: "h be FunctionFUNCT-1M1"
    assume A1: "f c=RELAT-1R2 h"
      and A2: "g c=RELAT-1R2 h"
      and A3: "f missesXBOOLE-0R1 g"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies  not x inHIDDENR3 domRELAT-1K1 g"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then have A4: "[TARSKIK4 x,f .FUNCT-1K1 x ] inHIDDENR3 f"
        using funct_1_def_2 sorry
      have "x inHIDDENR3 domRELAT-1K1 g implies  False "
      proof(rule impI)
        assume "x inHIDDENR3 domRELAT-1K1 g"
        then have A5: "[TARSKIK4 x,g .FUNCT-1K1 x ] inHIDDENR3 g"
          using funct_1_def_2 sorry
        then have "f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
          using A1 A2 A4 funct_1_def_1 sorry
        thus " False "
          using A3 A4 A5 xboole_0_th_3 sorry
      qed
      thus " not x inHIDDENR3 domRELAT-1K1 g"
         sorry
    qed "sorry"
    thus "domRELAT-1K1 f missesXBOOLE-0R1 domRELAT-1K1 g"
      using xboole_0_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem funct_1_th_113:
" for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds Y  |`RELAT-1K9 f =FUNCT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y"
proof(rule ballI,rule ballI)
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have A1: "Y  |`RELAT-1K9 f c=RELAT-1R2 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y"
    using relat_1_th_188 sorry
  have "f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y c=RELAT-1R2 Y  |`RELAT-1K9 f"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y implies [TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 f"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A2: "[TARSKIK4 x,y ] inHIDDENR3 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y"
      then have A3: "x inHIDDENR3 f \<inverse>FUNCT-1K6 Y"
        using relat_1_def_11 sorry
      have A4: "[TARSKIK4 x,y ] inHIDDENR3 f"
        using A2 relat_1_def_11 sorry
      have "f .FUNCT-1K1 x inTARSKIR2 Y"
        using A3 funct_1_def_7 sorry
      then have "y inHIDDENR3 Y"
        using A4 funct_1_th_1 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 Y  |`RELAT-1K9 f"
        using A4 relat_1_def_12 sorry
    qed "sorry"
    thus "f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y c=RELAT-1R2 Y  |`RELAT-1K9 f"
      using relat_1_def_3 sorry
  qed
  thus "Y  |`RELAT-1K9 f =FUNCT-1R1 f  |RELAT-1K8 f \<inverse>FUNCT-1K6 Y"
    using A1 sorry
qed "sorry"

mtheorem funct_1_reduce_1:
  mlet "X be setHIDDENM2", "x be ElementSUBSET-1M1-of X"
"reduce idRELAT-1K7 X .FUNCT-1K1 x to x"
proof
(*reducibility*)
  show "idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
  proof-
    show "idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
    proof-
      have cases: "X be emptyXBOOLE-0V1 or X be  non emptyXBOOLE-0V1"
         sorry
      have case1: "X be emptyXBOOLE-0V1 implies idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
      proof(rule impI)
        assume A1: "X be emptyXBOOLE-0V1"
        then have "x be emptyXBOOLE-0V1"
          using subset_1_def_1 sorry
        thus "idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
          using A1 sorry
      qed
      have case2: "X be  non emptyXBOOLE-0V1 implies idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
      proof(rule impI)
        assume "X be  non emptyXBOOLE-0V1"
        thus "idRELAT-1K7 X .FUNCT-1K1 x =HIDDENR1 x"
          using funct_1_th_18 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

mtheorem funct_1_th_114:
" for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 g implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies ( ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y))"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 g implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies  not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix g assume [ty]: "g be FunctionFUNCT-1M1"
    assume A1: "rngFUNCT-1K2 f c=TARSKIR1 rngFUNCT-1K2 g"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 domRELAT-1K1 f"
    then have "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
      using funct_1_def_3 sorry
    then have A2: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 g"
      using A1 sorry
    have " ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
      using funct_1_def_3 A2 sorry
    thus " not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 domRELAT-1K1 g & f .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
