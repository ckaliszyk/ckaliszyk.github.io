theory mcart_1
  imports funct_1 xregular
begin
(*begin*)
reserve v, x, x1, x2, x3, x4, y, y1, y2, y3, y4, z, z1, z2 for "objectHIDDENM1"
reserve X, X1, X2, X3, X4, Y, Y1, Y2, Y3, Y4, Y5, Z, Z1, Z2, Z3, Z4, Z5 for "setHIDDENM2"
(*\$CT 8*)
mtheorem mcart_1_th_9:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be objectHIDDENM1 st v inHIDDENR3 X &  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [TARSKIK4 x,y ]))"
proof-
  have " for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [TARSKIK4 x,y ]) implies  False ))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A1: "Y inTARSKIR2 X"and A2: " not ( ex Y1 be setHIDDENM2 st Y1 inTARSKIR2 Y &  not Y1 missesXBOOLE-0R1 X)"
      using xregular_th_2 sorry
    obtain v where 
      [ty]:"v be setHIDDENM2" and vDef:"v = Y"
       sorry
    show " ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [TARSKIK4 x,y ]) implies  False )"
    proof(rule bexI[of _ "v"],rule conjMI,rule impI)
      show "v inTARSKIR2 X"
        using A1 sorry
      assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [TARSKIK4 x,y ]"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A3: "x inHIDDENR3 X or y inHIDDENR3 X"and A4: "v =HIDDENR1 [TARSKIK4 x,y ]"
         sorry
      have A5: "{TARSKIK2 x,y } inTARSKIR2 Y"
        using A4 tarski_def_2 sorry
      have "x inHIDDENR3 {TARSKIK2 x,y } & y inHIDDENR3 {TARSKIK2 x,y }"
        using tarski_def_2 sorry
      thus " False "
        using A2 A5 A3 xboole_0_th_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_10:
" for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 inHIDDENR3 Y"
proof-
  have " for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 inHIDDENR3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A1: "(x inHIDDENR3 X & y inHIDDENR3 Y) & z =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_def_2 sorry
    show "z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 inHIDDENR3 Y"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem mcart_1_th_12:
" for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},Y :] implies z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 inHIDDENR3 Y"
proof-
  have " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},Y :] implies z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 inHIDDENR3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},Y :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK1 x}"
      using mcart_1_th_10 sorry
    thus "z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 inHIDDENR3 Y"
      using A1 mcart_1_th_10 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_13:
" for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 y} :] implies z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 =HIDDENR1 y"
proof-
  have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 y} :] implies z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 y} :]"
    then have "z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
      using mcart_1_th_10 sorry
    thus "z `1XTUPLE-0K1 inHIDDENR3 X & z `2XTUPLE-0K2 =HIDDENR1 y"
      using A1 mcart_1_th_10 tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_14:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] implies z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :] implies z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK1 y} :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK1 x} & z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
      using mcart_1_th_10 sorry
    thus "z `1XTUPLE-0K1 =HIDDENR1 x & z `2XTUPLE-0K2 =HIDDENR1 y"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_15:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },Y :] implies (z `1XTUPLE-0K1 =HIDDENR1 x1 or z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 inHIDDENR3 Y"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for Y be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },Y :] implies  not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 inHIDDENR3 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },Y :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK2 x1,x2 }"
      using mcart_1_th_10 sorry
    thus " not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 inHIDDENR3 Y"
      using A1 mcart_1_th_10 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_16:
" for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK2 y1,y2 } :] implies z `1XTUPLE-0K1 inHIDDENR3 X & (z `2XTUPLE-0K2 =HIDDENR1 y1 or z `2XTUPLE-0K2 =HIDDENR1 y2)"
proof-
  have " for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds  for X be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK2 y1,y2 } :] implies z `1XTUPLE-0K1 inHIDDENR3 X &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK2 y1,y2 } :]"
    then have "z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK2 y1,y2 }"
      using mcart_1_th_10 sorry
    thus "z `1XTUPLE-0K1 inHIDDENR3 X &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
      using A1 mcart_1_th_10 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_17:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK1 y} :] implies (z `1XTUPLE-0K1 =HIDDENR1 x1 or z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 =HIDDENR1 y"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK1 y} :] implies  not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK1 y} :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK2 x1,x2 } & z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK1 y}"
      using mcart_1_th_10 sorry
    thus " not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) & z `2XTUPLE-0K2 =HIDDENR1 y"
      using tarski_def_1 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_18:
" for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y1,y2 } :] implies z `1XTUPLE-0K1 =HIDDENR1 x & (z `2XTUPLE-0K2 =HIDDENR1 y1 or z `2XTUPLE-0K2 =HIDDENR1 y2)"
proof-
  have " for x be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y1,y2 } :] implies z `1XTUPLE-0K1 =HIDDENR1 x &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK1 x},{TARSKIK2 y1,y2 } :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK1 x} & z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK2 y1,y2 }"
      using mcart_1_th_10 sorry
    thus "z `1XTUPLE-0K1 =HIDDENR1 x &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
      using tarski_def_1 tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_19:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] implies (z `1XTUPLE-0K1 =HIDDENR1 x1 or z `1XTUPLE-0K1 =HIDDENR1 x2) & (z `2XTUPLE-0K2 =HIDDENR1 y1 or z `2XTUPLE-0K2 =HIDDENR1 y2)"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] implies  not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "z inHIDDENR3 [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :]"
    then have "z `1XTUPLE-0K1 inHIDDENR3 {TARSKIK2 x1,x2 } & z `2XTUPLE-0K2 inHIDDENR3 {TARSKIK2 y1,y2 }"
      using mcart_1_th_10 sorry
    thus " not ( not z `1XTUPLE-0K1 =HIDDENR1 x1 &  not z `1XTUPLE-0K1 =HIDDENR1 x2) &  not ( not z `2XTUPLE-0K2 =HIDDENR1 y1 &  not z `2XTUPLE-0K2 =HIDDENR1 y2)"
      using tarski_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_20:
" for x be objectHIDDENM1 holds ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]) implies x <>HIDDENR2 x `1XTUPLE-0K1 & x <>HIDDENR2 x `2XTUPLE-0K2"
proof-
  have " for x be objectHIDDENM1 holds ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]) implies x <>HIDDENR2 x `1XTUPLE-0K1 &  not x <>HIDDENR2 x `2XTUPLE-0K2"
  proof(rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume Given: " ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 y,z ]"
    then obtain y z where
      [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [TARSKIK4 y,z ]"
       sorry
    have "y =HIDDENR1 x implies  False "
    proof(rule impI)
      assume "y =HIDDENR1 x"
      then have "{TARSKIK2 {TARSKIK2 y,z },{TARSKIK1 y} } inTARSKIR2 {TARSKIK1 y}"
        using A1 tarski_def_1 sorry
      thus " False "
        using tarski_def_2 sorry
    qed
    thus "x <>HIDDENR2 x `1XTUPLE-0K1"
      using A1 sorry
    have "z =HIDDENR1 x implies  False "
    proof(rule impI)
      assume "z =HIDDENR1 x"
      then have "{TARSKIK2 {TARSKIK2 y,z },{TARSKIK1 y} } inTARSKIR2 {TARSKIK2 y,z }"
        using A1 tarski_def_2 sorry
      thus " False "
        using tarski_def_2 sorry
    qed
    thus " not x <>HIDDENR2 x `2XTUPLE-0K2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve R for "RelationRELAT-1M1"
mtheorem mcart_1_th_21:
" for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 R implies x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
proof-
  have " for x be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds x inHIDDENR3 R implies x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "x inHIDDENR3 R"
    then have " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st x =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using relat_1_def_1 sorry
    thus "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mcart_1_lm_1:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds  ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st x =HIDDENR1 [TARSKIK4 xx1,xx2 ])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds  ex tVar2 be ElementSUBSET-1M1-of X1 st  ex tVar3 be ElementSUBSET-1M1-of X2 st x =HIDDENR1 [TARSKIK4 tVar2,tVar3 ])"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    assume A1: "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
    obtain xx2 where 
      [ty]:"xx2 be ElementSUBSET-1M1-of X2" and xx2Def:"xx2 = x `2XTUPLE-0K2"
      using A1 mcart_1_th_10 sorry
    obtain xx1 where 
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" and xx1Def:"xx1 = x `1XTUPLE-0K1"
      using A1 mcart_1_th_10 sorry
    show " ex tVar2 be ElementSUBSET-1M1-of X1 st  ex tVar3 be ElementSUBSET-1M1-of X2 st x =HIDDENR1 [TARSKIK4 tVar2,tVar3 ]"
    proof(rule bexI[of _ "xx1"])
      show " ex tVar3 be ElementSUBSET-1M1-of X2 st x =HIDDENR1 [TARSKIK4 xx1,tVar3 ]"
      proof(rule bexI[of _ "xx2"])
        show "x =HIDDENR1 [TARSKIK4 xx1,xx2 ]"
          using A1 mcart_1_th_21 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_cl_1:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that pairXTUPLE-0V1 for ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds it be pairXTUPLE-0V1"
  proof-
    have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :] holds x be pairXTUPLE-0V1"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]"
      have " ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st x =HIDDENR1 [TARSKIK4 xx1,xx2 ]"
        using mcart_1_lm_1 sorry
      thus "x be pairXTUPLE-0V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ])"
  using mcart_1_th_21 sorry

mtheorem mcart_1_th_23:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =XBOOLE-0R4 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "[:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK2 y1,y2 } :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 x2},{TARSKIK2 y1,y2 } :]"
      using zfmisc_1_th_109 sorry
    also have "... = {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK1 x2},{TARSKIK2 y1,y2 } :]"
      using zfmisc_1_th_30 sorry
    also have "... = {TARSKIK2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 {TARSKIK2 [TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
      using zfmisc_1_th_30 sorry
    also have "... = {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
      using enumset1_th_5 sorry
    finally show "[:ZFMISC-1K2 {TARSKIK2 x1,x2 },{TARSKIK2 y1,y2 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 x1,y1 ],[TARSKIK4 x1,y2 ],[TARSKIK4 x2,y1 ],[TARSKIK4 x2,y2 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds x <>HIDDENR2 x `1XTUPLE-0K1 & x <>HIDDENR2 x `2XTUPLE-0K2)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds  not x <>HIDDENR2 x `1XTUPLE-0K1 &  not x <>HIDDENR2 x `2XTUPLE-0K2)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :]"
    have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
      using A1 mcart_1_th_21 sorry
    thus " not x <>HIDDENR2 x `1XTUPLE-0K1 &  not x <>HIDDENR2 x `2XTUPLE-0K2"
      using mcart_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem mcart_1_th_26:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be objectHIDDENM1 st v inHIDDENR3 X &  not ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K3 x,y,z ]))"
proof-
  have " for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K3 x,y,z ]) implies  False ))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A1: "Y inTARSKIR2 X"and A2: " not ( ex Y1 be setHIDDENM2 st  ex Y2 be setHIDDENM2 st  ex Y3 be setHIDDENM2 st ((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y) &  not Y1 missesXBOOLE-0R1 X)"
      using xregular_th_4 sorry
    obtain v where 
      [ty]:"v be setHIDDENM2" and vDef:"v = Y"
       sorry
    show " ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K3 x,y,z ]) implies  False )"
    proof(rule bexI[of _ "v"],rule conjMI,rule impI)
      show "v inTARSKIR2 X"
        using A1 sorry
      assume Given: " ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (x inHIDDENR3 X or y inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K3 x,y,z ]"
      then obtain x y z where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" "z be objectHIDDENM1" and 
        A3: "x inHIDDENR3 X or y inHIDDENR3 X"and A4: "v =HIDDENR1 [XTUPLE-0K3 x,y,z ]"
         sorry
      let ?Y1 = "{TARSKIK2 x,y }"
      let ?Y2 = "{TARSKIK2 ?Y1,{TARSKIK1 x} }"
      let ?Y3 = "{TARSKIK2 ?Y2,z }"
      have A5: "x inHIDDENR3 ?Y1 & y inHIDDENR3 ?Y1"
        using tarski_def_2 sorry
      have A6: "?Y3 inTARSKIR2 Y"
        using A4 tarski_def_2 sorry
      have "?Y1 inTARSKIR2 ?Y2 & ?Y2 inTARSKIR2 ?Y3"
        using tarski_def_2 sorry
      thus " False "
        using A2 A5 A6 A3 xboole_0_th_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 3*)
mtheorem mcart_1_th_30:
" for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be objectHIDDENM1 st v inHIDDENR3 X &  not ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (x1 inHIDDENR3 X or x2 inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]))"
proof-
  have " for X be setHIDDENM2 holds X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (x1 inHIDDENR3 X or x2 inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]) implies  False ))"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X <>HIDDENR2 {}XBOOLE-0K1"
    then obtain Y where
      [ty]:"Y be setHIDDENM2" and 
      A1: "Y inTARSKIR2 X"and A2: " for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds  for Y5 be setHIDDENM2 holds (((Y1 inTARSKIR2 Y2 & Y2 inTARSKIR2 Y3) & Y3 inTARSKIR2 Y4) & Y4 inTARSKIR2 Y5) & Y5 inTARSKIR2 Y implies Y1 missesXBOOLE-0R1 X"
      using xregular_th_6 sorry
    obtain v where 
      [ty]:"v be setHIDDENM2" and vDef:"v = Y"
       sorry
    show " ex v be setHIDDENM2 st v inTARSKIR2 X & (( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (x1 inHIDDENR3 X or x2 inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]) implies  False )"
    proof(rule bexI[of _ "v"],rule conjMI,rule impI)
      show "v inTARSKIR2 X"
        using A1 sorry
      assume Given: " ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (x1 inHIDDENR3 X or x2 inHIDDENR3 X) & v =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      then obtain x1 x2 x3 x4 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
        A3: "x1 inHIDDENR3 X or x2 inHIDDENR3 X"and A4: "v =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
         sorry
      let ?Y1 = "{TARSKIK2 x1,x2 }"
      let ?Y2 = "{TARSKIK2 ?Y1,{TARSKIK1 x1} }"
      let ?Y3 = "{TARSKIK2 ?Y2,x3 }"
      let ?Y4 = "{TARSKIK2 ?Y3,{TARSKIK1 ?Y2} }"
      let ?Y5 = "{TARSKIK2 ?Y4,x4 }"
      have A5: "?Y3 inTARSKIR2 ?Y4 & ?Y4 inTARSKIR2 ?Y5"
        using tarski_def_2 sorry
      have A6: "?Y5 inTARSKIR2 Y"
        using A4 tarski_def_2 sorry
      have A7: "x1 inHIDDENR3 ?Y1 & x2 inHIDDENR3 ?Y1"
        using tarski_def_2 sorry
      have "?Y1 inTARSKIR2 ?Y2 & ?Y2 inTARSKIR2 ?Y3"
        using tarski_def_2 sorry
      thus " False "
        using A2 A7 A5 A6 A3 xboole_0_th_3 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_31:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 iff [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  not ((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1) &  not ( not [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1 &  not (( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1))"
  proof(rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    have A1: "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1 iff [:ZFMISC-1K2 X1,X2 :] <>HIDDENR2 {}XBOOLE-0K1"
      using zfmisc_1_th_90 sorry
    have "[:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
      using zfmisc_1_def_3 sorry
    thus " not ((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1) &  not ( not [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1 &  not (( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1))"
      using A1 zfmisc_1_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve xx1 for "ElementSUBSET-1M1-of X1"
reserve xx2 for "ElementSUBSET-1M1-of X2"
reserve xx3 for "ElementSUBSET-1M1-of X3"
mtheorem mcart_1_th_32:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :] implies (X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3)"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1 implies (X3 <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :] implies (X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    have A1: "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      using zfmisc_1_def_3 sorry
    assume A2: "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
    assume A3: "X3 <>HIDDENR2 {}XBOOLE-0K1"
    assume "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
    then have A4: "[:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] =RELAT-1R1 [:ZFMISC-1K2 [:ZFMISC-1K2 Y1,Y2 :],Y3 :]"
      using A1 zfmisc_1_def_3 sorry
    then have "[:ZFMISC-1K2 X1,X2 :] =RELAT-1R1 [:ZFMISC-1K2 Y1,Y2 :]"
      using A2 A3 zfmisc_1_th_110 sorry
    thus "(X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3"
      using A2 A3 A4 zfmisc_1_th_110 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_33:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1 & [:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :] implies (X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1 implies  not ([:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :] &  not ((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    assume A1: "[:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "X3 <>HIDDENR2 {}XBOOLE-0K1"
      using mcart_1_th_31 sorry
    have "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
      using A1 mcart_1_th_31 sorry
    thus " not ([:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :] &  not ((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3))"
      using A2 mcart_1_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K3 X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K3 Y,Y,Y :] implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K3 X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K3 Y,Y,Y :] implies X =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "[:ZFMISC-1K3 X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K3 Y,Y,Y :]"
    then have "X <>HIDDENR2 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1 implies X =XBOOLE-0R4 Y"
      using mcart_1_th_32 sorry
    thus "X =XBOOLE-0R4 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma mcart_1_lm_2:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st  ex xx3 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  ex tVar6 be ElementSUBSET-1M1-of X1 st  ex tVar7 be ElementSUBSET-1M1-of X2 st  ex tVar8 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 tVar6,tVar7,tVar8 ])"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    assume A1: "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X3 <>HIDDENR2 {}XBOOLE-0K1"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    obtain x9 where 
      [ty]:"x9 be ElementSUBSET-1M1-of [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]" and x9Def:"x9 = x"
      using zfmisc_1_def_3 sorry
    obtain x12 xx3 where
      [ty]:"x12 be ElementSUBSET-1M1-of [:ZFMISC-1K2 X1,X2 :]" "xx3 be ElementSUBSET-1M1-of X3" and 
      A3: "x9 =HIDDENR1 [TARSKIK4 x12,xx3 ]"
      using A1 A2 mcart_1_lm_1 sorry
    obtain xx1 xx2 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" and 
      A4: "x12 =HIDDENR1 [TARSKIK4 xx1,xx2 ]"
      using A1 mcart_1_lm_1 sorry
    show " ex tVar6 be ElementSUBSET-1M1-of X1 st  ex tVar7 be ElementSUBSET-1M1-of X2 st  ex tVar8 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 tVar6,tVar7,tVar8 ]"
    proof(rule bexI[of _ "xx1"])
      show " ex tVar7 be ElementSUBSET-1M1-of X2 st  ex tVar8 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 xx1,tVar7,tVar8 ]"
      proof(rule bexI[of _ "xx2"])
        show " ex tVar8 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,tVar8 ]"
        proof(rule bexI[of _ "xx3"])
          show "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
            using A3 A4 sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_35:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3} :] =XBOOLE-0R4 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],{TARSKIK1 x3} :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK1 [TARSKIK4 x1,x2 ] },{TARSKIK1 x3} :]"
      using zfmisc_1_th_29 sorry
    also have "... = {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }"
      using zfmisc_1_th_29 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_36:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK1 x3} :] =XBOOLE-0R4 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK2 x1,y1 },{TARSKIK1 x2} :],{TARSKIK1 x3} :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 y1,x2 ] },{TARSKIK1 x3} :]"
      using zfmisc_1_th_30 sorry
    also have "... = {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ] }"
      using zfmisc_1_th_30 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_37:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =XBOOLE-0R4 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK2 x2,y2 } :],{TARSKIK1 x3} :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] },{TARSKIK1 x3} :]"
      using zfmisc_1_th_30 sorry
    also have "... = {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ] }"
      using zfmisc_1_th_30 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_38:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =XBOOLE-0R4 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK1 [TARSKIK4 x1,x2 ] },{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_th_29 sorry
    also have "... = {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ] }"
      using zfmisc_1_th_30 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_39:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =XBOOLE-0R4 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 y1,y2,x3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 y1,y2,x3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 } :],{TARSKIK1 x3} :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {ENUMSET1K2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ],[TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK1 x3} :]"
      using mcart_1_th_23 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK1 x3} :]"
      using enumset1_th_5 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] },{TARSKIK1 x3} :] \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK1 x3} :]"
      using zfmisc_1_th_97 sorry
    also have "... = {TARSKIK2 [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],x3 ] } \\/XBOOLE-0K2 [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK1 x3} :]"
      using zfmisc_1_th_30 sorry
    also have "... = {TARSKIK2 [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],x3 ] } \\/XBOOLE-0K2 {TARSKIK2 [TARSKIK4 [TARSKIK4 y1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 y1,y2 ],x3 ] }"
      using zfmisc_1_th_30 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[TARSKIK4 [TARSKIK4 y1,y2 ],x3 ] }"
      using enumset1_th_5 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 y1,y2,x3 ] }"
      using enumset1_th_62 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK1 x3} :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 y1,y2,x3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_40:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =XBOOLE-0R4 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 y1,x2,y3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 y1,x2,y3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK2 x1,y1 },{TARSKIK1 x2} :],{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 y1,x2 ] },{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_th_30 sorry
    also have "... = {ENUMSET1K2 [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,x2 ],y3 ],[TARSKIK4 [TARSKIK4 y1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 y1,x2 ],y3 ] }"
      using mcart_1_th_23 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 y1,x2,y3 ] }"
      using enumset1_th_62 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK1 x2},{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 y1,x2,y3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_41:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =XBOOLE-0R4 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    have "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK2 x2,y2 } :],{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] },{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_th_30 sorry
    also have "... = {ENUMSET1K2 [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,x2 ],y3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],y3 ] }"
      using mcart_1_th_23 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
      using enumset1_th_62 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK1 x1},{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_42:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =XBOOLE-0R4 {ENUMSET1K6 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds [:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K6 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    have A1: "[:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 [TARSKIK4 x1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,x2 ],y3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],x3 ],[TARSKIK4 [TARSKIK4 x1,y2 ],y3 ] }"
      using mcart_1_th_23 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
      using enumset1_th_62 sorry
    finally have "[:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] }"
       sorry
    have A2: "[:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [TARSKIK4 [TARSKIK4 y1,x2 ],x3 ],[TARSKIK4 [TARSKIK4 y1,x2 ],y3 ],[TARSKIK4 [TARSKIK4 y1,y2 ],x3 ],[TARSKIK4 [TARSKIK4 y1,y2 ],y3 ] }"
      using mcart_1_th_23 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
      using enumset1_th_62 sorry
    finally have "[:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K2 [XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
       sorry
    have "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 } :],{TARSKIK2 x3,y3 } :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K2 {ENUMSET1K2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ],[TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK2 x3,y3 } :]"
      using mcart_1_th_23 sorry
    also have "... = [:ZFMISC-1K2 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 x1,y2 ] } \\/XBOOLE-0K2 {TARSKIK2 [TARSKIK4 y1,x2 ],[TARSKIK4 y1,y2 ] },{TARSKIK2 x3,y3 } :]"
      using enumset1_th_5 sorry
    also have "... = {ENUMSET1K2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ] } \\/XBOOLE-0K2 {ENUMSET1K2 [XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
      using A1 A2 zfmisc_1_th_97 sorry
    also have "... = {ENUMSET1K6 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
      using enumset1_th_25 sorry
    finally show "[:ZFMISC-1K3 {TARSKIK2 x1,y1 },{TARSKIK2 x2,y2 },{TARSKIK2 x3,y3 } :] =HIDDENR1 {ENUMSET1K6 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 x1,y2,x3 ],[XTUPLE-0K3 x1,x2,y3 ],[XTUPLE-0K3 x1,y2,y3 ],[XTUPLE-0K3 y1,x2,x3 ],[XTUPLE-0K3 y1,y2,x3 ],[XTUPLE-0K3 y1,x2,y3 ],[XTUPLE-0K3 y1,y2,y3 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_cl_2:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that tripleXTUPLE-0V2 for ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds it be tripleXTUPLE-0V2"
  proof-
    have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds x be tripleXTUPLE-0V2"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
      have " ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st  ex xx3 be ElementSUBSET-1M1-of X3 st x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
        using mcart_1_lm_2 sorry
      thus "x be tripleXTUPLE-0V2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CD 4*)
syntax MCART_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `1-3MCART-1K1\<^bsub>'( _ , _ , _ ')\<^esub>" [164,0,0,0]164)
translations "x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>" \<rightharpoonup> "x `1-3XTUPLE-0K4"

mtheorem mcart_1_def_5:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"redefine func x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X1 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x1"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X1 holds it =HIDDENR1 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x1)"
  proof-
    have " for y be ElementSUBSET-1M1-of X1 holds (y =HIDDENR1 x `1-3XTUPLE-0K4 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x1)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x1) implies y =HIDDENR1 x `1-3XTUPLE-0K4)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X1"
      show "y =HIDDENR1 x `1-3XTUPLE-0K4 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x1)"
         sorry
      assume A2: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x1"
      obtain xx1 xx2 xx3 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
        A3: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
        using mcart_1_lm_2 sorry
      show "y =HIDDENR1 x `1-3XTUPLE-0K4"
        using A2 A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_1:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"cluster x `1-3XTUPLE-0K4 as-term-is ElementSUBSET-1M1-of X1"
proof
(*coherence*)
  show "x `1-3XTUPLE-0K4 be ElementSUBSET-1M1-of X1"
  proof-
    obtain xx1 xx2 xx3 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
      A1: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
      using mcart_1_lm_2 sorry
    show "x `1-3XTUPLE-0K4 be ElementSUBSET-1M1-of X1"
      using A1 sorry
  qed
qed "sorry"

syntax MCART_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `2-3MCART-1K2\<^bsub>'( _ , _ , _ ')\<^esub>" [164,0,0,0]164)
translations "x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>" \<rightharpoonup> "x `2-3XTUPLE-0K5"

mtheorem mcart_1_def_6:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"redefine func x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X2 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x2"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X2 holds it =HIDDENR1 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x2)"
  proof-
    have " for y be ElementSUBSET-1M1-of X2 holds (y =HIDDENR1 x `2-3XTUPLE-0K5 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x2)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x2) implies y =HIDDENR1 x `2-3XTUPLE-0K5)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X2"
      show "y =HIDDENR1 x `2-3XTUPLE-0K5 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x2)"
         sorry
      assume A5: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x2"
      obtain xx1 xx2 xx3 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
        A6: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
        using mcart_1_lm_2 sorry
      show "y =HIDDENR1 x `2-3XTUPLE-0K5"
        using A5 A6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_2:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"cluster x `2-3XTUPLE-0K5 as-term-is ElementSUBSET-1M1-of X2"
proof
(*coherence*)
  show "x `2-3XTUPLE-0K5 be ElementSUBSET-1M1-of X2"
  proof-
    obtain xx1 xx2 xx3 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
      A4: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
      using mcart_1_lm_2 sorry
    show "x `2-3XTUPLE-0K5 be ElementSUBSET-1M1-of X2"
      using A4 sorry
  qed
qed "sorry"

syntax MCART_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `3-3MCART-1K3\<^bsub>'( _ , _ , _ ')\<^esub>" [164,0,0,0]164)
translations "x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>" \<rightharpoonup> "x `2XTUPLE-0K2"

mtheorem mcart_1_def_7:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"redefine func x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X3 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x3"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X3 holds it =HIDDENR1 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies it =HIDDENR1 x3)"
  proof-
    have " for y be ElementSUBSET-1M1-of X3 holds (y =HIDDENR1 x `3-3XTUPLE-0K6 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x3)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x3) implies y =HIDDENR1 x `3-3XTUPLE-0K6)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X3"
      show "y =HIDDENR1 x `3-3XTUPLE-0K6 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x3)"
         sorry
      assume A8: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies y =HIDDENR1 x3"
      obtain xx1 xx2 xx3 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
        A9: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
        using mcart_1_lm_2 sorry
      show "y =HIDDENR1 x `3-3XTUPLE-0K6"
        using A8 A9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_3:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
"cluster x `2XTUPLE-0K2 as-term-is ElementSUBSET-1M1-of X3"
proof
(*coherence*)
  show "x `2XTUPLE-0K2 be ElementSUBSET-1M1-of X3"
  proof-
    have "x `3-3XTUPLE-0K6 be ElementSUBSET-1M1-of X3"
    proof-
      obtain xx1 xx2 xx3 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
        A7: "x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
        using mcart_1_lm_2 sorry
      show "x `3-3XTUPLE-0K6 be ElementSUBSET-1M1-of X3"
        using A7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 2*)
mtheorem mcart_1_th_45:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :] or X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :]) or X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :] implies X =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ((X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :] or X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :]) or X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :]) & X <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "(X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :] or X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :]) or X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :]"
      and A2: "X <>HIDDENR2 {}XBOOLE-0K1"
    have "([:ZFMISC-1K3 X,Y,Z :] <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K3 Y,Z,X :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K3 Z,X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A2 sorry
    then have 
      [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      using mcart_1_th_31 sorry
    show " False "
    proof-
      have cases: "(X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :] or X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :]) or X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :]"
        using A1 sorry
      have case1: "X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :] implies  False "
      proof(rule impI)
        assume A3: "X c=TARSKIR1 [:ZFMISC-1K3 X,Y,Z :]"
        obtain v where
          [ty]:"v be objectHIDDENM1" and 
          A4: "v inHIDDENR3 X"and A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 X or y inHIDDENR3 X implies v <>HIDDENR2 [XTUPLE-0K3 x,y,z ]"
          using mcart_1_th_26 sorry
        have 
          [ty]:"v be ElementSUBSET-1M1-of [:ZFMISC-1K3 X,Y,Z :]"
          using A3 A4 sorry
        have "v =HIDDENR1 [XTUPLE-0K3 v `1-3MCART-1K1\<^bsub>(X,Y,Z)\<^esub>,v `2-3MCART-1K2\<^bsub>(X,Y,Z)\<^esub>,v `3-3MCART-1K3\<^bsub>(X,Y,Z)\<^esub> ]"
           sorry
        thus " False "
          using A5 sorry
      qed
      have case2: "X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :] implies  not  True "
      proof(rule impI)
        assume "X c=TARSKIR1 [:ZFMISC-1K3 Y,Z,X :]"
        then have "X c=TARSKIR1 [:ZFMISC-1K2 [:ZFMISC-1K2 Y,Z :],X :]"
          using zfmisc_1_def_3 sorry
        thus " not  True "
          using zfmisc_1_th_111 sorry
      qed
      have case3: "X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :] implies  not  True "
      proof(rule impI)
        assume A6: "X c=TARSKIR1 [:ZFMISC-1K3 Z,X,Y :]"
        obtain v where
          [ty]:"v be objectHIDDENM1" and 
          A7: "v inHIDDENR3 X"and A8: " for z be objectHIDDENM1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds z inHIDDENR3 X or x inHIDDENR3 X implies v <>HIDDENR2 [XTUPLE-0K3 z,x,y ]"
          using mcart_1_th_26 sorry
        have 
          [ty]:"v be ElementSUBSET-1M1-of [:ZFMISC-1K3 Z,X,Y :]"
          using A6 A7 sorry
        have "v =HIDDENR1 [XTUPLE-0K3 v `1-3MCART-1K1\<^bsub>(Z,X,Y)\<^esub>,v `2-3MCART-1K2\<^bsub>(Z,X,Y)\<^esub>,v `3-3MCART-1K3\<^bsub>(Z,X,Y)\<^esub> ]"
           sorry
        thus " not  True "
          using A8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem mcart_1_th_47:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds (x <>HIDDENR2 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x <>HIDDENR2 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>) & x <>HIDDENR2 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds (x <>HIDDENR2 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x <>HIDDENR2 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>) &  not x <>HIDDENR2 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    let ?Y9 = "{TARSKIK2 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> }"
    let ?Y = "{TARSKIK2 ?Y9,{TARSKIK1 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> } }"
    let ?X9 = "{TARSKIK2 ?Y,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> }"
    let ?X = "{TARSKIK2 ?X9,{TARSKIK1 ?Y} }"
    have A1: "x =HIDDENR1 [XTUPLE-0K3 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    also have "... = [TARSKIK4 [TARSKIK4 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> ],x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    finally have "x =HIDDENR1 [TARSKIK4 [TARSKIK4 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> ],x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    then have "x =XBOOLE-0R4 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> or x =XBOOLE-0R4 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> implies ((?X inTARSKIR2 ?Y9 & ?Y9 inTARSKIR2 ?Y) & ?Y inTARSKIR2 ?X9) & ?X9 inTARSKIR2 ?X"
      using tarski_def_2 sorry
    thus "x <>HIDDENR2 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> & x <>HIDDENR2 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>"
      using xregular_th_8 sorry
    show " not x <>HIDDENR2 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
      using A1 mcart_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_48:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] meetsXBOOLE-0R5 [:ZFMISC-1K3 Y1,Y2,Y3 :] implies (X1 meetsXBOOLE-0R5 Y1 & X2 meetsXBOOLE-0R5 Y2) & X3 meetsXBOOLE-0R5 Y3"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds [:ZFMISC-1K3 X1,X2,X3 :] meetsXBOOLE-0R5 [:ZFMISC-1K3 Y1,Y2,Y3 :] implies ( not X1 meetsXBOOLE-0R5 Y1 &  not X2 meetsXBOOLE-0R5 Y2) &  not X3 meetsXBOOLE-0R5 Y3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    assume A1: "[:ZFMISC-1K3 X1,X2,X3 :] meetsXBOOLE-0R5 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
    have A2: "[:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :] & [:ZFMISC-1K2 [:ZFMISC-1K2 Y1,Y2 :],Y3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
      using zfmisc_1_def_3 sorry
    then have "[:ZFMISC-1K2 X1,X2 :] meetsXBOOLE-0R5 [:ZFMISC-1K2 Y1,Y2 :]"
      using A1 zfmisc_1_th_104 sorry
    thus "( not X1 meetsXBOOLE-0R5 Y1 &  not X2 meetsXBOOLE-0R5 Y2) &  not X3 meetsXBOOLE-0R5 Y3"
      using A2 A1 zfmisc_1_th_104 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_49:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    have "[:ZFMISC-1K4 X1,X2,X3,X4 :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      using zfmisc_1_def_4 sorry
    also have "... = [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :]"
      using zfmisc_1_def_3 sorry
    finally show "[:ZFMISC-1K4 X1,X2,X3,X4 :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_50:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds [:ZFMISC-1K3 [:ZFMISC-1K2 X1,X2 :],X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds [:ZFMISC-1K3 [:ZFMISC-1K2 X1,X2 :],X3,X4 :] =HIDDENR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    have "[:ZFMISC-1K3 [:ZFMISC-1K2 X1,X2 :],X3,X4 :] =HIDDENR1 [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :]"
      using zfmisc_1_def_3 sorry
    also have "... = [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using mcart_1_th_49 sorry
    finally show "[:ZFMISC-1K3 [:ZFMISC-1K2 X1,X2 :],X3,X4 :] =HIDDENR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_51:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds ((X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1) & X4 <>HIDDENR2 {}XBOOLE-0K1 iff [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  not (((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) &  not X4 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1) &  not ( not [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1 &  not ((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) &  not X4 <>HIDDENR2 {}XBOOLE-0K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    have A1: "[:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using zfmisc_1_def_4 sorry
    have "(X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 iff [:ZFMISC-1K3 X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1"
      using mcart_1_th_31 sorry
    thus " not (((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) &  not X4 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1) &  not ( not [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1 &  not ((( not X1 <>HIDDENR2 {}XBOOLE-0K1 &  not X2 <>HIDDENR2 {}XBOOLE-0K1) &  not X3 <>HIDDENR2 {}XBOOLE-0K1) &  not X4 <>HIDDENR2 {}XBOOLE-0K1))"
      using A1 zfmisc_1_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_52:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds (((X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1) & X4 <>HIDDENR2 {}XBOOLE-0K1) & [:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] implies ((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds (X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1 implies (X4 <>HIDDENR2 {}XBOOLE-0K1 implies ([:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] implies ((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    fix Y4 assume [ty]: "Y4 be setHIDDENM2"
    have A1: "[:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      using zfmisc_1_def_4 sorry
    assume A2: "(X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1"
    assume A3: "X4 <>HIDDENR2 {}XBOOLE-0K1"
    assume "[:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :]"
    then have A4: "[:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] =RELAT-1R1 [:ZFMISC-1K2 [:ZFMISC-1K3 Y1,Y2,Y3 :],Y4 :]"
      using A1 zfmisc_1_def_4 sorry
    have "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
      using A3 A4 A2 zfmisc_1_th_110 sorry
    thus "((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4"
      using A2 A3 A4 mcart_1_th_32 zfmisc_1_th_110 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_53:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1 & [:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] implies ((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1 implies  not ([:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] &  not (((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    fix Y4 assume [ty]: "Y4 be setHIDDENM2"
    assume A1: "[:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1"
    then have A2: "X3 <>HIDDENR2 {}XBOOLE-0K1 & X4 <>HIDDENR2 {}XBOOLE-0K1"
      using mcart_1_th_51 sorry
    have "X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1"
      using A1 mcart_1_th_51 sorry
    thus " not ([:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] &  not (((X1 =XBOOLE-0R4 Y1 & X2 =XBOOLE-0R4 Y2) & X3 =XBOOLE-0R4 Y3) & X4 =XBOOLE-0R4 Y4))"
      using A2 mcart_1_th_52 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_54:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K4 X,X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K4 Y,Y,Y,Y :] implies X =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K4 X,X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K4 Y,Y,Y,Y :] implies X =XBOOLE-0R4 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "[:ZFMISC-1K4 X,X,X,X :] =XBOOLE-0R4 [:ZFMISC-1K4 Y,Y,Y,Y :]"
    then have "X <>HIDDENR2 {}XBOOLE-0K1 or Y <>HIDDENR2 {}XBOOLE-0K1 implies X =XBOOLE-0R4 Y"
      using mcart_1_th_52 sorry
    thus "X =XBOOLE-0R4 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve xx4 for "ElementSUBSET-1M1-of X4"
mlemma mcart_1_lm_3:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds ((X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1) & X4 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st  ex xx3 be ElementSUBSET-1M1-of X3 st  ex xx4 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ])"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds ((X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1) & X4 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  ex tVar9 be ElementSUBSET-1M1-of X1 st  ex tVar10 be ElementSUBSET-1M1-of X2 st  ex tVar11 be ElementSUBSET-1M1-of X3 st  ex tVar12 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 tVar9,tVar10,tVar11,tVar12 ])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    assume A1: "(X1 <>HIDDENR2 {}XBOOLE-0K1 & X2 <>HIDDENR2 {}XBOOLE-0K1) & X3 <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X4 <>HIDDENR2 {}XBOOLE-0K1"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    obtain x9 where 
      [ty]:"x9 be ElementSUBSET-1M1-of [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]" and x9Def:"x9 = x"
      using zfmisc_1_def_4 sorry
    obtain x123 xx4 where
      [ty]:"x123 be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]" "xx4 be ElementSUBSET-1M1-of X4" and 
      A3: "x9 =HIDDENR1 [TARSKIK4 x123,xx4 ]"
      using A2 mcart_1_lm_1 A1 sorry
    obtain xx1 xx2 xx3 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" and 
      A4: "x123 =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ]"
      using A1 mcart_1_lm_2 sorry
    show " ex tVar9 be ElementSUBSET-1M1-of X1 st  ex tVar10 be ElementSUBSET-1M1-of X2 st  ex tVar11 be ElementSUBSET-1M1-of X3 st  ex tVar12 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 tVar9,tVar10,tVar11,tVar12 ]"
    proof(rule bexI[of _ "xx1"])
      show " ex tVar10 be ElementSUBSET-1M1-of X2 st  ex tVar11 be ElementSUBSET-1M1-of X3 st  ex tVar12 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 xx1,tVar10,tVar11,tVar12 ]"
      proof(rule bexI[of _ "xx2"])
        show " ex tVar11 be ElementSUBSET-1M1-of X3 st  ex tVar12 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,tVar11,tVar12 ]"
        proof(rule bexI[of _ "xx3"])
          show " ex tVar12 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,tVar12 ]"
          proof(rule bexI[of _ "xx4"])
            show "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
              using A3 A4 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_cl_3:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster note-that quadrupleXTUPLE-0V3 for ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds it be quadrupleXTUPLE-0V3"
  proof-
    have " for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds x be quadrupleXTUPLE-0V3"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      have " ex xx1 be ElementSUBSET-1M1-of X1 st  ex xx2 be ElementSUBSET-1M1-of X2 st  ex xx3 be ElementSUBSET-1M1-of X3 st  ex xx4 be ElementSUBSET-1M1-of X4 st x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      thus "x be quadrupleXTUPLE-0V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax MCART_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `1-4MCART-1K4\<^bsub>'( _ , _ , _ , _ ')\<^esub>" [164,0,0,0,0]164)
translations "x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>" \<rightharpoonup> "x `1-4XTUPLE-0K8"

mtheorem mcart_1_def_8:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"redefine func x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X1 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x1"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X1 holds it =HIDDENR1 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x1)"
  proof-
    have " for y be ElementSUBSET-1M1-of X1 holds (y =HIDDENR1 x `1-4XTUPLE-0K8 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x1)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x1) implies y =HIDDENR1 x `1-4XTUPLE-0K8)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X1"
      show "y =HIDDENR1 x `1-4XTUPLE-0K8 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x1)"
         sorry
      assume A2: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x1"
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A3: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "y =HIDDENR1 x `1-4XTUPLE-0K8"
        using A2 A3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_4:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"cluster x `1-4XTUPLE-0K8 as-term-is ElementSUBSET-1M1-of X1"
proof
(*coherence*)
  show "x `1-4XTUPLE-0K8 be ElementSUBSET-1M1-of X1"
  proof-
    obtain xx1 xx2 xx3 xx4 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
      using mcart_1_lm_3 sorry
    show "x `1-4XTUPLE-0K8 be ElementSUBSET-1M1-of X1"
      using A1 sorry
  qed
qed "sorry"

syntax MCART_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `2-4MCART-1K5\<^bsub>'( _ , _ , _ , _ ')\<^esub>" [164,0,0,0,0]164)
translations "x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>" \<rightharpoonup> "x `2-4XTUPLE-0K9"

mtheorem mcart_1_def_9:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"redefine func x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X2 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x2"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X2 holds it =HIDDENR1 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x2)"
  proof-
    have " for y be ElementSUBSET-1M1-of X2 holds (y =HIDDENR1 x `2-4XTUPLE-0K9 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x2)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x2) implies y =HIDDENR1 x `2-4XTUPLE-0K9)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X2"
      show "y =HIDDENR1 x `2-4XTUPLE-0K9 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x2)"
         sorry
      assume A5: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x2"
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A6: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "y =HIDDENR1 x `2-4XTUPLE-0K9"
        using A5 A6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_5:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"cluster x `2-4XTUPLE-0K9 as-term-is ElementSUBSET-1M1-of X2"
proof
(*coherence*)
  show "x `2-4XTUPLE-0K9 be ElementSUBSET-1M1-of X2"
  proof-
    obtain xx1 xx2 xx3 xx4 where
      [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
      A4: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
      using mcart_1_lm_3 sorry
    show "x `2-4XTUPLE-0K9 be ElementSUBSET-1M1-of X2"
      using A4 sorry
  qed
qed "sorry"

syntax MCART_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `3-4MCART-1K6\<^bsub>'( _ , _ , _ , _ ')\<^esub>" [164,0,0,0,0]164)
translations "x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>" \<rightharpoonup> "x `2-3XTUPLE-0K5"

mtheorem mcart_1_def_10:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"redefine func x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X3 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x3"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X3 holds it =HIDDENR1 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x3)"
  proof-
    have " for y be ElementSUBSET-1M1-of X3 holds (y =HIDDENR1 x `3-4XTUPLE-0K10 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x3)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x3) implies y =HIDDENR1 x `3-4XTUPLE-0K10)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X3"
      show "y =HIDDENR1 x `3-4XTUPLE-0K10 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x3)"
         sorry
      assume A8: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x3"
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A9: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "y =HIDDENR1 x `3-4XTUPLE-0K10"
        using A8 A9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_6:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"cluster x `2-3XTUPLE-0K5 as-term-is ElementSUBSET-1M1-of X3"
proof
(*coherence*)
  show "x `2-3XTUPLE-0K5 be ElementSUBSET-1M1-of X3"
  proof-
    have "x `3-4XTUPLE-0K10 be ElementSUBSET-1M1-of X3"
    proof-
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A7: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "x `3-4XTUPLE-0K10 be ElementSUBSET-1M1-of X3"
        using A7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax MCART_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ `4-4MCART-1K7\<^bsub>'( _ , _ , _ , _ ')\<^esub>" [164,0,0,0,0]164)
translations "x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>" \<rightharpoonup> "x `2XTUPLE-0K2"

mtheorem mcart_1_def_11:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"redefine func x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> \<rightarrow> ElementSUBSET-1M1-of X4 means
  \<lambda>it.  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x4"
proof
(*compatibility*)
  show " for it be ElementSUBSET-1M1-of X4 holds it =HIDDENR1 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies it =HIDDENR1 x4)"
  proof-
    have " for y be ElementSUBSET-1M1-of X4 holds (y =HIDDENR1 x `4-4XTUPLE-0K11 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x4)) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x4) implies y =HIDDENR1 x `4-4XTUPLE-0K11)"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of X4"
      show "y =HIDDENR1 x `4-4XTUPLE-0K11 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x4)"
         sorry
      assume A11: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies y =HIDDENR1 x4"
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A12: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "y =HIDDENR1 x `4-4XTUPLE-0K11"
        using A11 A12 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem mcart_1_add_7:
  mlet "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
"cluster x `2XTUPLE-0K2 as-term-is ElementSUBSET-1M1-of X4"
proof
(*coherence*)
  show "x `2XTUPLE-0K2 be ElementSUBSET-1M1-of X4"
  proof-
    have "x `4-4XTUPLE-0K11 be ElementSUBSET-1M1-of X4"
    proof-
      obtain xx1 xx2 xx3 xx4 where
        [ty]:"xx1 be ElementSUBSET-1M1-of X1" "xx2 be ElementSUBSET-1M1-of X2" "xx3 be ElementSUBSET-1M1-of X3" "xx4 be ElementSUBSET-1M1-of X4" and 
        A10: "x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ]"
        using mcart_1_lm_3 sorry
      show "x `4-4XTUPLE-0K11 be ElementSUBSET-1M1-of X4"
        using A10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT 3*)
mtheorem mcart_1_th_58:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ((x <>HIDDENR2 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x <>HIDDENR2 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>) & x <>HIDDENR2 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>) & x <>HIDDENR2 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>"
proof-
  have " for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds (x <>HIDDENR2 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x <>HIDDENR2 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>) & ( not x <>HIDDENR2 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> &  not x <>HIDDENR2 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    obtain Y where 
      [ty]:"Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and YDef:"Y = [:ZFMISC-1K2 X1,X2 :]" and
      [ty]:"X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
       sorry
    obtain x9 where 
      [ty]:"x9 be ElementSUBSET-1M1-of [:ZFMISC-1K3 Y,X3,X4 :]" and x9Def:"x9 = x"
      using mcart_1_th_50 sorry
    let ?Z9 = "{TARSKIK2 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> }"
    let ?Z = "{TARSKIK2 ?Z9,{TARSKIK1 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> } }"
    let ?Y9 = "{TARSKIK2 ?Z,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> }"
    let ?Y = "{TARSKIK2 ?Y9,{TARSKIK1 ?Z} }"
    let ?X9 = "{TARSKIK2 ?Y,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> }"
    let ?X = "{TARSKIK2 ?X9,{TARSKIK1 ?Y} }"
    have "x =HIDDENR1 [XTUPLE-0K7 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
       sorry
    also have "... = ?X"
       sorry
    finally have "x =HIDDENR1 ?X"
       sorry
    then have "x =XBOOLE-0R4 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> or x =XBOOLE-0R4 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> implies ((((?X inTARSKIR2 ?Z9 & ?Z9 inTARSKIR2 ?Z) & ?Z inTARSKIR2 ?Y9) & ?Y9 inTARSKIR2 ?Y) & ?Y inTARSKIR2 ?X9) & ?X9 inTARSKIR2 ?X"
      using tarski_def_2 sorry
    thus "x <>HIDDENR2 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> & x <>HIDDENR2 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using xregular_th_10 sorry
    have "x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =HIDDENR1 (x `1XTUPLE-0K1)`2XTUPLE-0K2"
       sorry
    also have "... = x9 `2-3MCART-1K2\<^bsub>(Y,X3,X4)\<^esub>"
       sorry
    finally have "x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =HIDDENR1 x9 `2-3MCART-1K2\<^bsub>(Y,X3,X4)\<^esub>"
       sorry
    thus " not x <>HIDDENR2 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> &  not x <>HIDDENR2 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using mcart_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_59:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds ((X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :] or X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :] implies X1 =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds (((X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :] or X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :]) & X1 <>HIDDENR2 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    assume A1: "((X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :] or X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :]"
      and A2: "X1 <>HIDDENR2 {}XBOOLE-0K1"
    have A3: "(([:ZFMISC-1K4 X1,X2,X3,X4 :] <>HIDDENR2 {}XBOOLE-0K1 or [:ZFMISC-1K4 X2,X3,X4,X1 :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K4 X3,X4,X1,X2 :] <>HIDDENR2 {}XBOOLE-0K1) or [:ZFMISC-1K4 X4,X1,X2,X3 :] <>HIDDENR2 {}XBOOLE-0K1"
      using A1 A2 sorry
    have 
      [ty]:"X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
      [ty]:"X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      using A3 mcart_1_th_51 sorry
    show " False "
    proof-
      have cases: "((X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :] or X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :]) or X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :]"
        using A1 sorry
      have case1: "X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies  False "
      proof(rule impI)
        assume A4: "X1 c=TARSKIR1 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
        obtain v where
          [ty]:"v be objectHIDDENM1" and 
          A5: "v inHIDDENR3 X1"and A6: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x1 inHIDDENR3 X1 or x2 inHIDDENR3 X1 implies v <>HIDDENR2 [XTUPLE-0K7 x1,x2,x3,x4 ]"
          using mcart_1_th_30 sorry
        have 
          [ty]:"v be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
          using A4 A5 sorry
        have "v =HIDDENR1 [XTUPLE-0K7 v `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,v `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,v `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,v `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
           sorry
        thus " False "
          using A6 sorry
      qed
      have case2: "X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :] implies  not  True "
      proof(rule impI)
        assume "X1 c=TARSKIR1 [:ZFMISC-1K4 X2,X3,X4,X1 :]"
        then have "X1 c=TARSKIR1 [:ZFMISC-1K3 [:ZFMISC-1K2 X2,X3 :],X4,X1 :]"
          using mcart_1_th_50 sorry
        thus " not  True "
          using mcart_1_th_45 sorry
      qed
      have case3: "X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :] implies  not  True "
      proof(rule impI)
        assume "X1 c=TARSKIR1 [:ZFMISC-1K4 X3,X4,X1,X2 :]"
        then have "X1 c=TARSKIR1 [:ZFMISC-1K3 [:ZFMISC-1K2 X3,X4 :],X1,X2 :]"
          using mcart_1_th_50 sorry
        thus " not  True "
          using mcart_1_th_45 sorry
      qed
      have case4: "X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :] implies  not  True "
      proof(rule impI)
        assume A7: "X1 c=TARSKIR1 [:ZFMISC-1K4 X4,X1,X2,X3 :]"
        obtain v where
          [ty]:"v be objectHIDDENM1" and 
          A8: "v inHIDDENR3 X1"and A9: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds x1 inHIDDENR3 X1 or x2 inHIDDENR3 X1 implies v <>HIDDENR2 [XTUPLE-0K7 x1,x2,x3,x4 ]"
          using mcart_1_th_30 sorry
        have 
          [ty]:"v be ElementSUBSET-1M1-of [:ZFMISC-1K4 X4,X1,X2,X3 :]"
          using A7 A8 sorry
        have "v =HIDDENR1 [XTUPLE-0K7 v `1-4MCART-1K4\<^bsub>(X4,X1,X2,X3)\<^esub>,v `2-4MCART-1K5\<^bsub>(X4,X1,X2,X3)\<^esub>,v `3-4MCART-1K6\<^bsub>(X4,X1,X2,X3)\<^esub>,v `4-4MCART-1K7\<^bsub>(X4,X1,X2,X3)\<^esub> ]"
           sorry
        thus " not  True "
          using A9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_60:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] meetsXBOOLE-0R5 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] implies ((X1 meetsXBOOLE-0R5 Y1 & X2 meetsXBOOLE-0R5 Y2) & X3 meetsXBOOLE-0R5 Y3) & X4 meetsXBOOLE-0R5 Y4"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds [:ZFMISC-1K4 X1,X2,X3,X4 :] meetsXBOOLE-0R5 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] implies (( not X1 meetsXBOOLE-0R5 Y1 &  not X2 meetsXBOOLE-0R5 Y2) &  not X3 meetsXBOOLE-0R5 Y3) &  not X4 meetsXBOOLE-0R5 Y4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    fix Y4 assume [ty]: "Y4 be setHIDDENM2"
    assume A1: "[:ZFMISC-1K4 X1,X2,X3,X4 :] meetsXBOOLE-0R5 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :]"
    have A2: "[:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :],X4 :] =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :] & [:ZFMISC-1K2 [:ZFMISC-1K2 [:ZFMISC-1K2 Y1,Y2 :],Y3 :],Y4 :] =XBOOLE-0R4 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :]"
      using mcart_1_th_49 sorry
    then have A3: "[:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] meetsXBOOLE-0R5 [:ZFMISC-1K2 [:ZFMISC-1K2 Y1,Y2 :],Y3 :]"
      using A1 zfmisc_1_th_104 sorry
    then have "[:ZFMISC-1K2 X1,X2 :] meetsXBOOLE-0R5 [:ZFMISC-1K2 Y1,Y2 :]"
      using zfmisc_1_th_104 sorry
    thus "(( not X1 meetsXBOOLE-0R5 Y1 &  not X2 meetsXBOOLE-0R5 Y2) &  not X3 meetsXBOOLE-0R5 Y3) &  not X4 meetsXBOOLE-0R5 Y4"
      using A2 A1 A3 zfmisc_1_th_104 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_61:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds [:ZFMISC-1K4 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3},{TARSKIK1 x4} :] =XBOOLE-0R4 {TARSKIK1 [XTUPLE-0K7 x1,x2,x3,x4 ] }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds [:ZFMISC-1K4 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3},{TARSKIK1 x4} :] =HIDDENR1 {TARSKIK1 [XTUPLE-0K7 x1,x2,x3,x4 ] }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "[:ZFMISC-1K4 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3},{TARSKIK1 x4} :] =HIDDENR1 [:ZFMISC-1K3 [:ZFMISC-1K2 {TARSKIK1 x1},{TARSKIK1 x2} :],{TARSKIK1 x3},{TARSKIK1 x4} :]"
      using mcart_1_th_50 sorry
    also have "... = [:ZFMISC-1K3 {TARSKIK1 [TARSKIK4 x1,x2 ] },{TARSKIK1 x3},{TARSKIK1 x4} :]"
      using zfmisc_1_th_29 sorry
    also have "... = {TARSKIK1 [XTUPLE-0K3 [TARSKIK4 x1,x2 ],x3,x4 ] }"
      using mcart_1_th_35 sorry
    also have "... = {TARSKIK1 [XTUPLE-0K7 x1,x2,x3,x4 ] }"
       sorry
    finally show "[:ZFMISC-1K4 {TARSKIK1 x1},{TARSKIK1 x2},{TARSKIK1 x3},{TARSKIK1 x4} :] =HIDDENR1 {TARSKIK1 [XTUPLE-0K7 x1,x2,x3,x4 ] }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_62:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds x <>HIDDENR2 x `1XTUPLE-0K1 & x <>HIDDENR2 x `2XTUPLE-0K2)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds [:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds  not x <>HIDDENR2 x `1XTUPLE-0K1 &  not x <>HIDDENR2 x `2XTUPLE-0K2)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "[:ZFMISC-1K2 X,Y :] <>HIDDENR2 {}XBOOLE-0K1"
    then have "X <>HIDDENR2 {}XBOOLE-0K1 & Y <>HIDDENR2 {}XBOOLE-0K1"
      using zfmisc_1_th_90 sorry
    thus " for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 X,Y :] holds  not x <>HIDDENR2 x `1XTUPLE-0K1 &  not x <>HIDDENR2 x `2XTUPLE-0K2"
      using mcart_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_63:
" for x be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds x inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies x <>HIDDENR2 x `1XTUPLE-0K1 & x <>HIDDENR2 x `2XTUPLE-0K2"
  using mcart_1_th_62 sorry

reserve A1 for "SubsetSUBSET-1M2-of X1"
reserve A2 for "SubsetSUBSET-1M2-of X2"
reserve A3 for "SubsetSUBSET-1M2-of X3"
reserve A4 for "SubsetSUBSET-1M2-of X4"
mtheorem mcart_1_th_64:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds  for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ] implies (x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> =HIDDENR1 x1 & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> =HIDDENR1 x2) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> =HIDDENR1 x3"
   sorry

mtheorem mcart_1_th_65:
" for y1 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y1 =HIDDENR1 xx1) implies y1 =HIDDENR1 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>"
proof-
  have " for y1 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y1 =HIDDENR1 xx1) implies y1 =HIDDENR1 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y1 =HIDDENR1 xx1"
    have "x =HIDDENR1 [XTUPLE-0K3 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    thus "y1 =HIDDENR1 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_66:
" for y2 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y2 =HIDDENR1 xx2) implies y2 =HIDDENR1 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>"
proof-
  have " for y2 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y2 =HIDDENR1 xx2) implies y2 =HIDDENR1 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y2 =HIDDENR1 xx2"
    have "x =HIDDENR1 [XTUPLE-0K3 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    thus "y2 =HIDDENR1 x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_67:
" for y3 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y3 =HIDDENR1 xx3) implies y3 =HIDDENR1 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
proof-
  have " for y3 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y3 =HIDDENR1 xx3) implies y3 =HIDDENR1 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds x =HIDDENR1 [XTUPLE-0K3 xx1,xx2,xx3 ] implies y3 =HIDDENR1 xx3"
    have "x =HIDDENR1 [XTUPLE-0K3 x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub>,x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub>,x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> ]"
       sorry
    thus "y3 =HIDDENR1 x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_68:
" for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :] implies ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
proof-
  have " for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :] implies  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    assume "z inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"
    then have "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      using zfmisc_1_def_3 sorry
    then obtain x12 x3 where
      [ty]:"x12 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A1: "x12 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"and A2: "x3 inHIDDENR3 X3"and A3: "z =HIDDENR1 [TARSKIK4 x12,x3 ]"
      using zfmisc_1_def_2 sorry
    obtain x1 x2 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
      A4: "x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2"and A5: "x12 =HIDDENR1 [TARSKIK4 x1,x2 ]"
      using A1 zfmisc_1_def_2 sorry
    have "z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using A3 A5 sorry
    thus " not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]))"
      using A2 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_69:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds [XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :] iff (x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  not ([XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :] &  not ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3)) &  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) &  not [XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    have A1: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] iff x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2"
      using zfmisc_1_th_87 sorry
    have "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      using zfmisc_1_def_3 sorry
    thus " not ([XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :] &  not ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3)) &  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) &  not [XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :])"
      using A1 zfmisc_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_70:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])) implies Z =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])) implies Z =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ])"
    have " for z be objectHIDDENM1 holds (z inHIDDENR3 Z implies z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]) & (z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] implies z inHIDDENR3 Z)"
    proof(rule ballI,rule conjMI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show "z inHIDDENR3 Z implies z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      proof(rule impI)
        assume "z inHIDDENR3 Z"
        then obtain x1 x2 x3 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
          A2: "x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2"and A3: "x3 inHIDDENR3 X3 & z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
          using A1 sorry
        have "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"
          using A2 zfmisc_1_def_2 sorry
        thus "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
          using A3 zfmisc_1_def_2 sorry
      qed
      assume "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      then obtain x12 x3 where
        [ty]:"x12 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
        A4: "x12 inHIDDENR3 [:ZFMISC-1K2 X1,X2 :]"and A5: "x3 inHIDDENR3 X3"and A6: "z =HIDDENR1 [TARSKIK4 x12,x3 ]"
        using zfmisc_1_def_2 sorry
      obtain x1 x2 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" and 
        A7: "x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2"and A8: "x12 =HIDDENR1 [TARSKIK4 x1,x2 ]"
        using A4 zfmisc_1_def_2 sorry
      have "z =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
        using A6 A8 sorry
      thus "z inHIDDENR3 Z"
        using A1 A5 A7 sorry
    qed "sorry"
    then have "Z =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :]"
      using tarski_th_2 sorry
    thus "Z =XBOOLE-0R4 [:ZFMISC-1K3 X1,X2,X3 :]"
      using zfmisc_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem mcart_1_th_72:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1 holds  for A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2 holds  for A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :] holds x inTARSKIR2 [:ZFMISC-1K3 A1,A2,A3 :] implies (x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A1 & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A2) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A3"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A1 assume [ty]: "A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1"
  fix A2 assume [ty]: "A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2"
  fix A3 assume [ty]: "A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K3 X1,X2,X3 :]"
  assume "x inTARSKIR2 [:ZFMISC-1K3 A1,A2,A3 :]"
  then obtain y where 
    [ty]:"y be ElementSUBSET-1M1-of [:ZFMISC-1K3 A1,A2,A3 :]" and yDef:"y = x"
     sorry
  have A1: "y `2-3MCART-1K2\<^bsub>(A1,A2,A3)\<^esub> inTARSKIR2 A2"
     sorry
  have A2: "y `3-3MCART-1K3\<^bsub>(A1,A2,A3)\<^esub> inTARSKIR2 A3"
     sorry
  have "y `1-3MCART-1K1\<^bsub>(A1,A2,A3)\<^esub> inTARSKIR2 A1"
     sorry
  thus "(x `1-3MCART-1K1\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A1 & x `2-3MCART-1K2\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A2) & x `3-3MCART-1K3\<^bsub>(X1,X2,X3)\<^esub> inTARSKIR2 A3"
    using A1 A2 sorry
qed "sorry"

mtheorem mcart_1_th_73:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds (X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2) & X3 c=TARSKIR1 Y3 implies [:ZFMISC-1K3 X1,X2,X3 :] c=TARSKIR1 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2 implies (X3 c=TARSKIR1 Y3 implies [:ZFMISC-1K3 X1,X2,X3 :] c=TARSKIR1 [:ZFMISC-1K3 Y1,Y2,Y3 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    have A1: "[:ZFMISC-1K3 X1,X2,X3 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 X1,X2 :],X3 :] & [:ZFMISC-1K3 Y1,Y2,Y3 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K2 Y1,Y2 :],Y3 :]"
      using zfmisc_1_def_3 sorry
    assume "X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2"
    then have A2: "[:ZFMISC-1K2 X1,X2 :] c=RELAT-1R2 [:ZFMISC-1K2 Y1,Y2 :]"
      using zfmisc_1_th_96 sorry
    assume "X3 c=TARSKIR1 Y3"
    thus "[:ZFMISC-1K3 X1,X2,X3 :] c=TARSKIR1 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
      using A2 A1 zfmisc_1_th_96 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_74:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ] implies ((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 x1 & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 x2) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 x3) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> =XBOOLE-0R4 x4"
   sorry

mtheorem mcart_1_th_75:
" for y1 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y1 =HIDDENR1 xx1) implies y1 =HIDDENR1 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>"
proof-
  have " for y1 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y1 =HIDDENR1 xx1) implies y1 =HIDDENR1 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y1 =HIDDENR1 xx1"
    have "x =HIDDENR1 [XTUPLE-0K7 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
       sorry
    thus "y1 =HIDDENR1 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_76:
" for y2 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y2 =HIDDENR1 xx2) implies y2 =HIDDENR1 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>"
proof-
  have " for y2 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y2 =HIDDENR1 xx2) implies y2 =HIDDENR1 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y2 =HIDDENR1 xx2"
    have "x =HIDDENR1 [XTUPLE-0K7 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
       sorry
    thus "y2 =HIDDENR1 x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_77:
" for y3 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y3 =HIDDENR1 xx3) implies y3 =HIDDENR1 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>"
proof-
  have " for y3 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y3 =HIDDENR1 xx3) implies y3 =HIDDENR1 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y3 =HIDDENR1 xx3"
    have "x =HIDDENR1 [XTUPLE-0K7 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
       sorry
    thus "y3 =HIDDENR1 x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_78:
" for y4 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y4 =HIDDENR1 xx4) implies y4 =HIDDENR1 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>"
proof-
  have " for y4 be objectHIDDENM1 holds  for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds ( for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y4 =HIDDENR1 xx4) implies y4 =HIDDENR1 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix y4 assume [ty]: "y4 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    assume A1: " for xx1 be ElementSUBSET-1M1-of X1 holds  for xx2 be ElementSUBSET-1M1-of X2 holds  for xx3 be ElementSUBSET-1M1-of X3 holds  for xx4 be ElementSUBSET-1M1-of X4 holds x =HIDDENR1 [XTUPLE-0K7 xx1,xx2,xx3,xx4 ] implies y4 =HIDDENR1 xx4"
    have "x =HIDDENR1 [XTUPLE-0K7 x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub>,x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub>,x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub>,x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> ]"
       sorry
    thus "y4 =HIDDENR1 x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub>"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_79:
" for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
proof-
  have " for z be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :] implies  not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  not ((((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    assume "z inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    then have "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      using zfmisc_1_def_4 sorry
    then obtain x123 x4 where
      [ty]:"x123 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x123 inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"and A2: "x4 inHIDDENR3 X4"and A3: "z =HIDDENR1 [TARSKIK4 x123,x4 ]"
      using zfmisc_1_def_2 sorry
    obtain x1 x2 x3 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A4: "(x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3"and A5: "x123 =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using A1 mcart_1_th_68 sorry
    have "z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using A3 A5 sorry
    thus " not ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  not ((((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]))"
      using A2 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_80:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds [XTUPLE-0K7 x1,x2,x3,x4 ] inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :] iff ((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  not ([XTUPLE-0K7 x1,x2,x3,x4 ] inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :] &  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4)) &  not ((((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) &  not [XTUPLE-0K7 x1,x2,x3,x4 ] inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    have A1: "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 X1,X2 :] iff x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2"
      using zfmisc_1_th_87 sorry
    have "[:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K3 [:ZFMISC-1K2 X1,X2 :],X3,X4 :] & [XTUPLE-0K7 x1,x2,x3,x4 ] =HIDDENR1 [XTUPLE-0K3 [TARSKIK4 x1,x2 ],x3,x4 ]"
      using mcart_1_th_50 sorry
    thus " not ([XTUPLE-0K7 x1,x2,x3,x4 ] inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :] &  not (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4)) &  not ((((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) &  not [XTUPLE-0K7 x1,x2,x3,x4 ] inHIDDENR3 [:ZFMISC-1K4 X1,X2,X3,X4 :])"
      using A1 mcart_1_th_69 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_81:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])) implies Z =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Z be setHIDDENM2 holds ( for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])) implies Z =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: " for z be objectHIDDENM1 holds z inHIDDENR3 Z iff ( ex x1 be objectHIDDENM1 st  ex x2 be objectHIDDENM1 st  ex x3 be objectHIDDENM1 st  ex x4 be objectHIDDENM1 st (((x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3) & x4 inHIDDENR3 X4) & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ])"
    have " for z be objectHIDDENM1 holds (z inHIDDENR3 Z implies z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]) & (z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] implies z inHIDDENR3 Z)"
    proof(rule ballI,rule conjMI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      show "z inHIDDENR3 Z implies z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      proof(rule impI)
        assume "z inHIDDENR3 Z"
        then obtain x1 x2 x3 x4 where
          [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
          A2: "(x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3"and A3: "x4 inHIDDENR3 X4 & z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
          using A1 sorry
        have "[XTUPLE-0K3 x1,x2,x3 ] inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"
          using A2 mcart_1_th_69 sorry
        thus "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
          using A3 zfmisc_1_def_2 sorry
      qed
      assume "z inHIDDENR3 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      then obtain x123 x4 where
        [ty]:"x123 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
        A4: "x123 inHIDDENR3 [:ZFMISC-1K3 X1,X2,X3 :]"and A5: "x4 inHIDDENR3 X4"and A6: "z =HIDDENR1 [TARSKIK4 x123,x4 ]"
        using zfmisc_1_def_2 sorry
      obtain x1 x2 x3 where
        [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
        A7: "(x1 inHIDDENR3 X1 & x2 inHIDDENR3 X2) & x3 inHIDDENR3 X3"and A8: "x123 =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
        using A4 mcart_1_th_68 sorry
      have "z =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
        using A6 A8 sorry
      thus "z inHIDDENR3 Z"
        using A1 A5 A7 sorry
    qed "sorry"
    then have "Z =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :]"
      using tarski_th_2 sorry
    thus "Z =XBOOLE-0R4 [:ZFMISC-1K4 X1,X2,X3,X4 :]"
      using zfmisc_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem mcart_1_th_83:
" for X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1 holds  for A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2 holds  for A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3 holds  for A4 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X4 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :] holds x inTARSKIR2 [:ZFMISC-1K4 A1,A2,A3,A4 :] implies ((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A1 & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A2) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A3) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A4"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix X1 assume [ty]: "X1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X2 assume [ty]: "X2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X3 assume [ty]: "X3 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X4 assume [ty]: "X4 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix A1 assume [ty]: "A1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X1"
  fix A2 assume [ty]: "A2 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X2"
  fix A3 assume [ty]: "A3 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X3"
  fix A4 assume [ty]: "A4 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of X4"
  fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
  assume "x inTARSKIR2 [:ZFMISC-1K4 A1,A2,A3,A4 :]"
  then obtain y where 
    [ty]:"y be ElementSUBSET-1M1-of [:ZFMISC-1K4 A1,A2,A3,A4 :]" and yDef:"y = x"
     sorry
  have A1: "y `2-4MCART-1K5\<^bsub>(A1,A2,A3,A4)\<^esub> inTARSKIR2 A2"
     sorry
  have A2: "y `4-4MCART-1K7\<^bsub>(A1,A2,A3,A4)\<^esub> inTARSKIR2 A4"
     sorry
  have A3: "y `3-4MCART-1K6\<^bsub>(A1,A2,A3,A4)\<^esub> inTARSKIR2 A3"
     sorry
  have "y `1-4MCART-1K4\<^bsub>(A1,A2,A3,A4)\<^esub> inTARSKIR2 A1"
     sorry
  thus "((x `1-4MCART-1K4\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A1 & x `2-4MCART-1K5\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A2) & x `3-4MCART-1K6\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A3) & x `4-4MCART-1K7\<^bsub>(X1,X2,X3,X4)\<^esub> inTARSKIR2 A4"
    using A1 A3 A2 sorry
qed "sorry"

mtheorem mcart_1_th_84:
" for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds ((X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2) & X3 c=TARSKIR1 Y3) & X4 c=TARSKIR1 Y4 implies [:ZFMISC-1K4 X1,X2,X3,X4 :] c=TARSKIR1 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :]"
proof-
  have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds  for X3 be setHIDDENM2 holds  for X4 be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for Y2 be setHIDDENM2 holds  for Y3 be setHIDDENM2 holds  for Y4 be setHIDDENM2 holds (X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2) & X3 c=TARSKIR1 Y3 implies (X4 c=TARSKIR1 Y4 implies [:ZFMISC-1K4 X1,X2,X3,X4 :] c=TARSKIR1 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :])"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix X2 assume [ty]: "X2 be setHIDDENM2"
    fix X3 assume [ty]: "X3 be setHIDDENM2"
    fix X4 assume [ty]: "X4 be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix Y2 assume [ty]: "Y2 be setHIDDENM2"
    fix Y3 assume [ty]: "Y3 be setHIDDENM2"
    fix Y4 assume [ty]: "Y4 be setHIDDENM2"
    have A1: "[:ZFMISC-1K4 X1,X2,X3,X4 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K3 X1,X2,X3 :],X4 :] & [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :] =XBOOLE-0R4 [:ZFMISC-1K2 [:ZFMISC-1K3 Y1,Y2,Y3 :],Y4 :]"
      using zfmisc_1_def_4 sorry
    assume "(X1 c=TARSKIR1 Y1 & X2 c=TARSKIR1 Y2) & X3 c=TARSKIR1 Y3"
    then have A2: "[:ZFMISC-1K3 X1,X2,X3 :] c=TARSKIR1 [:ZFMISC-1K3 Y1,Y2,Y3 :]"
      using mcart_1_th_73 sorry
    assume "X4 c=TARSKIR1 Y4"
    thus "[:ZFMISC-1K4 X1,X2,X3,X4 :] c=TARSKIR1 [:ZFMISC-1K4 Y1,Y2,Y3,Y4 :]"
      using A2 A1 zfmisc_1_th_96 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax MCART_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[:MCART-1K8\<^bsub>'( _ , _ ')\<^esub> _ , _ :]" [0,0,0,0]164)
translations "[:MCART-1K8\<^bsub>(X1,X2)\<^esub> A1,A2 :]" \<rightharpoonup> "[:ZFMISC-1K2 A1,A2 :]"

mtheorem mcart_1_add_8:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "A1 be SubsetSUBSET-1M2-of X1", "A2 be SubsetSUBSET-1M2-of X2"
"cluster [:ZFMISC-1K2 A1,A2 :] as-term-is SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
proof
(*coherence*)
  show "[:ZFMISC-1K2 A1,A2 :] be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X1,X2 :]"
    using zfmisc_1_th_96 sorry
qed "sorry"

syntax MCART_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[:MCART-1K9\<^bsub>'( _ , _ , _ ')\<^esub> _ , _ , _ :]" [0,0,0,0,0,0]164)
translations "[:MCART-1K9\<^bsub>(X1,X2,X3)\<^esub> A1,A2,A3 :]" \<rightharpoonup> "[:ZFMISC-1K3 A1,A2,A3 :]"

mtheorem mcart_1_add_9:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "X3 be setHIDDENM2", "A1 be SubsetSUBSET-1M2-of X1", "A2 be SubsetSUBSET-1M2-of X2", "A3 be SubsetSUBSET-1M2-of X3"
"cluster [:ZFMISC-1K3 A1,A2,A3 :] as-term-is SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
proof
(*coherence*)
  show "[:ZFMISC-1K3 A1,A2,A3 :] be SubsetSUBSET-1M2-of [:ZFMISC-1K3 X1,X2,X3 :]"
    using mcart_1_th_73 sorry
qed "sorry"

syntax MCART_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("[:MCART-1K10\<^bsub>'( _ , _ , _ , _ ')\<^esub> _ , _ , _ , _ :]" [0,0,0,0,0,0,0,0]164)
translations "[:MCART-1K10\<^bsub>(X1,X2,X3,X4)\<^esub> A1,A2,A3,A4 :]" \<rightharpoonup> "[:ZFMISC-1K4 A1,A2,A3,A4 :]"

mtheorem mcart_1_add_10:
  mlet "X1 be setHIDDENM2", "X2 be setHIDDENM2", "X3 be setHIDDENM2", "X4 be setHIDDENM2", "A1 be SubsetSUBSET-1M2-of X1", "A2 be SubsetSUBSET-1M2-of X2", "A3 be SubsetSUBSET-1M2-of X3", "A4 be SubsetSUBSET-1M2-of X4"
"cluster [:ZFMISC-1K4 A1,A2,A3,A4 :] as-term-is SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
proof
(*coherence*)
  show "[:ZFMISC-1K4 A1,A2,A3,A4 :] be SubsetSUBSET-1M2-of [:ZFMISC-1K4 X1,X2,X3,X4 :]"
    using mcart_1_th_84 sorry
qed "sorry"

(*begin*)
mdef mcart_1_def_12 ("pr1MCART-1K11  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func pr1MCART-1K11 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1))))"
      proof-
        let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)`1XTUPLE-0K1"
        have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =HIDDENR1 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1)) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FunctionFUNCT-1M1 holds  for p2 be FunctionFUNCT-1M1 holds domRELAT-1K1 p1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1) & (domRELAT-1K1 p2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1))) implies p1 =HIDDENR1 p2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix p1 assume [ty]: "p1 be FunctionFUNCT-1M1"
        fix p2 assume [ty]: "p2 be FunctionFUNCT-1M1"
        assume A1: "domRELAT-1K1 p1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1"
          and A3: "domRELAT-1K1 p2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =XBOOLE-0R4 p2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 domRELAT-1K1 f"
          then have "p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`1XTUPLE-0K1"
            using A2 sorry
          thus "p1 .FUNCT-1K1 x =XBOOLE-0R4 p2 .FUNCT-1K1 x"
            using A4 A5 sorry
        qed "sorry"
        thus "p1 =HIDDENR1 p2"
          using A1 A3 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef mcart_1_def_13 ("pr2MCART-1K12  _ " [228]228 ) where
  mlet "f be FunctionFUNCT-1M1"
"func pr2MCART-1K12 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2)"
    proof-
      have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2))))"
      proof-
        let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)`2XTUPLE-0K2"
        have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =HIDDENR1 ?F(x))"
          using funct_1_sch_3 sorry
        thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 f &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies it2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2)) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FunctionFUNCT-1M1 holds  for p2 be FunctionFUNCT-1M1 holds domRELAT-1K1 p1 =XBOOLE-0R4 domRELAT-1K1 f & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2) & (domRELAT-1K1 p2 =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2))) implies p1 =HIDDENR1 p2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix p1 assume [ty]: "p1 be FunctionFUNCT-1M1"
        fix p2 assume [ty]: "p2 be FunctionFUNCT-1M1"
        assume A6: "domRELAT-1K1 p1 =XBOOLE-0R4 domRELAT-1K1 f"
          and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2"
          and A8: "domRELAT-1K1 p2 =XBOOLE-0R4 domRELAT-1K1 f"
          and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p2 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies p1 .FUNCT-1K1 x =XBOOLE-0R4 p2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A10: "x inHIDDENR3 domRELAT-1K1 f"
          then have "p1 .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)`2XTUPLE-0K2"
            using A7 sorry
          thus "p1 .FUNCT-1K1 x =XBOOLE-0R4 p2 .FUNCT-1K1 x"
            using A9 A10 sorry
        qed "sorry"
        thus "p1 =HIDDENR1 p2"
          using A6 A8 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef mcart_1_def_14 (" _ `11MCART-1K13" [355]355 ) where
  mlet "x be objectHIDDENM1"
"func x `11MCART-1K13 \<rightarrow> setHIDDENM2 equals
  (x `1XTUPLE-0K1)`1XTUPLE-0K1"
proof-
  (*coherence*)
    show "(x `1XTUPLE-0K1)`1XTUPLE-0K1 be setHIDDENM2"
      using tarski_th_1 sorry
qed "sorry"

mdef mcart_1_def_15 (" _ `12MCART-1K14" [355]355 ) where
  mlet "x be objectHIDDENM1"
"func x `12MCART-1K14 \<rightarrow> setHIDDENM2 equals
  (x `1XTUPLE-0K1)`2XTUPLE-0K2"
proof-
  (*coherence*)
    show "(x `1XTUPLE-0K1)`2XTUPLE-0K2 be setHIDDENM2"
      using tarski_th_1 sorry
qed "sorry"

mdef mcart_1_def_16 (" _ `21MCART-1K15" [355]355 ) where
  mlet "x be objectHIDDENM1"
"func x `21MCART-1K15 \<rightarrow> setHIDDENM2 equals
  (x `2XTUPLE-0K2)`1XTUPLE-0K1"
proof-
  (*coherence*)
    show "(x `2XTUPLE-0K2)`1XTUPLE-0K1 be setHIDDENM2"
      using tarski_th_1 sorry
qed "sorry"

mdef mcart_1_def_17 (" _ `22MCART-1K16" [355]355 ) where
  mlet "x be objectHIDDENM1"
"func x `22MCART-1K16 \<rightarrow> setHIDDENM2 equals
  (x `2XTUPLE-0K2)`2XTUPLE-0K2"
proof-
  (*coherence*)
    show "(x `2XTUPLE-0K2)`2XTUPLE-0K2 be setHIDDENM2"
      using tarski_th_1 sorry
qed "sorry"

reserve x for "objectHIDDENM1"
mtheorem mcart_1_th_85:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for x be objectHIDDENM1 holds (([TARSKIK4 [TARSKIK4 x1,x2 ],y ] `11MCART-1K13 =HIDDENR1 x1 & [TARSKIK4 [TARSKIK4 x1,x2 ],y ] `12MCART-1K14 =HIDDENR1 x2) & [TARSKIK4 x,[TARSKIK4 y1,y2 ] ] `21MCART-1K15 =HIDDENR1 y1) & [TARSKIK4 x,[TARSKIK4 y1,y2 ] ] `22MCART-1K16 =HIDDENR1 y2"
   sorry

mtheorem mcart_1_th_86:
" for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 R implies x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 R & x `2XTUPLE-0K2 inHIDDENR3 rngRELAT-1K2 R"
proof-
  have " for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 R implies x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 R & x `2XTUPLE-0K2 inHIDDENR3 rngRELAT-1K2 R"
  proof(rule ballI,rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 R"
    then have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ]"
      using mcart_1_th_21 sorry
    thus "x `1XTUPLE-0K1 inHIDDENR3 domRELAT-1K1 R & x `2XTUPLE-0K2 inHIDDENR3 rngRELAT-1K2 R"
      using A1 xtuple_0_def_12 xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_87:
" for R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds ImRELAT-1K12(R,x) =XBOOLE-0R4 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
proof(rule ballI,rule ballI)
  fix R assume [ty]: "R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  let ?X = "{I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
  have "ImRELAT-1K12(R,x) c=TARSKIR1 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x } & {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x } c=TARSKIR1 ImRELAT-1K12(R,x)"
  proof(rule conjMI)
    show "ImRELAT-1K12(R,x) c=TARSKIR1 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 ImRELAT-1K12(R,x) implies z inHIDDENR3 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 ImRELAT-1K12(R,x)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 y,z ] inHIDDENR3 R"and A2: "y inHIDDENR3 {TARSKIK1 x}"
          using relat_1_def_13 sorry
        have A3: "y =HIDDENR1 x"
          using A2 tarski_def_1 sorry
        have "y =HIDDENR1 [TARSKIK4 y,z ] `1XTUPLE-0K1 & z =HIDDENR1 [TARSKIK4 y,z ] `2XTUPLE-0K2"
           sorry
        thus "z inHIDDENR3 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
          using A1 A3 sorry
      qed "sorry"
      thus "ImRELAT-1K12(R,x) c=TARSKIR1 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
        using tarski_def_3 sorry
    qed
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x } implies z inHIDDENR3 ImRELAT-1K12(R,x)"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 ?X"
      then obtain I where
        [ty]:"I be ElementSUBSET-1M1-of R" and 
        A4: "z =HIDDENR1 I `2XTUPLE-0K2"and A5: "I `1XTUPLE-0K1 =HIDDENR1 x"
         sorry
      have A6: "I =HIDDENR1 [TARSKIK4 I `1XTUPLE-0K1,I `2XTUPLE-0K2 ]"
        using mcart_1_th_21 sorry
      have "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      thus "z inHIDDENR3 ImRELAT-1K12(R,x)"
        using A4 A5 A6 relat_1_def_13 sorry
    qed "sorry"
    thus "{I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x } c=TARSKIR1 ImRELAT-1K12(R,x)"
      using tarski_def_3 sorry
  qed
  thus "ImRELAT-1K12(R,x) =XBOOLE-0R4 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem mcart_1_th_88:
" for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 R implies x `2XTUPLE-0K2 inHIDDENR3 ImRELAT-1K12(R,x `1XTUPLE-0K1)"
proof-
  have " for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 R implies x `2XTUPLE-0K2 inHIDDENR3 ImRELAT-1K12(R,x `1XTUPLE-0K1)"
  proof(rule ballI,rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume A1: "x inHIDDENR3 R"
    then have "x `2XTUPLE-0K2 inHIDDENR3 {I `2XTUPLE-0K2 where I be ElementSUBSET-1M1-of R : I `1XTUPLE-0K1 =HIDDENR1 x `1XTUPLE-0K1 }"
       sorry
    thus "x `2XTUPLE-0K2 inHIDDENR3 ImRELAT-1K12(R,x `1XTUPLE-0K1)"
      using A1 mcart_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_89:
" for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds ((x inHIDDENR3 R & y inHIDDENR3 R) & x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1) & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2 implies x =HIDDENR1 y"
proof-
  have " for y be objectHIDDENM1 holds  for R be RelationRELAT-1M1 holds  for x be objectHIDDENM1 holds x inHIDDENR3 R & y inHIDDENR3 R implies  not ((x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2) &  not x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 R & y inHIDDENR3 R"
    then have "x =HIDDENR1 [TARSKIK4 x `1XTUPLE-0K1,x `2XTUPLE-0K2 ] & y =HIDDENR1 [TARSKIK4 y `1XTUPLE-0K1,y `2XTUPLE-0K2 ]"
      using mcart_1_th_21 sorry
    thus " not ((x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2) &  not x =HIDDENR1 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_90:
" for R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1 holds  for x be ElementSUBSET-1M1-of R holds  for y be ElementSUBSET-1M1-of R holds x `1XTUPLE-0K1 =HIDDENR1 y `1XTUPLE-0K1 & x `2XTUPLE-0K2 =HIDDENR1 y `2XTUPLE-0K2 implies x =XBOOLE-0R4 y"
  using mcart_1_th_89 sorry

mtheorem mcart_1_th_91:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,y2,y3 ] }) =XBOOLE-0R4 {TARSKIK2 x1,y1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,y2,y3 ] }) =HIDDENR1 {TARSKIK2 x1,y1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    have "proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,y2,y3 ] }) =HIDDENR1 proj1XTUPLE-0K12 {TARSKIK2 [TARSKIK4 x1,x2 ],[TARSKIK4 y1,y2 ] }"
      using relat_1_th_10 sorry
    also have "... = {TARSKIK2 x1,y1 }"
      using relat_1_th_10 sorry
    finally show "proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK2 [XTUPLE-0K3 x1,x2,x3 ],[XTUPLE-0K3 y1,y2,y3 ] }) =HIDDENR1 {TARSKIK2 x1,y1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem mcart_1_th_92:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }) =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }) =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }) =HIDDENR1 proj1XTUPLE-0K12 {TARSKIK1 [TARSKIK4 x1,x2 ] }"
      using relat_1_th_9 sorry
    also have "... = {TARSKIK1 x1}"
      using relat_1_th_9 sorry
    finally show "proj1XTUPLE-0K12 (proj1XTUPLE-0K12 {TARSKIK1 [XTUPLE-0K3 x1,x2,x3 ] }) =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem mcart_1_sch_1:
  fixes Af0 Bf0 Cf0 Pp3 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Cf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex y be objectHIDDENM1 st  ex z be objectHIDDENM1 st (y inHIDDENR3 Bf0 & z inHIDDENR3 Cf0) & Pp3(x,y,z))"
  shows " ex f be FunctionFUNCT-1M1 st  ex g be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 Af0 & domRELAT-1K1 g =XBOOLE-0R4 Af0) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp3(x,f .FUNCT-1K1 x,g .FUNCT-1K1 x))"
  proof-
    have " ex tVar14 be FunctionFUNCT-1M1 st  ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar14 =XBOOLE-0R4 Af0 & domRELAT-1K1 tVar15 =XBOOLE-0R4 Af0) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp3(x,tVar14 .FUNCT-1K1 x,tVar15 .FUNCT-1K1 x))"
    proof-
      let ?H = "\<lambda>Lamb1. \<lambda>Lamb2.  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds Lamb2 `1XTUPLE-0K1 =HIDDENR1 y & Lamb2 `2XTUPLE-0K2 =HIDDENR1 z implies Pp3(Lamb1,y,z)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex p be objectHIDDENM1 st p inHIDDENR3 [:ZFMISC-1K2 Bf0,Cf0 :] & ?H(x,p))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ( ex tVar13 be objectHIDDENM1 st tVar13 inTARSKIR2 [:ZFMISC-1K2 Bf0,Cf0 :] & ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds tVar13 `1XTUPLE-0K1 =HIDDENR1 y & tVar13 `2XTUPLE-0K2 =HIDDENR1 z implies Pp3(x,y,z)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 Af0"
          then obtain y z where
            [ty]:"y be objectHIDDENM1" "z be objectHIDDENM1" and 
            A3: "y inHIDDENR3 Bf0 & z inHIDDENR3 Cf0"and A4: "Pp3(x,y,z)"
            using A1 sorry
          obtain p where 
            [ty]:"p be setHIDDENM2" and pDef:"p = [TARSKIK4 y,z ]"
             sorry
          show " ex tVar13 be objectHIDDENM1 st tVar13 inTARSKIR2 [:ZFMISC-1K2 Bf0,Cf0 :] & ( for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds tVar13 `1XTUPLE-0K1 =HIDDENR1 y & tVar13 `2XTUPLE-0K2 =HIDDENR1 z implies Pp3(x,y,z))"
          proof(rule bexI[of _ "p"],rule conjMI)
            show "p inTARSKIR2 [:ZFMISC-1K2 Bf0,Cf0 :]"
              using A3 zfmisc_1_th_87 sorry
            show " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds p `1XTUPLE-0K1 =HIDDENR1 y & p `2XTUPLE-0K2 =HIDDENR1 z implies Pp3(x,y,z)"
              using A4 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 h =XBOOLE-0R4 Af0 & rngFUNCT-1K2 h c=TARSKIR1 [:ZFMISC-1K2 Bf0,Cf0 :]"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies ?H(x,h .FUNCT-1K1 x)"
        using funct_1_sch_6 A2 sorry
      let ?g = "\<lambda>Lamb1. (h .FUNCT-1K1 Lamb1)`2XTUPLE-0K2"
      let ?f = "\<lambda>Lamb1. (h .FUNCT-1K1 Lamb1)`1XTUPLE-0K1"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A6: "domRELAT-1K1 f =XBOOLE-0R4 Af0"and A7: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =HIDDENR1 ?f(x)"
        using funct_1_sch_3 sorry
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A8: "domRELAT-1K1 g =XBOOLE-0R4 Af0"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies g .FUNCT-1K1 x =HIDDENR1 ?g(x)"
        using funct_1_sch_3 sorry
      show " ex tVar14 be FunctionFUNCT-1M1 st  ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 tVar14 =XBOOLE-0R4 Af0 & domRELAT-1K1 tVar15 =XBOOLE-0R4 Af0) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp3(x,tVar14 .FUNCT-1K1 x,tVar15 .FUNCT-1K1 x))"
      proof(rule bexI[of _ "f"])
        show " ex tVar15 be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 Af0 & domRELAT-1K1 tVar15 =XBOOLE-0R4 Af0) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp3(x,f .FUNCT-1K1 x,tVar15 .FUNCT-1K1 x))"
        proof(rule bexI[of _ "g"],rule conjMI)
          show "domRELAT-1K1 f =XBOOLE-0R4 Af0 & domRELAT-1K1 g =XBOOLE-0R4 Af0"
            using A6 A8 sorry
          show " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies Pp3(x,f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A10: "x inHIDDENR3 Af0"
            then have "f .FUNCT-1K1 x =HIDDENR1 (h .FUNCT-1K1 x)`1XTUPLE-0K1 & g .FUNCT-1K1 x =HIDDENR1 (h .FUNCT-1K1 x)`2XTUPLE-0K2"
              using A7 A9 sorry
            thus "Pp3(x,f .FUNCT-1K1 x,g .FUNCT-1K1 x)"
              using A5 A10 sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem mcart_1_th_93:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds [TARSKIK4 [TARSKIK4 x1,x2 ],[TARSKIK4 x3,x4 ] ] =HIDDENR1 [TARSKIK4 [TARSKIK4 y1,y2 ],[TARSKIK4 y3,y4 ] ] implies ((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds [TARSKIK4 [TARSKIK4 x1,x2 ],[TARSKIK4 x3,x4 ] ] =HIDDENR1 [TARSKIK4 [TARSKIK4 y1,y2 ],[TARSKIK4 y3,y4 ] ] implies ((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix y1 assume [ty]: "y1 be objectHIDDENM1"
    fix y2 assume [ty]: "y2 be objectHIDDENM1"
    fix y3 assume [ty]: "y3 be objectHIDDENM1"
    fix y4 assume [ty]: "y4 be objectHIDDENM1"
    assume "[TARSKIK4 [TARSKIK4 x1,x2 ],[TARSKIK4 x3,x4 ] ] =HIDDENR1 [TARSKIK4 [TARSKIK4 y1,y2 ],[TARSKIK4 y3,y4 ] ]"
    then have "[TARSKIK4 x1,x2 ] =HIDDENR1 [TARSKIK4 y1,y2 ] & [TARSKIK4 x3,x4 ] =HIDDENR1 [TARSKIK4 y3,y4 ]"
      using xtuple_0_th_1 sorry
    thus "((x1 =HIDDENR1 y1 & x2 =HIDDENR1 y2) & x3 =HIDDENR1 y3) & x4 =HIDDENR1 y4"
      using xtuple_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
