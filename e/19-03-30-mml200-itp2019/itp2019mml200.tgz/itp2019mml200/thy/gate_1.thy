theory gate_1
  imports xboole_0
begin
(*begin*)
mdef gate_1_def_1 ("NOT1GATE-1K1  _ " [164]164 ) where
  mlet "a be setHIDDENM2"
"func NOT1GATE-1K1 a \<rightarrow> setHIDDENM2 equals
  {}XBOOLE-0K1 if a be  non emptyXBOOLE-0V1 otherwise {TARSKIK1 {}XBOOLE-0K1 }"
proof-
  (*coherence*)
    show "(a be  non emptyXBOOLE-0V1 implies {}XBOOLE-0K1 be setHIDDENM2) & ( not a be  non emptyXBOOLE-0V1 implies {TARSKIK1 {}XBOOLE-0K1 } be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_cl_1:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster NOT1GATE-1K1 a as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NOT1GATE-1K1 a be  non emptyXBOOLE-0V1"
    using gate_1_def_1 sorry
qed "sorry"

mtheorem gate_1_cl_2:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster NOT1GATE-1K1 a as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NOT1GATE-1K1 a be emptyXBOOLE-0V1"
    using gate_1_def_1 sorry
qed "sorry"

mtheorem gate_1_th_1:
"NOT1GATE-1K1 {TARSKIK1 {}XBOOLE-0K1 } =XBOOLE-0R4 {}XBOOLE-0K1 & NOT1GATE-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 {TARSKIK1 {}XBOOLE-0K1 }"
  using gate_1_def_1 sorry

mtheorem gate_1_th_2:
" for a be setHIDDENM2 holds NOT1GATE-1K1 a be  non emptyXBOOLE-0V1 iff  not a be  non emptyXBOOLE-0V1"
   sorry

reserve a, b, c, d, e, f, g, h for "setHIDDENM2"
mtheorem gate_1_th_3:
"NOT1GATE-1K1 {}XBOOLE-0K1 be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_2 ("AND2GATE-1K2'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func AND2GATE-1K2(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K2_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds AND2GATE-1K2(a,b) =HIDDENR1 AND2GATE-1K2(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 AND2GATE-1K2(a,b) implies it =HIDDENR1 AND2GATE-1K2(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1) implies (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_3:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster AND2GATE-1K2(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND2GATE-1K2(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_2 sorry
qed "sorry"

mtheorem gate_1_cl_4:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2"
"cluster AND2GATE-1K2(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND2GATE-1K2(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_2 sorry
qed "sorry"

mtheorem gate_1_th_4:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds AND2GATE-1K2(a,b) be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_3 ("OR2GATE-1K3'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func OR2GATE-1K3(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K3_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds OR2GATE-1K3(a,b) =HIDDENR1 OR2GATE-1K3(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 OR2GATE-1K3(a,b) implies it =HIDDENR1 OR2GATE-1K3(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1) implies (b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_5:
  mlet "a be setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster OR2GATE-1K3(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_3 sorry
qed "sorry"

mtheorem gate_1_cl_6:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster OR2GATE-1K3(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR2GATE-1K3(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_3 sorry
qed "sorry"

mtheorem gate_1_th_5:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds OR2GATE-1K3(a,b) be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_4 ("XOR2GATE-1K4'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func XOR2GATE-1K4(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K4_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds XOR2GATE-1K4(a,b) =HIDDENR1 XOR2GATE-1K4(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 XOR2GATE-1K4(a,b) implies it =HIDDENR1 XOR2GATE-1K4(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1) implies (b be  non emptyXBOOLE-0V1 &  not a be  non emptyXBOOLE-0V1 or  not b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1 implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (b be  non emptyXBOOLE-0V1 &  not a be  non emptyXBOOLE-0V1 or  not b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_7:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR2GATE-1K4(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR2GATE-1K4(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_4 sorry
qed "sorry"

mtheorem gate_1_cl_8:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR2GATE-1K4(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_4 sorry
qed "sorry"

mtheorem gate_1_cl_9:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR2GATE-1K4(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_4 sorry
qed "sorry"

mtheorem gate_1_th_6:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds XOR2GATE-1K4(a,b) be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1"
   sorry

mtheorem gate_1_th_7:
" for a be setHIDDENM2 holds  not XOR2GATE-1K4(a,a) be  non emptyXBOOLE-0V1"
proof-
  have " for a be setHIDDENM2 holds XOR2GATE-1K4(a,a) be emptyXBOOLE-0V1"
  proof(rule ballI)
    fix a assume [ty]: "a be setHIDDENM2"
    have "XOR2GATE-1K4(a,a) be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1 &  not a be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1"
       sorry
    thus "XOR2GATE-1K4(a,a) be emptyXBOOLE-0V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_th_8:
" for a be setHIDDENM2 holds XOR2GATE-1K4(a,{}XBOOLE-0K1) be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1"
   sorry

mtheorem gate_1_th_9:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds XOR2GATE-1K4(a,b) be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(b,a) be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_5 ("EQV2GATE-1K5'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func EQV2GATE-1K5(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K5_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds EQV2GATE-1K5(a,b) =HIDDENR1 EQV2GATE-1K5(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 EQV2GATE-1K5(a,b) implies it =HIDDENR1 EQV2GATE-1K5(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds ((a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1) implies ((b be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not (b be  non emptyXBOOLE-0V1 iff a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_10:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster EQV2GATE-1K5(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "EQV2GATE-1K5(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_5 sorry
qed "sorry"

mtheorem gate_1_cl_11:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster EQV2GATE-1K5(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "EQV2GATE-1K5(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_5 sorry
qed "sorry"

mtheorem gate_1_cl_12:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster EQV2GATE-1K5(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "EQV2GATE-1K5(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_5 sorry
qed "sorry"

mtheorem gate_1_th_10:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds EQV2GATE-1K5(a,b) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1)"
   sorry

mtheorem gate_1_th_11:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds EQV2GATE-1K5(a,b) be  non emptyXBOOLE-0V1 iff  not XOR2GATE-1K4(a,b) be  non emptyXBOOLE-0V1"
proof-
  have " for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  not ( not EQV2GATE-1K5(a,b) be emptyXBOOLE-0V1 &  not XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1) &  not (XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1 & EQV2GATE-1K5(a,b) be emptyXBOOLE-0V1)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be setHIDDENM2"
    fix b assume [ty]: "b be setHIDDENM2"
    have "EQV2GATE-1K5(a,b) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 iff b be  non emptyXBOOLE-0V1)"
       sorry
    thus " not ( not EQV2GATE-1K5(a,b) be emptyXBOOLE-0V1 &  not XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1) &  not (XOR2GATE-1K4(a,b) be emptyXBOOLE-0V1 & EQV2GATE-1K5(a,b) be emptyXBOOLE-0V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef gate_1_def_6 ("NAND2GATE-1K6'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func NAND2GATE-1K6(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K6_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds NAND2GATE-1K6(a,b) =HIDDENR1 NAND2GATE-1K6(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 NAND2GATE-1K6(a,b) implies it =HIDDENR1 NAND2GATE-1K6(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds ( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ( not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1) implies ( not (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ( not (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_13:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2"
"cluster NAND2GATE-1K6(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NAND2GATE-1K6(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_6 sorry
qed "sorry"

mtheorem gate_1_cl_14:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster NAND2GATE-1K6(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NAND2GATE-1K6(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_6 sorry
qed "sorry"

mtheorem gate_1_th_12:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds NAND2GATE-1K6(a,b) be  non emptyXBOOLE-0V1 iff  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)"
   sorry

mdef gate_1_def_7 ("NOR2GATE-1K7'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func NOR2GATE-1K7(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K7_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds NOR2GATE-1K7(a,b) =HIDDENR1 NOR2GATE-1K7(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 NOR2GATE-1K7(a,b) implies it =HIDDENR1 NOR2GATE-1K7(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds ( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ( not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1) implies ( not (b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ( not (b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_cl_15:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster NOR2GATE-1K7(a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NOR2GATE-1K7(a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_7 sorry
qed "sorry"

mtheorem gate_1_cl_16:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2"
"cluster NOR2GATE-1K7(a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "NOR2GATE-1K7(a,b) be emptyXBOOLE-0V1"
    using gate_1_def_7 sorry
qed "sorry"

mtheorem gate_1_th_13:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds NOR2GATE-1K7(a,b) be  non emptyXBOOLE-0V1 iff  not (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1)"
   sorry

mdef gate_1_def_8 ("AND3GATE-1K8'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func AND3GATE-1K8(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_cl_17:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster AND3GATE-1K8(a,b,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND3GATE-1K8(a,b,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_8 sorry
qed "sorry"

mtheorem gate_1_cl_18:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster AND3GATE-1K8(a,b,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND3GATE-1K8(a,b,c) be emptyXBOOLE-0V1"
    using gate_1_def_8 sorry
qed "sorry"

mtheorem gate_1_cl_19:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster AND3GATE-1K8(b,a,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND3GATE-1K8(b,a,c) be emptyXBOOLE-0V1"
    using gate_1_def_8 sorry
qed "sorry"

mtheorem gate_1_cl_20:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster AND3GATE-1K8(b,c,a) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "AND3GATE-1K8(b,c,a) be emptyXBOOLE-0V1"
    using gate_1_def_8 sorry
qed "sorry"

mtheorem gate_1_th_14:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds AND3GATE-1K8(a,b,c) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_9 ("OR3GATE-1K9'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func OR3GATE-1K9(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_cl_21:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster OR3GATE-1K9(a,b,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR3GATE-1K9(a,b,c) be emptyXBOOLE-0V1"
    using gate_1_def_9 sorry
qed "sorry"

mtheorem gate_1_cl_22:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster OR3GATE-1K9(a,b,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR3GATE-1K9(a,b,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_9 sorry
qed "sorry"

mtheorem gate_1_cl_23:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster OR3GATE-1K9(b,a,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR3GATE-1K9(b,a,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_9 sorry
qed "sorry"

mtheorem gate_1_cl_24:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"cluster OR3GATE-1K9(b,c,a) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "OR3GATE-1K9(b,c,a) be  non emptyXBOOLE-0V1"
    using gate_1_def_9 sorry
qed "sorry"

mtheorem gate_1_th_15:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds OR3GATE-1K9(a,b,c) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_10 ("XOR3GATE-1K10'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func XOR3GATE-1K10(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) &  not c be  non emptyXBOOLE-0V1 or  not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) &  not c be  non emptyXBOOLE-0V1 or  not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) &  not c be  non emptyXBOOLE-0V1 or  not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_cl_25:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,b,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,b,c) be emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_26:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,b,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,b,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_27:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,c,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,c,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_28:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(c,a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(c,a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_29:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,b,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,b,c) be emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_30:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,c,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,c,b) be emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_31:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(c,a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(c,a,b) be emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_cl_32:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster XOR3GATE-1K10(a,b,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "XOR3GATE-1K10(a,b,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_10 sorry
qed "sorry"

mtheorem gate_1_th_16:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds XOR3GATE-1K10(a,b,c) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) &  not c be  non emptyXBOOLE-0V1 or  not (a be  non emptyXBOOLE-0V1 &  not b be  non emptyXBOOLE-0V1 or  not a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_11 ("MAJ3GATE-1K11'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func MAJ3GATE-1K11(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 & c be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 & c be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 & c be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_cl_33:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(a,b,c) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(a,b,c) be  non emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_cl_34:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(a,c,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(a,c,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_cl_35:
  mlet "a be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(c,a,b) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(c,a,b) be  non emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_cl_36:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(a,b,c) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(a,b,c) be emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_cl_37:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(a,c,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(a,c,b) be emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_cl_38:
  mlet "a be emptyXBOOLE-0V1\<bar>setHIDDENM2", "b be emptyXBOOLE-0V1\<bar>setHIDDENM2", "c be setHIDDENM2"
"cluster MAJ3GATE-1K11(c,a,b) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "MAJ3GATE-1K11(c,a,b) be emptyXBOOLE-0V1"
    using gate_1_def_11 sorry
qed "sorry"

mtheorem gate_1_th_17:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds MAJ3GATE-1K11(a,b,c) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1 & c be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1"
   sorry

mdef gate_1_def_12 ("NAND3GATE-1K12'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func NAND3GATE-1K12(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_18:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds NAND3GATE-1K12(a,b,c) be  non emptyXBOOLE-0V1 iff  not ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1)"
  using gate_1_def_12 sorry

mdef gate_1_def_13 ("NOR3GATE-1K13'( _ , _ , _ ')" [0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2"
"func NOR3GATE-1K13(a,b,c) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_19:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds NOR3GATE-1K13(a,b,c) be  non emptyXBOOLE-0V1 iff  not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1)"
  using gate_1_def_13 sorry

mdef gate_1_def_14 ("AND4GATE-1K14'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2"
"func AND4GATE-1K14(a,b,c,d) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_20:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds AND4GATE-1K14(a,b,c,d) be  non emptyXBOOLE-0V1 iff ((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1"
  using gate_1_def_14 sorry

mdef gate_1_def_15 ("OR4GATE-1K15'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2"
"func OR4GATE-1K15(a,b,c,d) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_21:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds OR4GATE-1K15(a,b,c,d) be  non emptyXBOOLE-0V1 iff ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1"
  using gate_1_def_15 sorry

mdef gate_1_def_16 ("NAND4GATE-1K16'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2"
"func NAND4GATE-1K16(a,b,c,d) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_22:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds NAND4GATE-1K16(a,b,c,d) be  non emptyXBOOLE-0V1 iff  not (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1)"
  using gate_1_def_16 sorry

mdef gate_1_def_17 ("NOR4GATE-1K17'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2"
"func NOR4GATE-1K17(a,b,c,d) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_23:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds NOR4GATE-1K17(a,b,c,d) be  non emptyXBOOLE-0V1 iff  not (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1)"
  using gate_1_def_17 sorry

mdef gate_1_def_18 ("AND5GATE-1K18'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2"
"func AND5GATE-1K18(a,b,c,d,e) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_24:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds AND5GATE-1K18(a,b,c,d,e) be  non emptyXBOOLE-0V1 iff (((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1"
  using gate_1_def_18 sorry

mdef gate_1_def_19 ("OR5GATE-1K19'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2"
"func OR5GATE-1K19(a,b,c,d,e) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_25:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds OR5GATE-1K19(a,b,c,d,e) be  non emptyXBOOLE-0V1 iff (((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1"
  using gate_1_def_19 sorry

mdef gate_1_def_20 ("NAND5GATE-1K20'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2"
"func NAND5GATE-1K20(a,b,c,d,e) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_26:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds NAND5GATE-1K20(a,b,c,d,e) be  non emptyXBOOLE-0V1 iff  not ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1)"
  using gate_1_def_20 sorry

mdef gate_1_def_21 ("NOR5GATE-1K21'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2"
"func NOR5GATE-1K21(a,b,c,d,e) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_27:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds NOR5GATE-1K21(a,b,c,d,e) be  non emptyXBOOLE-0V1 iff  not ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1)"
  using gate_1_def_21 sorry

mdef gate_1_def_22 ("AND6GATE-1K22'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2"
"func AND6GATE-1K22(a,b,c,d,e,f) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_28:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds AND6GATE-1K22(a,b,c,d,e,f) be  non emptyXBOOLE-0V1 iff ((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1"
  using gate_1_def_22 sorry

mdef gate_1_def_23 ("OR6GATE-1K23'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2"
"func OR6GATE-1K23(a,b,c,d,e,f) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_29:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds OR6GATE-1K23(a,b,c,d,e,f) be  non emptyXBOOLE-0V1 iff ((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1"
  using gate_1_def_23 sorry

mdef gate_1_def_24 ("NAND6GATE-1K24'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2"
"func NAND6GATE-1K24(a,b,c,d,e,f) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_30:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds NAND6GATE-1K24(a,b,c,d,e,f) be  non emptyXBOOLE-0V1 iff  not (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1)"
  using gate_1_def_24 sorry

mdef gate_1_def_25 ("NOR6GATE-1K25'( _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2"
"func NOR6GATE-1K25(a,b,c,d,e,f) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_31:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds NOR6GATE-1K25(a,b,c,d,e,f) be  non emptyXBOOLE-0V1 iff  not (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1)"
  using gate_1_def_25 sorry

mdef gate_1_def_26 ("AND7GATE-1K26'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2"
"func AND7GATE-1K26(a,b,c,d,e,f,g) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_32:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds AND7GATE-1K26(a,b,c,d,e,f,g) be  non emptyXBOOLE-0V1 iff (((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1"
  using gate_1_def_26 sorry

mdef gate_1_def_27 ("OR7GATE-1K27'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2"
"func OR7GATE-1K27(a,b,c,d,e,f,g) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_33:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds OR7GATE-1K27(a,b,c,d,e,f,g) be  non emptyXBOOLE-0V1 iff (((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1"
  using gate_1_def_27 sorry

mdef gate_1_def_28 ("NAND7GATE-1K28'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2"
"func NAND7GATE-1K28(a,b,c,d,e,f,g) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_34:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds NAND7GATE-1K28(a,b,c,d,e,f,g) be  non emptyXBOOLE-0V1 iff  not ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1)"
  using gate_1_def_28 sorry

mdef gate_1_def_29 ("NOR7GATE-1K29'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2"
"func NOR7GATE-1K29(a,b,c,d,e,f,g) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_35:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds NOR7GATE-1K29(a,b,c,d,e,f,g) be  non emptyXBOOLE-0V1 iff  not ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1)"
  using gate_1_def_29 sorry

mdef gate_1_def_30 ("AND8GATE-1K30'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2", "h be setHIDDENM2"
"func AND8GATE-1K30(a,b,c,d,e,f,g,h) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_36:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds  for h be setHIDDENM2 holds AND8GATE-1K30(a,b,c,d,e,f,g,h) be  non emptyXBOOLE-0V1 iff ((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1"
  using gate_1_def_30 sorry

mdef gate_1_def_31 ("OR8GATE-1K31'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2", "h be setHIDDENM2"
"func OR8GATE-1K31(a,b,c,d,e,f,g,h) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1 otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "(((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1 implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not (((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_37:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds  for h be setHIDDENM2 holds OR8GATE-1K31(a,b,c,d,e,f,g,h) be  non emptyXBOOLE-0V1 iff ((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1"
  using gate_1_def_31 sorry

mdef gate_1_def_32 ("NAND8GATE-1K32'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2", "h be setHIDDENM2"
"func NAND8GATE-1K32(a,b,c,d,e,f,g,h) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_38:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds  for h be setHIDDENM2 holds NAND8GATE-1K32(a,b,c,d,e,f,g,h) be  non emptyXBOOLE-0V1 iff  not (((((((a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) & c be  non emptyXBOOLE-0V1) & d be  non emptyXBOOLE-0V1) & e be  non emptyXBOOLE-0V1) & f be  non emptyXBOOLE-0V1) & g be  non emptyXBOOLE-0V1) & h be  non emptyXBOOLE-0V1)"
  using gate_1_def_32 sorry

mdef gate_1_def_33 ("NOR8GATE-1K33'( _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2", "c be setHIDDENM2", "d be setHIDDENM2", "e be setHIDDENM2", "f be setHIDDENM2", "g be setHIDDENM2", "h be setHIDDENM2"
"func NOR8GATE-1K33(a,b,c,d,e,f,g,h) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if  not (((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "( not (((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ( not (((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem gate_1_th_39:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds  for c be setHIDDENM2 holds  for d be setHIDDENM2 holds  for e be setHIDDENM2 holds  for f be setHIDDENM2 holds  for g be setHIDDENM2 holds  for h be setHIDDENM2 holds NOR8GATE-1K33(a,b,c,d,e,f,g,h) be  non emptyXBOOLE-0V1 iff  not (((((((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) or c be  non emptyXBOOLE-0V1) or d be  non emptyXBOOLE-0V1) or e be  non emptyXBOOLE-0V1) or f be  non emptyXBOOLE-0V1) or g be  non emptyXBOOLE-0V1) or h be  non emptyXBOOLE-0V1)"
  using gate_1_def_33 sorry

(*begin*)
mtheorem gate_1_th_40:
" for c1 be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for y3 be setHIDDENM2 holds  for y4 be setHIDDENM2 holds  for c2 be setHIDDENM2 holds  for c3 be setHIDDENM2 holds  for c4 be setHIDDENM2 holds  for c5 be setHIDDENM2 holds  for n1 be setHIDDENM2 holds  for n2 be setHIDDENM2 holds  for n3 be setHIDDENM2 holds  for n4 be setHIDDENM2 holds  for n be setHIDDENM2 holds  for c5b be setHIDDENM2 holds (((((((((MAJ3GATE-1K11(x1,y1,c1) be  non emptyXBOOLE-0V1 implies c2 be  non emptyXBOOLE-0V1) & (MAJ3GATE-1K11(x2,y2,c2) be  non emptyXBOOLE-0V1 implies c3 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x3,y3,c3) be  non emptyXBOOLE-0V1 implies c4 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1 implies c5 be  non emptyXBOOLE-0V1)) & (n1 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x1,y1) be  non emptyXBOOLE-0V1)) & (n2 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x2,y2) be  non emptyXBOOLE-0V1)) & (n3 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x3,y3) be  non emptyXBOOLE-0V1)) & (n4 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x4,y4) be  non emptyXBOOLE-0V1)) & (n be  non emptyXBOOLE-0V1 implies AND5GATE-1K18(c1,n1,n2,n3,n4) be  non emptyXBOOLE-0V1)) & (c5b be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1) implies (c5 be  non emptyXBOOLE-0V1 iff c5b be  non emptyXBOOLE-0V1)"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix c1 assume [ty]: "c1 be setHIDDENM2"
  fix x1 assume [ty]: "x1 be setHIDDENM2"
  fix x2 assume [ty]: "x2 be setHIDDENM2"
  fix x3 assume [ty]: "x3 be setHIDDENM2"
  fix x4 assume [ty]: "x4 be setHIDDENM2"
  fix y1 assume [ty]: "y1 be setHIDDENM2"
  fix y2 assume [ty]: "y2 be setHIDDENM2"
  fix y3 assume [ty]: "y3 be setHIDDENM2"
  fix y4 assume [ty]: "y4 be setHIDDENM2"
  fix c2 assume [ty]: "c2 be setHIDDENM2"
  fix c3 assume [ty]: "c3 be setHIDDENM2"
  fix c4 assume [ty]: "c4 be setHIDDENM2"
  fix c5 assume [ty]: "c5 be setHIDDENM2"
  fix n1 assume [ty]: "n1 be setHIDDENM2"
  fix n2 assume [ty]: "n2 be setHIDDENM2"
  fix n3 assume [ty]: "n3 be setHIDDENM2"
  fix n4 assume [ty]: "n4 be setHIDDENM2"
  fix n assume [ty]: "n be setHIDDENM2"
  fix c5b assume [ty]: "c5b be setHIDDENM2"
  show "(((((((((MAJ3GATE-1K11(x1,y1,c1) be  non emptyXBOOLE-0V1 implies c2 be  non emptyXBOOLE-0V1) & (MAJ3GATE-1K11(x2,y2,c2) be  non emptyXBOOLE-0V1 implies c3 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x3,y3,c3) be  non emptyXBOOLE-0V1 implies c4 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1 implies c5 be  non emptyXBOOLE-0V1)) & (n1 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x1,y1) be  non emptyXBOOLE-0V1)) & (n2 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x2,y2) be  non emptyXBOOLE-0V1)) & (n3 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x3,y3) be  non emptyXBOOLE-0V1)) & (n4 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x4,y4) be  non emptyXBOOLE-0V1)) & (n be  non emptyXBOOLE-0V1 implies AND5GATE-1K18(c1,n1,n2,n3,n4) be  non emptyXBOOLE-0V1)) & (c5b be  non emptyXBOOLE-0V1 iff OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1) implies (c5 be  non emptyXBOOLE-0V1 iff c5b be  non emptyXBOOLE-0V1)"
  proof-
    have "(((MAJ3GATE-1K11(x1,y1,c1) be  non emptyXBOOLE-0V1 implies c2 be  non emptyXBOOLE-0V1) & (MAJ3GATE-1K11(x2,y2,c2) be  non emptyXBOOLE-0V1 implies c3 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x3,y3,c3) be  non emptyXBOOLE-0V1 implies c4 be  non emptyXBOOLE-0V1)) & ((MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1 implies c5 be  non emptyXBOOLE-0V1) & ((n1 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x1,y1) be  non emptyXBOOLE-0V1) & ((n2 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x2,y2) be  non emptyXBOOLE-0V1) & ((n3 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x3,y3) be  non emptyXBOOLE-0V1) & ((n4 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x4,y4) be  non emptyXBOOLE-0V1) & ((n be  non emptyXBOOLE-0V1 implies AND5GATE-1K18(c1,n1,n2,n3,n4) be  non emptyXBOOLE-0V1) & ((c5b be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1) & (OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1 implies c5b be  non emptyXBOOLE-0V1)))))))) implies (c5 be  non emptyXBOOLE-0V1 implies c5b be  non emptyXBOOLE-0V1) & (c5b be  non emptyXBOOLE-0V1 implies  not c5 be emptyXBOOLE-0V1)"
    proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule impI)
      assume A1: "((MAJ3GATE-1K11(x1,y1,c1) be  non emptyXBOOLE-0V1 implies c2 be  non emptyXBOOLE-0V1) & (MAJ3GATE-1K11(x2,y2,c2) be  non emptyXBOOLE-0V1 implies c3 be  non emptyXBOOLE-0V1)) & (MAJ3GATE-1K11(x3,y3,c3) be  non emptyXBOOLE-0V1 implies c4 be  non emptyXBOOLE-0V1)"
        and A2: "MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1 implies c5 be  non emptyXBOOLE-0V1"
        and A3: "n1 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x1,y1) be  non emptyXBOOLE-0V1"
        and A4: "n2 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x2,y2) be  non emptyXBOOLE-0V1"
        and A5: "n3 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x3,y3) be  non emptyXBOOLE-0V1"
        and A6: "n4 be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(x4,y4) be  non emptyXBOOLE-0V1"
        and A7: "n be  non emptyXBOOLE-0V1 implies AND5GATE-1K18(c1,n1,n2,n3,n4) be  non emptyXBOOLE-0V1"
        and A8: "c5b be  non emptyXBOOLE-0V1 implies OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1"
        and A9: "OR2GATE-1K3(c5,n) be  non emptyXBOOLE-0V1 implies c5b be  non emptyXBOOLE-0V1"
      have A10: "n be  non emptyXBOOLE-0V1 implies MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1"
      proof(rule impI)
        assume A11: "n be  non emptyXBOOLE-0V1"
        then have A12: "c1 be  non emptyXBOOLE-0V1"
          using A7 gate_1_def_18 sorry
        have A13: "x3 be  non emptyXBOOLE-0V1 or y3 be  non emptyXBOOLE-0V1"
          using A5 A7 A11 gate_1_def_18 sorry
        have A14: "x2 be  non emptyXBOOLE-0V1 or y2 be  non emptyXBOOLE-0V1"
          using A4 A7 A11 gate_1_def_18 sorry
        have A15: "x4 be  non emptyXBOOLE-0V1 or y4 be  non emptyXBOOLE-0V1"
          using A6 A7 A11 gate_1_def_18 sorry
        have "x1 be  non emptyXBOOLE-0V1 or y1 be  non emptyXBOOLE-0V1"
          using A3 A7 A11 gate_1_def_18 sorry
        thus "MAJ3GATE-1K11(x4,y4,c4) be  non emptyXBOOLE-0V1"
          using A1 A12 A14 A13 A15 sorry
      qed
      show "c5 be  non emptyXBOOLE-0V1 implies c5b be  non emptyXBOOLE-0V1"
        using A9 sorry
      assume "c5b be  non emptyXBOOLE-0V1"
      thus " not c5 be emptyXBOOLE-0V1"
        using A2 A8 A10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef gate_1_def_34 ("MODADD2GATE-1K34'( _ , _ ')" [0,0]164 ) where
  mlet "a be setHIDDENM2", "b be setHIDDENM2"
"func MODADD2GATE-1K34(a,b) \<rightarrow> setHIDDENM2 equals
  NOT1GATE-1K1 {}XBOOLE-0K1 if (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) otherwise {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies NOT1GATE-1K1 {}XBOOLE-0K1 be setHIDDENM2) & ( not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)) implies {}XBOOLE-0K1 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem GATE_1K34_commutativity:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds MODADD2GATE-1K34(a,b) =HIDDENR1 MODADD2GATE-1K34(b,a)"
proof-
  have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds it =HIDDENR1 MODADD2GATE-1K34(a,b) implies it =HIDDENR1 MODADD2GATE-1K34(b,a)"
  proof-
    have " for it be setHIDDENM2 holds  for a be setHIDDENM2 holds  for b be setHIDDENM2 holds ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ((a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1) implies ((b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1) &  not (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1) implies it =HIDDENR1 NOT1GATE-1K1 {}XBOOLE-0K1) & ( not ((b be  non emptyXBOOLE-0V1 or a be  non emptyXBOOLE-0V1) &  not (b be  non emptyXBOOLE-0V1 & a be  non emptyXBOOLE-0V1)) implies it =HIDDENR1 {}XBOOLE-0K1)"
       sorry
    thus " ?thesis "
      using gate_1_def_34 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem gate_1_th_41:
" for a be setHIDDENM2 holds  for b be setHIDDENM2 holds MODADD2GATE-1K34(a,b) be  non emptyXBOOLE-0V1 iff (a be  non emptyXBOOLE-0V1 or b be  non emptyXBOOLE-0V1) &  not (a be  non emptyXBOOLE-0V1 & b be  non emptyXBOOLE-0V1)"
  using gate_1_def_34 sorry

abbreviation(input) GATE_1K35("ADD1GATE-1K35'( _ , _ , _ ')" [0,0,0]164) where
  "ADD1GATE-1K35(a,b,c) \<equiv> XOR3GATE-1K10(a,b,c)"

abbreviation(input) GATE_1K36("CARR1GATE-1K36'( _ , _ , _ ')" [0,0,0]164) where
  "CARR1GATE-1K36(a,b,c) \<equiv> MAJ3GATE-1K11(a,b,c)"

mdef gate_1_def_35 ("ADD2GATE-1K37'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "c be setHIDDENM2"
"func ADD2GATE-1K37(a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  XOR3GATE-1K10(a2,b2,CARR1GATE-1K36(a1,b1,c))"
proof-
  (*coherence*)
    show "XOR3GATE-1K10(a2,b2,CARR1GATE-1K36(a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mdef gate_1_def_36 ("CARR2GATE-1K38'( _ , _ , _ , _ , _ ')" [0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "c be setHIDDENM2"
"func CARR2GATE-1K38(a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  MAJ3GATE-1K11(a2,b2,CARR1GATE-1K36(a1,b1,c))"
proof-
  (*coherence*)
    show "MAJ3GATE-1K11(a2,b2,CARR1GATE-1K36(a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mdef gate_1_def_37 ("ADD3GATE-1K39'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "a3 be setHIDDENM2", "b3 be setHIDDENM2", "c be setHIDDENM2"
"func ADD3GATE-1K39(a3,b3,a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  XOR3GATE-1K10(a3,b3,CARR2GATE-1K38(a2,b2,a1,b1,c))"
proof-
  (*coherence*)
    show "XOR3GATE-1K10(a3,b3,CARR2GATE-1K38(a2,b2,a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mdef gate_1_def_38 ("CARR3GATE-1K40'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "a3 be setHIDDENM2", "b3 be setHIDDENM2", "c be setHIDDENM2"
"func CARR3GATE-1K40(a3,b3,a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  MAJ3GATE-1K11(a3,b3,CARR2GATE-1K38(a2,b2,a1,b1,c))"
proof-
  (*coherence*)
    show "MAJ3GATE-1K11(a3,b3,CARR2GATE-1K38(a2,b2,a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mdef gate_1_def_39 ("ADD4GATE-1K41'( _ , _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "a3 be setHIDDENM2", "b3 be setHIDDENM2", "a4 be setHIDDENM2", "b4 be setHIDDENM2", "c be setHIDDENM2"
"func ADD4GATE-1K41(a4,b4,a3,b3,a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  XOR3GATE-1K10(a4,b4,CARR3GATE-1K40(a3,b3,a2,b2,a1,b1,c))"
proof-
  (*coherence*)
    show "XOR3GATE-1K10(a4,b4,CARR3GATE-1K40(a3,b3,a2,b2,a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mdef gate_1_def_40 ("CARR4GATE-1K42'( _ , _ , _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0,0,0]164 ) where
  mlet "a1 be setHIDDENM2", "b1 be setHIDDENM2", "a2 be setHIDDENM2", "b2 be setHIDDENM2", "a3 be setHIDDENM2", "b3 be setHIDDENM2", "a4 be setHIDDENM2", "b4 be setHIDDENM2", "c be setHIDDENM2"
"func CARR4GATE-1K42(a4,b4,a3,b3,a2,b2,a1,b1,c) \<rightarrow> setHIDDENM2 equals
  MAJ3GATE-1K11(a4,b4,CARR3GATE-1K40(a3,b3,a2,b2,a1,b1,c))"
proof-
  (*coherence*)
    show "MAJ3GATE-1K11(a4,b4,CARR3GATE-1K40(a3,b3,a2,b2,a1,b1,c)) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem gate_1_th_42:
" for c1 be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for y3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for y4 be setHIDDENM2 holds  for c4 be setHIDDENM2 holds  for q1 be setHIDDENM2 holds  for p1 be setHIDDENM2 holds  for sd1 be setHIDDENM2 holds  for q2 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for sd2 be setHIDDENM2 holds  for q3 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds  for sd3 be setHIDDENM2 holds  for q4 be setHIDDENM2 holds  for p4 be setHIDDENM2 holds  for sd4 be setHIDDENM2 holds  for cb1 be setHIDDENM2 holds  for cb2 be setHIDDENM2 holds  for l2 be setHIDDENM2 holds  for t2 be setHIDDENM2 holds  for l3 be setHIDDENM2 holds  for m3 be setHIDDENM2 holds  for t3 be setHIDDENM2 holds  for l4 be setHIDDENM2 holds  for m4 be setHIDDENM2 holds  for n4 be setHIDDENM2 holds  for t4 be setHIDDENM2 holds  for l5 be setHIDDENM2 holds  for m5 be setHIDDENM2 holds  for n5 be setHIDDENM2 holds  for o5 be setHIDDENM2 holds  for s1 be setHIDDENM2 holds  for s2 be setHIDDENM2 holds  for s3 be setHIDDENM2 holds  for s4 be setHIDDENM2 holds (((((((((((((((((((((((((((((((q1 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x1,y1) be  non emptyXBOOLE-0V1) & (p1 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x1,y1) be  non emptyXBOOLE-0V1)) & (sd1 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x1,y1) be  non emptyXBOOLE-0V1)) & (q2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x2,y2) be  non emptyXBOOLE-0V1)) & (p2 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x2,y2) be  non emptyXBOOLE-0V1)) & (sd2 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x2,y2) be  non emptyXBOOLE-0V1)) & (q3 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x3,y3) be  non emptyXBOOLE-0V1)) & (p3 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x3,y3) be  non emptyXBOOLE-0V1)) & (sd3 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x3,y3) be  non emptyXBOOLE-0V1)) & (q4 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x4,y4) be  non emptyXBOOLE-0V1)) & (p4 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x4,y4) be  non emptyXBOOLE-0V1)) & (sd4 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x4,y4) be  non emptyXBOOLE-0V1)) & (cb1 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 c1 be  non emptyXBOOLE-0V1)) & (cb2 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 cb1 be  non emptyXBOOLE-0V1)) & (s1 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(cb2,sd1) be  non emptyXBOOLE-0V1)) & (l2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(cb1,p1) be  non emptyXBOOLE-0V1)) & (t2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(l2,q1) be  non emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t2,sd2) be  non emptyXBOOLE-0V1)) & (l3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q1,p2) be  non emptyXBOOLE-0V1)) & (m3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t3 be  non emptyXBOOLE-0V1 iff NOR3GATE-1K13(l3,m3,q2) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t3,sd3) be  non emptyXBOOLE-0V1)) & (l4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q2,p3) be  non emptyXBOOLE-0V1)) & (m4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q1,p3,p2) be  non emptyXBOOLE-0V1)) & (n4 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t4 be  non emptyXBOOLE-0V1 iff NOR4GATE-1K17(l4,m4,n4,q3) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t4,sd4) be  non emptyXBOOLE-0V1)) & (l5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q3,p4) be  non emptyXBOOLE-0V1)) & (m5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q2,p4,p3) be  non emptyXBOOLE-0V1)) & (n5 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(q1,p4,p3,p2) be  non emptyXBOOLE-0V1)) & (o5 be  non emptyXBOOLE-0V1 iff AND5GATE-1K18(p4,p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff NOR5GATE-1K21(q4,l5,m5,n5,o5) be  non emptyXBOOLE-0V1) implies ((((s1 be  non emptyXBOOLE-0V1 iff ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1) & (s2 be  non emptyXBOOLE-0V1 iff ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)"
proof-
  have " for c1 be setHIDDENM2 holds  for x1 be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds  for y3 be setHIDDENM2 holds  for x4 be setHIDDENM2 holds  for y4 be setHIDDENM2 holds  for c4 be setHIDDENM2 holds  for q1 be setHIDDENM2 holds  for p1 be setHIDDENM2 holds  for sd1 be setHIDDENM2 holds  for q2 be setHIDDENM2 holds  for p2 be setHIDDENM2 holds  for sd2 be setHIDDENM2 holds  for q3 be setHIDDENM2 holds  for p3 be setHIDDENM2 holds  for sd3 be setHIDDENM2 holds  for q4 be setHIDDENM2 holds  for p4 be setHIDDENM2 holds  for sd4 be setHIDDENM2 holds  for cb1 be setHIDDENM2 holds  for cb2 be setHIDDENM2 holds  for l2 be setHIDDENM2 holds  for t2 be setHIDDENM2 holds  for l3 be setHIDDENM2 holds  for m3 be setHIDDENM2 holds  for t3 be setHIDDENM2 holds  for l4 be setHIDDENM2 holds  for m4 be setHIDDENM2 holds  for n4 be setHIDDENM2 holds  for t4 be setHIDDENM2 holds  for l5 be setHIDDENM2 holds  for m5 be setHIDDENM2 holds  for n5 be setHIDDENM2 holds  for o5 be setHIDDENM2 holds  for s1 be setHIDDENM2 holds  for s2 be setHIDDENM2 holds  for s3 be setHIDDENM2 holds  for s4 be setHIDDENM2 holds (q1 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x1,y1) be  non emptyXBOOLE-0V1) & ((p1 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x1,y1) be  non emptyXBOOLE-0V1) & ((sd1 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x1,y1) be  non emptyXBOOLE-0V1) & (q2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x2,y2) be  non emptyXBOOLE-0V1))) implies ((((((((((((((((((((((((((((p2 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x2,y2) be  non emptyXBOOLE-0V1) & (sd2 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x2,y2) be  non emptyXBOOLE-0V1)) & (q3 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x3,y3) be  non emptyXBOOLE-0V1)) & (p3 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x3,y3) be  non emptyXBOOLE-0V1)) & (sd3 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x3,y3) be  non emptyXBOOLE-0V1)) & (q4 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x4,y4) be  non emptyXBOOLE-0V1)) & (p4 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x4,y4) be  non emptyXBOOLE-0V1)) & (sd4 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x4,y4) be  non emptyXBOOLE-0V1)) & (cb1 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 c1 be  non emptyXBOOLE-0V1)) & (cb2 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 cb1 be  non emptyXBOOLE-0V1)) & (s1 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(cb2,sd1) be  non emptyXBOOLE-0V1)) & (l2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(cb1,p1) be  non emptyXBOOLE-0V1)) & (t2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(l2,q1) be  non emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t2,sd2) be  non emptyXBOOLE-0V1)) & (l3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q1,p2) be  non emptyXBOOLE-0V1)) & (m3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t3 be  non emptyXBOOLE-0V1 iff NOR3GATE-1K13(l3,m3,q2) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t3,sd3) be  non emptyXBOOLE-0V1)) & (l4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q2,p3) be  non emptyXBOOLE-0V1)) & (m4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q1,p3,p2) be  non emptyXBOOLE-0V1)) & (n4 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t4 be  non emptyXBOOLE-0V1 iff NOR4GATE-1K17(l4,m4,n4,q3) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t4,sd4) be  non emptyXBOOLE-0V1)) & (l5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q3,p4) be  non emptyXBOOLE-0V1)) & (m5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q2,p4,p3) be  non emptyXBOOLE-0V1)) & (n5 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(q1,p4,p3,p2) be  non emptyXBOOLE-0V1)) & (o5 be  non emptyXBOOLE-0V1 iff AND5GATE-1K18(p4,p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff NOR5GATE-1K21(q4,l5,m5,n5,o5) be  non emptyXBOOLE-0V1) implies ((((s1 be  non emptyXBOOLE-0V1 iff ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1) & (s2 be  non emptyXBOOLE-0V1 iff ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix c1 assume [ty]: "c1 be setHIDDENM2"
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix y1 assume [ty]: "y1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix y2 assume [ty]: "y2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    fix y3 assume [ty]: "y3 be setHIDDENM2"
    fix x4 assume [ty]: "x4 be setHIDDENM2"
    fix y4 assume [ty]: "y4 be setHIDDENM2"
    fix c4 assume [ty]: "c4 be setHIDDENM2"
    fix q1 assume [ty]: "q1 be setHIDDENM2"
    fix p1 assume [ty]: "p1 be setHIDDENM2"
    fix sd1 assume [ty]: "sd1 be setHIDDENM2"
    fix q2 assume [ty]: "q2 be setHIDDENM2"
    fix p2 assume [ty]: "p2 be setHIDDENM2"
    fix sd2 assume [ty]: "sd2 be setHIDDENM2"
    fix q3 assume [ty]: "q3 be setHIDDENM2"
    fix p3 assume [ty]: "p3 be setHIDDENM2"
    fix sd3 assume [ty]: "sd3 be setHIDDENM2"
    fix q4 assume [ty]: "q4 be setHIDDENM2"
    fix p4 assume [ty]: "p4 be setHIDDENM2"
    fix sd4 assume [ty]: "sd4 be setHIDDENM2"
    fix cb1 assume [ty]: "cb1 be setHIDDENM2"
    fix cb2 assume [ty]: "cb2 be setHIDDENM2"
    fix l2 assume [ty]: "l2 be setHIDDENM2"
    fix t2 assume [ty]: "t2 be setHIDDENM2"
    fix l3 assume [ty]: "l3 be setHIDDENM2"
    fix m3 assume [ty]: "m3 be setHIDDENM2"
    fix t3 assume [ty]: "t3 be setHIDDENM2"
    fix l4 assume [ty]: "l4 be setHIDDENM2"
    fix m4 assume [ty]: "m4 be setHIDDENM2"
    fix n4 assume [ty]: "n4 be setHIDDENM2"
    fix t4 assume [ty]: "t4 be setHIDDENM2"
    fix l5 assume [ty]: "l5 be setHIDDENM2"
    fix m5 assume [ty]: "m5 be setHIDDENM2"
    fix n5 assume [ty]: "n5 be setHIDDENM2"
    fix o5 assume [ty]: "o5 be setHIDDENM2"
    fix s1 assume [ty]: "s1 be setHIDDENM2"
    fix s2 assume [ty]: "s2 be setHIDDENM2"
    fix s3 assume [ty]: "s3 be setHIDDENM2"
    fix s4 assume [ty]: "s4 be setHIDDENM2"
    assume A1: "q1 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x1,y1) be  non emptyXBOOLE-0V1"
      and A2: "p1 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x1,y1) be  non emptyXBOOLE-0V1"
      and A3: "sd1 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x1,y1) be  non emptyXBOOLE-0V1"
      and A4: "q2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x2,y2) be  non emptyXBOOLE-0V1"
    show "(((((((((((((((((((((((((((p2 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x2,y2) be  non emptyXBOOLE-0V1) & (sd2 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x2,y2) be  non emptyXBOOLE-0V1)) & (q3 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x3,y3) be  non emptyXBOOLE-0V1)) & (p3 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x3,y3) be  non emptyXBOOLE-0V1)) & (sd3 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x3,y3) be  non emptyXBOOLE-0V1)) & (q4 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x4,y4) be  non emptyXBOOLE-0V1)) & (p4 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x4,y4) be  non emptyXBOOLE-0V1)) & (sd4 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x4,y4) be  non emptyXBOOLE-0V1)) & (cb1 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 c1 be  non emptyXBOOLE-0V1)) & (cb2 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 cb1 be  non emptyXBOOLE-0V1)) & (s1 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(cb2,sd1) be  non emptyXBOOLE-0V1)) & (l2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(cb1,p1) be  non emptyXBOOLE-0V1)) & (t2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(l2,q1) be  non emptyXBOOLE-0V1)) & (s2 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t2,sd2) be  non emptyXBOOLE-0V1)) & (l3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q1,p2) be  non emptyXBOOLE-0V1)) & (m3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t3 be  non emptyXBOOLE-0V1 iff NOR3GATE-1K13(l3,m3,q2) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t3,sd3) be  non emptyXBOOLE-0V1)) & (l4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q2,p3) be  non emptyXBOOLE-0V1)) & (m4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q1,p3,p2) be  non emptyXBOOLE-0V1)) & (n4 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t4 be  non emptyXBOOLE-0V1 iff NOR4GATE-1K17(l4,m4,n4,q3) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t4,sd4) be  non emptyXBOOLE-0V1)) & (l5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q3,p4) be  non emptyXBOOLE-0V1)) & (m5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q2,p4,p3) be  non emptyXBOOLE-0V1)) & (n5 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(q1,p4,p3,p2) be  non emptyXBOOLE-0V1)) & (o5 be  non emptyXBOOLE-0V1 iff AND5GATE-1K18(p4,p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff NOR5GATE-1K21(q4,l5,m5,n5,o5) be  non emptyXBOOLE-0V1) implies ((((s1 be  non emptyXBOOLE-0V1 iff ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1) & (s2 be  non emptyXBOOLE-0V1 iff ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s3 be  non emptyXBOOLE-0V1 iff ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1)"
    proof-
      have "(p2 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x2,y2) be  non emptyXBOOLE-0V1) & ((sd2 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x2,y2) be  non emptyXBOOLE-0V1) & ((q3 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x3,y3) be  non emptyXBOOLE-0V1) & ((p3 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x3,y3) be  non emptyXBOOLE-0V1) & ((sd3 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x3,y3) be  non emptyXBOOLE-0V1) & ((q4 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x4,y4) be  non emptyXBOOLE-0V1) & ((p4 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x4,y4) be  non emptyXBOOLE-0V1) & ((sd4 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x4,y4) be  non emptyXBOOLE-0V1) & ((cb1 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 c1 be  non emptyXBOOLE-0V1) & (((cb2 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 cb1 be  non emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(cb2,sd1) be  non emptyXBOOLE-0V1)) & ((l2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(cb1,p1) be  non emptyXBOOLE-0V1) & (((t2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(l2,q1) be  non emptyXBOOLE-0V1) & (s2 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t2,sd2) be  non emptyXBOOLE-0V1)) & ((l3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q1,p2) be  non emptyXBOOLE-0V1) & ((m3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(p2,p1,cb1) be  non emptyXBOOLE-0V1) & (((t3 be  non emptyXBOOLE-0V1 iff NOR3GATE-1K13(l3,m3,q2) be  non emptyXBOOLE-0V1) & (s3 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t3,sd3) be  non emptyXBOOLE-0V1)) & ((l4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q2,p3) be  non emptyXBOOLE-0V1) & (((((m4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q1,p3,p2) be  non emptyXBOOLE-0V1) & (n4 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t4 be  non emptyXBOOLE-0V1 iff NOR4GATE-1K17(l4,m4,n4,q3) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t4,sd4) be  non emptyXBOOLE-0V1)) & ((l5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q3,p4) be  non emptyXBOOLE-0V1) & ((((m5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q2,p4,p3) be  non emptyXBOOLE-0V1) & (n5 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(q1,p4,p3,p2) be  non emptyXBOOLE-0V1)) & (o5 be  non emptyXBOOLE-0V1 iff AND5GATE-1K18(p4,p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (c4 be  non emptyXBOOLE-0V1 iff NOR5GATE-1K21(q4,l5,m5,n5,o5) be  non emptyXBOOLE-0V1))))))))))))))))))) implies (s1 be  non emptyXBOOLE-0V1 implies ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1) & ((ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1 implies s1 be  non emptyXBOOLE-0V1) & ((s2 be  non emptyXBOOLE-0V1 implies ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1) & ((ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s2 be  non emptyXBOOLE-0V1) & ((s3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1) & ((ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1) & ((s4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1) & ((ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s4 be  non emptyXBOOLE-0V1) & ((c4 be  non emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1) & (CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies (c4 be emptyXBOOLE-0V1 implies  not  True ))))))))))"
      proof(rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule impI,rule impI)
        assume A5: "p2 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x2,y2) be  non emptyXBOOLE-0V1"
          and A6: "sd2 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x2,y2) be  non emptyXBOOLE-0V1"
          and A7: "q3 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x3,y3) be  non emptyXBOOLE-0V1"
          and A8: "p3 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x3,y3) be  non emptyXBOOLE-0V1"
          and A9: "sd3 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x3,y3) be  non emptyXBOOLE-0V1"
          and A10: "q4 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(x4,y4) be  non emptyXBOOLE-0V1"
          and A11: "p4 be  non emptyXBOOLE-0V1 iff NAND2GATE-1K6(x4,y4) be  non emptyXBOOLE-0V1"
          and A12: "sd4 be  non emptyXBOOLE-0V1 iff MODADD2GATE-1K34(x4,y4) be  non emptyXBOOLE-0V1"
          and A13: "cb1 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 c1 be  non emptyXBOOLE-0V1"
          and A14: "(cb2 be  non emptyXBOOLE-0V1 iff NOT1GATE-1K1 cb1 be  non emptyXBOOLE-0V1) & (s1 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(cb2,sd1) be  non emptyXBOOLE-0V1)"
          and A15: "l2 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(cb1,p1) be  non emptyXBOOLE-0V1"
          and A16: "(t2 be  non emptyXBOOLE-0V1 iff NOR2GATE-1K7(l2,q1) be  non emptyXBOOLE-0V1) & (s2 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t2,sd2) be  non emptyXBOOLE-0V1)"
          and A17: "l3 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q1,p2) be  non emptyXBOOLE-0V1"
          and A18: "m3 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(p2,p1,cb1) be  non emptyXBOOLE-0V1"
          and A19: "(t3 be  non emptyXBOOLE-0V1 iff NOR3GATE-1K13(l3,m3,q2) be  non emptyXBOOLE-0V1) & (s3 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t3,sd3) be  non emptyXBOOLE-0V1)"
          and A20: "l4 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q2,p3) be  non emptyXBOOLE-0V1"
          and A21: "(((m4 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q1,p3,p2) be  non emptyXBOOLE-0V1) & (n4 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)) & (t4 be  non emptyXBOOLE-0V1 iff NOR4GATE-1K17(l4,m4,n4,q3) be  non emptyXBOOLE-0V1)) & (s4 be  non emptyXBOOLE-0V1 iff XOR2GATE-1K4(t4,sd4) be  non emptyXBOOLE-0V1)"
          and A22: "l5 be  non emptyXBOOLE-0V1 iff AND2GATE-1K2(q3,p4) be  non emptyXBOOLE-0V1"
          and A23: "((m5 be  non emptyXBOOLE-0V1 iff AND3GATE-1K8(q2,p4,p3) be  non emptyXBOOLE-0V1) & (n5 be  non emptyXBOOLE-0V1 iff AND4GATE-1K14(q1,p4,p3,p2) be  non emptyXBOOLE-0V1)) & (o5 be  non emptyXBOOLE-0V1 iff AND5GATE-1K18(p4,p3,p2,p1,cb1) be  non emptyXBOOLE-0V1)"
          and A24: "c4 be  non emptyXBOOLE-0V1 iff NOR5GATE-1K21(q4,l5,m5,n5,o5) be  non emptyXBOOLE-0V1"
        have A25: "p1 be  non emptyXBOOLE-0V1 iff  not (x1 be  non emptyXBOOLE-0V1 & y1 be  non emptyXBOOLE-0V1)"
          using A2 sorry
        have A26: "sd1 be  non emptyXBOOLE-0V1 iff (x1 be  non emptyXBOOLE-0V1 or y1 be  non emptyXBOOLE-0V1) &  not (x1 be  non emptyXBOOLE-0V1 & y1 be  non emptyXBOOLE-0V1)"
          using A3 gate_1_def_34 sorry
        show "s1 be  non emptyXBOOLE-0V1 implies ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A27: "s1 be  non emptyXBOOLE-0V1"
          show "ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
          proof-
            have cases: "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1 or c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1"
              using A13 A14 A27 sorry
            have case1: "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1 implies ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1"
              thus "ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A26 sorry
            qed
            have case2: "c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1 implies ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1"
              thus "ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A26 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        show "ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1 implies s1 be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A28: "ADD1GATE-1K35(x1,y1,c1) be  non emptyXBOOLE-0V1"
          show "s1 be  non emptyXBOOLE-0V1"
          proof-
            have cases: "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1 or c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1"
              using A26 A28 sorry
            have case1: "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1 implies s1 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "c1 be  non emptyXBOOLE-0V1 & sd1 be emptyXBOOLE-0V1"
              thus "s1 be  non emptyXBOOLE-0V1"
                using A13 A14 sorry
            qed
            have case2: "c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1 implies s1 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "c1 be emptyXBOOLE-0V1 & sd1 be  non emptyXBOOLE-0V1"
              thus "s1 be  non emptyXBOOLE-0V1"
                using A13 A14 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A29: "q1 be  non emptyXBOOLE-0V1 iff  not (x1 be  non emptyXBOOLE-0V1 or y1 be  non emptyXBOOLE-0V1)"
          using A1 sorry
        have A30: "sd2 be  non emptyXBOOLE-0V1 iff (x2 be  non emptyXBOOLE-0V1 or y2 be  non emptyXBOOLE-0V1) &  not (x2 be  non emptyXBOOLE-0V1 & y2 be  non emptyXBOOLE-0V1)"
          using A6 gate_1_def_34 sorry
        show "s2 be  non emptyXBOOLE-0V1 implies ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A31: "s2 be  non emptyXBOOLE-0V1"
          show "ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          proof-
            have cases: "((c1 be  non emptyXBOOLE-0V1 or p1 be emptyXBOOLE-0V1) & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1 or (c1 be emptyXBOOLE-0V1 & p1 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1"
              using A13 A15 A16 A31 sorry
            have case1: "((c1 be  non emptyXBOOLE-0V1 or p1 be emptyXBOOLE-0V1) & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1 implies ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "((c1 be  non emptyXBOOLE-0V1 or p1 be emptyXBOOLE-0V1) & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1"
              thus "ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A29 A25 A30 sorry
            qed
            have case2: "(c1 be emptyXBOOLE-0V1 & p1 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1 implies ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(c1 be emptyXBOOLE-0V1 & p1 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1"
              thus "ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A29 A25 A30 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A32: "cb1 be  non emptyXBOOLE-0V1 iff  not c1 be  non emptyXBOOLE-0V1"
          using A13 sorry
        show "ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s2 be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A33: "ADD2GATE-1K37(x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          show "s2 be  non emptyXBOOLE-0V1"
          proof-
            have cases: "(l2 be emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1 or (l2 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1"
              using A15 A29 A25 A30 A32 A33 sorry
            have case1: "(l2 be emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1 implies s2 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(l2 be emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & sd2 be emptyXBOOLE-0V1"
              thus "s2 be  non emptyXBOOLE-0V1"
                using A16 sorry
            qed
            have case2: "(l2 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1 implies s2 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(l2 be  non emptyXBOOLE-0V1 or q1 be  non emptyXBOOLE-0V1) & sd2 be  non emptyXBOOLE-0V1"
              thus "s2 be  non emptyXBOOLE-0V1"
                using A16 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A34: "q2 be  non emptyXBOOLE-0V1 iff  not (x2 be  non emptyXBOOLE-0V1 or y2 be  non emptyXBOOLE-0V1)"
          using A4 sorry
        have A35: "p2 be  non emptyXBOOLE-0V1 iff  not (x2 be  non emptyXBOOLE-0V1 & y2 be  non emptyXBOOLE-0V1)"
          using A5 sorry
        have A36: "sd3 be  non emptyXBOOLE-0V1 iff (x3 be  non emptyXBOOLE-0V1 or y3 be  non emptyXBOOLE-0V1) &  not (x3 be  non emptyXBOOLE-0V1 & y3 be  non emptyXBOOLE-0V1)"
          using A9 gate_1_def_34 sorry
        show "s3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A37: "s3 be  non emptyXBOOLE-0V1"
          show "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          proof-
            have cases: "((((((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1 or (((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1) or l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1) or m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1) or q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              using A9 A19 A37 gate_1_def_13 gate_1_def_34 sorry
            have case1: "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1"
              thus "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A17 A18 A29 A25 A34 A35 A32 sorry
            qed
            have case2: "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1"
              thus "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A17 A18 A29 A25 A34 A35 A32 sorry
            qed
            have case3: "l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume A38: "l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              then have A39: "x2 be emptyXBOOLE-0V1 or y2 be emptyXBOOLE-0V1"
                using A5 A17 sorry
              have "x1 be emptyXBOOLE-0V1 & y1 be emptyXBOOLE-0V1"
                using A1 A17 A38 sorry
              thus "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A36 A38 A39 sorry
            qed
            have case4: "m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume A40: "m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              then have "c1 be emptyXBOOLE-0V1"
                using A13 A18 sorry
              thus "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A18 A25 A35 A36 A40 sorry
            qed
            have case5: "q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              thus "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A34 A36 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 sorry
          qed
        qed
        show "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A41: "ADD3GATE-1K39(x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          show "s3 be  non emptyXBOOLE-0V1"
          proof-
            have cases: "((((((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1 or (((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1) or l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1) or m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1) or q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              using A17 A18 A29 A25 A34 A35 A36 A32 A41 sorry
            have case1: "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be emptyXBOOLE-0V1) & y3 be emptyXBOOLE-0V1"
              thus "s3 be  non emptyXBOOLE-0V1"
                using A9 A19 gate_1_def_13 gate_1_def_34 sorry
            qed
            have case2: "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((l3 be emptyXBOOLE-0V1 & m3 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1) & x3 be  non emptyXBOOLE-0V1) & y3 be  non emptyXBOOLE-0V1"
              thus "s3 be  non emptyXBOOLE-0V1"
                using A9 A19 gate_1_def_13 gate_1_def_34 sorry
            qed
            have case3: "l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "l3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              thus "s3 be  non emptyXBOOLE-0V1"
                using A19 gate_1_def_13 sorry
            qed
            have case4: "m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "m3 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              thus "s3 be  non emptyXBOOLE-0V1"
                using A19 gate_1_def_13 sorry
            qed
            have case5: "q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1 implies s3 be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "q2 be  non emptyXBOOLE-0V1 & sd3 be  non emptyXBOOLE-0V1"
              thus "s3 be  non emptyXBOOLE-0V1"
                using A19 gate_1_def_13 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 sorry
          qed
        qed
        have A42: "p3 be  non emptyXBOOLE-0V1 iff  not (x3 be  non emptyXBOOLE-0V1 & y3 be  non emptyXBOOLE-0V1)"
          using A8 sorry
        have A43: "sd4 be  non emptyXBOOLE-0V1 iff (x4 be  non emptyXBOOLE-0V1 or y4 be  non emptyXBOOLE-0V1) &  not (x4 be  non emptyXBOOLE-0V1 & y4 be  non emptyXBOOLE-0V1)"
          using A12 gate_1_def_34 sorry
        have A44: "q3 be  non emptyXBOOLE-0V1 iff  not (x3 be  non emptyXBOOLE-0V1 or y3 be  non emptyXBOOLE-0V1)"
          using A7 sorry
        show "s4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A45: "s4 be  non emptyXBOOLE-0V1"
          show "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          proof-
            have cases: "((((((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1 or l4 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1) or ((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1) or (((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1) or q3 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1"
              using A13 A21 A45 gate_1_def_14 gate_1_def_17 sorry
            have case1: "(((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1"
              thus "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A20 A29 A25 A34 A35 A44 A42 A43 sorry
            qed
            have case2: "l4 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "l4 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1"
              thus "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A20 A34 A42 A43 sorry
            qed
            have case3: "((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1"
              thus "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A29 A35 A42 A43 sorry
            qed
            have case4: "(((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1"
              thus "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A25 A35 A42 A43 sorry
            qed
            have case5: "q3 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1 implies ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "q3 be  non emptyXBOOLE-0V1 & sd4 be  non emptyXBOOLE-0V1"
              thus "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A44 A43 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 sorry
          qed
        qed
        show "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1 implies s4 be  non emptyXBOOLE-0V1"
        proof(rule impI)
          assume A46: "ADD4GATE-1K41(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          show "s4 be  non emptyXBOOLE-0V1"
          proof-
            have "s4 be emptyXBOOLE-0V1 implies  not  True "
            proof(rule impI)
              assume A47: "s4 be emptyXBOOLE-0V1"
              show " not  True "
              proof-
                have cases: "((((((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1 or l4 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1) or ((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1) or (((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1) or q3 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1"
                  using A13 A21 A47 gate_1_def_14 gate_1_def_17 sorry
                have case1: "(((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1 implies  not  True "
                proof(rule impI)
                  assume "(((l4 be emptyXBOOLE-0V1 & ((q1 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1)) & (((p3 be emptyXBOOLE-0V1 or p2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1) or c1 be  non emptyXBOOLE-0V1)) & q3 be emptyXBOOLE-0V1) & sd4 be  non emptyXBOOLE-0V1"
                  thus " not  True "
                    using A20 A29 A25 A34 A35 A44 A42 A43 A46 sorry
                qed
                have case2: "l4 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1 implies  not  True "
                proof(rule impI)
                  assume "l4 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1"
                  thus " not  True "
                    using A20 A34 A42 A43 A46 sorry
                qed
                have case3: "((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1 implies  not  True "
                proof(rule impI)
                  assume "((q1 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1"
                  thus " not  True "
                    using A29 A35 A42 A43 A46 sorry
                qed
                have case4: "(((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1 implies  not  True "
                proof(rule impI)
                  assume "(((p3 be  non emptyXBOOLE-0V1 & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1) & sd4 be emptyXBOOLE-0V1"
                  thus " not  True "
                    using A25 A35 A42 A43 A46 sorry
                qed
                have case5: "q3 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1 implies  not  True "
                proof(rule impI)
                  assume "q3 be  non emptyXBOOLE-0V1 & sd4 be emptyXBOOLE-0V1"
                  thus " not  True "
                    using A44 A43 A46 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 case4 case5 sorry
              qed
            qed
            thus " ?thesis "
               sorry
          qed
        qed
        have A48: "p4 be  non emptyXBOOLE-0V1 iff  not (x4 be  non emptyXBOOLE-0V1 & y4 be  non emptyXBOOLE-0V1)"
          using A11 sorry
        have A49: "q4 be  non emptyXBOOLE-0V1 iff  not (x4 be  non emptyXBOOLE-0V1 or y4 be  non emptyXBOOLE-0V1)"
          using A10 sorry
        have "q4 be emptyXBOOLE-0V1 & (l5 be emptyXBOOLE-0V1 & ((m5 be emptyXBOOLE-0V1 & n5 be emptyXBOOLE-0V1) & o5 be emptyXBOOLE-0V1)) implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
        proof(rule impMI ,rule impMI ,rule impI)
          assume A50: "q4 be emptyXBOOLE-0V1"
            and A51: "l5 be emptyXBOOLE-0V1"
            and A52: "(m5 be emptyXBOOLE-0V1 & n5 be emptyXBOOLE-0V1) & o5 be emptyXBOOLE-0V1"
          show "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          proof-
            have cases: "(((p4 be emptyXBOOLE-0V1 or p3 be emptyXBOOLE-0V1) or p2 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1) or p1 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1) or (c1 be  non emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1"
              using A13 A23 A52 gate_1_def_14 gate_1_def_18 sorry
            have case1: "p4 be emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "p4 be emptyXBOOLE-0V1"
              thus "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A48 sorry
            qed
            have case2: "p3 be emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "p3 be emptyXBOOLE-0V1"
              thus "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A42 A49 A50 sorry
            qed
            have case3: "p2 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "p2 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1"
              thus "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A22 A35 A44 A49 A48 A50 A51 sorry
            qed
            have case4: "p1 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "p1 be emptyXBOOLE-0V1 & q2 be emptyXBOOLE-0V1"
              thus "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A22 A25 A34 A44 A49 A48 A50 A51 sorry
            qed
            have case5: "(c1 be  non emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
            proof(rule impI)
              assume "(c1 be  non emptyXBOOLE-0V1 & q1 be emptyXBOOLE-0V1) & q2 be emptyXBOOLE-0V1"
              thus "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
                using A22 A29 A34 A44 A49 A48 A50 A51 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 case5 sorry
          qed
        qed
        thus "c4 be  non emptyXBOOLE-0V1 implies CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
          using A24 gate_1_def_21 sorry
        assume A53: "CARR4GATE-1K42(x4,y4,x3,y3,x2,y2,x1,y1,c1) be  non emptyXBOOLE-0V1"
        assume A54: "c4 be emptyXBOOLE-0V1"
        show " not  True "
        proof-
          have cases: "(((q4 be  non emptyXBOOLE-0V1 or q3 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) or (q2 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1) or ((q1 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) or (((p4 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1"
            using A13 A22 A23 A24 A54 gate_1_def_14 gate_1_def_18 gate_1_def_21 sorry
          have case1: "q4 be  non emptyXBOOLE-0V1 implies  not  True "
          proof(rule impI)
            assume "q4 be  non emptyXBOOLE-0V1"
            thus " not  True "
              using A49 A53 sorry
          qed
          have case2: "q3 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1 implies  not  True "
          proof(rule impI)
            assume "q3 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1"
            thus " not  True "
              using A44 A48 A53 sorry
          qed
          have case3: "(q2 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1 implies  not  True "
          proof(rule impI)
            assume "(q2 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1"
            thus " not  True "
              using A34 A42 A48 A53 sorry
          qed
          have case4: "((q1 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1 implies  not  True "
          proof(rule impI)
            assume "((q1 be  non emptyXBOOLE-0V1 & p4 be  non emptyXBOOLE-0V1) & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1"
            thus " not  True "
              using A29 A35 A42 A48 A53 sorry
          qed
          have case5: "(((p4 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1 implies  not  True "
          proof(rule impI)
            assume "(((p4 be  non emptyXBOOLE-0V1 & p3 be  non emptyXBOOLE-0V1) & p2 be  non emptyXBOOLE-0V1) & p1 be  non emptyXBOOLE-0V1) & c1 be emptyXBOOLE-0V1"
            thus " not  True "
              using A25 A35 A42 A48 A53 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 case5 sorry
        qed
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
