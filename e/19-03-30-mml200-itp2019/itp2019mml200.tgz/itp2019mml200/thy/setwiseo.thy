theory setwiseo
  imports finsub_1
begin
(*begin*)
reserve x, y, z, X, Y for "setHIDDENM2"
mtheorem setwiseo_th_1:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds {TARSKIK1 x} c=TARSKIR1 {ENUMSET1K1 x,y,z }"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds {TARSKIK1 x} c=TARSKIR1 {ENUMSET1K1 x,y,z }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    have "{ENUMSET1K1 x,y,z } =XBOOLE-0R4 {TARSKIK1 x} \\/XBOOLE-0K2 {TARSKIK2 y,z }"
      using enumset1_th_2 sorry
    thus "{TARSKIK1 x} c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      using xboole_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_2:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds {TARSKIK2 x,y } c=TARSKIR1 {ENUMSET1K1 x,y,z }"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds {TARSKIK2 x,y } c=TARSKIR1 {ENUMSET1K1 x,y,z }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix z assume [ty]: "z be setHIDDENM2"
    have "{ENUMSET1K1 x,y,z } =XBOOLE-0R4 {TARSKIK2 x,y } \\/XBOOLE-0K2 {TARSKIK1 z}"
      using enumset1_th_3 sorry
    thus "{TARSKIK2 x,y } c=TARSKIR1 {ENUMSET1K1 x,y,z }"
      using xboole_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT 3*)
mtheorem setwiseo_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 f .:FUNCT-1K5 Y \\SUBSET-1K6 X"
proof(rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have " for x be objectHIDDENM1 holds (x inHIDDENR3 f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X) implies x inHIDDENR3 f .:FUNCT-1K5 Y \\SUBSET-1K6 X) & (x inHIDDENR3 f .:FUNCT-1K5 Y \\SUBSET-1K6 X implies x inHIDDENR3 f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X))"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x inHIDDENR3 f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X) implies x inHIDDENR3 f .:FUNCT-1K5 Y \\SUBSET-1K6 X"
    proof(rule impI)
      assume "x inHIDDENR3 f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X)"
      then obtain z where
        [ty]:"z be objectHIDDENM1" and 
        A1: "z inHIDDENR3 domRELAT-1K1 f"and A2: "z inHIDDENR3 Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X"and A3: "f .FUNCT-1K1 z =HIDDENR1 x"
        using funct_1_def_6 sorry
      have " not z inHIDDENR3 f \<inverse>FUNCT-1K6 X"
        using A2 xboole_0_def_5 sorry
      then have A4: " not x inHIDDENR3 X"
        using A1 A3 funct_1_def_7 sorry
      have "f .FUNCT-1K1 z inTARSKIR2 f .:FUNCT-1K5 Y"
        using A1 A2 funct_1_def_6 sorry
      thus "x inHIDDENR3 f .:FUNCT-1K5 Y \\SUBSET-1K6 X"
        using A3 A4 xboole_0_def_5 sorry
    qed
    assume A5: "x inHIDDENR3 f .:FUNCT-1K5 Y \\SUBSET-1K6 X"
    then obtain z where
      [ty]:"z be objectHIDDENM1" and 
      A6: "z inHIDDENR3 domRELAT-1K1 f"and A7: "z inHIDDENR3 Y"and A8: "f .FUNCT-1K1 z =HIDDENR1 x"
      using funct_1_def_6 sorry
    have " not x inHIDDENR3 X"
      using A5 xboole_0_def_5 sorry
    then have " not z inHIDDENR3 f \<inverse>FUNCT-1K6 X"
      using A8 funct_1_def_7 sorry
    then have "z inHIDDENR3 Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X"
      using A7 xboole_0_def_5 sorry
    thus "x inHIDDENR3 f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X)"
      using A6 A8 funct_1_def_6 sorry
  qed "sorry"
  thus "f .:FUNCT-1K5 (Y \\SUBSET-1K6 f \<inverse>FUNCT-1K6 X) =XBOOLE-0R4 f .:FUNCT-1K5 Y \\SUBSET-1K6 X"
    using tarski_th_2 sorry
qed "sorry"

reserve X, Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve f for "FunctionFUNCT-2M1-of(X,Y)"
mtheorem setwiseo_th_7:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
      using tarski_def_1 sorry
    thus "x inTARSKIR2 f \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
      using funct_2_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_8:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for x be ElementSUBSET-1M1-of X holds ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x} iff y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
    proof-
      have " for y be objectHIDDENM1 holds (y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x} implies y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) &  not (y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x &  not y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x})"
      proof(rule ballI,rule conjMI)
        fix y assume [ty]: "y be objectHIDDENM1"
        show "y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x} implies y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
        proof(rule impI)
          assume "y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x}"
          then have " ex z be objectHIDDENM1 st (z inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f & z inHIDDENR3 {TARSKIK1 x}) & f .FUNCT-1K1 z =HIDDENR1 y"
            using funct_1_def_6 sorry
          thus "y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
            using tarski_def_1 sorry
        qed
        have "x inTARSKIR2 {TARSKIK1 x}"
          using tarski_def_1 sorry
        thus " not (y =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x &  not y inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x})"
          using funct_2_th_35 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ImRELAT-1K12(f,x) =XBOOLE-0R4 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_9:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be setHIDDENM2 holds x inTARSKIR2 B implies x be ElementSUBSET-1M1-of X"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be setHIDDENM2 holds x inTARSKIR2 B implies x be ElementSUBSET-1M1-of X"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have A1: "B c=TARSKIR1 X"
      using finsub_1_def_5 sorry
    fix x assume [ty]: "x be setHIDDENM2"
    assume "x inTARSKIR2 B"
    thus "x be ElementSUBSET-1M1-of X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_10:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 A implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 B) implies f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A c=TARSKIR1 B"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 A implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 B) implies f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A c=TARSKIR1 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B assume [ty]: "B be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: " for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 A implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 B"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A implies x inHIDDENR3 B"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
      then obtain y where
        [ty]:"y be objectHIDDENM1" and 
        "y inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> f"and A2: "y inHIDDENR3 A"and A3: "x =HIDDENR1 f .FUNCT-1K1 y"
        using funct_1_def_6 sorry
      have 
        [ty]:"y be ElementSUBSET-1M1-of X"
        using A2 setwiseo_th_9 sorry
      have "x =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> y"
        using A3 sorry
      thus "x inHIDDENR3 B"
        using A1 A2 sorry
    qed "sorry"
    thus "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A c=TARSKIR1 B"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_11:
" for X be setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for A be setHIDDENM2 holds A c=TARSKIR1 B implies A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
  fix A assume [ty]: "A be setHIDDENM2"
  assume A1: "A c=TARSKIR1 B"
  have "B c=TARSKIR1 X"
    using finsub_1_def_5 sorry
  then have "A c=TARSKIR1 X"
    using A1 sorry
  thus "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    using A1 finsub_1_def_5 sorry
qed "sorry"

mlemma setwiseo_lm_1:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
  using finsub_1_def_5 sorry

mtheorem setwiseo_th_12:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be ElementSUBSET-1M1-of X st x inTARSKIR2 B)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( ex tVar1 be ElementSUBSET-1M1-of X st tVar1 inTARSKIR2 B)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    let ?x = "the ElementSUBSET-1M1-of B"
    assume A1: "B <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of X" and xDef:"x = ?x"
      using setwiseo_th_9 sorry
    show " ex tVar1 be ElementSUBSET-1M1-of X st tVar1 inTARSKIR2 B"
    proof(rule bexI[of _ "x"])
      show "x inTARSKIR2 B"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_13:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 implies A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1 implies (A <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A1: "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1"
    assume "A <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where
      [ty]:"x be ElementSUBSET-1M1-of X" and 
      A2: "x inTARSKIR2 A"
      using setwiseo_th_12 sorry
    have "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
      using A2 funct_2_th_35 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_cl_1:
  mlet "X be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of FinFINSUB-1K5 X st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        using finsub_1_th_7 sorry
      thus " not ( for VarFor1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef setwiseo_def_1 ("{}.SETWISEOK1  _ " [250]250 ) where
  mlet "X be setHIDDENM2"
"func {}.SETWISEOK1 X \<rightarrow> emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X equals
  {}XBOOLE-0K1"
proof-
  (*coherence*)
    show "{}XBOOLE-0K1 be emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
      using finsub_1_th_7 sorry
qed "sorry"

theorem setwiseo_sch_1:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0"
  shows " ex f be FunctionFUNCT-2M1-of(Af0,FinFINSUB-1K5 Af0) st  for b be ElementSUBSET-1M1-of Af0 holds  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 f .FUNCT-2K3\<^bsub>(Af0,FinFINSUB-1K5 Af0)\<^esub> b iff a inTARSKIR2 Bf0 & Pp2(a,b)"
  proof-
    have " ex f be FunctionFUNCT-2M1-of(Af0,FinFINSUB-1K5 Af0) st  for x be ElementSUBSET-1M1-of Af0 holds  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 f .FUNCT-2K3\<^bsub>(Af0,FinFINSUB-1K5 Af0)\<^esub> x iff a inTARSKIR2 Bf0 & Pp2(a,x)"
    proof-
      let ?X = "\<lambda>Lamb1. \<lambda>Lamb2.  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 Lamb2 iff a inTARSKIR2 Bf0 & Pp2(a,Lamb1)"
      have A1: " for x be ElementSUBSET-1M1-of Af0 holds  ex y9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 st  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 y9 iff a inTARSKIR2 Bf0 & Pp2(a,x)"
      proof(rule ballI)
        obtain B where 
          [ty]:"B be SubsetSUBSET-1M2-of Af0" and BDef:"B = Bf0"
          using finsub_1_def_5 sorry
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Af0"
        let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 Bf0 & Pp2(Lamb1,x)"
        obtain y where
          [ty]:"y be SubsetSUBSET-1M2-of Af0" and 
          A2: " for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 y iff ?X(a)"
          using subset_1_sch_3 sorry
        have " for x be ElementSUBSET-1M1-of Af0 holds x inTARSKIR2 y implies x inTARSKIR2 B"
          using A2 sorry
        then have "y c=TARSKIR1 Bf0"
           sorry
        then have 
          [ty]:"y be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0"
          using finsub_1_def_5 sorry
        obtain y9 where 
          [ty]:"y9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0" and y9Def:"y9 = y"
           sorry
        show " ex y9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Af0 st  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 y9 iff a inTARSKIR2 Bf0 & Pp2(a,x)"
        proof(rule bexI[of _ "y9"])
          show " for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 y9 iff a inTARSKIR2 Bf0 & Pp2(a,x)"
            using A2 sorry
        qed "sorry"
      qed "sorry"
      show " ex f be FunctionFUNCT-2M1-of(Af0,FinFINSUB-1K5 Af0) st  for x be ElementSUBSET-1M1-of Af0 holds  for a be ElementSUBSET-1M1-of Af0 holds a inTARSKIR2 f .FUNCT-2K3\<^bsub>(Af0,FinFINSUB-1K5 Af0)\<^esub> x iff a inTARSKIR2 Bf0 & Pp2(a,x)"
        using funct_2_sch_3 A1 sorry
    qed
    thus " ?thesis "
       sorry
  qed

mdef setwiseo_def_2 ("having-a-unitySETWISEOV1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"attr having-a-unitySETWISEOV1\<^bsub>(X)\<^esub> for BinOpBINOP-1M2-of X means
  (\<lambda>F.  ex x be ElementSUBSET-1M1-of X st x is-a-unity-wrtBINOP-1R3\<^bsub>(X)\<^esub> F)"..

mtheorem setwiseo_th_14:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds F be having-a-unitySETWISEOV1\<^bsub>(X)\<^esub> iff the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F is-a-unity-wrtBINOP-1R3\<^bsub>(X)\<^esub> F"
  using binop_1_def_8 sorry

mtheorem setwiseo_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of X holds F be having-a-unitySETWISEOV1\<^bsub>(X)\<^esub> implies ( for x be ElementSUBSET-1M1-of X holds F .BINOP-1K4\<^bsub>(X)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F,x) =XBOOLE-0R4 x & F .BINOP-1K4\<^bsub>(X)\<^esub>(x,the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F) =XBOOLE-0R4 x)"
proof(rule ballI,rule ballI,rule impI,rule ballI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be BinOpBINOP-1M2-of X"
  assume "F be having-a-unitySETWISEOV1\<^bsub>(X)\<^esub>"
  then have A1: "the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F is-a-unity-wrtBINOP-1R3\<^bsub>(X)\<^esub> F"
    using setwiseo_th_14 sorry
  fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
  show "F .BINOP-1K4\<^bsub>(X)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F,x) =XBOOLE-0R4 x & F .BINOP-1K4\<^bsub>(X)\<^esub>(x,the-unity-wrtBINOP-1K3\<^bsub>(X)\<^esub> F) =XBOOLE-0R4 x"
    using A1 binop_1_th_3 sorry
qed "sorry"

mtheorem setwiseo_cl_2:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of FinFINSUB-1K5 X st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      let ?x = "the ElementSUBSET-1M1-of X"
      have "{TARSKIK1 ?x} be SubsetSUBSET-1M2-of X"
        using subset_1_th_41 sorry
      then have "{TARSKIK1 ?x} be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        using finsub_1_def_5 sorry
      thus " not ( for VarFor1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax SETWISEOK2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK2\<^bsub>'( _ ')\<^esub>  _ .}" [0,0]164)
translations "{.SETWISEOK2\<^bsub>(X)\<^esub> x.}" \<rightharpoonup> "{TARSKIK1 x}"

syntax SETWISEOK3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK3\<^bsub>'( _ ')\<^esub> _ , _ .}" [0,0,0]164)
translations "{.SETWISEOK3\<^bsub>(X)\<^esub> x,y .}" \<rightharpoonup> "{TARSKIK2 x,y }"

syntax SETWISEOK4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK4\<^bsub>'( _ ')\<^esub> _ , _ , _ .}" [0,0,0,0]164)
translations "{.SETWISEOK4\<^bsub>(X)\<^esub> x,y,z .}" \<rightharpoonup> "{ENUMSET1K1 x,y,z }"

syntax SETWISEOK5 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK5\<^bsub>'( _ ')\<^esub>  _ .}" [0,0]164)
translations "{.SETWISEOK5\<^bsub>(X)\<^esub> x.}" \<rightharpoonup> "{TARSKIK1 x}"

mtheorem setwiseo_add_1:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of X"
"cluster {TARSKIK1 x} as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*coherence*)
  show "{TARSKIK1 x} be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
  proof-
    have "{TARSKIK1 x} be SubsetSUBSET-1M2-of X"
      using subset_1_th_41 sorry
    thus "{TARSKIK1 x} be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
      using finsub_1_def_5 sorry
  qed
qed "sorry"

syntax SETWISEOK6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK6\<^bsub>'( _ ')\<^esub> _ , _ .}" [0,0,0]164)
translations "{.SETWISEOK6\<^bsub>(X)\<^esub> x,y .}" \<rightharpoonup> "{TARSKIK2 x,y }"

mtheorem setwiseo_add_2:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of X", "y be ElementSUBSET-1M1-of X"
"cluster {TARSKIK2 x,y } as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*coherence*)
  show "{TARSKIK2 x,y } be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
  proof-
    have "{TARSKIK2 x,y } be SubsetSUBSET-1M2-of X"
      using subset_1_th_34 sorry
    thus "{TARSKIK2 x,y } be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
      using finsub_1_def_5 sorry
  qed
qed "sorry"

syntax SETWISEOK7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("{.SETWISEOK7\<^bsub>'( _ ')\<^esub> _ , _ , _ .}" [0,0,0,0]164)
translations "{.SETWISEOK7\<^bsub>(X)\<^esub> x,y,z .}" \<rightharpoonup> "{ENUMSET1K1 x,y,z }"

mtheorem setwiseo_add_3:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of X", "y be ElementSUBSET-1M1-of X", "z be ElementSUBSET-1M1-of X"
"cluster {ENUMSET1K1 x,y,z } as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*coherence*)
  show "{ENUMSET1K1 x,y,z } be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
  proof-
    have "{ENUMSET1K1 x,y,z } be SubsetSUBSET-1M2-of X"
      using subset_1_th_35 sorry
    thus "{ENUMSET1K1 x,y,z } be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
      using finsub_1_def_5 sorry
  qed
qed "sorry"

syntax SETWISEOK8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\'/SETWISEOK8\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "A \\/SETWISEOK8\<^bsub>(X)\<^esub> B" \<rightharpoonup> "A \\/XBOOLE-0K2 B"

mtheorem setwiseo_add_4:
  mlet "X be setHIDDENM2", "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X", "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
"cluster A \\/XBOOLE-0K2 B as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*coherence*)
  show "A \\/XBOOLE-0K2 B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    using finsub_1_th_1 sorry
qed "sorry"

syntax SETWISEOK9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '\\SETWISEOK9\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132)
translations "A \\SETWISEOK9\<^bsub>(X)\<^esub> B" \<rightharpoonup> "A \\XBOOLE-0K4 B"

mtheorem setwiseo_add_5:
  mlet "X be setHIDDENM2", "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X", "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
"cluster A \\XBOOLE-0K4 B as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 X"
proof
(*coherence*)
  show "A \\XBOOLE-0K4 B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    using finsub_1_th_1 sorry
qed "sorry"

theorem setwiseo_sch_2:
  fixes Xf0 Pp1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: "Pp1({}.SETWISEOK1 Xf0)" and
   A2: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds  for b be ElementSUBSET-1M1-of Xf0 holds Pp1(B9) &  not b inTARSKIR2 B9 implies Pp1(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
  shows " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds Pp1(B)"
  proof(rule ballI)
    let ?X = "\<lambda>Lamb1.  ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 Lamb1 & Pp1(B9)"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0"
    have A3: " for x be setHIDDENM2 holds  for A be setHIDDENM2 holds (x inTARSKIR2 B & A c=TARSKIR1 B) & ?X(A) implies ?X(A \\/XBOOLE-0K2 {TARSKIK1 x})"
    proof-
      have " for x be setHIDDENM2 holds  for A be setHIDDENM2 holds x inTARSKIR2 B & (A c=TARSKIR1 B & ( ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 A & Pp1(B9))) implies ( ex Ax be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st Ax =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x} & Pp1(Ax))"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix A assume [ty]: "A be setHIDDENM2"
        assume A4: "x inTARSKIR2 B"
          and A5: "A c=TARSKIR1 B"
          and A6: " ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 A & Pp1(B9)"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of Xf0" and x9Def:"x9 = x"
          using A4 setwiseo_th_9 sorry
        obtain A9 where 
          [ty]:"A9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0" and A9Def:"A9 = A"
          using A5 setwiseo_th_11 sorry
        obtain Ax where 
          [ty]:"Ax be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0" and AxDef:"Ax = A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.}"
           sorry
        show " ex Ax be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st Ax =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x} & Pp1(Ax)"
        proof(rule bexI[of _ "Ax"],rule conjMI)
          show "Ax =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x}"
             sorry
          show "Pp1(Ax)"
            using A2 A6 zfmisc_1_th_40 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "B be finiteFINSET-1V1"
       sorry
    have A8: "?X({}XBOOLE-0K1)"
      using A1 sorry
    have "?X(B)"
      using finset_1_sch_2 A7 A8 A3 sorry
    thus "Pp1(B)"
       sorry
  qed "sorry"

theorem setwiseo_sch_3:
  fixes Xf0 Pp1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds Pp1({.SETWISEOK5\<^bsub>(Xf0)\<^esub> x.})" and
   A2: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds Pp1(B1) & Pp1(B2) implies Pp1(B1 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> B2)"
  shows " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds Pp1(B)"
  proof(rule ballI)
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies ( ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 Lamb1 & Pp1(B9))"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0"
    have A3: " for x be setHIDDENM2 holds  for A be setHIDDENM2 holds (x inTARSKIR2 B & A c=TARSKIR1 B) & ?X(A) implies ?X(A \\/XBOOLE-0K2 {TARSKIK1 x})"
    proof-
      have " for x be setHIDDENM2 holds  for A be setHIDDENM2 holds x inTARSKIR2 B & (A c=TARSKIR1 B & ((A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 A & Pp1(B9))) & A \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1)) implies ( ex tVar4 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st tVar4 =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x} & Pp1(tVar4))"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        fix A assume [ty]: "A be setHIDDENM2"
        assume A4: "x inTARSKIR2 B"
          and A5: "A c=TARSKIR1 B"
          and A6: "A <>HIDDENR2 {}XBOOLE-0K1 implies ( ex B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st B9 =XBOOLE-0R4 A & Pp1(B9))"
          and "A \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
        obtain x9 where 
          [ty]:"x9 be ElementSUBSET-1M1-of Xf0" and x9Def:"x9 = x"
          using A4 setwiseo_th_9 sorry
        obtain A9 where 
          [ty]:"A9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0" and A9Def:"A9 = A"
          using A5 setwiseo_th_11 sorry
        show " ex tVar4 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 st tVar4 =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x} & Pp1(tVar4)"
        proof(rule bexI[of _ "A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.}"],rule conjMI)
          show "A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.} =XBOOLE-0R4 A \\/XBOOLE-0K2 {TARSKIK1 x}"
             sorry
          have A7: "Pp1({.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
            using A1 sorry
          show "Pp1(A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
          proof-
            have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies Pp1(A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
            proof(rule impI)
              assume "A =XBOOLE-0R4 {}XBOOLE-0K1"
              thus "Pp1(A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
                using A1 sorry
            qed
            have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies Pp1(A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
            proof(rule impI)
              assume "A <>HIDDENR2 {}XBOOLE-0K1"
              thus "Pp1(A9 \\/SETWISEOK8\<^bsub>(Xf0)\<^esub> {.SETWISEOK5\<^bsub>(Xf0)\<^esub> x9.})"
                using A2 A6 A7 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "?X({}XBOOLE-0K1)"
       sorry
    have A9: "B be finiteFINSET-1V1"
       sorry
    have "?X(B)"
      using finset_1_sch_2 A9 A8 A3 sorry
    thus "Pp1(B)"
       sorry
  qed "sorry"

theorem setwiseo_sch_4:
  fixes Xf0 Pp1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: "Pp1({}.SETWISEOK1 Xf0)" and
   A2: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds  for b be ElementSUBSET-1M1-of Xf0 holds Pp1(B9) implies Pp1(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
  shows " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds Pp1(B)"
  proof-
    have A3: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds  for b be ElementSUBSET-1M1-of Xf0 holds Pp1(B9) &  not b inTARSKIR2 B9 implies Pp1(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
      using A2 sorry
    have A4: "Pp1({}.SETWISEOK1 Xf0)"
      using A1 sorry
    show " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 Xf0 holds Pp1(B)"
      using setwiseo_sch_2 A4 A3 sorry
  qed

mdef setwiseo_def_3 (" _ $$SETWISEOK10\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [180,0,0,0,0]180 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be BinOpBINOP-1M2-of Y", "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X", "f be FunctionFUNCT-2M1-of(X,Y)"
"assume (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) func F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) \<rightarrow> ElementSUBSET-1M1-of Y means
  \<lambda>it.  ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
proof-
  (*existence*)
    show "(B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) implies ( ex it be ElementSUBSET-1M1-of Y st  ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))"
    proof(rule impI)
      assume Assume: "(B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>)"
      have A1: "B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
        using Assume sorry
      have A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>"
        using Assume sorry
      have A3: "F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of Y st  ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
      proof-
        have " ex tVar11 be ElementSUBSET-1M1-of Y st  ex tVar12 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B =XBOOLE-0R4 tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not tVar12 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds tVar12 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 &  not tVar12 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))"
        proof-
          let ?X = "\<lambda>Lamb1.  ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st (( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 Lamb1 & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 Lamb1 \\SUBSET-1K6 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
          have A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
          proof-
            have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be ElementSUBSET-1M1-of X holds ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st (( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies ( not x inTARSKIR2 B implies ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st (( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x9 be ElementSUBSET-1M1-of X holds x9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x9}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)))))"
            proof(rule ballI,rule ballI,rule impI,rule impI)
              fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
              fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
              assume Given: " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st (( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
              then obtain G where
                [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
                A5: " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A6: " for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A7: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
                 sorry
              assume A8: " not x inTARSKIR2 B"
              show " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st (( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x9 be ElementSUBSET-1M1-of X holds x9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x9}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)))"
              proof-
                have " ex J be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies J .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & (( for x be ElementSUBSET-1M1-of X holds J .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x9 be ElementSUBSET-1M1-of X holds x9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 B9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9))))"
                proof-
                  let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & Lamb1 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies Lamb2 =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & Lamb1 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies Lamb2 =XBOOLE-0R4 G .FUNCT-1K1 Lamb1)"
                  have A9: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  ex y be ElementSUBSET-1M1-of Y st ( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)"
                  proof(rule ballI)
                    fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
                    show " ex y be ElementSUBSET-1M1-of Y st ( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)"
                    proof-
                      have " not ( for y be ElementSUBSET-1M1-of Y holds  not (( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)))"
                      proof-
                        have A10: "( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies ( ex y be ElementSUBSET-1M1-of Y st  not ( for y be ElementSUBSET-1M1-of Y holds  not (( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9))))"
                        proof(rule impI)
                          assume Given: " ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                          then obtain C where
                            [ty]:"C be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and 
                            A11: "C <>HIDDENR2 {}XBOOLE-0K1"and A12: "C c=TARSKIR1 B"and A13: "B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                             sorry
                          obtain y where 
                            [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                             sorry
                          show " ex y be ElementSUBSET-1M1-of Y st  not ( for y be ElementSUBSET-1M1-of Y holds  not (( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)))"
                          proof(rule bexI[of _ "y"])
                            have " for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                            proof-
                              have " for C1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds C1 <>HIDDENR2 {}XBOOLE-0K1 & (C1 c=TARSKIR1 B & B9 =XBOOLE-0R4 C1 \\/XBOOLE-0K2 {TARSKIK1 x}) implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C1,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              proof(rule ballI,rule impMI ,rule impMI ,rule impI)
                                have " not x inTARSKIR2 C"
                                  using A8 A12 sorry
                                then have A14: "C c=TARSKIR1 B9 \\SUBSET-1K6 {TARSKIK1 x}"
                                  using A13 xboole_1_th_7 zfmisc_1_th_34 sorry
                                have "B9 \\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 C \\SUBSET-1K6 {TARSKIK1 x}"
                                  using A13 xboole_1_th_40 sorry
                                then have A15: "B9 \\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 C"
                                  using A14 xboole_0_def_10 sorry
                                fix C1 assume [ty]: "C1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
                                assume "C1 <>HIDDENR2 {}XBOOLE-0K1"
                                  and A16: "C1 c=TARSKIR1 B"
                                  and A17: "B9 =XBOOLE-0R4 C1 \\/XBOOLE-0K2 {TARSKIK1 x}"
                                have " not x inTARSKIR2 C1"
                                  using A8 A16 sorry
                                then have A18: "C1 c=TARSKIR1 B9 \\SUBSET-1K6 {TARSKIK1 x}"
                                  using A17 xboole_1_th_7 zfmisc_1_th_34 sorry
                                have "B9 \\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 C1 \\SUBSET-1K6 {TARSKIK1 x}"
                                  using A17 xboole_1_th_40 sorry
                                thus "y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C1,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                                  using A18 A15 xboole_0_def_10 sorry
                              qed "sorry"
                              thus " ?thesis "
                                 sorry
                            qed
                            thus " not ( for y be ElementSUBSET-1M1-of Y holds  not (( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)))"
                              using A11 A12 A13 sorry
                          qed "sorry"
                        qed
                        have " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies ( ex y be ElementSUBSET-1M1-of Y st ( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies y =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9))"
                        proof(rule impI)
                          assume A19: " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x})"
                          obtain y where 
                            [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9"
                             sorry
                          show " ex y be ElementSUBSET-1M1-of Y st ( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies y =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9)"
                          proof(rule bexI[of _ "y"],rule conjMI)
                            show " for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              using A19 sorry
                            show " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies y =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9"
                               sorry
                          qed "sorry"
                        qed
                        thus " not ( for y be ElementSUBSET-1M1-of Y holds  not (( for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.} implies y =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) implies y =XBOOLE-0R4 G .FUNCT-1K1 B9)))"
                          using A10 sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                  qed "sorry"
                  obtain H where
                    [ty]:"H be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
                    A20: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B9,H .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9)"
                    using funct_2_sch_3 A9 sorry
                  obtain J where 
                    [ty]:"J be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and JDef:"J = H"
                     sorry
                  show " ex J be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies J .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & (( for x be ElementSUBSET-1M1-of X holds J .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x9 be ElementSUBSET-1M1-of X holds x9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 B9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9))))"
                  proof(rule bexI[of _ "J"],rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
                    have "( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & {TARSKIK1 x} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies  False "
                    proof(rule impI)
                      assume Given: " ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & {TARSKIK1 x} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                      then obtain C where
                        [ty]:"C be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and 
                        A21: "C <>HIDDENR2 {}XBOOLE-0K1"and A22: "C c=TARSKIR1 B"and A23: "{TARSKIK1 x} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                         sorry
                      have "C =XBOOLE-0R4 {TARSKIK1 x}"
                        using A21 A23 xboole_1_th_7 zfmisc_1_th_33 sorry
                      then have "x inTARSKIR2 C"
                        using tarski_def_1 sorry
                      thus " False "
                        using A8 A22 sorry
                    qed
                    then have A24: "J .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.})"
                      using A20 sorry
                    show " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies J .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"
                    proof-
                      have " for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not J .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)"
                      proof-
                        obtain E where 
                          [ty]:"E be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and EDef:"E = {}XBOOLE-0K1"
                          using finsub_1_th_7 sorry
                        have " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & E =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x})"
                           sorry
                        then have "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> E =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> E"
                          using A20 sorry
                        thus " for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not J .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)"
                          using A5 sorry
                      qed
                      thus " ?thesis "
                         sorry
                    qed
                    show " for x be ElementSUBSET-1M1-of X holds J .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                    proof-
                      have " for x9 be ElementSUBSET-1M1-of X holds J .FUNCT-1K1 {TARSKIK1 x9} =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9"
                      proof(rule ballI)
                        fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of X"
                        have "( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & {TARSKIK1 x9} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}) implies  False "
                        proof(rule impI)
                          assume Given: " ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & {TARSKIK1 x9} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                          then obtain C where
                            [ty]:"C be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and 
                            A25: "C <>HIDDENR2 {}XBOOLE-0K1"and A26: "C c=TARSKIR1 B"and A27: "{TARSKIK1 x9} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x}"
                             sorry
                          have A28: "C =XBOOLE-0R4 {TARSKIK1 x9}"
                            using A25 A27 xboole_1_th_7 zfmisc_1_th_33 sorry
                          have "x =XBOOLE-0R4 x9"
                            using A27 xboole_1_th_7 zfmisc_1_th_18 sorry
                          then have "x inTARSKIR2 C"
                            using A28 tarski_def_1 sorry
                          thus " False "
                            using A8 A26 sorry
                        qed
                        then have "J .FUNCT-1K1 {TARSKIK1 x9} =HIDDENR1 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x9.})"
                          using A20 sorry
                        also have "... = f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9"
                          using A6 sorry
                        finally show "J .FUNCT-1K1 {TARSKIK1 x9} =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9"
                           sorry
                      qed "sorry"
                      thus " ?thesis "
                         sorry
                    qed
                    fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
                    assume A29: "B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x}"
                      and A30: "B9 <>HIDDENR2 {}XBOOLE-0K1"
                    fix x9 assume [ty]: "x9 be ElementSUBSET-1M1-of X"
                    assume A31: "x9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 x})\\SUBSET-1K6 B9"
                    then have A32: " not x9 inTARSKIR2 B9"
                      using xboole_0_def_5 sorry
                    show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                    proof-
                      have cases: "x inTARSKIR2 B9 or  not x inTARSKIR2 B9"
                         sorry
                      have case1: "x inTARSKIR2 B9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                      proof(rule impI)
                        assume A33: "x inTARSKIR2 B9"
                        then have A34: "x9 inTARSKIR2 B"
                          using A31 A32 zfmisc_1_th_136 sorry
                        show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                        proof-
                          have cases: "B9 =XBOOLE-0R4 {TARSKIK1 x} or B9 <>HIDDENR2 {TARSKIK1 x}"
                             sorry
                          have case1: "B9 =XBOOLE-0R4 {TARSKIK1 x} implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                          proof(rule impI)
                            assume A35: "B9 =XBOOLE-0R4 {TARSKIK1 x}"
                            then have "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x9.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              using A20 A34 zfmisc_1_th_31 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              using A6 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A2 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A6 A24 A35 sorry
                            finally show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                               sorry
                          qed
                          have case2: "B9 <>HIDDENR2 {TARSKIK1 x} implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                          proof(rule impI)
                            assume "B9 <>HIDDENR2 {TARSKIK1 x}"
                            then have " not B9 c=TARSKIR1 {TARSKIK1 x}"
                              using A30 zfmisc_1_th_33 sorry
                            then have A36: "B9 \\SUBSET-1K6 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
                              using xboole_1_th_37 sorry
                            let ?C = "(B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.})\\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}"
                            have " not x9 inTARSKIR2 B9 \\SUBSET-1K6 {TARSKIK1 x}"
                              using A31 xboole_0_def_5 sorry
                            then have A37: "x9 inTARSKIR2 B \\SUBSET-1K6 (B9 \\SUBSET-1K6 {TARSKIK1 x})"
                              using A34 xboole_0_def_5 sorry
                            have "B9 \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 B"
                              using A29 xboole_1_th_43 sorry
                            then have A38: "?C c=TARSKIR1 B"
                              using A33 A31 A32 zfmisc_1_th_136 zfmisc_1_th_137 sorry
                            have "B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.} =HIDDENR1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x9}"
                              using A33 zfmisc_1_th_40 sorry
                            also have "... = ((B9 \\SUBSET-1K6 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x})\\/XBOOLE-0K2 {TARSKIK1 x9}"
                              using xboole_1_th_39 sorry
                            also have "... = ?C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}"
                              using xboole_1_th_4 sorry
                            finally have "B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.} =HIDDENR1 ?C \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}"
                               sorry
                            then have "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ((B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.})\\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              using A20 A38 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                              using A7 A29 A36 A37 xboole_1_th_43 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
                              using A3 sorry
                            also have "... = F .BINOP-1K1(G .FUNCT-1K1 (B9 \\SUBSET-1K6 {TARSKIK1 x}),F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9))"
                              using A2 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A3 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ((B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.})\\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A20 A29 A36 xboole_1_th_43 sorry
                            also have "... = F .BINOP-1K1(J .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using xboole_1_th_39 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A33 zfmisc_1_th_40 sorry
                            finally show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      have case2: " not x inTARSKIR2 B9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                      proof(rule impI)
                        assume A39: " not x inTARSKIR2 B9"
                        then have A40: "B9 c=TARSKIR1 B"
                          using A29 zfmisc_1_th_135 sorry
                        have A41: " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x})"
                          using A39 zfmisc_1_th_136 sorry
                        show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                        proof-
                          have cases: "x <>HIDDENR2 x9 or x =XBOOLE-0R4 x9"
                             sorry
                          have case1: "x <>HIDDENR2 x9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                          proof(rule impI)
                            assume A42: "x <>HIDDENR2 x9"
                            then have "x9 inTARSKIR2 B"
                              using A31 zfmisc_1_th_136 sorry
                            then have A43: "x9 inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9"
                              using A32 xboole_0_def_5 sorry
                            have " not x inTARSKIR2 B9 \\/XBOOLE-0K2 {TARSKIK1 x9}"
                              using A39 A42 zfmisc_1_th_136 sorry
                            then have " not ( ex C be ElementSUBSET-1M1-of FinFINSUB-1K5 X st (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B) & B9 \\/XBOOLE-0K2 {TARSKIK1 x9} =XBOOLE-0R4 C \\/XBOOLE-0K2 {TARSKIK1 x})"
                              using zfmisc_1_th_136 sorry
                            then have "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.})"
                              using A20 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A7 A30 A40 A43 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A20 A41 sorry
                            finally show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                               sorry
                          qed
                          have case2: "x =XBOOLE-0R4 x9 implies J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                          proof(rule impI)
                            assume "x =XBOOLE-0R4 x9"
                            then have "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A20 A29 A30 A39 zfmisc_1_th_135 sorry
                            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                              using A20 A41 sorry
                            finally show "J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(J .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9)"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A44: "?X({}.SETWISEOK1 X)"
          proof-
            have " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & (( for x be ElementSUBSET-1M1-of X holds G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {}.SETWISEOK1 X & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {}.SETWISEOK1 X \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))"
            proof-
              obtain e where
                [ty]:"e be ElementSUBSET-1M1-of Y" and 
                A45: "( ex e be ElementSUBSET-1M1-of Y st e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F) implies e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F"
                 sorry
              let ?X = "\<lambda>Lamb1. \<lambda>Lamb2. ( for x9 be ElementSUBSET-1M1-of X holds Lamb1 =XBOOLE-0R4 {TARSKIK1 x9} implies Lamb2 =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st Lamb1 =XBOOLE-0R4 {TARSKIK1 x9}) implies Lamb2 =XBOOLE-0R4 e)"
              have A46: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e)"
              proof(rule ballI)
                fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
                have A47: "( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies ( ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e))"
                proof(rule impI)
                  assume Given: " ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}"
                  then obtain x9 where
                    [ty]:"x9 be ElementSUBSET-1M1-of X" and 
                    A48: "x =XBOOLE-0R4 {TARSKIK1 x9}"
                     sorry
                  obtain y where 
                    [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9"
                     sorry
                  show " ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e)"
                  proof(rule bexI[of _ "y"],rule conjMI)
                    show " for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9"
                      using A48 zfmisc_1_th_3 sorry
                    show " not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e"
                      using A48 sorry
                  qed "sorry"
                qed
                have " not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies ( ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e))"
                proof(rule impI)
                  assume A49: " not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9})"
                  obtain y where 
                    [ty]:"y be ElementSUBSET-1M1-of Y" and yDef:"y = e"
                     sorry
                  show " ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e)"
                  proof(rule bexI[of _ "y"])
                    show "( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e)"
                      using A49 sorry
                  qed "sorry"
                qed
                thus " ex y be ElementSUBSET-1M1-of Y st ( for x9 be ElementSUBSET-1M1-of X holds x =XBOOLE-0R4 {TARSKIK1 x9} implies y =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9) & ( not ( ex x9 be ElementSUBSET-1M1-of X st x =XBOOLE-0R4 {TARSKIK1 x9}) implies y =XBOOLE-0R4 e)"
                  using A47 sorry
              qed "sorry"
              obtain G9 where
                [ty]:"G9 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
                A50: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B9,G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9)"
                using funct_2_sch_3 A46 sorry
              obtain G where 
                [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and GDef:"G = G9"
                 sorry
              show " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & (( for x be ElementSUBSET-1M1-of X holds G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {}.SETWISEOK1 X & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {}.SETWISEOK1 X \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))"
              proof(rule bexI[of _ "G"],rule conjMI,rule conjMI)
                show " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"
                proof-
                  have " for e9 be ElementSUBSET-1M1-of Y holds e9 is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 e9"
                  proof(rule ballI,rule impI)
                    obtain E where 
                      [ty]:"E be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and EDef:"E = {}XBOOLE-0K1"
                      using finsub_1_th_7 sorry
                    fix e9 assume [ty]: "e9 be ElementSUBSET-1M1-of Y"
                    assume A51: "e9 is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F"
                    have " not ( ex x9 be ElementSUBSET-1M1-of X st E =XBOOLE-0R4 {TARSKIK1 x9})"
                       sorry
                    then have "G .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 e"
                      using A50 sorry
                    also have "... = e9"
                      using A45 A51 binop_1_def_8 sorry
                    finally show "G .FUNCT-1K1 {}XBOOLE-0K1 =HIDDENR1 e9"
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                show " for x be ElementSUBSET-1M1-of X holds G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                  using A50 sorry
                show " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {}.SETWISEOK1 X & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {}.SETWISEOK1 X \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
                   sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B)"
            using setwiseo_sch_2 A44 A4 sorry
          then obtain G where
            [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
            A52: "(( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
             sorry
          show " ex tVar11 be ElementSUBSET-1M1-of Y st  ex tVar12 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B =XBOOLE-0R4 tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not tVar12 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds tVar12 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 &  not tVar12 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))"
          proof(rule bexI[of _ "G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B"])
            show " ex tVar12 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B =XBOOLE-0R4 tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not tVar12 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds tVar12 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 &  not tVar12 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(tVar12 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))"
            proof(rule bexI[of _ "G"])
              show "((G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 &  not G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))"
                using A52 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "(B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) implies ( for it1 be ElementSUBSET-1M1-of Y holds  for it2 be ElementSUBSET-1M1-of Y holds ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it1 =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) & ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it2 =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "(B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>)"
      have A1: "B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
        using Assume sorry
      have A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>"
        using Assume sorry
      have A3: "F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of Y holds  for it2 be ElementSUBSET-1M1-of Y holds ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it1 =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) & ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((it2 =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies it1 =HIDDENR1 it2"
      proof-
        have " for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds ( ex G1 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((x =XBOOLE-0R4 G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G1 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies (( ex G2 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((y =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G2 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G2 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of Y"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of Y"
          assume Given: " ex G1 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((x =XBOOLE-0R4 G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G1 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
          then obtain G1 where
            [ty]:"G1 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
            A53: "x =XBOOLE-0R4 G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B"and A54: " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G1 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A55: " for x be ElementSUBSET-1M1-of X holds G1 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A56: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
             sorry
          assume Given: " ex G2 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((y =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G2 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G2 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
          then obtain G2 where
            [ty]:"G2 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
            A57: "y =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B"and A58: " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G2 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A59: " for x be ElementSUBSET-1M1-of X holds G2 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A60: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
             sorry
          show "x =HIDDENR1 y"
          proof-
            have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies x =HIDDENR1 y"
            proof(rule impI)
              assume A61: "B =XBOOLE-0R4 {}XBOOLE-0K1"
              have "x =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F"
                using A53 A54 A61 A1 setwiseo_th_14 sorry
              also have "... = y"
                using A57 A58 A61 A1 setwiseo_th_14 sorry
              finally show "x =HIDDENR1 y"
                 sorry
            qed
            have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies x =HIDDENR1 y"
            proof(rule impI)
              assume A62: "B <>HIDDENR2 {}XBOOLE-0K1"
              let ?X = "\<lambda>Lamb1. Lamb1 c=TARSKIR1 B & Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies G1 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 G2 .FUNCT-1K1 Lamb1"
              have A63: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
              proof-
                have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be ElementSUBSET-1M1-of X holds (B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9 =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9) implies ( not x inTARSKIR2 B9 implies (B9 \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 B implies (B9 \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}))))"
                proof(rule ballI,rule ballI,rule impI,rule impI,rule impI,rule impI)
                  fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
                  fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
                  assume A64: "B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9 =XBOOLE-0R4 G2 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9"
                  assume A65: " not x inTARSKIR2 B9"
                  assume A66: "B9 \\/XBOOLE-0K2 {TARSKIK1 x} c=TARSKIR1 B"
                  then have A67: "B9 c=TARSKIR1 B"
                    using zfmisc_1_th_137 sorry
                  assume "B9 \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
                  have "x inTARSKIR2 B"
                    using A66 zfmisc_1_th_137 sorry
                  then have A68: "x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9"
                    using A65 xboole_0_def_5 sorry
                  show "G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                  proof-
                    have cases: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 or B9 <>HIDDENR2 {}XBOOLE-0K1"
                       sorry
                    have case1: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                    proof(rule impI)
                      assume A69: "B9 =XBOOLE-0R4 {}XBOOLE-0K1"
                      then have "G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                        using A55 sorry
                      also have "... = G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                        using A59 A69 sorry
                      finally show "G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                         sorry
                    qed
                    have case2: "B9 <>HIDDENR2 {}XBOOLE-0K1 implies G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                    proof(rule impI)
                      assume A70: "B9 <>HIDDENR2 {}XBOOLE-0K1"
                      then have "G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G1 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                        using A56 A67 A68 sorry
                      also have "... = G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                        using A60 A64 A67 A68 A70 sorry
                      finally show "G1 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 G2 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x})"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A71: "?X({}.SETWISEOK1 X)"
                 sorry
              have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B9)"
                using setwiseo_sch_2 A71 A63 sorry
              thus "x =HIDDENR1 y"
                using A53 A57 A62 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem setwiseo_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (((B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>) & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for IT be ElementSUBSET-1M1-of Y holds IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) iff ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) & (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>)) implies ( for IT be ElementSUBSET-1M1-of Y holds (IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) implies ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))) & (( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))) implies IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
      and A2: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A3: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>"
      and A4: "F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    fix IT assume [ty]: "IT be ElementSUBSET-1M1-of Y"
    show "IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) implies ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))"
    proof-
      have "IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) implies  not ( for G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) holds  not (((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B &  not G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))))"
      proof(rule impI)
        assume "IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)"
        then obtain G where
          [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
          A5: "IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)"and A6: " for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A7: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
          using A1 A3 A4 setwiseo_def_3 sorry
        have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
        proof-
          have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
          proof(rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
            fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
            assume A8: "B9 c=TARSKIR1 B"
              and A9: "B9 <>HIDDENR2 {}XBOOLE-0K1"
            fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
            assume A10: "x inTARSKIR2 B"
            show "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
            proof-
              have cases: "x inTARSKIR2 B9 or  not x inTARSKIR2 B9"
                 sorry
              have case1: "x inTARSKIR2 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              proof(rule impI)
                assume "x inTARSKIR2 B9"
                then have A11: "B9 \\/XBOOLE-0K2 {TARSKIK1 x} =XBOOLE-0R4 B9"
                  using zfmisc_1_th_40 sorry
                then have A12: "{TARSKIK1 x} c=TARSKIR1 B9"
                  using xboole_1_th_7 sorry
                have " not x inTARSKIR2 B9 \\SUBSET-1K6 {TARSKIK1 x}"
                  using zfmisc_1_th_56 sorry
                then have A13: "x inTARSKIR2 B \\SUBSET-1K6 (B9 \\SUBSET-1K6 {TARSKIK1 x})"
                  using A10 xboole_0_def_5 sorry
                show "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                proof-
                  have cases: "B9 =XBOOLE-0R4 {TARSKIK1 x} or B9 <>HIDDENR2 {TARSKIK1 x}"
                     sorry
                  have case1: "B9 =XBOOLE-0R4 {TARSKIK1 x} implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                  proof(rule impI)
                    assume A14: "B9 =XBOOLE-0R4 {TARSKIK1 x}"
                    then have "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                      using A2 A6 sorry
                    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                      using A6 A14 sorry
                    finally show "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                       sorry
                  qed
                  have case2: "B9 <>HIDDENR2 {TARSKIK1 x} implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                  proof(rule impI)
                    assume "B9 <>HIDDENR2 {TARSKIK1 x}"
                    then have " not B9 c=TARSKIR1 {TARSKIK1 x}"
                      using A12 xboole_0_def_10 sorry
                    then have "B9 \\SUBSET-1K6 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
                      using xboole_1_th_37 sorry
                    then have A15: "G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ((B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.})\\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                      using A7 A8 A13 xboole_1_th_1 sorry
                    have "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K1(G .FUNCT-1K1 (B9 \\SUBSET-1K6 {TARSKIK1 x}),F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
                      using A2 A15 xboole_1_th_39 sorry
                    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B9 \\SETWISEOK9\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                      using A4 sorry
                    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                      using A11 A15 xboole_1_th_39 sorry
                    finally show "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                       sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              have case2: " not x inTARSKIR2 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              proof(rule impI)
                assume " not x inTARSKIR2 B9"
                then have "x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9"
                  using A10 xboole_0_def_5 sorry
                thus "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                  using A7 A8 A9 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus " not ( for G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) holds  not (((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F &  not G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e))) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  not ((B9 c=TARSKIR1 B &  not B9 <>HIDDENR2 {}XBOOLE-0K1) &  not ( for x be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 B &  not G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))))))"
          using A5 A6 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
    then obtain G where
      [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
      A16: "(IT =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"and A17: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
       sorry
    have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
    proof(rule ballI,rule impI,rule ballI,rule impI)
      fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
      assume A18: "B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1"
      fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
      assume "x inTARSKIR2 B \\SETWISEOK9\<^bsub>(X)\<^esub> B9"
      then have "x inTARSKIR2 B"
        using xboole_0_def_5 sorry
      thus "G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
        using A17 A18 sorry
    qed "sorry"
    thus "IT =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)"
      using A1 A3 A4 A16 setwiseo_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X, Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve F for "BinOpBINOP-1M2-of Y"
reserve B for "ElementSUBSET-1M1-of FinFINSUB-1K5 X"
reserve f for "FunctionFUNCT-2M1-of(X,Y)"
mtheorem setwiseo_th_17:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for b be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> b.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for b be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> b.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
    have " ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> b.},f) =XBOOLE-0R4 G .FUNCT-1K1 {TARSKIK1 b} & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {TARSKIK1 b} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {TARSKIK1 b} \\SUBSET-1K6 B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
      using A1 setwiseo_def_3 sorry
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> b.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_18:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "(F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of X"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
    obtain G where
      [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
      A2: "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .},f) =XBOOLE-0R4 G .FUNCT-1K1 {TARSKIK2 a,b }"and " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A3: " for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {TARSKIK2 a,b } & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {TARSKIK2 a,b } implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
      using A1 setwiseo_th_16 sorry
    have A5: "b inTARSKIR2 {TARSKIK2 a,b }"
      using tarski_def_2 sorry
    have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .},f) =HIDDENR1 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> a.} \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> b.})"
      using A2 enumset1_th_1 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> a.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
      using A4 A5 zfmisc_1_th_7 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
      using A3 sorry
    finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_19:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of X holds  for c be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> a,b,c .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> c))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of X holds  for c be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> a,b,c .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> c))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "(F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of X"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of X"
    obtain G where
      [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
      A2: "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> a,b,c .},f) =XBOOLE-0R4 G .FUNCT-1K1 {ENUMSET1K1 a,b,c }"and " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A3: " for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {ENUMSET1K1 a,b,c } & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {ENUMSET1K1 a,b,c } implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
      using A1 setwiseo_th_16 sorry
    have A5: "b inTARSKIR2 {ENUMSET1K1 a,b,c }"
      using enumset1_def_1 sorry
    have A6: "G .FUNCT-1K1 {TARSKIK2 a,b } =HIDDENR1 G .FUNCT-1K1 ({TARSKIK1 a} \\/XBOOLE-0K2 {TARSKIK1 b})"
      using enumset1_th_1 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> a.}),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
      using A4 A5 setwiseo_th_1 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
      using A3 sorry
    finally have "G .FUNCT-1K1 {TARSKIK2 a,b } =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b)"
       sorry
    have A7: "c inTARSKIR2 {ENUMSET1K1 a,b,c }"
      using enumset1_def_1 sorry
    have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> a,b,c .},f) =HIDDENR1 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> ({.SETWISEOK6\<^bsub>(X)\<^esub> a,b .} \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> c.})"
      using A2 enumset1_th_3 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> c)"
      using A4 A6 A7 setwiseo_th_2 sorry
    finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> a,b,c .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_20:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ((F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & B <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies (B <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "(F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    assume A2: "B <>HIDDENR2 {}XBOOLE-0K1"
    then obtain G9 where
      [ty]:"G9 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
      A3: "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B"and " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A4: " for x be ElementSUBSET-1M1-of X holds G9 .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A5: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies G9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
      using A1 setwiseo_th_16 sorry
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    obtain G where
      [ty]:"G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y)" and 
      A6: "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.})"and " for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A7: " for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"and A8: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x9 be ElementSUBSET-1M1-of X holds x9 inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x} implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x9}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9))"
      using A1 setwiseo_th_16 sorry
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 & Lamb1 c=TARSKIR1 B implies G .FUNCT-1K1 Lamb1 =XBOOLE-0R4 G9 .FUNCT-1K1 Lamb1"
    have A9: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) implies ?X(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
    proof-
      have " for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for y be ElementSUBSET-1M1-of X holds (C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B implies G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C =XBOOLE-0R4 G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C) implies (C \\/XBOOLE-0K2 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1 & C \\/XBOOLE-0K2 {TARSKIK1 y} c=TARSKIR1 B implies G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}))"
      proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
        have A10: "B c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 x}"
          using xboole_1_th_7 sorry
        fix C assume [ty]: "C be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix y assume [ty]: "y be ElementSUBSET-1M1-of X"
        assume A11: "C <>HIDDENR2 {}XBOOLE-0K1 & C c=TARSKIR1 B implies G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C =XBOOLE-0R4 G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C"
        assume "C \\/XBOOLE-0K2 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
          and A12: "C \\/XBOOLE-0K2 {TARSKIK1 y} c=TARSKIR1 B"
        have A13: "C c=TARSKIR1 B & y inTARSKIR2 B"
          using A12 zfmisc_1_th_137 sorry
        show "G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
        proof-
          have cases: "C =XBOOLE-0R4 {}XBOOLE-0K1 or C <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "C =XBOOLE-0R4 {}XBOOLE-0K1 implies G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
          proof(rule impI)
            assume A14: "C =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> y"
              using A7 sorry
            also have "... = G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
              using A4 A14 sorry
            finally show "G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
               sorry
          qed
          have case2: "C <>HIDDENR2 {}XBOOLE-0K1 implies G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
          proof(rule impI)
            assume A15: "C <>HIDDENR2 {}XBOOLE-0K1"
            then have "G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> C,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> y)"
              using A8 A11 A13 A10 xboole_1_th_1 sorry
            also have "... = G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
              using A5 A13 A15 sorry
            finally show "G .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y}) =HIDDENR1 G9 .FUNCT-1K1 (C \\/XBOOLE-0K2 {TARSKIK1 y})"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A16: "?X({}.SETWISEOK1 X)"
       sorry
    have A17: " for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(C)"
      using setwiseo_sch_4 A16 A9 sorry
    have "x inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 x}"
      using zfmisc_1_th_136 sorry
    then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
      using A2 A6 A8 xboole_1_th_7 sorry
    also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
      using A2 A3 A17 sorry
    finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_21:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> implies ( for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) implies ( for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B1 <>HIDDENR2 {}XBOOLE-0K1 implies  not ( not B2 <>HIDDENR2 {}XBOOLE-0K1 &  not F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>"
      and A3: "F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    fix B1 assume [ty]: "B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B2 assume [ty]: "B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> Lamb1,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f))"
    assume A4: "B1 <>HIDDENR2 {}XBOOLE-0K1"
    have A5: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) implies ?X(B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> b.})"
    proof-
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be ElementSUBSET-1M1-of X holds (B <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f))) & B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        assume A6: "B <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f))"
          and "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
        show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
        proof-
          have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
          proof(rule impI)
            assume A7: "B =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A1 A2 A3 A4 setwiseo_th_20 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
              using A2 A3 A7 setwiseo_th_17 sorry
            finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
               sorry
          qed
          have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
          proof(rule impI)
            assume A8: "B <>HIDDENR2 {}XBOOLE-0K1"
            have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>((B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B)\\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)"
              using xboole_1_th_4 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A1 A2 A3 A6 A8 setwiseo_th_20 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
              using A3 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
              using A1 A2 A3 A8 setwiseo_th_20 sorry
            finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> (B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f))"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: "?X({}.SETWISEOK1 X)"
       sorry
    have " for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B2)"
      using setwiseo_sch_4 A9 A5 sorry
    thus " not ( not B2 <>HIDDENR2 {}XBOOLE-0K1 &  not F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_22:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 B implies F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A2: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    assume A3: "x inTARSKIR2 B"
    have "F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f))"
      using A1 setwiseo_th_17 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.} \\/SETWISEOK8\<^bsub>(X)\<^esub> B,f)"
      using A1 A2 A3 setwiseo_th_21 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)"
      using A3 zfmisc_1_th_40 sorry
    finally show "F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_23:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 & B c=TARSKIR1 C implies F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for C be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 & B c=TARSKIR1 C implies F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix C assume [ty]: "C be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A2: "B <>HIDDENR2 {}XBOOLE-0K1"
      and A3: "B c=TARSKIR1 C"
    have "C <>HIDDENR2 {}XBOOLE-0K1"
      using A2 A3 sorry
    then have "F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> C,f)"
      using A1 A2 setwiseo_th_21 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)"
      using A3 xboole_1_th_12 sorry
    finally show "F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(C,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_24:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ((B <>HIDDENR2 {}XBOOLE-0K1 & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of Y holds ( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds B <>HIDDENR2 {}XBOOLE-0K1 & ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>) implies ( for a be ElementSUBSET-1M1-of Y holds  not (( for b be ElementSUBSET-1M1-of X holds  not (b inTARSKIR2 B &  not f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a)) &  not F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "B <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A3: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of Y"
    let ?X = "\<lambda>Lamb1. ( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 Lamb1 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f) =XBOOLE-0R4 a"
    have A4: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B1) & ?X(B2) implies ?X(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2)"
    proof-
      have " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ((( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B1 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f) =XBOOLE-0R4 a) & (( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B2 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f) =XBOOLE-0R4 a)) & ( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 a"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        assume A5: "(( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B1 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f) =XBOOLE-0R4 a) & (( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B2 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f) =XBOOLE-0R4 a)"
          and A6: " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
        have A7: " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B2 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
        proof(rule ballI,rule impI)
          fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
          assume "b inTARSKIR2 B2"
          then have "b inTARSKIR2 B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2"
            using xboole_0_def_3 sorry
          thus "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
            using A6 sorry
        qed "sorry"
        have " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B1 implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
        proof(rule ballI,rule impI)
          fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
          assume "b inTARSKIR2 B1"
          then have "b inTARSKIR2 B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2"
            using xboole_0_def_3 sorry
          thus "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
            using A6 sorry
        qed "sorry"
        then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(a,a)"
          using A2 A3 A5 A7 setwiseo_th_21 sorry
        also have "... = a"
          using A3 sorry
        finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 a"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: " for x be ElementSUBSET-1M1-of X holds ?X({.SETWISEOK5\<^bsub>(X)\<^esub> x.})"
    proof-
      have " for x be ElementSUBSET-1M1-of X holds ( for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 {TARSKIK1 x} implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a) implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 a"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        assume A9: " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 {TARSKIK1 x} implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
        have A10: "x inTARSKIR2 {TARSKIK1 x}"
          using tarski_def_1 sorry
        have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
          using A2 setwiseo_th_17 sorry
        also have "... = a"
          using A9 A10 sorry
        finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 a"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B)"
      using setwiseo_sch_3 A8 A4 sorry
    thus " not (( for b be ElementSUBSET-1M1-of X holds  not (b inTARSKIR2 B &  not f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a)) &  not F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_25:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of Y holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =XBOOLE-0R4 {TARSKIK1 a} implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for a be ElementSUBSET-1M1-of Y holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =XBOOLE-0R4 {TARSKIK1 a} implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of Y"
    assume A2: "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =XBOOLE-0R4 {TARSKIK1 a}"
    have A3: " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B implies f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
      assume "b inTARSKIR2 B"
      then have "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b inTARSKIR2 {TARSKIK1 a}"
        using A2 funct_2_th_35 sorry
      thus "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 a"
        using tarski_def_1 sorry
    qed "sorry"
    have "B <>HIDDENR2 {}XBOOLE-0K1"
      using A2 sorry
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 a"
      using A1 A3 setwiseo_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_26:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds A <>HIDDENR2 {}XBOOLE-0K1 & f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & (F be associativeBINOP-1V2\<^bsub>(Y)\<^esub> & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>) implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds A <>HIDDENR2 {}XBOOLE-0K1 & f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A3: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Y)"
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> Lamb1 =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
    have A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) implies ?X(B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> b.})"
    proof-
      have " for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be ElementSUBSET-1M1-of X holds (A <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))) implies (A \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> (A \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)))"
      proof(rule ballI,rule ballI,rule impI,rule impI,rule ballI,rule impI)
        fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        assume A5: "A <>HIDDENR2 {}XBOOLE-0K1 implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
        assume "A \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        assume A6: "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> (A \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B"
        show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
        proof-
          have cases: "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A or  not f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
             sorry
          have case1: "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
          proof(rule impI)
            assume "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
            then obtain x9 where
              [ty]:"x9 be ElementSUBSET-1M1-of X" and 
              A7: "x9 inTARSKIR2 A"and A8: "f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9 =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
              using funct_2_th_65 sorry
            have A9: "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =HIDDENR1 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\/XBOOLE-0K2 ImRELAT-1K12(f,x)"
              using A6 relat_1_th_120 sorry
            also have "... = f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\/XBOOLE-0K2 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
              using setwiseo_th_8 sorry
            also have "... = f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
              using A7 A8 funct_2_th_35 zfmisc_1_th_40 sorry
            finally have "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =HIDDENR1 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
               sorry
            have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A1 A2 A3 A7 setwiseo_th_20 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.},f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A7 zfmisc_1_th_40 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A1 A2 A3 A7 setwiseo_th_20 sorry
            also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f),F .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9))"
              using A2 A8 sorry
            also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x9.},f)"
              using A1 A2 A3 A7 setwiseo_th_20 sorry
            also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f)"
              using A7 zfmisc_1_th_40 sorry
            also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
              using A5 A7 A9 sorry
            finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
               sorry
          qed
          have case2: " not f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
          proof(rule impI)
            assume A10: " not f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x inTARSKIR2 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A"
            show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
            proof-
              have cases: "A =XBOOLE-0R4 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
                 sorry
              have case1: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
              proof(rule impI)
                assume A11: "A =XBOOLE-0R4 {}XBOOLE-0K1"
                then have A12: "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =HIDDENR1 ImRELAT-1K12(f,x)"
                  using A6 sorry
                also have "... = {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using setwiseo_th_8 sorry
                finally have "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B =HIDDENR1 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                   sorry
                have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                  using A1 A2 A11 setwiseo_th_17 sorry
                also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
                  using A1 A2 A3 A12 setwiseo_th_25 sorry
                finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
                   sorry
              qed
              have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
              proof(rule impI)
                assume A13: "A <>HIDDENR2 {}XBOOLE-0K1"
                obtain B1 where 
                  [ty]:"B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and B1Def:"B1 = B \\SUBSET-1K6 g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using setwiseo_th_11 sorry
                have A14: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
                proof(rule impI)
                  assume "B1 =XBOOLE-0R4 {}XBOOLE-0K1"
                  then have A15: "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B c=TARSKIR1 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using relat_1_th_123 xboole_1_th_37 sorry
                  have "g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x } c=TARSKIR1 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using funct_1_th_75 sorry
                  then have "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> (A \\/XBOOLE-0K2 {TARSKIK1 x}) c=TARSKIR1 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using A6 A15 sorry
                  then have "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\/FINSUB-1K1\<^bsub>(boolZFMISC-1K1 Y)\<^esub> f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x} c=TARSKIR1 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using relat_1_th_120 sorry
                  then have "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =HIDDENR1 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A /\\SUBSET-1K8\<^bsub>(Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using xboole_1_th_11 xboole_1_th_28 sorry
                  also have "... = {}XBOOLE-0K1"
                    using A10 xboole_0_def_7 zfmisc_1_th_50 sorry
                  finally have "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =HIDDENR1 {}XBOOLE-0K1"
                     sorry
                  thus " False "
                    using A13 setwiseo_th_13 sorry
                qed
                obtain B2 where 
                  [ty]:"B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X" and B2Def:"B2 = B /\\SUBSET-1K9\<^bsub>(X)\<^esub> g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using setwiseo_th_11 xboole_1_th_17 sorry
                have A16: "B =XBOOLE-0R4 B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2"
                  using xboole_1_th_51 sorry
                have A17: " for b be ElementSUBSET-1M1-of X holds b inTARSKIR2 B2 implies g .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                proof(rule ballI,rule impI)
                  fix b assume [ty]: "b be ElementSUBSET-1M1-of X"
                  assume "b inTARSKIR2 B2"
                  then have "b inTARSKIR2 g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using xboole_0_def_4 sorry
                  then have "g .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b inTARSKIR2 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                    using funct_1_def_7 sorry
                  thus "g .FUNCT-2K3\<^bsub>(X,Y)\<^esub> b =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                    using tarski_def_1 sorry
                qed "sorry"
                have A18: "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =HIDDENR1 f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\SUBSET-1K7\<^bsub>(Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using A10 zfmisc_1_th_57 sorry
                also have "... = f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\SUBSET-1K7\<^bsub>(Y)\<^esub> ImRELAT-1K12(f,x)"
                  using setwiseo_th_8 sorry
                also have "... = (f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A \\/FINSUB-1K1\<^bsub>(boolZFMISC-1K1 Y)\<^esub> f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x})\\FINSUB-1K2\<^bsub>(boolZFMISC-1K1 Y)\<^esub> f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> {TARSKIK1 x}"
                  using xboole_1_th_40 sorry
                also have "... = f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> (A \\/XBOOLE-0K2 {TARSKIK1 x}) \\SUBSET-1K7\<^bsub>(Y)\<^esub> ImRELAT-1K12(f,x)"
                  using relat_1_th_120 sorry
                also have "... = g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B \\SUBSET-1K7\<^bsub>(Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using A6 setwiseo_th_8 sorry
                also have "... = g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B1"
                  using setwiseo_th_6 sorry
                finally have "f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =HIDDENR1 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B1"
                   sorry
                have "x inTARSKIR2 A \\/XBOOLE-0K2 {TARSKIK1 x}"
                  using zfmisc_1_th_136 sorry
                then obtain x9 where
                  [ty]:"x9 be ElementSUBSET-1M1-of X" and 
                  A19: "x9 inTARSKIR2 B"and A20: "g .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x9 =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
                  using A6 funct_2_th_35 funct_2_th_65 sorry
                have "x9 inTARSKIR2 g \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x }"
                  using A20 setwiseo_th_7 sorry
                then have A21: "B2 <>HIDDENR2 {}XBOOLE-0K1"
                  using A19 xboole_0_def_4 sorry
                have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                  using A1 A2 A3 A13 setwiseo_th_20 sorry
                also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,g),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
                  using A5 A13 A18 sorry
                also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,g),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,g))"
                  using A1 A2 A3 A21 A17 setwiseo_th_24 sorry
                also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
                  using A1 A2 A3 A16 A14 A21 setwiseo_th_21 sorry
                finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A22: "?X({}.SETWISEOK1 X)"
       sorry
    have A23: " for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(A)"
      using setwiseo_sch_4 A22 A4 sorry
    fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume "A <>HIDDENR2 {}XBOOLE-0K1 & f .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:RELSET-1K7\<^bsub>(X,Y)\<^esub> B"
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
      using A23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_27:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for G be BinOpBINOP-1M2-of Y holds ((F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for a be ElementSUBSET-1M1-of Y holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for G be BinOpBINOP-1M2-of Y holds F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for a be ElementSUBSET-1M1-of Y holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of Y"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A4: "B <>HIDDENR2 {}XBOOLE-0K1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of Y"
    let ?X = "\<lambda>Lamb1. G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
    have A5: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B1) & ?X(B2) implies ?X(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2)"
    proof-
      have " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)) & G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)) implies G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
      proof(rule ballI,rule ballI,rule impI)
        fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        assume A6: "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)) & G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
        have "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f)) =HIDDENR1 G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)))"
          using A1 A2 setwiseo_th_21 sorry
        also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)))"
          using A3 A6 binop_1_th_11 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
          using A1 A2 setwiseo_th_21 sorry
        finally show "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for x be ElementSUBSET-1M1-of X holds ?X({.SETWISEOK5\<^bsub>(X)\<^esub> x.})"
    proof-
      have " for x be ElementSUBSET-1M1-of X holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        have "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
          using A2 setwiseo_th_17 sorry
        also have "... = (G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f)).FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
          using funcop_1_th_53 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
          using A2 setwiseo_th_17 sorry
        finally show "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B)"
      using setwiseo_sch_3 A7 A5 sorry
    thus "G .BINOP-1K4\<^bsub>(Y)\<^esub>(a,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(Y,X)\<^esub>(a,f))"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_28:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for G be BinOpBINOP-1M2-of Y holds ((F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for a be ElementSUBSET-1M1-of Y holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for G be BinOpBINOP-1M2-of Y holds F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for a be ElementSUBSET-1M1-of Y holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of Y"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(Y)\<^esub> F"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A4: "B <>HIDDENR2 {}XBOOLE-0K1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of Y"
    let ?X = "\<lambda>Lamb1. G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
    have A5: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B1) & ?X(B2) implies ?X(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2)"
    proof-
      have " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)) & G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)) implies G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f),a) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
      proof(rule ballI,rule ballI,rule impI)
        fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        assume A6: "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)) & G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
        have "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f),a) =HIDDENR1 G .BINOP-1K4\<^bsub>(Y)\<^esub>(F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)),a)"
          using A1 A2 setwiseo_th_21 sorry
        also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)))"
          using A3 A6 binop_1_th_11 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
          using A1 A2 setwiseo_th_21 sorry
        finally show "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f),a) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for x be ElementSUBSET-1M1-of X holds ?X({.SETWISEOK5\<^bsub>(X)\<^esub> x.})"
    proof-
      have " for x be ElementSUBSET-1M1-of X holds G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f),a) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        have "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f),a) =HIDDENR1 G .BINOP-1K4\<^bsub>(Y)\<^esub>(f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x,a)"
          using A2 setwiseo_th_17 sorry
        also have "... = (G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a)).FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
          using funcop_1_th_48 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
          using A2 setwiseo_th_17 sorry
        finally show "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},f),a) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B)"
      using setwiseo_sch_3 A7 A5 sorry
    thus "G .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),a) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(Y,X)\<^esub>(f,a))"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax SETWISEOK11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .:SETWISEOK11\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> A" \<rightharpoonup> "f .:RELAT-1K10 A"

mtheorem setwiseo_add_6:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(X,Y)", "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
"cluster f .:RELAT-1K10 A as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
proof
(*coherence*)
  show "f .:RELAT-1K10 A be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
    using setwiseo_lm_1 sorry
qed "sorry"

mtheorem setwiseo_th_29:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of A holds (F be idempotentBINOP-1V3\<^bsub>(A)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(A)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(A)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,A) holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)))"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of A holds F be idempotentBINOP-1V3\<^bsub>(A)\<^esub> & (F be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & F be associativeBINOP-1V2\<^bsub>(A)\<^esub>) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,A) holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule impI,rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of A"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & F be associativeBINOP-1V2\<^bsub>(A)\<^esub>"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A3: "B <>HIDDENR2 {}XBOOLE-0K1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,A)"
    let ?X = "\<lambda>Lamb1. F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> Lamb1,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(Lamb1,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
    have A4: "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using funct_2_def_1 sorry
    have A5: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B1) & ?X(B2) implies ?X(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2)"
    proof-
      have " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B1,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B1,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f) & F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B2,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B2,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f) implies F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> (B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
      proof(rule ballI,rule ballI,rule impI)
        fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        assume A6: "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B1,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B1,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f) & F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B2,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B2,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
        have A7: "B1 c=TARSKIR1 X"
          using finsub_1_def_5 sorry
        have A8: "B2 c=TARSKIR1 X"
          using finsub_1_def_5 sorry
        have "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> (B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B1 \\/SETWISEOK8\<^bsub>(Y)\<^esub> f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B2,g)"
          using relat_1_th_120 sorry
        also have "... = F .BINOP-1K4\<^bsub>(A)\<^esub>(F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B1,g),F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B2,g))"
          using A1 A2 A7 A8 setwiseo_th_21 A4 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
          using A1 A2 A6 setwiseo_th_21 sorry
        finally show "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> (B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: " for x be ElementSUBSET-1M1-of X holds ?X({.SETWISEOK5\<^bsub>(X)\<^esub> x.})"
    proof-
      have " for x be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        have "f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}) =XBOOLE-0R4 ImRELAT-1K12(f,x)"
           sorry
        then have "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>({.SETWISEOK5\<^bsub>(Y)\<^esub> f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x.},g)"
          using A4 funct_1_th_59 sorry
        also have "... = g .FUNCT-2K3\<^bsub>(Y,A)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
          using A2 setwiseo_th_17 sorry
        also have "... = (g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f).FUNCT-2K3\<^bsub>(X,A)\<^esub> x"
          using funct_2_th_15 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
          using A2 setwiseo_th_17 sorry
        finally show "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> ({.SETWISEOK5\<^bsub>(X)\<^esub> x.}),g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 X holds ?X(B)"
      using setwiseo_sch_3 A9 A5 sorry
    thus "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_30:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds (G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds ( for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f))))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> implies ( for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds (G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds ( for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A2: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of Z"
    assume A3: "G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>"
      and A4: "G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume A5: " for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)"
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(Lamb1,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(Lamb1,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
    have A6: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for b be ElementSUBSET-1M1-of X holds ?X(B9) implies ?X(B9 \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> b.})"
    proof-
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be ElementSUBSET-1M1-of X holds (B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)) & B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
        assume A7: "B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
          and "B \\/XBOOLE-0K2 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
        show "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
        proof-
          have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
          proof(rule impI)
            assume A8: "B =XBOOLE-0R4 {}XBOOLE-0K1"
            then have "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
              using A1 setwiseo_th_17 sorry
            also have "... = (g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f).FUNCT-2K3\<^bsub>(X,Z)\<^esub> x"
              using funct_2_th_15 sorry
            also have "... = G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
              using A3 A8 setwiseo_th_17 sorry
            finally show "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
               sorry
          qed
          have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
          proof(rule impI)
            assume A9: "B <>HIDDENR2 {}XBOOLE-0K1"
            then have "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
              using A1 A2 setwiseo_th_20 sorry
            also have "... = G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)),g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
              using A5 sorry
            also have "... = G .BINOP-1K4\<^bsub>(Z)\<^esub>(G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f),(g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f).FUNCT-2K3\<^bsub>(X,Z)\<^esub> x)"
              using A7 A9 funct_2_th_15 sorry
            also have "... = G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
              using A3 A4 A9 setwiseo_th_20 sorry
            finally show "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "?X({}.SETWISEOK1 X)"
       sorry
    show " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
      using setwiseo_sch_4 A10 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_31:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    have "the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F & ( ex G be FunctionFUNCT-2M1-of(FinFINSUB-1K5 X,Y) st ((F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> {}.SETWISEOK1 X & ( for e be ElementSUBSET-1M1-of Y holds e is-a-unity-wrtBINOP-1R3\<^bsub>(Y)\<^esub> F implies G .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e)) & ( for x be ElementSUBSET-1M1-of X holds G .FUNCT-1K1 {TARSKIK1 x} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)) & ( for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B9 c=TARSKIR1 {}.SETWISEOK1 X & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for x be ElementSUBSET-1M1-of X holds x inTARSKIR2 {}.SETWISEOK1 X \\SETWISEOK9\<^bsub>(X)\<^esub> B9 implies G .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 x}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(G .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 X,Y)\<^esub> B9,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))))"
      using A1 setwiseo_def_3 setwiseo_th_14 sorry
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_32:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ((F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for x be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) implies (F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for x be ElementSUBSET-1M1-of X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
    assume A3: "F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    have A4: "{}XBOOLE-0K1 =RELAT-1R1 {}.SETWISEOK1 X"
       sorry
    have "B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
    proof(rule impI)
      assume A5: "B =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x"
        using A2 setwiseo_th_17 sorry
      also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F,f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
        using A3 setwiseo_th_15 sorry
      also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
        using A2 A3 A4 A5 setwiseo_th_31 sorry
      finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
         sorry
    qed
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> x.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,Y)\<^esub> x)"
      using A1 A2 setwiseo_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_33:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds ((F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds  for f be FunctionFUNCT-2M1-of(X,Y) holds F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) implies ( for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A3: "F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
    fix B1 assume [ty]: "B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B2 assume [ty]: "B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have "B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
    proof(rule impI)
      have A4: "{}XBOOLE-0K1 =RELAT-1R1 {}.SETWISEOK1 X"
         sorry
      assume A5: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1"
      show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
      proof-
        have cases: "B2 =XBOOLE-0R4 {}XBOOLE-0K1 or B1 =XBOOLE-0R4 {}XBOOLE-0K1"
          using A5 sorry
        have case1: "B2 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
        proof(rule impI)
          assume A6: "B2 =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F)"
            using A3 setwiseo_th_15 sorry
          also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
            using A2 A3 A4 A6 setwiseo_th_31 sorry
          finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
             sorry
        qed
        have case2: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
        proof(rule impI)
          assume A7: "B1 =XBOOLE-0R4 {}XBOOLE-0K1"
          then have "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F,F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
            using A3 setwiseo_th_15 sorry
          also have "... = F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
            using A2 A3 A4 A7 setwiseo_th_31 sorry
          finally show "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(Y)\<^esub>(F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B2,f))"
      using A1 A2 setwiseo_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_34:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(X,Y) holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A2: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A3: "F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(X,Y)"
    fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    assume A4: "f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 g .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B"
    have "A =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
    proof(rule impI)
      assume A5: "A =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "A =XBOOLE-0R4 {}.SETWISEOK1 X"
         sorry
      then have A6: "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F"
        using A1 A3 setwiseo_th_31 sorry
      have "f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> A =XBOOLE-0R4 {}XBOOLE-0K1"
        using A5 sorry
      then have "B =XBOOLE-0R4 {}.SETWISEOK1 X"
        using A4 setwiseo_th_13 sorry
      thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
        using A1 A3 A6 setwiseo_th_31 sorry
    qed
    thus "F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(A,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,g)"
      using A1 A2 A4 setwiseo_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_35:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of A holds ((F be idempotentBINOP-1V3\<^bsub>(A)\<^esub> & F be commutativeBINOP-1V1\<^bsub>(A)\<^esub>) & F be associativeBINOP-1V2\<^bsub>(A)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(A)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,A) holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f))"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of A holds F be idempotentBINOP-1V3\<^bsub>(A)\<^esub> & ((F be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & F be associativeBINOP-1V2\<^bsub>(A)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(A)\<^esub>) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,A) holds F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of A"
    assume A1: "F be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
      and A2: "F be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & F be associativeBINOP-1V2\<^bsub>(A)\<^esub>"
      and A3: "F be having-a-unitySETWISEOV1\<^bsub>(A)\<^esub>"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,A)"
    have "B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
    proof(rule impI)
      assume A4: "B =XBOOLE-0R4 {}XBOOLE-0K1"
      then have "f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B =XBOOLE-0R4 {}.SETWISEOK1 Y"
         sorry
      then have A5: "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(A)\<^esub> F"
        using A2 A3 setwiseo_th_31 sorry
      have "B =XBOOLE-0R4 {}.SETWISEOK1 X"
        using A4 sorry
      thus "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
        using A2 A3 A5 setwiseo_th_31 sorry
    qed
    thus "F $$SETWISEOK10\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,A)\<^esub> f)"
      using A1 A2 setwiseo_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_36:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds ((F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub> implies ( for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds ((G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub>) & G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G & ( for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f))))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of Y holds (F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>) & (F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>) implies ( for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds (G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & (G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub> & G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub>) implies ( for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,Z) holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G & ( for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of Y"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(Y)\<^esub> & F be associativeBINOP-1V2\<^bsub>(Y)\<^esub>"
      and A2: "F be idempotentBINOP-1V3\<^bsub>(Y)\<^esub>"
      and A3: "F be having-a-unitySETWISEOV1\<^bsub>(Y)\<^esub>"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of Z"
    assume A4: "G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>"
      and A5: "G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub>"
      and A6: "G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,Z)"
    assume A7: "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G"
      and A8: " for x be ElementSUBSET-1M1-of Y holds  for y be ElementSUBSET-1M1-of Y holds g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F .BINOP-1K4\<^bsub>(Y)\<^esub>(x,y)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> y)"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    show "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
    proof-
      have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
      proof(rule impI)
        assume "B =XBOOLE-0R4 {}XBOOLE-0K1"
        then have A9: "B =XBOOLE-0R4 {}.SETWISEOK1 X"
           sorry
        then have "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(Y)\<^esub> F"
          using A1 A3 setwiseo_th_31 sorry
        also have "... = G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
          using A4 A6 A7 A9 setwiseo_th_31 sorry
        finally show "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
           sorry
      qed
      have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
      proof(rule impI)
        assume "B <>HIDDENR2 {}XBOOLE-0K1"
        thus "g .FUNCT-2K3\<^bsub>(Y,Z)\<^esub> (F $$SETWISEOK10\<^bsub>(X,Y)\<^esub>(B,f)) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,Z)\<^esub> f)"
          using A1 A2 A4 A5 A8 setwiseo_th_30 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setwiseo_def_4 ("FinUnionSETWISEOK12  _ " [250]250 ) where
  mlet "A be setHIDDENM2"
"func FinUnionSETWISEOK12 A \<rightarrow> BinOpBINOP-1M2-of FinFINSUB-1K5 A means
  \<lambda>it.  for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds it .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of FinFINSUB-1K5 A st  for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds it .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y"
    proof-
      have " not ( for VarFor1 be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds  not ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds VarFor1 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y))"
      proof-
        let ?U = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 \\/SETWISEOK8\<^bsub>(A)\<^esub> Lamb2"
        have " ex IT be BinOpBINOP-1M2-of FinFINSUB-1K5 A st  for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 ?U(x,y)"
          using binop_1_sch_4 sorry
        thus " not ( for VarFor1 be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds  not ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds VarFor1 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds  for it2 be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds it1 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y) & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds it2 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds  for IT9 be BinOpBINOP-1M2-of FinFINSUB-1K5 A holds ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y) & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT9 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y) implies IT =BINOP-1R13\<^bsub>(FinFINSUB-1K5 A,FinFINSUB-1K5 A,FinFINSUB-1K5 A)\<^esub> IT9"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT assume [ty]: "IT be BinOpBINOP-1M2-of FinFINSUB-1K5 A"
        fix IT9 assume [ty]: "IT9 be BinOpBINOP-1M2-of FinFINSUB-1K5 A"
        assume A1: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y"
          and A2: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT9 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =XBOOLE-0R4 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y"
        have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 IT9 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y)"
        proof(rule ballI,rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
          fix y assume [ty]: "y be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
          have "IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 x \\/SETWISEOK8\<^bsub>(A)\<^esub> y"
            using A1 sorry
          also have "... = IT9 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y)"
            using A2 sorry
          finally show "IT .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 IT9 .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y)"
             sorry
        qed "sorry"
        thus "IT =BINOP-1R13\<^bsub>(FinFINSUB-1K5 A,FinFINSUB-1K5 A,FinFINSUB-1K5 A)\<^esub> IT9"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

reserve A for "setHIDDENM2"
reserve x, y, z for "ElementSUBSET-1M1-of FinFINSUB-1K5 A"
mtheorem setwiseo_th_37:
" for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
proof-
  have " for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,x) =HIDDENR1 x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      have "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,x) =HIDDENR1 x \\/SETWISEOK8\<^bsub>(A)\<^esub> x"
        using setwiseo_def_4 sorry
      also have "... = x"
         sorry
      finally show "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,x) =HIDDENR1 x"
         sorry
    qed "sorry"
    thus "FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using binop_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_38:
" for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
proof-
  have " for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,x)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      fix y assume [ty]: "y be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      have "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 y \\/SETWISEOK8\<^bsub>(A)\<^esub> x"
        using setwiseo_def_4 sorry
      also have "... = FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,x)"
        using setwiseo_def_4 sorry
      finally show "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,x)"
         sorry
    qed "sorry"
    thus "FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using binop_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_39:
" for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
proof-
  have " for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds  for z be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y),z) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,z))"
    proof(rule ballI,rule ballI,rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      fix y assume [ty]: "y be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      fix z assume [ty]: "z be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
      have "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y),z) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x \\/SETWISEOK8\<^bsub>(A)\<^esub> y,z)"
        using setwiseo_def_4 sorry
      also have "... = (x \\/SETWISEOK8\<^bsub>(A)\<^esub> y)\\/SETWISEOK8\<^bsub>(A)\<^esub> z"
        using setwiseo_def_4 sorry
      also have "... = x \\/SETWISEOK8\<^bsub>(A)\<^esub> (y \\/SETWISEOK8\<^bsub>(A)\<^esub> z)"
        using xboole_1_th_4 sorry
      also have "... = FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y \\/SETWISEOK8\<^bsub>(A)\<^esub> z)"
        using setwiseo_def_4 sorry
      also have "... = FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,z))"
        using setwiseo_def_4 sorry
      finally show "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,y),z) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(y,z))"
         sorry
    qed "sorry"
    thus "FinUnionSETWISEOK12 A be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using binop_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_40:
" for A be setHIDDENM2 holds {}.SETWISEOK1 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
proof-
  have " for A be setHIDDENM2 holds {}.SETWISEOK1 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>({}.SETWISEOK1 A,x) =XBOOLE-0R4 x) & {}.SETWISEOK1 A is-a-right-unity-wrtBINOP-1R2\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
    proof(rule conjMI)
      show " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>({}.SETWISEOK1 A,x) =XBOOLE-0R4 x"
      proof-
        have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>({}.SETWISEOK1 A,x) =HIDDENR1 x"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
          have "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>({}.SETWISEOK1 A,x) =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 x"
            using setwiseo_def_4 sorry
          also have "... = x"
             sorry
          finally show "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>({}.SETWISEOK1 A,x) =HIDDENR1 x"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 A holds FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,{}.SETWISEOK1 A) =HIDDENR1 x"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
        have "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,{}.SETWISEOK1 A) =HIDDENR1 x \\/XBOOLE-0K2 {}XBOOLE-0K1"
          using setwiseo_def_4 sorry
        also have "... = x"
           sorry
        finally show "FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(x,{}.SETWISEOK1 A) =HIDDENR1 x"
           sorry
      qed "sorry"
      thus "{}.SETWISEOK1 A is-a-right-unity-wrtBINOP-1R2\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
        using binop_1_def_17 sorry
    qed
    thus "{}.SETWISEOK1 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
      using binop_1_def_7 binop_1_def_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_41:
" for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be having-a-unitySETWISEOV1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
proof-
  have " for A be setHIDDENM2 holds FinUnionSETWISEOK12 A be having-a-unitySETWISEOV1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "{}.SETWISEOK1 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
      using setwiseo_th_40 sorry
    thus "FinUnionSETWISEOK12 A be having-a-unitySETWISEOV1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_42:
" for A be setHIDDENM2 holds the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
  using setwiseo_th_14 setwiseo_th_41 sorry

mtheorem setwiseo_th_43:
" for A be setHIDDENM2 holds the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for A be setHIDDENM2 holds the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A =XBOOLE-0R4 {}XBOOLE-0K1"
  proof(rule ballI)
    fix A assume [ty]: "A be setHIDDENM2"
    have "{}.SETWISEOK1 A is-a-unity-wrtBINOP-1R3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
      using setwiseo_th_40 sorry
    thus "the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A =XBOOLE-0R4 {}XBOOLE-0K1"
      using binop_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve X, Y for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve A for "setHIDDENM2"
reserve f for "FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
reserve i, j, k for "ElementSUBSET-1M1-of X"
mdef setwiseo_def_5 ("FinUnionSETWISEOK13\<^bsub>'( _ , _ ')\<^esub>'( _ , _ ')" [0,0,0,0]250 ) where
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "A be setHIDDENM2", "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X", "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
"func FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) \<rightarrow> ElementSUBSET-1M1-of FinFINSUB-1K5 A equals
  FinUnionSETWISEOK12 A $$SETWISEOK10\<^bsub>(X,FinFINSUB-1K5 A)\<^esub>(B,f)"
proof-
  (*coherence*)
    show "FinUnionSETWISEOK12 A $$SETWISEOK10\<^bsub>(X,FinFINSUB-1K5 A)\<^esub>(B,f) be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
       sorry
qed "sorry"

mtheorem setwiseo_th_44:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
    have "FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_38 sorry
    thus "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
      using setwiseo_th_17 setwiseo_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_45:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for j be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> i,j .},f) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for j be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> i,j .},f) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
    fix j assume [ty]: "j be ElementSUBSET-1M1-of X"
    have "FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub> & FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_37 setwiseo_th_38 sorry
    then have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> i,j .},f) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i,f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j)"
      using setwiseo_th_18 setwiseo_th_39 sorry
    also have "... = f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j"
      using setwiseo_def_4 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK6\<^bsub>(X)\<^esub> i,j .},f) =HIDDENR1 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_46:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for j be ElementSUBSET-1M1-of X holds  for k be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> i,j,k .},f) =XBOOLE-0R4 (f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j)\\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for j be ElementSUBSET-1M1-of X holds  for k be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> i,j,k .},f) =HIDDENR1 (f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j)\\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
    fix j assume [ty]: "j be ElementSUBSET-1M1-of X"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of X"
    have "FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub> & FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_37 setwiseo_th_38 sorry
    then have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> i,j,k .},f) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i,f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j),f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k)"
      using setwiseo_th_19 setwiseo_th_39 sorry
    also have "... = FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j,f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k)"
      using setwiseo_def_4 sorry
    also have "... = (f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j)\\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k"
      using setwiseo_def_4 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({.SETWISEOK7\<^bsub>(X)\<^esub> i,j,k .},f) =HIDDENR1 (f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> j)\\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_47:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({}.SETWISEOK1 X,f) =HIDDENR1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    have "FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub> & FinUnionSETWISEOK12 A be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_38 setwiseo_th_39 sorry
    then have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({}.SETWISEOK1 X,f) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 A)\<^esub> FinUnionSETWISEOK12 A"
      using setwiseo_th_31 setwiseo_th_41 sorry
    also have "... = {}XBOOLE-0K1"
      using setwiseo_th_43 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({}.SETWISEOK1 X,f) =HIDDENR1 {}XBOOLE-0K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_48:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for i be ElementSUBSET-1M1-of X holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have A1: "FinUnionSETWISEOK12 A be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_39 sorry
    have "FinUnionSETWISEOK12 A be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 A)\<^esub> & FinUnionSETWISEOK12 A be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 A)\<^esub>"
      using setwiseo_th_37 setwiseo_th_38 sorry
    then have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 FinUnionSETWISEOK12 A .BINOP-1K4\<^bsub>(FinFINSUB-1K5 A)\<^esub>(FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i)"
      using A1 setwiseo_th_32 setwiseo_th_41 sorry
    also have "... = FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
      using setwiseo_def_4 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_49:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    let ?X = "\<lambda>Lamb1. FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(Lamb1,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> Lamb1)"
    have A1: " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for i be ElementSUBSET-1M1-of X holds ?X(B) implies ?X(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.})"
    proof-
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for i be ElementSUBSET-1M1-of X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B) implies FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 unionTARSKIK3 (f .:RELSET-1K7\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> (B \\/XBOOLE-0K2 {TARSKIK1 i}))"
      proof(rule ballI,rule ballI,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
        fix i assume [ty]: "i be ElementSUBSET-1M1-of X"
        assume "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
        then have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B) \\/XBOOLE-0K2 unionTARSKIK3 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i }"
          using setwiseo_th_48 sorry
        also have "... = unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B \\/XBOOLE-0K2 {TARSKIK1 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i })"
          using zfmisc_1_th_78 sorry
        also have "... = unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B \\/XBOOLE-0K2 ImRELAT-1K12(f,i))"
          using setwiseo_th_8 sorry
        also have "... = unionTARSKIK3 (f .:RELSET-1K7\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> (B \\/XBOOLE-0K2 {TARSKIK1 i}))"
          using relat_1_th_120 sorry
        finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B \\/SETWISEOK8\<^bsub>(X)\<^esub> {.SETWISEOK5\<^bsub>(X)\<^esub> i.},f) =HIDDENR1 unionTARSKIK3 (f .:RELSET-1K7\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> (B \\/XBOOLE-0K2 {TARSKIK1 i}))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>({}.SETWISEOK1 X,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> {}.SETWISEOK1 X)"
      using setwiseo_th_47 zfmisc_1_th_2 sorry
    then have A2: "?X({}.SETWISEOK1 X)"
       sorry
    show " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) =XBOOLE-0R4 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
      using setwiseo_sch_4 A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_50:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B2,f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B2,f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix B1 assume [ty]: "B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix B2 assume [ty]: "B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> (B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2))"
      using setwiseo_th_49 sorry
    also have "... = unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B1 \\/SETWISEOK8\<^bsub>(FinFINSUB-1K5 A)\<^esub> f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B2)"
      using relat_1_th_120 sorry
    also have "... = unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B1) \\/XBOOLE-0K2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B2)"
      using zfmisc_1_th_78 sorry
    also have "... = FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1,f) \\/XBOOLE-0K2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B2)"
      using setwiseo_th_49 sorry
    also have "... = FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B2,f)"
      using setwiseo_th_49 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(X)\<^esub> B2,f) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B1,f) \\/SETWISEOK8\<^bsub>(A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B2,f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_51:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,FinFINSUB-1K5 A) holds FinUnionSETWISEOK13\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,FinFINSUB-1K5 A)\<^esub> f)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for f be FunctionFUNCT-2M1-of(X,Y) holds  for g be FunctionFUNCT-2M1-of(Y,FinFINSUB-1K5 A) holds FinUnionSETWISEOK13\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,FinFINSUB-1K5 A)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(Y,FinFINSUB-1K5 A)"
    have "FinUnionSETWISEOK13\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =HIDDENR1 unionTARSKIK3 (g .:SETWISEOK11\<^bsub>(Y,FinFINSUB-1K5 A)\<^esub> (f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B))"
      using setwiseo_th_49 sorry
    also have "... = unionTARSKIK3 ((g *PARTFUN1K1\<^bsub>(X,Y,Y,FinFINSUB-1K5 A)\<^esub> f).:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
      using relat_1_th_126 sorry
    also have "... = FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,FinFINSUB-1K5 A)\<^esub> f)"
      using setwiseo_th_49 sorry
    finally show "FinUnionSETWISEOK13\<^bsub>(Y,A)\<^esub>(f .:SETWISEOK11\<^bsub>(X,Y)\<^esub> B,g) =HIDDENR1 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,Y,Y,FinFINSUB-1K5 A)\<^esub> f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_52:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for G be BinOpBINOP-1M2-of A holds (G be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & G be associativeBINOP-1V2\<^bsub>(A)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(A)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds B <>HIDDENR2 {}XBOOLE-0K1 implies ( for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y) holds  for g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,A) holds ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(A)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> y)) implies g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,A)\<^esub> f)))"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix G assume [ty]: "G be BinOpBINOP-1M2-of A"
  assume A1: "(G be commutativeBINOP-1V1\<^bsub>(A)\<^esub> & G be associativeBINOP-1V2\<^bsub>(A)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(A)\<^esub>"
  fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
  assume A2: "B <>HIDDENR2 {}XBOOLE-0K1"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y)"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,A)"
  assume A3: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(A)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> y)"
  have A4: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (FinUnionSETWISEOK12 Y .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Y)\<^esub>(x,y)) =HIDDENR1 G .BINOP-1K4\<^bsub>(A)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
    have "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (FinUnionSETWISEOK12 Y .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Y)\<^esub>(x,y)) =HIDDENR1 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y)"
      using setwiseo_def_4 sorry
    also have "... = G .BINOP-1K4\<^bsub>(A)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> y)"
      using A3 sorry
    finally show "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> (FinUnionSETWISEOK12 Y .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Y)\<^esub>(x,y)) =HIDDENR1 G .BINOP-1K4\<^bsub>(A)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> y)"
       sorry
  qed "sorry"
  have A5: "FinUnionSETWISEOK12 Y be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 Y)\<^esub>"
    using setwiseo_th_37 sorry
  have "FinUnionSETWISEOK12 Y be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 Y)\<^esub> & FinUnionSETWISEOK12 Y be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 Y)\<^esub>"
    using setwiseo_th_38 setwiseo_th_39 sorry
  thus "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,A)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,A)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,A)\<^esub> f)"
    using A1 A5 A2 A4 setwiseo_th_30 sorry
qed "sorry"

mtheorem setwiseo_th_53:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds ((G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub>) & G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub> implies ( for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y) holds  for g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,Z) holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for G be BinOpBINOP-1M2-of Z holds (G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>) & (G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub> & G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub>) implies ( for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y) holds  for g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,Z) holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> y)) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Z assume [ty]: "Z be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of Z"
    assume A1: "G be commutativeBINOP-1V1\<^bsub>(Z)\<^esub> & G be associativeBINOP-1V2\<^bsub>(Z)\<^esub>"
      and A2: "G be idempotentBINOP-1V3\<^bsub>(Z)\<^esub>"
      and A3: "G be having-a-unitySETWISEOV1\<^bsub>(Z)\<^esub>"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,Z)"
    assume A4: "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(Z)\<^esub> G"
      and A5: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> y)"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have A6: "{}XBOOLE-0K1 =RELAT-1R1 {}.SETWISEOK1 X"
       sorry
    have A7: "{}XBOOLE-0K1 =RELAT-1R1 {}.SETWISEOK1 (FinFINSUB-1K5 Y)"
       sorry
    show "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
    proof-
      have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
      proof(rule impI)
        assume A8: "B =XBOOLE-0R4 {}XBOOLE-0K1"
        then have A9: "f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 Y)\<^esub> B =XBOOLE-0R4 {}XBOOLE-0K1"
           sorry
        have "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =HIDDENR1 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> {}.SETWISEOK1 Y"
          using A6 A8 setwiseo_th_47 sorry
        also have "... = G $$SETWISEOK10\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub>(f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 Y)\<^esub> B,g)"
          using A1 A3 A4 A7 A9 setwiseo_th_31 sorry
        also have "... = G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
          using A1 A2 A3 setwiseo_th_35 sorry
        finally show "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =HIDDENR1 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
           sorry
      qed
      have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
      proof(rule impI)
        assume "B <>HIDDENR2 {}XBOOLE-0K1"
        thus "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 G $$SETWISEOK10\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,Z)\<^esub> f)"
          using A1 A2 A5 setwiseo_th_52 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setwiseo_def_6 ("singletonSETWISEOK14  _ " [250]250 ) where
  mlet "A be setHIDDENM2"
"func singletonSETWISEOK14 A \<rightarrow> FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) st  for x be objectHIDDENM1 holds x inHIDDENR3 A implies it .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
    proof-
      have " ex f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) st  for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
      proof-
        let ?U = "\<lambda>Lamb1. {TARSKIK1 Lamb1}"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A implies {TARSKIK1 x} inTARSKIR2 FinFINSUB-1K5 A"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A2: "x inHIDDENR3 A"
          then obtain A9 where 
            [ty]:"A9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and A9Def:"A9 = A"
             sorry
          obtain x9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of A9" and x9Def:"x9 = x"
            using A2 sorry
          have "{.SETWISEOK5\<^bsub>(A9)\<^esub> x9.} inTARSKIR2 FinFINSUB-1K5 A9"
             sorry
          thus "{TARSKIK1 x} inTARSKIR2 FinFINSUB-1K5 A"
             sorry
        qed "sorry"
        show " ex f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) st  for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
          using funct_2_sch_2 A1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds  for it2 be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A implies it1 .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}) & ( for x be objectHIDDENM1 holds x inHIDDENR3 A implies it2 .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds  for IT9 be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds ( for x be objectHIDDENM1 holds x inHIDDENR3 A implies IT .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}) & ( for x be objectHIDDENM1 holds x inHIDDENR3 A implies IT9 .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}) implies IT =HIDDENR1 IT9"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT assume [ty]: "IT be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A)"
        fix IT9 assume [ty]: "IT9 be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A)"
        assume A3: " for x be objectHIDDENM1 holds x inHIDDENR3 A implies IT .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
          and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 A implies IT9 .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies IT .FUNCT-1K1 x =XBOOLE-0R4 IT9 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 A"
          then have "IT .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
            using A3 sorry
          thus "IT .FUNCT-1K1 x =XBOOLE-0R4 IT9 .FUNCT-1K1 x"
            using A4 A5 sorry
        qed "sorry"
        thus "IT =HIDDENR1 IT9"
          using funct_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem setwiseo_th_54:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds f =FUNCT-2R2\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> singletonSETWISEOK14 A iff ( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> x =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A) holds (f =FUNCT-2R2\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> singletonSETWISEOK14 A implies ( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> x =XBOOLE-0R4 {TARSKIK1 x})) & (( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> x =XBOOLE-0R4 {TARSKIK1 x}) implies f =FUNCT-2R2\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> singletonSETWISEOK14 A)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,FinFINSUB-1K5 A)"
    show "f =FUNCT-2R2\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> singletonSETWISEOK14 A implies ( for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> x =XBOOLE-0R4 {TARSKIK1 x})"
      using setwiseo_def_6 sorry
    assume " for x be ElementSUBSET-1M1-of A holds f .FUNCT-2K3\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> x =XBOOLE-0R4 {TARSKIK1 x}"
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies f .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x}"
       sorry
    thus "f =FUNCT-2R2\<^bsub>(A,FinFINSUB-1K5 A)\<^esub> singletonSETWISEOK14 A"
      using setwiseo_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_55:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be ElementSUBSET-1M1-of X holds x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y iff x =XBOOLE-0R4 y"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be setHIDDENM2 holds  for y be ElementSUBSET-1M1-of X holds  not (x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y &  not x =XBOOLE-0R4 y) &  not (x =XBOOLE-0R4 y &  not x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of X"
    have "singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y =XBOOLE-0R4 {TARSKIK1 y}"
      using setwiseo_th_54 sorry
    thus " not (x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y &  not x =XBOOLE-0R4 y) &  not (x =XBOOLE-0R4 y &  not x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> y)"
      using tarski_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_56:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds  for z be ElementSUBSET-1M1-of X holds x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z & y inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z implies x =XBOOLE-0R4 y"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of X holds  for z be ElementSUBSET-1M1-of X holds x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z & y inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z implies x =XBOOLE-0R4 y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of X"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of X"
    fix z assume [ty]: "z be ElementSUBSET-1M1-of X"
    assume A1: "x inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z"
      and A2: "y inTARSKIR2 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> z"
    have "x =XBOOLE-0R4 z"
      using A1 setwiseo_th_55 sorry
    thus "x =XBOOLE-0R4 y"
      using A2 setwiseo_th_55 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma setwiseo_lm_2:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be setHIDDENM2 holds  for P be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,D) holds f .:RELSET-1K7\<^bsub>(X,D)\<^esub> P c=TARSKIR1 D"
   sorry

mtheorem setwiseo_th_57:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be setHIDDENM2 holds x inTARSKIR2 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) iff ( ex i be ElementSUBSET-1M1-of X st i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i)"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A) holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds  for x be setHIDDENM2 holds  not (x inTARSKIR2 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) & ( for i be ElementSUBSET-1M1-of X holds  not (i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i))) &  not ( not ( for i be ElementSUBSET-1M1-of X holds  not (i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i)) &  not x inTARSKIR2 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 A)"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    fix x assume [ty]: "x be setHIDDENM2"
    have A1: "x inTARSKIR2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B) implies ( ex i9 be ElementSUBSET-1M1-of X st i9 inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i9)"
    proof(rule impI)
      assume "x inTARSKIR2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
      then obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A2: "x inTARSKIR2 Z"and A3: "Z inTARSKIR2 f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B"
        using tarski_def_4 sorry
      have "f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B be SubsetSUBSET-1M2-of FinFINSUB-1K5 A"
        using setwiseo_lm_2 sorry
      then have 
        [ty]:"Z be ElementSUBSET-1M1-of FinFINSUB-1K5 A"
        using A3 sorry
      obtain i where
        [ty]:"i be ElementSUBSET-1M1-of X" and 
        A4: "i inTARSKIR2 B & Z =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
        using A3 funct_2_th_65 sorry
      obtain i9 where 
        [ty]:"i9 be ElementSUBSET-1M1-of X" and i9Def:"i9 = i"
         sorry
      show " ex i9 be ElementSUBSET-1M1-of X st i9 inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i9"
      proof(rule bexI[of _ "i9"])
        show "i9 inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i9"
          using A2 A4 sorry
      qed "sorry"
    qed
    have "( ex i be ElementSUBSET-1M1-of X st i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i) implies x inTARSKIR2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
    proof(rule impI)
      assume Given: " ex i be ElementSUBSET-1M1-of X st i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
      then obtain i where
        [ty]:"i be ElementSUBSET-1M1-of X" and 
        A5: "i inTARSKIR2 B"and A6: "x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i"
         sorry
      have "f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i inTARSKIR2 f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B"
        using A5 funct_2_th_35 sorry
      thus "x inTARSKIR2 unionTARSKIK3 (f .:SETWISEOK11\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> B)"
        using A6 tarski_def_4 sorry
    qed
    thus " not (x inTARSKIR2 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f) & ( for i be ElementSUBSET-1M1-of X holds  not (i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i))) &  not ( not ( for i be ElementSUBSET-1M1-of X holds  not (i inTARSKIR2 B & x inTARSKIR2 f .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 A)\<^esub> i)) &  not x inTARSKIR2 FinUnionSETWISEOK13\<^bsub>(X,A)\<^esub>(B,f))"
      using A1 setwiseo_th_49 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_58:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X) =XBOOLE-0R4 B"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X) =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have " for x be objectHIDDENM1 holds (x inHIDDENR3 FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X) implies x inHIDDENR3 B) & (x inHIDDENR3 B implies x inHIDDENR3 FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X))"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X) implies x inHIDDENR3 B"
      proof(rule impI)
        assume "x inHIDDENR3 FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X)"
        then have " ex i be ElementSUBSET-1M1-of X st i inTARSKIR2 B & x inHIDDENR3 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> i"
          using setwiseo_th_57 sorry
        thus "x inHIDDENR3 B"
          using setwiseo_th_55 sorry
      qed
      assume A1: "x inHIDDENR3 B"
      then obtain x9 where 
        [ty]:"x9 be ElementSUBSET-1M1-of X" and x9Def:"x9 = x"
        using setwiseo_th_9 sorry
      have "x inHIDDENR3 singletonSETWISEOK14 X .FUNCT-2K3\<^bsub>(X,FinFINSUB-1K5 X)\<^esub> x9"
        using setwiseo_th_55 sorry
      thus "x inHIDDENR3 FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X)"
        using A1 setwiseo_th_57 sorry
    qed "sorry"
    thus "FinUnionSETWISEOK13\<^bsub>(X,X)\<^esub>(B,singletonSETWISEOK14 X) =XBOOLE-0R4 B"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwiseo_th_59:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y) holds  for g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z) holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 {}.SETWISEOK1 Z & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x \\/SETWISEOK8\<^bsub>(Z)\<^esub> g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> f))"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y) holds  for g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z) holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 {}.SETWISEOK1 Z & ( for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x \\/SETWISEOK8\<^bsub>(Z)\<^esub> g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y) implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 X holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(X,FinFINSUB-1K5 Y)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)"
    assume A1: "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 {}.SETWISEOK1 Z"
      and A2: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =XBOOLE-0R4 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x \\/SETWISEOK8\<^bsub>(Z)\<^esub> g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y"
    have A3: "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> {}.SETWISEOK1 Y =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(FinFINSUB-1K5 Z)\<^esub> FinUnionSETWISEOK12 Z"
      using A1 setwiseo_th_43 sorry
    have A4: " for x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds  for y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y holds g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =HIDDENR1 FinUnionSETWISEOK12 Z .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y)"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
      fix y assume [ty]: "y be ElementSUBSET-1M1-of FinFINSUB-1K5 Y"
      have "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =HIDDENR1 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x \\/SETWISEOK8\<^bsub>(Z)\<^esub> g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y"
        using A2 sorry
      also have "... = FinUnionSETWISEOK12 Z .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y)"
        using setwiseo_def_4 sorry
      finally show "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> (x \\/SETWISEOK8\<^bsub>(Y)\<^esub> y) =HIDDENR1 FinUnionSETWISEOK12 Z .BINOP-1K4\<^bsub>(FinFINSUB-1K5 Z)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> x,g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> y)"
         sorry
    qed "sorry"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 X"
    have A5: "FinUnionSETWISEOK12 Z be idempotentBINOP-1V3\<^bsub>(FinFINSUB-1K5 Z)\<^esub>"
      using setwiseo_th_37 sorry
    have "FinUnionSETWISEOK12 Z be associativeBINOP-1V2\<^bsub>(FinFINSUB-1K5 Z)\<^esub> & FinUnionSETWISEOK12 Z be commutativeBINOP-1V1\<^bsub>(FinFINSUB-1K5 Z)\<^esub>"
      using setwiseo_th_38 setwiseo_th_39 sorry
    thus "g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> FinUnionSETWISEOK13\<^bsub>(X,Y)\<^esub>(B,f) =XBOOLE-0R4 FinUnionSETWISEOK13\<^bsub>(X,Z)\<^esub>(B,g *PARTFUN1K1\<^bsub>(X,FinFINSUB-1K5 Y,FinFINSUB-1K5 Y,FinFINSUB-1K5 Z)\<^esub> f)"
      using A5 A3 A4 setwiseo_th_41 setwiseo_th_53 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
