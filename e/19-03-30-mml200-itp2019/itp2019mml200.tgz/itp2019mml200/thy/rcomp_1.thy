theory rcomp_1
  imports seq_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, n1, m, k for "NatNAT-1M1"
reserve s, g, g1, g2, r, p, p2, q, t for "RealXREAL-0M1"
reserve s1, s2, s3 for "Real-SequenceSEQ-1M1"
reserve Nseq for "increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
reserve X for "SubsetSUBSET-1M2-of REALNUMBERSK2"
abbreviation(input) RCOMP_1K1("[.RCOMP-1K1 _ , _ .]" [0,0]164) where
  "[.RCOMP-1K1 g,s .] \<equiv> [.XXREAL-1K1 g,s .]"

mtheorem rcomp_1_def_1:
  mlet "g be RealXREAL-0M1", "s be RealXREAL-0M1"
"redefine func [.RCOMP-1K1 g,s .] \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K1 g,s .] iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
  proof-
    have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =HIDDENR1 [.XXREAL-1K1 g,s .] &  not X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s } &  not X =HIDDENR1 [.XXREAL-1K1 g,s .])"
    proof(rule ballI)
      let ?Y = "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
      fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      have A2: "[.XXREAL-1K1 g,s .] c=TARSKIR1 ?Y"
      proof-
        have "[.XXREAL-1K1 g,s .] c=TARSKIR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 [.XXREAL-1K1 g,s .] implies x inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 [.XXREAL-1K1 g,s .]"
            then obtain r where
              [ty]:"r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3" and 
              A3: "x =HIDDENR1 r"and A4: "g <=XXREAL-0R1 r & r <=XXREAL-0R1 s"
               sorry
            have "g inHIDDENR3 REALNUMBERSK2 & s inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            then have "r inTARSKIR2 REALNUMBERSK2"
              using A4 xxreal_0_th_45 sorry
            thus "x inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
              using A3 A4 sorry
          qed "sorry"
          thus "[.XXREAL-1K1 g,s .] c=TARSKIR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "?Y c=TARSKIR1 [.XXREAL-1K1 g,s .]"
      proof-
        have "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s } c=TARSKIR1 [.XXREAL-1K1 g,s .]"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s } implies x inHIDDENR3 [.XXREAL-1K1 g,s .]"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?Y"
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A5: "(x =HIDDENR1 r & g <=XXREAL-0R1 r) & r <=XXREAL-0R1 s"
               sorry
            have "r inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "x inHIDDENR3 [.XXREAL-1K1 g,s .]"
              using A5 numbers_th_31 sorry
          qed "sorry"
          thus "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s } c=TARSKIR1 [.XXREAL-1K1 g,s .]"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not (X =HIDDENR1 [.XXREAL-1K1 g,s .] &  not X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <=XXREAL-0R1 s } &  not X =HIDDENR1 [.XXREAL-1K1 g,s .])"
        using A2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rcomp_1_add_1:
  mlet "g be RealXREAL-0M1", "s be RealXREAL-0M1"
"cluster [.XXREAL-1K1 g,s .] as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "[.XXREAL-1K1 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 [.XXREAL-1K1 g,s .] implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 [.XXREAL-1K1 g,s .]"
      then have A1: " ex r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 r & g <=XXREAL-0R1 r) & r <=XXREAL-0R1 s"
         sorry
      have "g inHIDDENR3 REALNUMBERSK2 & s inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_45 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using tarski_def_3 sorry
  qed
qed "sorry"

abbreviation(input) RCOMP_1K2("].RCOMP-1K2 _ , _ .[" [0,0]164) where
  "].RCOMP-1K2 g,s .[ \<equiv> ].XXREAL-1K4 g,s .["

mtheorem rcomp_1_def_2:
  mlet "g be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"redefine func ].RCOMP-1K2 g,s .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K2 g,s .[ iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s }"
  proof-
    have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =HIDDENR1 ].XXREAL-1K4 g,s .[ &  not X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s } &  not X =HIDDENR1 ].XXREAL-1K4 g,s .[)"
    proof(rule ballI)
      let ?Y = "{r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s }"
      fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      have A1: "?Y c=TARSKIR1 ].XXREAL-1K4 g,s .["
      proof-
        have "{r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s } c=TARSKIR1 ].XXREAL-1K4 g,s .["
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <XXREAL-0R3 s } implies x inHIDDENR3 ].XXREAL-1K4 g,s .["
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?Y"
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A2: "(x =HIDDENR1 r & g <XXREAL-0R3 r) & r <XXREAL-0R3 s"
               sorry
            have "r inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "x inHIDDENR3 ].XXREAL-1K4 g,s .["
              using A2 numbers_th_31 sorry
          qed "sorry"
          thus "{r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s } c=TARSKIR1 ].XXREAL-1K4 g,s .["
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "].XXREAL-1K4 g,s .[ c=TARSKIR1 ?Y"
      proof-
        have "].XXREAL-1K4 g,s .[ c=TARSKIR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K4 g,s .[ implies x inHIDDENR3 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ].XXREAL-1K4 g,s .["
            then obtain r where
              [ty]:"r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3" and 
              A3: "x =HIDDENR1 r"and A4: "g <XXREAL-0R3 r & r <XXREAL-0R3 s"
               sorry
            have "r inTARSKIR2 REALNUMBERSK2"
              using A4 xxreal_0_th_48 sorry
            thus "x inHIDDENR3 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }"
              using A3 A4 sorry
          qed "sorry"
          thus "].XXREAL-1K4 g,s .[ c=TARSKIR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not (X =HIDDENR1 ].XXREAL-1K4 g,s .[ &  not X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r &  not r <XXREAL-0R3 s } &  not X =HIDDENR1 ].XXREAL-1K4 g,s .[)"
        using A1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rcomp_1_add_2:
  mlet "g be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 g,s .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K4 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have " for x be objectHIDDENM1 holds x inHIDDENR3 ].XXREAL-1K4 g,s .[ implies x inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 ].XXREAL-1K4 g,s .["
      then have " ex r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (x =HIDDENR1 r & g <XXREAL-0R3 r) & r <XXREAL-0R3 s"
         sorry
      thus "x inHIDDENR3 REALNUMBERSK2"
        using xxreal_0_th_48 sorry
    qed "sorry"
    thus "].XXREAL-1K4 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using tarski_def_3 sorry
  qed
qed "sorry"

mtheorem rcomp_1_th_1:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[ iff  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
proof-
  have " for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds (r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[ implies  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g) & ( |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g implies r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    show "r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[ implies  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
    proof-
      have "r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .[ implies  not  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
      proof(rule impI)
        assume "r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .["
        then have A1: " ex s be RealXREAL-0M1 st (r =COMPLEX1R1 s & p -XCMPLX-0K6 g <XXREAL-0R3 s) & s <XXREAL-0R3 p +XCMPLX-0K2 g"
           sorry
        then have "p +XCMPLX-0K2 (-XCMPLX-0K4 g) <XXREAL-0R3 r"
           sorry
        then have A2: "-XCMPLX-0K4 g <XXREAL-0R3 r -XCMPLX-0K6 p"
          using xreal_1_th_20 sorry
        have "r -XCMPLX-0K6 p <XXREAL-0R3 g"
          using A1 xreal_1_th_19 sorry
        thus " not  |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
          using A2 seq_2_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: " |.COMPLEX1K10 r -XCMPLX-0K6 p .| <XXREAL-0R3 g"
    then have "r -XCMPLX-0K6 p <XXREAL-0R3 g"
      using seq_2_th_1 sorry
    then have A4: "r <XXREAL-0R3 p +XCMPLX-0K2 g"
      using xreal_1_th_19 sorry
    have "-XCMPLX-0K4 g <XXREAL-0R3 r -XCMPLX-0K6 p"
      using A3 seq_2_th_1 sorry
    then have "r be RealXREAL-0M1 & p +XCMPLX-0K2 (-XCMPLX-0K4 g) <XXREAL-0R3 r"
      using xreal_1_th_20 sorry
    thus "r inHIDDENR3 ].RCOMP-1K2 p -XCMPLX-0K6 g,p +XCMPLX-0K2 g .["
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_2:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 p,g .] iff  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p"
proof-
  have " for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds (r inHIDDENR3 [.RCOMP-1K1 p,g .] implies  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p) & ( |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p implies r inHIDDENR3 [.RCOMP-1K1 p,g .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    show "r inHIDDENR3 [.RCOMP-1K1 p,g .] implies  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p"
    proof(rule impI)
      assume "r inHIDDENR3 [.RCOMP-1K1 p,g .]"
      then have A1: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & p <=XXREAL-0R1 s) & s <=XXREAL-0R1 g"
         sorry
      then have "\<two>\<^sub>M *XCMPLX-0K3 r <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 g"
        using xreal_1_th_64 sorry
      then have "-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r >=XXREAL-0R2 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 g"
        using xreal_1_th_24 sorry
      then have "(p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r) >=XXREAL-0R2 (p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 g)"
        using xreal_1_th_7 sorry
      then have A2: "(p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r >=XXREAL-0R2 -XCMPLX-0K4 (g -XCMPLX-0K6 p)"
         sorry
      have "\<two>\<^sub>M *XCMPLX-0K3 p <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 r"
        using A1 xreal_1_th_64 sorry
      then have "-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p >=XXREAL-0R2 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r"
        using xreal_1_th_24 sorry
      then have "(p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p) >=XXREAL-0R2 (p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r)"
        using xreal_1_th_7 sorry
      thus " |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p"
        using A2 absvalue_th_5 sorry
    qed
    assume A3: " |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <=XXREAL-0R1 g -XCMPLX-0K6 p"
    then have "(p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r >=XXREAL-0R2 -XCMPLX-0K4 (g -XCMPLX-0K6 p)"
      using absvalue_th_5 sorry
    then have "p +XCMPLX-0K2 g >=XXREAL-0R2 (p -XCMPLX-0K6 g)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 r"
      using xreal_1_th_19 sorry
    then have "(p +XCMPLX-0K2 g)-XCMPLX-0K6 (p -XCMPLX-0K6 g) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 r"
      using xreal_1_th_19 sorry
    then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 g) >=XXREAL-0R2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 r)"
      using xreal_1_th_64 sorry
    have "g -XCMPLX-0K6 p >=XXREAL-0R2 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r"
      using A3 absvalue_th_5 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 r +XCMPLX-0K2 (g -XCMPLX-0K6 p) >=XXREAL-0R2 p +XCMPLX-0K2 g"
      using xreal_1_th_20 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 r >=XXREAL-0R2 (p +XCMPLX-0K2 g)-XCMPLX-0K6 (g -XCMPLX-0K6 p)"
      using xreal_1_th_20 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 r) >=XXREAL-0R2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 p)"
      using xreal_1_th_64 sorry
    thus "r inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_3:
" for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 ].RCOMP-1K2 p,g .[ iff  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
proof-
  have " for g be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds (r inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p) & ( |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p implies r inHIDDENR3 ].RCOMP-1K2 p,g .[)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    show "r inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
    proof-
      have "r inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  not  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
      proof(rule impI)
        assume "r inHIDDENR3 ].RCOMP-1K2 p,g .["
        then have A1: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & p <XXREAL-0R3 s) & s <XXREAL-0R3 g"
           sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 r <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 g"
          using xreal_1_th_68 sorry
        then have "-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r >XXREAL-0R4 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 g"
          using xreal_1_th_24 sorry
        then have "(p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r) >XXREAL-0R4 (p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 g)"
          using xreal_1_th_6 sorry
        then have A2: "(p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r >XXREAL-0R4 -XCMPLX-0K4 (g -XCMPLX-0K6 p)"
           sorry
        have "\<two>\<^sub>M *XCMPLX-0K3 p <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 r"
          using A1 xreal_1_th_68 sorry
        then have "-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p >XXREAL-0R4 -XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r"
          using xreal_1_th_24 sorry
        then have "(p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 p) >XXREAL-0R4 (p +XCMPLX-0K2 g)+XCMPLX-0K2 (-XCMPLX-0K4 \<two>\<^sub>M *XCMPLX-0K3 r)"
          using xreal_1_th_6 sorry
        thus " not  |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
          using A2 seq_2_th_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A3: " |.COMPLEX1K10 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r .| <XXREAL-0R3 g -XCMPLX-0K6 p"
    then have "(p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r >XXREAL-0R4 -XCMPLX-0K4 (g -XCMPLX-0K6 p)"
      using seq_2_th_1 sorry
    then have "p +XCMPLX-0K2 g >XXREAL-0R4 (p -XCMPLX-0K6 g)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 r"
      using xreal_1_th_20 sorry
    then have "(p +XCMPLX-0K2 g)-XCMPLX-0K6 (p -XCMPLX-0K6 g) >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 r"
      using xreal_1_th_20 sorry
    then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 g) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 r)"
      using xreal_1_th_68 sorry
    have "g -XCMPLX-0K6 p >XXREAL-0R4 (p +XCMPLX-0K2 g)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 r"
      using A3 seq_2_th_1 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 r +XCMPLX-0K2 (g -XCMPLX-0K6 p) >XXREAL-0R4 p +XCMPLX-0K2 g"
      using xreal_1_th_19 sorry
    then have "\<two>\<^sub>M *XCMPLX-0K3 r >XXREAL-0R4 (p +XCMPLX-0K2 g)-XCMPLX-0K6 (g -XCMPLX-0K6 p)"
      using xreal_1_th_19 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 r) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 p)"
      using xreal_1_th_68 sorry
    thus "r inHIDDENR3 ].RCOMP-1K2 p,g .["
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rcomp_1_def_3 ("compactRCOMP-1V1" 70 ) where
"attr compactRCOMP-1V1 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X.  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X implies ( ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X))"..

mdef rcomp_1_def_4 ("closedRCOMP-1V2" 70 ) where
"attr closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X.  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3 implies limSEQ-2K1 s1 inHIDDENR3 X)"..

mdef rcomp_1_def_5 ("openRCOMP-1V3" 70 ) where
"attr openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>X. X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> be closedRCOMP-1V2)"..

mtheorem rcomp_1_th_4:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] implies s1 be boundedCOMSEQ-2V1"
proof-
  have " for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] implies s1 be boundedCOMSEQ-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    assume A1: "rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .]"
    have "s1 be bounded-aboveSEQ-2V3 & s1 be bounded-belowSEQ-2V2"
    proof(rule conjMI)
      show "s1 be bounded-aboveSEQ-2V3"
      proof-
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = g +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        have " ex r be setHIDDENM2 st  for n be NatNAT-1M1 holds  not r <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule bexI[of _ "r"],rule ballI)
          have A2: " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies t <XXREAL-0R3 r"
          proof-
            have " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies  not t <XXREAL-0R3 r"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be RealXREAL-0M1"
              assume "t inHIDDENR3 rngFUNCT-1K2 s1"
              then have "t inHIDDENR3 [.RCOMP-1K1 s,g .]"
                using A1 sorry
              then have A3: " ex p be RealXREAL-0M1 st (t =COMPLEX1R1 p & s <=XXREAL-0R1 p) & p <=XXREAL-0R1 g"
                 sorry
              have "g <XXREAL-0R3 r"
                using xreal_1_th_29 sorry
              thus " not t <XXREAL-0R3 r"
                using A3 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n inTARSKIR2 domRELAT-1K1 s1"
            using funct_2_def_1 sorry
          then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
            using funct_1_def_3 sorry
          thus " not r <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using A2 sorry
        qed "sorry"
        thus "s1 be bounded-aboveSEQ-2V3"
          using seq_2_def_3 sorry
      qed
      obtain r where 
        [ty]:"r be setHIDDENM2" and rDef:"r = s -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have " ex r be setHIDDENM2 st  for n be NatNAT-1M1 holds  not s1 .FUNCT-1K1 n <=XXREAL-0R1 r"
      proof(rule bexI[of _ "r"],rule ballI)
        have A4: "r +XCMPLX-0K2 \<one>\<^sub>M =COMPLEX1R1 s -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
        have A5: " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies r <XXREAL-0R3 t"
        proof-
          have " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies  not r <XXREAL-0R3 t"
          proof(rule ballI,rule impI)
            fix t assume [ty]: "t be RealXREAL-0M1"
            assume "t inHIDDENR3 rngFUNCT-1K2 s1"
            then have "t inHIDDENR3 [.RCOMP-1K1 s,g .]"
              using A1 sorry
            then have A6: " ex p be RealXREAL-0M1 st (t =COMPLEX1R1 p & s <=XXREAL-0R1 p) & p <=XXREAL-0R1 g"
               sorry
            have "r <XXREAL-0R3 s"
              using A4 xreal_1_th_29 sorry
            thus " not r <XXREAL-0R3 t"
              using A6 xxreal_0_th_2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have "n inTARSKIR2 domRELAT-1K1 s1"
          using funct_2_def_1 sorry
        then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
          using funct_1_def_3 sorry
        thus " not s1 .FUNCT-1K1 n <=XXREAL-0R1 r"
          using A5 sorry
      qed "sorry"
      thus "s1 be bounded-belowSEQ-2V2"
        using seq_2_def_4 sorry
    qed
    thus "s1 be boundedCOMSEQ-2V1"
      using seq_2_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_5:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be closedRCOMP-1V2"
proof-
  have " for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be closedRCOMP-1V2"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] & s1 be convergentCOMSEQ-2V3 implies limSEQ-2K1 s1 inHIDDENR3 [.RCOMP-1K1 s,g .]"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A1: "rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .]"
        and A2: "s1 be convergentCOMSEQ-2V3"
      have A3: "s <=XXREAL-0R1 limSEQ-2K1 s1"
      proof-
        let ?s2 = "seq-constSEQ-1K1 s"
        have A4: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 s).FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n inTARSKIR2 domRELAT-1K1 s1"
            using funct_2_def_1 sorry
          then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
            using funct_1_def_3 sorry
          then have "s1 .FUNCT-1K1 n inTARSKIR2 [.RCOMP-1K1 s,g .]"
            using A1 sorry
          then have " ex p be RealXREAL-0M1 st (s1 .FUNCT-1K1 n =COMPLEX1R1 p & s <=XXREAL-0R1 p) & p <=XXREAL-0R1 g"
             sorry
          thus "(seq-constSEQ-1K1 s).FUNCT-1K1 n <=XXREAL-0R1 s1 .FUNCT-1K1 n"
            using seq_1_th_57 sorry
        qed "sorry"
        have "?s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s"
          using seq_1_th_57 sorry
        then have "limSEQ-2K1 ?s2 =COMPLEX1R1 s"
          using seq_4_th_25 sorry
        thus "s <=XXREAL-0R1 limSEQ-2K1 s1"
          using A2 A4 seq_2_th_18 sorry
      qed
      have "limSEQ-2K1 s1 <=XXREAL-0R1 g"
      proof-
        let ?s2 = "seq-constSEQ-1K1 g"
        have A5: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 g).FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "n inTARSKIR2 domRELAT-1K1 s1"
            using funct_2_def_1 sorry
          then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
            using funct_1_def_3 sorry
          then have "s1 .FUNCT-1K1 n inTARSKIR2 [.RCOMP-1K1 s,g .]"
            using A1 sorry
          then have " ex p be RealXREAL-0M1 st (s1 .FUNCT-1K1 n =COMPLEX1R1 p & s <=XXREAL-0R1 p) & p <=XXREAL-0R1 g"
             sorry
          thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 g).FUNCT-1K1 n"
            using seq_1_th_57 sorry
        qed "sorry"
        have "?s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 g"
          using seq_1_th_57 sorry
        then have "limSEQ-2K1 ?s2 =COMPLEX1R1 g"
          using seq_4_th_25 sorry
        thus "limSEQ-2K1 s1 <=XXREAL-0R1 g"
          using A2 A5 seq_2_th_18 sorry
      qed
      thus "limSEQ-2K1 s1 inHIDDENR3 [.RCOMP-1K1 s,g .]"
        using A3 sorry
    qed "sorry"
    thus "[.RCOMP-1K1 s,g .] be closedRCOMP-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_6:
" for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be compactRCOMP-1V1"
proof-
  have " for s be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds [.RCOMP-1K1 s,g .] be compactRCOMP-1V1"
  proof(rule ballI,rule ballI)
    fix s assume [ty]: "s be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] implies ( ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 [.RCOMP-1K1 s,g .])"
    proof-
      have " for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .] implies ( ex tVar3 be Real-SequenceSEQ-1M1 st (tVar3 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & tVar3 be convergentCOMSEQ-2V3) & limSEQ-2K1 tVar3 inHIDDENR3 [.RCOMP-1K1 s,g .])"
      proof(rule ballI,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        have A1: "[.RCOMP-1K1 s,g .] be closedRCOMP-1V2"
          using rcomp_1_th_5 sorry
        assume A2: "rngFUNCT-1K2 s1 c=TARSKIR1 [.RCOMP-1K1 s,g .]"
        then obtain s2 where
          [ty]:"s2 be Real-SequenceSEQ-1M1" and 
          A3: "s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1"and A4: "s2 be convergentCOMSEQ-2V3"
          using rcomp_1_th_4 seq_4_th_40 sorry
        show " ex tVar3 be Real-SequenceSEQ-1M1 st (tVar3 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & tVar3 be convergentCOMSEQ-2V3) & limSEQ-2K1 tVar3 inHIDDENR3 [.RCOMP-1K1 s,g .]"
        proof(rule bexI[of _ "s2"])
          have " ex Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st s2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
            using A3 valued_0_def_17 sorry
          then have "rngFUNCT-1K2 s2 c=TARSKIR1 rngFUNCT-1K2 s1"
            using relat_1_th_26 sorry
          then have "rngFUNCT-1K2 s2 c=TARSKIR1 [.RCOMP-1K1 s,g .]"
            using A2 sorry
          thus "(s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 [.RCOMP-1K1 s,g .]"
            using A3 A4 A1 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "[.RCOMP-1K1 s,g .] be compactRCOMP-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_7:
" for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ].RCOMP-1K2 p,q .[ be openRCOMP-1V3"
proof-
  have " for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds ].RCOMP-1K2 p,q .[ be openRCOMP-1V3"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 p or q <=XXREAL-0R1 Lamb1"
    obtain X where
      [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and 
      A1: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X iff ?P(r)"
      using subset_1_sch_3 sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X & s1 be convergentCOMSEQ-2V3 implies limSEQ-2K1 s1 inHIDDENR3 X"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A2: "rngFUNCT-1K2 s1 c=TARSKIR1 X"
        and A3: "s1 be convergentCOMSEQ-2V3"
      have A4: "limSEQ-2K1 s1 inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "limSEQ-2K1 s1 <=XXREAL-0R1 p or q <=XXREAL-0R1 limSEQ-2K1 s1"
      proof-
        have " not ( not ( not limSEQ-2K1 s1 <=XXREAL-0R1 p &  not q <=XXREAL-0R1 limSEQ-2K1 s1)) implies  False "
        proof(rule impI)
          assume A5: " not ( not ( not limSEQ-2K1 s1 <=XXREAL-0R1 p &  not q <=XXREAL-0R1 limSEQ-2K1 s1))"
          then have "0NUMBERSK6 <XXREAL-0R3 limSEQ-2K1 s1 -XCMPLX-0K6 p"
            using xreal_1_th_50 sorry
          then obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A6: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 limSEQ-2K1 s1 -XCMPLX-0K6 p"
            using A3 seq_2_def_7 sorry
          have "0NUMBERSK6 <XXREAL-0R3 q -XCMPLX-0K6 limSEQ-2K1 s1"
            using A5 xreal_1_th_50 sorry
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A7: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 q -XCMPLX-0K6 limSEQ-2K1 s1"
            using A3 seq_2_def_7 sorry
          obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A8: "maxXXREAL-0K5(n,n1) <XXREAL-0R3 k"
            using seq_4_th_3 sorry
          have "n1 <=XXREAL-0R1 maxXXREAL-0K5(n,n1)"
            using xxreal_0_th_25 sorry
          then have "n1 <=XXREAL-0R1 k"
            using A8 xxreal_0_th_2 sorry
          then have A9: " |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 limSEQ-2K1 s1 -XCMPLX-0K6 p"
            using A6 sorry
          have "-XCMPLX-0K4  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 .| <=XXREAL-0R1 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1"
            using absvalue_th_4 sorry
          then have "-XCMPLX-0K4 (s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 -XCMPLX-0K4 (-XCMPLX-0K4  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 .|)"
            using xreal_1_th_24 sorry
          then have "-XCMPLX-0K4 (s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1) <XXREAL-0R3 limSEQ-2K1 s1 -XCMPLX-0K6 p"
            using A9 xxreal_0_th_2 sorry
          then have "-XCMPLX-0K4 (limSEQ-2K1 s1 -XCMPLX-0K6 p) <XXREAL-0R3 -XCMPLX-0K4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1))"
            using xreal_1_th_24 sorry
          then have "p -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1"
             sorry
          then have A10: "p <XXREAL-0R3 s1 .FUNCT-1K1 k"
            using xreal_1_th_9 sorry
          have "n <=XXREAL-0R1 maxXXREAL-0K5(n,n1)"
            using xxreal_0_th_25 sorry
          then have "n <=XXREAL-0R1 k"
            using A8 xxreal_0_th_2 sorry
          then have "s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 <=XXREAL-0R1  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 .| &  |.COMPLEX1K10 s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 q -XCMPLX-0K6 limSEQ-2K1 s1"
            using A7 absvalue_th_4 sorry
          then have "s1 .FUNCT-1K1 k -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 q -XCMPLX-0K6 limSEQ-2K1 s1"
            using xxreal_0_th_2 sorry
          then have A11: "s1 .FUNCT-1K1 k <XXREAL-0R3 q"
            using xreal_1_th_9 sorry
          have A12: "k inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have A13: "s1 .FUNCT-1K1 k inTARSKIR2 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          have "domRELAT-1K1 s1 =XBOOLE-0R4 NATNUMBERSK1"
            using funct_2_def_1 sorry
          then have "s1 .FUNCT-1K1 k inTARSKIR2 rngFUNCT-1K2 s1"
            using funct_1_def_3 A12 sorry
          thus " False "
            using A1 A2 A11 A10 A13 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "limSEQ-2K1 s1 inHIDDENR3 X"
        using A1 A4 sorry
    qed "sorry"
    then have A14: "X be closedRCOMP-1V2"
       sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 (].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> implies r inHIDDENR3 X"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have A15: "r inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      assume "r inHIDDENR3 (].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
      then have " not r inHIDDENR3 ].RCOMP-1K2 p,q .["
        using xboole_0_def_5 sorry
      then have "r <=XXREAL-0R1 p or q <=XXREAL-0R1 r"
         sorry
      thus "r inHIDDENR3 X"
        using A1 A15 sorry
    qed "sorry"
    then have A16: "(].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> c=TARSKIR1 X"
       sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 X implies r inHIDDENR3 (].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "r inHIDDENR3 X"
      then have " not ( ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & p <XXREAL-0R3 s) & s <XXREAL-0R3 q)"
        using A1 sorry
      then have "r inHIDDENR3 REALNUMBERSK2 &  not r inHIDDENR3 ].RCOMP-1K2 p,q .["
        using xreal_0_def_1 sorry
      thus "r inHIDDENR3 (].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
        using xboole_0_def_5 sorry
    qed "sorry"
    then have "X c=TARSKIR1 (].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
       sorry
    then have "(].RCOMP-1K2 p,q .[)`SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> =XBOOLE-0R4 X"
      using A16 sorry
    thus "].RCOMP-1K2 p,q .[ be openRCOMP-1V3"
      using A14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_cl_1:
  mlet "p be RealXREAL-0M1", "q be RealXREAL-0M1"
"cluster ].RCOMP-1K2 p,q .[ as-term-is openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K2 p,q .[ implies it be openRCOMP-1V3"
    using rcomp_1_th_7 sorry
qed "sorry"

mtheorem rcomp_1_cl_2:
  mlet "p be RealXREAL-0M1", "q be RealXREAL-0M1"
"cluster [.RCOMP-1K1 p,q .] as-term-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K1 p,q .] implies it be closedRCOMP-1V2"
    using rcomp_1_th_5 sorry
qed "sorry"

mtheorem rcomp_1_th_8:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies X be closedRCOMP-1V2"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies ( not X be closedRCOMP-1V2 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be compactRCOMP-1V1"
    assume " not X be closedRCOMP-1V2"
    then obtain s1 where
      [ty]:"s1 be Real-SequenceSEQ-1M1" and 
      A2: "rngFUNCT-1K2 s1 c=TARSKIR1 X"and A3: "s1 be convergentCOMSEQ-2V3 &  not limSEQ-2K1 s1 inHIDDENR3 X"
       sorry
    have " ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X"
      using A1 A2 sorry
    thus " False "
      using A3 seq_4_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_cl_3:
"cluster compactRCOMP-1V1 also-is closedRCOMP-1V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be compactRCOMP-1V1 implies it be closedRCOMP-1V2"
    using rcomp_1_th_8 sorry
qed "sorry"

mtheorem rcomp_1_th_9:
" for s1 be Real-SequenceSEQ-1M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 p .|))) implies ( for s2 be Real-SequenceSEQ-1M1 holds s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 implies  not (s2 be convergentCOMSEQ-2V3 & limSEQ-2K1 s2 inHIDDENR3 X))"
proof-
  have " for s1 be Real-SequenceSEQ-1M1 holds  for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 p .|))) &  not ( for s2 be Real-SequenceSEQ-1M1 holds s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 implies  not (s2 be convergentCOMSEQ-2V3 & limSEQ-2K1 s2 inHIDDENR3 X)) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 p .|))"
      and A2: " not ( for s2 be Real-SequenceSEQ-1M1 holds s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 implies  not (s2 be convergentCOMSEQ-2V3 & limSEQ-2K1 s2 inHIDDENR3 X))"
    obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A3: "s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1"and A4: "s2 be convergentCOMSEQ-2V3"and A5: "limSEQ-2K1 s2 inHIDDENR3 X"
      using A2 sorry
    obtain r n where
      [ty]:"r be RealXREAL-0M1" "n be NatNAT-1M1" and 
      A6: "0NUMBERSK6 <XXREAL-0R3 r"and A7: " for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s2 .|"
      using A1 A5 sorry
    obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A8: " for m be NatNAT-1M1 holds n1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s2 .| <XXREAL-0R3 r"
      using A4 A6 seq_2_def_7 sorry
    obtain NS where
      [ty]:"NS be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A9: "s2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> NS"
      using A3 valued_0_def_17 sorry
    obtain k where 
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 n1"
      using ordinal1_def_12 sorry
    have " |.COMPLEX1K10 (s1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> NS).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k -XCMPLX-0K6 limSEQ-2K1 s2 .| <XXREAL-0R3 r"
      using A8 A9 nat_1_th_11 sorry
    then have A10: " |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (NS .RECDEF-1K1 k) -XCMPLX-0K6 limSEQ-2K1 s2 .| <XXREAL-0R3 r"
      using funct_2_th_15 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
      using nat_1_th_11 sorry
    then have A11: "n <XXREAL-0R3 k"
      using nat_1_th_13 sorry
    have "k <=XXREAL-0R1 NS .RECDEF-1K1 k"
      using seqm_3_th_14 sorry
    then have "n <XXREAL-0R3 NS .RECDEF-1K1 k"
      using A11 xxreal_0_th_2 sorry
    thus " False "
      using A7 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_10:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies X be real-boundedXXREAL-2V5"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 implies ( not X be real-boundedXXREAL-2V5 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be compactRCOMP-1V1"
    assume A2: " not X be real-boundedXXREAL-2V5"
    show " False "
    proof-
      have cases: " not X be bounded-aboveXXREAL-2V4 or  not X be bounded-belowXXREAL-2V3"
        using A2 sorry
      have case1: " not X be bounded-aboveXXREAL-2V4 implies  False "
      proof(rule impI)
        assume A3: " not X be bounded-aboveXXREAL-2V4"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be RealXREAL-0M1 st (q =COMPLEX1R1 Lamb2 & q inHIDDENR3 X) & Lamb1 <XXREAL-0R3 q"
        have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar4 be setHIDDENM2 & tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar4 & q inHIDDENR3 X) & n <XXREAL-0R3 q)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have " not n be UpperBoundXXREAL-2M1-of X"
              using A3 xxreal_2_def_10 sorry
            then obtain t where
              [ty]:"t be ExtRealXXREAL-0M1" and 
              A5: "t inHIDDENR3 X & n <XXREAL-0R3 t"
              using xxreal_2_def_1 sorry
            show " ex tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar4 be setHIDDENM2 & tVar4 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar4 & q inHIDDENR3 X) & n <XXREAL-0R3 q)"
            proof(rule bexI[of _ "t"])
              show "(t be setHIDDENM2 & t be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 t & q inHIDDENR3 X) & n <XXREAL-0R3 q)"
                using A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of REALNUMBERSK2" and 
          A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A4 sorry
        have A7: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n inTARSKIR2 X & n <XXREAL-0R3 f .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have " ex q be RealXREAL-0M1 st (q =COMPLEX1R1 f .FUNCT-1K1 n & q inHIDDENR3 X) & n <XXREAL-0R3 q"
            using A6 sorry
          thus "f .FUNCT-1K1 n inTARSKIR2 X & n <XXREAL-0R3 f .FUNCT-1K1 n"
             sorry
        qed "sorry"
        have A8: " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|))"
        proof-
          have " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|))"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be RealXREAL-0M1"
            assume "p inHIDDENR3 X"
            obtain q where
              [ty]:"q be RealXREAL-0M1" and 
              A9: "q =COMPLEX1R1 \<one>\<^sub>M"
               sorry
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = q"
               sorry
            show " ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|)"
            proof(rule bexI[of _ "r"])
              obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A10: "p +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 k"
                using seq_4_th_3 sorry
              obtain n where 
                [ty]:"n be NatNAT-1M1" and nDef:"n = k"
                 sorry
              show " ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|)"
              proof(rule bexI[of _ "n"],rule conjMI,rule ballI,rule impI)
                show "0NUMBERSK6 <XXREAL-0R3 r"
                  using A9 sorry
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "n <XXREAL-0R3 m"
                then have "p +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 m"
                  using A10 xxreal_0_th_2 sorry
                then have "p +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 f .FUNCT-1K1 m"
                  using A7 xxreal_0_th_2 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 f .FUNCT-1K1 m -XCMPLX-0K6 p"
                  using xreal_1_th_20 sorry
                thus " not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|"
                  using A9 absvalue_def_1 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "rngFUNCT-1K2 f c=TARSKIR1 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A11 funct_2_def_1 sorry
            have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> y inTARSKIR2 X"
              using A7 sorry
            thus "x inHIDDENR3 X"
              using A12 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 X"
            using tarski_def_3 sorry
        qed
        then have " ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of f & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X"
          using A1 sorry
        thus " False "
          using A8 rcomp_1_th_9 sorry
      qed
      have case2: " not X be bounded-belowXXREAL-2V3 implies  False "
      proof(rule impI)
        assume A13: " not X be bounded-belowXXREAL-2V3"
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be RealXREAL-0M1 st (q =COMPLEX1R1 Lamb2 & q inHIDDENR3 X) & q <XXREAL-0R3 -XCMPLX-0K4 Lamb1"
        have A14: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar7 be setHIDDENM2 & tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar7 & q inHIDDENR3 X) & q <XXREAL-0R3 -XCMPLX-0K4 n)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have " not -XCMPLX-0K4 n be LowerBoundXXREAL-2M2-of X"
              using A13 xxreal_2_def_9 sorry
            then obtain t where
              [ty]:"t be ExtRealXXREAL-0M1" and 
              A15: "t inHIDDENR3 X & t <XXREAL-0R3 -XCMPLX-0K4 n"
              using xxreal_2_def_2 sorry
            show " ex tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar7 be setHIDDENM2 & tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar7 & q inHIDDENR3 X) & q <XXREAL-0R3 -XCMPLX-0K4 n)"
            proof(rule bexI[of _ "t"])
              show "(t be setHIDDENM2 & t be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 t & q inHIDDENR3 X) & q <XXREAL-0R3 -XCMPLX-0K4 n)"
                using A15 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of REALNUMBERSK2" and 
          A16: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A14 sorry
        have A17: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n inTARSKIR2 X & f .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have " ex q be RealXREAL-0M1 st (q =COMPLEX1R1 f .FUNCT-1K1 n & q inHIDDENR3 X) & q <XXREAL-0R3 -XCMPLX-0K4 n"
            using A16 sorry
          thus "f .FUNCT-1K1 n inTARSKIR2 X & f .FUNCT-1K1 n <XXREAL-0R3 -XCMPLX-0K4 n"
             sorry
        qed "sorry"
        have A18: " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|))"
        proof-
          have " for p be RealXREAL-0M1 holds p inHIDDENR3 X implies ( ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|))"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be RealXREAL-0M1"
            assume "p inHIDDENR3 X"
            obtain q where
              [ty]:"q be RealXREAL-0M1" and 
              A19: "q =COMPLEX1R1 \<one>\<^sub>M"
               sorry
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = q"
               sorry
            show " ex r be RealXREAL-0M1 st  ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|)"
            proof(rule bexI[of _ "r"])
              obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A20: " |.COMPLEX1K10 p -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 k"
                using seq_4_th_3 sorry
              obtain n where 
                [ty]:"n be NatNAT-1M1" and nDef:"n = k"
                 sorry
              show " ex n be NatNAT-1M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for m be NatNAT-1M1 holds n <XXREAL-0R3 m implies  not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|)"
              proof(rule bexI[of _ "n"],rule conjMI,rule ballI,rule impI)
                show "0NUMBERSK6 <XXREAL-0R3 r"
                  using A19 sorry
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "n <XXREAL-0R3 m"
                then have A21: "-XCMPLX-0K4 m <XXREAL-0R3 -XCMPLX-0K4 n"
                  using xreal_1_th_24 sorry
                have "-XCMPLX-0K4 k <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
                  using A20 seq_2_th_1 sorry
                then have "-XCMPLX-0K4 m <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
                  using A21 xxreal_0_th_2 sorry
                then have "f .FUNCT-1K1 m <XXREAL-0R3 p -XCMPLX-0K6 \<one>\<^sub>M"
                  using A17 xxreal_0_th_2 sorry
                then have "f .FUNCT-1K1 m +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 p"
                  using xreal_1_th_20 sorry
                then have "\<one>\<^sub>M <XXREAL-0R3 p -XCMPLX-0K6 f .FUNCT-1K1 m"
                  using xreal_1_th_20 sorry
                then have "r <XXREAL-0R3  |.COMPLEX1K10 -XCMPLX-0K4 (f .FUNCT-1K1 m -XCMPLX-0K6 p) .|"
                  using A19 absvalue_def_1 sorry
                thus " not r <XXREAL-0R3  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 p .|"
                  using complex1_th_52 sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "rngFUNCT-1K2 f c=TARSKIR1 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A22: "y inHIDDENR3 domRELAT-1K1 f"and A23: "x =HIDDENR1 f .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A22 funct_2_def_1 sorry
            have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> y inTARSKIR2 X"
              using A17 sorry
            thus "x inHIDDENR3 X"
              using A23 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 X"
            using tarski_def_3 sorry
        qed
        then have " ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of f & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X"
          using A1 sorry
        thus " False "
          using A18 rcomp_1_th_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_11:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5\<bar>closedRCOMP-1V2 implies X be compactRCOMP-1V1"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be real-boundedXXREAL-2V5 & X be closedRCOMP-1V2 implies X be compactRCOMP-1V1"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be real-boundedXXREAL-2V5"
      and A2: "X be closedRCOMP-1V2"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngFUNCT-1K2 s1 c=TARSKIR1 X implies ( ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X)"
    proof(rule ballI,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A3: "rngFUNCT-1K2 s1 c=TARSKIR1 X"
      have A4: "s1 be bounded-belowSEQ-2V4"
      proof-
        obtain p where
          [ty]:"p be RealXREAL-0M1" and 
          A5: "p be LowerBoundXXREAL-2M2-of X"
          using A1 xxreal_2_def_9 sorry
        have A6: " for q be RealXREAL-0M1 holds q inHIDDENR3 X implies p <=XXREAL-0R1 q"
          using A5 xxreal_2_def_2 sorry
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = p -XCMPLX-0K6 \<one>\<^sub>M"
           sorry
        have " ex r be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not s1 .FUNCT-1K1 VarFor1 <=XXREAL-0R1 r"
        proof(rule bexI[of _ "r"])
          have A7: "r +XCMPLX-0K2 \<one>\<^sub>M =COMPLEX1R1 p -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
             sorry
          have A8: " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies r <XXREAL-0R3 t"
          proof-
            have " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies  not r <XXREAL-0R3 t"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be RealXREAL-0M1"
              assume "t inHIDDENR3 rngFUNCT-1K2 s1"
              then have A9: "p <=XXREAL-0R1 t"
                using A3 A6 sorry
              have "r <XXREAL-0R3 p"
                using A7 xreal_1_th_29 sorry
              thus " not r <XXREAL-0R3 t"
                using A9 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for n be NatNAT-1M1 holds r <XXREAL-0R3 s1 .FUNCT-1K1 n"
          proof-
            have " for n be NatNAT-1M1 holds  not r <XXREAL-0R3 s1 .FUNCT-1K1 n"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have "n inTARSKIR2 domRELAT-1K1 s1"
                using funct_2_def_1 sorry
              then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
                using funct_1_def_3 sorry
              thus " not r <XXREAL-0R3 s1 .FUNCT-1K1 n"
                using A8 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for VarFor1 be setHIDDENM2 holds  not s1 .FUNCT-1K1 VarFor1 <=XXREAL-0R1 r"
             sorry
        qed "sorry"
        thus "s1 be bounded-belowSEQ-2V4"
          using seq_2_def_4 sorry
      qed
      have "s1 be bounded-aboveSEQ-2V3"
      proof-
        obtain p where
          [ty]:"p be RealXREAL-0M1" and 
          A10: "p be UpperBoundXXREAL-2M1-of X"
          using A1 xxreal_2_def_10 sorry
        have A11: " for q be RealXREAL-0M1 holds q inHIDDENR3 X implies q <=XXREAL-0R1 p"
          using A10 xxreal_2_def_1 sorry
        obtain r where 
          [ty]:"r be setHIDDENM2" and rDef:"r = p +XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        have " ex r be setHIDDENM2 st  for VarFor1 be setHIDDENM2 holds  not r <=XXREAL-0R1 s1 .FUNCT-1K1 VarFor1"
        proof(rule bexI[of _ "r"])
          have A12: " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies t <XXREAL-0R3 r"
          proof-
            have " for t be RealXREAL-0M1 holds t inHIDDENR3 rngFUNCT-1K2 s1 implies  not t <XXREAL-0R3 r"
            proof(rule ballI,rule impI)
              fix t assume [ty]: "t be RealXREAL-0M1"
              assume "t inHIDDENR3 rngFUNCT-1K2 s1"
              then have A13: "t <=XXREAL-0R1 p"
                using A3 A11 sorry
              have "p <XXREAL-0R3 r"
                using xreal_1_th_29 sorry
              thus " not t <XXREAL-0R3 r"
                using A13 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <XXREAL-0R3 r"
          proof-
            have " for n be NatNAT-1M1 holds  not s1 .FUNCT-1K1 n <XXREAL-0R3 r"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have "n inTARSKIR2 domRELAT-1K1 s1"
                using funct_2_def_1 sorry
              then have "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
                using funct_1_def_3 sorry
              thus " not s1 .FUNCT-1K1 n <XXREAL-0R3 r"
                using A12 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for VarFor1 be setHIDDENM2 holds  not r <=XXREAL-0R1 s1 .FUNCT-1K1 VarFor1"
             sorry
        qed "sorry"
        thus "s1 be bounded-aboveSEQ-2V3"
          using seq_2_def_3 sorry
      qed
      then have "s1 be boundedCOMSEQ-2V1"
        using A4 sorry
      then obtain s2 where
        [ty]:"s2 be Real-SequenceSEQ-1M1" and 
        A14: "s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1"and A15: "s2 be convergentCOMSEQ-2V3"
        using seq_4_th_40 sorry
      have " ex Nseq be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st s2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> Nseq"
        using A14 valued_0_def_17 sorry
      then have "rngFUNCT-1K2 s2 c=TARSKIR1 rngFUNCT-1K2 s1"
        using relat_1_th_26 sorry
      then have "rngFUNCT-1K2 s2 c=TARSKIR1 X"
        using A3 sorry
      then have "limSEQ-2K1 s2 inHIDDENR3 X"
        using A2 A15 sorry
      thus " ex s2 be Real-SequenceSEQ-1M1 st (s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & s2 be convergentCOMSEQ-2V3) & limSEQ-2K1 s2 inHIDDENR3 X"
        using A14 A15 sorry
    qed "sorry"
    thus "X be compactRCOMP-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_12:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be closedRCOMP-1V2) & X be bounded-aboveXXREAL-2V4 implies upper-boundSEQ-4K2 X inHIDDENR3 X"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & (X be closedRCOMP-1V2 & (X be bounded-aboveXXREAL-2V4 &  not upper-boundSEQ-4K2 X inHIDDENR3 X)) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X be closedRCOMP-1V2"
      and A3: "X be bounded-aboveXXREAL-2V4"
      and A4: " not upper-boundSEQ-4K2 X inHIDDENR3 X"
    let ?s1 = "upper-boundSEQ-4K2 X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be RealXREAL-0M1 st (q =COMPLEX1R1 Lamb2 & q inHIDDENR3 X) & ?s1 -XCMPLX-0K6 q <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar12 be setHIDDENM2 & tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar12 & q inHIDDENR3 X) & upper-boundSEQ-4K2 X -XCMPLX-0K6 q <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "0NUMBERSK6 <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_1_th_215 sorry
        then obtain t where
          [ty]:"t be RealXREAL-0M1" and 
          A6: "t inHIDDENR3 X"and A7: "?s1 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 t"
          using A1 A3 seq_4_def_1 sorry
        show " ex tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar12 be setHIDDENM2 & tVar12 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar12 & q inHIDDENR3 X) & upper-boundSEQ-4K2 X -XCMPLX-0K6 q <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule bexI[of _ "t"])
          have "?s1 <XXREAL-0R3 t +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
            using A7 xreal_1_th_19 sorry
          then have "?s1 -XCMPLX-0K6 t <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
            using xreal_1_th_19 sorry
          thus "(t be setHIDDENM2 & t be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 t & q inHIDDENR3 X) & upper-boundSEQ-4K2 X -XCMPLX-0K6 q <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
            using A6 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be sequenceNAT-1M2-of REALNUMBERSK2" and 
      A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A5 sorry
    have A9: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n inTARSKIR2 X & upper-boundSEQ-4K2 X -XCMPLX-0K6 f .FUNCT-1K1 n <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have " ex q be RealXREAL-0M1 st (q =COMPLEX1R1 f .FUNCT-1K1 n & q inHIDDENR3 X) & ?s1 -XCMPLX-0K6 q <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
        using A8 sorry
      thus "f .FUNCT-1K1 n inTARSKIR2 X & upper-boundSEQ-4K2 X -XCMPLX-0K6 f .FUNCT-1K1 n <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have A10: "rngFUNCT-1K2 f c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A11 funct_2_def_1 sorry
        have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> y inTARSKIR2 X"
          using A9 sorry
        thus "x inHIDDENR3 X"
          using A12 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have A13: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 upper-boundSEQ-4K2 X .| <XXREAL-0R3 s)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be RealXREAL-0M1"
      assume A14: "0NUMBERSK6 <XXREAL-0R3 s"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A15: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      obtain k where 
        [ty]:"k be NatNAT-1M1" and kDef:"k = n"
         sorry
      show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 upper-boundSEQ-4K2 X .| <XXREAL-0R3 s"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "k <=XXREAL-0R1 m"
        then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A16: "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "f .FUNCT-1K1 m inTARSKIR2 X"
          using A9 sorry
        then have "f .FUNCT-1K1 m <=XXREAL-0R1 ?s1"
          using A3 seq_4_def_1 sorry
        then have A17: "0NUMBERSK6 <=XXREAL-0R1 ?s1 -XCMPLX-0K6 f .FUNCT-1K1 m"
          using xreal_1_th_48 sorry
        have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A15 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
          using A14 xreal_1_th_76 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using xcmplx_1_th_216 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using A16 xxreal_0_th_2 sorry
        then have "?s1 -XCMPLX-0K6 f .FUNCT-1K1 m <XXREAL-0R3 s"
          using A9 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 -XCMPLX-0K4 (f .FUNCT-1K1 m -XCMPLX-0K6 ?s1) .| <XXREAL-0R3 s"
          using A17 absvalue_def_1 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 upper-boundSEQ-4K2 X .| <XXREAL-0R3 s"
          using complex1_th_52 sorry
      qed "sorry"
    qed "sorry"
    then have A18: "f be convergentCOMSEQ-2V3"
       sorry
    then have "limSEQ-2K1 f =COMPLEX1R1 ?s1"
      using A13 seq_2_def_7 sorry
    thus " False "
      using A2 A4 A18 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_13:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X <>HIDDENR2 {}XBOOLE-0K1 & X be closedRCOMP-1V2) & X be bounded-belowXXREAL-2V3 implies lower-boundSEQ-4K3 X inHIDDENR3 X"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & (X be closedRCOMP-1V2 & (X be bounded-belowXXREAL-2V3 &  not lower-boundSEQ-4K3 X inHIDDENR3 X)) implies  False "
  proof(rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "X be closedRCOMP-1V2"
      and A3: "X be bounded-belowXXREAL-2V3"
      and A4: " not lower-boundSEQ-4K3 X inHIDDENR3 X"
    let ?i1 = "lower-boundSEQ-4K3 X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex q be RealXREAL-0M1 st (q =COMPLEX1R1 Lamb2 & q inHIDDENR3 X) & q -XCMPLX-0K6 ?i1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar14 be setHIDDENM2 & tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar14 & q inHIDDENR3 X) & q -XCMPLX-0K6 lower-boundSEQ-4K3 X <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "0NUMBERSK6 <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_1_th_215 sorry
        then obtain t where
          [ty]:"t be RealXREAL-0M1" and 
          A6: "t inHIDDENR3 X"and A7: "t <XXREAL-0R3 ?i1 +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 A3 seq_4_def_2 sorry
        show " ex tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar14 be setHIDDENM2 & tVar14 be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 tVar14 & q inHIDDENR3 X) & q -XCMPLX-0K6 lower-boundSEQ-4K3 X <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule bexI[of _ "t"])
          have "t -XCMPLX-0K6 ?i1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
            using A7 xreal_1_th_19 sorry
          thus "(t be setHIDDENM2 & t be ElementSUBSET-1M1-of REALNUMBERSK2) & ( ex q be RealXREAL-0M1 st (q =COMPLEX1R1 t & q inHIDDENR3 X) & q -XCMPLX-0K6 lower-boundSEQ-4K3 X <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
            using A6 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be sequenceNAT-1M2-of REALNUMBERSK2" and 
      A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A5 sorry
    have A9: " for n be NatNAT-1M1 holds f .FUNCT-1K1 n inTARSKIR2 X & f .FUNCT-1K1 n -XCMPLX-0K6 lower-boundSEQ-4K3 X <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have " ex q be RealXREAL-0M1 st (q =COMPLEX1R1 f .FUNCT-1K1 n & q inHIDDENR3 X) & q -XCMPLX-0K6 ?i1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
        using A8 sorry
      thus "f .FUNCT-1K1 n inTARSKIR2 X & f .FUNCT-1K1 n -XCMPLX-0K6 lower-boundSEQ-4K3 X <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    have A10: "rngFUNCT-1K2 f c=TARSKIR1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A11: "y inHIDDENR3 domRELAT-1K1 f"and A12: "x =HIDDENR1 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A11 funct_2_def_1 sorry
        have "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> y inTARSKIR2 X"
          using A9 sorry
        thus "x inHIDDENR3 X"
          using A12 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 X"
        using tarski_def_3 sorry
    qed
    have A13: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 lower-boundSEQ-4K3 X .| <XXREAL-0R3 s)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be RealXREAL-0M1"
      assume A14: "0NUMBERSK6 <XXREAL-0R3 s"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A15: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      obtain k where 
        [ty]:"k be NatNAT-1M1" and kDef:"k = n"
         sorry
      show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 lower-boundSEQ-4K3 X .| <XXREAL-0R3 s"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "k <=XXREAL-0R1 m"
        then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A16: "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "f .FUNCT-1K1 m inTARSKIR2 X"
          using A9 sorry
        then have "?i1 <=XXREAL-0R1 f .FUNCT-1K1 m"
          using A3 seq_4_def_2 sorry
        then have A17: "0NUMBERSK6 <=XXREAL-0R1 f .FUNCT-1K1 m -XCMPLX-0K6 ?i1"
          using xreal_1_th_48 sorry
        have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A15 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
          using A14 xreal_1_th_76 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using xcmplx_1_th_216 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using A16 xxreal_0_th_2 sorry
        then have "f .FUNCT-1K1 m -XCMPLX-0K6 ?i1 <XXREAL-0R3 s"
          using A9 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 m -XCMPLX-0K6 lower-boundSEQ-4K3 X .| <XXREAL-0R3 s"
          using A17 absvalue_def_1 sorry
      qed "sorry"
    qed "sorry"
    then have A18: "f be convergentCOMSEQ-2V3"
       sorry
    then have "limSEQ-2K1 f =COMPLEX1R1 ?i1"
      using A13 seq_2_def_7 sorry
    thus " False "
      using A2 A4 A18 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_14:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X <>HIDDENR2 {}XBOOLE-0K1 & X be compactRCOMP-1V1 implies upper-boundSEQ-4K2 X inHIDDENR3 X & lower-boundSEQ-4K3 X inHIDDENR3 X"
proof(rule ballI,rule impMI ,rule impI)
  fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
  assume A1: "X <>HIDDENR2 {}XBOOLE-0K1"
    and A2: "X be compactRCOMP-1V1"
  have "X be real-boundedXXREAL-2V5\<bar>closedRCOMP-1V2"
    using A2 rcomp_1_th_10 sorry
  thus "upper-boundSEQ-4K2 X inHIDDENR3 X & lower-boundSEQ-4K3 X inHIDDENR3 X"
    using A1 rcomp_1_th_12 rcomp_1_th_13 sorry
qed "sorry"

mtheorem rcomp_1_th_15:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X) implies ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 p,g .])"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be compactRCOMP-1V1 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X) implies ( ex tVar16 be RealXREAL-0M1 st  ex tVar17 be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 tVar16,tVar17 .])"
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be compactRCOMP-1V1"
      and A2: " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X"
    show " ex tVar16 be RealXREAL-0M1 st  ex tVar17 be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 tVar16,tVar17 .]"
    proof-
      have cases: "X =XBOOLE-0R4 {}XBOOLE-0K1 or X <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar16 be RealXREAL-0M1 st  ex tVar17 be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 tVar16,tVar17 .])"
      proof(rule impI)
        assume A3: "X =XBOOLE-0R4 {}XBOOLE-0K1"
        show " ex tVar16 be RealXREAL-0M1 st  ex tVar17 be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 tVar16,tVar17 .]"
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          show " ex tVar17 be RealXREAL-0M1 st X =XBOOLE-0R4 [.RCOMP-1K1 \<one>\<^sub>M,tVar17 .]"
          proof(rule bexI[of _ "0NUMBERSK6"])
            show "X =XBOOLE-0R4 [.RCOMP-1K1 \<one>\<^sub>M,0NUMBERSK6 .]"
              using A3 xxreal_1_th_29 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be objectHIDDENM1 st  ex g be objectHIDDENM1 st X =XBOOLE-0R4 [.RCOMP-1K1 p,g .])"
      proof(rule impI)
        assume A4: "X <>HIDDENR2 {}XBOOLE-0K1"
        obtain p where 
          [ty]:"p be objectHIDDENM1" and pDef:"p = lower-boundSEQ-4K3 X"
           sorry
        show " ex p be objectHIDDENM1 st  ex g be objectHIDDENM1 st X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
        proof(rule bexI[of _ "p"])
          obtain g where 
            [ty]:"g be objectHIDDENM1" and gDef:"g = upper-boundSEQ-4K2 X"
             sorry
          show " ex g be objectHIDDENM1 st X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
          proof(rule bexI[of _ "g"])
            have A5: "X be real-boundedXXREAL-2V5\<bar>closedRCOMP-1V2"
              using A1 rcomp_1_th_10 sorry
            have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X implies r inTARSKIR2 [.RCOMP-1K1 p,g .]"
            proof(rule ballI,rule impI)
              fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
              assume "r inTARSKIR2 X"
              then have "r <=XXREAL-0R1 g & p <=XXREAL-0R1 r"
                using A5 seq_4_def_1 seq_4_def_2 sorry
              thus "r inTARSKIR2 [.RCOMP-1K1 p,g .]"
                 sorry
            qed "sorry"
            then have A6: "X c=TARSKIR1 [.RCOMP-1K1 p,g .]"
               sorry
            have "upper-boundSEQ-4K2 X inHIDDENR3 X & lower-boundSEQ-4K3 X inHIDDENR3 X"
              using A4 A5 rcomp_1_th_12 rcomp_1_th_13 sorry
            then have "[.RCOMP-1K1 p,g .] c=TARSKIR1 X"
              using A2 sorry
            thus "X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
              using A6 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_cl_4:
"cluster openRCOMP-1V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be openRCOMP-1V3"
  proof-
    have " ex tVar20 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar20 be openRCOMP-1V3"
    proof-
      show " ex tVar20 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar20 be openRCOMP-1V3"
      proof(rule bexI[of _ "].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .["])
        show "].RCOMP-1K2 0NUMBERSK6,\<one>\<^sub>M .[ be openRCOMP-1V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef rcomp_1_def_6 ("NeighbourhoodRCOMP-1M1-of  _ " [70]70 ) where
  mlet "r be RealXREAL-0M1"
"mode NeighbourhoodRCOMP-1M1-of r \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>it.  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & it =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[)"
proof-
  (*existence*)
    show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st  ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & it =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
    proof-
      have " ex tVar21 be SubsetSUBSET-1M2-of REALNUMBERSK2 st  not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & tVar21 =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[))"
      proof-
        show " ex tVar21 be SubsetSUBSET-1M2-of REALNUMBERSK2 st  not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & tVar21 =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[))"
        proof(rule bexI[of _ "].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M,r +XCMPLX-0K2 \<one>\<^sub>M .["])
          show " not ( for g be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 g & ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M,r +XCMPLX-0K2 \<one>\<^sub>M .[ =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rcomp_1_cl_5:
  mlet "r be RealXREAL-0M1"
"cluster note-that openRCOMP-1V3 for NeighbourhoodRCOMP-1M1-of r"
proof
(*coherence*)
  show " for it be NeighbourhoodRCOMP-1M1-of r holds it be openRCOMP-1V3"
  proof-
    have " for A be NeighbourhoodRCOMP-1M1-of r holds A be openRCOMP-1V3"
    proof(rule ballI)
      fix A assume [ty]: "A be NeighbourhoodRCOMP-1M1-of r"
      have " ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & A =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
        using rcomp_1_def_6 sorry
      thus "A be openRCOMP-1V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rcomp_1_th_16:
" for r be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of r holds r inHIDDENR3 N"
proof-
  have " for r be RealXREAL-0M1 holds  for N be NeighbourhoodRCOMP-1M1-of r holds r inHIDDENR3 N"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix N assume [ty]: "N be NeighbourhoodRCOMP-1M1-of r"
    have "( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & N =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[) &  |.COMPLEX1K10 r -XCMPLX-0K6 r .| =COMPLEX1R1 0NUMBERSK6"
      using rcomp_1_def_6 absvalue_th_2 sorry
    thus "r inHIDDENR3 N"
      using rcomp_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_17:
" for r be RealXREAL-0M1 holds  for N1 be NeighbourhoodRCOMP-1M1-of r holds  for N2 be NeighbourhoodRCOMP-1M1-of r holds  ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 N1 & N c=TARSKIR1 N2"
proof-
  have " for r be RealXREAL-0M1 holds  for N1 be NeighbourhoodRCOMP-1M1-of r holds  for N2 be NeighbourhoodRCOMP-1M1-of r holds  ex tVar22 be NeighbourhoodRCOMP-1M1-of r st tVar22 c=TARSKIR1 N1 & tVar22 c=TARSKIR1 N2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of r"
    fix N2 assume [ty]: "N2 be NeighbourhoodRCOMP-1M1-of r"
    obtain g1 where
      [ty]:"g1 be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 g1"and A2: "].RCOMP-1K2 r -XCMPLX-0K6 g1,r +XCMPLX-0K2 g1 .[ =XBOOLE-0R4 N1"
      using rcomp_1_def_6 sorry
    obtain g2 where
      [ty]:"g2 be RealXREAL-0M1" and 
      A3: "0NUMBERSK6 <XXREAL-0R3 g2"and A4: "].RCOMP-1K2 r -XCMPLX-0K6 g2,r +XCMPLX-0K2 g2 .[ =XBOOLE-0R4 N2"
      using rcomp_1_def_6 sorry
    let ?g = "minXXREAL-0K4(g1,g2)"
    have "0NUMBERSK6 <XXREAL-0R3 ?g"
      using A1 A3 xxreal_0_th_15 sorry
    then obtain N where 
      [ty]:"N be NeighbourhoodRCOMP-1M1-of r" and NDef:"N = ].RCOMP-1K2 r -XCMPLX-0K6 ?g,r +XCMPLX-0K2 ?g .["
      using rcomp_1_def_6 sorry
    show " ex tVar22 be NeighbourhoodRCOMP-1M1-of r st tVar22 c=TARSKIR1 N1 & tVar22 c=TARSKIR1 N2"
    proof(rule bexI[of _ "N"])
      have A5: "?g <=XXREAL-0R1 g1"
        using xxreal_0_th_17 sorry
      then have A6: "r +XCMPLX-0K2 ?g <=XXREAL-0R1 r +XCMPLX-0K2 g1"
        using xreal_1_th_7 sorry
      have "-XCMPLX-0K4 g1 <=XXREAL-0R1 -XCMPLX-0K4 ?g"
        using A5 xreal_1_th_24 sorry
      then have A7: "r +XCMPLX-0K2 (-XCMPLX-0K4 g1) <=XXREAL-0R1 r +XCMPLX-0K2 (-XCMPLX-0K4 ?g)"
        using xreal_1_th_7 sorry
      have A8: "?g <=XXREAL-0R1 g2"
        using xxreal_0_th_17 sorry
      then have "-XCMPLX-0K4 g2 <=XXREAL-0R1 -XCMPLX-0K4 ?g"
        using xreal_1_th_24 sorry
      then have A9: "r +XCMPLX-0K2 (-XCMPLX-0K4 g2) <=XXREAL-0R1 r +XCMPLX-0K2 (-XCMPLX-0K4 ?g)"
        using xreal_1_th_7 sorry
      have A10: "r +XCMPLX-0K2 ?g <=XXREAL-0R1 r +XCMPLX-0K2 g2"
        using A8 xreal_1_th_7 sorry
      have "].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
      proof-
        show "].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
        proof-
          have cases: "g1 <=XXREAL-0R1 g2 or g2 <=XXREAL-0R1 g1"
             sorry
          have case1: "g1 <=XXREAL-0R1 g2 implies ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
          proof(rule impI)
            assume A11: "g1 <=XXREAL-0R1 g2"
            have A12: " for y be objectHIDDENM1 holds y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ implies y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 g2,r +XCMPLX-0K2 g2 .["
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A13: "y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 ?g,r +XCMPLX-0K2 ?g .["
              then obtain x1 where 
                [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = y"
                 sorry
              have " ex p2 be RealXREAL-0M1 st (y =HIDDENR1 p2 & r -XCMPLX-0K6 ?g <XXREAL-0R3 p2) & p2 <XXREAL-0R3 r +XCMPLX-0K2 ?g"
                using A13 sorry
              then have "x1 <XXREAL-0R3 r +XCMPLX-0K2 g2 & r -XCMPLX-0K6 g2 <XXREAL-0R3 x1"
                using A10 A9 xxreal_0_th_2 sorry
              thus "y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 g2,r +XCMPLX-0K2 g2 .["
                 sorry
            qed "sorry"
            have "g1 =COMPLEX1R1 ?g"
              using A11 xxreal_0_def_9 sorry
            thus "].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
              using A2 A4 A12 sorry
          qed
          have case2: "g2 <=XXREAL-0R1 g1 implies ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
          proof(rule impI)
            assume A14: "g2 <=XXREAL-0R1 g1"
            have A15: " for y be objectHIDDENM1 holds y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ implies y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 g1,r +XCMPLX-0K2 g1 .["
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A16: "y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 ?g,r +XCMPLX-0K2 ?g .["
              then obtain x1 where 
                [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = y"
                 sorry
              have " ex p2 be RealXREAL-0M1 st (y =HIDDENR1 p2 & r -XCMPLX-0K6 ?g <XXREAL-0R3 p2) & p2 <XXREAL-0R3 r +XCMPLX-0K2 ?g"
                using A16 sorry
              then have "x1 <XXREAL-0R3 r +XCMPLX-0K2 g1 & r -XCMPLX-0K6 g1 <XXREAL-0R3 x1"
                using A6 A7 xxreal_0_th_2 sorry
              thus "y inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 g1,r +XCMPLX-0K2 g1 .["
                 sorry
            qed "sorry"
            have "g2 =COMPLEX1R1 ?g"
              using A14 xxreal_0_def_9 sorry
            thus "].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N1 & ].RCOMP-1K2 r -XCMPLX-0K6 minXXREAL-0K4(g1,g2),r +XCMPLX-0K2 minXXREAL-0K4(g1,g2) .[ c=TARSKIR1 N2"
              using A2 A4 A15 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "N c=TARSKIR1 N1 & N c=TARSKIR1 N2"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_18:
" for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)"
proof-
  have " for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X & ( for N be NeighbourhoodRCOMP-1M1-of r holds  not N c=TARSKIR1 X) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r inHIDDENR3 X"
      and A2: " for N be NeighbourhoodRCOMP-1M1-of r holds  not N c=TARSKIR1 X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M),r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M) .[ & Lamb2 inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
    have A3: " for N be NeighbourhoodRCOMP-1M1-of r holds  ex s be ElementSUBSET-1M1-of REALNUMBERSK2 st s inTARSKIR2 N & s inTARSKIR2 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
    proof(rule ballI)
      fix N assume [ty]: "N be NeighbourhoodRCOMP-1M1-of r"
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        "0NUMBERSK6 <XXREAL-0R3 g"and A4: "N =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
        using rcomp_1_def_6 sorry
      have " not N c=TARSKIR1 X"
        using A2 sorry
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A5: "x inHIDDENR3 N"and A6: " not x inHIDDENR3 X"
         sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A7: "x =HIDDENR1 s"and "r -XCMPLX-0K6 g <XXREAL-0R3 s"and "s <XXREAL-0R3 r +XCMPLX-0K2 g"
        using A5 A4 sorry
      have 
        [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      show " ex s be ElementSUBSET-1M1-of REALNUMBERSK2 st s inTARSKIR2 N & s inTARSKIR2 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
      proof(rule bexI[of _ "s"],rule conjMI)
        show "s inTARSKIR2 N"
          using A5 A7 sorry
        show "s inTARSKIR2 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
          using A6 A7 xboole_0_def_5 sorry
      qed "sorry"
    qed "sorry"
    have A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex s be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,s)"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for s be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (s inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M),r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) .[ & s inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>))"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_0_def_9 sorry
        then obtain N where 
          [ty]:"N be NeighbourhoodRCOMP-1M1-of r" and NDef:"N = ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M),r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) .["
          using rcomp_1_def_6 sorry
        have " ex s be ElementSUBSET-1M1-of REALNUMBERSK2 st s inTARSKIR2 N & s inTARSKIR2 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
          using A3 sorry
        thus " not ( for s be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not (s inHIDDENR3 ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M),r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) .[ & s inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain s3 where
      [ty]:"s3 be Real-SequenceSEQ-1M1" and 
      A9: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A8 sorry
    let ?G = "\<lambda>Lamb1. r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    let ?F = "\<lambda>Lamb1. r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s1 where
      [ty]:"s1 be Real-SequenceSEQ-1M1" and 
      A10: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A11: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 ?G(n)"
      using seq_1_sch_1 sorry
    have A12: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 s3 .FUNCT-1K1 n & s3 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
    proof(rule ballI,rule conjMI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "n inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      then have "s3 .FUNCT-1K1 n inTARSKIR2 ].RCOMP-1K2 r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M),r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) .["
        using A9 sorry
      then have A13: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 s3 .FUNCT-1K1 n & r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s) & s <XXREAL-0R3 r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 s3 .FUNCT-1K1 n"
        using A10 sorry
      show "s3 .FUNCT-1K1 n <=XXREAL-0R1 s2 .FUNCT-1K1 n"
        using A11 A13 sorry
    qed "sorry"
    have A14: "rngFUNCT-1K2 s3 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 s3 implies x inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 s3"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A15: "y inHIDDENR3 domRELAT-1K1 s3"and A16: "s3 .FUNCT-1K1 y =HIDDENR1 x"
          using funct_1_def_3 sorry
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A15 funct_2_def_1 sorry
        have "s3 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> y inTARSKIR2 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
          using A9 sorry
        thus "x inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
          using A16 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 s3 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
        using tarski_def_3 sorry
    qed
    have A17: "X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> be closedRCOMP-1V2"
      using rcomp_1_def_5 sorry
    have A18: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be RealXREAL-0M1"
      assume A19: "0NUMBERSK6 <XXREAL-0R3 s"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A20: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A21: "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A20 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
          using A19 xreal_1_th_76 sorry
        then have A22: "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using xcmplx_1_th_216 sorry
        have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1  |.COMPLEX1K10 (r +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 r .|"
          using A11 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M)"
          using absvalue_def_1 sorry
        finally have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s"
          using A22 A21 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    then have A23: "s2 be convergentCOMSEQ-2V3"
       sorry
    then have A24: "limSEQ-2K1 s2 =COMPLEX1R1 r"
      using A18 seq_2_def_7 sorry
    have A25: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s)"
    proof(rule ballI,rule impI)
      fix s assume [ty]: "s be RealXREAL-0M1"
      assume A26: "0NUMBERSK6 <XXREAL-0R3 s"
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A27: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
        using seq_4_th_3 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "n <=XXREAL-0R1 m"
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A28: "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A27 xreal_1_th_8 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
          using A26 xreal_1_th_76 sorry
        then have A29: "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
          using xcmplx_1_th_216 sorry
        have " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1  |.COMPLEX1K10 (r -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 r .|"
          using A10 sorry
        also have "... =  |.COMPLEX1K10 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) .|"
           sorry
        also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) .|"
          using complex1_th_52 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M)"
          using absvalue_def_1 sorry
        finally have " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 r .| =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 r .| <XXREAL-0R3 s"
          using A29 A28 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    then have A30: "s1 be convergentCOMSEQ-2V3"
       sorry
    then have "limSEQ-2K1 s1 =COMPLEX1R1 r"
      using A25 seq_2_def_7 sorry
    then have "s3 be convergentCOMSEQ-2V3 & limSEQ-2K1 s3 =COMPLEX1R1 r"
      using A30 A23 A24 A12 seq_2_th_19 seq_2_th_20 sorry
    then have "r inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
      using A14 A17 sorry
    thus " False "
      using A1 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_19:
" for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex g be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 g & ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[ c=TARSKIR1 X)"
proof-
  have " for X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for r be RealXREAL-0M1 holds r inHIDDENR3 X implies ( ex tVar26 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar26 & ].RCOMP-1K2 r -XCMPLX-0K6 tVar26,r +XCMPLX-0K2 tVar26 .[ c=TARSKIR1 X)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume "r inHIDDENR3 X"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of r" and 
      A1: "N c=TARSKIR1 X"
      using rcomp_1_th_18 sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A2: "0NUMBERSK6 <XXREAL-0R3 g & N =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
      using rcomp_1_def_6 sorry
    show " ex tVar26 be RealXREAL-0M1 st  not 0NUMBERSK6 <XXREAL-0R3 tVar26 & ].RCOMP-1K2 r -XCMPLX-0K6 tVar26,r +XCMPLX-0K2 tVar26 .[ c=TARSKIR1 X"
    proof(rule bexI[of _ "g"])
      show " not 0NUMBERSK6 <XXREAL-0R3 g & ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .[ c=TARSKIR1 X"
        using A1 A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_20:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)) implies X be openRCOMP-1V3"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)) &  not X be openRCOMP-1V3 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 X implies ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 X)"
      and A2: " not X be openRCOMP-1V3"
    have " not X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub> be closedRCOMP-1V2"
      using A2 sorry
    then obtain s1 where
      [ty]:"s1 be Real-SequenceSEQ-1M1" and 
      A3: "rngFUNCT-1K2 s1 c=TARSKIR1 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"and A4: "s1 be convergentCOMSEQ-2V3"and A5: " not limSEQ-2K1 s1 inHIDDENR3 X `SUBSET-1K3\<^bsub>(REALNUMBERSK2)\<^esub>"
       sorry
    obtain ls where 
      [ty]:"ls be ElementSUBSET-1M1-of REALNUMBERSK2" and lsDef:"ls = limSEQ-2K1 s1"
      using xreal_0_def_1 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of ls" and 
      A6: "N c=TARSKIR1 X"
      using A1 A5 subset_1_th_29 sorry
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A7: "0NUMBERSK6 <XXREAL-0R3 g"and A8: "].RCOMP-1K2 limSEQ-2K1 s1 -XCMPLX-0K6 g,limSEQ-2K1 s1 +XCMPLX-0K2 g .[ =XBOOLE-0R4 N"
      using rcomp_1_def_6 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 g"
      using A4 A7 seq_2_def_7 sorry
    have "n inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have "n inTARSKIR2 domRELAT-1K1 s1"
      using funct_2_def_1 sorry
    then have A10: "s1 .FUNCT-1K1 n inTARSKIR2 rngFUNCT-1K2 s1"
      using funct_1_def_3 sorry
    have A11: " |.COMPLEX1K10 s1 .FUNCT-1K1 n -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 g"
      using A9 sorry
    then have "s1 .FUNCT-1K1 n -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 g"
      using seq_2_th_1 sorry
    then have A12: "s1 .FUNCT-1K1 n <XXREAL-0R3 limSEQ-2K1 s1 +XCMPLX-0K2 g"
      using xreal_1_th_19 sorry
    have "-XCMPLX-0K4 g <XXREAL-0R3 s1 .FUNCT-1K1 n -XCMPLX-0K6 limSEQ-2K1 s1"
      using A11 seq_2_th_1 sorry
    then have "limSEQ-2K1 s1 +XCMPLX-0K2 (-XCMPLX-0K4 g) <XXREAL-0R3 limSEQ-2K1 s1 +XCMPLX-0K2 (s1 .FUNCT-1K1 n -XCMPLX-0K6 limSEQ-2K1 s1)"
      using xreal_1_th_6 sorry
    then have "s1 .FUNCT-1K1 n inTARSKIR2 {s where s be RealXREAL-0M1 : limSEQ-2K1 s1 -XCMPLX-0K6 g <XXREAL-0R3 s & s <XXREAL-0R3 limSEQ-2K1 s1 +XCMPLX-0K2 g }"
      using A12 sorry
    thus " False "
      using A3 A6 A8 A10 xboole_0_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_21:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>bounded-aboveXXREAL-2V4 implies  not upper-boundSEQ-4K2 X inHIDDENR3 X"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3 & X be bounded-aboveXXREAL-2V4 implies (upper-boundSEQ-4K2 X inHIDDENR3 X implies  False )"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be openRCOMP-1V3"
      and A2: "X be bounded-aboveXXREAL-2V4"
    assume "upper-boundSEQ-4K2 X inHIDDENR3 X"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of upper-boundSEQ-4K2 X" and 
      A3: "N c=TARSKIR1 X"
      using A1 rcomp_1_th_18 sorry
    obtain t where
      [ty]:"t be RealXREAL-0M1" and 
      A4: "t >XXREAL-0R4 0NUMBERSK6"and A5: "N =XBOOLE-0R4 ].RCOMP-1K2 upper-boundSEQ-4K2 X -XCMPLX-0K6 t,upper-boundSEQ-4K2 X +XCMPLX-0K2 t .["
      using rcomp_1_def_6 sorry
    have A6: "upper-boundSEQ-4K2 X +XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 upper-boundSEQ-4K2 X"
      using A4 xreal_1_th_29 xreal_1_th_215 sorry
    have A7: "(upper-boundSEQ-4K2 X +XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 upper-boundSEQ-4K2 X +XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M"
      using A4 xreal_1_th_29 xreal_1_th_215 sorry
    have "upper-boundSEQ-4K2 X -XCMPLX-0K6 t <XXREAL-0R3 upper-boundSEQ-4K2 X"
      using A4 xreal_1_th_44 sorry
    then have "upper-boundSEQ-4K2 X -XCMPLX-0K6 t <XXREAL-0R3 upper-boundSEQ-4K2 X +XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M"
      using A6 xxreal_0_th_2 sorry
    then have "upper-boundSEQ-4K2 X +XCMPLX-0K2 t /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : upper-boundSEQ-4K2 X -XCMPLX-0K6 t <XXREAL-0R3 s & s <XXREAL-0R3 upper-boundSEQ-4K2 X +XCMPLX-0K2 t }"
      using A7 sorry
    thus " False "
      using A2 A3 A5 A6 seq_4_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_22:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>bounded-belowXXREAL-2V3 implies  not lower-boundSEQ-4K3 X inHIDDENR3 X"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3 & X be bounded-belowXXREAL-2V3 implies (lower-boundSEQ-4K3 X inHIDDENR3 X implies  False )"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be openRCOMP-1V3"
      and A2: "X be bounded-belowXXREAL-2V3"
    assume "lower-boundSEQ-4K3 X inHIDDENR3 X"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of lower-boundSEQ-4K3 X" and 
      A3: "N c=TARSKIR1 X"
      using A1 rcomp_1_th_18 sorry
    obtain t where
      [ty]:"t be RealXREAL-0M1" and 
      A4: "t >XXREAL-0R4 0NUMBERSK6"and A5: "N =XBOOLE-0R4 ].RCOMP-1K2 lower-boundSEQ-4K3 X -XCMPLX-0K6 t,lower-boundSEQ-4K3 X +XCMPLX-0K2 t .["
      using rcomp_1_def_6 sorry
    have A6: "lower-boundSEQ-4K3 X -XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 lower-boundSEQ-4K3 X"
      using A4 xreal_1_th_44 xreal_1_th_215 sorry
    have A7: "(lower-boundSEQ-4K3 X -XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 lower-boundSEQ-4K3 X -XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M"
      using A4 xreal_1_th_44 xreal_1_th_215 sorry
    have "lower-boundSEQ-4K3 X <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 t"
      using A4 xreal_1_th_29 sorry
    then have "lower-boundSEQ-4K3 X -XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 t"
      using A6 xxreal_0_th_2 sorry
    then have "lower-boundSEQ-4K3 X -XCMPLX-0K6 t /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : lower-boundSEQ-4K3 X -XCMPLX-0K6 t <XXREAL-0R3 s & s <XXREAL-0R3 lower-boundSEQ-4K3 X +XCMPLX-0K2 t }"
      using A7 sorry
    thus " False "
      using A2 A3 A5 A6 seq_4_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rcomp_1_th_23:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3\<bar>real-boundedXXREAL-2V5 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X) implies ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[)"
proof-
  have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be openRCOMP-1V3 & (X be real-boundedXXREAL-2V5 & ( for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X)) implies ( ex tVar27 be RealXREAL-0M1 st  ex tVar28 be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 tVar27,tVar28 .[)"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "X be openRCOMP-1V3"
      and A2: "X be real-boundedXXREAL-2V5"
      and A3: " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 X & g2 inHIDDENR3 X implies [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X"
    show " ex tVar27 be RealXREAL-0M1 st  ex tVar28 be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 tVar27,tVar28 .["
    proof-
      have cases: "X =XBOOLE-0R4 {}XBOOLE-0K1 or X <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies ( ex tVar27 be RealXREAL-0M1 st  ex tVar28 be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 tVar27,tVar28 .[)"
      proof(rule impI)
        assume A4: "X =XBOOLE-0R4 {}XBOOLE-0K1"
        show " ex tVar27 be RealXREAL-0M1 st  ex tVar28 be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 tVar27,tVar28 .["
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          show " ex tVar28 be RealXREAL-0M1 st X =XBOOLE-0R4 ].RCOMP-1K2 \<one>\<^sub>M,tVar28 .["
          proof(rule bexI[of _ "0NUMBERSK6"])
            show "X =XBOOLE-0R4 ].RCOMP-1K2 \<one>\<^sub>M,0NUMBERSK6 .["
              using A4 xxreal_1_th_28 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "X <>HIDDENR2 {}XBOOLE-0K1 implies ( ex p be objectHIDDENM1 st  ex g be objectHIDDENM1 st X =XBOOLE-0R4 ].RCOMP-1K2 p,g .[)"
      proof(rule impI)
        assume A5: "X <>HIDDENR2 {}XBOOLE-0K1"
        obtain p where 
          [ty]:"p be objectHIDDENM1" and pDef:"p = lower-boundSEQ-4K3 X"
           sorry
        show " ex p be objectHIDDENM1 st  ex g be objectHIDDENM1 st X =XBOOLE-0R4 ].RCOMP-1K2 p,g .["
        proof(rule bexI[of _ "p"])
          obtain g where 
            [ty]:"g be objectHIDDENM1" and gDef:"g = upper-boundSEQ-4K2 X"
             sorry
          show " ex g be objectHIDDENM1 st X =XBOOLE-0R4 ].RCOMP-1K2 p,g .["
          proof(rule bexI[of _ "g"])
            have " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds (r inTARSKIR2 X implies r inTARSKIR2 ].RCOMP-1K2 p,g .[) & (r inTARSKIR2 ].RCOMP-1K2 p,g .[ implies r inTARSKIR2 X)"
            proof(rule ballI,rule conjMI,rule impI)
              fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
              show "r inTARSKIR2 X implies r inTARSKIR2 ].RCOMP-1K2 p,g .["
              proof(rule impI)
                assume A6: "r inTARSKIR2 X"
                then have "p <>HIDDENR2 r & p <=XXREAL-0R1 r"
                  using A1 A2 rcomp_1_th_22 seq_4_def_2 sorry
                then have A7: "p <XXREAL-0R3 r"
                  using xxreal_0_th_1 sorry
                have "g <>HIDDENR2 r & r <=XXREAL-0R1 g"
                  using A1 A2 A6 rcomp_1_th_21 seq_4_def_1 sorry
                then have "r <XXREAL-0R3 g"
                  using xxreal_0_th_1 sorry
                thus "r inTARSKIR2 ].RCOMP-1K2 p,g .["
                  using A7 sorry
              qed
              assume "r inTARSKIR2 ].RCOMP-1K2 p,g .["
              then have A8: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & p <XXREAL-0R3 s) & s <XXREAL-0R3 g"
                 sorry
              then have "g -XCMPLX-0K6 r >XXREAL-0R4 0NUMBERSK6"
                using xreal_1_th_50 sorry
              then obtain g2 where
                [ty]:"g2 be RealXREAL-0M1" and 
                A9: "g2 inHIDDENR3 X & g -XCMPLX-0K6 (g -XCMPLX-0K6 r) <XXREAL-0R3 g2"
                using A2 A5 seq_4_def_1 sorry
              have "r -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                using A8 xreal_1_th_50 sorry
              then obtain g1 where
                [ty]:"g1 be RealXREAL-0M1" and 
                A10: "g1 inHIDDENR3 X & g1 <XXREAL-0R3 p +XCMPLX-0K2 (r -XCMPLX-0K6 p)"
                using A2 A5 seq_4_def_2 sorry
              have 
                [ty]:"g1 be RealXREAL-0M1" and
                [ty]:"g2 be RealXREAL-0M1"
                 sorry
              have "r inTARSKIR2 {s where s be RealXREAL-0M1 : g1 <=XXREAL-0R1 s & s <=XXREAL-0R1 g2 } & [.RCOMP-1K1 g1,g2 .] c=TARSKIR1 X"
                using A3 A9 A10 sorry
              thus "r inTARSKIR2 X"
                 sorry
            qed "sorry"
            thus "X =XBOOLE-0R4 ].RCOMP-1K2 p,g .["
              using subset_1_th_3 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RCOMP_1K3("[.RCOMP-1K3 _ , _ .[" [0,0]164) where
  "[.RCOMP-1K3 g,s .[ \<equiv> [.XXREAL-1K2 g,s .["

mtheorem rcomp_1_def_7:
  mlet "g be RealXREAL-0M1", "s be ExtRealXXREAL-0M1"
"redefine func [.RCOMP-1K3 g,s .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 [.RCOMP-1K3 g,s .[ iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s }"
  proof-
    have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =HIDDENR1 [.XXREAL-1K2 g,s .[ &  not X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s } &  not X =HIDDENR1 [.XXREAL-1K2 g,s .[)"
    proof(rule ballI)
      let ?Y = "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s }"
      fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      have A2: "[.XXREAL-1K2 g,s .[ c=TARSKIR1 ?Y"
      proof-
        have "[.XXREAL-1K2 g,s .[ c=TARSKIR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 [.XXREAL-1K2 g,s .[ implies e inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 [.XXREAL-1K2 g,s .["
            then obtain r where
              [ty]:"r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3" and 
              A3: "e =HIDDENR1 r"and A4: "g <=XXREAL-0R1 r & r <XXREAL-0R3 s"
               sorry
            have "g inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            then have "r inTARSKIR2 REALNUMBERSK2"
              using A4 xxreal_0_th_46 sorry
            thus "e inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }"
              using A3 A4 sorry
          qed "sorry"
          thus "[.XXREAL-1K2 g,s .[ c=TARSKIR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "?Y c=TARSKIR1 [.XXREAL-1K2 g,s .["
      proof-
        have "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s } c=TARSKIR1 [.XXREAL-1K2 g,s .["
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r & r <XXREAL-0R3 s } implies e inHIDDENR3 [.XXREAL-1K2 g,s .["
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 ?Y"
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A5: "(e =HIDDENR1 r & g <=XXREAL-0R1 r) & r <XXREAL-0R3 s"
               sorry
            have "r inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "e inHIDDENR3 [.XXREAL-1K2 g,s .["
              using A5 numbers_th_31 sorry
          qed "sorry"
          thus "{r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s } c=TARSKIR1 [.XXREAL-1K2 g,s .["
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not (X =HIDDENR1 [.XXREAL-1K2 g,s .[ &  not X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 : g <=XXREAL-0R1 r &  not r <XXREAL-0R3 s } &  not X =HIDDENR1 [.XXREAL-1K2 g,s .[)"
        using A2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rcomp_1_add_3:
  mlet "g be RealXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 g,s .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "[.XXREAL-1K2 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have " for e be objectHIDDENM1 holds e inHIDDENR3 [.XXREAL-1K2 g,s .[ implies e inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 [.XXREAL-1K2 g,s .["
      then have A1: " ex r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (e =HIDDENR1 r & g <=XXREAL-0R1 r) & r <XXREAL-0R3 s"
         sorry
      have "g inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "e inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_46 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 g,s .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using tarski_def_3 sorry
  qed
qed "sorry"

abbreviation(input) RCOMP_1K4("].RCOMP-1K4 _ , _ .]" [0,0]164) where
  "].RCOMP-1K4 g,s .] \<equiv> ].XXREAL-1K3 g,s .]"

mtheorem rcomp_1_def_8:
  mlet "g be ExtRealXXREAL-0M1", "s be RealXREAL-0M1"
"redefine func ].RCOMP-1K4 g,s .] \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 equals
  {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].RCOMP-1K4 g,s .] iff it =HIDDENR1 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
  proof-
    have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not (X =HIDDENR1 ].XXREAL-1K3 g,s .] &  not X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s } &  not X =HIDDENR1 ].XXREAL-1K3 g,s .])"
    proof(rule ballI)
      let ?Y = "{r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
      fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      have A2: "].XXREAL-1K3 g,s .] c=TARSKIR1 ?Y"
      proof-
        have "].XXREAL-1K3 g,s .] c=TARSKIR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 ].XXREAL-1K3 g,s .] implies e inHIDDENR3 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 ].XXREAL-1K3 g,s .]"
            then obtain r where
              [ty]:"r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3" and 
              A3: "e =HIDDENR1 r"and A4: "g <XXREAL-0R3 r & r <=XXREAL-0R1 s"
               sorry
            have "s inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            then have "r inTARSKIR2 REALNUMBERSK2"
              using A4 xxreal_0_th_47 sorry
            thus "e inHIDDENR3 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
              using A3 A4 sorry
          qed "sorry"
          thus "].XXREAL-1K3 g,s .] c=TARSKIR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "?Y c=TARSKIR1 ].XXREAL-1K3 g,s .]"
      proof-
        have "{r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s } c=TARSKIR1 ].XXREAL-1K3 g,s .]"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 {r where r be RealXREAL-0M1 : g <XXREAL-0R3 r & r <=XXREAL-0R1 s } implies e inHIDDENR3 ].XXREAL-1K3 g,s .]"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 ?Y"
            then obtain r where
              [ty]:"r be RealXREAL-0M1" and 
              A5: "(e =HIDDENR1 r & g <XXREAL-0R3 r) & r <=XXREAL-0R1 s"
               sorry
            have "r inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "e inHIDDENR3 ].XXREAL-1K3 g,s .]"
              using A5 numbers_th_31 sorry
          qed "sorry"
          thus "{r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s } c=TARSKIR1 ].XXREAL-1K3 g,s .]"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not (X =HIDDENR1 ].XXREAL-1K3 g,s .] &  not X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s }) &  not (X =HIDDENR1 {r where r be RealXREAL-0M1 :  not g <XXREAL-0R3 r & r <=XXREAL-0R1 s } &  not X =HIDDENR1 ].XXREAL-1K3 g,s .])"
        using A2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem rcomp_1_add_4:
  mlet "g be ExtRealXXREAL-0M1", "s be RealXREAL-0M1"
"cluster ].XXREAL-1K3 g,s .] as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K3 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have " for e be objectHIDDENM1 holds e inHIDDENR3 ].XXREAL-1K3 g,s .] implies e inHIDDENR3 REALNUMBERSK2"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 ].XXREAL-1K3 g,s .]"
      then have A1: " ex r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st (e =HIDDENR1 r & g <XXREAL-0R3 r) & r <=XXREAL-0R1 s"
         sorry
      have "s inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus "e inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_47 sorry
    qed "sorry"
    thus "].XXREAL-1K3 g,s .] be SubsetSUBSET-1M2-of REALNUMBERSK2"
      using tarski_def_3 sorry
  qed
qed "sorry"

end
