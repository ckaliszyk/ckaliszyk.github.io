theory fdiff_2
  imports scheme1 rolle fcont_3 funct_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x for "objectHIDDENM1"
reserve x0, r, r1, r2, g, g1, g2, p, y0 for "RealXREAL-0M1"
reserve n, m, k, l for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve a, b, d for "Real-SequenceSEQ-1M1"
reserve h, h1, h2 for "non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
reserve c, c1 for "constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
reserve A for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
reserve L for "LinearFuncFDIFF-1M2"
reserve R for "RestFuncFDIFF-1M1"
mtheorem fdiff_2_cl_1:
  mlet "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
"cluster -VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h as-term-is non-zeroORDINAL1V9\<bar>convergentCOMSEQ-2V3"
proof
(*coherence*)
  show "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h be non-zeroORDINAL1V9\<bar>convergentCOMSEQ-2V3"
    using seq_1_th_45 sorry
qed "sorry"

mtheorem fdiff_2_th_1:
" for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for d be Real-SequenceSEQ-1M1 holds ((a be convergentSEQ-2V5 & b be convergentSEQ-2V5) & limSEQ-2K1 a =COMPLEX1R1 limSEQ-2K1 b) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies d be convergentSEQ-2V5 & limSEQ-2K1 d =COMPLEX1R1 limSEQ-2K1 a"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds  for d be Real-SequenceSEQ-1M1 holds a be convergentSEQ-2V5 & (b be convergentSEQ-2V5 & (limSEQ-2K1 a =COMPLEX1R1 limSEQ-2K1 b & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))) implies d be convergentSEQ-2V5 & limSEQ-2K1 d =COMPLEX1R1 limSEQ-2K1 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    fix d assume [ty]: "d be Real-SequenceSEQ-1M1"
    assume A1: "a be convergentSEQ-2V5"
      and A2: "b be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 a =COMPLEX1R1 limSEQ-2K1 b"
      and A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    have A5: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r)"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume A6: "0NUMBERSK6 <XXREAL-0R3 r"
      then obtain k1 where
        [ty]:"k1 be NatNAT-1M1" and 
        A7: " for m be NatNAT-1M1 holds k1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 a .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
        using A1 seq_2_def_7 sorry
      obtain k2 where
        [ty]:"k2 be NatNAT-1M1" and 
        A8: " for m be NatNAT-1M1 holds k2 <=XXREAL-0R1 m implies  |.COMPLEX1K10 b .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 b .| <XXREAL-0R3 r"
        using A2 A6 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be NatNAT-1M1" and nDef:"n = maxXXREAL-0K5(\<two>\<^sub>M *XCMPLX-0K3 k1,\<two>\<^sub>M *XCMPLX-0K3 k2 +NAT-1K1 \<one>\<^sub>M)"
        using tarski_th_1 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A9: "n <=XXREAL-0R1 m"
        then have A10: "\<two>\<^sub>M *XCMPLX-0K3 k2 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using xxreal_0_th_30 sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A11: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n or m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
          using scheme1_th_1 sorry
        have A12: "\<two>\<^sub>M *XCMPLX-0K3 k1 <=XXREAL-0R1 m"
          using A9 xxreal_0_th_30 sorry
        have " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
        proof-
          show " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
          proof-
            have cases: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n or m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
              using A11 sorry
            have case1: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n implies  |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
            proof(rule impI)
              assume A13: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n"
              then have A14: "n >=XXREAL-0R2 k1"
                using A12 xreal_1_th_68 sorry
              have " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| =COMPLEX1R1  |.COMPLEX1K10 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 limSEQ-2K1 a .|"
                using A4 A13 sorry
              thus " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
                using A7 A14 sorry
            qed
            have case2: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M implies  |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
            proof(rule impI)
              assume A15: "m =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
              have A16: "n <XXREAL-0R3 k2 implies  False "
              proof(rule impI)
                assume "n <XXREAL-0R3 k2"
                then have "\<two>\<^sub>M *NAT-1K2 n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 k2"
                  using xreal_1_th_68 sorry
                thus " False "
                  using A10 A15 xreal_1_th_6 sorry
              qed
              have " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| =COMPLEX1R1  |.COMPLEX1K10 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 limSEQ-2K1 a .|"
                using A4 A15 sorry
              thus " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
                using A3 A8 A16 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " |.COMPLEX1K10 d .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 a .| <XXREAL-0R3 r"
           sorry
      qed "sorry"
    qed "sorry"
    thus "d be convergentSEQ-2V5"
      using seq_2_def_6 sorry
    thus "limSEQ-2K1 d =COMPLEX1R1 limSEQ-2K1 a"
      using A5 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_2:
" for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n"
    have A2: "a be increasingVALUED-0V9"
    proof-
      have " for n be NatNAT-1M1 holds a .FUNCT-1K1 n <XXREAL-0R3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A4: "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        finally have "\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "a .FUNCT-1K1 n <XXREAL-0R3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 A4 A3 sorry
      qed "sorry"
      thus "a be increasingVALUED-0V9"
        using valued_1_def_13 sorry
    qed
    have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies a .FUNCT-1K1 x inTARSKIR2 NATNUMBERSK1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 NATNUMBERSK1"
      then obtain n where 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
         sorry
      have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n"
        using A1 sorry
      thus "a .FUNCT-1K1 x inTARSKIR2 NATNUMBERSK1"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> a =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    thus "a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
      using A2 A5 funct_2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_3:
" for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) implies a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    assume A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
    have A2: "a be increasingVALUED-0V9"
    proof-
      have " for n be NatNAT-1M1 holds a .FUNCT-1K1 n <XXREAL-0R3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A4: "(\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 0NUMBERSK6 <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        have "(\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
        also have "... = a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        finally have "(\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "a .FUNCT-1K1 n <XXREAL-0R3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 A4 A3 sorry
      qed "sorry"
      thus "a be increasingVALUED-0V9"
        using valued_1_def_13 sorry
    qed
    have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> a implies a .FUNCT-1K1 x inTARSKIR2 NATNUMBERSK1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> a"
      then obtain n where 
        [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
         sorry
      have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M"
        using A1 sorry
      thus "a .FUNCT-1K1 x inTARSKIR2 NATNUMBERSK1"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> a =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    thus "a be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
      using A2 A5 funct_2_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_4:
" for x0 be RealXREAL-0M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} implies ((c be convergentSEQ-2V5 & limSEQ-2K1 c =COMPLEX1R1 x0) & h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5) & limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} implies c be convergentSEQ-2V5 & (limSEQ-2K1 c =COMPLEX1R1 x0 & (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5 & limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
    assume A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
    show "c be convergentSEQ-2V5"
       sorry
    have "x0 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
      using A1 tarski_def_1 sorry
    thus A2: "limSEQ-2K1 c =COMPLEX1R1 x0"
      using seq_4_th_25 sorry
    show "h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
       sorry
    have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 x0"
      using A2 seq_2_th_6 sorry
    also have "... = x0"
       sorry
    finally show "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_5:
" for r be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> b =XBOOLE-0R4 {TARSKIK1 r} implies a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b"
proof-
  have " for r be RealXREAL-0M1 holds  for a be Real-SequenceSEQ-1M1 holds  for b be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> b =XBOOLE-0R4 {TARSKIK1 r} implies a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix b assume [ty]: "b be Real-SequenceSEQ-1M1"
    assume A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r}"
      and A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> b =XBOOLE-0R4 {TARSKIK1 r}"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
        using valued_0_th_28 sorry
      then have A3: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 r"
        using A1 tarski_def_1 sorry
      have "b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> b"
        using valued_0_th_28 sorry
      thus "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A2 A3 tarski_def_1 sorry
    qed "sorry"
    thus "a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_6:
" for a be Real-SequenceSEQ-1M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds a be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h implies a be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds a be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h implies a be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    assume A1: "a be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h"
    then obtain I where
      [ty]:"I be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A2: "a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I"
      using valued_0_def_17 sorry
    have " not ( ex n be NatNAT-1M1 st a .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6)"
      using A2 seq_1_th_5 sorry
    then have A3: "a be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
    have A4: "a be convergentSEQ-2V5"
      using A1 seq_4_th_16 sorry
    have "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6"
      using A1 seq_4_th_17 sorry
    thus "a be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      using A4 A3 fdiff_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_7:
" for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies ( for h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for h2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
proof-
  have " for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies ( for h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for h2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)) implies limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
    fix h1 assume [ty]: "h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix h2 assume [ty]: "h2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
    assume A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 g}"
      and A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A5: "{TARSKIK1 g} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    let ?G = "\<lambda>Lamb1. h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1"
    let ?F = "\<lambda>Lamb1. h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1"
    obtain a where
      [ty]:"a be Real-SequenceSEQ-1M1" and 
      A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) =COMPLEX1R1 ?F(n) & a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ?G(n)"
      using scheme1_sch_2 sorry
    have " for n be NatNAT-1M1 holds a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain m where
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A7: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m or n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
        using scheme1_th_1 sorry
      have "a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
      proof-
        show "a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        proof-
          have cases: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m or n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
            using A7 sorry
          have case1: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m implies a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          proof(rule impI)
            assume "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m"
            then have "a .FUNCT-1K1 n =COMPLEX1R1 h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
              using A6 sorry
            thus "a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
              using seq_1_th_5 sorry
          qed
          have case2: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M implies a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          proof(rule impI)
            assume "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
            then have "a .FUNCT-1K1 n =COMPLEX1R1 h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
              using A6 sorry
            thus "a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
              using seq_1_th_5 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "a .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
         sorry
    qed "sorry"
    then have A8: "a be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
    have A9: "limSEQ-2K1 h1 =COMPLEX1R1 0NUMBERSK6"
       sorry
    have A10: "limSEQ-2K1 h2 =COMPLEX1R1 0NUMBERSK6"
       sorry
    have A11: "a be convergentSEQ-2V5"
      using A6 A9 A10 fdiff_2_th_1 sorry
    have "limSEQ-2K1 a =COMPLEX1R1 0NUMBERSK6"
      using A6 A9 A10 fdiff_2_th_1 sorry
    then have 
      [ty]:"a be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
      using A11 A8 fdiff_1_def_1 sorry
    have A12: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A13: "x =HIDDENR1 (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using funct_2_th_113 sorry
        obtain m where
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m or n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
          using scheme1_th_1 sorry
        have "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          show "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof-
            have cases: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m or n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
              using A14 sorry
            have case1: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m implies (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule impI)
              assume A15: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m"
              have A16: "(h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                using valued_0_th_28 sorry
              have "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A6 A15 sorry
              also have "... = h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                using valued_0_th_23 sorry
              also have "... = (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                using seq_1_th_7 sorry
              finally have "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                 sorry
              thus "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A3 A16 sorry
            qed
            have case2: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M implies (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule impI)
              assume A17: "n =COMPLEX1R1 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
              have A18: "(h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                using valued_0_th_28 sorry
              have "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A6 A17 sorry
              also have "... = h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                using valued_0_th_23 sorry
              also have "... = (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                using seq_1_th_7 sorry
              finally have "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                 sorry
              thus "(a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A4 A18 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A13 sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using tarski_def_3 sorry
    qed
    then have A19: "a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
      using A1 A2 A5 sorry
    let ?G = "\<lambda>Lamb1. \<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<one>\<^sub>M"
    obtain d where
      [ty]:"d be Real-SequenceSEQ-1M1" and 
      A20: " for n be NatNAT-1M1 holds d .FUNCT-1K1 n =COMPLEX1R1 ?G(n)"
      using seq_1_sch_1 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?G(n)"
      using A20 sorry
    then obtain I2 where 
      [ty]:"I2 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and I2Def:"I2 = d"
      using fdiff_2_th_3 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)"
        using A20 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)"
        using seq_1_th_8 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using rfunct_2_th_1 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (f .FUNCT-1K1 ((a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using A12 funct_2_th_108 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using seq_1_th_7 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (f .FUNCT-1K1 (h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using A6 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (f .FUNCT-1K1 (h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using valued_0_th_23 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (f .FUNCT-1K1 ((h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using seq_1_th_7 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using A4 funct_2_th_108 sorry
      also have "... = (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))\<inverse>REAL-1K2 *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using valued_1_th_10 sorry
      also have "... = (h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using A6 sorry
      also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M))"
        using valued_1_th_10 sorry
      also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n +NAT-1K1 \<one>\<^sub>M)))"
        using A2 A5 funct_2_th_108 sorry
      also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
        using valued_0_th_23 sorry
      also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using A2 A5 funct_2_th_108 sorry
      also have "... = h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using rfunct_2_th_1 sorry
      also have "... = (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A21: "(a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
       sorry
    have "(a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
      using valued_0_def_17 sorry
    then have A22: "limSEQ-2K1 ((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) =COMPLEX1R1 limSEQ-2K1 (a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using A19 seq_4_th_17 sorry
    let ?F = "\<lambda>Lamb1. \<two>\<^sub>M *XCMPLX-0K3 Lamb1"
    obtain b where
      [ty]:"b be Real-SequenceSEQ-1M1" and 
      A23: " for n be NatNAT-1M1 holds b .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
      using seq_1_sch_1 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
      using A23 sorry
    then obtain I1 where 
      [ty]:"I1 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and I1Def:"I1 = b"
      using fdiff_2_th_2 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I1 .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = (a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)"
        using A23 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)"
        using seq_1_th_8 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using rfunct_2_th_1 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *XCMPLX-0K3 (f .FUNCT-1K1 ((a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using A12 funct_2_th_108 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *XCMPLX-0K3 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using seq_1_th_7 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *XCMPLX-0K3 (f .FUNCT-1K1 (h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using A6 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *XCMPLX-0K3 (f .FUNCT-1K1 (h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using valued_0_th_23 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using seq_1_th_7 sorry
      also have "... = a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n) *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using A3 funct_2_th_108 sorry
      also have "... = (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))\<inverse>REAL-1K2 *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using valued_1_th_10 sorry
      also have "... = (h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2 *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using A6 sorry
      also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n))"
        using valued_1_th_10 sorry
      also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (\<two>\<^sub>M *NAT-1K2 n)))"
        using A2 A5 funct_2_th_108 sorry
      also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
        using valued_0_th_23 sorry
      also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using A2 A5 funct_2_th_108 sorry
      also have "... = h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using rfunct_2_th_1 sorry
      also have "... = (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_8 sorry
      finally show "((a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A24: "(a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
       sorry
    have "(a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of a \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (a +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
      using valued_0_def_17 sorry
    thus "limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 limSEQ-2K1 (h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using A19 A22 A24 A21 seq_4_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_8:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ( ex h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 st  ex c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 st (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 r} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies ( ex tVar2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 st  ex tVar3 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> tVar3 =XBOOLE-0R4 {TARSKIK1 r} & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (tVar2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar3) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & {TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f))"
  proof(rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex N be NeighbourhoodRCOMP-1M1-of r st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of r" and 
      A1: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    obtain r0 where 
      [ty]:"r0 be ElementSUBSET-1M1-of REALNUMBERSK2" and r0Def:"r0 = r"
      using xreal_0_def_1 sorry
    let ?a = "seq-constSEQ-1K1 r"
    obtain g where
      [ty]:"g be RealXREAL-0M1" and 
      A2: "0NUMBERSK6 <XXREAL-0R3 g"and A3: "N =XBOOLE-0R4 ].RCOMP-1K2 r -XCMPLX-0K6 g,r +XCMPLX-0K2 g .["
      using rcomp_1_def_6 sorry
    obtain a where 
      [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
       sorry
    let ?G = "\<lambda>Lamb1. g /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<two>\<^sub>M)"
    obtain b where
      [ty]:"b be Real-SequenceSEQ-1M1" and 
      A4: " for n be NatNAT-1M1 holds b .FUNCT-1K1 n =COMPLEX1R1 ?G(n)"
      using seq_1_sch_1 sorry
    have A5: "limSEQ-2K1 b =COMPLEX1R1 0NUMBERSK6"
      using A4 seq_4_th_31 sorry
    have A6: "b be convergentSEQ-2V5"
      using A4 seq_4_th_31 sorry
    have " for n be NatNAT-1M1 holds 0NUMBERSK6 <>HIDDENR2 b .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "0NUMBERSK6 <XXREAL-0R3 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
        using A2 sorry
      thus "0NUMBERSK6 <>HIDDENR2 b .FUNCT-1K1 n"
        using A4 sorry
    qed "sorry"
    then have "b be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
    then have 
      [ty]:"b be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
      using A6 A5 fdiff_1_def_1 sorry
    show " ex tVar2 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 st  ex tVar3 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> tVar3 =XBOOLE-0R4 {TARSKIK1 r} & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (tVar2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar3) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & {TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
    proof(rule bexI[of _ "b"])
      show " ex tVar3 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> tVar3 =XBOOLE-0R4 {TARSKIK1 r} & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar3) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & {TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
      proof(rule bexI[of _ "a"],rule conjMI,rule conjMI)
        show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r}"
        proof-
          have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 r} & {TARSKIK1 r} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
          proof(rule conjMI)
            show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 r}"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 {TARSKIK1 r}"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using funct_2_th_113 sorry
                then have "x =HIDDENR1 r"
                  using seq_1_th_57 sorry
                thus "x inHIDDENR3 {TARSKIK1 r}"
                  using tarski_def_1 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 r}"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 r} implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 {TARSKIK1 r}"
              then have "x =HIDDENR1 r"
                using tarski_def_1 sorry
              also have "... = a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
                using seq_1_th_57 sorry
              finally have "x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
                 sorry
              thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                using valued_0_th_28 sorry
            qed "sorry"
            thus "{TARSKIK1 r} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
              using tarski_def_3 sorry
          qed
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 r}"
            using xboole_0_def_10 sorry
        qed
        show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A7: "x =HIDDENR1 (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using funct_2_th_113 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<two>\<^sub>M"
              using xreal_1_th_8 sorry
            then have "g *XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 g *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)"
              using A2 xreal_1_th_97 sorry
            then have "g *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 (g *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)\<inverse>XCMPLX-0K5"
              using xreal_1_th_68 sorry
            then have "g *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 g *XCMPLX-0K3 ((n +NAT-1K1 \<two>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)\<inverse>XCMPLX-0K5)"
               sorry
            then have "g *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 g *XCMPLX-0K3 \<one>\<^sub>M"
              using xcmplx_0_def_7 sorry
            then have "g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 g"
              using xcmplx_0_def_9 sorry
            then have A8: "r +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 r +XCMPLX-0K2 g"
              using xreal_1_th_6 sorry
            have A9: "r -XCMPLX-0K6 g <XXREAL-0R3 r -XCMPLX-0K6 0NUMBERSK6"
              using A2 xreal_1_th_15 sorry
            have "r +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 r +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
              using A2 xreal_1_th_8 sorry
            then have "r -XCMPLX-0K6 g <XXREAL-0R3 r +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
              using A9 xxreal_0_th_2 sorry
            then have A10: "r +XCMPLX-0K2 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : r -XCMPLX-0K6 g <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r +XCMPLX-0K2 g }"
              using A8 sorry
            have "x =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A7 seq_1_th_7 sorry
            also have "... = g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A4 sorry
            also have "... = g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 r"
              using seq_1_th_57 sorry
            finally have "x =HIDDENR1 g /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 r"
               sorry
            then have "x inHIDDENR3 N"
              using A3 A10 rcomp_1_def_2 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A1 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 r} implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {TARSKIK1 r}"
          then have "x =HIDDENR1 r"
            using tarski_def_1 sorry
          then have "x inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
        qed "sorry"
        thus "{TARSKIK1 r} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using tarski_def_3 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_9:
" for a be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
proof-
  have " for a be Real-SequenceSEQ-1M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be Real-SequenceSEQ-1M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    then have A2: "f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using funct_1_th_101 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 funct_1_th_101 sorry
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 valued_0_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem fdiff_2_sch_1:
  fixes sf0 Pp1 
  assumes
[ty]: "sf0 be Real-SequenceSEQ-1M1" and
   A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
  shows " ex q be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st ( for n be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> q).FUNCT-1K1 n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 q .RECDEF-1K1 m))"
  proof-
    have " ex tVar8 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st ( for n be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> tVar8).FUNCT-1K1 n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)) implies ( ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 tVar8 .RECDEF-1K1 tVar9))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb2 =XBOOLE-0R4 n & Lamb3 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) implies m <=XXREAL-0R1 k)"
      let ?R = "\<lambda>Lamb1. Pp1(sf0 .FUNCT-1K1 Lamb1)"
      have " ex m1 be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m1)"
        using A1 sorry
      then have A2: " ex m be NatNAT-1M1 st ?R(m)"
         sorry
      obtain M where
        [ty]:"M be NatNAT-1M1" and 
        A3: "?R(M) & ( for n be NatNAT-1M1 holds ?R(n) implies M <=XXREAL-0R1 n)"
        using nat_1_sch_5 A2 sorry
      obtain M9 where 
        [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
        using ordinal1_def_12 sorry
      have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        obtain m where
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A5: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"and A6: "Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
          using A1 sorry
        show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
        proof(rule bexI[of _ "m"])
          show "n <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)"
            using A5 A6 nat_1_th_13 sorry
        qed "sorry"
      qed "sorry"
      have A7: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & tVar5 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) implies m <=XXREAL-0R1 k))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
          let ?R = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & Pp1(sf0 .FUNCT-1K1 Lamb1)"
          have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?R(m)"
            using A4 sorry
          then have A8: " ex m be NatNAT-1M1 st ?R(m)"
             sorry
          obtain l where
            [ty]:"l be NatNAT-1M1" and 
            A9: "?R(l) & ( for k be NatNAT-1M1 holds ?R(k) implies l <=XXREAL-0R1 k)"
            using nat_1_sch_5 A8 sorry
          show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & tVar5 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) implies m <=XXREAL-0R1 k))"
          proof(rule bexI[of _ "l"])
            have "l inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m)) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k) implies m <=XXREAL-0R1 k))"
              using A9 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain F where
        [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
        A10: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?P(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
        using recdef_1_sch_2 A7 sorry
      have A11: "rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> F c=TARSKIR1 REALNUMBERSK2"
        using numbers_th_19 sorry
      have A12: "rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> F c=TARSKIR1 NATNUMBERSK1"
         sorry
      have A13: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      then have 
        [ty]:"F be Real-SequenceSEQ-1M1"
        using A11 relset_1_th_4 sorry
      have A14: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> F"
          using A13 funct_1_def_3 sorry
        thus "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A12 sorry
      qed "sorry"
      have " for n be NatNAT-1M1 holds F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A15: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A16: "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A14 sorry
        have "F .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A14 A15 sorry
        thus "F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A10 A16 sorry
      qed "sorry"
      then have 
        [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
        using seqm_3_def_6 sorry
      have A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
      proof-
        have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st Pp1(sf0 .FUNCT-1K1 n) & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
        proof(rule impI)
          let ?R = "\<lambda>Lamb1. Pp1(sf0 .FUNCT-1K1 Lamb1) & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
          assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?R(n)"
          then have A18: " ex n be NatNAT-1M1 st ?R(n)"
             sorry
          obtain M1 where
            [ty]:"M1 be NatNAT-1M1" and 
            A19: "?R(M1) & ( for n be NatNAT-1M1 holds ?R(n) implies M1 <=XXREAL-0R1 n)"
            using nat_1_sch_5 A18 sorry
          let ?H = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & Pp1(sf0 .FUNCT-1K1 Lamb1)) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
          have A20: " ex n be NatNAT-1M1 st ?H(n)"
          proof-
            have " ex tVar6 be NatNAT-1M1 st tVar6 <XXREAL-0R3 M1 & (Pp1(sf0 .FUNCT-1K1 tVar6) & ( ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 tVar6))"
            proof-
              show " ex tVar6 be NatNAT-1M1 st tVar6 <XXREAL-0R3 M1 & (Pp1(sf0 .FUNCT-1K1 tVar6) & ( ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 tVar6))"
              proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                have A21: "M <>HIDDENR2 M1"
                  using A10 A19 sorry
                have "M <=XXREAL-0R1 M1"
                  using A3 A19 sorry
                thus "M <XXREAL-0R3 M1"
                  using A21 xxreal_0_th_1 sorry
                show "Pp1(sf0 .FUNCT-1K1 M)"
                  using A3 sorry
                show " ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar7 =COMPLEX1R1 M"
                proof(rule bexI[of _ "0NUMBERSK6"])
                  show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                    using A10 sorry
                qed "sorry"
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          have A22: " for n be NatNAT-1M1 holds ?H(n) implies n <=XXREAL-0R1 M1"
             sorry
          obtain X where
            [ty]:"X be NatNAT-1M1" and 
            A23: "?H(X) & ( for n be NatNAT-1M1 holds ?H(n) implies n <=XXREAL-0R1 X)"
            using nat_1_sch_6 A22 A20 sorry
          have A24: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds X <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies  not Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
          proof-
            have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (X <XXREAL-0R3 k & k <XXREAL-0R3 M1) & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)) implies  False "
            proof(rule impI)
              assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (X <XXREAL-0R3 k & k <XXREAL-0R3 M1) & Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
              then obtain k where
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A25: "X <XXREAL-0R3 k"and A26: "k <XXREAL-0R3 M1"and A27: "Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k)"
                 sorry
              have " False "
              proof-
                show " False "
                proof-
                  have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                     sorry
                  have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                  proof(rule impI)
                    assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                    thus " False "
                      using A23 A25 A26 A27 sorry
                  qed
                  have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                  proof(rule impI)
                    assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                    thus " False "
                      using A19 A26 A27 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " False "
                 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          obtain m where
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
            A28: "F .RECDEF-1K1 m =COMPLEX1R1 X"
            using A23 sorry
          have "M1 inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have A29: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
            using A10 A19 A23 A28 sorry
          have A30: "Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)))"
            using A10 A28 sorry
          have A31: "X <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
            using A10 A28 sorry
          have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
          proof(rule impI)
            assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
            then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
              using A29 xxreal_0_th_1 sorry
            thus " False "
              using A24 A31 A30 sorry
          qed
          thus " False "
            using A19 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      show " ex tVar8 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1 st ( for n be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> tVar8).FUNCT-1K1 n)) & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)) implies ( ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 tVar8 .RECDEF-1K1 tVar9))"
      proof(rule bexI[of _ "F"],rule conjMI,rule ballI,rule impI)
        let ?q = "sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F"
        let ?S = "\<lambda>Lamb1. Pp1(?q .FUNCT-1K1 Lamb1)"
        have A32: " for k be NatNAT-1M1 holds ?S(k) implies ?S(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k) implies Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume "Pp1(?q .FUNCT-1K1 k)"
            have "?P(k,F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
              using A10 sorry
            then have "Pp1(sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)))"
               sorry
            thus "Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
              using funct_2_th_15 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A33: "?S(0NUMBERSK6)"
          using A3 A10 funct_2_th_15 sorry
        show " for n be NatNAT-1M1 holds Pp1((sf0 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 n)"
          using nat_1_sch_2 A33 A32 sorry
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        assume " for r be RealXREAL-0M1 holds r =COMPLEX1R1 sf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies Pp1(r)"
        then obtain m where
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A34: "F .RECDEF-1K1 m =COMPLEX1R1 n"
          using A17 sorry
        show " ex tVar9 be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 F .RECDEF-1K1 tVar9"
        proof(rule bexI[of _ "m"])
          show "n =COMPLEX1R1 F .RECDEF-1K1 m"
            using A34 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem fdiff_2_th_10:
" for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f .FUNCT-1K1 x0 <>HIDDENR2 r & f is-differentiable-inFDIFF-1R1 x0 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for g be RealXREAL-0M1 holds g inHIDDENR3 N implies f .FUNCT-1K1 g <>HIDDENR2 r))"
  using fcont_3_th_7 fdiff_1_th_24 sorry

mlemma fdiff_2_lm_1:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies f is-differentiable-inFDIFF-1R1 x0 & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies f is-differentiable-inFDIFF-1R1 x0 & ( for h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c1 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c1 =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1))))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?G = "\<lambda>Lamb1. InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 REALNUMBERSK2"
    assume Given: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A1: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    assume A2: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
    then have A3: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & {TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
       sorry
    obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
      using rcomp_1_def_6 sorry
    obtain h c where
      [ty]:"h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1" "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and 
      A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"and A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A8: "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 fdiff_2_th_8 sorry
    let ?l = "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
    let ?F = "\<lambda>Lamb1. InSUBSET-1K10(?l *XCMPLX-0K3 Lamb1,REALNUMBERSK2)"
    obtain L where
      [ty]:"L be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A9: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L iff ?P(g)"and A10: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L implies L .FUNCT-1K1 g =COMPLEX1R1 ?F(g)"
      using seq_1_sch_3 sorry
    have " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L iff ?P(g)"
      using A9 sorry
    then have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L =XBOOLE-0R4 REALNUMBERSK2"
      using fdiff_1_th_1 sorry
    have A12: " for g be RealXREAL-0M1 holds L .FUNCT-1K1 g =COMPLEX1R1 ?l *XCMPLX-0K3 g"
    proof-
      have " for g be RealXREAL-0M1 holds L .FUNCT-1K1 g =HIDDENR1 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 g"
      proof(rule ballI)
        fix g assume [ty]: "g be RealXREAL-0M1"
        obtain gg where 
          [ty]:"gg be ElementSUBSET-1M1-of REALNUMBERSK2" and ggDef:"gg = g"
          using xreal_0_def_1 sorry
        have A13: "gg inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L"
          using A11 sorry
        have "L .FUNCT-1K1 g =HIDDENR1 L .FUNCT-1K1 gg"
           sorry
        also have "... = InSUBSET-1K10((limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 gg,REALNUMBERSK2)"
          using A13 A10 sorry
        also have "... = (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 gg"
           sorry
        also have "... = (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 g"
           sorry
        finally show "L .FUNCT-1K1 g =HIDDENR1 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 g"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: "L be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using A11 partfun1_def_2 sorry
    let ?F1 = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 +XCMPLX-0K2 x0,REALNUMBERSK2)"
    obtain T where
      [ty]:"T be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A15: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T iff ?P(g)"and A16: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T implies T .FUNCT-1K1 g =COMPLEX1R1 ?F1(g)"
      using seq_1_sch_3 sorry
    have " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T iff ?P(g)"
      using A15 sorry
    then have A17: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T =XBOOLE-0R4 REALNUMBERSK2"
      using fdiff_1_th_1 sorry
    let ?F2 = "\<lambda>Lamb1. InSUBSET-1K10((f *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T).FUNCT-1K1 Lamb1 -XCMPLX-0K6 f .FUNCT-1K1 x0,REALNUMBERSK2)"
    obtain T1 where
      [ty]:"T1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A18: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T1 iff ?P(g)"and A19: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T1 implies T1 .FUNCT-1K1 g =COMPLEX1R1 ?F2(g)"
      using seq_1_sch_3 sorry
    let ?F3 = "\<lambda>Lamb1. InSUBSET-1K10((T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 Lamb1,REALNUMBERSK2)"
    have " for g be RealXREAL-0M1 holds g inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T1 iff ?P(g)"
      using A18 sorry
    then have A20: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> T1 =XBOOLE-0R4 REALNUMBERSK2"
      using fdiff_1_th_1 sorry
    then have A21: "T1 be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      using partfun1_def_2 sorry
    have 
      [ty]:"L be LinearFuncFDIFF-1M2"
      using A14 A12 fdiff_1_def_3 sorry
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
    obtain R where
      [ty]:"R be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A22: "R be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"and A23: " for g be ElementSUBSET-1M1-of REALNUMBERSK2 holds g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R implies (?P(g) implies R .FUNCT-1K1 g =COMPLEX1R1 ?F3(g)) & ( not ?P(g) implies R .FUNCT-1K1 g =COMPLEX1R1 ?G(g))"
      using scheme1_sch_8 sorry
    have A24: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> R =XBOOLE-0R4 REALNUMBERSK2"
      using A22 partfun1_def_2 sorry
    have A25: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {TARSKIK1 x0}"
        using A6 valued_0_th_28 sorry
      thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
        using tarski_def_1 sorry
    qed "sorry"
    have " for h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1 be convergentSEQ-2V5 & limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule conjMI)
      fix h1 assume [ty]: "h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      have A26: "limSEQ-2K1 h1 =COMPLEX1R1 0NUMBERSK6"
         sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A27: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies  |.COMPLEX1K10 h1 .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
        using A4 A26 seq_2_def_7 sorry
      let ?h2 = "h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have A28: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have " |.COMPLEX1K10 h1 .FUNCT-1K1 (n +XCMPLX-0K2 k) -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
          using A27 nat_1_th_12 sorry
        then have "h1 .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6 -XCMPLX-0K6 r,0NUMBERSK6 +XCMPLX-0K2 r .["
          using rcomp_1_th_1 sorry
        thus "(h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
          using nat_1_def_3 sorry
      qed "sorry"
      have A29: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof-
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A30: "x =HIDDENR1 (?h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using funct_2_th_113 sorry
            have "?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
              using A28 sorry
            then have "?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {g where g be RealXREAL-0M1 : -XCMPLX-0K4 r <XXREAL-0R3 g & g <XXREAL-0R3 r }"
              using rcomp_1_def_2 sorry
            then have A31: " ex g be RealXREAL-0M1 st (g =COMPLEX1R1 ?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & -XCMPLX-0K4 r <XXREAL-0R3 g) & g <XXREAL-0R3 r"
               sorry
            then have A32: "?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
              using xreal_1_th_6 sorry
            have "x0 +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 ?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0"
              using A31 xreal_1_th_6 sorry
            then have A33: "?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0 inTARSKIR2 {g where g be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g & g <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
              using A32 sorry
            have "x =HIDDENR1 ?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A30 seq_1_th_7 sorry
            also have "... = ?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0"
              using A25 sorry
            finally have "x =HIDDENR1 ?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0"
               sorry
            then have "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
              using A33 rcomp_1_def_2 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A1 A5 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      let ?b = "?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
      let ?a = "?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
      have A34: "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using seqm_3_th_19 sorry
      also have "... = ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using seqm_3_th_18 sorry
      also have "... = ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
        using A22 valued_0_th_29 sorry
      finally have "(h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =HIDDENR1 ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
         sorry
      have A35: "?a -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?b =HIDDENR1 ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2)"
        using seq_1_th_21 sorry
      also have "... = ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
        using A14 A21 rfunct_2_th_13 sorry
      finally have "?a -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?b =HIDDENR1 ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2"
         sorry
      have A36: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A37: "?h2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
          using A28 sorry
        have "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A35 seq_1_th_8 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A14 A21 funct_2_th_115 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (InSUBSET-1K10((T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n),REALNUMBERSK2))"
           sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 R .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A23 A24 A37 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A22 funct_2_th_115 sorry
        also have "... = ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        finally show "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      obtain ll where 
        [ty]:"ll be ElementSUBSET-1M1-of REALNUMBERSK2" and llDef:"ll = ?l"
        using xreal_0_def_1 sorry
      have A38: " for n be NatNAT-1M1 holds ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-1K1 n =HIDDENR1 ll"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A39: "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A40: "?h2 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
          using seq_1_th_5 sorry
        have A41: "?h2 .FUNCT-1K1 n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> L"
          using A11 xreal_0_def_1 sorry
        have "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-1K1 n =HIDDENR1 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-1K1 n"
          using seq_1_th_8 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 L .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)"
          using A14 A39 funct_2_th_115 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (InSUBSET-1K10((limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n,REALNUMBERSK2))"
          using A10 A41 sorry
        also have "... = ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n *XCMPLX-0K3 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)*XCMPLX-0K3 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
           sorry
        also have "... = (((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n)*XCMPLX-0K3 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
          using valued_1_th_10 sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 (limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
          using A40 xcmplx_0_def_7 sorry
        also have "... = ll"
           sorry
        finally show "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-1K1 n =HIDDENR1 ll"
           sorry
      qed "sorry"
      then have A42: "?b be constantFUNCT-1V5"
        using valued_0_def_18 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A43: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
          using A25 sorry
        have "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 T1 .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A21 funct_2_th_115 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (InSUBSET-1K10((f *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T).FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x0,REALNUMBERSK2))"
          using A19 A20 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T).FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 x0)"
           sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 (T .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 f .FUNCT-1K1 x0)"
          using A17 funct_1_th_13 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 (InSUBSET-1K10((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0,REALNUMBERSK2)) -XCMPLX-0K6 f .FUNCT-1K1 x0)"
          using A17 A16 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0) -XCMPLX-0K6 f .FUNCT-1K1 x0)"
           sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
          using A43 seq_1_th_7 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f .FUNCT-1K1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A6 A8 funct_2_th_108 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A29 funct_2_th_108 sorry
        also have "... = (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using rfunct_2_th_1 sorry
        also have "... = ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        finally show "((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A44: "?a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
         sorry
      then have A45: "?a be convergentSEQ-2V5"
        using A2 A6 A29 sorry
      then have "?a -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?b be convergentSEQ-2V5"
        using A42 sorry
      then have A46: "?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2 be convergentSEQ-2V5"
        using A36 funct_2_th_63 sorry
      thus "h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1 be convergentSEQ-2V5"
        using A34 seq_4_th_21 sorry
      have A47: "?l =COMPLEX1R1 limSEQ-2K1 ?a"
        using A3 A6 A7 A8 A29 A44 fdiff_2_th_7 sorry
      have "limSEQ-2K1 ?b =HIDDENR1 ?b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using A42 seq_4_th_25 sorry
      also have "... = ?l"
        using A38 sorry
      finally have "limSEQ-2K1 ?b =HIDDENR1 ?l"
         sorry
      then have "limSEQ-2K1 (?a -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?b) =HIDDENR1 ?l -XCMPLX-0K6 ?l"
        using A45 A47 A42 seq_2_th_12 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 (?a -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?b) =HIDDENR1 0NUMBERSK6"
         sorry
      then have "limSEQ-2K1 (?h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2) =COMPLEX1R1 0NUMBERSK6"
        using A36 funct_2_th_63 sorry
      thus "limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> R /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h1) =COMPLEX1R1 0NUMBERSK6"
        using A46 A34 seq_4_th_22 sorry
    qed "sorry"
    then have 
      [ty]:"R be RestFuncFDIFF-1M1"
      using A22 fdiff_1_def_2 sorry
    have A48: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) & ( for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 N implies L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0))"
    proof-
      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) & ( for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 N implies L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0))"
      proof(rule bexI[of _ "N"],rule conjMI)
        show "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        show " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) & ( for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 N implies L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0)"
        proof(rule bexI[of _ "L"])
          show " ex R be RestFuncFDIFF-1M1 st L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) & ( for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 N implies L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0)"
          proof(rule bexI[of _ "R"],rule conjMI,rule ballI,rule impI)
            have "\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
              using numbers_th_19 sorry
            then have "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 InSUBSET-1K10((limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))*XCMPLX-0K3 \<one>\<^sub>M,REALNUMBERSK2)"
              using A10 A11 sorry
            also have "... = limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
               sorry
            finally show "L .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
               sorry
            fix g1 assume [ty]: "g1 be RealXREAL-0M1"
            assume "g1 inHIDDENR3 N"
            then have A49: "g1 -XCMPLX-0K6 x0 inTARSKIR2 ].RCOMP-1K2 -XCMPLX-0K4 r,r .["
              using A5 fcont_3_th_2 sorry
            obtain gg1 xx0 where 
              [ty]:"gg1 be ElementSUBSET-1M1-of REALNUMBERSK2" and gg1Def:"gg1 = g1" and
              [ty]:"xx0 be ElementSUBSET-1M1-of REALNUMBERSK2" and xx0Def:"xx0 = x0"
              using xreal_0_def_1 sorry
            have "L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 InSUBSET-1K10((T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 (g1 -XCMPLX-0K6 x0),REALNUMBERSK2)"
              using A23 A24 A49 sorry
            also have "... = L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 (T1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> L).FUNCT-1K1 (g1 -XCMPLX-0K6 x0)"
               sorry
            also have "... = L .FUNCT-1K1 (gg1 -REAL-1K5 xx0) +XCMPLX-0K2 (T1 .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) -XCMPLX-0K6 L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0))"
              using A14 A21 rfunct_1_th_56 sorry
            also have "... = L .FUNCT-1K1 (gg1 -REAL-1K5 xx0) +XCMPLX-0K2 (InSUBSET-1K10((f *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T).FUNCT-1K1 (g1 -XCMPLX-0K6 x0) -XCMPLX-0K6 f .FUNCT-1K1 x0,REALNUMBERSK2) -XCMPLX-0K6 L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0))"
              using A19 A20 sorry
            also have "... = (f *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> T).FUNCT-1K1 (gg1 -REAL-1K5 xx0) -XCMPLX-0K6 f .FUNCT-1K1 x0"
               sorry
            also have "... = f .FUNCT-1K1 (T .FUNCT-1K1 (gg1 -REAL-1K5 xx0)) -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using A17 funct_1_th_13 sorry
            also have "... = f .FUNCT-1K1 (InSUBSET-1K10((gg1 -REAL-1K5 xx0)+XCMPLX-0K2 x0,REALNUMBERSK2)) -XCMPLX-0K6 f .FUNCT-1K1 x0"
              using A17 A16 sorry
            also have "... = f .FUNCT-1K1 ((gg1 -REAL-1K5 xx0)+REAL-1K3 xx0) -XCMPLX-0K6 f .FUNCT-1K1 x0"
               sorry
            also have "... = f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0"
               sorry
            finally show "L .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g1 -XCMPLX-0K6 x0) =HIDDENR1 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 x0"
               sorry
          qed "sorry"
        qed "sorry"
      qed "sorry"
    qed
    show "f is-differentiable-inFDIFF-1R1 x0"
      using A48 sorry
    then have A50: "diffFDIFF-1K1(f,x0) =COMPLEX1R1 ?l"
      using A48 fdiff_1_def_5 sorry
    fix h1 assume [ty]: "h1 be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix c1 assume [ty]: "c1 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
    assume A51: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c1 =XBOOLE-0R4 {TARSKIK1 x0}"
      and A52: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "c1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
      using A6 A51 fdiff_2_th_5 sorry
    thus "diffFDIFF-1K1(f,x0) =COMPLEX1R1 limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1))"
      using A3 A6 A7 A8 A50 A52 fdiff_2_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_11:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 iff ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-differentiable-inFDIFF-1R1 x0 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5)) & (( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5) implies f is-differentiable-inFDIFF-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-differentiable-inFDIFF-1R1 x0 implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5)"
    proof(rule impI,rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A1: "f is-differentiable-inFDIFF-1R1 x0"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A2: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for g be RealXREAL-0M1 holds g inHIDDENR3 N implies f .FUNCT-1K1 g -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (g -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (g -XCMPLX-0K6 x0)"
         sorry
      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A2 sorry
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
        and A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A5: "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
         sorry
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A6: "0NUMBERSK6 <XXREAL-0R3 r"and A7: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A8: " for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies  |.COMPLEX1K10 h .FUNCT-1K1 n -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
        using A5 A6 seq_2_def_7 sorry
      let ?h1 = "h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
      proof-
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies x inHIDDENR3 N"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
            then obtain n where
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A9: "x =HIDDENR1 (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using funct_2_th_113 sorry
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_28 sorry
            then have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
              using A3 tarski_def_1 sorry
            then have A10: "x =HIDDENR1 ?h1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 x0"
              using A9 seq_1_th_7 sorry
            also have "... = h .FUNCT-1K1 (n +XCMPLX-0K2 k) +XCMPLX-0K2 x0"
              using nat_1_def_3 sorry
            finally have "x =HIDDENR1 h .FUNCT-1K1 (n +XCMPLX-0K2 k) +XCMPLX-0K2 x0"
               sorry
            have " |.COMPLEX1K10 h .FUNCT-1K1 (n +XCMPLX-0K2 k) -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
              using A8 nat_1_th_12 sorry
            then have "h .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 ].RCOMP-1K2 0NUMBERSK6 -XCMPLX-0K6 r,0NUMBERSK6 +XCMPLX-0K2 r .["
              using rcomp_1_th_1 sorry
            then have "h .FUNCT-1K1 (n +XCMPLX-0K2 k) inTARSKIR2 {g where g be RealXREAL-0M1 : -XCMPLX-0K4 r <XXREAL-0R3 g & g <XXREAL-0R3 r }"
              using rcomp_1_def_2 sorry
            then have A11: " ex g be RealXREAL-0M1 st (g =COMPLEX1R1 h .FUNCT-1K1 (n +XCMPLX-0K2 k) & -XCMPLX-0K4 r <XXREAL-0R3 g) & g <XXREAL-0R3 r"
               sorry
            then have A12: "h .FUNCT-1K1 (n +XCMPLX-0K2 k) +XCMPLX-0K2 x0 <XXREAL-0R3 x0 +XCMPLX-0K2 r"
              using xreal_1_th_6 sorry
            have "x0 +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 h .FUNCT-1K1 (n +XCMPLX-0K2 k) +XCMPLX-0K2 x0"
              using A11 xreal_1_th_6 sorry
            then have "h .FUNCT-1K1 (n +XCMPLX-0K2 k) +XCMPLX-0K2 x0 inTARSKIR2 {g where g be RealXREAL-0M1 : x0 -XCMPLX-0K6 r <XXREAL-0R3 g & g <XXREAL-0R3 x0 +XCMPLX-0K2 r }"
              using A12 sorry
            thus "x inHIDDENR3 N"
              using A7 A10 rcomp_1_def_2 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 N"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have A13: "?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A1 A2 A3 fdiff_1_th_12 sorry
      have A14: "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 x0} implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {TARSKIK1 x0}"
          then have A15: "x =HIDDENR1 x0"
            using tarski_def_1 sorry
          have "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A2 A15 sorry
        qed "sorry"
        thus "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using tarski_def_3 sorry
      qed
      have "c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
        using valued_0_th_26 sorry
      then have "?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))"
        using seqm_3_th_15 sorry
      also have "... = ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k))"
        using A4 valued_0_th_27 sorry
      also have "... = ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using A3 A14 valued_0_th_27 sorry
      also have "... = ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using seqm_3_th_17 sorry
      also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
        using seqm_3_th_18 sorry
      also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
        using seqm_3_th_19 sorry
      finally have "?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
         sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A13 seq_4_th_21 sorry
    qed "sorry"
    assume A16: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A17: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
    show "f is-differentiable-inFDIFF-1R1 x0"
      using A16 A17 fdiff_2_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_12:
" for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g iff ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for g be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g)) & (( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g) implies f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g)"
    proof-
      have "f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 g implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds  not ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g)))"
      proof(rule impMI ,rule impI,rule conjMI)
        assume A1: "f is-differentiable-inFDIFF-1R1 x0"
          and A2: "diffFDIFF-1K1(f,x0) =COMPLEX1R1 g"
        show " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        have A3: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
          using A1 fdiff_2_th_11 sorry
        have " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 sorry
        thus " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds  not ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g))"
          using A2 A3 fdiff_2_lm_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A4: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A5: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g"
    have A6: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
      using A5 sorry
    thus "f is-differentiable-inFDIFF-1R1 x0"
      using A4 fdiff_2_lm_1 sorry
    obtain h c where
      [ty]:"h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1" "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and 
      A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"and A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and "{TARSKIK1 x0} c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A4 fdiff_2_th_8 sorry
    have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 g"
      using A5 A7 A8 sorry
    thus "diffFDIFF-1K1(f,x0) =COMPLEX1R1 g"
      using A4 A6 A7 A8 fdiff_2_lm_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_2_lm_2:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) & f1 is-differentiable-inFDIFF-1R1 x0) & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)) implies (f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex N be NeighbourhoodRCOMP-1M1-of x0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A1: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
       sorry
    assume A2: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A3: "f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0"
    have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
        and A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      have A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 fdiff_2_th_9 sorry
      let ?a = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
      have A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          using valued_0_th_28 sorry
        thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
          using A4 tarski_def_1 sorry
      qed "sorry"
      have A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          then have A9: " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
            using funct_2_th_113 sorry
          have "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
            using A1 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
            using A7 A9 sorry
        qed "sorry"
        thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
          using tarski_def_3 sorry
      qed
      let ?d = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
      have A10: "limSEQ-2K1 h =COMPLEX1R1 0NUMBERSK6"
         sorry
      have "limSEQ-2K1 c =COMPLEX1R1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        using seq_4_th_25 sorry
      then have "limSEQ-2K1 c =COMPLEX1R1 x0"
        using A7 sorry
      then have A11: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 x0"
        using A10 seq_2_th_6 sorry
      also have "... = x0"
         sorry
      finally have "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 x0"
         sorry
      have A12: "f1 is-continuous-inFCONT-1R1 x0"
        using A2 fdiff_1_th_24 sorry
      then have A13: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A6 A11 fcont_1_def_1 sorry
      have A14: "f1 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using A6 A11 A12 fcont_1_def_1 sorry
      have A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 fdiff_2_th_9 sorry
      have A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          then have A17: "x =HIDDENR1 x0"
            using A4 tarski_def_1 sorry
          have "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A1 A17 funct_1_th_11 sorry
        qed "sorry"
        thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using tarski_def_3 sorry
      qed
      have A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a =XBOOLE-0R4 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
      proof-
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =XBOOLE-0R4 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
        proof-
          have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 {TARSKIK1 f1 .FUNCT-1K1 x0 } & {TARSKIK1 f1 .FUNCT-1K1 x0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
          proof(rule conjMI)
            show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies x inHIDDENR3 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A19: "?a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x"
                  using funct_2_th_113 sorry
                have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
                  using A7 sorry
                then have "x =HIDDENR1 f1 .FUNCT-1K1 x0"
                  using A16 A19 funct_2_th_108 sorry
                thus "x inHIDDENR3 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
                  using tarski_def_1 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
                using tarski_def_3 sorry
            qed
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 f1 .FUNCT-1K1 x0 } implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              have A20: "?a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a"
                using valued_0_th_28 sorry
              assume "x inHIDDENR3 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
              then have A21: "x =HIDDENR1 f1 .FUNCT-1K1 x0"
                using tarski_def_1 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 x0"
                using A7 sorry
              thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                using A16 A21 A20 funct_2_th_108 sorry
            qed "sorry"
            thus "{TARSKIK1 f1 .FUNCT-1K1 x0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using tarski_def_3 sorry
          qed
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =XBOOLE-0R4 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
            using xboole_0_def_10 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A22: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      proof-
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a"
            then have A23: "x =HIDDENR1 f1 .FUNCT-1K1 x0"
              using A18 tarski_def_1 sorry
            have "x0 inHIDDENR3 N"
              using rcomp_1_th_16 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A1 A23 funct_1_th_11 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A24: " for n be NatNAT-1M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 n =COMPLEX1R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "?a .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a"
          using valued_0_th_28 sorry
        then have A25: "?a .FUNCT-1K1 n =COMPLEX1R1 f1 .FUNCT-1K1 x0"
          using A18 tarski_def_1 sorry
        have "?a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a"
          using valued_0_th_28 sorry
        thus "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 n =COMPLEX1R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A18 A25 tarski_def_1 sorry
      qed "sorry"
      then have "?a be constantFUNCT-1V5"
        using valued_0_th_25 sorry
      then have A26: "?d be convergentSEQ-2V5"
        using A13 sorry
      obtain a where 
        [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
        using A24 valued_0_th_25 sorry
      have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
        using valued_0_th_28 sorry
      then have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 f1 .FUNCT-1K1 x0"
        using A18 tarski_def_1 sorry
      then have "limSEQ-2K1 a =COMPLEX1R1 f1 .FUNCT-1K1 x0"
        using seq_4_th_25 sorry
      then have A27: "limSEQ-2K1 ?d =HIDDENR1 f1 .FUNCT-1K1 x0 -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
        using A13 A14 seq_2_th_12 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "limSEQ-2K1 ?d =HIDDENR1 0NUMBERSK6"
         sorry
      have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
      proof-
        show "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
        proof-
          have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0)"
             sorry
          have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
          proof(rule impI,rule conjMI)
            assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0"
            then obtain k where
              [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A28: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0"
               sorry
            have "( ex n be NatNAT-1M1 st ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st (?d ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A29: "(?d ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                 sorry
              have "0NUMBERSK6 =HIDDENR1 ?d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                using A29 nat_1_def_3 sorry
              also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k)"
                using rfunct_2_th_1 sorry
              also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) -XCMPLX-0K6 f1 .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k))"
                using A16 funct_2_th_108 sorry
              also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
                using A7 sorry
              finally have "0NUMBERSK6 =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 k) -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
                 sorry
              thus " False "
                using A28 nat_1_th_12 sorry
            qed
            then have A30: "?d ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
            let ?c1 = "c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
            let ?h1 = "h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
            let ?a1 = "a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
            let ?s = "?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1)"
            have A31: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)+REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              finally show "((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            have "limSEQ-2K1 (?d ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 0NUMBERSK6"
              using A26 A27 seq_4_th_20 sorry
            then obtain d1 where 
              [ty]:"d1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and d1Def:"d1 = ?d ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A26 A30 fdiff_1_def_1 sorry
            let ?t = "d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)"
            have "d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?d +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using seqm_3_th_15 sorry
            then have A32: "d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using A31 funct_2_th_63 sorry
            have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
              using valued_0_th_21 sorry
            then have A33: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
              using A15 A32 sorry
            have A34: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a1 =XBOOLE-0R4 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
              using A18 valued_0_th_26 sorry
            then have A35: "limSEQ-2K1 ?t =COMPLEX1R1 diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0)"
              using A3 A33 fdiff_2_th_12 sorry
            have "diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0) =COMPLEX1R1 diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0)"
               sorry
            then have A36: "?t be convergentSEQ-2V5"
              using A3 A34 A33 fdiff_2_th_12 sorry
            have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using valued_0_th_21 sorry
            then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A6 sorry
            then have A37: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using seqm_3_th_15 sorry
            have A38: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1 =XBOOLE-0R4 {TARSKIK1 x0}"
              using A4 valued_0_th_26 sorry
            have "diffFDIFF-1K1(f1,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
               sorry
            then have A39: "?s be convergentSEQ-2V5"
              using A2 A38 A37 fdiff_2_th_12 sorry
            have A40: "?t (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s =HIDDENR1 (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
              using seqm_3_th_15 sorry
            also have "... = (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
              using A6 valued_0_th_27 sorry
            also have "... = (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
              using A16 valued_0_th_27 sorry
            also have "... = ((f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
              using seqm_3_th_17 sorry
            also have "... = (((f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using seq_1_th_14 sorry
            also have "... = (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using seq_1_th_37 sorry
            also have "... = (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using A15 A32 valued_0_th_27 sorry
            also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using A5 valued_0_th_31 sorry
            also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using A22 valued_0_th_27 sorry
            also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using A8 valued_0_th_31 sorry
            also have "... = (((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
              using seqm_3_th_17 sorry
            also have "... = (((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k)"
              using seqm_3_th_18 sorry
            also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
              using seqm_3_th_19 sorry
            finally have "?t (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k"
               sorry
            then have A41: "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k be convergentSEQ-2V5"
              using A39 A36 sorry
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using seq_4_th_21 sorry
            have "limSEQ-2K1 ?s =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
              using A2 A38 A37 fdiff_2_th_12 sorry
            then have "limSEQ-2K1 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> k) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
              using A40 A39 A36 A35 seq_2_th_15 sorry
            thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
              using A41 seq_4_th_22 sorry
          qed
          have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
          proof(rule impI)
            assume A42: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0"
            let ?P = "\<lambda>Lamb1. Lamb1 =HIDDENR1 f1 .FUNCT-1K1 x0"
            have A43: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & ?P(f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A42 sorry
            obtain I1 where
              [ty]:"I1 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
              A44: " for n be NatNAT-1M1 holds ?P((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1).FUNCT-1K1 n)"and " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies ?P(r)) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 I1 .RECDEF-1K1 m)"
              using fdiff_2_sch_1 A43 sorry
            have "h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h"
              using valued_0_def_17 sorry
            then obtain h1 where 
              [ty]:"h1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h1Def:"h1 = h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1"
              using fdiff_2_th_6 sorry
            let ?c1 = "c *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1"
            have A45: "?c1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c"
              using valued_0_def_17 sorry
            then have A46: "?c1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
              using valued_0_th_26 sorry
            have A47: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1 =XBOOLE-0R4 {TARSKIK1 x0}"
              using A4 A45 valued_0_th_26 sorry
            obtain c1 where 
              [ty]:"c1 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and c1Def:"c1 = ?c1"
               sorry
            have A48: " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 g)"
            proof(rule ballI,rule impI)
              fix g assume [ty]: "g be RealXREAL-0M1"
              assume A49: "0NUMBERSK6 <XXREAL-0R3 g"
              obtain n where 
                [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
                 sorry
              show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 g"
              proof(rule bexI[of _ "n"],rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "n <=XXREAL-0R1 m"
                have A50: "m inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have " |.COMPLEX1K10 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1).FUNCT-1K1 m .|"
                  using seq_1_th_8 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) .FUNCT-1K1 m -XCMPLX-0K6 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1 .FUNCT-1K1 m) .|"
                  using rfunct_2_th_1 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) .FUNCT-1K1 m -XCMPLX-0K6 f1 .FUNCT-1K1 (c .FUNCT-1K1 m)) .|"
                  using A16 A46 A50 funct_2_th_108 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) .FUNCT-1K1 m -XCMPLX-0K6 f1 .FUNCT-1K1 x0) .|"
                  using A7 A50 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1) .FUNCT-1K1 m -XCMPLX-0K6 f1 .FUNCT-1K1 x0) .|"
                  using rfunct_2_th_2 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1).FUNCT-1K1 m -XCMPLX-0K6 f1 .FUNCT-1K1 x0) .|"
                  using A6 funct_2_th_110 sorry
                also have "... =  |.COMPLEX1K10 h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f1 .FUNCT-1K1 x0 -XCMPLX-0K6 f1 .FUNCT-1K1 x0) .|"
                  using A44 sorry
                also have "... = 0NUMBERSK6"
                  using absvalue_th_2 sorry
                finally have " |.COMPLEX1K10 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1 0NUMBERSK6"
                   sorry
                thus " |.COMPLEX1K10 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 g"
                  using A49 sorry
              qed "sorry"
            qed "sorry"
            have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
              using valued_0_def_17 sorry
            then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using valued_0_th_21 sorry
            then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using A6 sorry
            then have A51: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
              using rfunct_2_th_2 sorry
            then have A52: "limSEQ-2K1 (h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1)) =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
              using A2 A47 fdiff_2_th_12 sorry
            have "diffFDIFF-1K1(f1,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
               sorry
            then have "h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c1) be convergentSEQ-2V5"
              using A2 A47 A51 fdiff_2_th_12 sorry
            then have A53: "diffFDIFF-1K1(f1,x0) =COMPLEX1R1 0NUMBERSK6"
              using A52 A48 seq_2_def_7 sorry
            have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
            proof-
              show "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
              proof-
                have cases: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0) or ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0)"
                   sorry
                have case1: "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                proof(rule impI,rule conjMI)
                  assume " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0"
                  then obtain k where
                    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                    A54: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds k <=XXREAL-0R1 n implies f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f1 .FUNCT-1K1 x0"
                     sorry
                  have A55: " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g)"
                  proof(rule ballI,rule impI)
                    fix g assume [ty]: "g be RealXREAL-0M1"
                    assume A56: "0NUMBERSK6 <XXREAL-0R3 g"
                    obtain n where 
                      [ty]:"n be NatNAT-1M1" and nDef:"n = k"
                       sorry
                    show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                    proof(rule bexI[of _ "n"],rule ballI,rule impI)
                      fix m assume [ty]: "m be NatNAT-1M1"
                      have A57: "m inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      assume "n <=XXREAL-0R1 m"
                      then have A58: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m =COMPLEX1R1 f1 .FUNCT-1K1 x0"
                        using A54 A57 sorry
                      have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| =HIDDENR1  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 m .|"
                        using A53 seq_1_th_8 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m) .|"
                        using rfunct_2_th_1 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) .FUNCT-1K1 m -XCMPLX-0K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m) .|"
                        using A5 valued_0_th_31 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m) -XCMPLX-0K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m) .|"
                        using A15 funct_2_th_108 A57 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) -XCMPLX-0K6 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m) .|"
                        using A8 A58 valued_0_th_31 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m)) .|"
                        using A22 funct_2_th_108 A57 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 (c .FUNCT-1K1 m))) .|"
                        using A16 funct_2_th_108 A57 sorry
                      also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0)) .|"
                        using A7 A57 sorry
                      also have "... = 0NUMBERSK6"
                        using absvalue_th_2 sorry
                      finally have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| =HIDDENR1 0NUMBERSK6"
                         sorry
                      thus " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                        using A56 sorry
                    qed "sorry"
                  qed "sorry"
                  thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
                    using seq_2_def_6 sorry
                  thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                    using A55 seq_2_def_7 sorry
                qed
                have case2: "( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                proof(rule impI,rule conjMI)
                  assume A59: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 f1 .FUNCT-1K1 x0"
                  let ?P = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 f1 .FUNCT-1K1 x0"
                  have A60: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st k <=XXREAL-0R1 n & ?P(f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                    using A59 sorry
                  obtain I2 where
                    [ty]:"I2 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
                    A61: " for n be NatNAT-1M1 holds ?P((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n)"and A62: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for r be RealXREAL-0M1 holds r =COMPLEX1R1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies ?P(r)) implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n =COMPLEX1R1 I2 .RECDEF-1K1 m)"
                    using fdiff_2_sch_1 A60 sorry
                  have "( ex n be NatNAT-1M1 st ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
                  proof(rule impI)
                    assume Given: " ex n be NatNAT-1M1 st (?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                    then obtain n where
                      [ty]:"n be NatNAT-1M1" and 
                      A63: "(?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                       sorry
                    have A64: "n inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    then have "0NUMBERSK6 =HIDDENR1 ?d .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n)"
                      using A63 funct_2_th_15 sorry
                    also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n) -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n)"
                      using rfunct_2_th_1 sorry
                    also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n) -XCMPLX-0K6 f1 .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n))"
                      using A16 funct_2_th_108 sorry
                    also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (I2 .RECDEF-1K1 n) -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
                      using A7 sorry
                    also have "... = (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
                      using funct_2_th_15 A64 sorry
                    finally have "0NUMBERSK6 =HIDDENR1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 n -XCMPLX-0K6 f1 .FUNCT-1K1 x0"
                       sorry
                    thus " False "
                      using A61 sorry
                  qed
                  then have A65: "?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be non-zeroORDINAL1V9"
                    using seq_1_th_5 sorry
                  have "h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h"
                    using valued_0_def_17 sorry
                  then obtain h2 where 
                    [ty]:"h2 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and h2Def:"h2 = h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                    using fdiff_2_th_6 sorry
                  let ?a1 = "a *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                  let ?c2 = "c *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                  obtain c2 where 
                    [ty]:"c2 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and c2Def:"c2 = ?c2"
                     sorry
                  let ?s = "h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c2) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c2)"
                  have A66: "?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of ?d"
                    using valued_0_def_17 sorry
                  then have A67: "?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be convergentSEQ-2V5"
                    using A26 seq_4_th_16 sorry
                  have "limSEQ-2K1 (?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) =COMPLEX1R1 0NUMBERSK6"
                    using A26 A27 A66 seq_4_th_17 sorry
                  then obtain d1 where 
                    [ty]:"d1 be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1" and d1Def:"d1 = ?d *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                    using A67 A65 fdiff_1_def_1 sorry
                  let ?t = "d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)"
                  have "?a1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of a"
                    using valued_0_def_17 sorry
                  then have A68: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?a1 =XBOOLE-0R4 {TARSKIK1 f1 .FUNCT-1K1 x0 }"
                    using A18 valued_0_th_26 sorry
                  have A69: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  proof(rule ballI)
                    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                    have "((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                      using seq_1_th_7 sorry
                    also have "... = (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)+REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                      using rfunct_2_th_1 sorry
                    also have "... = f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                       sorry
                    finally show "((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                       sorry
                  qed "sorry"
                  have "d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?d +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                    using rfunct_2_th_2 sorry
                  then have A70: "d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1 =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                    using A69 funct_2_th_63 sorry
                  have A71: "?t (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s =HIDDENR1 (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
                    using rfunct_2_th_2 sorry
                  also have "... = (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
                    using A6 funct_2_th_110 sorry
                  also have "... = (d1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
                    using A16 funct_2_th_110 sorry
                  also have "... = ((f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)"
                    using rfunct_2_th_2 sorry
                  also have "... = (((f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> d1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using seq_1_th_14 sorry
                  also have "... = (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using seq_1_th_37 sorry
                  also have "... = (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using A15 A70 funct_2_th_110 sorry
                  also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?a1)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using A5 valued_0_th_31 sorry
                  also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using A22 funct_2_th_110 sorry
                  also have "... = ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using A8 valued_0_th_31 sorry
                  also have "... = (((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h2 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
                    using rfunct_2_th_2 sorry
                  also have "... = (((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2)"
                    using rfunct_2_th_5 sorry
                  also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                    using rfunct_2_th_2 sorry
                  finally have "?t (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2"
                     sorry
                  obtain a1 where 
                    [ty]:"a1 be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and a1Def:"a1 = ?a1"
                     sorry
                  have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_def_17 sorry
                  then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
                    using valued_0_th_21 sorry
                  then have A72: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (d1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
                    using A15 A70 sorry
                  have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
                    using valued_0_def_17 sorry
                  then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                    using valued_0_th_21 sorry
                  then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                    using A6 sorry
                  then have A73: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h2 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
                    using rfunct_2_th_2 sorry
                  have "c2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of c"
                    using valued_0_def_17 sorry
                  then have A74: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c2 =XBOOLE-0R4 {TARSKIK1 x0}"
                    using A4 valued_0_th_26 sorry
                  then have A75: "limSEQ-2K1 ?s =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
                    using A2 A73 fdiff_2_th_12 sorry
                  have "diffFDIFF-1K1(f1,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
                     sorry
                  then have A76: "?s be convergentSEQ-2V5"
                    using A2 A74 A73 fdiff_2_th_12 sorry
                  have "diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0) =COMPLEX1R1 diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0)"
                     sorry
                  then have A77: "?t be convergentSEQ-2V5"
                    using A3 A68 A72 fdiff_2_th_12 sorry
                  then have A78: "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2 be convergentSEQ-2V5"
                    using A71 A76 sorry
                  have "limSEQ-2K1 ?t =COMPLEX1R1 diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0)"
                    using A3 A68 A72 fdiff_2_th_12 sorry
                  then have A79: "limSEQ-2K1 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                    using A71 A76 A75 A77 seq_2_th_15 sorry
                  have A80: " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g)"
                  proof(rule ballI,rule impI)
                    let ?DF = "(diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                    fix g assume [ty]: "g be RealXREAL-0M1"
                    assume A81: "0NUMBERSK6 <XXREAL-0R3 g"
                    obtain k where
                      [ty]:"k be NatNAT-1M1" and 
                      A82: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-1K1 m -XCMPLX-0K6 ?DF .| <XXREAL-0R3 g"
                      using A78 A79 A81 seq_2_def_7 sorry
                    have A83: "k inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    obtain n where 
                      [ty]:"n be NatNAT-1M1" and nDef:"n = I2 .RECDEF-1K1 k"
                       sorry
                    show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                    proof(rule bexI[of _ "n"],rule ballI,rule impI)
                      fix m assume [ty]: "m be NatNAT-1M1"
                      assume A84: "n <=XXREAL-0R1 m"
                      have A85: "m inTARSKIR2 NATNUMBERSK1"
                        using ordinal1_def_12 sorry
                      have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                      proof-
                        show " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                        proof-
                          have cases: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m =COMPLEX1R1 f1 .FUNCT-1K1 x0 or f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m <>HIDDENR2 f1 .FUNCT-1K1 x0"
                             sorry
                          have case1: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m =COMPLEX1R1 f1 .FUNCT-1K1 x0 implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                          proof(rule impI)
                            assume A86: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m =COMPLEX1R1 f1 .FUNCT-1K1 x0"
                            have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 ?DF .| =HIDDENR1  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 m .|"
                              using A53 seq_1_th_8 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m) .|"
                              using rfunct_2_th_1 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m) .|"
                              using A8 valued_0_th_31 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-1K1 m)) .|"
                              using A22 funct_2_th_108 A85 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 (c .FUNCT-1K1 m))) .|"
                              using A16 funct_2_th_108 A85 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0)) .|"
                              using A7 A85 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) .FUNCT-1K1 m -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0)) .|"
                              using A5 valued_0_th_31 sorry
                            also have "... =  |.COMPLEX1K10 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 (f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) -XCMPLX-0K6 f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0)) .|"
                              using A15 A86 funct_2_th_108 A85 sorry
                            also have "... = 0NUMBERSK6"
                              using absvalue_th_2 sorry
                            finally have " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 ?DF .| =HIDDENR1 0NUMBERSK6"
                               sorry
                            thus " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                              using A81 sorry
                          qed
                          have case2: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m <>HIDDENR2 f1 .FUNCT-1K1 x0 implies  |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                          proof(rule impI)
                            assume "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m <>HIDDENR2 f1 .FUNCT-1K1 x0"
                            then have " for r1 be RealXREAL-0M1 holds f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-1K1 m =COMPLEX1R1 r1 implies r1 <>HIDDENR2 f1 .FUNCT-1K1 x0"
                               sorry
                            then obtain l where
                              [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                              A87: "m =COMPLEX1R1 I2 .RECDEF-1K1 l"
                              using A62 A85 sorry
                            have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> I2 =XBOOLE-0R4 NATNUMBERSK1"
                              using funct_2_def_1 sorry
                            then have "l >=XXREAL-0R2 k"
                              using A84 A87 valued_0_def_13 A83 sorry
                            then have " |.COMPLEX1K10 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> I2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l -XCMPLX-0K6 ?DF .| <XXREAL-0R3 g"
                              using A82 sorry
                            thus " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                              using A87 funct_2_th_15 sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus " |.COMPLEX1K10 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-1K1 m -XCMPLX-0K6 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0)) .| <XXREAL-0R3 g"
                         sorry
                    qed "sorry"
                  qed "sorry"
                  thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
                    using seq_2_def_6 sorry
                  thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
                    using A80 seq_2_def_7 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
         sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
      using A1 fdiff_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_13:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A2: "f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0"
    obtain N2 where
      [ty]:"N2 be NeighbourhoodRCOMP-1M1-of f1 .FUNCT-1K1 x0" and 
      A3: "N2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 sorry
    have "f1 is-continuous-inFCONT-1R1 x0"
      using A1 fdiff_1_th_24 sorry
    then obtain N3 where
      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of x0" and 
      A4: "f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N3 c=TARSKIR1 N2"
      using fcont_1_th_5 sorry
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A5: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A6: "N c=TARSKIR1 N1"and A7: "N c=TARSKIR1 N3"
      using rcomp_1_th_17 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 N implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A8: "x inHIDDENR3 N"
        then obtain x9 where 
          [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
           sorry
        have A9: "x inHIDDENR3 N1"
          using A6 A8 sorry
        then have "f1 .FUNCT-1K1 x9 inTARSKIR2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N3"
          using A5 A7 A8 funct_1_def_6 sorry
        then have "f1 .FUNCT-1K1 x9 inTARSKIR2 N2"
          using A4 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
          using A5 A3 A9 funct_1_th_11 sorry
      qed "sorry"
      thus "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using tarski_def_3 sorry
    qed
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0) =COMPLEX1R1 (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
      using A1 A2 fdiff_2_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_14:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f1 is-differentiable-inFDIFF-1R1 x0) & f2 is-differentiable-inFDIFF-1R1 x0 implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & (f1 is-differentiable-inFDIFF-1R1 x0 & f2 is-differentiable-inFDIFF-1R1 x0) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
      and A2: "f1 is-differentiable-inFDIFF-1R1 x0"
      and A3: "f2 is-differentiable-inFDIFF-1R1 x0"
    obtain N1 where
      [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
      A4: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A2 sorry
    obtain N3 where
      [ty]:"N3 be NeighbourhoodRCOMP-1M1-of x0" and 
      A5: "N3 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"and A6: " for g be RealXREAL-0M1 holds g inHIDDENR3 N3 implies f2 .FUNCT-1K1 g <>HIDDENR2 0NUMBERSK6"
      using A1 A3 fcont_3_th_7 fdiff_1_th_24 sorry
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A7: "N c=TARSKIR1 N1"and A8: "N c=TARSKIR1 N3"
      using rcomp_1_th_17 sorry
    have A9: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 N implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A10: "x inHIDDENR3 N"
        then obtain x9 where 
          [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
           sorry
        have "f2 .FUNCT-1K1 x9 <>HIDDENR2 0NUMBERSK6"
          using A6 A8 A10 sorry
        then have " not f2 .FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        then have A11: " not x9 inHIDDENR3 f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using funct_1_def_7 sorry
        have "x9 inHIDDENR3 N3"
          using A8 A10 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using A5 A11 xboole_0_def_5 sorry
      qed "sorry"
      thus "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    have A12: "f2 is-continuous-inFCONT-1R1 x0"
      using A3 fdiff_1_th_24 sorry
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A4 A7 sorry
    then have A13: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A9 xboole_1_th_19 sorry
    have A14: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
    proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using rfunct_1_def_2 sorry
      then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_36 sorry
      fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
      fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
      assume A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
        and A17: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
        using A17 rfunct_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using xboole_1_th_17 sorry
      then have A19: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A18 sorry
      then have A20: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_def_2 sorry
      then have A21: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be non-zeroORDINAL1V9"
        using rfunct_2_th_11 sorry
      have A22: "limSEQ-2K1 c =COMPLEX1R1 x0"
        using A16 fdiff_2_th_4 sorry
      let ?u2 = "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
      let ?u1 = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
      let ?v2 = "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
      let ?h2 = "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2)"
      let ?v1 = "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
      let ?h1 = "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1)"
      have A23: "f1 is-continuous-inFCONT-1R1 x0"
        using A2 fdiff_1_th_24 sorry
      have A24: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
          then have A25: "x =HIDDENR1 x0"
            using A16 tarski_def_1 sorry
          have "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
            using A13 A25 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using rfunct_1_def_2 sorry
        qed "sorry"
        thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using tarski_def_3 sorry
      qed
      have A26: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using xboole_1_th_17 sorry
      then have A27: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be non-zeroORDINAL1V9"
        using A24 rfunct_2_th_11 xboole_1_th_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A28: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A18 sorry
      then have A29: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A20 xboole_1_th_19 sorry
      have A30: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using rfunct_1_th_31 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using rfunct_1_th_31 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using A29 rfunct_2_th_8 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using A20 rfunct_2_th_12 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using A24 rfunct_2_th_8 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c /\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using A24 A26 rfunct_2_th_12 xboole_1_th_1 sorry
      also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
        using A21 A27 seq_1_th_50 sorry
      also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
        using seq_1_th_41 sorry
      finally have "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =HIDDENR1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
         sorry
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A24 A26 sorry
      then have A31: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A15 sorry
      then have A32: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
        using A12 A22 fcont_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A33: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A24 sorry
      then have A34: "limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =COMPLEX1R1 f1 .FUNCT-1K1 x0"
        using A22 A23 fcont_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_36 sorry
      then have A35: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A19 sorry
      have "diffFDIFF-1K1(f2,x0) =COMPLEX1R1 diffFDIFF-1K1(f2,x0)"
         sorry
      then have A36: "?h2 be convergentSEQ-2V5"
        using A3 A16 A35 fdiff_2_th_12 sorry
      have A37: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c be convergentSEQ-2V5"
        using A33 A22 A23 fcont_1_def_1 sorry
      then have A38: "?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2 be convergentSEQ-2V5"
        using A36 sorry
      have "limSEQ-2K1 ?h2 =COMPLEX1R1 diffFDIFF-1K1(f2,x0)"
        using A3 A16 A35 fdiff_2_th_12 sorry
      then have A39: "limSEQ-2K1 (?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?h2) =COMPLEX1R1 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0"
        using A36 A37 A34 seq_2_th_15 sorry
      let ?w1 = "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c"
      have A40: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 x0"
        using A16 fdiff_2_th_4 sorry
      have A41: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A12 A35 A40 fcont_1_def_1 sorry
      then have A42: "?w1 be convergentSEQ-2V5"
        using A32 sorry
      have "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be non-zeroORDINAL1V9"
        using A20 rfunct_2_th_11 sorry
      then have A43: "?w1 be non-zeroORDINAL1V9"
        using A27 seq_1_th_35 sorry
      have A44: "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c =COMPLEX1R1 f2 .FUNCT-1K1 x0"
        using A12 A31 A22 fcont_1_def_1 sorry
      have "diffFDIFF-1K1(f1,x0) =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
         sorry
      then have A45: "?h1 be convergentSEQ-2V5"
        using A2 A16 A28 fdiff_2_th_12 sorry
      then have A46: "?h1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2 be convergentSEQ-2V5"
        using A32 sorry
      have "limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 f2 .FUNCT-1K1 x0"
        using A12 A35 A40 fcont_1_def_1 sorry
      then have A47: "limSEQ-2K1 ?w1 =COMPLEX1R1 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A41 A32 A44 seq_2_th_15 sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using rfunct_2_th_1 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using seq_1_th_8 sorry
        also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using seq_1_th_8 sorry
        also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))*REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
           sorry
        also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
          using rfunct_2_th_1 sorry
        also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)*REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using rfunct_2_th_1 sorry
        also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using seq_1_th_8 sorry
        also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using seq_1_th_8 sorry
        also have "... = ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using rfunct_2_th_1 sorry
        finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A48: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?v2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1))(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2))"
         sorry
      then have A49: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?v2) be convergentSEQ-2V5"
        using A46 A38 sorry
      thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
        using A1 A30 A42 A47 A43 seq_2_th_23 sorry
      have "limSEQ-2K1 ?h1 =COMPLEX1R1 diffFDIFF-1K1(f1,x0)"
        using A2 A16 A28 fdiff_2_th_12 sorry
      then have "limSEQ-2K1 (?h1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2) =COMPLEX1R1 (diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0"
        using A32 A44 A45 seq_2_th_15 sorry
      then have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?v1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u2 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?u1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?v2)) =COMPLEX1R1 (diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0"
        using A48 A46 A38 A39 seq_2_th_12 sorry
      thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A1 A30 A42 A47 A49 A43 seq_2_th_24 sorry
    qed "sorry"
    have "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A13 rfunct_1_def_1 sorry
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0) =COMPLEX1R1 ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
      using A14 fdiff_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_15:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x0 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f is-differentiable-inFDIFF-1R1 x0 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain jj where 
      [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
      using numbers_th_19 sorry
    obtain f1 where 
      [ty]:"f1 be PartFuncPARTFUN1M1-of(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f,REALNUMBERSK2)" and f1Def:"f1 = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f -->PARTFUN2K4\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> jj"
      using funcop_1_th_45 sorry
    have 
      [ty]:"f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
    assume A1: "f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
      and A2: "f is-differentiable-inFDIFF-1R1 x0"
    obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A3: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 sorry
    have A4: "x0 inHIDDENR3 N"
      using rcomp_1_th_16 sorry
    have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using funcop_1_th_13 sorry
    have A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
    proof-
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M} & {TARSKIK1 \<one>\<^sub>M} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      proof(rule conjMI)
        show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1 c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M}"
          using funcop_1_th_13 sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have A7: "x0 inHIDDENR3 N"
            using rcomp_1_th_16 sorry
          assume "x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
          then have "x =HIDDENR1 \<one>\<^sub>M"
            using tarski_def_1 sorry
          then have "f1 .FUNCT-1K1 x0 =HIDDENR1 x"
            using A3 A7 funcop_1_th_7 sorry
          thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1"
            using A5 A3 A7 funct_1_def_3 sorry
        qed "sorry"
        thus "{TARSKIK1 \<one>\<^sub>M} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using tarski_def_3 sorry
      qed
      thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
        using xboole_0_def_10 sorry
    qed
    then have A8: "f1 is-differentiable-onFDIFF-1R2 N"
      using A5 A3 fdiff_1_th_11 sorry
    then have A9: "f1 is-differentiable-inFDIFF-1R1 x0"
      using A4 fdiff_1_th_9 sorry
    have "0NUMBERSK6 =HIDDENR1 (f1 `|FDIFF-1K2 N).FUNCT-1K1 x0"
      using A5 A3 A6 fdiff_1_th_11 rcomp_1_th_16 sorry
    also have "... = diffFDIFF-1K1(f1,x0)"
      using A8 A4 fdiff_1_def_7 sorry
    finally have "0NUMBERSK6 =HIDDENR1 diffFDIFF-1K1(f1,x0)"
       sorry
    then have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 ((0NUMBERSK6)*XCMPLX-0K3 f .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
      using A1 A2 A9 fdiff_2_th_14 sorry
    then have A10: "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (-XCMPLX-0K4 (diffFDIFF-1K1(f,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
       sorry
    also have "... = (-XCMPLX-0K4 (diffFDIFF-1K1(f,x0))*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
      using A3 A4 funcop_1_th_7 sorry
    also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
      using xcmplx_1_th_187 sorry
    finally have "diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
       sorry
    have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using A5 xboole_1_th_28 xboole_1_th_36 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
       sorry
    have A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A5 xboole_1_th_36 sorry
    have A13: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 r =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 r"
    proof(rule ballI,rule impI)
      have A14: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_def_2 sorry
      fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A15: "r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      have "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 r =HIDDENR1 f1 .FUNCT-1K1 r *XCMPLX-0K3 (f .FUNCT-1K1 r)\<inverse>XCMPLX-0K5"
        using A15 rfunct_1_def_1 sorry
      also have "... = \<one>\<^sub>M *XCMPLX-0K3 (f .FUNCT-1K1 r)\<inverse>XCMPLX-0K5"
        using A5 A12 A11 A15 A14 funcop_1_th_7 sorry
      also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 r"
        using A11 A15 rfunct_1_def_2 sorry
      finally show "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 r =HIDDENR1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 r"
         sorry
    qed "sorry"
    have "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A1 A2 A9 fdiff_2_th_14 sorry
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
      using A10 A11 A13 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_16:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-onFDIFF-1R2 A & f `|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-onFDIFF-1R2 A & f `|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 A"
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> A"
      using xboole_1_th_19 sorry
    then have A2: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)"
      using relat_1_th_61 sorry
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-inFDIFF-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 A"
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-inFDIFF-1R1 x0"
        using A1 sorry
      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-inFDIFF-1R1 x0"
        using relat_1_th_72 sorry
    qed "sorry"
    thus A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-onFDIFF-1R2 A"
      using A2 sorry
    then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have A5: " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 A implies (f `|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A6: "x0 inTARSKIR2 A"
      then obtain N2 where
        [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
        A7: "N2 c=TARSKIR1 A"
        using rcomp_1_th_18 sorry
      have A8: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A is-differentiable-inFDIFF-1R1 x0"
        using A1 A6 sorry
      have A9: "f is-differentiable-inFDIFF-1R1 x0"
        using A1 A6 fdiff_1_th_9 sorry
      then obtain N1 where
        [ty]:"N1 be NeighbourhoodRCOMP-1M1-of x0" and 
        A10: "N1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A11: " ex L be LinearFuncFDIFF-1M2 st  ex R be RestFuncFDIFF-1M1 st  for r be RealXREAL-0M1 holds r inHIDDENR3 N1 implies f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (r -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (r -XCMPLX-0K6 x0)"
         sorry
      obtain L R where
        [ty]:"L be LinearFuncFDIFF-1M2" "R be RestFuncFDIFF-1M1" and 
        A12: " for r be RealXREAL-0M1 holds r inHIDDENR3 N1 implies f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 x0 =COMPLEX1R1 L .FUNCT-1K1 (r -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (r -XCMPLX-0K6 x0)"
        using A11 sorry
      obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A13: "N c=TARSKIR1 N1"and A14: "N c=TARSKIR1 N2"
        using rcomp_1_th_17 sorry
      have A15: "N c=TARSKIR1 A"
        using A7 A14 sorry
      then have A16: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)"
        using A2 sorry
      have A17: " for r be RealXREAL-0M1 holds r inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 r -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (r -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (r -XCMPLX-0K6 x0)"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A18: "r inHIDDENR3 N"
        then have A19: "r inHIDDENR3 A"
          using A15 sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 r -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 x0 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A2 A6 funct_1_th_47 sorry
        also have "... = f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 x0"
          using A2 A19 funct_1_th_47 sorry
        also have "... = L .FUNCT-1K1 (r -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (r -XCMPLX-0K6 x0)"
          using A12 A13 A18 sorry
        finally show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 r -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 x0 =HIDDENR1 L .FUNCT-1K1 (r -XCMPLX-0K6 x0) +XCMPLX-0K2 R .FUNCT-1K1 (r -XCMPLX-0K6 x0)"
           sorry
      qed "sorry"
      have "(f `|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f,x0)"
        using A1 A6 fdiff_1_def_7 sorry
      also have "... = L .FUNCT-1K1 \<one>\<^sub>M"
        using A9 A10 A12 fdiff_1_def_5 sorry
      also have "... = diffFDIFF-1K1(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A,x0)"
        using A8 A16 A17 fdiff_1_def_5 sorry
      also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A3 A6 fdiff_1_def_7 sorry
      finally show "(f `|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A1 fdiff_1_def_7 sorry
    thus "f `|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A `|FDIFF-1K2 A"
      using A4 A5 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_17:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 A"
      and A2: "f2 is-differentiable-onFDIFF-1R2 A"
    have A3: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 sorry
    have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 xboole_1_th_19 sorry
    then have A4: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_1 sorry
    then have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A"
      using A1 A2 fdiff_1_th_18 sorry
    then have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A2 fdiff_1_def_7 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A1 fdiff_1_def_7 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A6 sorry
    then have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using valued_1_def_1 sorry
    have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 A implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A8: "x0 inTARSKIR2 A"
      then have "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f1,x0) +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
        using A1 A2 A4 fdiff_1_th_18 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 +XCMPLX-0K2 diffFDIFF-1K1(f2,x0)"
        using A1 A8 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 +XCMPLX-0K2 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A2 A8 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A7 A8 valued_1_def_1 sorry
      finally show "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
      using A1 A2 A4 A5 A7 fdiff_1_th_18 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_18:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 A"
      and A2: "f2 is-differentiable-onFDIFF-1R2 A"
    have A3: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 sorry
    have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 xboole_1_th_19 sorry
    then have A4: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_th_12 sorry
    then have "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A"
      using A1 A2 fdiff_1_th_19 sorry
    then have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A2 fdiff_1_def_7 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A1 fdiff_1_def_7 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A6 sorry
    then have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using valued_1_th_12 sorry
    have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 A implies ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A8: "x0 inTARSKIR2 A"
      then have "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f1,x0) -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
        using A1 A2 A4 fdiff_1_th_19 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 -XCMPLX-0K6 diffFDIFF-1K1(f2,x0)"
        using A1 A8 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 -XCMPLX-0K6 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A2 A8 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A7 A8 valued_1_th_13 sorry
      finally show "((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 `|FDIFF-1K2 A -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 `|FDIFF-1K2 A"
      using A1 A2 A4 A5 A7 fdiff_1_th_19 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_19:
" for r be RealXREAL-0M1 holds  for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 A & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)"
proof-
  have " for r be RealXREAL-0M1 holds  for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 A & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 A"
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    then have A2: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    then have "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 A"
      using A1 fdiff_1_th_20 sorry
    then have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A1 fdiff_1_def_7 sorry
    then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)) =XBOOLE-0R4 A"
      using valued_1_def_5 sorry
    have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 A implies ((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A5: "x0 inTARSKIR2 A"
      then have "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 r *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
        using A1 A2 fdiff_1_th_20 sorry
      also have "... = r *XCMPLX-0K3 (f `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A1 A5 fdiff_1_def_7 sorry
      also have "... = (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)).FUNCT-1K1 x0"
        using A4 A5 valued_1_def_5 sorry
      finally show "((r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 A & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)"
      using A1 A2 A3 A4 fdiff_1_th_20 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_20:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A implies f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 A"
      and A2: "f2 is-differentiable-onFDIFF-1R2 A"
    have A3: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    have A4: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 sorry
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 xboole_1_th_19 sorry
    then have A5: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_4 sorry
    then have "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A"
      using A1 A2 fdiff_1_th_21 sorry
    then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A2 fdiff_1_def_7 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A3 xboole_1_th_28 sorry
    then have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)) =XBOOLE-0R4 A"
      using valued_1_def_4 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using A1 fdiff_1_def_7 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 A"
      using A4 xboole_1_th_28 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 A"
      using valued_1_def_4 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)) =XBOOLE-0R4 A"
      using A7 sorry
    then have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)) =XBOOLE-0R4 A"
      using valued_1_def_1 sorry
    have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 A implies ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A9: "x0 inTARSKIR2 A"
      then have "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
        using A1 A2 A5 fdiff_1_th_21 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0 +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (diffFDIFF-1K1(f2,x0))"
        using A1 A9 fdiff_1_def_7 sorry
      also have "... = (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0 +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A2 A9 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 +XCMPLX-0K2 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 +XCMPLX-0K2 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
        using A8 A9 valued_1_def_1 sorry
      finally show "((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)"
      using A1 A2 A5 A6 A8 fdiff_1_th_21 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_2_lm_3:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule ballI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof(rule conjMI)
      show "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A1: "x inHIDDENR3 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          then obtain x9 where 
            [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
             sorry
          have "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using A1 funct_1_def_7 sorry
          then have "0NUMBERSK6 =HIDDENR1 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x9"
            using tarski_def_1 sorry
          also have "... = f .FUNCT-1K1 x9 *XCMPLX-0K3 f .FUNCT-1K1 x9"
            using valued_1_th_5 sorry
          finally have "0NUMBERSK6 =HIDDENR1 f .FUNCT-1K1 x9 *XCMPLX-0K3 f .FUNCT-1K1 x9"
             sorry
          then have "f .FUNCT-1K1 x9 =COMPLEX1R1 0NUMBERSK6"
             sorry
          then have A2: "f .FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
            using tarski_def_1 sorry
          have "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using A1 funct_1_def_7 sorry
          then have "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using valued_1_def_4 sorry
          thus "x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
            using A2 funct_1_def_7 sorry
        qed "sorry"
        thus "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then obtain x9 where 
          [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
           sorry
        have "f .FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A3 funct_1_def_7 sorry
        then have "0NUMBERSK6 =COMPLEX1R1 f .FUNCT-1K1 x9"
          using tarski_def_1 sorry
        then have "f .FUNCT-1K1 x9 *XCMPLX-0K3 f .FUNCT-1K1 x9 =COMPLEX1R1 0NUMBERSK6"
           sorry
        then have "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x9 =COMPLEX1R1 0NUMBERSK6"
          using valued_1_th_5 sorry
        then have A4: "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A3 funct_1_def_7 sorry
        then have "x9 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using valued_1_def_4 sorry
        thus "x inHIDDENR3 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using A4 funct_1_def_7 sorry
      qed "sorry"
      thus "f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    thus "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_21:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 A & f2 is-differentiable-onFDIFF-1R2 A) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & (f2 is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6)) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A & (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 A"
      and A2: "f2 is-differentiable-onFDIFF-1R2 A"
      and A3: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
    have A4: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    have A5: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 sorry
    have A6: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A7: "x inHIDDENR3 A"
        then obtain x9 where 
          [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
           sorry
        assume " not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then have " not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 or x inHIDDENR3 f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        then have "f2 .FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A5 A7 funct_1_def_7 sorry
        then have "f2 .FUNCT-1K1 x9 =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        thus " False "
          using A3 A7 sorry
      qed "sorry"
      thus "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A4 xboole_1_th_19 sorry
    then have A8: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using rfunct_1_def_1 sorry
    have A9: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & (f1 is-differentiable-inFDIFF-1R1 x0 & (f2 is-differentiable-inFDIFF-1R1 x0 & f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0))"
    proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A10: "x0 inHIDDENR3 A"
      thus A11: "f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using A3 sorry
      show A12: "f1 is-differentiable-inFDIFF-1R1 x0"
        using A1 A10 fdiff_1_th_9 sorry
      show "f2 is-differentiable-inFDIFF-1R1 x0"
        using A2 A10 fdiff_1_th_9 sorry
      thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
        using A11 A12 fdiff_2_th_14 sorry
    qed "sorry"
    then have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x0"
       sorry
    thus A13: "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 A"
      using A8 fdiff_1_th_9 sorry
    then have A14: "A =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A)"
      using fdiff_1_def_7 sorry
    have A15: " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A) implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A16: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A)"
      then have A17: "f1 is-differentiable-inFDIFF-1R1 x0"
        using A9 A14 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
        using A2 fdiff_1_def_7 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A4 A14 A16 xboole_0_def_4 sorry
      then have A18: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using valued_1_def_4 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) =XBOOLE-0R4 A"
        using A1 fdiff_1_def_7 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 A14 A16 xboole_0_def_4 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using valued_1_def_4 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using A18 xboole_0_def_4 sorry
      then have A19: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        using valued_1_th_12 sorry
      have A20: "f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using A9 A14 A16 sorry
      then have "f2 .FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
         sorry
      then have "(f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using valued_1_th_5 sorry
      then have " not (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      then have A21: " not x0 inTARSKIR2 (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A5 A14 A16 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using valued_1_def_4 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A21 xboole_0_def_5 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
        using A19 xboole_0_def_4 sorry
      then have A22: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
        using rfunct_1_def_1 sorry
      have A23: "f2 is-differentiable-inFDIFF-1R1 x0"
        using A9 A14 A16 sorry
      have "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x0)"
        using A13 A14 A16 fdiff_1_def_7 sorry
      also have "... = ((diffFDIFF-1K1(f1,x0))*XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A20 A17 A23 fdiff_2_th_14 sorry
      also have "... = ((f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (diffFDIFF-1K1(f2,x0))*XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A1 A14 A16 fdiff_1_def_7 sorry
      also have "... = ((f1 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0 -XCMPLX-0K6 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A2 A14 A16 fdiff_1_def_7 sorry
      also have "... = (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 -XCMPLX-0K6 (f2 `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 f1 .FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using valued_1_th_5 sorry
      also have "... = (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 -XCMPLX-0K6 ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0)/XCMPLX-0K7 (f2 .FUNCT-1K1 x0)^2SQUARE-1K1"
        using valued_1_th_5 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 /XCMPLX-0K7 (f2 .FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0)"
        using A19 valued_1_th_13 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 /XCMPLX-0K7 (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 *XCMPLX-0K3 ((f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0)\<inverse>XCMPLX-0K5"
        using xcmplx_0_def_9 sorry
      also have "... = (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x0"
        using A22 rfunct_1_def_1 sorry
      finally show "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    also have "... = (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using valued_1_th_12 sorry
    also have "... = ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using valued_1_def_4 sorry
    also have "... = ((A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A1 fdiff_1_def_7 sorry
    also have "... = (A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A5 xboole_1_th_28 sorry
    also have "... = (A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using valued_1_def_4 sorry
    also have "... = (A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1))/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A2 fdiff_1_def_7 sorry
    also have "... = (A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> A)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A4 xboole_1_th_28 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using valued_1_def_4 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using fdiff_2_lm_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A)"
      using A6 A14 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A)"
       sorry
    thus "(f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f1 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 A)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A15 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_22:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 A & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 A & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-onFDIFF-1R2 A"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
    have A3: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & (f is-differentiable-inFDIFF-1R1 x0 & f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0)"
    proof(rule ballI,rule impI,rule conjMI,rule conjMI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A4: "x0 inHIDDENR3 A"
      thus A5: "f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      show "f is-differentiable-inFDIFF-1R1 x0"
        using A1 A4 fdiff_1_th_9 sorry
      thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0"
        using A5 fdiff_2_th_15 sorry
    qed "sorry"
    then have A6: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x0"
       sorry
    have A7: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 sorry
    have A8: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies ( not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies  False )"
      proof(rule ballI,rule impI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A9: "x inHIDDENR3 A"
        then obtain x9 where 
          [ty]:"x9 be RealXREAL-0M1" and x9Def:"x9 = x"
           sorry
        assume " not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then have " not x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f or x inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using xboole_0_def_5 sorry
        then have "f .FUNCT-1K1 x9 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A7 A9 funct_1_def_7 sorry
        then have "f .FUNCT-1K1 x9 =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        thus " False "
          using A2 A9 sorry
      qed "sorry"
      thus "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    thus A10: "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 A"
      using A6 fdiff_1_th_9 sorry
    then have A11: "A =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A)"
      using fdiff_1_def_7 sorry
    have A12: " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A) implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      have A13: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A) =XBOOLE-0R4 A"
        using A1 fdiff_1_def_7 sorry
      assume A14: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A)"
      then have A15: "f is-differentiable-inFDIFF-1R1 x0"
        using A3 A11 sorry
      have A16: "f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using A3 A11 A14 sorry
      then have "f .FUNCT-1K1 x0 *XCMPLX-0K3 f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
         sorry
      then have "(f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
        using valued_1_th_5 sorry
      then have " not (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      then have A17: " not x0 inTARSKIR2 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using funct_1_def_7 sorry
      have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A11 A14 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        using valued_1_def_4 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A17 xboole_0_def_5 sorry
      then have "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
        using A11 A14 A13 xboole_0_def_4 sorry
      then have A18: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        using rfunct_1_def_1 sorry
      have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0)"
        using A10 A11 A14 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 (f .FUNCT-1K1 x0)^2SQUARE-1K1"
        using A16 A15 fdiff_2_th_15 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 A).FUNCT-1K1 x0 /XCMPLX-0K7 (f .FUNCT-1K1 x0 *XCMPLX-0K3 f .FUNCT-1K1 x0)"
        using A1 A11 A14 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 A).FUNCT-1K1 x0 /XCMPLX-0K7 (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 A).FUNCT-1K1 x0 *XCMPLX-0K3 ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0)\<inverse>XCMPLX-0K5"
        using xcmplx_0_def_9 sorry
      also have "... = -XCMPLX-0K4 ((f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x0"
        using A18 rfunct_1_def_1 sorry
      also have "... = (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x0"
        using valued_1_th_8 sorry
      finally show "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using valued_1_th_8 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using A1 fdiff_1_def_7 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using valued_1_def_4 sorry
    also have "... = A /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 })"
      using fdiff_2_lm_3 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A)"
      using A8 A11 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A)"
       sorry
    thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f `|FDIFF-1K2 A)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A12 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_23:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f1 is-differentiable-onFDIFF-1R2 A & f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2) & f2 is-differentiable-onFDIFF-1R2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 A & (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1 is-differentiable-onFDIFF-1R2 A & (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 & f2 is-differentiable-onFDIFF-1R2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 A & (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f1 is-differentiable-onFDIFF-1R2 A"
      and A2: "f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
      and A3: "f2 is-differentiable-onFDIFF-1R2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A"
    have A4: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 sorry
    have A5: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f1 is-differentiable-inFDIFF-1R1 x0 & (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & (f1 .FUNCT-1K1 x0 inTARSKIR2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A & (f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0 & f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0)))"
    proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A6: "x0 inHIDDENR3 A"
      thus A7: "f1 is-differentiable-inFDIFF-1R1 x0"
        using A1 fdiff_1_th_9 sorry
      show "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A4 A6 sorry
      show "f1 .FUNCT-1K1 x0 inTARSKIR2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A"
        using A4 A6 funct_1_def_6 sorry
      thus "f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0"
        using A2 A3 fdiff_1_th_9 sorry
      thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0"
        using A7 fdiff_2_th_13 sorry
    qed "sorry"
    have "f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 sorry
    then have A8: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A4 funct_3_th_3 sorry
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-inFDIFF-1R1 x0"
      using A5 sorry
    thus A9: "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-differentiable-onFDIFF-1R2 A"
      using A8 fdiff_1_th_9 sorry
    then have A10: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A) =XBOOLE-0R4 A"
      using fdiff_1_def_7 sorry
    have A11: " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A) implies ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A12: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A)"
      then have A13: "f1 is-differentiable-inFDIFF-1R1 x0"
        using A5 A10 sorry
      have A14: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A5 A10 A12 sorry
      have A15: "f1 .FUNCT-1K1 x0 inTARSKIR2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A"
        using A5 A10 A12 sorry
      have A16: "f2 is-differentiable-inFDIFF-1R1 f1 .FUNCT-1K1 x0"
        using A5 A10 A12 sorry
      have "((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 diffFDIFF-1K1(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1,x0)"
        using A9 A10 A12 fdiff_1_def_7 sorry
      also have "... = (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f1,x0))"
        using A13 A16 fdiff_2_th_13 sorry
      also have "... = (diffFDIFF-1K1(f2,f1 .FUNCT-1K1 x0))*XCMPLX-0K3 (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A1 A10 A12 fdiff_1_def_7 sorry
      also have "... = (f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A).FUNCT-1K1 (f1 .FUNCT-1K1 x0) *XCMPLX-0K3 (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A3 A15 fdiff_1_def_7 sorry
      also have "... = ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 *XCMPLX-0K3 (f1 `|FDIFF-1K2 A).FUNCT-1K1 x0"
        using A14 funct_1_th_13 sorry
      also have "... = (((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      finally show "((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A).FUNCT-1K1 x0 =HIDDENR1 (((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)).FUNCT-1K1 x0"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A) =XBOOLE-0R4 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A"
      using A3 fdiff_1_def_7 sorry
    then have "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
      using A4 funct_1_th_101 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> A"
      using A10 xboole_1_th_28 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)"
      using A1 fdiff_1_def_7 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A))"
      using valued_1_def_4 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A))"
       sorry
    thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)`|FDIFF-1K2 A =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f2 `|FDIFF-1K2 f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> A)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 `|FDIFF-1K2 A)"
      using A11 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_24:
" for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 A & p inHIDDENR3 A implies  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 p .| <=XXREAL-0R1 (r -XCMPLX-0K6 p)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6)"
proof-
  have " for A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 A & p inHIDDENR3 A implies  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 p .| <=XXREAL-0R1 (r -XCMPLX-0K6 p)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 A & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
    fix A assume [ty]: "A be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "A c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: " for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds r inHIDDENR3 A & p inHIDDENR3 A implies  |.COMPLEX1K10 f .FUNCT-1K1 r -XCMPLX-0K6 f .FUNCT-1K1 p .| <=XXREAL-0R1 (r -XCMPLX-0K6 p)^2SQUARE-1K1"
    have A3: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume "x0 inHIDDENR3 A"
      then obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A4: "N c=TARSKIR1 A"
        using rcomp_1_th_18 sorry
      have A5: "N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A4 sorry
      have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 0NUMBERSK6"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
        let ?a = "seq-constSEQ-1K1 (0NUMBERSK6)"
        fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
        fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
        assume A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
          and A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        have A8: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 x0"
          using A6 fdiff_2_th_4 sorry
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A9: "0NUMBERSK6 <XXREAL-0R3 r"and A10: "N =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A11: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
          using A8 A9 seq_2_def_7 sorry
        let ?hc = "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
        have A12: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?hc c=TARSKIR1 A"
        proof-
          have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 A"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) implies x inHIDDENR3 A"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?hc"
              then obtain m where
                [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A13: "x =HIDDENR1 ?hc .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m"
                using funct_2_th_113 sorry
              have "x =HIDDENR1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 (m +XCMPLX-0K2 n)"
                using A13 nat_1_def_3 sorry
              then have " |.COMPLEX1K10 ?hc .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m -XCMPLX-0K6 x0 .| <XXREAL-0R3 r"
                using A11 A13 nat_1_th_12 sorry
              then have "x inHIDDENR3 N"
                using A10 A13 rcomp_1_th_1 sorry
              thus "x inHIDDENR3 A"
                using A4 sorry
            qed "sorry"
            thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 A"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
            then have A15: "x =HIDDENR1 x0"
              using A6 tarski_def_1 sorry
            have "x0 inHIDDENR3 N"
              using rcomp_1_th_16 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A5 A15 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
        qed
        let ?fn = "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
        let ?h1 = "h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
        let ?c1 = "c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n"
        have A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1 c=TARSKIR1 A"
        proof-
          have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 A"
          proof-
            have A17: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_21 sorry
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) implies x inHIDDENR3 A"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1"
              then have A18: "x =HIDDENR1 x0"
                using A6 A17 tarski_def_1 sorry
              have "x0 inHIDDENR3 N"
                using rcomp_1_th_16 sorry
              thus "x inHIDDENR3 A"
                using A4 A18 sorry
            qed "sorry"
            thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) c=TARSKIR1 A"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A19: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 be non-zeroORDINAL1V9"
          using seq_1_th_53 sorry
        have A20: " for m be NatNAT-1M1 holds ?a .FUNCT-1K1 m <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?fn .FUNCT-1K1 m & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?fn .FUNCT-1K1 m <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1.|).FUNCT-1K1 m"
        proof-
          have " for m be NatNAT-1M1 holds (seq-constSEQ-1K1 (0NUMBERSK6)).FUNCT-1K1 m <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-1K1 m & absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-1K1 m <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
          proof(rule ballI,rule conjMI)
            fix m assume [ty]: "m be NatNAT-1M1"
            have A21: "m inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A22: "?c1 .FUNCT-1K1 m inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?c1"
              using valued_0_th_28 sorry
            have "?hc .FUNCT-1K1 m inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?hc"
              using valued_0_th_28 sorry
            then have " |.COMPLEX1K10 f .FUNCT-1K1 (?hc .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 (?c1 .FUNCT-1K1 m) .| <=XXREAL-0R1 (?hc .FUNCT-1K1 m -XCMPLX-0K6 ?c1 .FUNCT-1K1 m)^2SQUARE-1K1"
              using A2 A12 A16 A22 sorry
            then have A23: " |.COMPLEX1K10 f .FUNCT-1K1 (?hc .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 (?c1 .FUNCT-1K1 m) .| <=XXREAL-0R1 ( |.COMPLEX1K10 ?hc .FUNCT-1K1 m -XCMPLX-0K6 ?c1 .FUNCT-1K1 m .|)^2SQUARE-1K1"
              using complex1_th_75 sorry
            have A24: "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-1K1 m"
              using valued_1_th_10 sorry
            also have "... = (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
              using seq_1_th_8 sorry
            also have "... = (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>) (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)).FUNCT-1K1 m"
              using seq_1_th_54 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .|).FUNCT-1K1 m"
              using seq_1_th_52 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .|).FUNCT-1K1 m"
              using seqm_3_th_18 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
              using seqm_3_th_19 sorry
            finally have "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
               sorry
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 ?fn .FUNCT-1K1 m.|"
              using complex1_th_46 sorry
            then have "?a .FUNCT-1K1 m <=XXREAL-0R1  |.COMPLEX1K10 ?fn .FUNCT-1K1 m.|"
              using seq_1_th_57 sorry
            thus "(seq-constSEQ-1K1 (0NUMBERSK6)).FUNCT-1K1 m <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-1K1 m"
              using seq_1_th_12 sorry
            have A25: "( |.COMPLEX1K10 ?hc .FUNCT-1K1 m -XCMPLX-0K6 ?c1 .FUNCT-1K1 m .|)^2SQUARE-1K1 =HIDDENR1 ( |.COMPLEX1K10 (?h1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1).FUNCT-1K1 m -XCMPLX-0K6 ?c1 .FUNCT-1K1 m .|)^2SQUARE-1K1"
              using seqm_3_th_15 sorry
            also have "... = ( |.COMPLEX1K10 (?h1 .FUNCT-1K1 m +XCMPLX-0K2 ?c1 .FUNCT-1K1 m)-XCMPLX-0K6 ?c1 .FUNCT-1K1 m .|)^2SQUARE-1K1"
              using seq_1_th_7 sorry
            also have "... = (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)^2SQUARE-1K1"
              using seq_1_th_12 sorry
            also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m"
               sorry
            finally have "( |.COMPLEX1K10 ?hc .FUNCT-1K1 m -XCMPLX-0K6 ?c1 .FUNCT-1K1 m .|)^2SQUARE-1K1 =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m"
               sorry
            have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 ?h1 .FUNCT-1K1 m.|"
              using complex1_th_46 sorry
            then have A26: "0NUMBERSK6 <=XXREAL-0R1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m"
              using seq_1_th_12 sorry
            have A27: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6"
              using A19 seq_1_th_5 sorry
            have A28: "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)*XCMPLX-0K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5)"
               sorry
            also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 \<one>\<^sub>M"
              using A27 xcmplx_0_def_7 sorry
            also have "... = absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m"
               sorry
            finally have "(absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m *XCMPLX-0K3 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)*XCMPLX-0K3 (absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 =HIDDENR1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 .FUNCT-1K1 m"
               sorry
            have " |.COMPLEX1K10 f .FUNCT-1K1 (?hc .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 (?c1 .FUNCT-1K1 m) .| =HIDDENR1  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?hc .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 (?c1 .FUNCT-1K1 m) .|"
              using A1 A12 funct_2_th_108 xboole_1_th_1 A21 sorry
            also have "... =  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?hc .FUNCT-1K1 m -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1 .FUNCT-1K1 m .|"
              using A1 A16 funct_2_th_108 xboole_1_th_1 A21 sorry
            also have "... =  |.COMPLEX1K10 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?hc -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1).FUNCT-1K1 m.|"
              using rfunct_2_th_1 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?hc -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1 .|).FUNCT-1K1 m"
              using seq_1_th_12 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?c1 .|).FUNCT-1K1 m"
              using A7 valued_0_th_27 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
              using A14 valued_0_th_27 sorry
            also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
              using seqm_3_th_17 sorry
            finally have " |.COMPLEX1K10 f .FUNCT-1K1 (?hc .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 (?c1 .FUNCT-1K1 m) .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
               sorry
            thus "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n) .FUNCT-1K1 m <=XXREAL-0R1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> n .|).FUNCT-1K1 m"
              using A23 A25 A26 A28 A24 xreal_1_th_64 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "limSEQ-2K1 ?h1 =COMPLEX1R1 0NUMBERSK6"
           sorry
        then have A29: "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 .|"
          using seq_4_th_14 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_th_2 sorry
        finally have "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?h1 =HIDDENR1 0NUMBERSK6"
           sorry
        have A30: "limSEQ-2K1 ?a =HIDDENR1 ?a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using seq_4_th_26 sorry
        also have "... = 0NUMBERSK6"
          using seq_1_th_57 sorry
        finally have "limSEQ-2K1 ?a =HIDDENR1 0NUMBERSK6"
           sorry
        then have A31: "limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?fn =COMPLEX1R1 0NUMBERSK6"
          using A29 A20 seq_2_th_20 sorry
        have A32: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ?fn be convergentSEQ-2V5"
          using A30 A29 A20 seq_2_th_19 sorry
        then have A33: "?fn be convergentSEQ-2V5"
          using A31 seq_4_th_15 sorry
        thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
          using seq_4_th_21 sorry
        have "limSEQ-2K1 ?fn =COMPLEX1R1 0NUMBERSK6"
          using A32 A31 seq_4_th_15 sorry
        thus "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 0NUMBERSK6"
          using A33 seq_4_th_22 sorry
      qed "sorry"
      thus "f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
        using A5 fdiff_2_th_12 sorry
    qed "sorry"
    then have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 A implies f is-differentiable-inFDIFF-1R1 x0"
       sorry
    thus "f is-differentiable-onFDIFF-1R2 A"
      using A1 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume "x0 inHIDDENR3 A"
    thus "diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_25:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & r2 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & r2 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) & ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 ].RCOMP-1K2 p,g .[ & r2 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1"
      and A2: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    show A3: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      using A1 A2 fdiff_2_th_24 sorry
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 fdiff_2_th_24 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be constantFUNCT-1V5"
      using A3 rolle_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_26:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r & r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be constantFUNCT-1V5"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r & r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r & r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A3: "r1 inTARSKIR2 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inTARSKIR2 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      let ?rr = "minXXREAL-0K4(r1,r2)"
      have A5: "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 left-open-halflineLIMFUNC1K1 r"
        using xxreal_1_th_263 sorry
      then have A6: " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ & g2 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 g2 .| <=XXREAL-0R1 (g1 -XCMPLX-0K6 g2)^2SQUARE-1K1"
        using A2 sorry
      have "r2 inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inTARSKIR2 {p where p be RealXREAL-0M1 : p <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have A7: " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & g2 <XXREAL-0R3 r"
         sorry
      have "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 r }"
        using A7 sorry
      then have A8: "r2 inTARSKIR2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A9: "r2 inTARSKIR2 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 xboole_0_def_4 sorry
      have "r1 inTARSKIR2 left-open-halflineLIMFUNC1K1 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inTARSKIR2 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have A10: " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & g1 <XXREAL-0R3 r"
         sorry
      have "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r }"
        using A10 sorry
      then have A11: "r1 inTARSKIR2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have A12: "r1 inTARSKIR2 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A11 xboole_0_def_4 sorry
      have "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A5 sorry
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[) be constantFUNCT-1V5"
        using A6 fdiff_2_th_25 sorry
      thus "f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
        using A12 A9 partfun2_th_58 sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be constantFUNCT-1V5"
      using A1 A2 fdiff_2_th_24 partfun2_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_27:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r & r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be constantFUNCT-1V5"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r & r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be constantFUNCT-1V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r & r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1"
    have " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A3: "r1 inTARSKIR2 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inTARSKIR2 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      let ?rr = "maxXXREAL-0K5(r1,r2)"
      have A5: "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 right-open-halflineLIMFUNC1K4 r"
        using xxreal_1_th_247 sorry
      then have A6: " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ & g2 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 g2 .| <=XXREAL-0R1 (g1 -XCMPLX-0K6 g2)^2SQUARE-1K1"
        using A2 sorry
      have "r2 inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inTARSKIR2 {p where p be RealXREAL-0M1 : r <XXREAL-0R3 p }"
        using xxreal_1_th_230 sorry
      then have A7: " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & r <XXREAL-0R3 g2"
         sorry
      have "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      then have "r2 inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A7 sorry
      then have A8: "r2 inTARSKIR2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A9: "r2 inTARSKIR2 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 xboole_0_def_4 sorry
      have "r1 inTARSKIR2 right-open-halflineLIMFUNC1K4 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inTARSKIR2 {g where g be RealXREAL-0M1 : r <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have A10: " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & r <XXREAL-0R3 g1"
         sorry
      have "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      then have "r1 inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A10 sorry
      then have A11: "r1 inTARSKIR2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have A12: "r1 inTARSKIR2 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A11 xboole_0_def_4 sorry
      have "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A1 A5 sorry
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[) be constantFUNCT-1V5"
        using A6 fdiff_2_th_25 sorry
      thus "f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
        using A12 A9 partfun2_th_58 sorry
    qed "sorry"
    thus "f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be constantFUNCT-1V5"
      using A1 A2 fdiff_2_th_24 partfun2_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_28:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be constantFUNCT-1V5"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1) implies f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be constantFUNCT-1V5"
  proof(rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      and A2: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
      using A1 partfun1_def_2 sorry
    have A4: " for r1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for r2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds r1 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be ElementSUBSET-1M1-of REALNUMBERSK2"
      fix r2 assume [ty]: "r2 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A5: "r1 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A6: "r2 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      let ?rx = "maxXXREAL-0K5(r1,r2)"
      let ?rn = "minXXREAL-0K4(r1,r2)"
      have A7: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have A8: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inTARSKIR2 {g2 where g2 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A8 sorry
      then have A9: "r2 inTARSKIR2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 xboole_0_def_4 sorry
      then have A10: "r2 inTARSKIR2 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A9 xboole_0_def_4 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inTARSKIR2 {g1 where g1 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A7 sorry
      then have A11: "r1 inTARSKIR2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A5 xboole_0_def_4 sorry
      then have A12: "r1 inTARSKIR2 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A11 xboole_0_def_4 sorry
      have " for g1 be RealXREAL-0M1 holds  for g2 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ & g2 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ implies  |.COMPLEX1K10 f .FUNCT-1K1 g1 -XCMPLX-0K6 f .FUNCT-1K1 g2 .| <=XXREAL-0R1 (g1 -XCMPLX-0K6 g2)^2SQUARE-1K1"
        using A2 sorry
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[) be constantFUNCT-1V5"
        using A3 fdiff_2_th_25 sorry
      thus "f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"
        using A12 A10 partfun2_th_58 sorry
    qed "sorry"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 & r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 implies  |.COMPLEX1K10 f .FUNCT-1K1 r1 -XCMPLX-0K6 f .FUNCT-1K1 r2 .| <=XXREAL-0R1 (r1 -XCMPLX-0K6 r2)^2SQUARE-1K1"
      using A2 sorry
    thus "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be constantFUNCT-1V5"
      using A3 A4 fdiff_2_th_24 partfun2_th_58 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_29:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "minXXREAL-0K4(r1,r2)"
      have A6: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : p <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & g2 <XXREAL-0R3 r"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 r }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using A1 fdiff_1_th_26 xxreal_1_th_263 sorry
      have "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 left-open-halflineLIMFUNC1K1 r"
        using xxreal_1_th_263 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[) be increasingVALUED-0V9"
        using A9 rolle_th_9 sorry
      have A11: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & g1 <XXREAL-0R3 r"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
        using A5 A10 A8 rfunct_2_th_20 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be increasingVALUED-0V9"
      using rfunct_2_th_20 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_30:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "minXXREAL-0K4(r1,r2)"
      have A6: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : p <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & g2 <XXREAL-0R3 r"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 r }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using A1 fdiff_1_th_26 xxreal_1_th_263 sorry
      have "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 left-open-halflineLIMFUNC1K1 r"
        using xxreal_1_th_263 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ implies diffFDIFF-1K1(f,g1) <XXREAL-0R3 0NUMBERSK6"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[) be decreasingVALUED-0V10"
        using A9 rolle_th_10 sorry
      have A11: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & g1 <XXREAL-0R3 r"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
        using A5 A10 A8 rfunct_2_th_21 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be decreasingVALUED-0V10"
      using rfunct_2_th_21 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_31:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "minXXREAL-0K4(r1,r2)"
      have A6: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : p <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & g2 <XXREAL-0R3 r"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 r }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using A1 fdiff_1_th_26 xxreal_1_th_263 sorry
      have "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 left-open-halflineLIMFUNC1K1 r"
        using xxreal_1_th_263 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[) be non-decreasingVALUED-0V11"
        using A9 rolle_th_11 sorry
      have A11: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & g1 <XXREAL-0R3 r"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
        using A5 A10 A8 rfunct_2_th_22 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-decreasingVALUED-0V11"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_32:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "left-open-halflineLIMFUNC1K1 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (left-open-halflineLIMFUNC1K1 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "minXXREAL-0K4(r1,r2)"
      have A6: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r2 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : p <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & g2 <XXREAL-0R3 r"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 r }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using A1 fdiff_1_th_26 xxreal_1_th_263 sorry
      have "].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ c=TARSKIR1 left-open-halflineLIMFUNC1K1 r"
        using xxreal_1_th_263 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[ implies diffFDIFF-1K1(f,g1) <=XXREAL-0R1 0NUMBERSK6"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[) be non-increasingVALUED-0V12"
        using A9 rolle_th_12 sorry
      have A11: "?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      have "r1 inHIDDENR3 left-open-halflineLIMFUNC1K1 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : g <XXREAL-0R3 r }"
        using xxreal_1_th_229 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & g1 <XXREAL-0R3 r"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rr -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 r }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rr -XCMPLX-0K6 \<one>\<^sub>M,r .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
        using A5 A10 A8 rfunct_2_th_23 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 r) be non-increasingVALUED-0V12"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_33:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "maxXXREAL-0K5(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : r <XXREAL-0R3 p }"
        using xxreal_1_th_230 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & r <XXREAL-0R3 g2"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 xxreal_1_th_247 sorry
      have "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 right-open-halflineLIMFUNC1K4 r"
        using xxreal_1_th_247 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[) be increasingVALUED-0V9"
        using A9 rolle_th_9 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : r <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & r <XXREAL-0R3 g1"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
        using A5 A10 A8 rfunct_2_th_20 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be increasingVALUED-0V9"
      using rfunct_2_th_20 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_34:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "maxXXREAL-0K5(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : r <XXREAL-0R3 p }"
        using xxreal_1_th_230 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & r <XXREAL-0R3 g2"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 xxreal_1_th_247 sorry
      have "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 right-open-halflineLIMFUNC1K4 r"
        using xxreal_1_th_247 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ implies diffFDIFF-1K1(f,g1) <XXREAL-0R3 0NUMBERSK6"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[) be decreasingVALUED-0V10"
        using A9 rolle_th_10 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : r <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & r <XXREAL-0R3 g1"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
        using A5 A10 A8 rfunct_2_th_21 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be decreasingVALUED-0V10"
      using rfunct_2_th_21 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be one-to-oneFUNCT-1V2"
      using fcont_3_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_35:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "maxXXREAL-0K5(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : r <XXREAL-0R3 p }"
        using xxreal_1_th_230 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & r <XXREAL-0R3 g2"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 xxreal_1_th_247 sorry
      have "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 right-open-halflineLIMFUNC1K4 r"
        using xxreal_1_th_247 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[) be non-decreasingVALUED-0V11"
        using A9 rolle_th_11 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : r <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & r <XXREAL-0R3 g1"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
        using A5 A10 A8 rfunct_2_th_22 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-decreasingVALUED-0V11"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_36:
" for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12"
proof-
  have " for r be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "right-open-halflineLIMFUNC1K4 r c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 r"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 r implies diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 (right-open-halflineLIMFUNC1K4 r)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rr = "maxXXREAL-0K5(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r2 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A4 xboole_0_def_4 sorry
      then have "r2 inHIDDENR3 {p where p be RealXREAL-0M1 : r <XXREAL-0R3 p }"
        using xxreal_1_th_230 sorry
      then have " ex g2 be RealXREAL-0M1 st g2 =COMPLEX1R1 r2 & r <XXREAL-0R3 g2"
         sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : r <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 xxreal_1_th_247 sorry
      have "].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ c=TARSKIR1 right-open-halflineLIMFUNC1K4 r"
        using xxreal_1_th_247 sorry
      then have " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[ implies diffFDIFF-1K1(f,g1) <=XXREAL-0R1 0NUMBERSK6"
        using A2 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[) be non-increasingVALUED-0V12"
        using A9 rolle_th_12 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "r1 inHIDDENR3 right-open-halflineLIMFUNC1K4 r"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 {g where g be RealXREAL-0M1 : r <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have " ex g1 be RealXREAL-0M1 st g1 =COMPLEX1R1 r1 & r <XXREAL-0R3 g1"
         sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : r <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rr +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 r,?rr +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
        using A5 A10 A8 rfunct_2_th_23 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 r) be non-increasingVALUED-0V12"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_37:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9 & f be one-to-oneFUNCT-1V2"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9 & f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A2: " for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
    have A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A4: "r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A6: "r1 <XXREAL-0R3 r2"
      let ?rx = "maxXXREAL-0K5(r1,r2)"
      let ?rn = "minXXREAL-0K4(r1,r2)"
      have A7: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A7 sorry
      then have A8: "r2 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A5 xboole_0_def_4 sorry
      then have A9: "r2 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 xboole_0_def_4 sorry
      have A10: " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      have "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 sorry
      then have A11: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[) be increasingVALUED-0V9"
        using A10 rolle_th_9 sorry
      have A12: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A12 sorry
      then have A13: "r1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A13 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <XXREAL-0R3 f .FUNCT-1K1 r2"
        using A6 A11 A9 rfunct_2_th_20 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9"
      using rfunct_2_th_20 sorry
    have "( ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2) & r1 <>HIDDENR2 r2) implies  False "
    proof(rule impI)
      assume Given: " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2) & r1 <>HIDDENR2 r2"
      then obtain r1 r2 where
        [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" "r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A14: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A15: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A16: "f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"and A17: "r1 <>HIDDENR2 r2"
         sorry
      have A18: "r2 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A15 xboole_0_def_4 sorry
      have A19: "r1 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 xboole_0_def_4 sorry
      have " False "
      proof-
        show " False "
        proof-
          have cases: "r1 <XXREAL-0R3 r2 or r2 <XXREAL-0R3 r1"
            using A17 xxreal_0_th_1 sorry
          have case1: "r1 <XXREAL-0R3 r2 implies  False "
          proof(rule impI)
            assume "r1 <XXREAL-0R3 r2"
            thus " False "
              using A3 A16 A19 A18 sorry
          qed
          have case2: "r2 <XXREAL-0R3 r1 implies  False "
          proof(rule impI)
            assume "r2 <XXREAL-0R3 r1"
            thus " False "
              using A3 A16 A19 A18 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " False "
         sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
      using partfun1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_38:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10 & f be one-to-oneFUNCT-1V2"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10 & f be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule impI,rule impMI ,rule impI,rule conjMI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A2: " for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
    have A3: " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A4: "r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A6: "r1 <XXREAL-0R3 r2"
      let ?rx = "maxXXREAL-0K5(r1,r2)"
      let ?rn = "minXXREAL-0K4(r1,r2)"
      have A7: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A7 sorry
      then have A8: "r2 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A5 xboole_0_def_4 sorry
      then have A9: "r2 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A8 xboole_0_def_4 sorry
      have A10: " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ implies diffFDIFF-1K1(f,g1) <XXREAL-0R3 0NUMBERSK6"
        using A2 sorry
      have "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 sorry
      then have A11: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[) be decreasingVALUED-0V10"
        using A10 rolle_th_10 sorry
      have A12: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A12 sorry
      then have A13: "r1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A13 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <XXREAL-0R3 f .FUNCT-1K1 r1"
        using A6 A11 A9 rfunct_2_th_21 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10"
      using rfunct_2_th_21 sorry
    have "( ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2) & r1 <>HIDDENR2 r2) implies  False "
    proof(rule impI)
      assume Given: " ex r1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex r2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ((r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2) & r1 <>HIDDENR2 r2"
      then obtain r1 r2 where
        [ty]:"r1 be ElementSUBSET-1M1-of REALNUMBERSK2" "r2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A14: "r1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A15: "r2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A16: "f .FUNCT-1K1 r1 =COMPLEX1R1 f .FUNCT-1K1 r2"and A17: "r1 <>HIDDENR2 r2"
         sorry
      have A18: "r2 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A15 xboole_0_def_4 sorry
      have A19: "r1 inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A14 xboole_0_def_4 sorry
      have " False "
      proof-
        show " False "
        proof-
          have cases: "r1 <XXREAL-0R3 r2 or r2 <XXREAL-0R3 r1"
            using A17 xxreal_0_th_1 sorry
          have case1: "r1 <XXREAL-0R3 r2 implies  False "
          proof(rule impI)
            assume "r1 <XXREAL-0R3 r2"
            thus " False "
              using A3 A16 A19 A18 sorry
          qed
          have case2: "r2 <XXREAL-0R3 r1 implies  False "
          proof(rule impI)
            assume "r2 <XXREAL-0R3 r1"
            thus " False "
              using A3 A16 A19 A18 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " False "
         sorry
    qed
    thus "f be one-to-oneFUNCT-1V2"
      using partfun1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_39:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-decreasingVALUED-0V11"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-decreasingVALUED-0V11)"
  proof(rule ballI,rule impI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A2: " for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,x0)"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rx = "maxXXREAL-0K5(r1,r2)"
      let ?rn = "minXXREAL-0K4(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ implies 0NUMBERSK6 <=XXREAL-0R1 diffFDIFF-1K1(f,g1)"
        using A2 sorry
      have "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[) be non-decreasingVALUED-0V11"
        using A9 rolle_th_11 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r1 <=XXREAL-0R1 f .FUNCT-1K1 r2"
        using A5 A10 A8 rfunct_2_th_22 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-decreasingVALUED-0V11"
      using rfunct_2_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_40:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-increasingVALUED-0V12"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-increasingVALUED-0V12)"
  proof(rule ballI,rule impI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A1: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A2: " for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <=XXREAL-0R1 0NUMBERSK6"
    have " for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r1 <XXREAL-0R3 r2) implies f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix r1 assume [ty]: "r1 be RealXREAL-0M1"
      fix r2 assume [ty]: "r2 be RealXREAL-0M1"
      assume A3: "r1 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A4: "r2 inHIDDENR3 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A5: "r1 <XXREAL-0R3 r2"
      let ?rx = "maxXXREAL-0K5(r1,r2)"
      let ?rn = "minXXREAL-0K4(r1,r2)"
      have A6: "r2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r2 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r2 inHIDDENR3 {g2 where g2 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g2 & g2 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A6 sorry
      then have A7: "r2 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A4 xboole_0_def_4 sorry
      then have A8: "r2 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 xboole_0_def_4 sorry
      have A9: " for g1 be RealXREAL-0M1 holds g1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[ implies diffFDIFF-1K1(f,g1) <=XXREAL-0R1 0NUMBERSK6"
        using A2 sorry
      have "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using A1 fdiff_1_th_26 sorry
      then have A10: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[) be non-increasingVALUED-0V12"
        using A9 rolle_th_12 sorry
      have A11: "r1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_8 xxreal_0_th_25 sorry
      have "?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 r1 -XCMPLX-0K6 0NUMBERSK6"
        using xreal_1_th_15 xxreal_0_th_17 sorry
      then have "r1 inHIDDENR3 {g1 where g1 be RealXREAL-0M1 : ?rn -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 g1 & g1 <XXREAL-0R3 ?rx +XCMPLX-0K2 \<one>\<^sub>M }"
        using A11 sorry
      then have A12: "r1 inHIDDENR3 ].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .["
        using rcomp_1_def_2 sorry
      have "r1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_0_def_4 sorry
      then have "r1 inHIDDENR3 (].RCOMP-1K2 ?rn -XCMPLX-0K6 \<one>\<^sub>M,?rx +XCMPLX-0K2 \<one>\<^sub>M .[)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A12 xboole_0_def_4 sorry
      thus "f .FUNCT-1K1 r2 <=XXREAL-0R1 f .FUNCT-1K1 r1"
        using A5 A10 A8 rfunct_2_th_23 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be non-increasingVALUED-0V12"
      using rfunct_2_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_41:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .["
      and A3: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be continuousFCONT-1V1"
      using A2 fdiff_1_th_25 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
    proof-
      show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
      proof-
        have cases: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
          using A3 sorry
        have case1: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9"
            using A2 rolle_th_9 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_23 sorry
        qed
        have case2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10"
            using A2 rolle_th_10 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_23 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)) be openRCOMP-1V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_42:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?L = "left-open-halflineLIMFUNC1K1 p"
    assume A1: "?L c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f is-differentiable-onFDIFF-1R2 ?L"
      and A3: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?L implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?L implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?L be continuousFCONT-1V1"
      using A2 fdiff_1_th_25 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
    proof-
      show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
      proof-
        have cases: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
          using A3 sorry
        have case1: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be increasingVALUED-0V9"
            using A2 fdiff_2_th_29 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_24 sorry
        qed
        have case2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be decreasingVALUED-0V10"
            using A2 fdiff_2_th_30 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_24 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)) be openRCOMP-1V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_43:
" for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
proof-
  have " for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3)"
  proof(rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?l = "right-open-halflineLIMFUNC1K4 p"
    assume A1: "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f is-differentiable-onFDIFF-1R2 ?l"
      and A3: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be continuousFCONT-1V1"
      using A2 fdiff_1_th_25 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
    proof-
      show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
      proof-
        have cases: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
          using A3 sorry
        have case1: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be increasingVALUED-0V9"
            using A2 fdiff_2_th_33 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_25 sorry
        qed
        have case2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be decreasingVALUED-0V10"
            using A2 fdiff_2_th_34 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
            using A1 A4 fcont_3_th_25 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)) be openRCOMP-1V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3)"
  proof(rule ballI,rule impI,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A3: "( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be continuousFCONT-1V1"
      using A2 fdiff_1_th_25 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
    proof-
      show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
      proof-
        have cases: "( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
          using A3 sorry
        have case1: "( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9"
            using A2 fdiff_2_th_37 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
            using A1 A4 fcont_3_th_26 sorry
        qed
        have case2: "( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
        proof(rule impI)
          assume " for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10"
            using A2 fdiff_2_th_38 sorry
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
            using A1 A4 fcont_3_th_26 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_45:
" for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ([#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f be one-to-oneFUNCT-1V2 & f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
proof-
  have " for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds [#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2 & (( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6))) implies f be one-to-oneFUNCT-1V2 & (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))))"
  proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A1: "f is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      and A2: "( for x0 be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be openRCOMP-1V3"
      using A1 A2 fdiff_2_th_44 sorry
    show "f be one-to-oneFUNCT-1V2"
       sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using funct_1_th_33 sorry
    have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using funct_1_th_33 sorry
    have A6: " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
    proof(rule ballI,rule impI)
      fix y0 assume [ty]: "y0 be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A7: "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      then obtain x0 where
        [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A8: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A9: "y0 =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A4 partfun1_th_3 sorry
      have A10: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
      proof-
        have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
        proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
          obtain fy where 
            [ty]:"fy be ElementSUBSET-1M1-of REALNUMBERSK2" and fyDef:"fy = f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            using xreal_0_def_1 sorry
          let ?a = "seq-constSEQ-1K1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
          fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
          fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
          assume A11: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0}"
            and A12: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          have A13: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 y0"
            using A11 fdiff_2_th_4 sorry
          obtain a where 
            [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
             sorry
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 Lamb2)"
          have A14: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,r)"
          proof-
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                using valued_0_th_28 sorry
              then obtain g where
                [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                "g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A15: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 g"
                using A4 A12 partfun1_th_3 sorry
              obtain r where 
                [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = g -REAL-1K5 x0"
                 sorry
              show " ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
              proof(rule bexI[of _ "r"],rule ballI,rule ballI,rule impMI ,rule impI)
                fix r1 assume [ty]: "r1 be RealXREAL-0M1"
                fix r2 assume [ty]: "r2 be RealXREAL-0M1"
                assume A16: "r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  and A17: "r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 x0)"
                  using A9 seq_1_th_57 sorry
                also have "... = x0"
                  using A8 funct_1_th_34 sorry
                finally have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x0"
                   sorry
                thus "r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
                  using A15 A16 A17 sorry
              qed "sorry"
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain b where
            [ty]:"b be Real-SequenceSEQ-1M1" and 
            A18: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using funct_2_sch_3 A14 sorry
          have A19: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 x0"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_28 sorry
            thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 x0"
              using A9 A11 tarski_def_1 sorry
          qed "sorry"
          have "( ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
          proof(rule impI)
            assume Given: " ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A20: "b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
               sorry
            have A21: "n inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            have A22: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 c .FUNCT-1K1 n"
              using seq_1_th_7 sorry
            also have "... = h .FUNCT-1K1 n +XCMPLX-0K2 f .FUNCT-1K1 x0"
              using A19 A21 sorry
            finally have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 f .FUNCT-1K1 x0"
               sorry
            have "f .FUNCT-1K1 (a .FUNCT-1K1 n +XCMPLX-0K2 b .FUNCT-1K1 n) =HIDDENR1 f .FUNCT-1K1 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 x0))"
              using A9 A20 seq_1_th_57 sorry
            also have "... = f .FUNCT-1K1 x0"
              using A8 funct_1_th_34 sorry
            finally have "f .FUNCT-1K1 (a .FUNCT-1K1 n +XCMPLX-0K2 b .FUNCT-1K1 n) =HIDDENR1 f .FUNCT-1K1 x0"
               sorry
            then have "h .FUNCT-1K1 n +XCMPLX-0K2 f .FUNCT-1K1 x0 =COMPLEX1R1 f .FUNCT-1K1 x0"
              using A18 A22 A21 sorry
            thus " False "
              using seq_1_th_5 sorry
          qed
          then have A23: "b be non-zeroORDINAL1V9"
            using seq_1_th_5 sorry
          have A24: "[#]SUBSET-1K2 REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 REALNUMBERSK2"
             sorry
          then have A25: "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
            using partfun1_def_2 sorry
          have A26: "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
            using A4 A7 relat_1_th_69 sorry
          have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be increasingVALUED-0V9 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> [#]SUBSET-1K2 REALNUMBERSK2 be decreasingVALUED-0V10"
            using A1 A2 fdiff_2_th_37 fdiff_2_th_38 sorry
          then have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
            using A25 fcont_3_th_22 sorry
          then have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-continuous-inFCONT-1R1 y0"
            using A4 A26 fcont_1_def_2 sorry
          then have A27: "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 y0"
            using relat_1_th_68 sorry
          have A28: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A29: "b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2"
               sorry
            have "((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using rfunct_2_th_1 sorry
            also have "... = f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A12 funct_2_th_108 sorry
            also have "... = f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A18 sorry
            also have "... = (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A24 A29 funct_1_th_34 sorry
            also have "... = b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
            finally show "((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          have A30: "(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
            using A12 A13 A27 fcont_1_def_1 sorry
          then have "(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be convergentSEQ-2V5"
             sorry
          then have A31: "b be convergentSEQ-2V5"
            using A28 funct_2_th_63 sorry
          have A32: "limSEQ-2K1 a =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using seq_4_th_26 sorry
          also have "... = f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            using seq_1_th_57 sorry
          finally have "limSEQ-2K1 a =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
             sorry
          have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 =COMPLEX1R1 limSEQ-2K1 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
            using A12 A13 A27 fcont_1_def_1 sorry
          then have "limSEQ-2K1 ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 -XCMPLX-0K6 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            using A30 A32 seq_2_th_12 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally have "limSEQ-2K1 ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 0NUMBERSK6"
             sorry
          then have A33: "limSEQ-2K1 b =COMPLEX1R1 0NUMBERSK6"
            using A28 funct_2_th_63 sorry
          have A34: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A24 sorry
          have 
            [ty]:"b be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
            using A23 A31 A33 fdiff_1_def_1 sorry
          have A35: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
            using seq_1_th_33 sorry
          have A36: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
          proof-
            have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } & {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
            proof(rule conjMI)
              show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                  then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    using funct_2_th_113 sorry
                  then have "x =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                    using seq_1_th_57 sorry
                  thus "x inHIDDENR3 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    using tarski_def_1 sorry
                qed "sorry"
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                then have "x =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                  using tarski_def_1 sorry
                then have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 x"
                  using seq_1_th_57 sorry
                thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                  using valued_0_th_28 sorry
              qed "sorry"
              thus "{TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                using tarski_def_3 sorry
            qed
            thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
              using xboole_0_def_10 sorry
          qed
          have A37: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
              then have "x =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                using A36 tarski_def_1 sorry
              thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A5 A7 funct_1_def_3 sorry
            qed "sorry"
            thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using tarski_def_3 sorry
          qed
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_28 sorry
            then have A38: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
              using A11 tarski_def_1 sorry
            have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A37 funct_2_th_108 sorry
            also have "... = f .FUNCT-1K1 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using seq_1_th_57 sorry
            also have "... = c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A4 A7 A38 funct_1_th_35 sorry
            finally show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          then have A39: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
             sorry
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A18 sorry
            then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using seq_1_th_7 sorry
            then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A39 sorry
            also have "... = f .FUNCT-1K1 ((b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using seq_1_th_7 sorry
            also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A34 funct_2_th_108 sorry
            also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using rfunct_2_th_1 sorry
            finally show "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          then have A40: "h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a"
             sorry
          then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be non-zeroORDINAL1V9"
             sorry
          then have A41: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be non-zeroORDINAL1V9"
            using A35 seq_1_th_35 sorry
          have A42: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using A7 A11 tarski_def_1 sorry
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A43: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [#]SUBSET-1K2 REALNUMBERSK2"
               sorry
            have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
              using valued_0_th_28 sorry
            then have A44: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
              using A11 tarski_def_1 sorry
            have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using seq_1_th_8 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using rfunct_2_th_1 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A12 funct_2_th_108 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A18 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A24 A43 funct_1_th_34 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
              using A42 funct_2_th_108 sorry
            also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A44 seq_1_th_57 sorry
            also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using seq_1_th_8 sorry
            also have "... = (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A40 seq_1_th_36 sorry
            finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          then have A45: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
             sorry
          have A46: "f is-differentiable-inFDIFF-1R1 fy"
            using A1 fdiff_1_th_9 sorry
          then have A47: "limSEQ-2K1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)) =COMPLEX1R1 diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
            using A36 A34 fdiff_2_th_12 sorry
          have "diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0) =COMPLEX1R1 diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
             sorry
          then have A48: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be convergentSEQ-2V5"
            using A36 A34 A46 fdiff_2_th_12 sorry
          have A49: "0NUMBERSK6 <>HIDDENR2 diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
            using A2 sorry
          thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
            using A45 A41 A48 A47 seq_2_th_21 sorry
          have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))\<inverse>XCMPLX-0K5"
            using A45 A41 A48 A47 A49 seq_2_th_22 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
            using xcmplx_1_th_215 sorry
          finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " ex N be NeighbourhoodRCOMP-1M1-of y0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using A3 A4 A7 rcomp_1_th_18 sorry
      thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
        using A10 fdiff_2_th_12 sorry
    qed "sorry"
    then have " for y0 be RealXREAL-0M1 holds y0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0"
       sorry
    thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A3 A4 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    thus "diffFDIFF-1K1(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_46:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds left-open-halflineLIMFUNC1K1 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 left-open-halflineLIMFUNC1K1 p & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 left-open-halflineLIMFUNC1K1 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be one-to-oneFUNCT-1V2 & ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?l = "left-open-halflineLIMFUNC1K1 p"
    assume "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A1: "f is-differentiable-onFDIFF-1R2 ?l"
      and A2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be openRCOMP-1V3"
      using A1 A2 fdiff_2_th_42 sorry
    let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p) be one-to-oneFUNCT-1V2"
       sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A6: " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
    proof-
      have " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
      proof(rule ballI,rule impI)
        fix y0 assume [ty]: "y0 be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A7: "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        then obtain x0 where
          [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A8: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A9: "y0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
          using A4 partfun1_th_3 sorry
        have A10: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
        proof-
          have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
            have A11: "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A1 sorry
            have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be increasingVALUED-0V9 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be decreasingVALUED-0V10"
              using A1 A2 fdiff_2_th_29 fdiff_2_th_30 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be continuousFCONT-1V1"
              using A11 fcont_3_th_18 sorry
            then have A12: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 be continuousFCONT-1V1"
              using relat_1_th_115 sorry
            have "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1)"
              using A4 A7 relat_1_th_69 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 is-continuous-inFCONT-1R1 y0"
              using A12 fcont_1_def_2 sorry
            then have A13: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 y0"
              using A4 relat_1_th_68 sorry
            obtain fy where 
              [ty]:"fy be ElementSUBSET-1M1-of REALNUMBERSK2" and fyDef:"fy = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using xreal_0_def_1 sorry
            let ?a = "seq-constSEQ-1K1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
            fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
            assume A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0}"
              and A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have A16: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 y0"
              using A14 fdiff_2_th_4 sorry
            obtain a where 
              [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
               sorry
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 implies (r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 Lamb2) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l)"
            have A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,r)"
            proof-
              have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)))"
              proof(rule ballI)
                fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then obtain g where
                  [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                  A18: "g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A19: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?f1 .FUNCT-1K1 g"
                  using A4 A15 partfun1_th_3 sorry
                obtain r where 
                  [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = g -REAL-1K5 x0"
                   sorry
                show " ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)))"
                proof(rule bexI[of _ "r"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
                  fix r1 assume [ty]: "r1 be RealXREAL-0M1"
                  fix r2 assume [ty]: "r2 be RealXREAL-0M1"
                  assume A20: "r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    and A21: "r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  have A22: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                    using A9 seq_1_th_57 sorry
                  also have "... = x0"
                    using A8 funct_1_th_34 sorry
                  finally have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x0"
                     sorry
                  thus "r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
                    using A18 A19 A20 A21 funct_1_th_47 sorry
                  have "g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                    using A18 relat_1_th_61 sorry
                  thus "r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))"
                    using A18 A22 A21 xboole_0_def_4 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain b where
              [ty]:"b be Real-SequenceSEQ-1M1" and 
              A23: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using funct_2_sch_3 A17 sorry
            have A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A25: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A26: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A15 funct_2_th_108 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 A25 funct_1_th_47 sorry
              also have "... = (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A26 funct_1_th_34 sorry
              also have "... = b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              finally show "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            have A27: "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be convergentSEQ-2V5"
               sorry
            then have A28: "b be convergentSEQ-2V5"
              using A24 funct_2_th_63 sorry
            have A29: "limSEQ-2K1 a =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
              using seq_4_th_26 sorry
            also have "... = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using seq_1_th_57 sorry
            finally have "limSEQ-2K1 a =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
               sorry
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 =COMPLEX1R1 limSEQ-2K1 (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 -XCMPLX-0K6 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A27 A29 seq_2_th_12 sorry
            also have "... = 0NUMBERSK6"
               sorry
            finally have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 0NUMBERSK6"
               sorry
            then have A30: "limSEQ-2K1 b =COMPLEX1R1 0NUMBERSK6"
              using A24 funct_2_th_63 sorry
            have A31: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A32: "x =HIDDENR1 (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using funct_2_th_113 sorry
                have A33: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                   sorry
                have "x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using A32 seq_1_th_7 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A23 A33 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
              using A5 A7 funct_1_def_3 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
              using relat_1_th_61 sorry
            then have A34: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 ?l"
              using xboole_0_def_4 sorry
            then have A35: "f is-differentiable-inFDIFF-1R1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A1 fdiff_1_th_9 sorry
            have A36: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)).FUNCT-1K1 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)).FUNCT-1K1 x0"
                using A9 A14 tarski_def_1 sorry
            qed "sorry"
            have A37: "0NUMBERSK6 <>HIDDENR2 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A2 A34 sorry
            have "( ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A38: "b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                 sorry
              have A39: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "a .FUNCT-1K1 n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                using A9 seq_1_th_57 sorry
              also have "... = x0"
                using A8 funct_1_th_34 sorry
              finally have "a .FUNCT-1K1 n =HIDDENR1 x0"
                 sorry
              then have A40: "f .FUNCT-1K1 (a .FUNCT-1K1 n +XCMPLX-0K2 b .FUNCT-1K1 n) =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A8 A38 funct_1_th_47 sorry
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 c .FUNCT-1K1 n"
                using seq_1_th_7 sorry
              also have "... = h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                using A36 A39 sorry
              finally have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                 sorry
              then have "h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A23 A40 A39 sorry
              thus " False "
                using seq_1_th_5 sorry
            qed
            then have "b be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
            then have 
              [ty]:"b be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
              using A28 A30 fdiff_1_def_1 sorry
            have A41: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
              using seq_1_th_33 sorry
            have A42: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
            proof-
              have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
              proof-
                have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } & {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                proof(rule conjMI)
                  show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                        using funct_2_th_113 sorry
                      then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                        using seq_1_th_57 sorry
                      thus "x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                        using tarski_def_1 sorry
                    qed "sorry"
                    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                      using tarski_def_3 sorry
                  qed
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                      using tarski_def_1 sorry
                    then have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 x"
                      using seq_1_th_57 sorry
                    thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      using valued_0_th_28 sorry
                  qed "sorry"
                  thus "{TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                    using tarski_def_3 sorry
                qed
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A43: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                  using A42 tarski_def_1 sorry
                then have "x =HIDDENR1 x0"
                  using A8 A9 funct_1_th_34 sorry
                then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                  using A8 relat_1_th_61 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using xboole_0_def_4 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A44: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                using A7 funct_1_def_3 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A45: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A43 funct_2_th_108 sorry
              also have "... = f .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using seq_1_th_57 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using A5 A44 funct_1_th_47 sorry
              also have "... = c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A4 A7 A45 funct_1_th_35 sorry
              finally show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A46: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
               sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using seq_1_th_7 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A46 sorry
              also have "... = f .FUNCT-1K1 ((b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A31 funct_2_th_108 sorry
              also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              finally show "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A47: "h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a"
               sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be non-zeroORDINAL1V9"
               sorry
            then have A48: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be non-zeroORDINAL1V9"
              using A41 seq_1_th_35 sorry
            have A49: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using A7 A14 tarski_def_1 sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A50: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A51: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A52: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using rfunct_2_th_1 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A15 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 A50 funct_1_th_47 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A51 funct_1_th_34 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                using A49 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A52 seq_1_th_57 sorry
              also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A47 seq_1_th_36 sorry
              finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A53: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
               sorry
            have "diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
               sorry
            then have A54: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be convergentSEQ-2V5"
              using A42 A31 A35 fdiff_2_th_12 sorry
            have A55: "limSEQ-2K1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A42 A31 A35 fdiff_2_th_12 sorry
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A53 A48 A54 A37 seq_2_th_21 sorry
            have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))\<inverse>XCMPLX-0K5"
              using A53 A48 A54 A55 A37 seq_2_th_22 sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
              using xcmplx_1_th_215 sorry
            finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex N be NeighbourhoodRCOMP-1M1-of y0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A3 A4 A7 rcomp_1_th_18 sorry
        thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          using A10 fdiff_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for y0 be RealXREAL-0M1 holds y0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0"
       sorry
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A3 A4 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    thus "diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (left-open-halflineLIMFUNC1K1 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_47:
" for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
proof-
  have " for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds right-open-halflineLIMFUNC1K4 p c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 p & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 right-open-halflineLIMFUNC1K4 p implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be one-to-oneFUNCT-1V2 & ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?l = "right-open-halflineLIMFUNC1K4 p"
    assume "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A1: "f is-differentiable-onFDIFF-1R2 ?l"
      and A2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be openRCOMP-1V3"
      using A1 A2 fdiff_2_th_43 sorry
    let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p) be one-to-oneFUNCT-1V2"
       sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A6: " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
    proof-
      have " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
      proof(rule ballI,rule impI)
        fix y0 assume [ty]: "y0 be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A7: "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        then obtain x0 where
          [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A8: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A9: "y0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
          using A4 partfun1_th_3 sorry
        have A10: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
        proof-
          have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
            have A11: "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A1 sorry
            have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be increasingVALUED-0V9 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be decreasingVALUED-0V10"
              using A1 A2 fdiff_2_th_33 fdiff_2_th_34 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be continuousFCONT-1V1"
              using A11 fcont_3_th_19 sorry
            then have A12: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 be continuousFCONT-1V1"
              using relat_1_th_115 sorry
            have "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1)"
              using A4 A7 relat_1_th_69 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 is-continuous-inFCONT-1R1 y0"
              using A12 fcont_1_def_2 sorry
            then have A13: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 y0"
              using A4 relat_1_th_68 sorry
            obtain fy where 
              [ty]:"fy be ElementSUBSET-1M1-of REALNUMBERSK2" and fyDef:"fy = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using xreal_0_def_1 sorry
            let ?a = "seq-constSEQ-1K1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
            fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
            assume A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0}"
              and A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have A16: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 y0"
              using A14 fdiff_2_th_4 sorry
            obtain a where 
              [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
               sorry
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 implies (r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 Lamb2) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l)"
            have A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,r)"
            proof-
              have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)))"
              proof(rule ballI)
                fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then obtain g where
                  [ty]:"g be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                  A18: "g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A19: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?f1 .FUNCT-1K1 g"
                  using A4 A15 partfun1_th_3 sorry
                obtain r where 
                  [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = g -REAL-1K5 x0"
                   sorry
                show " ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)))"
                proof(rule bexI[of _ "r"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
                  fix r1 assume [ty]: "r1 be RealXREAL-0M1"
                  fix r2 assume [ty]: "r2 be RealXREAL-0M1"
                  assume A20: "r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    and A21: "r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  have A22: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                    using A9 seq_1_th_57 sorry
                  also have "... = x0"
                    using A8 funct_1_th_34 sorry
                  finally have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x0"
                     sorry
                  thus "r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
                    using A18 A19 A20 A21 funct_1_th_47 sorry
                  have "g inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                    using A18 relat_1_th_61 sorry
                  thus "r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))"
                    using A18 A22 A21 xboole_0_def_4 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain b where
              [ty]:"b be Real-SequenceSEQ-1M1" and 
              A23: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using funct_2_sch_3 A17 sorry
            have A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A25: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A26: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A15 funct_2_th_108 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 A25 funct_1_th_47 sorry
              also have "... = (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A26 funct_1_th_34 sorry
              also have "... = b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              finally show "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            have A27: "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be convergentSEQ-2V5"
               sorry
            then have A28: "b be convergentSEQ-2V5"
              using A24 funct_2_th_63 sorry
            have A29: "limSEQ-2K1 a =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
              using seq_4_th_26 sorry
            also have "... = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using seq_1_th_57 sorry
            finally have "limSEQ-2K1 a =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
               sorry
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 =COMPLEX1R1 limSEQ-2K1 (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 -XCMPLX-0K6 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A27 A29 seq_2_th_12 sorry
            also have "... = 0NUMBERSK6"
               sorry
            finally have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 0NUMBERSK6"
               sorry
            then have A30: "limSEQ-2K1 b =COMPLEX1R1 0NUMBERSK6"
              using A24 funct_2_th_63 sorry
            have A31: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A32: "x =HIDDENR1 (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using funct_2_th_113 sorry
                have A33: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                   sorry
                have "x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using A32 seq_1_th_7 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A23 A33 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
              using A5 A7 funct_1_def_3 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
              using relat_1_th_61 sorry
            then have A34: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 ?l"
              using xboole_0_def_4 sorry
            then have A35: "f is-differentiable-inFDIFF-1R1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A1 fdiff_1_th_9 sorry
            have A36: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)).FUNCT-1K1 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)).FUNCT-1K1 x0"
                using A9 A14 tarski_def_1 sorry
            qed "sorry"
            have A37: "0NUMBERSK6 <>HIDDENR2 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A2 A34 sorry
            have "( ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A38: "b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                 sorry
              have A39: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "a .FUNCT-1K1 n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                using A9 seq_1_th_57 sorry
              also have "... = x0"
                using A8 funct_1_th_34 sorry
              finally have "a .FUNCT-1K1 n =HIDDENR1 x0"
                 sorry
              then have A40: "f .FUNCT-1K1 (a .FUNCT-1K1 n +XCMPLX-0K2 b .FUNCT-1K1 n) =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A8 A38 funct_1_th_47 sorry
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 c .FUNCT-1K1 n"
                using seq_1_th_7 sorry
              also have "... = h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                using A36 A39 sorry
              finally have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                 sorry
              then have "h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A23 A40 A39 sorry
              thus " False "
                using seq_1_th_5 sorry
            qed
            then have "b be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
            then have 
              [ty]:"b be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
              using A28 A30 fdiff_1_def_1 sorry
            have A41: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
              using seq_1_th_33 sorry
            have A42: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
            proof-
              have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
              proof-
                have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } & {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                proof(rule conjMI)
                  show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                        using funct_2_th_113 sorry
                      then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                        using seq_1_th_57 sorry
                      thus "x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                        using tarski_def_1 sorry
                    qed "sorry"
                    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                      using tarski_def_3 sorry
                  qed
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                      using tarski_def_1 sorry
                    then have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 x"
                      using seq_1_th_57 sorry
                    thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      using valued_0_th_28 sorry
                  qed "sorry"
                  thus "{TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                    using tarski_def_3 sorry
                qed
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A43: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                  using A42 tarski_def_1 sorry
                then have "x =HIDDENR1 x0"
                  using A8 A9 funct_1_th_34 sorry
                then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                  using A8 relat_1_th_61 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using xboole_0_def_4 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A44: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                using A7 funct_1_def_3 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A45: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A43 funct_2_th_108 sorry
              also have "... = f .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using seq_1_th_57 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using A5 A44 funct_1_th_47 sorry
              also have "... = c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A4 A7 A45 funct_1_th_35 sorry
              finally show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A46: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
               sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using seq_1_th_7 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A46 sorry
              also have "... = f .FUNCT-1K1 ((b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A31 funct_2_th_108 sorry
              also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              finally show "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A47: "h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a"
               sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be non-zeroORDINAL1V9"
               sorry
            then have A48: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be non-zeroORDINAL1V9"
              using A41 seq_1_th_35 sorry
            have A49: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using A7 A14 tarski_def_1 sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A50: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A51: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A52: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using rfunct_2_th_1 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A15 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 A50 funct_1_th_47 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A51 funct_1_th_34 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                using A49 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A52 seq_1_th_57 sorry
              also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A47 seq_1_th_36 sorry
              finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A53: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
               sorry
            have "diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
               sorry
            then have A54: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be convergentSEQ-2V5"
              using A42 A31 A35 fdiff_2_th_12 sorry
            have A55: "limSEQ-2K1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A42 A31 A35 fdiff_2_th_12 sorry
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A53 A48 A54 A37 seq_2_th_21 sorry
            have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))\<inverse>XCMPLX-0K5"
              using A53 A48 A54 A55 A37 seq_2_th_22 sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
              using xcmplx_1_th_215 sorry
            finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex N be NeighbourhoodRCOMP-1M1-of y0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A3 A4 A7 rcomp_1_th_18 sorry
        thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          using A10 fdiff_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for y0 be RealXREAL-0M1 holds y0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0"
       sorry
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A3 A4 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    thus "diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (right-open-halflineLIMFUNC1K4 p))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_48:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[) & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be one-to-oneFUNCT-1V2 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0)))"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ].RCOMP-1K2 p,g .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 p,g .[ & (( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be one-to-oneFUNCT-1V2 & ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule ballI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?l = "].RCOMP-1K2 p,g .["
    assume "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A1: "f is-differentiable-onFDIFF-1R2 ?l"
      and A2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
    have A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be openRCOMP-1V3"
      using A1 A2 fdiff_2_th_41 sorry
    let ?f1 = "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be one-to-oneFUNCT-1V2"
       sorry
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
      using funct_1_th_33 sorry
    have A6: " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
    proof-
      have " for y0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
      proof(rule ballI,rule impI)
        fix y0 assume [ty]: "y0 be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A7: "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        then obtain x0 where
          [ty]:"x0 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A8: "x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A9: "y0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
          using A4 partfun1_th_3 sorry
        have A10: " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
        proof-
          have " for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5 & limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
            have A11: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be increasingVALUED-0V9 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l be decreasingVALUED-0V10"
            proof-
              have " not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
              proof-
                show " not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
                proof-
                  have cases: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) or ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6)"
                    using A2 sorry
                  have case1: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)) implies  not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
                  proof(rule impI)
                    assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(f,x0)"
                    thus " not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
                      using A1 rolle_th_9 sorry
                  qed
                  have case2: "( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ].RCOMP-1K2 p,g .[ implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6) implies  not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
                  proof(rule impI)
                    assume " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 ?l implies diffFDIFF-1K1(f,x0) <XXREAL-0R3 0NUMBERSK6"
                    thus " not ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be increasingVALUED-0V9 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[) be decreasingVALUED-0V10)"
                      using A1 rolle_th_10 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ?thesis "
                 sorry
            qed
            have "?l c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A1 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l) be continuousFCONT-1V1"
              using A11 fcont_3_th_17 sorry
            then have A12: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 be continuousFCONT-1V1"
              using relat_1_th_115 sorry
            have "y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1)"
              using A4 A7 relat_1_th_69 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f1 is-continuous-inFCONT-1R1 y0"
              using A12 fcont_1_def_2 sorry
            then have A13: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 y0"
              using A4 relat_1_th_68 sorry
            obtain fy where 
              [ty]:"fy be ElementSUBSET-1M1-of REALNUMBERSK2" and fyDef:"fy = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using xreal_0_def_1 sorry
            let ?a = "seq-constSEQ-1K1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
            fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
            fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
            assume A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 y0}"
              and A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            have A16: "limSEQ-2K1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =COMPLEX1R1 y0"
              using A14 fdiff_2_th_4 sorry
            obtain a where 
              [ty]:"a be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1" and aDef:"a = ?a"
               sorry
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 implies (r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 Lamb2) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & r2 +XCMPLX-0K2 Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?l)"
            have A17: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,r)"
            proof-
              have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)))"
              proof(rule ballI)
                fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
                  using valued_0_th_28 sorry
                then obtain g1 where
                  [ty]:"g1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                  A18: "g1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"and A19: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?f1 .FUNCT-1K1 g1"
                  using A4 A15 partfun1_th_3 sorry
                obtain r where 
                  [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = g1 -REAL-1K5 x0"
                   sorry
                show " ex r be ElementSUBSET-1M1-of REALNUMBERSK2 st  for r1 be RealXREAL-0M1 holds  for r2 be RealXREAL-0M1 holds r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n & r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n implies r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r) & (r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)))"
                proof(rule bexI[of _ "r"],rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
                  fix r1 assume [ty]: "r1 be RealXREAL-0M1"
                  fix r2 assume [ty]: "r2 be RealXREAL-0M1"
                  assume A20: "r1 =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                    and A21: "r2 =COMPLEX1R1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  have A22: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                    using A9 seq_1_th_57 sorry
                  also have "... = x0"
                    using A8 funct_1_th_34 sorry
                  finally have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 x0"
                     sorry
                  thus "r1 =COMPLEX1R1 f .FUNCT-1K1 (r2 +XCMPLX-0K2 r)"
                    using A18 A19 A20 A21 funct_1_th_47 sorry
                  have "g1 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                    using A18 relat_1_th_61 sorry
                  thus "r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & r2 +XCMPLX-0K2 r inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))"
                    using A18 A22 A21 xboole_0_def_4 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain b where
              [ty]:"b be Real-SequenceSEQ-1M1" and 
              A23: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using funct_2_sch_3 A17 sorry
            have A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A25: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A26: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A15 funct_2_th_108 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A23 A25 funct_1_th_47 sorry
              also have "... = (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A26 funct_1_th_34 sorry
              also have "... = b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              finally show "(((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            have A27: "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "(?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be convergentSEQ-2V5"
               sorry
            then have A28: "b be convergentSEQ-2V5"
              using A24 funct_2_th_63 sorry
            have A29: "limSEQ-2K1 a =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
              using seq_4_th_26 sorry
            also have "... = ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using seq_1_th_57 sorry
            finally have "limSEQ-2K1 a =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
               sorry
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 =COMPLEX1R1 limSEQ-2K1 (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
              using A15 A16 A13 fcont_1_def_1 sorry
            then have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 -XCMPLX-0K6 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A27 A29 seq_2_th_12 sorry
            also have "... = 0NUMBERSK6"
               sorry
            finally have "limSEQ-2K1 ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) =HIDDENR1 0NUMBERSK6"
               sorry
            then have A30: "limSEQ-2K1 b =COMPLEX1R1 0NUMBERSK6"
              using A24 funct_2_th_63 sorry
            have A31: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)"
                then obtain n where
                  [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A32: "x =HIDDENR1 (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using funct_2_th_113 sorry
                have A33: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                   sorry
                have "x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using A32 seq_1_th_7 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using A23 A33 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
              using A5 A7 funct_1_def_3 sorry
            then have "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
              using relat_1_th_61 sorry
            then have A34: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 ?l"
              using xboole_0_def_4 sorry
            then have A35: "f is-differentiable-inFDIFF-1R1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
              using A1 fdiff_1_th_9 sorry
            have A36: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              thus "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 x0"
                using A9 A14 tarski_def_1 sorry
            qed "sorry"
            have A37: "0NUMBERSK6 <>HIDDENR2 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A2 A34 sorry
            have "( ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6) implies  False "
            proof(rule impI)
              assume Given: " ex n be NatNAT-1M1 st b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A38: "b .FUNCT-1K1 n =COMPLEX1R1 0NUMBERSK6"
                 sorry
              have A39: "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have "a .FUNCT-1K1 n =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (?f1 .FUNCT-1K1 x0)"
                using A9 seq_1_th_57 sorry
              also have "... = x0"
                using A8 funct_1_th_34 sorry
              finally have "a .FUNCT-1K1 n =HIDDENR1 x0"
                 sorry
              then have A40: "f .FUNCT-1K1 (a .FUNCT-1K1 n +XCMPLX-0K2 b .FUNCT-1K1 n) =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A8 A38 funct_1_th_47 sorry
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 c .FUNCT-1K1 n"
                using seq_1_th_7 sorry
              also have "... = h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                using A36 A39 sorry
              finally have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-1K1 n =HIDDENR1 h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0"
                 sorry
              then have "h .FUNCT-1K1 n +XCMPLX-0K2 ?f1 .FUNCT-1K1 x0 =COMPLEX1R1 ?f1 .FUNCT-1K1 x0"
                using A23 A40 A39 sorry
              thus " False "
                using seq_1_th_5 sorry
            qed
            then have "b be non-zeroORDINAL1V9"
              using seq_1_th_5 sorry
            then have 
              [ty]:"b be 0NUMBERSK6 -convergentFDIFF-1V1\<bar>non-zeroORDINAL1V9\<bar>Real-SequenceSEQ-1M1"
              using A28 A30 fdiff_1_def_1 sorry
            have A41: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be non-zeroORDINAL1V9"
              using seq_1_th_33 sorry
            have A42: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
            proof-
              have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
              proof-
                have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } & {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                proof(rule conjMI)
                  show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  proof-
                    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    proof(rule ballI,rule impI)
                      fix x assume [ty]: "x be objectHIDDENM1"
                      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                        using funct_2_th_113 sorry
                      then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                        using seq_1_th_57 sorry
                      thus "x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                        using tarski_def_1 sorry
                    qed "sorry"
                    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                      using tarski_def_3 sorry
                  qed
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 {TARSKIK1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                    then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                      using tarski_def_1 sorry
                    then have "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 x"
                      using seq_1_th_57 sorry
                    thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                      using valued_0_th_28 sorry
                  qed "sorry"
                  thus "{TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 } c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                    using tarski_def_3 sorry
                qed
                thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a =XBOOLE-0R4 {TARSKIK1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 }"
                  using xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A43: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a"
                then have "x =HIDDENR1 ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0"
                  using A42 tarski_def_1 sorry
                then have "x =HIDDENR1 x0"
                  using A8 A9 funct_1_th_34 sorry
                then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?l"
                  using A8 relat_1_th_61 sorry
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  using xboole_0_def_4 sorry
              qed "sorry"
              thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> a c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using tarski_def_3 sorry
            qed
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A44: "?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
                using A7 funct_1_def_3 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A45: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A43 funct_2_th_108 sorry
              also have "... = f .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using seq_1_th_57 sorry
              also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
                using A5 A44 funct_1_th_47 sorry
              also have "... = c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A4 A7 A45 funct_1_th_35 sorry
              finally show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A46: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> c"
               sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using seq_1_th_7 sorry
              then have "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f .FUNCT-1K1 (b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A46 sorry
              also have "... = f .FUNCT-1K1 ((b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_7 sorry
              also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A31 funct_2_th_108 sorry
              also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using rfunct_2_th_1 sorry
              finally show "h .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A47: "h =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a"
               sorry
            then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a be non-zeroORDINAL1V9"
               sorry
            then have A48: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be non-zeroORDINAL1V9"
              using A41 seq_1_th_35 sorry
            have A49: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
              using A7 A14 tarski_def_1 sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A50: "(h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
              then have A51: "a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f1"
                using A23 sorry
              have "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c"
                using valued_0_th_28 sorry
              then have A52: "c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 y0"
                using A14 tarski_def_1 sorry
              have "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using rfunct_2_th_1 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A15 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (f .FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[)).FUNCT-1K1 (a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)) -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A23 A50 funct_1_th_47 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A51 funct_1_th_34 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 (c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
                using A49 funct_2_th_108 sorry
              also have "... = h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n *REAL-1K4 ((a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 b .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)-REAL-1K5 a .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A52 seq_1_th_57 sorry
              also have "... = (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using seq_1_th_8 sorry
              also have "... = (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A47 seq_1_th_36 sorry
              finally show "(h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A53: "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a))\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
               sorry
            have "diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
               sorry
            then have A54: "b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) be convergentSEQ-2V5"
              using A42 A31 A35 fdiff_2_th_12 sorry
            have A55: "limSEQ-2K1 (b \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (b +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a)) =COMPLEX1R1 diffFDIFF-1K1(f,?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0)"
              using A42 A31 A35 fdiff_2_th_12 sorry
            thus "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) be convergentSEQ-2V5"
              using A53 A48 A54 A37 seq_2_th_21 sorry
            have "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))\<inverse>XCMPLX-0K5"
              using A53 A48 A54 A55 A37 seq_2_th_22 sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
              using xcmplx_1_th_215 sorry
            finally show "limSEQ-2K1 (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have " ex N be NeighbourhoodRCOMP-1M1-of y0 st N c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using A3 A4 A7 rcomp_1_th_18 sorry
        thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0 & diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,y0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 y0))"
          using A10 fdiff_2_th_12 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for y0 be RealXREAL-0M1 holds y0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies ?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 y0"
       sorry
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A3 A4 fdiff_1_th_9 sorry
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f1 \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    thus "diffFDIFF-1K1((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x0) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (diffFDIFF-1K1(f,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 p,g .[))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x0))"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_2_th_49:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) be convergentSEQ-2V5 & limSEQ-2K1 ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))) =COMPLEX1R1 diffFDIFF-1K1(f,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies ( for h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1 holds  for c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0} & (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) be convergentSEQ-2V5 & limSEQ-2K1 ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))) =COMPLEX1R1 diffFDIFF-1K1(f,x0))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
    fix h assume [ty]: "h be non-zeroORDINAL1V9\<bar>0NUMBERSK6 -convergentFDIFF-1V1\<bar>Real-SequenceSEQ-1M1"
    fix c assume [ty]: "c be constantFUNCT-1V5\<bar>Real-SequenceSEQ-1M1"
    assume A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> c =XBOOLE-0R4 {TARSKIK1 x0}"
      and A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    let ?fm = "(-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
    have "limSEQ-2K1 (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h) =COMPLEX1R1 -XCMPLX-0K4 limSEQ-2K1 h"
      using seq_2_th_10 sorry
    then have A5: "-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h be 0NUMBERSK6 -convergentFDIFF-1V1"
       sorry
    have A6: "limSEQ-2K1 ?fm =COMPLEX1R1 diffFDIFF-1K1(f,x0)"
      using A1 A2 A4 fdiff_2_th_12 A5 sorry
    let ?fp = "h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (h +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)"
    have A7: "diffFDIFF-1K1(f,x0) =COMPLEX1R1 diffFDIFF-1K1(f,x0)"
       sorry
    then have A8: "?fm be convergentSEQ-2V5"
      using A1 A2 A4 fdiff_2_th_12 A5 sorry
    have A9: "?fp be convergentSEQ-2V5"
      using A1 A2 A3 A7 fdiff_2_th_12 sorry
    then have A10: "?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm be convergentSEQ-2V5"
      using A8 sorry
    have A11: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using seq_1_th_7 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n +REAL-1K3 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
        using rfunct_2_th_1 sorry
      also have "... = (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
      finally show "((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    have A12: "\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm) =HIDDENR1 \<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using seq_1_th_47 sorry
    also have "... = \<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
      using seq_1_th_18 sorry
    also have "... = \<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c) +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
      using seq_1_th_19 sorry
    also have "... = \<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
      using seq_1_th_16 sorry
    also have "... = (\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h \<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using seq_1_th_18 sorry
    also have "... = (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using seq_1_th_46 sorry
    also have "... = (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))))"
      using seq_1_th_30 sorry
    also have "... = (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c)))"
      using seq_1_th_30 sorry
    also have "... = (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
      using seq_1_th_30 sorry
    finally have "\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm) =HIDDENR1 (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))+VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c))"
       sorry
    have "limSEQ-2K1 ?fp =COMPLEX1R1 diffFDIFF-1K1(f,x0)"
      using A1 A2 A3 fdiff_2_th_12 sorry
    then have "limSEQ-2K1 (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(f,x0)) +XCMPLX-0K2 diffFDIFF-1K1(f,x0)"
      using A9 A8 A6 seq_2_th_6 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
    finally have "limSEQ-2K1 (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
    then have A13: "limSEQ-2K1 (\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm)) =HIDDENR1 \<two>\<^sub>M \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (diffFDIFF-1K1(f,x0)))"
      using A10 seq_2_th_8 sorry
    also have "... = diffFDIFF-1K1(f,x0)"
       sorry
    finally have "limSEQ-2K1 (\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm)) =HIDDENR1 diffFDIFF-1K1(f,x0)"
       sorry
    have "\<two>\<^sub>M \<inverse>XCMPLX-0K5 (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (?fp +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?fm) be convergentSEQ-2V5"
      using A10 sorry
    thus "(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)) be convergentSEQ-2V5 & limSEQ-2K1 ((\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> h)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (c -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h))) =COMPLEX1R1 diffFDIFF-1K1(f,x0)"
      using A13 A12 A11 funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
