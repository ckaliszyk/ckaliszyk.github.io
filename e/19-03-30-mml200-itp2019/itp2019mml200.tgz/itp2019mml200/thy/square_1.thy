theory square_1
  imports axioms xreal_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, x, y, z for "RealXREAL-0M1"
theorem square_1_sch_1:
  fixes Pp1 Qp1 
  assumes
    A1: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds Pp1(x) & Qp1(y) implies x <=XXREAL-0R1 y"
  shows " ex z be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds Pp1(x) & Qp1(y) implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
  proof-
    have " ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds Pp1(x) & Qp1(y) implies x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y"
    proof-
      let ?Y = "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Qp1(z) }"
      let ?X = "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Pp1(z) }"
      have A2: "?X c=TARSKIR1 REALNUMBERSK2"
      proof-
        have "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Pp1(z) } c=TARSKIR1 REALNUMBERSK2"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Pp1(z) } implies x inHIDDENR3 REALNUMBERSK2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?X"
            then have " ex z be ElementSUBSET-1M1-of REALNUMBERSK2 st z =HIDDENR1 x & Pp1(z)"
               sorry
            thus "x inHIDDENR3 REALNUMBERSK2"
               sorry
          qed "sorry"
          thus "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Pp1(z) } c=TARSKIR1 REALNUMBERSK2"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "?Y c=TARSKIR1 REALNUMBERSK2"
      proof-
        have "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Qp1(z) } c=TARSKIR1 REALNUMBERSK2"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Qp1(z) } implies x inHIDDENR3 REALNUMBERSK2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 ?Y"
            then have " ex z be ElementSUBSET-1M1-of REALNUMBERSK2 st z =HIDDENR1 x & Qp1(z)"
               sorry
            thus "x inHIDDENR3 REALNUMBERSK2"
               sorry
          qed "sorry"
          thus "{z where z be ElementSUBSET-1M1-of REALNUMBERSK2 : Qp1(z) } c=TARSKIR1 REALNUMBERSK2"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain X Y where 
        [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = ?X" and
        [ty]:"Y be SubsetSUBSET-1M2-of REALNUMBERSK2" and YDef:"Y = ?Y"
        using A2 sorry
      have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        assume A3: "x inHIDDENR3 X"
          and A4: "y inHIDDENR3 Y"
        have A5: " ex z be ElementSUBSET-1M1-of REALNUMBERSK2 st z =HIDDENR1 y & Qp1(z)"
          using A4 sorry
        have " ex z be ElementSUBSET-1M1-of REALNUMBERSK2 st z =HIDDENR1 x & Pp1(z)"
          using A3 sorry
        thus "x <=XXREAL-0R1 y"
          using A1 A5 sorry
      qed "sorry"
      then obtain z where
        [ty]:"z be RealXREAL-0M1" and 
        A6: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
        using axioms_th_1 sorry
      show " ex tVar1 be RealXREAL-0M1 st  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds Pp1(x) & Qp1(y) implies x <=XXREAL-0R1 tVar1 & tVar1 <=XXREAL-0R1 y"
      proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        assume A7: "Pp1(x)"
          and A8: "Qp1(y)"
        have "y be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have A9: "y inHIDDENR3 Y"
          using A8 sorry
        have "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "x inHIDDENR3 X"
          using A7 sorry
        thus "x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
          using A6 A9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem square_1_th_1:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    show "minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
    proof-
      have cases: "x <=XXREAL-0R1 y or x >XXREAL-0R4 y"
         sorry
      have case1: "x <=XXREAL-0R1 y implies minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
      proof(rule impI)
        assume A1: "x <=XXREAL-0R1 y"
        then have "minXXREAL-0K4(x,y) =HIDDENR1 x"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
          using A1 xxreal_0_def_10 sorry
      qed
      have case2: "x >XXREAL-0R4 y implies minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
      proof(rule impI)
        assume A2: "x >XXREAL-0R4 y"
        then have "minXXREAL-0K4(x,y) =HIDDENR1 y"
          using xxreal_0_def_9 sorry
        thus "minXXREAL-0K4(x,y) +XCMPLX-0K2 maxXXREAL-0K5(x,y) =HIDDENR1 x +XCMPLX-0K2 y"
          using A2 xxreal_0_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_2:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & 0NUMBERSK6 <=XXREAL-0R1 y implies maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
    and A2: "0NUMBERSK6 <=XXREAL-0R1 y"
  have "maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
  proof-
    show "maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
    proof-
      have cases: "maxXXREAL-0K5(x,y) =HIDDENR1 x or maxXXREAL-0K5(x,y) =HIDDENR1 y"
        using xxreal_0_th_16 sorry
      have case1: "maxXXREAL-0K5(x,y) =HIDDENR1 x implies maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
      proof(rule impI)
        assume A3: "maxXXREAL-0K5(x,y) =HIDDENR1 x"
        have "x +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 x +XCMPLX-0K2 y"
          using A2 xreal_1_th_7 sorry
        thus "maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
          using A3 sorry
      qed
      have case2: "maxXXREAL-0K5(x,y) =HIDDENR1 y implies maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
      proof(rule impI)
        assume A4: "maxXXREAL-0K5(x,y) =HIDDENR1 y"
        have "y +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 y +XCMPLX-0K2 x"
          using A1 xreal_1_th_7 sorry
        thus "maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
          using A4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "maxXXREAL-0K5(x,y) <=XXREAL-0R1 x +XCMPLX-0K2 y"
     sorry
qed "sorry"

mdef square_1_def_1 (" _ ^2SQUARE-1K1" [354]354 ) where
  mlet "x be ComplexXCMPLX-0M1"
"func x ^2SQUARE-1K1 \<rightarrow> numberORDINAL1M2 equals
  x *XCMPLX-0K3 x"
proof-
  (*coherence*)
    show "x *XCMPLX-0K3 x be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem square_1_cl_1:
  mlet "x be ComplexXCMPLX-0M1"
"cluster x ^2SQUARE-1K1 as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "x ^2SQUARE-1K1 be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem square_1_cl_2:
  mlet "x be RealXREAL-0M1"
"cluster x ^2SQUARE-1K1 as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "x ^2SQUARE-1K1 be realXREAL-0V1"
     sorry
qed "sorry"

abbreviation(input) SQUARE_1K2(" _ ^2SQUARE-1K2" [354]354) where
  "x ^2SQUARE-1K2 \<equiv> x ^2SQUARE-1K1"

mtheorem square_1_add_1:
  mlet "x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
"cluster x ^2SQUARE-1K1 as-term-is ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show "x ^2SQUARE-1K1 be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    using xcmplx_0_def_2 sorry
qed "sorry"

mtheorem square_1_th_3:
" for a be ComplexXCMPLX-0M1 holds a ^2SQUARE-1K1 =HIDDENR1 (-XCMPLX-0K4 a)^2SQUARE-1K1"
   sorry

mtheorem square_1_th_4:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a +XCMPLX-0K2 b)^2SQUARE-1K1 =HIDDENR1 (a ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1"
   sorry

mtheorem square_1_th_5:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a -XCMPLX-0K6 b)^2SQUARE-1K1 =HIDDENR1 (a ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1"
   sorry

mtheorem square_1_th_6:
" for a be ComplexXCMPLX-0M1 holds (a +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1 =HIDDENR1 (a ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 \<one>\<^sub>M"
   sorry

mtheorem square_1_th_7:
" for a be ComplexXCMPLX-0M1 holds (a -XCMPLX-0K6 \<one>\<^sub>M)^2SQUARE-1K1 =HIDDENR1 (a ^2SQUARE-1K1 -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 \<one>\<^sub>M"
   sorry

mtheorem square_1_th_8:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1"
   sorry

mtheorem square_1_th_9:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds (a *XCMPLX-0K3 b)^2SQUARE-1K1 =HIDDENR1 a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1"
   sorry

mtheorem square_1_th_10:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 b) =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix b assume [ty]: "b be ComplexXCMPLX-0M1"
  assume "a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
  then have "a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
     sorry
  then have "\<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 b) =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b))/XCMPLX-0K7 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b))"
    using xcmplx_1_th_91 sorry
  also have "... = (a -XCMPLX-0K6 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
     sorry
  finally show "\<one>\<^sub>M /XCMPLX-0K7 (a +XCMPLX-0K2 b) =HIDDENR1 (a -XCMPLX-0K6 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
     sorry
qed "sorry"

mtheorem square_1_th_11:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b) =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix b assume [ty]: "b be ComplexXCMPLX-0M1"
  assume "a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
  then have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b) <>HIDDENR2 0NUMBERSK6"
     sorry
  then have "a +XCMPLX-0K2 b <>HIDDENR2 0NUMBERSK6"
     sorry
  then have "\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b) =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b))/XCMPLX-0K7 ((a -XCMPLX-0K6 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b))"
    using xcmplx_1_th_91 sorry
  also have "... = (a +XCMPLX-0K2 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
     sorry
  finally show "\<one>\<^sub>M /XCMPLX-0K7 (a -XCMPLX-0K6 b) =HIDDENR1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 (a ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)"
     sorry
qed "sorry"

mtheorem square_1_th_12:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <>HIDDENR2 a implies 0NUMBERSK6 <XXREAL-0R3 a ^2SQUARE-1K1"
  using xreal_1_th_63 sorry

mtheorem square_1_th_13:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies a ^2SQUARE-1K1 <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies  not a ^2SQUARE-1K1 <XXREAL-0R3 a"
  proof(rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
    have "a *XCMPLX-0K3 a <XXREAL-0R3 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_th_68 sorry
    thus " not a ^2SQUARE-1K1 <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_14:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies a <XXREAL-0R3 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M <XXREAL-0R3 a implies  not a <XXREAL-0R3 a ^2SQUARE-1K1"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "\<one>\<^sub>M <XXREAL-0R3 a"
    then have "a *XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 a *XCMPLX-0K3 a"
      using xreal_1_th_68 sorry
    thus " not a <XXREAL-0R3 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_1:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies ( ex x be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 x & x ^2SQUARE-1K1 <XXREAL-0R3 a)"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies ( ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 &  not tVar2 ^2SQUARE-1K1 <XXREAL-0R3 a)"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    show " ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 &  not tVar2 ^2SQUARE-1K1 <XXREAL-0R3 a"
    proof-
      have cases: "\<one>\<^sub>M <=XXREAL-0R1 a or a <XXREAL-0R3 \<one>\<^sub>M"
         sorry
      have case1: "\<one>\<^sub>M <=XXREAL-0R1 a implies ( ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 &  not tVar2 ^2SQUARE-1K1 <XXREAL-0R3 a)"
      proof(rule impI)
        assume A2: "\<one>\<^sub>M <=XXREAL-0R1 a"
        obtain x where 
          [ty]:"x be RealXREAL-0M1" and xDef:"x = \<two>\<^sub>M \<inverse>XCMPLX-0K5"
           sorry
        show " ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 &  not tVar2 ^2SQUARE-1K1 <XXREAL-0R3 a"
        proof(rule bexI[of _ "x"],rule conjMI)
          show "0NUMBERSK6 <XXREAL-0R3 x"
             sorry
          show " not x ^2SQUARE-1K1 <XXREAL-0R3 a"
            using A2 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex x be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 x &  not x ^2SQUARE-1K1 <XXREAL-0R3 a)"
      proof(rule impI)
        assume A3: "a <XXREAL-0R3 \<one>\<^sub>M"
        obtain x where 
          [ty]:"x be RealXREAL-0M1" and xDef:"x = a"
           sorry
        show " ex x be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 x &  not x ^2SQUARE-1K1 <XXREAL-0R3 a"
        proof(rule bexI[of _ "x"],rule conjMI)
          show "0NUMBERSK6 <XXREAL-0R3 x"
            using A1 sorry
          show " not x ^2SQUARE-1K1 <XXREAL-0R3 a"
            using A1 A3 square_1_th_13 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_15:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y implies x ^2SQUARE-1K1 <=XXREAL-0R1 y ^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y implies x ^2SQUARE-1K1 <=XXREAL-0R1 y ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "x <=XXREAL-0R1 y"
    have A3: "x *XCMPLX-0K3 y <=XXREAL-0R1 y *XCMPLX-0K3 y"
      using A1 A2 xreal_1_th_64 sorry
    have "x *XCMPLX-0K3 x <=XXREAL-0R1 x *XCMPLX-0K3 y"
      using A1 A2 xreal_1_th_64 sorry
    thus "x ^2SQUARE-1K1 <=XXREAL-0R1 y ^2SQUARE-1K1"
      using A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_16:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 y implies x ^2SQUARE-1K1 <XXREAL-0R3 y ^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 y implies  not x ^2SQUARE-1K1 <XXREAL-0R3 y ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "x <XXREAL-0R3 y"
    have A3: "x *XCMPLX-0K3 y <XXREAL-0R3 y *XCMPLX-0K3 y"
      using A1 A2 xreal_1_th_68 sorry
    have "x *XCMPLX-0K3 x <=XXREAL-0R1 x *XCMPLX-0K3 y"
      using A1 A2 xreal_1_th_64 sorry
    thus " not x ^2SQUARE-1K1 <XXREAL-0R3 y ^2SQUARE-1K1"
      using A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_2:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & 0NUMBERSK6 <=XXREAL-0R1 y) & x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1 implies x =HIDDENR1 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & 0NUMBERSK6 <=XXREAL-0R1 y implies (x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1 implies x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 y"
    assume A3: "x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1"
    then have A4: "y <=XXREAL-0R1 x"
      using A1 square_1_th_16 sorry
    have "x <=XXREAL-0R1 y"
      using A2 A3 square_1_th_16 sorry
    thus "x =HIDDENR1 y"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef square_1_def_2 ("sqrtSQUARE-1K3  _ " [300]300 ) where
  mlet "a be RealXREAL-0M1"
"assume 0NUMBERSK6 <=XXREAL-0R1 a func sqrtSQUARE-1K3 a \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. 0NUMBERSK6 <=XXREAL-0R1 it & it ^2SQUARE-1K1 =HIDDENR1 a"
proof-
  (*existence*)
    show "0NUMBERSK6 <=XXREAL-0R1 a implies ( ex it be RealXREAL-0M1 st 0NUMBERSK6 <=XXREAL-0R1 it & it ^2SQUARE-1K1 =HIDDENR1 a)"
    proof(rule impI)
      assume Assume: "0NUMBERSK6 <=XXREAL-0R1 a"
      have A1: "0NUMBERSK6 <=XXREAL-0R1 a"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st 0NUMBERSK6 <=XXREAL-0R1 it & it ^2SQUARE-1K1 =HIDDENR1 a"
      proof-
        have " ex tVar4 be RealXREAL-0M1 st 0NUMBERSK6 <=XXREAL-0R1 tVar4 & (tVar4 ^2SQUARE-1K1 <>HIDDENR2 a implies  False )"
        proof-
          let ?Y = "\<lambda>Lamb1. 0NUMBERSK6 <=XXREAL-0R1 Lamb1 & a <=XXREAL-0R1 Lamb1 ^2SQUARE-1K1"
          let ?X = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 0NUMBERSK6 or Lamb1 ^2SQUARE-1K1 <=XXREAL-0R1 a"
          have "a <=XXREAL-0R1 a +XCMPLX-0K2 \<one>\<^sub>M"
            using xreal_1_th_29 sorry
          then have A2: "0NUMBERSK6 +XCMPLX-0K2 a <=XXREAL-0R1 (a ^2SQUARE-1K1 +XCMPLX-0K2 a)+XCMPLX-0K2 (a +XCMPLX-0K2 \<one>\<^sub>M)"
            using A1 xreal_1_th_7 sorry
          have A3: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ?X(x) & ?Y(y) implies x <=XXREAL-0R1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            fix y assume [ty]: "y be RealXREAL-0M1"
            assume A4: "?X(x)"
              and A5: "?Y(y)"
            show "x <=XXREAL-0R1 y"
            proof-
              have cases: "x <=XXREAL-0R1 0NUMBERSK6 or  not x <=XXREAL-0R1 0NUMBERSK6"
                 sorry
              have case1: "x <=XXREAL-0R1 0NUMBERSK6 implies x <=XXREAL-0R1 y"
              proof(rule impI)
                assume "x <=XXREAL-0R1 0NUMBERSK6"
                thus "x <=XXREAL-0R1 y"
                  using A5 sorry
              qed
              have case2: " not x <=XXREAL-0R1 0NUMBERSK6 implies x <=XXREAL-0R1 y"
              proof(rule impI)
                assume " not x <=XXREAL-0R1 0NUMBERSK6"
                then have "x ^2SQUARE-1K1 <=XXREAL-0R1 y ^2SQUARE-1K1"
                  using A4 A5 xxreal_0_th_2 sorry
                thus "x <=XXREAL-0R1 y"
                  using A5 square_1_th_16 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          obtain z where
            [ty]:"z be RealXREAL-0M1" and 
            A6: " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ?X(x) & ?Y(y) implies x <=XXREAL-0R1 z & z <=XXREAL-0R1 y"
            using square_1_sch_1 A3 sorry
          show " ex tVar4 be RealXREAL-0M1 st 0NUMBERSK6 <=XXREAL-0R1 tVar4 & (tVar4 ^2SQUARE-1K1 <>HIDDENR2 a implies  False )"
          proof(rule bexI[of _ "z"],rule conjMI,rule impI)
            have A7: "(a +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1 =HIDDENR1 (a ^2SQUARE-1K1 +XCMPLX-0K2 a)+XCMPLX-0K2 (a +XCMPLX-0K2 \<one>\<^sub>M)"
               sorry
            thus "0NUMBERSK6 <=XXREAL-0R1 z"
              using A1 A2 A6 sorry
            assume A8: "z ^2SQUARE-1K1 <>HIDDENR2 a"
            have " False "
            proof-
              show " False "
              proof-
                have cases: "(z <=XXREAL-0R1 0NUMBERSK6 or z ^2SQUARE-1K1 <XXREAL-0R3 a &  not z <=XXREAL-0R1 0NUMBERSK6) or a <XXREAL-0R3 z ^2SQUARE-1K1 &  not z <=XXREAL-0R1 0NUMBERSK6"
                  using A8 xxreal_0_th_1 sorry
                have case1: "z <=XXREAL-0R1 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume A9: "z <=XXREAL-0R1 0NUMBERSK6"
                  then have "z =HIDDENR1 0NUMBERSK6"
                    using A1 A7 A2 A6 sorry
                  then have " ex c be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 c & c ^2SQUARE-1K1 <XXREAL-0R3 a"
                    using A1 A8 square_1_lm_1 sorry
                  thus " False "
                    using A1 A7 A2 A6 A9 sorry
                qed
                have case2: "z ^2SQUARE-1K1 <XXREAL-0R3 a &  not z <=XXREAL-0R1 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume A10: "z ^2SQUARE-1K1 <XXREAL-0R3 a &  not z <=XXREAL-0R1 0NUMBERSK6"
                  let ?b = "a -XCMPLX-0K6 z ^2SQUARE-1K1"
                  have A11: "0NUMBERSK6 <XXREAL-0R3 ?b"
                    using A10 xreal_1_th_50 sorry
                  then obtain c where
                    [ty]:"c be RealXREAL-0M1" and 
                    A12: "0NUMBERSK6 <XXREAL-0R3 c"and A13: "c ^2SQUARE-1K1 <XXREAL-0R3 ?b /XCMPLX-0K7 \<two>\<^sub>M"
                    using square_1_lm_1 sorry
                  let ?eps = "minXXREAL-0K4(c,?b /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 z))"
                  have A14: "0NUMBERSK6 <XXREAL-0R3 ?eps"
                    using A10 A11 A12 xxreal_0_th_15 sorry
                  then have A15: "z <XXREAL-0R3 z +XCMPLX-0K2 ?eps"
                    using xreal_1_th_29 sorry
                  have "?eps *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z) <=XXREAL-0R1 (?b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z)))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z)"
                    using A10 xreal_1_th_64 xxreal_0_th_17 sorry
                  then have "?eps *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z) <=XXREAL-0R1 ((?b /XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z)"
                    using xcmplx_1_th_78 sorry
                  then have A16: "(\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps <=XXREAL-0R1 ?b /XCMPLX-0K7 \<two>\<^sub>M"
                    using A10 xcmplx_1_th_87 sorry
                  have "?eps ^2SQUARE-1K1 <=XXREAL-0R1 c ^2SQUARE-1K1"
                    using A14 square_1_th_15 xxreal_0_th_17 sorry
                  then have "?eps ^2SQUARE-1K1 <=XXREAL-0R1 ?b /XCMPLX-0K7 \<two>\<^sub>M"
                    using A13 xxreal_0_th_2 sorry
                  then have A17: "(\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps +XCMPLX-0K2 ?eps ^2SQUARE-1K1 <=XXREAL-0R1 ?b /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 ?b /XCMPLX-0K7 \<two>\<^sub>M"
                    using A16 xreal_1_th_7 sorry
                  have A18: "(z +XCMPLX-0K2 ?eps)^2SQUARE-1K1 =HIDDENR1 z ^2SQUARE-1K1 +XCMPLX-0K2 ((\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps +XCMPLX-0K2 ?eps ^2SQUARE-1K1)"
                     sorry
                  have "a =HIDDENR1 z ^2SQUARE-1K1 +XCMPLX-0K2 ?b"
                     sorry
                  then have "(z +XCMPLX-0K2 ?eps)^2SQUARE-1K1 <=XXREAL-0R1 a"
                    using A18 A17 xreal_1_th_6 sorry
                  thus " False "
                    using A1 A7 A2 A6 A15 sorry
                qed
                have case3: "a <XXREAL-0R3 z ^2SQUARE-1K1 &  not z <=XXREAL-0R1 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume A19: "a <XXREAL-0R3 z ^2SQUARE-1K1 &  not z <=XXREAL-0R1 0NUMBERSK6"
                  let ?b = "z ^2SQUARE-1K1 -XCMPLX-0K6 a"
                  let ?eps = "minXXREAL-0K4(?b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z),z)"
                  have A20: "(z -XCMPLX-0K6 ?eps)^2SQUARE-1K1 =HIDDENR1 z ^2SQUARE-1K1 -XCMPLX-0K6 ((\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps -XCMPLX-0K6 ?eps ^2SQUARE-1K1)"
                     sorry
                  have "0NUMBERSK6 <XXREAL-0R3 ?b"
                    using A19 xreal_1_th_50 sorry
                  then have "0NUMBERSK6 <XXREAL-0R3 ?eps"
                    using A19 xxreal_0_th_15 sorry
                  then have A21: "z -XCMPLX-0K6 ?eps <XXREAL-0R3 z"
                    using xreal_1_th_44 sorry
                  have "0NUMBERSK6 <=XXREAL-0R1 ?eps ^2SQUARE-1K1"
                    using xreal_1_th_63 sorry
                  then have A22: "(\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps -XCMPLX-0K6 ?eps ^2SQUARE-1K1 <=XXREAL-0R1 (\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps -XCMPLX-0K6 0NUMBERSK6"
                    using xreal_1_th_13 sorry
                  have "?eps *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z) <=XXREAL-0R1 (?b /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 z))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 z)"
                    using A19 xreal_1_th_64 xxreal_0_th_17 sorry
                  then have "(\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps <=XXREAL-0R1 ?b"
                    using A19 xcmplx_1_th_87 sorry
                  then have A23: "(\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 ?eps -XCMPLX-0K6 ?eps ^2SQUARE-1K1 <=XXREAL-0R1 ?b"
                    using A22 xxreal_0_th_2 sorry
                  have A24: "0NUMBERSK6 <=XXREAL-0R1 z -XCMPLX-0K6 ?eps"
                    using xreal_1_th_48 xxreal_0_th_17 sorry
                  have "a =HIDDENR1 z ^2SQUARE-1K1 -XCMPLX-0K6 ?b"
                     sorry
                  then have "a <=XXREAL-0R1 (z -XCMPLX-0K6 ?eps)^2SQUARE-1K1"
                    using A20 A23 xreal_1_th_13 sorry
                  thus " False "
                    using A6 A24 A21 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 case3 sorry
              qed
            qed
            thus " False "
               sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "0NUMBERSK6 <=XXREAL-0R1 a implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 it1 & it1 ^2SQUARE-1K1 =HIDDENR1 a) & (0NUMBERSK6 <=XXREAL-0R1 it2 & it2 ^2SQUARE-1K1 =HIDDENR1 a) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "0NUMBERSK6 <=XXREAL-0R1 a"
      have A1: "0NUMBERSK6 <=XXREAL-0R1 a"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 it1 & it1 ^2SQUARE-1K1 =HIDDENR1 a) & (0NUMBERSK6 <=XXREAL-0R1 it2 & it2 ^2SQUARE-1K1 =HIDDENR1 a) implies it1 =HIDDENR1 it2"
        using square_1_lm_2 sorry
    qed
qed "sorry"

mtheorem square_1_th_17:
"sqrtSQUARE-1K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
proof-
  have "sqrtSQUARE-1K3 (0NUMBERSK6)^2SQUARE-1K1 =HIDDENR1 0NUMBERSK6"
    using square_1_def_2 sorry
  thus "sqrtSQUARE-1K3 (0NUMBERSK6) =HIDDENR1 0NUMBERSK6"
     sorry
qed

mtheorem square_1_th_18:
"sqrtSQUARE-1K3 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
proof-
  have "sqrtSQUARE-1K3 \<one>\<^sub>M ^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M"
    using square_1_def_2 sorry
  thus "sqrtSQUARE-1K3 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
     sorry
qed

mlemma square_1_lm_3:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 y implies sqrtSQUARE-1K3 x <XXREAL-0R3 sqrtSQUARE-1K3 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 y implies  not sqrtSQUARE-1K3 x <XXREAL-0R3 sqrtSQUARE-1K3 y"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "x <XXREAL-0R3 y"
    have A3: "(sqrtSQUARE-1K3 y)^2SQUARE-1K1 =HIDDENR1 y"
      using A1 A2 square_1_def_2 sorry
    have A4: "(sqrtSQUARE-1K3 x)^2SQUARE-1K1 =HIDDENR1 x"
      using A1 square_1_def_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 y"
      using A1 A2 square_1_def_2 sorry
    thus " not sqrtSQUARE-1K3 x <XXREAL-0R3 sqrtSQUARE-1K3 y"
      using A2 A4 A3 square_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_19:
"\<one>\<^sub>M <XXREAL-0R3 sqrtSQUARE-1K3 \<two>\<^sub>M"
  using square_1_lm_3 square_1_th_18 sorry

mlemma square_1_lm_4:
"\<two>\<^sub>M ^2SQUARE-1K1 =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M"
   sorry

mtheorem square_1_th_20:
"sqrtSQUARE-1K3 \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M"
  using square_1_def_2 square_1_lm_4 sorry

mtheorem square_1_th_21:
"sqrtSQUARE-1K3 \<two>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M"
  using square_1_lm_3 square_1_th_20 sorry

mtheorem square_1_th_22:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies sqrtSQUARE-1K3 a ^2SQUARE-1K1 =HIDDENR1 a"
  using square_1_def_2 sorry

mtheorem square_1_th_23:
" for a be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies sqrtSQUARE-1K3 a ^2SQUARE-1K1 =HIDDENR1 -XCMPLX-0K4 a"
proof-
  have " for a be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 implies sqrtSQUARE-1K3 a ^2SQUARE-1K1 =HIDDENR1 -XCMPLX-0K4 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have A1: "a ^2SQUARE-1K1 =HIDDENR1 (-XCMPLX-0K4 a)^2SQUARE-1K1"
       sorry
    assume "a <=XXREAL-0R1 0NUMBERSK6"
    thus "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =HIDDENR1 -XCMPLX-0K4 a"
      using A1 square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_24:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & sqrtSQUARE-1K3 a =HIDDENR1 0NUMBERSK6 implies a =HIDDENR1 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  not ((0NUMBERSK6 <=XXREAL-0R1 a & sqrtSQUARE-1K3 a =HIDDENR1 0NUMBERSK6) &  not a =HIDDENR1 0NUMBERSK6)"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "0NUMBERSK6 <=XXREAL-0R1 a & sqrtSQUARE-1K3 a =HIDDENR1 0NUMBERSK6 implies a =HIDDENR1 (0NUMBERSK6)^2SQUARE-1K1"
      using square_1_def_2 sorry
    thus " not ((0NUMBERSK6 <=XXREAL-0R1 a & sqrtSQUARE-1K3 a =HIDDENR1 0NUMBERSK6) &  not a =HIDDENR1 0NUMBERSK6)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_25:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 sqrtSQUARE-1K3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not 0NUMBERSK6 <XXREAL-0R3 sqrtSQUARE-1K3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    then have "sqrtSQUARE-1K3 a <>HIDDENR2 (0NUMBERSK6)^2SQUARE-1K1"
      using square_1_def_2 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 sqrtSQUARE-1K3 a"
      using A1 square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_26:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y implies sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  not ((0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y) &  not sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    show " not ((0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y) &  not sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y)"
    proof-
      have cases: "x =HIDDENR1 y or x <>HIDDENR2 y"
         sorry
      have case1: "x =HIDDENR1 y implies  not ((0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y) &  not sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y)"
      proof(rule impI)
        assume "x =HIDDENR1 y"
        thus " not ((0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 y) &  not sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y)"
           sorry
      qed
      have case2: "x <>HIDDENR2 y implies (0NUMBERSK6 <=XXREAL-0R1 x implies (x <=XXREAL-0R1 y implies sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y))"
      proof(rule impI,rule impI,rule impI)
        assume A1: "x <>HIDDENR2 y"
        assume A2: "0NUMBERSK6 <=XXREAL-0R1 x"
        assume "x <=XXREAL-0R1 y"
        then have "x <XXREAL-0R3 y"
          using A1 xxreal_0_th_1 sorry
        thus "sqrtSQUARE-1K3 x <=XXREAL-0R1 sqrtSQUARE-1K3 y"
          using A2 square_1_lm_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_27:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <XXREAL-0R3 y implies sqrtSQUARE-1K3 x <XXREAL-0R3 sqrtSQUARE-1K3 y"
  using square_1_lm_3 sorry

mtheorem square_1_th_28:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 x & 0NUMBERSK6 <=XXREAL-0R1 y) & sqrtSQUARE-1K3 x =HIDDENR1 sqrtSQUARE-1K3 y implies x =HIDDENR1 y"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & (0NUMBERSK6 <=XXREAL-0R1 y & sqrtSQUARE-1K3 x =HIDDENR1 sqrtSQUARE-1K3 y) implies (x <>HIDDENR2 y implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 y"
      and A3: "sqrtSQUARE-1K3 x =HIDDENR1 sqrtSQUARE-1K3 y"
    assume "x <>HIDDENR2 y"
    then have "x <XXREAL-0R3 y or y <XXREAL-0R3 x"
      using xxreal_0_th_1 sorry
    thus " False "
      using A1 A2 A3 square_1_lm_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
    have A3: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 a"
      using A1 square_1_def_2 sorry
    have A4: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 b"
      using A2 square_1_def_2 sorry
    have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 a *XCMPLX-0K3 b"
      using A1 A2 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a)^2SQUARE-1K1 *XCMPLX-0K3 b"
      using A1 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a)^2SQUARE-1K1 *XCMPLX-0K3 (sqrtSQUARE-1K3 b)^2SQUARE-1K1"
      using A2 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b)^2SQUARE-1K1"
       sorry
    finally have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 (sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b)^2SQUARE-1K1"
       sorry
    then have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 (sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b)^2SQUARE-1K1"
      using A1 A2 square_1_def_2 sorry
    also have "... = sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b"
      using A3 A4 square_1_def_2 sorry
    finally show "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_30:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) =HIDDENR1 sqrtSQUARE-1K3 a /XCMPLX-0K7 sqrtSQUARE-1K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) =HIDDENR1 sqrtSQUARE-1K3 a /XCMPLX-0K7 sqrtSQUARE-1K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
    have A3: "(sqrtSQUARE-1K3 b)^2SQUARE-1K1 =HIDDENR1 b"
      using A2 square_1_def_2 sorry
    have "(sqrtSQUARE-1K3 a)^2SQUARE-1K1 =HIDDENR1 a"
      using A1 square_1_def_2 sorry
    then have A4: "(sqrtSQUARE-1K3 a /XCMPLX-0K7 sqrtSQUARE-1K3 b)^2SQUARE-1K1 =HIDDENR1 a /XCMPLX-0K7 b"
      using A3 xcmplx_1_th_76 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 b"
      using A2 square_1_def_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 a"
      using A1 square_1_def_2 sorry
    thus "sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) =HIDDENR1 sqrtSQUARE-1K3 a /XCMPLX-0K7 sqrtSQUARE-1K3 b"
      using A5 A4 square_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_31:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies (sqrtSQUARE-1K3 (a +XCMPLX-0K2 b) =HIDDENR1 0NUMBERSK6 iff a =HIDDENR1 0NUMBERSK6 & b =HIDDENR1 0NUMBERSK6)"
  using square_1_th_17 square_1_th_24 sorry

mtheorem square_1_th_32:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies sqrtSQUARE-1K3 (\<one>\<^sub>M /XCMPLX-0K7 a) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 a"
  using square_1_th_18 square_1_th_30 sorry

mtheorem square_1_th_33:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies sqrtSQUARE-1K3 a /XCMPLX-0K7 a =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies sqrtSQUARE-1K3 a /XCMPLX-0K7 a =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    then have "sqrtSQUARE-1K3 a <>HIDDENR2 (0NUMBERSK6)^2SQUARE-1K1"
      using square_1_def_2 sorry
    then have "sqrtSQUARE-1K3 a /XCMPLX-0K7 a =HIDDENR1 (sqrtSQUARE-1K3 a)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 sqrtSQUARE-1K3 a)"
      using xcmplx_1_th_91 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (sqrtSQUARE-1K3 a *XCMPLX-0K3 a)"
      using A1 square_1_def_2 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 a"
      using A1 xcmplx_1_th_91 sorry
    finally show "sqrtSQUARE-1K3 a /XCMPLX-0K7 a =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_34:
" for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 sqrtSQUARE-1K3 a =HIDDENR1 sqrtSQUARE-1K3 a"
proof-
  have " for a be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies a /XCMPLX-0K7 sqrtSQUARE-1K3 a =HIDDENR1 sqrtSQUARE-1K3 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
    then have "sqrtSQUARE-1K3 a <>HIDDENR2 (0NUMBERSK6)^2SQUARE-1K1"
      using square_1_def_2 sorry
    then have "a /XCMPLX-0K7 sqrtSQUARE-1K3 a =HIDDENR1 (a *XCMPLX-0K3 sqrtSQUARE-1K3 a)/XCMPLX-0K7 (sqrtSQUARE-1K3 a)^2SQUARE-1K1"
      using xcmplx_1_th_91 sorry
    also have "... = (sqrtSQUARE-1K3 a *XCMPLX-0K3 a)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 a)"
      using A1 square_1_def_2 sorry
    also have "... = sqrtSQUARE-1K3 a /XCMPLX-0K7 \<one>\<^sub>M"
      using A1 xcmplx_1_th_91 sorry
    also have "... = sqrtSQUARE-1K3 a"
       sorry
    finally show "a /XCMPLX-0K7 sqrtSQUARE-1K3 a =HIDDENR1 sqrtSQUARE-1K3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_35:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 a -XCMPLX-0K6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 a -XCMPLX-0K6 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
    have "(sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1"
       sorry
    also have "... = a -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1"
      using A1 square_1_def_2 sorry
    also have "... = a -XCMPLX-0K6 b"
      using A2 square_1_def_2 sorry
    finally show "(sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 a -XCMPLX-0K6 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_5:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b) & a <>HIDDENR2 b implies (sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (0NUMBERSK6 <=XXREAL-0R1 b & a <>HIDDENR2 b) implies  not (sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
      and A3: "a <>HIDDENR2 b"
    have A4: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 a"
      using A1 square_1_def_2 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 b"
      using A2 square_1_def_2 sorry
    have "sqrtSQUARE-1K3 a <>HIDDENR2 sqrtSQUARE-1K3 b"
      using A1 A2 A3 square_1_th_28 sorry
    thus " not (sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1 <>HIDDENR2 0NUMBERSK6"
      using A4 A5 square_1_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_36:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b) & a <>HIDDENR2 b implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (0NUMBERSK6 <=XXREAL-0R1 b & a <>HIDDENR2 b) implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
      and A3: "a <>HIDDENR2 b"
    have "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 ((sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 A2 A3 square_1_lm_5 square_1_th_10 sorry
    also have "... = (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      using A2 square_1_def_2 sorry
    finally show "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_37:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & b <XXREAL-0R3 a implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & b <XXREAL-0R3 a implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 b"
      and A2: "b <XXREAL-0R3 a"
    have "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 ((sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 A2 square_1_lm_5 square_1_th_10 sorry
    also have "... = (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 A2 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      using A1 square_1_def_2 sorry
    finally show "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_38:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
    show "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
    proof-
      have cases: "a <>HIDDENR2 b or a =HIDDENR1 b"
         sorry
      have case1: "a <>HIDDENR2 b implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      proof(rule impI)
        assume "a <>HIDDENR2 b"
        then have "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 ((sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
          using A1 A2 square_1_lm_5 square_1_th_11 sorry
        also have "... = (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
          using A1 square_1_def_2 sorry
        also have "... = (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
          using A2 square_1_def_2 sorry
        finally show "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
           sorry
      qed
      have case2: "a =HIDDENR1 b implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      proof(rule impI)
        assume A3: "a =HIDDENR1 b"
        then have "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
          using A3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_39:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & b <XXREAL-0R3 a implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 b & b <XXREAL-0R3 a implies \<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 b"
      and A2: "b <XXREAL-0R3 a"
    have "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 ((sqrtSQUARE-1K3 a)^2SQUARE-1K1 -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 A2 square_1_lm_5 square_1_th_11 sorry
    also have "... = (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A1 A2 square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      using A1 square_1_def_2 sorry
    finally show "\<one>\<^sub>M /XCMPLX-0K7 (sqrtSQUARE-1K3 a -XCMPLX-0K6 sqrtSQUARE-1K3 b) =HIDDENR1 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)/XCMPLX-0K7 (a -XCMPLX-0K6 b)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_40:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1 implies x =HIDDENR1 y or x =HIDDENR1 -XCMPLX-0K4 y"
proof-
  have " for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1 implies  not ( not x =HIDDENR1 y &  not x =HIDDENR1 -XCMPLX-0K4 y)"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    fix y assume [ty]: "y be ComplexXCMPLX-0M1"
    assume "x ^2SQUARE-1K1 =HIDDENR1 y ^2SQUARE-1K1"
    then have "(x -XCMPLX-0K6 y)*XCMPLX-0K3 (x +XCMPLX-0K2 y) =HIDDENR1 0NUMBERSK6"
       sorry
    then have "x -XCMPLX-0K6 y =HIDDENR1 0NUMBERSK6 or x +XCMPLX-0K2 y =HIDDENR1 0NUMBERSK6"
       sorry
    thus " not ( not x =HIDDENR1 y &  not x =HIDDENR1 -XCMPLX-0K4 y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_41:
" for x be ComplexXCMPLX-0M1 holds x ^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M implies x =HIDDENR1 \<one>\<^sub>M or x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
proof-
  have " for x be ComplexXCMPLX-0M1 holds x ^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M implies  not ( not x =HIDDENR1 \<one>\<^sub>M &  not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ComplexXCMPLX-0M1"
    assume "x ^2SQUARE-1K1 =HIDDENR1 \<one>\<^sub>M"
    then have "(x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
       sorry
    then have "x -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 or x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
       sorry
    thus " not ( not x =HIDDENR1 \<one>\<^sub>M &  not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_42:
" for x be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 \<one>\<^sub>M implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
proof-
  have " for x be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 x & x <=XXREAL-0R1 \<one>\<^sub>M implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
  proof(rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 x"
      and A2: "x <=XXREAL-0R1 \<one>\<^sub>M"
    show "x ^2SQUARE-1K1 <=XXREAL-0R1 x"
    proof-
      have cases: "0NUMBERSK6 =HIDDENR1 x or 0NUMBERSK6 <XXREAL-0R3 x"
        using A1 sorry
      have case1: "0NUMBERSK6 =HIDDENR1 x implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
      proof(rule impI)
        assume "0NUMBERSK6 =HIDDENR1 x"
        thus "x ^2SQUARE-1K1 <=XXREAL-0R1 x"
           sorry
      qed
      have case2: "0NUMBERSK6 <XXREAL-0R3 x implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
      proof(rule impI)
        assume A3: "0NUMBERSK6 <XXREAL-0R3 x"
        show "x ^2SQUARE-1K1 <=XXREAL-0R1 x"
        proof-
          have cases: "x =HIDDENR1 \<one>\<^sub>M or x <XXREAL-0R3 \<one>\<^sub>M"
            using A2 xxreal_0_th_1 sorry
          have case1: "x =HIDDENR1 \<one>\<^sub>M implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
          proof(rule impI)
            assume "x =HIDDENR1 \<one>\<^sub>M"
            thus "x ^2SQUARE-1K1 <=XXREAL-0R1 x"
               sorry
          qed
          have case2: "x <XXREAL-0R3 \<one>\<^sub>M implies x ^2SQUARE-1K1 <=XXREAL-0R1 x"
          proof(rule impI)
            assume "x <XXREAL-0R3 \<one>\<^sub>M"
            thus "x ^2SQUARE-1K1 <=XXREAL-0R1 x"
              using A3 square_1_th_13 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_43:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6 implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6 implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 0NUMBERSK6"
    then have "(x -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M) <=XXREAL-0R1 0NUMBERSK6"
       sorry
    thus "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 x & x <=XXREAL-0R1 \<one>\<^sub>M"
      using xreal_1_th_93 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem square_1_th_44:
" for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & x <XXREAL-0R3 a implies x ^2SQUARE-1K1 >XXREAL-0R4 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & x <XXREAL-0R3 a implies  not x ^2SQUARE-1K1 >XXREAL-0R4 a ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
      and A2: "x <XXREAL-0R3 a"
    have "-XCMPLX-0K4 x >XXREAL-0R4 -XCMPLX-0K4 a"
      using A2 xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 x)^2SQUARE-1K1 >XXREAL-0R4 (-XCMPLX-0K4 a)^2SQUARE-1K1"
      using A1 square_1_th_16 sorry
    thus " not x ^2SQUARE-1K1 >XXREAL-0R4 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_45:
" for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M >=XXREAL-0R2 a implies -XCMPLX-0K4 a <=XXREAL-0R1 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M >=XXREAL-0R2 a implies -XCMPLX-0K4 a <=XXREAL-0R1 a ^2SQUARE-1K1"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M >=XXREAL-0R2 a"
    then have "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) <=XXREAL-0R1 -XCMPLX-0K4 a"
      using xreal_1_th_24 sorry
    then have "-XCMPLX-0K4 a <=XXREAL-0R1 (-XCMPLX-0K4 a)^2SQUARE-1K1"
      using xreal_1_th_151 sorry
    thus "-XCMPLX-0K4 a <=XXREAL-0R1 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_46:
" for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M >XXREAL-0R4 a implies -XCMPLX-0K4 a <XXREAL-0R3 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M >XXREAL-0R4 a implies  not -XCMPLX-0K4 a <XXREAL-0R3 a ^2SQUARE-1K1"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "-XCMPLX-0K4 \<one>\<^sub>M >XXREAL-0R4 a"
    then have "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 -XCMPLX-0K4 a"
      using xreal_1_th_24 sorry
    then have "-XCMPLX-0K4 a <XXREAL-0R3 (-XCMPLX-0K4 a)^2SQUARE-1K1"
      using square_1_th_14 sorry
    thus " not -XCMPLX-0K4 a <XXREAL-0R3 a ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_47:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 & a >=XXREAL-0R2 0NUMBERSK6 implies -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 & a >=XXREAL-0R2 0NUMBERSK6 implies -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
      and A2: "a >=XXREAL-0R2 0NUMBERSK6"
    have "-XCMPLX-0K4 a >XXREAL-0R4 b or b >XXREAL-0R4 a implies  False "
    proof(rule impI)
      assume A3: "-XCMPLX-0K4 a >XXREAL-0R4 b or b >XXREAL-0R4 a"
      have "-XCMPLX-0K4 a >XXREAL-0R4 b &  False  or b >XXREAL-0R4 a & (b >XXREAL-0R4 a implies  False )"
      proof-
        show "-XCMPLX-0K4 a >XXREAL-0R4 b &  False  or b >XXREAL-0R4 a & (b >XXREAL-0R4 a implies  False )"
        proof-
          have cases: "-XCMPLX-0K4 a >XXREAL-0R4 b or b >XXREAL-0R4 a"
            using A3 sorry
          have case1: "-XCMPLX-0K4 a >XXREAL-0R4 b implies  False "
          proof(rule impI)
            assume "-XCMPLX-0K4 a >XXREAL-0R4 b"
            then have "-XCMPLX-0K4 (-XCMPLX-0K4 a) <XXREAL-0R3 -XCMPLX-0K4 b"
              using xreal_1_th_24 sorry
            then have "a ^2SQUARE-1K1 <XXREAL-0R3 (-XCMPLX-0K4 b)^2SQUARE-1K1"
              using A2 square_1_th_16 sorry
            thus " False "
              using A1 sorry
          qed
          have case2: "b >XXREAL-0R4 a implies  False "
          proof(rule impI)
            assume "b >XXREAL-0R4 a"
            thus " False "
              using A1 A2 square_1_th_16 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " False "
         sorry
    qed
    thus "-XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_48:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1 & a >=XXREAL-0R2 0NUMBERSK6 implies -XCMPLX-0K4 a <XXREAL-0R3 b & b <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1 & a >=XXREAL-0R2 0NUMBERSK6 implies  not -XCMPLX-0K4 a <XXREAL-0R3 b &  not b <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
      and A2: "a >=XXREAL-0R2 0NUMBERSK6"
    have "-XCMPLX-0K4 a >=XXREAL-0R2 b or b >=XXREAL-0R2 a implies  False "
    proof(rule impI)
      assume A3: "-XCMPLX-0K4 a >=XXREAL-0R2 b or b >=XXREAL-0R2 a"
      have "-XCMPLX-0K4 a >=XXREAL-0R2 b &  False  or b >=XXREAL-0R2 a & (b >=XXREAL-0R2 a implies  False )"
      proof-
        show "-XCMPLX-0K4 a >=XXREAL-0R2 b &  False  or b >=XXREAL-0R2 a & (b >=XXREAL-0R2 a implies  False )"
        proof-
          have cases: "-XCMPLX-0K4 a >=XXREAL-0R2 b or b >=XXREAL-0R2 a"
            using A3 sorry
          have case1: "-XCMPLX-0K4 a >=XXREAL-0R2 b implies  False "
          proof(rule impI)
            assume "-XCMPLX-0K4 a >=XXREAL-0R2 b"
            then have "-XCMPLX-0K4 (-XCMPLX-0K4 a) <=XXREAL-0R1 -XCMPLX-0K4 b"
              using xreal_1_th_24 sorry
            then have "a ^2SQUARE-1K1 <=XXREAL-0R1 (-XCMPLX-0K4 b)^2SQUARE-1K1"
              using A2 square_1_th_15 sorry
            thus " False "
              using A1 sorry
          qed
          have case2: "b >=XXREAL-0R2 a implies  False "
          proof(rule impI)
            assume "b >=XXREAL-0R2 a"
            thus " False "
              using A1 A2 square_1_th_15 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus " False "
         sorry
    qed
    thus " not -XCMPLX-0K4 a <XXREAL-0R3 b &  not b <XXREAL-0R3 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_49:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a implies b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 a <=XXREAL-0R1 b & b <=XXREAL-0R1 a implies b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 a <=XXREAL-0R1 b"
      and A2: "b <=XXREAL-0R1 a"
    show "b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
    proof-
      have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
      proof(rule impI)
        assume "b >=XXREAL-0R2 0NUMBERSK6"
        thus "b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
          using A2 square_1_th_15 sorry
      qed
      have case2: "b <XXREAL-0R3 0NUMBERSK6 implies b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
      proof(rule impI)
        assume A3: "b <XXREAL-0R3 0NUMBERSK6"
        have "-XCMPLX-0K4 (-XCMPLX-0K4 a) >=XXREAL-0R2 -XCMPLX-0K4 b"
          using A1 xreal_1_th_24 sorry
        then have "(-XCMPLX-0K4 b)^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
          using A3 square_1_th_15 sorry
        thus "b ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_50:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 a <XXREAL-0R3 b & b <XXREAL-0R3 a implies b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 a <XXREAL-0R3 b & b <XXREAL-0R3 a implies  not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 a <XXREAL-0R3 b"
      and A2: "b <XXREAL-0R3 a"
    show " not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
    proof-
      have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies  not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
      proof(rule impI)
        assume "b >=XXREAL-0R2 0NUMBERSK6"
        thus " not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
          using A2 square_1_th_16 sorry
      qed
      have case2: "b <XXREAL-0R3 0NUMBERSK6 implies  not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
      proof(rule impI)
        assume A3: "b <XXREAL-0R3 0NUMBERSK6"
        have "-XCMPLX-0K4 (-XCMPLX-0K4 a) >XXREAL-0R4 -XCMPLX-0K4 b"
          using A1 xreal_1_th_24 sorry
        then have "(-XCMPLX-0K4 b)^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
          using A3 square_1_th_16 sorry
        thus " not b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_51:
" for a be RealXREAL-0M1 holds a ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M"
    then have "a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M ^2SQUARE-1K1"
      using xreal_1_th_9 sorry
    then have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 \<one>\<^sub>M) <=XXREAL-0R1 0NUMBERSK6"
       sorry
    thus "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M"
      using xreal_1_th_93 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_52:
" for a be RealXREAL-0M1 holds a ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies  not -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a &  not a <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume "a ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
    then have "a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M ^2SQUARE-1K1"
      using xreal_1_th_9 sorry
    then have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 0NUMBERSK6"
       sorry
    thus " not -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a &  not a <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_94 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b) & b <=XXREAL-0R1 \<one>\<^sub>M implies a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & (a <=XXREAL-0R1 \<one>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b & b <=XXREAL-0R1 \<one>\<^sub>M)) implies a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b"
      and A4: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have A5: "0NUMBERSK6 <=XXREAL-0R1 b ^2SQUARE-1K1"
      using xreal_1_th_63 sorry
    have "a ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1"
      using A1 A2 square_1_th_49 sorry
    then have A6: "a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1"
      using A5 xreal_1_th_64 sorry
    have "b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M ^2SQUARE-1K1"
      using A3 A4 square_1_th_49 sorry
    thus "a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M"
      using A6 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 b =HIDDENR1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 b =HIDDENR1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
    have "sqrtSQUARE-1K3 a ^2SQUARE-1K1 =HIDDENR1 a"
      using A1 square_1_def_2 sorry
    thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 b =HIDDENR1 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)"
      using A1 A2 square_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b) & b <=XXREAL-0R1 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & (a <=XXREAL-0R1 \<one>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b & b <=XXREAL-0R1 \<one>\<^sub>M)) implies (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b"
      and A4: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have "a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A2 A3 A4 square_1_th_53 sorry
    then have "\<one>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1"
      using xreal_1_th_7 sorry
    thus "(\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b) & b <=XXREAL-0R1 \<one>\<^sub>M implies (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) & -XCMPLX-0K4 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & (a <=XXREAL-0R1 \<one>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b & b <=XXREAL-0R1 \<one>\<^sub>M)) implies (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) & -XCMPLX-0K4 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b"
      and A4: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have A5: "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A6: "\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_7 sorry
    have "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A7: "sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
      using square_1_def_2 sorry
    have A8: "sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
      using A5 square_1_def_2 sorry
    have A9: "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
    proof-
      show "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
      proof-
        have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
        proof(rule impI)
          assume "b >=XXREAL-0R2 0NUMBERSK6"
          thus "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
            using A8 A7 sorry
        qed
        have case2: "b <XXREAL-0R3 0NUMBERSK6 implies (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
        proof(rule impI)
          assume A10: "b <XXREAL-0R3 0NUMBERSK6"
          have A11: "(-XCMPLX-0K4 b)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
            using xreal_1_th_63 sorry
          have "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) =HIDDENR1 sqrtSQUARE-1K3 ((-XCMPLX-0K4 b)^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1))"
            using A5 A10 square_1_th_54 sorry
          thus "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
            using A1 A2 A3 A4 A6 A11 square_1_lm_6 square_1_th_26 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have "-XCMPLX-0K4 (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) >=XXREAL-0R2 -XCMPLX-0K4 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using xreal_1_th_24 sorry
    thus "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) & -XCMPLX-0K4 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      using A9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & a <=XXREAL-0R1 \<one>\<^sub>M) & -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b) & b <=XXREAL-0R1 \<one>\<^sub>M implies b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds -XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a & (a <=XXREAL-0R1 \<one>\<^sub>M & (-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b & b <=XXREAL-0R1 \<one>\<^sub>M)) implies b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 b"
      and A4: "b <=XXREAL-0R1 \<one>\<^sub>M"
    have A5: "-XCMPLX-0K4 \<one>\<^sub>M <=XXREAL-0R1 -XCMPLX-0K4 b"
      using A4 xreal_1_th_24 sorry
    have "-XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M) >=XXREAL-0R2 -XCMPLX-0K4 b"
      using A3 xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 (-XCMPLX-0K4 b))*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 b)^2SQUARE-1K1)"
      using A1 A2 A5 square_1_th_55 sorry
    thus "b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds b <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "b <=XXREAL-0R1 0NUMBERSK6"
      and A2: "a <=XXREAL-0R1 b"
    have A3: "(-XCMPLX-0K4 a)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) =HIDDENR1 sqrtSQUARE-1K3 ((-XCMPLX-0K4 a)^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1))"
      using A1 A2 square_1_th_54 sorry
    have "a <XXREAL-0R3 b or a =HIDDENR1 b"
      using A2 xxreal_0_th_1 sorry
    then have "b ^2SQUARE-1K1 <XXREAL-0R3 a ^2SQUARE-1K1 or a =HIDDENR1 b"
      using A1 square_1_th_44 sorry
    then have A4: "b ^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1 *XCMPLX-0K3 a ^2SQUARE-1K1 <=XXREAL-0R1 a ^2SQUARE-1K1 *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1"
      using xreal_1_th_7 sorry
    have A5: "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A6: "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "(-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) =HIDDENR1 sqrtSQUARE-1K3 ((-XCMPLX-0K4 b)^2SQUARE-1K1 *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1))"
      using A1 square_1_th_54 sorry
    then have "-XCMPLX-0K4 a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 -XCMPLX-0K4 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      using A6 A3 A4 A5 square_1_th_26 sorry
    thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      using xreal_1_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma square_1_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & a <=XXREAL-0R1 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a <=XXREAL-0R1 0NUMBERSK6"
    and A2: "a <=XXREAL-0R1 b"
  have "b <=XXREAL-0R1 0NUMBERSK6 & a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) or b >XXREAL-0R4 0NUMBERSK6 & (b >XXREAL-0R4 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1))"
  proof-
    show "b <=XXREAL-0R1 0NUMBERSK6 & a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) or b >XXREAL-0R4 0NUMBERSK6 & (b >XXREAL-0R4 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1))"
    proof-
      have cases: "b <=XXREAL-0R1 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "b <=XXREAL-0R1 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      proof(rule impI)
        assume "b <=XXREAL-0R1 0NUMBERSK6"
        thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
          using A2 square_1_lm_7 sorry
      qed
      have case2: "b >XXREAL-0R4 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      proof(rule impI)
        assume A3: "b >XXREAL-0R4 0NUMBERSK6"
        have "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_63 sorry
        then have "sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >XXREAL-0R4 0NUMBERSK6"
          using square_1_th_25 sorry
        then have A4: "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 0NUMBERSK6"
          using A1 sorry
        have "a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_63 sorry
        then have "sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1) >XXREAL-0R4 0NUMBERSK6"
          using square_1_th_25 sorry
        thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
          using A3 A4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
     sorry
qed "sorry"

mlemma square_1_lm_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & a >=XXREAL-0R2 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
    and A2: "a >=XXREAL-0R2 b"
  have "-XCMPLX-0K4 a <=XXREAL-0R1 -XCMPLX-0K4 b"
    using A2 xreal_1_th_24 sorry
  then have "(-XCMPLX-0K4 a)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 b)^2SQUARE-1K1) <=XXREAL-0R1 (-XCMPLX-0K4 b)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 a)^2SQUARE-1K1)"
    using A1 square_1_lm_8 sorry
  then have "-XCMPLX-0K4 a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) <=XXREAL-0R1 -XCMPLX-0K4 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
     sorry
  thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
    using xreal_1_th_24 sorry
qed "sorry"

mtheorem square_1_th_57:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 b implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 b"
    show "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
    proof-
      have cases: "a >=XXREAL-0R2 0NUMBERSK6 or a <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a >=XXREAL-0R2 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      proof(rule impI)
        assume "a >=XXREAL-0R2 0NUMBERSK6"
        thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
          using A1 square_1_lm_9 sorry
      qed
      have case2: "a <XXREAL-0R3 0NUMBERSK6 implies a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
      proof(rule impI)
        assume "a <XXREAL-0R3 0NUMBERSK6"
        thus "a *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b *XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 a ^2SQUARE-1K1)"
          using A1 square_1_lm_7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_58:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
    show "sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
    proof-
      have cases: "b <XXREAL-0R3 0NUMBERSK6 or b >=XXREAL-0R2 0NUMBERSK6"
         sorry
      have case1: "b <XXREAL-0R3 0NUMBERSK6 implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
      proof(rule impI)
        assume "b <XXREAL-0R3 0NUMBERSK6"
        thus "sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
          using A1 square_1_def_2 sorry
      qed
      have case2: "b >=XXREAL-0R2 0NUMBERSK6 implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
      proof(rule impI)
        assume A2: "b >=XXREAL-0R2 0NUMBERSK6"
        have A3: "b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_63 sorry
        have "a +XCMPLX-0K2 b ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 b ^2SQUARE-1K1"
          using A1 xreal_1_th_6 sorry
        then have "sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
          using A3 square_1_th_26 sorry
        thus "sqrtSQUARE-1K3 (a +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 b"
          using A2 square_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem square_1_th_59:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & 0NUMBERSK6 <=XXREAL-0R1 b implies sqrtSQUARE-1K3 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "0NUMBERSK6 <=XXREAL-0R1 b"
    have A3: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 a"
      using A1 square_1_def_2 sorry
    have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using A1 A2 square_1_def_2 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b"
      using A1 A2 square_1_th_29 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 a *XCMPLX-0K3 sqrtSQUARE-1K3 b)"
       sorry
    then have "a +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b"
      using xreal_1_th_6 sorry
    then have A4: "a +XCMPLX-0K2 b <=XXREAL-0R1 (a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b)+XCMPLX-0K2 b"
      using xreal_1_th_6 sorry
    have A5: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 b"
      using A2 square_1_def_2 sorry
    have "sqrtSQUARE-1K3 ((a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b)+XCMPLX-0K2 b) =HIDDENR1 sqrtSQUARE-1K3 (((sqrtSQUARE-1K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b)+XCMPLX-0K2 b)"
      using A1 square_1_def_2 sorry
    also have "... = sqrtSQUARE-1K3 (((sqrtSQUARE-1K3 a)^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b)+XCMPLX-0K2 (sqrtSQUARE-1K3 b)^2SQUARE-1K1)"
      using A2 square_1_def_2 sorry
    also have "... = sqrtSQUARE-1K3 (sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b)^2SQUARE-1K1"
       sorry
    also have "... = sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b"
      using A3 A5 square_1_def_2 sorry
    finally have "sqrtSQUARE-1K3 ((a +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 a)*XCMPLX-0K3 sqrtSQUARE-1K3 b)+XCMPLX-0K2 b) =HIDDENR1 sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b"
       sorry
    thus "sqrtSQUARE-1K3 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 a +XCMPLX-0K2 sqrtSQUARE-1K3 b"
      using A1 A2 A4 square_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
