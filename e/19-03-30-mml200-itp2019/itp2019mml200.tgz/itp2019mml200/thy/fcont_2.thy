theory fcont_2
  imports fcont_1 binop_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve x, X, X1, Z, Z1 for "setHIDDENM2"
reserve s, g, r, t, p, x0, x1, x2 for "RealXREAL-0M1"
reserve s1, s2, q1 for "Real-SequenceSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef fcont_2_def_1 ("uniformly-continuousFCONT-2V1" 70 ) where
"attr uniformly-continuousFCONT-2V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"..

mtheorem fcont_2_th_1:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 iff ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))) & (( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"
    proof-
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar1 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 tVar1 &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))))"
      proof(rule impI,rule ballI,rule impI)
        assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 r"
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A2: "0NUMBERSK6 <XXREAL-0R3 s"and A3: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A1 sorry
        show " ex tVar1 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar1 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 tVar1 &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
            using A2 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume A4: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            and A5: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          have A6: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 =COMPLEX1R1 f .FUNCT-1K1 x2"
            using A5 funct_1_th_47 sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x1"
            using A4 funct_1_th_47 sorry
          thus " not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
            using A3 A4 A5 A6 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A7: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 tVar2 &  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <XXREAL-0R3 r)))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A8: "0NUMBERSK6 <XXREAL-0R3 s"and A9: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
        using A7 sorry
      show " ex tVar2 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar2 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 tVar2 &  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 s"
          using A8 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume A10: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          and A11: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        have A12: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 =COMPLEX1R1 f .FUNCT-1K1 x2"
          using A11 funct_1_th_47 sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x1"
          using A10 funct_1_th_47 sorry
        thus " not ( not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s &  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
          using A9 A10 A11 A12 sorry
      qed "sorry"
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      using fcont_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_2:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      and A2: "X1 c=TARSKIR1 X"
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A3: "0NUMBERSK6 <XXREAL-0R3 s"and A4: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
        using A1 fcont_2_th_1 sorry
      show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 s"
          using A3 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume A5: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)"
          and A6: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)"
          and A7: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
        have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 c=RELSET-1R1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
          using A2 relat_1_th_75 sorry
        then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using relat_1_th_11 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A4 A5 A6 A7 sorry
      qed "sorry"
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_3:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      and A2: "X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A3: "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 xboole_1_th_108 sorry
    have "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 xboole_1_th_108 sorry
    then have "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 xboole_1_th_19 sorry
    then have A4: "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_def_1 sorry
    assume A5: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      and A6: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
    have A7: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using A6 fcont_2_th_2 xboole_1_th_17 sorry
    have A8: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using A5 fcont_2_th_2 xboole_1_th_17 sorry
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p) implies  |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have A9: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_1 sorry
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then have A10: "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_215 sorry
      then obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A11: "0NUMBERSK6 <XXREAL-0R3 s"and A12: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A8 fcont_2_th_1 sorry
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A13: "0NUMBERSK6 <XXREAL-0R3 g"and A14: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 g implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A7 A10 fcont_2_th_1 sorry
      obtain p where 
        [ty]:"p be objectHIDDENM1" and pDef:"p = minXXREAL-0K4(s,g)"
         sorry
      show " ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p) implies  |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 p"
          using A11 A13 xxreal_0_th_15 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume A15: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          and A16: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          and A17: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p"
        have A18: "x2 inHIDDENR3 X /\\XBOOLE-0K3 X1"
          using A16 relat_1_th_57 sorry
        have A19: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A16 relat_1_th_57 sorry
        then have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 xboole_0_def_4 sorry
        then have A20: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A18 relat_1_th_57 sorry
        have "p <=XXREAL-0R1 g"
          using xxreal_0_th_17 sorry
        then have A21: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 g"
          using A17 xxreal_0_th_2 sorry
        have A22: "x1 inHIDDENR3 X /\\XBOOLE-0K3 X1"
          using A15 relat_1_th_57 sorry
        have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A9 A19 xboole_0_def_4 sorry
        then have A23: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A18 relat_1_th_57 sorry
        have "p <=XXREAL-0R1 s"
          using xxreal_0_th_17 sorry
        then have A24: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
          using A17 xxreal_0_th_2 sorry
        have A25: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 relat_1_th_57 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 xboole_0_def_4 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A22 relat_1_th_57 sorry
        then have A26: " |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A14 A21 A20 sorry
        have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A9 A25 xboole_0_def_4 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A22 relat_1_th_57 sorry
        then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A12 A24 A23 sorry
        then have A27: " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A26 xreal_1_th_8 sorry
        have A28: " |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)+XCMPLX-0K2 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .|"
          using complex1_th_56 sorry
        have " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 +XCMPLX-0K2 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .|"
          using A4 A22 valued_1_def_1 sorry
        also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 +XCMPLX-0K2 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 .FUNCT-1K1 x2 +XCMPLX-0K2 f2 .FUNCT-1K1 x2) .|"
          using A4 A18 valued_1_def_1 sorry
        also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)+XCMPLX-0K2 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
           sorry
        finally have " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)+XCMPLX-0K2 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
           sorry
        thus " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A27 A28 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_4:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      and A2: "X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    have A3: "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A2 xboole_1_th_108 sorry
    have "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A1 xboole_1_th_108 sorry
    then have "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A3 xboole_1_th_19 sorry
    then have A4: "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using valued_1_th_12 sorry
    assume A5: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      and A6: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
    have A7: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using A6 fcont_2_th_2 xboole_1_th_17 sorry
    have A8: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using A5 fcont_2_th_2 xboole_1_th_17 sorry
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p) implies  |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have A9: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_th_12 sorry
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then have A10: "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using xreal_1_th_215 sorry
      then obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A11: "0NUMBERSK6 <XXREAL-0R3 s"and A12: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A8 fcont_2_th_1 sorry
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A13: "0NUMBERSK6 <XXREAL-0R3 g"and A14: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 g implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
        using A7 A10 fcont_2_th_1 sorry
      obtain p where 
        [ty]:"p be objectHIDDENM1" and pDef:"p = minXXREAL-0K4(s,g)"
         sorry
      show " ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p) implies  |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 p"
          using A11 A13 xxreal_0_th_15 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume A15: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          and A16: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          and A17: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 p"
        have A18: "x2 inHIDDENR3 X /\\XBOOLE-0K3 X1"
          using A16 relat_1_th_57 sorry
        have A19: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A16 relat_1_th_57 sorry
        then have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 xboole_0_def_4 sorry
        then have A20: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A18 relat_1_th_57 sorry
        have "p <=XXREAL-0R1 g"
          using xxreal_0_th_17 sorry
        then have A21: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 g"
          using A17 xxreal_0_th_2 sorry
        have A22: "x1 inHIDDENR3 X /\\XBOOLE-0K3 X1"
          using A15 relat_1_th_57 sorry
        have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A9 A19 xboole_0_def_4 sorry
        then have A23: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A18 relat_1_th_57 sorry
        have "p <=XXREAL-0R1 s"
          using xxreal_0_th_17 sorry
        then have A24: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
          using A17 xxreal_0_th_2 sorry
        have A25: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          using A15 relat_1_th_57 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A9 xboole_0_def_4 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A22 relat_1_th_57 sorry
        then have A26: " |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A14 A21 A20 sorry
        have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A9 A25 xboole_0_def_4 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1))"
          using A22 relat_1_th_57 sorry
        then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A12 A24 A23 sorry
        then have A27: " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
          using A26 xreal_1_th_8 sorry
        have A28: " |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)-XCMPLX-0K6 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .|"
          using complex1_th_57 sorry
        have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .|"
          using A4 A22 valued_1_th_13 sorry
        also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 .FUNCT-1K1 x2 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
          using A4 A18 valued_1_th_13 sorry
        also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)-XCMPLX-0K6 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
           sorry
        finally have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)-XCMPLX-0K6 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
           sorry
        thus " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A27 A28 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_5:
" for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    then have A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
    show "(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
    proof-
      have cases: "p =COMPLEX1R1 0NUMBERSK6 or p <>HIDDENR2 0NUMBERSK6"
         sorry
      have case1: "p =COMPLEX1R1 0NUMBERSK6 implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      proof(rule impI)
        assume A3: "p =COMPLEX1R1 0NUMBERSK6"
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume A4: "0NUMBERSK6 <XXREAL-0R3 r"
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A5: "0NUMBERSK6 <XXREAL-0R3 s"and " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
            using A2 fcont_2_th_1 sorry
          show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 s"
              using A5 sorry
            fix x1 assume [ty]: "x1 be RealXREAL-0M1"
            fix x2 assume [ty]: "x2 be RealXREAL-0M1"
            assume A6: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and A7: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
            have A8: "x2 inHIDDENR3 X"
              using A7 relat_1_th_57 sorry
            have "x1 inHIDDENR3 X"
              using A6 relat_1_th_57 sorry
            then have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .|"
              using A1 valued_1_def_5 sorry
            also have "... =  |.COMPLEX1K10 0NUMBERSK6 -XCMPLX-0K6 p *XCMPLX-0K3 f .FUNCT-1K1 x2 .|"
              using A1 A3 A8 valued_1_def_5 sorry
            also have "... = 0NUMBERSK6"
              using A3 absvalue_th_2 sorry
            finally have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1 0NUMBERSK6"
               sorry
            thus " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r"
              using A4 sorry
          qed "sorry"
        qed "sorry"
        thus "(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
          using fcont_2_th_1 sorry
      qed
      have case2: "p <>HIDDENR2 0NUMBERSK6 implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      proof(rule impI)
        assume A9: "p <>HIDDENR2 0NUMBERSK6"
        then have A10: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 p.|"
          using complex1_th_47 sorry
        have A11: "0NUMBERSK6 <>HIDDENR2  |.COMPLEX1K10 p.|"
          using A9 complex1_th_47 sorry
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then have "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 ( |.COMPLEX1K10 p.|)"
            using A10 xreal_1_th_139 sorry
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A12: "0NUMBERSK6 <XXREAL-0R3 s"and A13: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 ( |.COMPLEX1K10 p.|)"
            using A2 fcont_2_th_1 sorry
          show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 s"
              using A12 sorry
            fix x1 assume [ty]: "x1 be RealXREAL-0M1"
            fix x2 assume [ty]: "x2 be RealXREAL-0M1"
            assume A14: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and A15: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and A16: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
            have A17: "x2 inHIDDENR3 X"
              using A15 relat_1_th_57 sorry
            have A18: "x1 inHIDDENR3 X"
              using A14 relat_1_th_57 sorry
            then have A19: " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .|"
              using A1 valued_1_def_5 sorry
            also have "... =  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 p *XCMPLX-0K3 f .FUNCT-1K1 x2 .|"
              using A1 A17 valued_1_def_5 sorry
            also have "... =  |.COMPLEX1K10 p *XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2) .|"
               sorry
            also have "... = ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|)"
              using complex1_th_65 sorry
            finally have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1 ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|)"
               sorry
            have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using A15 relat_1_th_57 sorry
            then have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using valued_1_def_5 sorry
            then have A20: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using A17 relat_1_th_57 sorry
            have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using A14 relat_1_th_57 sorry
            then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using valued_1_def_5 sorry
            then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using A18 relat_1_th_57 sorry
            then have "( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|) <XXREAL-0R3 (r /XCMPLX-0K7 ( |.COMPLEX1K10 p.|))*XCMPLX-0K3 ( |.COMPLEX1K10 p.|)"
              using A10 A13 A16 A20 xreal_1_th_68 sorry
            thus " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <XXREAL-0R3 r"
              using A11 A19 xcmplx_1_th_87 sorry
          qed "sorry"
        qed "sorry"
        thus "(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
          using fcont_2_th_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_6:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  using fcont_2_th_5 sorry

mtheorem fcont_2_th_7:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A2: "0NUMBERSK6 <XXREAL-0R3 s"and A3: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
        using A1 fcont_2_th_1 sorry
      show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 s"
          using A2 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume A4: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          and A5: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          and A6: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
        have "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          using A5 relat_1_th_57 sorry
        then have A7: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using valued_1_def_11 sorry
        have "x2 inHIDDENR3 X"
          using A5 relat_1_th_57 sorry
        then have A8: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A7 relat_1_th_57 sorry
        have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .|"
          using valued_1_th_18 sorry
        also have "... =  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6  |.COMPLEX1K10 f .FUNCT-1K1 x2.| .|"
          using valued_1_th_18 sorry
        finally have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6  |.COMPLEX1K10 f .FUNCT-1K1 x2.| .|"
           sorry
        then have A9: " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|"
          using complex1_th_64 sorry
        have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          using A4 relat_1_th_57 sorry
        then have A10: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using valued_1_def_11 sorry
        have "x1 inHIDDENR3 X"
          using A4 relat_1_th_57 sorry
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A10 relat_1_th_57 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A3 A6 A8 sorry
        thus " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
          using A9 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_8:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6 implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 & (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1 & (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6)) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be uniformly-continuousFCONT-2V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix Z1 assume [ty]: "Z1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      and A2: "X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    assume A3: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      and A4: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be uniformly-continuousFCONT-2V1"
      and A5: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6"
      and A6: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6"
    obtain x1 where
      [ty]:"x1 be RealXREAL-0M1" and 
      A7: " for r be objectHIDDENM1 holds r inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies  |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1 x1"
      using A5 rfunct_1_th_73 sorry
    obtain x2 where
      [ty]:"x2 be RealXREAL-0M1" and 
      A8: " for r be objectHIDDENM1 holds r inHIDDENR3 Z1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1 x2"
      using A6 rfunct_1_th_73 sorry
    have 
      [ty]:"x1 be RealXREAL-0M1" and
      [ty]:"x2 be RealXREAL-0M1"
       sorry
    let ?M1 = " |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M"
    let ?M2 = " |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M"
    let ?M = "maxXXREAL-0K5(?M1,?M2)"
    have A9: " for r be RealXREAL-0M1 holds r inHIDDENR3 ((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1 implies  |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <XXREAL-0R3 maxXXREAL-0K5( |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M, |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M) &  |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <XXREAL-0R3 maxXXREAL-0K5( |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M, |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M)"
    proof(rule ballI,rule impI,rule conjMI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      have A10: "?M1 <=XXREAL-0R1 ?M"
        using xxreal_0_th_25 sorry
      assume "r inHIDDENR3 ((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1"
      then have A11: "r inHIDDENR3 (X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 (X1 /\\XBOOLE-0K3 Z1)"
        using xboole_1_th_16 sorry
      then have A12: "r inHIDDENR3 X /\\XBOOLE-0K3 Z"
        using xboole_0_def_4 sorry
      then have A13: "r inHIDDENR3 Z"
        using xboole_0_def_4 sorry
      have "r inHIDDENR3 X"
        using A12 xboole_0_def_4 sorry
      then have "r inHIDDENR3 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A1 A13 xboole_0_def_4 sorry
      then have A14: " |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1 x1"
        using A7 sorry
      have "x1 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?M1"
        using absvalue_th_4 xreal_1_th_8 sorry
      then have " |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <XXREAL-0R3 ?M1"
        using A14 xxreal_0_th_2 sorry
      thus " |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <XXREAL-0R3 maxXXREAL-0K5( |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M, |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M)"
        using A10 xxreal_0_th_2 sorry
      have A15: "?M2 <=XXREAL-0R1 ?M"
        using xxreal_0_th_25 sorry
      have A16: "r inHIDDENR3 X1 /\\XBOOLE-0K3 Z1"
        using A11 xboole_0_def_4 sorry
      then have A17: "r inHIDDENR3 Z1"
        using xboole_0_def_4 sorry
      have "r inHIDDENR3 X1"
        using A16 xboole_0_def_4 sorry
      then have "r inHIDDENR3 Z1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A2 A17 xboole_0_def_4 sorry
      then have A18: " |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1 x2"
        using A8 sorry
      have "x2 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 ?M2"
        using absvalue_th_4 xreal_1_th_8 sorry
      then have " |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <XXREAL-0R3 ?M2"
        using A18 xxreal_0_th_2 sorry
      thus " |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <XXREAL-0R3 maxXXREAL-0K5( |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M, |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M)"
        using A15 xxreal_0_th_2 sorry
    qed "sorry"
    have A19: "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x2.| +XCMPLX-0K2 \<one>\<^sub>M"
      using complex1_th_46 xreal_1_th_8 sorry
    have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x1.| +XCMPLX-0K2 \<one>\<^sub>M"
      using complex1_th_46 xreal_1_th_8 sorry
    then have A20: "0NUMBERSK6 <XXREAL-0R3 ?M"
      using A19 xxreal_0_th_16 sorry
    then have A21: "0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 ?M"
      using xreal_1_th_129 sorry
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof-
      have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1)) & y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1)) implies ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .| <XXREAL-0R3 p implies  not  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <XXREAL-0R3 r)))"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 r"
        then have A22: "0NUMBERSK6 <XXREAL-0R3 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)"
          using A21 xreal_1_th_139 sorry
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A23: "0NUMBERSK6 <XXREAL-0R3 s"and A24: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)"
          using A3 fcont_2_th_1 sorry
        obtain g where
          [ty]:"g be RealXREAL-0M1" and 
          A25: "0NUMBERSK6 <XXREAL-0R3 g"and A26: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 g implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <XXREAL-0R3 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)"
          using A4 A22 fcont_2_th_1 sorry
        obtain p where 
          [ty]:"p be objectHIDDENM1" and pDef:"p = minXXREAL-0K4(s,g)"
           sorry
        show " ex p be objectHIDDENM1 st 0NUMBERSK6 <XXREAL-0R3 p & ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1)) & y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1)) implies ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .| <XXREAL-0R3 p implies  not  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <XXREAL-0R3 r))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 p"
            using A23 A25 xxreal_0_th_15 sorry
          fix y1 assume [ty]: "y1 be RealXREAL-0M1"
          fix y2 assume [ty]: "y2 be RealXREAL-0M1"
          assume A27: "y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1))"
            and A28: "y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1))"
          assume A29: " |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .| <XXREAL-0R3 p"
          have A30: "y2 inHIDDENR3 ((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1"
            using A28 relat_1_th_57 sorry
          then have A31: "y2 inHIDDENR3 (X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 (X1 /\\XBOOLE-0K3 Z1)"
            using xboole_1_th_16 sorry
          then have "y2 inHIDDENR3 X /\\XBOOLE-0K3 Z"
            using xboole_0_def_4 sorry
          then have "y2 inHIDDENR3 X"
            using xboole_0_def_4 sorry
          then have A32: "y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using A1 relat_1_th_62 sorry
          have A33: "y1 inHIDDENR3 ((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1"
            using A27 relat_1_th_57 sorry
          then have A34: "y1 inHIDDENR3 (X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 (X1 /\\XBOOLE-0K3 Z1)"
            using xboole_1_th_16 sorry
          then have "y1 inHIDDENR3 X /\\XBOOLE-0K3 Z"
            using xboole_0_def_4 sorry
          then have "y1 inHIDDENR3 X"
            using xboole_0_def_4 sorry
          then have A35: "y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using A1 relat_1_th_62 sorry
          have "y2 inHIDDENR3 X1 /\\XBOOLE-0K3 Z1"
            using A31 xboole_0_def_4 sorry
          then have "y2 inHIDDENR3 X1"
            using xboole_0_def_4 sorry
          then have A36: "y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)"
            using A2 relat_1_th_62 sorry
          have "y1 inHIDDENR3 X1 /\\XBOOLE-0K3 Z1"
            using A34 xboole_0_def_4 sorry
          then have "y1 inHIDDENR3 X1"
            using xboole_0_def_4 sorry
          then have A37: "y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)"
            using A2 relat_1_th_62 sorry
          have "p <=XXREAL-0R1 g"
            using xxreal_0_th_17 sorry
          then have " |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .| <XXREAL-0R3 g"
            using A29 xxreal_0_th_2 sorry
          then have A38: " |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .| <XXREAL-0R3 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)"
            using A26 A37 A36 sorry
          have " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| =HIDDENR1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .|"
            using valued_1_th_5 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y1 +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y2 -XCMPLX-0K6 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y2))-XCMPLX-0K6 f1 .FUNCT-1K1 y2 *XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
            using valued_1_th_5 sorry
          also have "... =  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
             sorry
          finally have " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| =HIDDENR1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
             sorry
          then have A39: " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| +XCMPLX-0K2  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
            using complex1_th_56 sorry
          have A40: " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| =COMPLEX1R1 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|)"
            using complex1_th_65 sorry
          have A41: " |.COMPLEX1K10 f2 .FUNCT-1K1 y2.| <XXREAL-0R3 ?M"
            using A9 A30 sorry
          have A42: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f2 .FUNCT-1K1 y2.|"
            using complex1_th_46 sorry
          have A43: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|"
            using complex1_th_46 sorry
          have A44: " |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| =COMPLEX1R1 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y2.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|)"
            using complex1_th_65 sorry
          have "p <=XXREAL-0R1 s"
            using xxreal_0_th_17 sorry
          then have " |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .| <XXREAL-0R3 s"
            using A29 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .| <XXREAL-0R3 r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)"
            using A24 A35 A32 sorry
          then have A45: " |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| <XXREAL-0R3 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M))"
            using A44 A41 A43 A42 xreal_1_th_96 sorry
          have A46: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1.|"
            using complex1_th_46 sorry
          have A47: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|"
            using complex1_th_46 sorry
          have " |.COMPLEX1K10 f1 .FUNCT-1K1 y1.| <XXREAL-0R3 ?M"
            using A9 A33 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| <XXREAL-0R3 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M))"
            using A40 A38 A47 A46 xreal_1_th_96 sorry
          then have A48: " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| +XCMPLX-0K2  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| <XXREAL-0R3 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)) +XCMPLX-0K2 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M))"
            using A45 xreal_1_th_8 sorry
          have "?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)) +XCMPLX-0K2 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)) =HIDDENR1 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (?M *XCMPLX-0K3 \<two>\<^sub>M) +XCMPLX-0K2 r /XCMPLX-0K7 (?M *XCMPLX-0K3 \<two>\<^sub>M))"
             sorry
          also have "... = (r /XCMPLX-0K7 ?M)*XCMPLX-0K3 ?M"
            using xcmplx_1_th_118 sorry
          also have "... = r"
            using A20 xcmplx_1_th_87 sorry
          finally have "?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)) +XCMPLX-0K2 ?M *XCMPLX-0K3 (r /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 ?M)) =HIDDENR1 r"
             sorry
          thus " not  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <XXREAL-0R3 r"
            using A39 A48 xxreal_0_th_2 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_9:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
    have " for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume A3: "x0 inHIDDENR3 X"
        and A4: "0NUMBERSK6 <XXREAL-0R3 r"
      have A5: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        using A1 A3 relat_1_th_62 sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A6: "0NUMBERSK6 <XXREAL-0R3 s"and A7: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
        using A2 A4 fcont_2_th_1 sorry
      have 
        [ty]:"s be RealXREAL-0M1"
         sorry
      show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
        show "0NUMBERSK6 <XXREAL-0R3 s"
          using A6 sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        assume A8: "x1 inHIDDENR3 X"
          and A9: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
        have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A1 A8 relat_1_th_62 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          using A7 A9 A5 sorry
      qed "sorry"
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A1 fcont_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_10:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A1: "0NUMBERSK6 <XXREAL-0R3 r"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
      using fcont_1_th_32 sorry
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r))"
    proof-
      have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 p))"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A3: "0NUMBERSK6 <XXREAL-0R3 p"
        obtain s where 
          [ty]:"s be setHIDDENM2" and sDef:"s = p /XCMPLX-0K7 r"
           sorry
        show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 p)"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
            using A1 A3 xreal_1_th_139 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume A4: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            and A5: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            and A6: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s"
          have A7: "r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|) <XXREAL-0R3 s *XCMPLX-0K3 r"
            using A1 A6 xreal_1_th_68 sorry
          have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A2 A4 A5 sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 (p /XCMPLX-0K7 r)*XCMPLX-0K3 r"
            using A7 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 p"
            using A1 xcmplx_1_th_87 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
      using fcont_2_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_11:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (Y be compactRCOMP-1V1 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1) implies ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1 implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "Y be compactRCOMP-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1"
    assume " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      using fcont_2_th_1 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Y & ( ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x2 inTARSKIR2 Y &  |.COMPLEX1K10 Lamb2 -XCMPLX-0K6 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
    have A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st x1 inHIDDENR3 Y & ( ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x2 inTARSKIR2 Y &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      obtain x1 where
        [ty]:"x1 be RealXREAL-0M1" and 
        A7: " ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r"
        using A5 xreal_1_th_139 sorry
      have 
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      show " ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st x1 inHIDDENR3 Y & ( ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x2 inTARSKIR2 Y &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "x1"])
        have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 Y"
          using A1 relat_1_th_62 sorry
        thus "x1 inHIDDENR3 Y & ( ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x2 inTARSKIR2 Y &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 r)"
          using A7 sorry
      qed "sorry"
    qed "sorry"
    obtain s1 where
      [ty]:"s1 be Real-SequenceSEQ-1M1" and 
      A8: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A6 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_113 sorry
      thus "x inHIDDENR3 Y"
        using A8 sorry
    qed "sorry"
    then have A9: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 Y"
      using tarski_def_3 sorry
    then obtain q1 where
      [ty]:"q1 be Real-SequenceSEQ-1M1" and 
      A10: "q1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1"and A11: "q1 be convergentSEQ-2V5"and A12: "limSEQ-2K1 q1 inHIDDENR3 Y"
      using A2 rcomp_1_def_3 sorry
    have "limSEQ-2K1 q1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
      using A1 A12 relat_1_th_57 sorry
    then have A13: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y is-continuous-inFCONT-1R1 limSEQ-2K1 q1"
      using A3 fcont_1_def_2 sorry
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
      using A10 valued_0_th_21 sorry
    then have A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 Y"
      using A9 xboole_1_th_1 sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 xboole_1_th_1 sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Y"
      using A14 xboole_1_th_19 sorry
    then have A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
      using relat_1_th_61 sorry
    then have A16: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (limSEQ-2K1 q1) =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1"
      using A11 A13 fcont_1_def_1 sorry
    have A17: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 be convergentSEQ-2V5"
      using A11 A13 A15 fcont_1_def_1 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 inHIDDENR3 Y &  |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1 -XCMPLX-0K6 Lamb2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> Lamb1) -XCMPLX-0K6 f .FUNCT-1K1 Lamb2 .| <XXREAL-0R3 r"
    have A18: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,x2)"
      using A8 sorry
    obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A19: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A18 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 implies x inHIDDENR3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2"
      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_113 sorry
      thus "x inHIDDENR3 Y"
        using A19 sorry
    qed "sorry"
    then have A20: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 c=TARSKIR1 Y"
      using tarski_def_3 sorry
    obtain Ns1 where
      [ty]:"Ns1 be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1" and 
      A21: "q1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1"
      using A10 valued_0_def_17 sorry
    let ?q2 = "q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1"
    have A22: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (s2 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (s1 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n -REAL-1K5 ((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A21 rfunct_2_th_1 sorry
      also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n) -REAL-1K5 ((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n) -REAL-1K5 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n)"
        using funct_2_th_15 sorry
      also have "... = s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n) -REAL-1K5 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n) -REAL-1K5 s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 n))"
        using rfunct_2_th_1 sorry
      also have "... = (s2 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_15 sorry
      finally show "(q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (s2 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    then have A23: "?q2 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s2 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1"
      using funct_2_th_63 sorry
    have "?q2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s2"
      using A22 funct_2_th_63 valued_0_def_17 sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2"
      using valued_0_th_21 sorry
    then have A24: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2 c=TARSKIR1 Y"
      using A20 xboole_1_th_1 sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 xboole_1_th_1 sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Y"
      using A24 xboole_1_th_19 sorry
    then have A25: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
      using relat_1_th_61 sorry
    have A26: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p)"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A27: "0NUMBERSK6 <XXREAL-0R3 p"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A28: "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 k"
        using seq_4_th_3 sorry
      show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
      proof(rule bexI[of _ "k"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        have A29: "m inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        assume "k <=XXREAL-0R1 m"
        then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        then have A30: " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
          using A19 xxreal_0_th_2 A29 sorry
        have "k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "p \<inverse>XCMPLX-0K5 <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
          using A28 xxreal_0_th_2 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 p \<inverse>XCMPLX-0K5"
          using A27 xreal_1_th_76 sorry
        then have A31: "\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 p"
          using xcmplx_1_th_216 sorry
        have " |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| =COMPLEX1R1  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m .|"
          using rfunct_2_th_1 sorry
        thus " |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 p"
          using A31 A30 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    then have A32: "s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
    have A33: "(s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
      using valued_0_def_17 sorry
    then have A34: "(s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1 be convergentSEQ-2V5"
      using A32 seq_4_th_16 sorry
    have "limSEQ-2K1 (s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2) =COMPLEX1R1 0NUMBERSK6"
      using A26 A32 seq_2_def_7 sorry
    then have "limSEQ-2K1 ((s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2)*PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1) =COMPLEX1R1 0NUMBERSK6"
      using A32 A33 seq_4_th_17 sorry
    then have A35: "limSEQ-2K1 ?q2 =HIDDENR1 limSEQ-2K1 q1 -XCMPLX-0K6 0NUMBERSK6"
      using A11 A34 seq_2_th_12 sorry
    also have "... = limSEQ-2K1 q1"
       sorry
    finally have "limSEQ-2K1 ?q2 =HIDDENR1 limSEQ-2K1 q1"
       sorry
    have A36: "?q2 be convergentSEQ-2V5"
      using A11 A34 seq_2_th_11 sorry
    then have A37: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2 be convergentSEQ-2V5"
      using A13 A35 A25 fcont_1_def_1 sorry
    then have A38: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2 be convergentSEQ-2V5"
      using A17 seq_2_th_11 sorry
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (limSEQ-2K1 q1) =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2"
      using A13 A36 A35 A25 fcont_1_def_1 sorry
    then have A39: "limSEQ-2K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (limSEQ-2K1 q1) -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (limSEQ-2K1 q1)"
      using A17 A16 A37 seq_2_th_12 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "limSEQ-2K1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2) =HIDDENR1 0NUMBERSK6"
       sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  False "
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A40: " for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 r"
        using A4 A38 A39 seq_2_def_7 sorry
      have A41: "q1 .FUNCT-1K1 k inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1"
        using valued_0_th_28 sorry
      have A42: "?q2 .FUNCT-1K1 k inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?q2"
        using valued_0_th_28 sorry
      have A43: "k inTARSKIR2 NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have " |.COMPLEX1K10 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2).FUNCT-1K1 k -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 .FUNCT-1K1 k -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2 .FUNCT-1K1 k .|"
        using rfunct_2_th_1 sorry
      also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (q1 .FUNCT-1K1 k) -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2 .FUNCT-1K1 k .|"
        using A15 funct_2_th_108 A43 sorry
      also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (q1 .FUNCT-1K1 k) -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (?q2 .FUNCT-1K1 k) .|"
        using A25 funct_2_th_108 A43 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (q1 .FUNCT-1K1 k) -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 (?q2 .FUNCT-1K1 k) .|"
        using A15 A41 funct_1_th_47 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (q1 .FUNCT-1K1 k) -XCMPLX-0K6 f .FUNCT-1K1 (?q2 .FUNCT-1K1 k) .|"
        using A25 A42 funct_1_th_47 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 k)) -XCMPLX-0K6 f .FUNCT-1K1 ((s2 *PARTFUN1K1\<^bsub>(NATNUMBERSK1,NATNUMBERSK1,NATNUMBERSK1,REALNUMBERSK2)\<^esub> Ns1).FUNCT-1K1 k) .|"
        using A21 A23 funct_2_th_15 A43 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 k)) -XCMPLX-0K6 f .FUNCT-1K1 (s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 k)) .|"
        using funct_2_th_15 A43 sorry
      finally have " |.COMPLEX1K10 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?q2).FUNCT-1K1 k -XCMPLX-0K6 0NUMBERSK6 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 k)) -XCMPLX-0K6 f .FUNCT-1K1 (s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (Ns1 .RECDEF-1K1 k)) .|"
         sorry
      thus " False "
        using A19 A40 sorry
    qed "sorry"
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_12:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
  using fcont_2_th_9 fcont_1_th_29 sorry

mtheorem fcont_2_th_13:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be uniformly-continuousFCONT-2V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
  using fcont_2_th_9 fcont_1_th_31 sorry

mtheorem fcont_2_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be constantVALUED-0V15 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be uniformly-continuousFCONT-2V1"
  using fcont_2_th_10 sorry

mtheorem fcont_2_th_15:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] implies  not ( for s be RealXREAL-0M1 holds  not (s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "p <=XXREAL-0R1 g"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A4: "r inHIDDENR3 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .]"
    have A5: "[.RCOMP-1K1 p,g .] be compactRCOMP-1V1"
      using rcomp_1_th_6 sorry
    have A6: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)"
    proof-
      have "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g & ( for s be RealXREAL-0M1 holds s inHIDDENR3 [.RCOMP-1K1 p,g .] implies r <>HIDDENR2 f .FUNCT-1K1 s) implies  False "
      proof(rule impMI ,rule impI)
        have "r inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then obtain f1 where 
          [ty]:"f1 be FunctionFUNCT-2M1-of([.RCOMP-1K1 p,g .],REALNUMBERSK2)" and f1Def:"f1 = [.RCOMP-1K1 p,g .] -->FUNCOP-1K7 r"
          using funcop_1_th_45 sorry
        assume A7: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g"
          and A8: " for s be RealXREAL-0M1 holds s inHIDDENR3 [.RCOMP-1K1 p,g .] implies r <>HIDDENR2 f .FUNCT-1K1 s"
        have "[.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] =HIDDENR1 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/XBOOLE-0K2 {}XBOOLE-0K1"
          using A7 xxreal_1_th_29 sorry
        also have "... = [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .]"
           sorry
        finally have "[.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] =HIDDENR1 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .]"
           sorry
        then have "r inHIDDENR3 {s where s be RealXREAL-0M1 : f .FUNCT-1K1 p <=XXREAL-0R1 s & s <=XXREAL-0R1 f .FUNCT-1K1 g }"
          using A4 rcomp_1_def_1 sorry
        then have A9: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & f .FUNCT-1K1 p <=XXREAL-0R1 s) & s <=XXREAL-0R1 f .FUNCT-1K1 g"
           sorry
        have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
          using A1 xxreal_1_th_1 sorry
        then have A10: "r <>HIDDENR2 f .FUNCT-1K1 p"
          using A8 sorry
        have 
          [ty]:"f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          using relset_1_th_7 sorry
        have A11: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
          using funcop_1_th_13 sorry
        then have A12: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_1_th_19 sorry
        then have A13: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using valued_1_th_12 sorry
        have A14: "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
        proof-
          have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
          proof(rule impI)
            assume "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
            then obtain x2 where
              [ty]:"x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A15: "x2 inTARSKIR2 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
              using subset_1_th_4 sorry
            have "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using A15 funct_1_def_7 sorry
            then have A16: "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using valued_1_def_11 sorry
            then have "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using valued_1_th_12 sorry
            then have A17: "x2 inTARSKIR2 [.RCOMP-1K1 p,g .]"
              using A11 xboole_0_def_4 sorry
            have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x2 inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
              using A15 funct_1_def_7 sorry
            then have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using tarski_def_1 sorry
            then have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2.| =COMPLEX1R1 0NUMBERSK6"
              using valued_1_th_18 sorry
            then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using absvalue_th_2 sorry
            then have "f1 .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using A16 valued_1_th_13 sorry
            then have "r -XCMPLX-0K6 f .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using A17 funcop_1_th_7 sorry
            thus " False "
              using A8 A17 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A18: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
          using rfunct_1_def_2 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using A14 valued_1_def_11 sorry
        also have "... = ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A11 valued_1_th_12 sorry
        also have "... = [.RCOMP-1K1 p,g .]"
          using A2 xboole_1_th_28 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 [.RCOMP-1K1 p,g .]"
           sorry
        have 
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies f1 .FUNCT-1K1 x0 =COMPLEX1R1 r"
          using A11 funcop_1_th_7 sorry
        then have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be constantVALUED-0V15"
          using partfun2_th_57 sorry
        then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A3 A12 fcont_1_th_18 sorry
        then have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A13 fcont_1_th_21 sorry
        then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A14 fcont_1_th_22 sorry
        then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
          using A5 A18 fcont_1_th_29 rcomp_1_th_10 sorry
        then obtain M where
          [ty]:"M be RealXREAL-0M1" and 
          A19: "M be UpperBoundXXREAL-2M1-of (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
          using xxreal_2_def_10 sorry
        have A20: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) implies x1 <=XXREAL-0R1 M"
          using A19 xxreal_2_def_1 sorry
        have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
          using complex1_th_46 xreal_1_th_8 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        then have A21: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
          using xcmplx_1_th_215 sorry
        have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be uniformly-continuousFCONT-2V1"
          using A2 A3 fcont_2_th_11 rcomp_1_th_6 sorry
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A22: "0NUMBERSK6 <XXREAL-0R3 s"and A23: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
          using A21 fcont_2_th_1 sorry
        have A24: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 [.RCOMP-1K1 p,g .] implies \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
        proof(rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          assume A25: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x1 inTARSKIR2 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using A18 funct_1_def_6 sorry
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x1 <=XXREAL-0R1 M"
            using A20 sorry
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x1)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A18 A25 rfunct_1_def_2 sorry
          then have A26: "( |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1.|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using valued_1_th_18 sorry
          have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A2 A11 A25 xboole_0_def_4 sorry
          then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using valued_1_th_12 sorry
          then have "( |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A26 valued_1_th_13 sorry
          then have A27: "( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A25 funcop_1_th_7 sorry
          have "r -XCMPLX-0K6 f .FUNCT-1K1 x1 <>HIDDENR2 0NUMBERSK6"
            using A8 A25 sorry
          then have A28: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
            using complex1_th_47 sorry
          have "M +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
            using absvalue_th_4 xreal_1_th_8 sorry
          then have "( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
            using A27 xxreal_0_th_2 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5"
            using A28 xreal_1_th_76 sorry
          thus "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
            using xcmplx_1_th_216 sorry
        qed "sorry"
        have " False "
        proof-
          show " False "
          proof-
            have cases: "p =COMPLEX1R1 g or p <>HIDDENR2 g"
               sorry
            have case1: "p =COMPLEX1R1 g implies  False "
            proof(rule impI)
              assume "p =COMPLEX1R1 g"
              thus " False "
                using A7 sorry
            qed
            have case2: "p <>HIDDENR2 g implies  False "
            proof(rule impI)
              assume "p <>HIDDENR2 g"
              then have "p <XXREAL-0R3 g"
                using A1 xxreal_0_th_1 sorry
              then have A29: "0NUMBERSK6 <XXREAL-0R3 g -XCMPLX-0K6 p"
                using xreal_1_th_50 sorry
              then have A30: "0NUMBERSK6 <XXREAL-0R3 (g -XCMPLX-0K6 p)/XCMPLX-0K7 s"
                using A22 xreal_1_th_139 sorry
              obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A31: "(g -XCMPLX-0K6 p)/XCMPLX-0K7 s <XXREAL-0R3 k"
                using seq_4_th_3 sorry
              have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 s)*XCMPLX-0K3 s <XXREAL-0R3 s *XCMPLX-0K3 k"
                using A22 A31 xreal_1_th_68 sorry
              then have "g -XCMPLX-0K6 p <XXREAL-0R3 s *XCMPLX-0K3 k"
                using A22 xcmplx_1_th_87 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 (s *XCMPLX-0K3 k)/XCMPLX-0K7 k"
                using A31 A30 xreal_1_th_74 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 (s *XCMPLX-0K3 k)*XCMPLX-0K3 k \<inverse>XCMPLX-0K5"
                using xcmplx_0_def_9 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 s *XCMPLX-0K3 (k *XCMPLX-0K3 k \<inverse>XCMPLX-0K5)"
                 sorry
              then have A32: "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 s *XCMPLX-0K3 \<one>\<^sub>M"
                using A31 A30 xcmplx_0_def_7 sorry
              let ?F = "\<lambda>Lamb1. p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 Lamb1"
              obtain s1 where
                [ty]:"s1 be Real-SequenceSEQ-1M1" and 
                A33: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
                using seq_1_sch_1 sorry
              have A34: "0NUMBERSK6 <XXREAL-0R3 (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                using A29 A31 A30 xreal_1_th_139 sorry
              have A35: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k implies s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [.RCOMP-1K1 p,g .] & (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 [.RCOMP-1K1 p,g .] &  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M))"
              proof(rule ballI,rule impI,rule conjMI,rule conjMI)
                fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                have A36: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
                  using A2 relat_1_th_62 sorry
                assume A37: "n <XXREAL-0R3 k"
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <XXREAL-0R3 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                  using A34 xreal_1_th_68 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <XXREAL-0R3 g -XCMPLX-0K6 p"
                  using A31 A30 xcmplx_1_th_87 sorry
                then have "p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <XXREAL-0R3 p +XCMPLX-0K2 (g -XCMPLX-0K6 p)"
                  using xreal_1_th_6 sorry
                then have A38: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <XXREAL-0R3 p +XCMPLX-0K2 (g -XCMPLX-0K6 p)"
                  using A33 sorry
                have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                  using A37 nat_1_th_13 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                  using A29 xreal_1_th_64 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                  using A31 A30 xcmplx_1_th_87 sorry
                then have "p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p +XCMPLX-0K2 (g -XCMPLX-0K6 p)"
                  using xreal_1_th_7 sorry
                then have A39: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 p +XCMPLX-0K2 (g -XCMPLX-0K6 p)"
                  using A33 sorry
                have "p +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n"
                  using A29 xreal_1_th_7 sorry
                then have "p <=XXREAL-0R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using A33 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {x2 where x2 be RealXREAL-0M1 : p <=XXREAL-0R1 x2 & x2 <=XXREAL-0R1 g }"
                  using A38 sorry
                thus A40: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [.RCOMP-1K1 p,g .]"
                  using rcomp_1_def_1 sorry
                have "p +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A29 xreal_1_th_7 sorry
                then have "p <=XXREAL-0R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  using A33 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {x2 where x2 be RealXREAL-0M1 : p <=XXREAL-0R1 x2 & x2 <=XXREAL-0R1 g }"
                  using A39 sorry
                thus A41: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 [.RCOMP-1K1 p,g .]"
                  using rcomp_1_def_1 sorry
                have " |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| =HIDDENR1  |.COMPLEX1K10 (p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
                  using A33 sorry
                also have "... =  |.COMPLEX1K10 (p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n) .|"
                  using A33 sorry
                also have "... = (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                  using A29 absvalue_def_1 sorry
                finally have " |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| =HIDDENR1 (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                   sorry
                thus " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
                  using A23 A32 A40 A41 A36 sorry
              qed "sorry"
              let ?P = "\<lambda>Lamb1. r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-1K1 Lamb1)"
              have A42: "s1 .FUNCT-1K1 k =HIDDENR1 p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                using A33 sorry
              also have "... = p +XCMPLX-0K2 (g -XCMPLX-0K6 p)"
                using A31 A30 xcmplx_1_th_87 sorry
              also have "... = g"
                 sorry
              finally have "s1 .FUNCT-1K1 k =HIDDENR1 g"
                 sorry
              then have A43: " ex n be NatNAT-1M1 st ?P(n)"
                using A9 sorry
              obtain l where
                [ty]:"l be NatNAT-1M1" and 
                A44: "?P(l) & ( for m be NatNAT-1M1 holds ?P(m) implies l <=XXREAL-0R1 m)"
                using nat_1_sch_5 A43 sorry
              have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 p +XCMPLX-0K2 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (0NUMBERSK6)"
                using A33 sorry
              also have "... = p"
                 sorry
              finally have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 p"
                 sorry
              then have "l <>HIDDENR2 0NUMBERSK6"
                using A9 A10 A44 xxreal_0_th_1 sorry
              then obtain l1 where
                [ty]:"l1 be NatNAT-1M1" and 
                A45: "l =COMPLEX1R1 l1 +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              have 
                [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A46: "r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using A44 A45 xreal_1_th_9 sorry
              have "l1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                using A9 A42 A44 A45 sorry
              then have A47: "l1 <XXREAL-0R3 k"
                using nat_1_th_13 sorry
              then have A48: " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
                using A35 sorry
              have "f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) <XXREAL-0R3 r"
              proof-
                have "r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) implies  False "
                proof(rule impI)
                  assume "r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                  then have "l <=XXREAL-0R1 l1"
                    using A44 sorry
                  then have "l +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 l"
                    using A45 xreal_1_th_8 sorry
                  thus " False "
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then have A49: "0NUMBERSK6 <XXREAL-0R3 r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using xreal_1_th_50 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using A44 A45 xreal_1_th_9 sorry
              then have " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| =COMPLEX1R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using absvalue_def_1 sorry
              then have A50: " |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .|"
                using A49 A46 absvalue_def_1 sorry
              have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1 inTARSKIR2 [.RCOMP-1K1 p,g .]"
                using A35 A47 sorry
              thus " False "
                using A24 A50 A48 xxreal_0_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A51: "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 p implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)"
    proof-
      have "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 p & ( for s be RealXREAL-0M1 holds s inHIDDENR3 [.RCOMP-1K1 p,g .] implies r <>HIDDENR2 f .FUNCT-1K1 s) implies  False "
      proof(rule impMI ,rule impI)
        have "r inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then obtain f1 where 
          [ty]:"f1 be FunctionFUNCT-2M1-of([.RCOMP-1K1 p,g .],REALNUMBERSK2)" and f1Def:"f1 = [.RCOMP-1K1 p,g .] -->FUNCOP-1K7 r"
          using funcop_1_th_45 sorry
        assume A52: "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 p"
          and A53: " for s be RealXREAL-0M1 holds s inHIDDENR3 [.RCOMP-1K1 p,g .] implies r <>HIDDENR2 f .FUNCT-1K1 s"
        have "[.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] =HIDDENR1 {}XBOOLE-0K1 \\/XBOOLE-0K2 [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .]"
          using A52 xxreal_1_th_29 sorry
        also have "... = [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .]"
           sorry
        finally have "[.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] =HIDDENR1 [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .]"
           sorry
        then have "r inHIDDENR3 {s where s be RealXREAL-0M1 : f .FUNCT-1K1 g <=XXREAL-0R1 s & s <=XXREAL-0R1 f .FUNCT-1K1 p }"
          using A4 rcomp_1_def_1 sorry
        then have A54: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 r & f .FUNCT-1K1 g <=XXREAL-0R1 s) & s <=XXREAL-0R1 f .FUNCT-1K1 p"
           sorry
        have "g inHIDDENR3 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s & s <=XXREAL-0R1 g }"
          using A1 sorry
        then have "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
          using rcomp_1_def_1 sorry
        then have A55: "r <>HIDDENR2 f .FUNCT-1K1 g"
          using A53 sorry
        have 
          [ty]:"f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          using relset_1_th_7 sorry
        have A56: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
          using funcop_1_th_13 sorry
        then have A57: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A2 xboole_1_th_19 sorry
        then have A58: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using valued_1_th_12 sorry
        have A59: "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
        proof-
          have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
          proof(rule impI)
            assume "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } <>HIDDENR2 {}XBOOLE-0K1"
            then obtain x2 where
              [ty]:"x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
              A60: "x2 inTARSKIR2 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
              using subset_1_th_4 sorry
            have "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using A60 funct_1_def_7 sorry
            then have A61: "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              using valued_1_def_11 sorry
            then have "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using valued_1_th_12 sorry
            then have A62: "x2 inTARSKIR2 [.RCOMP-1K1 p,g .]"
              using A56 xboole_0_def_4 sorry
            have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x2 inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
              using A60 funct_1_def_7 sorry
            then have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using tarski_def_1 sorry
            then have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2.| =COMPLEX1R1 0NUMBERSK6"
              using valued_1_th_18 sorry
            then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using absvalue_th_2 sorry
            then have "f1 .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using A61 valued_1_th_13 sorry
            then have "r -XCMPLX-0K6 f .FUNCT-1K1 x2 =COMPLEX1R1 0NUMBERSK6"
              using A62 funcop_1_th_7 sorry
            thus " False "
              using A53 A62 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A63: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
          using rfunct_1_def_2 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
          using A59 valued_1_def_11 sorry
        also have "... = ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A56 valued_1_th_12 sorry
        also have "... = [.RCOMP-1K1 p,g .]"
          using A2 xboole_1_th_28 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 [.RCOMP-1K1 p,g .]"
           sorry
        have 
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have " for x0 be ElementSUBSET-1M1-of REALNUMBERSK2 holds x0 inTARSKIR2 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies f1 .FUNCT-1K1 x0 =COMPLEX1R1 r"
          using A56 funcop_1_th_7 sorry
        then have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be constantVALUED-0V15"
          using partfun2_th_57 sorry
        then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A3 A57 fcont_1_th_18 sorry
        then have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A58 fcont_1_th_21 sorry
        then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
          using A59 fcont_1_th_22 sorry
        then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
          using A5 A63 fcont_1_th_29 rcomp_1_th_10 sorry
        then obtain M where
          [ty]:"M be RealXREAL-0M1" and 
          A64: "M be UpperBoundXXREAL-2M1-of (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
          using xxreal_2_def_10 sorry
        have A65: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) implies x1 <=XXREAL-0R1 M"
          using A64 xxreal_2_def_1 sorry
        have "0NUMBERSK6 +NAT-1K1 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
          using complex1_th_46 xreal_1_th_8 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        then have A66: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
          using xcmplx_1_th_215 sorry
        have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be uniformly-continuousFCONT-2V1"
          using A2 A3 fcont_2_th_11 rcomp_1_th_6 sorry
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A67: "0NUMBERSK6 <XXREAL-0R3 s"and A68: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
          using A66 fcont_2_th_1 sorry
        have A69: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 [.RCOMP-1K1 p,g .] implies \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
        proof(rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          assume A70: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x1 inTARSKIR2 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using A63 funct_1_def_6 sorry
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x1 <=XXREAL-0R1 M"
            using A65 sorry
          then have "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) .FUNCT-1K1 x1)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A63 A70 rfunct_1_def_2 sorry
          then have A71: "( |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1.|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using valued_1_th_18 sorry
          have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A2 A56 A70 xboole_0_def_4 sorry
          then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
            using valued_1_th_12 sorry
          then have "( |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A71 valued_1_th_13 sorry
          then have A72: "( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 M"
            using A70 funcop_1_th_7 sorry
          have "r -XCMPLX-0K6 f .FUNCT-1K1 x1 <>HIDDENR2 0NUMBERSK6"
            using A53 A70 sorry
          then have A73: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
            using complex1_th_47 sorry
          have "M +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
            using absvalue_th_4 xreal_1_th_8 sorry
          then have "( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5 <XXREAL-0R3  |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M"
            using A72 xxreal_0_th_2 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|)\<inverse>XCMPLX-0K5"
            using A73 xreal_1_th_76 sorry
          thus "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3  |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 x1 .|"
            using xcmplx_1_th_216 sorry
        qed "sorry"
        have " False "
        proof-
          show " False "
          proof-
            have cases: "p =COMPLEX1R1 g or p <>HIDDENR2 g"
               sorry
            have case1: "p =COMPLEX1R1 g implies  False "
            proof(rule impI)
              assume "p =COMPLEX1R1 g"
              thus " False "
                using A52 sorry
            qed
            have case2: "p <>HIDDENR2 g implies  False "
            proof(rule impI)
              assume "p <>HIDDENR2 g"
              then have "p <XXREAL-0R3 g"
                using A1 xxreal_0_th_1 sorry
              then have A74: "0NUMBERSK6 <XXREAL-0R3 g -XCMPLX-0K6 p"
                using xreal_1_th_50 sorry
              then have A75: "0NUMBERSK6 <XXREAL-0R3 (g -XCMPLX-0K6 p)/XCMPLX-0K7 s"
                using A67 xreal_1_th_139 sorry
              obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A76: "(g -XCMPLX-0K6 p)/XCMPLX-0K7 s <XXREAL-0R3 k"
                using seq_4_th_3 sorry
              have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 s)*XCMPLX-0K3 s <XXREAL-0R3 s *XCMPLX-0K3 k"
                using A67 A76 xreal_1_th_68 sorry
              then have "g -XCMPLX-0K6 p <XXREAL-0R3 s *XCMPLX-0K3 k"
                using A67 xcmplx_1_th_87 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 (s *XCMPLX-0K3 k)/XCMPLX-0K7 k"
                using A76 A75 xreal_1_th_74 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 (s *XCMPLX-0K3 k)*XCMPLX-0K3 k \<inverse>XCMPLX-0K5"
                using xcmplx_0_def_9 sorry
              then have "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 s *XCMPLX-0K3 (k *XCMPLX-0K3 k \<inverse>XCMPLX-0K5)"
                 sorry
              then have A77: "(g -XCMPLX-0K6 p)/XCMPLX-0K7 k <XXREAL-0R3 s *XCMPLX-0K3 \<one>\<^sub>M"
                using A76 A75 xcmplx_0_def_7 sorry
              let ?F = "\<lambda>Lamb1. g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 Lamb1"
              obtain s1 where
                [ty]:"s1 be Real-SequenceSEQ-1M1" and 
                A78: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
                using seq_1_sch_1 sorry
              have A79: "0NUMBERSK6 <XXREAL-0R3 (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                using A74 A76 A75 xreal_1_th_139 sorry
              have A80: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k implies s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [.RCOMP-1K1 p,g .] & (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 [.RCOMP-1K1 p,g .] &  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M))"
              proof(rule ballI,rule impI,rule conjMI,rule conjMI)
                fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                have A81: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
                  using A2 relat_1_th_62 sorry
                assume A82: "n <XXREAL-0R3 k"
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <XXREAL-0R3 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                  using A79 xreal_1_th_68 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <XXREAL-0R3 g -XCMPLX-0K6 p"
                  using A76 A75 xcmplx_1_th_87 sorry
                then have "g -XCMPLX-0K6 (g -XCMPLX-0K6 p) <XXREAL-0R3 g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n"
                  using xreal_1_th_15 sorry
                then have A83: "g -XCMPLX-0K6 (g -XCMPLX-0K6 p) <XXREAL-0R3 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                  using A78 sorry
                have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                  using A82 nat_1_th_13 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                  using A74 xreal_1_th_64 sorry
                then have "((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                  using A76 A75 xcmplx_1_th_87 sorry
                then have "g -XCMPLX-0K6 (g -XCMPLX-0K6 p) <=XXREAL-0R1 g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)"
                  using xreal_1_th_13 sorry
                then have A84: "g -XCMPLX-0K6 (g -XCMPLX-0K6 p) <=XXREAL-0R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                  using A78 sorry
                have "g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n <=XXREAL-0R1 g -XCMPLX-0K6 0NUMBERSK6"
                  using A74 xreal_1_th_13 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 g"
                  using A78 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 {x2 where x2 be RealXREAL-0M1 : p <=XXREAL-0R1 x2 & x2 <=XXREAL-0R1 g }"
                  using A83 sorry
                thus A85: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 [.RCOMP-1K1 p,g .]"
                  using rcomp_1_def_1 sorry
                have "g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 g -XCMPLX-0K6 0NUMBERSK6"
                  using A74 xreal_1_th_13 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 g"
                  using A78 sorry
                then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 {x2 where x2 be RealXREAL-0M1 : p <=XXREAL-0R1 x2 & x2 <=XXREAL-0R1 g }"
                  using A84 sorry
                thus A86: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 [.RCOMP-1K1 p,g .]"
                  using rcomp_1_def_1 sorry
                have " |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| =HIDDENR1  |.COMPLEX1K10 (g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .|"
                  using A78 sorry
                also have "... =  |.COMPLEX1K10 (g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n) .|"
                  using A78 sorry
                also have "... =  |.COMPLEX1K10 -XCMPLX-0K4 (((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 n) .|"
                   sorry
                also have "... =  |.COMPLEX1K10 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 n) .|"
                  using complex1_th_52 sorry
                also have "... = (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                  using A74 absvalue_def_1 sorry
                finally have " |.COMPLEX1K10 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -REAL-1K5 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n .| =HIDDENR1 (g -XCMPLX-0K6 p)/XCMPLX-0K7 k"
                   sorry
                thus " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
                  using A68 A77 A85 A86 A81 sorry
              qed "sorry"
              let ?P = "\<lambda>Lamb1. r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-1K1 Lamb1)"
              have A87: "s1 .FUNCT-1K1 k =HIDDENR1 g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 k"
                using A78 sorry
              also have "... = g -XCMPLX-0K6 (g -XCMPLX-0K6 p)"
                using A76 A75 xcmplx_1_th_87 sorry
              also have "... = p"
                 sorry
              finally have "s1 .FUNCT-1K1 k =HIDDENR1 p"
                 sorry
              then have A88: " ex n be NatNAT-1M1 st ?P(n)"
                using A54 sorry
              obtain l where
                [ty]:"l be NatNAT-1M1" and 
                A89: "?P(l) & ( for m be NatNAT-1M1 holds ?P(m) implies l <=XXREAL-0R1 m)"
                using nat_1_sch_5 A88 sorry
              have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 g -XCMPLX-0K6 ((g -XCMPLX-0K6 p)/XCMPLX-0K7 k)*XCMPLX-0K3 (0NUMBERSK6)"
                using A78 sorry
              also have "... = g"
                 sorry
              finally have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 g"
                 sorry
              then have "l <>HIDDENR2 0NUMBERSK6"
                using A54 A55 A89 xxreal_0_th_1 sorry
              then obtain l1 where
                [ty]:"l1 be NatNAT-1M1" and 
                A90: "l =COMPLEX1R1 l1 +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_6 sorry
              have 
                [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A91: "r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using A89 A90 xreal_1_th_9 sorry
              have "l1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
                using A54 A87 A89 A90 sorry
              then have A92: "l1 <XXREAL-0R3 k"
                using nat_1_th_13 sorry
              then have A93: " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 M.| +XCMPLX-0K2 \<one>\<^sub>M)"
                using A80 sorry
              have "f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) <XXREAL-0R3 r"
              proof-
                have "r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) implies  False "
                proof(rule impI)
                  assume "r <=XXREAL-0R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                  then have "l <=XXREAL-0R1 l1"
                    using A89 sorry
                  then have "l +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 l"
                    using A90 xreal_1_th_8 sorry
                  thus " False "
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then have A94: "0NUMBERSK6 <XXREAL-0R3 r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using xreal_1_th_50 sorry
              then have "0NUMBERSK6 <XXREAL-0R3 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using A89 A90 xreal_1_th_9 sorry
              then have " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| =COMPLEX1R1 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1)"
                using absvalue_def_1 sorry
              then have A95: " |.COMPLEX1K10 r -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .| <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (l1 +NAT-1K1 \<one>\<^sub>M)) -XCMPLX-0K6 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1) .|"
                using A94 A91 absvalue_def_1 sorry
              have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l1 inTARSKIR2 [.RCOMP-1K1 p,g .]"
                using A80 A92 sorry
              thus " False "
                using A69 A95 A93 xxreal_0_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "f .FUNCT-1K1 p =COMPLEX1R1 f .FUNCT-1K1 g implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)"
    proof-
      have "f .FUNCT-1K1 p =COMPLEX1R1 f .FUNCT-1K1 g implies ( ex tVar14 be RealXREAL-0M1 st tVar14 inHIDDENR3 [.RCOMP-1K1 tVar14,g .] & r =COMPLEX1R1 f .FUNCT-1K1 tVar14)"
      proof(rule impI)
        assume A96: "f .FUNCT-1K1 p =COMPLEX1R1 f .FUNCT-1K1 g"
        show " ex tVar14 be RealXREAL-0M1 st tVar14 inHIDDENR3 [.RCOMP-1K1 tVar14,g .] & r =COMPLEX1R1 f .FUNCT-1K1 tVar14"
        proof(rule bexI[of _ "p"],rule conjMI)
          show "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
            using A1 xxreal_1_th_1 sorry
          have "[.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 p .] =XBOOLE-0R4 {SEQ-4K1 f .FUNCT-1K1 p }"
            using A96 xxreal_1_th_17 sorry
          thus "r =COMPLEX1R1 f .FUNCT-1K1 p"
            using A4 tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus " not ( for s be RealXREAL-0M1 holds  not (s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
      using A6 A51 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_16:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .] implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) implies ( for r be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .] implies  not ( for s be RealXREAL-0M1 holds  not (s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "p <=XXREAL-0R1 g"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
    have "[.RCOMP-1K1 p,g .] be compactRCOMP-1V1"
      using rcomp_1_th_6 sorry
    then have A4: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
      using A2 A3 fcont_1_th_29 rcomp_1_th_10 sorry
    let ?ub = "upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
    let ?lb = "lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
    have "[.RCOMP-1K1 p,g .] <>HIDDENR2 {}XBOOLE-0K1"
      using A1 xxreal_1_th_1 sorry
    then obtain x2 x1 where
      [ty]:"x2 be RealXREAL-0M1" "x1 be RealXREAL-0M1" and 
      A5: "x2 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A6: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A7: "f .FUNCT-1K1 x2 =COMPLEX1R1 ?ub"and A8: "f .FUNCT-1K1 x1 =COMPLEX1R1 ?lb"
      using A2 A3 fcont_1_th_31 rcomp_1_th_6 sorry
    have 
      [ty]:"x1 be RealXREAL-0M1" and
      [ty]:"x2 be RealXREAL-0M1"
       sorry
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A9: "r inHIDDENR3 [.RCOMP-1K1 ?lb,?ub .]"
    have "f .FUNCT-1K1 x1 inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A2 A6 funct_1_def_6 sorry
    then have A10: "[.RCOMP-1K1 ?lb,?ub .] =XBOOLE-0R4 [.RCOMP-1K1 ?lb,?ub .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 ?ub,?lb .]"
      using A4 seq_4_th_11 xxreal_1_th_222 sorry
    have " ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
    proof-
      show " ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
      proof-
        have cases: "x1 <=XXREAL-0R1 x2 or x2 <=XXREAL-0R1 x1"
           sorry
        have case1: "x1 <=XXREAL-0R1 x2 implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)"
        proof(rule impI)
          assume A11: "x1 <=XXREAL-0R1 x2"
          have A12: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
            using A5 A6 xxreal_2_def_12 sorry
          have A13: "[.RCOMP-1K1 x1,x2 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
            using A5 A6 xxreal_2_def_12 sorry
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,x2 .]) be continuousFCONT-1V1"
            using A3 fcont_1_th_16 sorry
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A14: "s inHIDDENR3 [.RCOMP-1K1 x1,x2 .]"and A15: "r =COMPLEX1R1 f .FUNCT-1K1 s"
            using A2 A9 A7 A8 A10 A11 A12 fcont_2_th_15 xboole_1_th_1 sorry
          show " ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
          proof(rule bexI[of _ "s"])
            show "s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
              using A13 A14 A15 sorry
          qed "sorry"
        qed
        have case2: "x2 <=XXREAL-0R1 x1 implies ( ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s)"
        proof(rule impI)
          assume A16: "x2 <=XXREAL-0R1 x1"
          have A17: "[.RCOMP-1K1 x2,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
            using A5 A6 xxreal_2_def_12 sorry
          have A18: "[.RCOMP-1K1 x2,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
            using A5 A6 xxreal_2_def_12 sorry
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x2,x1 .]) be continuousFCONT-1V1"
            using A3 fcont_1_th_16 sorry
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A19: "s inHIDDENR3 [.RCOMP-1K1 x2,x1 .]"and A20: "r =COMPLEX1R1 f .FUNCT-1K1 s"
            using A2 A9 A7 A8 A10 A16 A17 fcont_2_th_15 xboole_1_th_1 sorry
          show " ex s be RealXREAL-0M1 st s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
          proof(rule bexI[of _ "s"])
            show "s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s"
              using A18 A19 A20 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( for s be RealXREAL-0M1 holds  not (s inHIDDENR3 [.RCOMP-1K1 p,g .] & r =COMPLEX1R1 f .FUNCT-1K1 s))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_17:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be one-to-oneFUNCT-1V2 & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & p <=XXREAL-0R1 g) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be one-to-oneFUNCT-1V2 & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (p <=XXREAL-0R1 g & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 & ( not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 &  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2)))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A0: "p be setHIDDENM2"
      using tarski_th_1 sorry
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "p <=XXREAL-0R1 g"
      and A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
      and A5: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
      and A6: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
    have " False "
    proof-
      show " False "
      proof-
        have cases: "p =COMPLEX1R1 g or p <>HIDDENR2 g"
           sorry
        have case1: "p =COMPLEX1R1 g implies  False "
        proof(rule impI)
          assume "p =COMPLEX1R1 g"
          then have "[.RCOMP-1K1 p,g .] =XBOOLE-0R4 {SEQ-4K1 p}"
            using xxreal_1_th_17 sorry
          thus " False "
            using A6 A0 rfunct_2_th_44 sorry
        qed
        have case2: "p <>HIDDENR2 g implies  False "
        proof(rule impI)
          assume A7: "p <>HIDDENR2 g"
          have A8: "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
            using A3 xxreal_1_th_1 sorry
          have A9: "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
            using A3 xxreal_1_th_1 sorry
          then have A10: "f .FUNCT-1K1 p <>HIDDENR2 f .FUNCT-1K1 g"
            using A1 A2 A7 A8 funct_1_def_4 sorry
          have " False "
          proof-
            show " False "
            proof-
              have cases: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g or f .FUNCT-1K1 p >XXREAL-0R4 f .FUNCT-1K1 g"
                using A10 xxreal_0_th_1 sorry
              have case1: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g implies  False "
              proof(rule impI)
                assume A11: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 g"
                have A12: " for x1 be RealXREAL-0M1 holds p <=XXREAL-0R1 x1 & x1 <=XXREAL-0R1 g implies f .FUNCT-1K1 p <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 g"
                proof-
                  have " for x1 be RealXREAL-0M1 holds p <=XXREAL-0R1 x1 & (x1 <=XXREAL-0R1 g &  not (f .FUNCT-1K1 p <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 g)) implies  False "
                  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
                    fix x1 assume [ty]: "x1 be RealXREAL-0M1"
                    assume A13: "p <=XXREAL-0R1 x1"
                      and A14: "x1 <=XXREAL-0R1 g"
                      and A15: " not (f .FUNCT-1K1 p <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 g)"
                    have " False "
                    proof-
                      show " False "
                      proof-
                        have cases: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 p or f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 x1"
                          using A15 sorry
                        have case1: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 p implies  False "
                        proof(rule impI)
                          assume A16: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 p"
                          then have "f .FUNCT-1K1 p inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 x1 <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 g }"
                            using A11 sorry
                          then have "f .FUNCT-1K1 p inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 g .]"
                            using rcomp_1_def_1 sorry
                          then have A17: "f .FUNCT-1K1 p inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 x1 .]"
                            using xboole_0_def_3 sorry
                          have "x1 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                            using A13 A14 sorry
                          then have A18: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using rcomp_1_def_1 sorry
                          have "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using A3 xxreal_1_th_1 sorry
                          then have A19: "[.RCOMP-1K1 x1,g .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using A18 xxreal_2_def_12 sorry
                          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,g .]) be continuousFCONT-1V1"
                            using A4 fcont_1_th_16 sorry
                          then obtain s where
                            [ty]:"s be RealXREAL-0M1" and 
                            A20: "s inHIDDENR3 [.RCOMP-1K1 x1,g .]"and A21: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 p"
                            using A2 A14 A19 A17 fcont_2_th_15 xboole_1_th_1 sorry
                          have "s inHIDDENR3 {t where t be RealXREAL-0M1 : x1 <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
                            using A20 rcomp_1_def_1 sorry
                          then have A22: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & x1 <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                             sorry
                          have A23: "x1 >XXREAL-0R4 p"
                            using A13 A16 xxreal_0_th_1 sorry
                          have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using A19 A20 sorry
                          thus " False "
                            using A1 A2 A9 A23 A21 A22 funct_1_def_4 sorry
                        qed
                        have case2: "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 x1 implies  False "
                        proof(rule impI)
                          assume A24: "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 x1"
                          then have "f .FUNCT-1K1 g inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 p <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 x1 }"
                            using A11 sorry
                          then have "f .FUNCT-1K1 g inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 x1 .]"
                            using rcomp_1_def_1 sorry
                          then have A25: "f .FUNCT-1K1 g inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 x1 .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 p .]"
                            using xboole_0_def_3 sorry
                          have "x1 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                            using A13 A14 sorry
                          then have A26: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using rcomp_1_def_1 sorry
                          have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using A3 xxreal_1_th_1 sorry
                          then have A27: "[.RCOMP-1K1 p,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using A26 xxreal_2_def_12 sorry
                          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,x1 .]) be continuousFCONT-1V1"
                            using A4 fcont_1_th_16 sorry
                          then obtain s where
                            [ty]:"s be RealXREAL-0M1" and 
                            A28: "s inHIDDENR3 [.RCOMP-1K1 p,x1 .]"and A29: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 g"
                            using A2 A13 A27 A25 fcont_2_th_15 xboole_1_th_1 sorry
                          have "s inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 x1 }"
                            using A28 rcomp_1_def_1 sorry
                          then have A30: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 x1"
                             sorry
                          have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                            using A27 A28 sorry
                          then have "s =COMPLEX1R1 g"
                            using A1 A2 A8 A29 funct_1_def_4 sorry
                          thus " False "
                            using A14 A24 A30 xxreal_0_th_1 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " False "
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                obtain x1 x2 where
                  [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
                  A31: "x1 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A32: "x2 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A33: "x1 <XXREAL-0R3 x2"and A34: "f .FUNCT-1K1 x2 <=XXREAL-0R1 f .FUNCT-1K1 x1"
                  using A5 rfunct_2_th_20 sorry
                have A35: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A31 xboole_0_def_4 sorry
                then have A36: "[.RCOMP-1K1 p,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                  using A9 xxreal_2_def_12 sorry
                have A37: "x2 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A32 xboole_0_def_4 sorry
                then have "x2 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                  using rcomp_1_def_1 sorry
                then have " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x2 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                   sorry
                then have "f .FUNCT-1K1 p <=XXREAL-0R1 f .FUNCT-1K1 x2"
                  using A12 sorry
                then have "f .FUNCT-1K1 x2 inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 p <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 x1 }"
                  using A34 sorry
                then have "f .FUNCT-1K1 x2 inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 x1 .]"
                  using rcomp_1_def_1 sorry
                then have A38: "f .FUNCT-1K1 x2 inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 x1 .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 p .]"
                  using xboole_0_def_3 sorry
                have "x1 inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
                  using A35 rcomp_1_def_1 sorry
                then have A39: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x1 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                   sorry
                have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A3 xxreal_1_th_1 sorry
                then have A40: "[.RCOMP-1K1 p,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                  using A35 xxreal_2_def_12 sorry
                then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,x1 .]) be continuousFCONT-1V1"
                  using A4 fcont_1_th_16 sorry
                then obtain s where
                  [ty]:"s be RealXREAL-0M1" and 
                  A41: "s inHIDDENR3 [.RCOMP-1K1 p,x1 .]"and A42: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 x2"
                  using A2 A39 A38 A36 fcont_2_th_15 xboole_1_th_1 sorry
                have "s inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 x1 }"
                  using A41 rcomp_1_def_1 sorry
                then have A43: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 x1"
                   sorry
                have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A40 A41 sorry
                thus " False "
                  using A1 A2 A33 A37 A42 A43 funct_1_def_4 sorry
              qed
              have case2: "f .FUNCT-1K1 p >XXREAL-0R4 f .FUNCT-1K1 g implies  False "
              proof(rule impI)
                assume A44: "f .FUNCT-1K1 p >XXREAL-0R4 f .FUNCT-1K1 g"
                have A45: " for x1 be RealXREAL-0M1 holds p <=XXREAL-0R1 x1 & x1 <=XXREAL-0R1 g implies f .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 p"
                proof-
                  have " for x1 be RealXREAL-0M1 holds p <=XXREAL-0R1 x1 & (x1 <=XXREAL-0R1 g &  not (f .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 p)) implies  False "
                  proof(rule ballI,rule impMI ,rule impMI ,rule impI)
                    fix x1 assume [ty]: "x1 be RealXREAL-0M1"
                    assume A46: "p <=XXREAL-0R1 x1"
                      and A47: "x1 <=XXREAL-0R1 g"
                      and A48: " not (f .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 x1 & f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 p)"
                    have " False "
                    proof-
                      show " False "
                      proof-
                        have cases: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 g or f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 x1"
                          using A48 sorry
                        have case1: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 g implies  False "
                        proof(rule impI)
                          assume A49: "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 g"
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "g =COMPLEX1R1 x1 or g <>HIDDENR2 x1"
                                 sorry
                              have case1: "g =COMPLEX1R1 x1 implies  False "
                              proof(rule impI)
                                assume "g =COMPLEX1R1 x1"
                                thus " False "
                                  using A49 sorry
                              qed
                              have case2: "g <>HIDDENR2 x1 implies  False "
                              proof(rule impI)
                                assume A50: "g <>HIDDENR2 x1"
                                have "x1 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                                  using A46 A47 sorry
                                then have A51: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using rcomp_1_def_1 sorry
                                have "f .FUNCT-1K1 g inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 x1 <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 p }"
                                  using A44 A49 sorry
                                then have "f .FUNCT-1K1 g inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 p .]"
                                  using rcomp_1_def_1 sorry
                                then have A52: "f .FUNCT-1K1 g inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 p,f .FUNCT-1K1 x1 .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 p .]"
                                  using xboole_0_def_3 sorry
                                have "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using A3 xxreal_1_th_1 sorry
                                then have A53: "[.RCOMP-1K1 p,x1 .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                                  using A51 xxreal_2_def_12 sorry
                                then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,x1 .]) be continuousFCONT-1V1"
                                  using A4 fcont_1_th_16 sorry
                                then obtain s where
                                  [ty]:"s be RealXREAL-0M1" and 
                                  A54: "s inHIDDENR3 [.RCOMP-1K1 p,x1 .]"and A55: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 g"
                                  using A2 A46 A53 A52 fcont_2_th_15 xboole_1_th_1 sorry
                                have "s inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 x1 }"
                                  using A54 rcomp_1_def_1 sorry
                                then have A56: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 x1"
                                   sorry
                                have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using A53 A54 sorry
                                then have "s =COMPLEX1R1 g"
                                  using A1 A2 A8 A55 funct_1_def_4 sorry
                                thus " False "
                                  using A47 A50 A56 xxreal_0_th_1 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        have case2: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 x1 implies  False "
                        proof(rule impI)
                          assume A57: "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 x1"
                          have " False "
                          proof-
                            show " False "
                            proof-
                              have cases: "p =COMPLEX1R1 x1 or p <>HIDDENR2 x1"
                                 sorry
                              have case1: "p =COMPLEX1R1 x1 implies  False "
                              proof(rule impI)
                                assume "p =COMPLEX1R1 x1"
                                thus " False "
                                  using A57 sorry
                              qed
                              have case2: "p <>HIDDENR2 x1 implies  False "
                              proof(rule impI)
                                assume A58: "p <>HIDDENR2 x1"
                                have "x1 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                                  using A46 A47 sorry
                                then have A59: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using rcomp_1_def_1 sorry
                                have "f .FUNCT-1K1 p inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 g <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 x1 }"
                                  using A44 A57 sorry
                                then have "f .FUNCT-1K1 p inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 x1 .]"
                                  using rcomp_1_def_1 sorry
                                then have A60: "f .FUNCT-1K1 p inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 x1,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 x1 .]"
                                  using xboole_0_def_3 sorry
                                have "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using A3 xxreal_1_th_1 sorry
                                then have A61: "[.RCOMP-1K1 x1,g .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                                  using A59 xxreal_2_def_12 sorry
                                then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x1,g .]) be continuousFCONT-1V1"
                                  using A4 fcont_1_th_16 sorry
                                then obtain s where
                                  [ty]:"s be RealXREAL-0M1" and 
                                  A62: "s inHIDDENR3 [.RCOMP-1K1 x1,g .]"and A63: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 p"
                                  using A2 A47 A61 A60 fcont_2_th_15 xboole_1_th_1 sorry
                                have "s inHIDDENR3 {t where t be RealXREAL-0M1 : x1 <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
                                  using A62 rcomp_1_def_1 sorry
                                then have A64: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & x1 <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                                   sorry
                                have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                                  using A61 A62 sorry
                                then have "s =COMPLEX1R1 p"
                                  using A1 A2 A9 A63 funct_1_def_4 sorry
                                thus " False "
                                  using A46 A58 A64 xxreal_0_th_1 sorry
                              qed
                              show " ?thesis "
                                using cases case1 case2 sorry
                            qed
                          qed
                          thus " False "
                             sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " False "
                       sorry
                  qed "sorry"
                  thus " ?thesis "
                     sorry
                qed
                obtain x1 x2 where
                  [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
                  A65: "x1 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A66: "x2 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"and A67: "x1 <XXREAL-0R3 x2"and A68: "f .FUNCT-1K1 x1 <=XXREAL-0R1 f .FUNCT-1K1 x2"
                  using A6 rfunct_2_th_21 sorry
                have A69: "x2 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A66 xboole_0_def_4 sorry
                then have A70: "[.RCOMP-1K1 x2,g .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                  using A8 xxreal_2_def_12 sorry
                have A71: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A65 xboole_0_def_4 sorry
                then have "x1 inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
                  using rcomp_1_def_1 sorry
                then have " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x1 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                   sorry
                then have "f .FUNCT-1K1 g <=XXREAL-0R1 f .FUNCT-1K1 x1"
                  using A45 sorry
                then have "f .FUNCT-1K1 x1 inTARSKIR2 {r where r be RealXREAL-0M1 : f .FUNCT-1K1 g <=XXREAL-0R1 r & r <=XXREAL-0R1 f .FUNCT-1K1 x2 }"
                  using A68 sorry
                then have "f .FUNCT-1K1 x1 inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 x2 .]"
                  using rcomp_1_def_1 sorry
                then have A72: "f .FUNCT-1K1 x1 inTARSKIR2 [.RCOMP-1K1 f .FUNCT-1K1 x2,f .FUNCT-1K1 g .] \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> [.RCOMP-1K1 f .FUNCT-1K1 g,f .FUNCT-1K1 x2 .]"
                  using xboole_0_def_3 sorry
                have "x2 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
                  using A69 rcomp_1_def_1 sorry
                then have A73: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x2 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                   sorry
                have "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A3 xxreal_1_th_1 sorry
                then have A74: "[.RCOMP-1K1 x2,g .] c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                  using A69 xxreal_2_def_12 sorry
                then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x2,g .]) be continuousFCONT-1V1"
                  using A4 fcont_1_th_16 sorry
                then obtain s where
                  [ty]:"s be RealXREAL-0M1" and 
                  A75: "s inHIDDENR3 [.RCOMP-1K1 x2,g .]"and A76: "f .FUNCT-1K1 s =COMPLEX1R1 f .FUNCT-1K1 x1"
                  using A2 A73 A72 A70 fcont_2_th_15 xboole_1_th_1 sorry
                have "s inHIDDENR3 {t where t be RealXREAL-0M1 : x2 <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
                  using A75 rcomp_1_def_1 sorry
                then have A77: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 s & x2 <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
                   sorry
                have "s inHIDDENR3 [.RCOMP-1K1 p,g .]"
                  using A74 A75 sorry
                thus " False "
                  using A1 A2 A67 A71 A76 A77 funct_1_def_4 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " False "
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_18:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f be one-to-oneFUNCT-1V2 & p <=XXREAL-0R1 g) & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g or lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be one-to-oneFUNCT-1V2 & (p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1)) implies  not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: "p <=XXREAL-0R1 g"
      and A3: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
    have A5: "p inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using A2 xxreal_1_th_1 sorry
    then have A6: "f .FUNCT-1K1 p inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A3 funct_1_def_6 sorry
    have A7: "g inHIDDENR3 [.RCOMP-1K1 p,g .]"
      using A2 xxreal_1_th_1 sorry
    then have A8: "f .FUNCT-1K1 g inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
      using A3 funct_1_def_6 sorry
    have A9: "g inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 A7 xboole_0_def_4 sorry
    have A10: "p inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 A5 xboole_0_def_4 sorry
    have "[.RCOMP-1K1 p,g .] <>HIDDENR2 {}XBOOLE-0K1"
      using A2 xxreal_1_th_1 sorry
    then obtain x1 x2 where
      [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
      A11: "x1 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A12: "x2 inHIDDENR3 [.RCOMP-1K1 p,g .]"and A13: "f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"and A14: "f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
      using A3 A4 fcont_1_th_31 rcomp_1_th_6 sorry
    have A15: "x2 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 A12 xboole_0_def_4 sorry
    have "x2 inHIDDENR3 {t where t be RealXREAL-0M1 : p <=XXREAL-0R1 t & t <=XXREAL-0R1 g }"
      using A12 rcomp_1_def_1 sorry
    then have A16: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x2 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
       sorry
    have "x1 inHIDDENR3 {r where r be RealXREAL-0M1 : p <=XXREAL-0R1 r & r <=XXREAL-0R1 g }"
      using A11 rcomp_1_def_1 sorry
    then have A17: " ex r be RealXREAL-0M1 st (r =COMPLEX1R1 x1 & p <=XXREAL-0R1 r) & r <=XXREAL-0R1 g"
       sorry
    have "[.RCOMP-1K1 p,g .] be compactRCOMP-1V1"
      using rcomp_1_th_6 sorry
    then have A18: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
      using A3 A4 fcont_1_th_29 rcomp_1_th_10 sorry
    have A19: "x1 inHIDDENR3 ([.RCOMP-1K1 p,g .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 A11 xboole_0_def_4 sorry
    have " not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
    proof-
      show " not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          using A1 A2 A3 A4 fcont_2_th_17 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies  not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
        proof(rule impI)
          assume A20: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
          have A21: "x1 <>HIDDENR2 g implies  False "
          proof(rule impI)
            assume "x1 <>HIDDENR2 g"
            then have "x1 <XXREAL-0R3 g"
              using A17 xxreal_0_th_1 sorry
            then have "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 g"
              using A9 A19 A20 rfunct_2_th_20 sorry
            thus " False "
              using A8 A18 A13 seq_4_def_1 sorry
          qed
          have "x2 <>HIDDENR2 p implies  False "
          proof(rule impI)
            assume "x2 <>HIDDENR2 p"
            then have "p <XXREAL-0R3 x2"
              using A16 xxreal_0_th_1 sorry
            then have "f .FUNCT-1K1 p <XXREAL-0R3 f .FUNCT-1K1 x2"
              using A10 A15 A20 rfunct_2_th_20 sorry
            thus " False "
              using A6 A18 A14 seq_4_def_2 sorry
          qed
          thus " not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
            using A13 A14 A21 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies  not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
        proof(rule impI)
          assume A22: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          have A23: "x2 <>HIDDENR2 g implies  False "
          proof(rule impI)
            assume "x2 <>HIDDENR2 g"
            then have "x2 <XXREAL-0R3 g"
              using A16 xxreal_0_th_1 sorry
            then have "f .FUNCT-1K1 g <XXREAL-0R3 f .FUNCT-1K1 x2"
              using A9 A15 A22 rfunct_2_th_21 sorry
            thus " False "
              using A8 A18 A14 seq_4_def_2 sorry
          qed
          have "x1 <>HIDDENR2 p implies  False "
          proof(rule impI)
            assume "x1 <>HIDDENR2 p"
            then have "p <XXREAL-0R3 x1"
              using A17 xxreal_0_th_1 sorry
            then have "f .FUNCT-1K1 x1 <XXREAL-0R3 f .FUNCT-1K1 p"
              using A10 A19 A22 rfunct_2_th_21 sorry
            thus " False "
              using A6 A18 A13 seq_4_def_1 sorry
          qed
          thus " not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
            using A13 A14 A23 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g) &  not (lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 g & upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =COMPLEX1R1 f .FUNCT-1K1 p))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Darboux Theorem*)
mtheorem fcont_2_th_19:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) =XBOOLE-0R4 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) =XBOOLE-0R4 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "p <=XXREAL-0R1 g"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
    have "[.RCOMP-1K1 p,g .] be compactRCOMP-1V1"
      using rcomp_1_th_6 sorry
    then have A4: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be real-boundedXXREAL-2V5"
      using A2 A3 fcont_1_th_29 rcomp_1_th_10 sorry
    have " for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds (y inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) implies y inTARSKIR2 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) & (y inTARSKIR2 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .] implies y inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
      show "y inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) implies y inTARSKIR2 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
      proof(rule impI)
        assume A5: "y inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
        then have A6: "y >=XXREAL-0R2 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
          using A4 seq_4_def_2 sorry
        have "y <=XXREAL-0R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
          using A4 A5 seq_4_def_1 sorry
        then have "y inTARSKIR2 {s where s be RealXREAL-0M1 : lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) <=XXREAL-0R1 s & s <=XXREAL-0R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) }"
          using A6 sorry
        thus "y inTARSKIR2 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
          using rcomp_1_def_1 sorry
      qed
      assume "y inTARSKIR2 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
      then have " ex x0 be RealXREAL-0M1 st x0 inHIDDENR3 [.RCOMP-1K1 p,g .] & y =COMPLEX1R1 f .FUNCT-1K1 x0"
        using A1 A2 A3 fcont_2_th_16 sorry
      thus "y inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
        using A2 funct_1_def_6 sorry
    qed "sorry"
    thus "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) =XBOOLE-0R4 [.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]"
      using subset_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_2_th_20:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1) implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "p <=XXREAL-0R1 g"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be continuousFCONT-1V1"
    have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
    proof-
      show "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          using A1 A2 A3 fcont_2_th_17 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
            using rfunct_2_th_51 sorry
          then have "(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
            using rfunct_2_th_17 sorry
          then have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be monotoneRFUNCT-2V5"
            using relat_1_th_72 sorry
          then have A4: "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be monotoneRFUNCT-2V5"
            using A1 A2 A3 fcont_2_th_19 sorry
          have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using A1 A2 A3 fcont_2_th_19 sorry
          also have "... = (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_129 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using rfunct_2_th_17 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using relat_1_th_61 sorry
          also have "... = [.RCOMP-1K1 p,g .]"
            using A2 xboole_1_th_28 sorry
          finally have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) =HIDDENR1 [.RCOMP-1K1 p,g .]"
             sorry
          thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
            using A1 A4 fcont_1_th_46 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
            using rfunct_2_th_52 sorry
          then have "(f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
            using rfunct_2_th_17 sorry
          then have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be monotoneRFUNCT-2V5"
            using relat_1_th_72 sorry
          then have A5: "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be monotoneRFUNCT-2V5"
            using A1 A2 A3 fcont_2_th_19 sorry
          have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) =HIDDENR1 f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using A1 A2 A3 fcont_2_th_19 sorry
          also have "... = (f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_129 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using rfunct_2_th_17 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using relat_1_th_61 sorry
          also have "... = [.RCOMP-1K1 p,g .]"
            using A2 xboole_1_th_28 sorry
          finally have "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) =HIDDENR1 [.RCOMP-1K1 p,g .]"
             sorry
          thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
            using A1 A5 fcont_1_th_46 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f \<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])),upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) .]) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
