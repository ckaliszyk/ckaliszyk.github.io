theory rfunct_3
  imports setwop_2 partfun2 limfunc1 rfinseq
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m for "NatNAT-1M1"
reserve r, r1, r2, s, t for "RealXREAL-0M1"
mdef rfunct_3_def_1 ("max+RFUNCT-3K1  _ " [300]300 ) where
  mlet "r be RealXREAL-0M1"
"func max+RFUNCT-3K1 r \<rightarrow> RealXREAL-0M1 equals
  maxXXREAL-0K5(r,0NUMBERSK6)"
proof-
  (*coherence*)
    show "maxXXREAL-0K5(r,0NUMBERSK6) be RealXREAL-0M1"
       sorry
qed "sorry"

mdef rfunct_3_def_2 ("max-RFUNCT-3K2  _ " [300]300 ) where
  mlet "r be RealXREAL-0M1"
"func max-RFUNCT-3K2 r \<rightarrow> RealXREAL-0M1 equals
  maxXXREAL-0K5(-XCMPLX-0K4 r,0NUMBERSK6)"
proof-
  (*coherence*)
    show "maxXXREAL-0K5(-XCMPLX-0K4 r,0NUMBERSK6) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rfunct_3_th_1:
" for r be RealXREAL-0M1 holds r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
proof(rule ballI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  have "0NUMBERSK6 <=XXREAL-0R1 r & r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r)"
  proof-
    show "0NUMBERSK6 <=XXREAL-0R1 r & r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r)"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 r or r <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 r implies r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
      proof(rule impI)
        assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
        then have "max-RFUNCT-3K2 r =COMPLEX1R1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        thus "r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
          using A1 xxreal_0_def_10 sorry
      qed
      have case2: "r <XXREAL-0R3 0NUMBERSK6 implies r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
      proof(rule impI)
        assume "r <XXREAL-0R3 0NUMBERSK6"
        then have "max+RFUNCT-3K1 r =COMPLEX1R1 0NUMBERSK6 & max-RFUNCT-3K2 r =COMPLEX1R1 -XCMPLX-0K4 r"
          using xxreal_0_def_10 sorry
        thus "r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "r =COMPLEX1R1 max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r"
     sorry
qed "sorry"

mtheorem rfunct_3_th_2:
" for r be RealXREAL-0M1 holds  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
proof(rule ballI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  have "0NUMBERSK6 <=XXREAL-0R1 r &  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r)"
  proof-
    show "0NUMBERSK6 <=XXREAL-0R1 r &  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r)"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 r or r <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 r implies  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
      proof(rule impI)
        assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
        then have "max+RFUNCT-3K1 r =COMPLEX1R1 r & max-RFUNCT-3K2 r =COMPLEX1R1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        thus " |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
          using A1 absvalue_def_1 sorry
      qed
      have case2: "r <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
      proof(rule impI)
        assume A2: "r <XXREAL-0R3 0NUMBERSK6"
        then have "max+RFUNCT-3K1 r =COMPLEX1R1 0NUMBERSK6 & max-RFUNCT-3K2 r =COMPLEX1R1 -XCMPLX-0K4 r"
          using xxreal_0_def_10 sorry
        thus " |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
          using A2 absvalue_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus " |.COMPLEX1K10 r.| =COMPLEX1R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r"
     sorry
qed "sorry"

mtheorem rfunct_3_th_3:
" for r be RealXREAL-0M1 holds \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 r =COMPLEX1R1 r +XCMPLX-0K2  |.COMPLEX1K10 r.|"
proof-
  have " for r be RealXREAL-0M1 holds r +XCMPLX-0K2  |.COMPLEX1K10 r.| =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 r"
  proof(rule ballI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    have "r +XCMPLX-0K2  |.COMPLEX1K10 r.| =HIDDENR1 (max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r)+XCMPLX-0K2  |.COMPLEX1K10 r.|"
      using rfunct_3_th_1 sorry
    also have "... = (max+RFUNCT-3K1 r -XCMPLX-0K6 max-RFUNCT-3K2 r)+XCMPLX-0K2 (max+RFUNCT-3K1 r +XCMPLX-0K2 max-RFUNCT-3K2 r)"
      using rfunct_3_th_2 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 r"
       sorry
    finally show "r +XCMPLX-0K2  |.COMPLEX1K10 r.| =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 r"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_4:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 r implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
proof(rule ballI,rule ballI,rule impI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix s assume [ty]: "s be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <=XXREAL-0R1 r"
  have "0NUMBERSK6 <=XXREAL-0R1 s & max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s or s <XXREAL-0R3 0NUMBERSK6 & (s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s)"
  proof-
    show "0NUMBERSK6 <=XXREAL-0R1 s & max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s or s <XXREAL-0R3 0NUMBERSK6 & (s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s)"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 s or s <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 s implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
      proof(rule impI)
        assume A2: "0NUMBERSK6 <=XXREAL-0R1 s"
        then have "max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 s"
          using A1 xxreal_0_def_10 sorry
        thus "max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
          using A2 xxreal_0_def_10 sorry
      qed
      have case2: "s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
      proof(rule impI)
        assume A3: "s <XXREAL-0R3 0NUMBERSK6"
        then have "max+RFUNCT-3K1 s =COMPLEX1R1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        thus "max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
          using A1 A3 xxreal_0_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "max+RFUNCT-3K1 (r *XCMPLX-0K3 s) =COMPLEX1R1 r *XCMPLX-0K3 max+RFUNCT-3K1 s"
     sorry
qed "sorry"

mtheorem rfunct_3_th_5:
" for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
proof(rule ballI,rule ballI)
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix s assume [ty]: "s be RealXREAL-0M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 maxXXREAL-0K5(r,0NUMBERSK6) & 0NUMBERSK6 <=XXREAL-0R1 maxXXREAL-0K5(s,0NUMBERSK6)"
    using xxreal_0_th_25 sorry
  have A2: "r <=XXREAL-0R1 maxXXREAL-0K5(r,0NUMBERSK6) & s <=XXREAL-0R1 maxXXREAL-0K5(s,0NUMBERSK6)"
    using xxreal_0_th_25 sorry
  have "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2 s & max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s or r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6 & (r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s)"
  proof-
    show "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2 s & max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s or r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6 & (r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s)"
    proof-
      have cases: "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2 s or r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2 s implies max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
      proof(rule impI)
        assume "0NUMBERSK6 <=XXREAL-0R1 r +XCMPLX-0K2 s"
        then have "max+RFUNCT-3K1 (r +XCMPLX-0K2 s) =COMPLEX1R1 r +XCMPLX-0K2 s"
          using xxreal_0_def_10 sorry
        thus "max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
          using A2 xreal_1_th_7 sorry
      qed
      have case2: "r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6 implies max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
      proof(rule impI)
        assume "r +XCMPLX-0K2 s <XXREAL-0R3 0NUMBERSK6"
        then have "max+RFUNCT-3K1 (r +XCMPLX-0K2 s) =COMPLEX1R1 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        thus "max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "max+RFUNCT-3K1 (r +XCMPLX-0K2 s) <=XXREAL-0R1 max+RFUNCT-3K1 r +XCMPLX-0K2 max+RFUNCT-3K1 s"
     sorry
qed "sorry"

mlemma rfunct_3_lm_1:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =FINSEQ-1R1 f"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =FINSEQ-1R1 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using finseq_1_def_3 sorry
    assume "lenFINSEQ-1K4 f <=XXREAL-0R1 n"
    then have "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =RELSET-1R2\<^bsub>(NATNUMBERSK1,D)\<^esub> f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 n & domFINSEQ-1K5 f c=MEMBEREDR6 SegFINSEQ-1K2 n"
      using A1 finseq_1_th_5 finseq_1_def_15 sorry
    thus "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =FINSEQ-1R1 f"
      using relat_1_th_68 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rfunct_3_lm_2:
" for f be FunctionFUNCT-1M1 holds  for x be setHIDDENM2 holds  not x inTARSKIR2 rngFUNCT-1K2 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix x assume [ty]: "x be setHIDDENM2"
  assume A1: " not x inTARSKIR2 rngFUNCT-1K2 f"
  have "rngFUNCT-1K2 f missesXBOOLE-0R1 {TARSKIK1 x}"
  proof-
    let ?y = "the ElementSUBSET-1M1-of rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x}"
    have "rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1 implies  False "
    proof(rule impI)
      assume "rngFUNCT-1K2 f /\\XBOOLE-0K3 {TARSKIK1 x} <>HIDDENR2 {}XBOOLE-0K1"
      then have "?y inTARSKIR2 rngFUNCT-1K2 f & ?y inTARSKIR2 {TARSKIK1 x}"
        using xboole_0_def_4 sorry
      thus " False "
        using A1 tarski_def_1 sorry
    qed
    thus "rngFUNCT-1K2 f missesXBOOLE-0R1 {TARSKIK1 x}"
      using xboole_0_def_7 sorry
  qed
  thus "f \<inverse>FUNCT-1K6 {TARSKIK1 x} =XBOOLE-0R4 {}XBOOLE-0K1"
    using relat_1_th_138 sorry
qed "sorry"

(*begin*)
mtheorem rfunct_3_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } =XBOOLE-0R4 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix s assume [ty]: "s be RealXREAL-0M1"
  assume A1: "r <>HIDDENR2 0NUMBERSK6"
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } c=TARSKIR1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} & (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r }"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } c=TARSKIR1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } implies x inHIDDENR3 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r }"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A2 funct_1_def_7 sorry
        then have A3: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
          using valued_1_def_5 sorry
        have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s /XCMPLX-0K7 r }"
          using A2 funct_1_def_7 sorry
        then have "F .FUNCT-1K1 d =COMPLEX1R1 s /XCMPLX-0K7 r"
          using tarski_def_1 sorry
        then have "r *XCMPLX-0K3 F .FUNCT-1K1 d =COMPLEX1R1 s"
          using A1 xcmplx_1_th_87 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d =COMPLEX1R1 s"
          using A3 valued_1_def_5 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s}"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
          using A3 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } c=TARSKIR1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
        using A4 funct_1_def_7 sorry
      have "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s}"
        using A4 funct_1_def_7 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d =COMPLEX1R1 s"
        using tarski_def_1 sorry
      then have "r *XCMPLX-0K3 F .FUNCT-1K1 d =COMPLEX1R1 s"
        using A5 valued_1_def_5 sorry
      then have "F .FUNCT-1K1 d =COMPLEX1R1 s /XCMPLX-0K7 r"
        using A1 xcmplx_1_th_89 sorry
      then have A6: "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s /XCMPLX-0K7 r }"
        using tarski_def_1 sorry
      have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A5 valued_1_def_5 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r }"
        using A6 funct_1_def_7 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r }"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s /XCMPLX-0K7 r } =XBOOLE-0R4 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F & domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule conjMI)
    show "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
          using A1 funct_1_def_7 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using valued_1_def_5 sorry
      qed "sorry"
      thus "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F implies x inHIDDENR3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A2: "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have A3: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
        using A2 valued_1_def_5 sorry
      then have "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 F .FUNCT-1K1 d"
        using valued_1_def_5 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally have "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d =HIDDENR1 0NUMBERSK6"
         sorry
      then have "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A3 funct_1_def_7 sorry
    qed "sorry"
    thus "domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using tarski_def_3 sorry
  qed
  thus "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
  have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using valued_1_def_11 sorry
  have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } & F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } c=TARSKIR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
  proof(rule conjMI)
    show "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
        then obtain rr where 
          [ty]:"rr be ElementSUBSET-1M1-of D" and rrDef:"rr = x"
           sorry
        have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK1 r}"
          using A3 funct_1_def_7 sorry
        then have " |.COMPLEX1K10 F .FUNCT-1K1 rr.| inHIDDENR3 {TARSKIK1 r}"
          using valued_1_th_18 sorry
        then have A4: " |.COMPLEX1K10 F .FUNCT-1K1 rr.| =COMPLEX1R1 r"
          using tarski_def_1 sorry
        have A5: "rr inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
          using A3 funct_1_def_7 sorry
        have "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 rr & x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } or F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6 & (F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6 implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r })"
        proof-
          show "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 rr & x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } or F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6 & (F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6 implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r })"
          proof-
            have cases: "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 rr or F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 rr implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
            proof(rule impI)
              assume "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 rr"
              then have "F .FUNCT-1K1 rr =COMPLEX1R1 r"
                using A4 absvalue_def_1 sorry
              then have "F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK2 -XCMPLX-0K4 r,r }"
                using tarski_def_2 sorry
              thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
                using A2 A5 funct_1_def_7 sorry
            qed
            have case2: "F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6 implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
            proof(rule impI)
              assume "F .FUNCT-1K1 rr <XXREAL-0R3 0NUMBERSK6"
              then have "-XCMPLX-0K4 F .FUNCT-1K1 rr =COMPLEX1R1 r"
                using A4 absvalue_def_1 sorry
              then have "F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK2 -XCMPLX-0K4 r,r }"
                using tarski_def_2 sorry
              thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
                using A2 A5 funct_1_def_7 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
           sorry
      qed "sorry"
      thus "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
      then obtain rr where 
        [ty]:"rr be ElementSUBSET-1M1-of D" and rrDef:"rr = x"
         sorry
      have A7: "rr inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A6 funct_1_def_7 sorry
      have A8: "F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK2 -XCMPLX-0K4 r,r }"
        using A6 funct_1_def_7 sorry
      have "F .FUNCT-1K1 rr =COMPLEX1R1 -XCMPLX-0K4 r & x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} or F .FUNCT-1K1 rr =COMPLEX1R1 r & (F .FUNCT-1K1 rr =COMPLEX1R1 r implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
      proof-
        show "F .FUNCT-1K1 rr =COMPLEX1R1 -XCMPLX-0K4 r & x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} or F .FUNCT-1K1 rr =COMPLEX1R1 r & (F .FUNCT-1K1 rr =COMPLEX1R1 r implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof-
          have cases: "F .FUNCT-1K1 rr =COMPLEX1R1 -XCMPLX-0K4 r or F .FUNCT-1K1 rr =COMPLEX1R1 r"
            using A8 tarski_def_2 sorry
          have case1: "F .FUNCT-1K1 rr =COMPLEX1R1 -XCMPLX-0K4 r implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
          proof(rule impI)
            assume "F .FUNCT-1K1 rr =COMPLEX1R1 -XCMPLX-0K4 r"
            then have "r =HIDDENR1  |.COMPLEX1K10 -XCMPLX-0K4 F .FUNCT-1K1 rr .|"
              using A1 absvalue_def_1 sorry
            also have "... =  |.COMPLEX1K10 F .FUNCT-1K1 rr.|"
              using complex1_th_52 sorry
            also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr"
              using valued_1_th_18 sorry
            finally have "r =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr"
               sorry
            then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK1 r}"
              using tarski_def_1 sorry
            thus "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
              using A2 A7 funct_1_def_7 sorry
          qed
          have case2: "F .FUNCT-1K1 rr =COMPLEX1R1 r implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
          proof(rule impI)
            assume "F .FUNCT-1K1 rr =COMPLEX1R1 r"
            then have "r =HIDDENR1  |.COMPLEX1K10 F .FUNCT-1K1 rr.|"
              using A1 absvalue_def_1 sorry
            also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr"
              using valued_1_th_18 sorry
            finally have "r =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr"
               sorry
            then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 rr inTARSKIR2 {TARSKIK1 r}"
              using tarski_def_1 sorry
            thus "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
              using A2 A7 funct_1_def_7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
         sorry
    qed "sorry"
    thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r } c=TARSKIR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      using tarski_def_3 sorry
  qed
  thus "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -XCMPLX-0K4 r,r }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using valued_1_def_11 sorry
  have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  proof(rule conjMI)
    show "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        then obtain r where 
          [ty]:"r be ElementSUBSET-1M1-of D" and rDef:"r = x"
           sorry
        have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 r inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A2 funct_1_def_7 sorry
        then have " |.COMPLEX1K10 F .FUNCT-1K1 r.| inHIDDENR3 {TARSKIK1 0NUMBERSK6 }"
          using valued_1_th_18 sorry
        then have " |.COMPLEX1K10 F .FUNCT-1K1 r.| =COMPLEX1R1 0NUMBERSK6"
          using tarski_def_1 sorry
        then have "F .FUNCT-1K1 r =COMPLEX1R1 0NUMBERSK6"
          using absvalue_th_2 sorry
        then have A3: "F .FUNCT-1K1 r inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using tarski_def_1 sorry
        have "r inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
          using A2 funct_1_def_7 sorry
        thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using A1 A3 funct_1_def_7 sorry
      qed "sorry"
      thus "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of D" and rDef:"r = x"
         sorry
      have "F .FUNCT-1K1 r inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using A4 funct_1_def_7 sorry
      then have "F .FUNCT-1K1 r =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      then have " |.COMPLEX1K10 F .FUNCT-1K1 r.| =COMPLEX1R1 0NUMBERSK6"
        using absvalue_th_2 sorry
      then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 r =COMPLEX1R1 0NUMBERSK6"
        using valued_1_th_18 sorry
      then have A5: "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 r inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_1 sorry
      have "r inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A4 funct_1_def_7 sorry
      thus "x inHIDDENR3 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using A1 A5 funct_1_def_7 sorry
    qed "sorry"
    thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      using tarski_def_3 sorry
  qed
  thus "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_10:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 implies absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <XXREAL-0R3 0NUMBERSK6 implies (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} <>HIDDENR2 {}XBOOLE-0K1 implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <XXREAL-0R3 0NUMBERSK6"
    let ?x = "the ElementSUBSET-1M1-of absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    assume A2: "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} <>HIDDENR2 {}XBOOLE-0K1"
    then obtain x where 
      [ty]:"x be ElementSUBSET-1M1-of D" and xDef:"x = ?x"
      using tarski_def_3 sorry
    have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 r}"
      using A2 funct_1_def_7 sorry
    then have " |.COMPLEX1K10 F .FUNCT-1K1 x.| inHIDDENR3 {TARSKIK1 r}"
      using valued_1_th_18 sorry
    then have " |.COMPLEX1K10 F .FUNCT-1K1 x.| =COMPLEX1R1 r"
      using tarski_def_1 sorry
    thus " False "
      using A1 complex1_th_46 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_11:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies ((F,G)are-fiberwise-equipotentCLASSES1R2 iff (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r <>HIDDENR2 0NUMBERSK6 implies ((F,G)are-fiberwise-equipotentCLASSES1R2 implies (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2) & ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2 implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "r <>HIDDENR2 0NUMBERSK6"
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
      using xreal_0_def_1 sorry
    have A2: "rngRVSUM-1K1 (rr (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 (rr (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G) c=MEMBEREDR3 REALNUMBERSK2"
       sorry
    show "(F,G)are-fiberwise-equipotentCLASSES1R2 implies (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    proof(rule impI)
      assume A3: "(F,G)are-fiberwise-equipotentCLASSES1R2"
      have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G,x))"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "CoimRELAT-1K13(F,x /XCMPLX-0K7 r) =XBOOLE-0R4 CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,x) & CoimRELAT-1K13(G,x /XCMPLX-0K7 r) =XBOOLE-0R4 CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G,x)"
          using A1 rfunct_3_th_6 sorry
        thus "cardCARD-1K1 (CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G,x))"
          using A3 classes1_def_10 sorry
      qed "sorry"
      thus "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
        using A2 classes1_th_79 sorry
    qed
    assume A4: "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    have A5: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      have A6: "G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 (r *XCMPLX-0K3 x)/XCMPLX-0K7 r } =XBOOLE-0R4 CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(C,REALNUMBERSK2)\<^esub> G,r *XCMPLX-0K3 x)"
        using A1 rfunct_3_th_6 sorry
      have "(r *XCMPLX-0K3 x)/XCMPLX-0K7 r =COMPLEX1R1 x & F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 (r *XCMPLX-0K3 x)/XCMPLX-0K7 r } =XBOOLE-0R4 CoimRELAT-1K13(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r *XCMPLX-0K3 x)"
        using A1 rfunct_3_th_6 xcmplx_1_th_89 sorry
      thus "cardCARD-1K1 (CoimRELAT-1K13(F,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,x))"
        using A4 A6 classes1_def_10 sorry
    qed "sorry"
    have "rngRVSUM-1K1 F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 G c=MEMBEREDR3 REALNUMBERSK2"
       sorry
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F,-VALUED-1K34\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
  using rfunct_3_th_11 sorry

mtheorem rfunct_3_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F,absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
  have A2: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G,r))"
  proof(rule ballI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) or 0NUMBERSK6 =COMPLEX1R1 r & (0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
    proof-
      show "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) or 0NUMBERSK6 =COMPLEX1R1 r & (0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 r or 0NUMBERSK6 =COMPLEX1R1 r) or r <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK2 -REAL-1K1 r,r } & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK2 -REAL-1K1 r,r }"
            using rfunct_3_th_8 sorry
          thus "cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A1 classes1_th_78 sorry
        qed
        have case2: "0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume "0NUMBERSK6 =COMPLEX1R1 r"
          then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} & absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
            using rfunct_3_th_9 sorry
          thus "cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A1 classes1_th_78 sorry
        qed
        have case3: "r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume A3: "r <XXREAL-0R3 0NUMBERSK6"
          then have "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 {}XBOOLE-0K1"
            using rfunct_3_th_10 sorry
          thus "cardCARD-1K1 (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A3 rfunct_3_th_10 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "cardCARD-1K1 (CoimRELAT-1K13(absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G,r))"
       sorry
  qed "sorry"
  have "rngRVSUM-1K1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G c=MEMBEREDR3 REALNUMBERSK2"
     sorry
  thus "(absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F,absVALUED-1K59\<^bsub>(C,REALNUMBERSK2)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    using A2 classes1_th_79 sorry
qed "sorry"

mdef rfunct_3_def_3 ("PartFunc-setRFUNCT-3M1-of'( _ , _ ')" [0,0]70 ) where
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"mode PartFunc-setRFUNCT-3M1-of(X,Y) \<rightarrow> setHIDDENM2 means
  (\<lambda>it.  for x be ElementSUBSET-1M1-of it holds x be PartFuncPARTFUN1M1-of(X,Y))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be ElementSUBSET-1M1-of it holds x be PartFuncPARTFUN1M1-of(X,Y)"
    proof-
      have " ex tVar1 be setHIDDENM2 st  for x be ElementSUBSET-1M1-of tVar1 holds x be PartFuncPARTFUN1M1-of(X,Y)"
      proof-
        obtain h where 
          [ty]:"h be PartFuncPARTFUN1M1-of(X,Y)" and hDef:"h = {}XBOOLE-0K1"
          using relset_1_th_12 sorry
        show " ex tVar1 be setHIDDENM2 st  for x be ElementSUBSET-1M1-of tVar1 holds x be PartFuncPARTFUN1M1-of(X,Y)"
        proof(rule bexI[of _ "{TARSKIK1 h}"])
          show " for x be ElementSUBSET-1M1-of {TARSKIK1 h} holds x be PartFuncPARTFUN1M1-of(X,Y)"
            using tarski_def_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rfunct_3_cl_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1 for PartFunc-setRFUNCT-3M1-of(X,Y)"
proof
(*existence*)
  show " ex it be PartFunc-setRFUNCT-3M1-of(X,Y) st it be  non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be PartFunc-setRFUNCT-3M1-of(X,Y) holds VarFor1 be emptyXBOOLE-0V1)"
    proof-
      obtain h where 
        [ty]:"h be PartFuncPARTFUN1M1-of(X,Y)" and hDef:"h = {}XBOOLE-0K1"
        using relset_1_th_12 sorry
      have "{TARSKIK1 h} be PartFunc-setRFUNCT-3M1-of(X,Y)"
      proof-
        have " for x be ElementSUBSET-1M1-of {TARSKIK1 h} holds x be PartFuncPARTFUN1M1-of(X,Y)"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of {TARSKIK1 h}"
          show "x be PartFuncPARTFUN1M1-of(X,Y)"
            using tarski_def_1 sorry
        qed "sorry"
        thus "{TARSKIK1 h} be PartFunc-setRFUNCT-3M1-of(X,Y)"
          using rfunct_3_def_3 sorry
      qed
      thus " not ( for VarFor1 be PartFunc-setRFUNCT-3M1-of(X,Y) holds VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) RFUNCT_3M2("PFUNC-DOMAINRFUNCT-3M2-of'( _ , _ ')" [0,0]70) where
  "PFUNC-DOMAINRFUNCT-3M2-of(X,Y) \<equiv>  non emptyXBOOLE-0V1\<bar>PartFunc-setRFUNCT-3M1-of(X,Y)"

abbreviation(input) RFUNCT_3K3("PFuncsRFUNCT-3K3'( _ , _ ')" [0,0]228) where
  "PFuncsRFUNCT-3K3(X,Y) \<equiv> PFuncsPARTFUN1K4(X,Y)"

mtheorem rfunct_3_add_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster PFuncsPARTFUN1K4(X,Y) as-term-is PartFunc-setRFUNCT-3M1-of(X,Y)"
proof
(*coherence*)
  show "PFuncsPARTFUN1K4(X,Y) be PartFunc-setRFUNCT-3M1-of(X,Y)"
  proof-
    have " for x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(X,Y) holds x be PartFuncPARTFUN1M1-of(X,Y)"
      using partfun1_th_47 sorry
    thus "PFuncsPARTFUN1K4(X,Y) be PartFunc-setRFUNCT-3M1-of(X,Y)"
      using rfunct_3_def_3 sorry
  qed
qed "sorry"

syntax RFUNCT_3M3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementRFUNCT-3M3\<^bsub>'( _ , _ ')\<^esub>-of  _ " [0,0,70]70)
translations "ElementRFUNCT-3M3\<^bsub>(X,Y)\<^esub>-of P" \<rightharpoonup> "ElementSUBSET-1M1-of P"

mtheorem rfunct_3_add_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "P be  non emptyXBOOLE-0V1\<bar>PartFunc-setRFUNCT-3M1-of(X,Y)"
"cluster note-that PartFuncPARTFUN1M1-of(X,Y) for ElementSUBSET-1M1-of P"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of P holds it be PartFuncPARTFUN1M1-of(X,Y)"
    using rfunct_3_def_3 sorry
qed "sorry"

syntax RFUNCT_3K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -->RFUNCT-3K4\<^bsub>'( _ , _ ')\<^esub>  _ " [116,0,0,116]116)
translations "X -->RFUNCT-3K4\<^bsub>(D,C)\<^esub> c" \<rightharpoonup> "X -->FUNCOP-1K2 c"

mtheorem rfunct_3_add_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "X be SubsetSUBSET-1M2-of D", "c be ElementSUBSET-1M1-of C"
"cluster X -->FUNCOP-1K2 c as-term-is ElementRFUNCT-3M3\<^bsub>(D,C)\<^esub>-of PFuncsRFUNCT-3K3(D,C)"
proof
(*coherence*)
  show "X -->FUNCOP-1K2 c be ElementRFUNCT-3M3\<^bsub>(D,C)\<^esub>-of PFuncsRFUNCT-3K3(D,C)"
  proof-
    have "X -->PARTFUN2K4\<^bsub>(D,C)\<^esub> c be PartFuncPARTFUN1M1-of(D,C)"
       sorry
    thus "X -->FUNCOP-1K2 c be ElementRFUNCT-3M3\<^bsub>(D,C)\<^esub>-of PFuncsRFUNCT-3K3(D,C)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

mtheorem rfunct_3_cl_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster note-that real-valuedVALUED-0V7 for ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
proof
(*coherence*)
  show " for it be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E) holds it be real-valuedVALUED-0V7"
     sorry
qed "sorry"

syntax RFUNCT_3K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +RFUNCT-3K5\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "F1 +RFUNCT-3K5\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 +VALUED-1K1 F2"

mtheorem rfunct_3_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 +VALUED-1K1 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 +VALUED-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F1 be PartFuncPARTFUN1M1-of(D,E)" and
      [ty]:"F2 be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "F1 +VALUED-1K3\<^bsub>(D,E,E)\<^esub> F2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "F1 +VALUED-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -RFUNCT-3K6\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "F1 -RFUNCT-3K6\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 -VALUED-1K47 F2"

mtheorem rfunct_3_add_5:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 -VALUED-1K47 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 -VALUED-1K47 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F1 be PartFuncPARTFUN1M1-of(D,E)" and
      [ty]:"F2 be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "F1 -VALUED-1K49\<^bsub>(D,E,E)\<^esub> F2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "F1 -VALUED-1K47 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')RFUNCT-3K7\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "F1 (#)RFUNCT-3K7\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 (#)VALUED-1K19 F2"

mtheorem rfunct_3_add_6:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 (#)VALUED-1K19 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 (#)VALUED-1K19 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F1 be PartFuncPARTFUN1M1-of(D,E)" and
      [ty]:"F2 be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "F1 (#)VALUED-1K21\<^bsub>(D,E,E)\<^esub> F2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "F1 (#)VALUED-1K19 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/RFUNCT-3K8\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "F1 /RFUNCT-3K8\<^bsub>(D,E)\<^esub> F2" \<rightharpoonup> "F1 /RFUNCT-1K1 F2"

mtheorem rfunct_3_add_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F1 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "F2 be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F1 /RFUNCT-1K1 F2 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F1 /RFUNCT-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F1 be PartFuncPARTFUN1M1-of(D,E)" and
      [ty]:"F2 be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "F1 /RFUNCT-1K3\<^bsub>(D,E)\<^esub> F2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "F1 /RFUNCT-1K1 F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absRFUNCT-3K9\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absRFUNCT-3K9\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> " |.VALUED-1K56 F.|"

mtheorem rfunct_3_add_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster  |.VALUED-1K56 F.| as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show " |.VALUED-1K56 F.| be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "absVALUED-1K59\<^bsub>(D,E)\<^esub> F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus " |.VALUED-1K56 F.| be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-RFUNCT-3K10\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-RFUNCT-3K10\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "-VALUED-1K32 F"

mtheorem rfunct_3_add_9:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster -VALUED-1K32 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "-VALUED-1K32 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "-VALUED-1K34\<^bsub>(D,E)\<^esub> F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "-VALUED-1K32 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^RFUNCT-3K11\<^bsub>'( _ , _ ')\<^esub>" [164,0,0]164)
translations "F ^RFUNCT-3K11\<^bsub>(D,E)\<^esub>" \<rightharpoonup> "F ^RFUNCT-1K4"

mtheorem rfunct_3_add_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)"
"cluster F ^RFUNCT-1K4 as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "F ^RFUNCT-1K4 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "F ^RFUNCT-1K6\<^bsub>(D,E)\<^esub> be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "F ^RFUNCT-1K4 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

syntax RFUNCT_3K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')RFUNCT-3K12\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)RFUNCT-3K12\<^bsub>(D,E)\<^esub> F" \<rightharpoonup> "r (#)VALUED-1K25 F"

mtheorem rfunct_3_add_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "E be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "F be ElementRFUNCT-3M3\<^bsub>(D,E)\<^esub>-of PFuncsRFUNCT-3K3(D,E)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 F as-term-is ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  proof-
    have 
      [ty]:"F be PartFuncPARTFUN1M1-of(D,E)"
       sorry
    have "r (#)VALUED-1K28\<^bsub>(D,E)\<^esub> F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
       sorry
    thus "r (#)VALUED-1K25 F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      using partfun1_th_45 sorry
  qed
qed "sorry"

mdef rfunct_3_def_4 ("addpfuncRFUNCT-3K13  _ " [300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func addpfuncRFUNCT-3K13 D \<rightarrow> BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it.  for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2"
proof-
  (*existence*)
    show " ex it be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st  for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2"
    proof-
      have " not ( for VarFor1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  not ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds VarFor1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2))"
      proof-
        let ?O = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> Lamb2"
        have " ex o be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st  for a be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for b be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(a,b) =FUNCT-1R1 ?O(a,b)"
          using binop_1_sch_4 sorry
        thus " not ( for VarFor1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  not ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds VarFor1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2) & ( for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds it2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =FUNCT-1R1 F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2) implies it1 =HIDDENR1 it2"
    proof-
      have " for o1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for o2 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds ( for f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> f2) & ( for f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> f2) implies o1 =HIDDENR1 o2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix o1 assume [ty]: "o1 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        fix o2 assume [ty]: "o2 be BinOpBINOP-1M2-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        assume A1: " for f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> f2"
          and A2: " for f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> f2"
        have " for f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds o1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 o2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2)"
        proof(rule ballI,rule ballI)
          fix f1 assume [ty]: "f1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
          fix f2 assume [ty]: "f2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
          have "o1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> f2"
            using A1 sorry
          thus "o1 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2) =FUNCT-1R1 o2 .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(f1,f2)"
            using A2 sorry
        qed "sorry"
        thus "o1 =HIDDENR1 o2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rfunct_3_th_14:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be commutativeBINOP-1V1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  have " for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F1)"
  proof(rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix F2 assume [ty]: "F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    let ?o = "addpfuncRFUNCT-3K13 D"
    have "addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =HIDDENR1 F2 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F1"
      using rfunct_3_def_4 sorry
    also have "... = addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F1)"
      using rfunct_3_def_4 sorry
    finally show "addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F1)"
       sorry
  qed "sorry"
  thus "addpfuncRFUNCT-3K13 D be commutativeBINOP-1V1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
    using binop_1_def_2 sorry
qed "sorry"

mtheorem rfunct_3_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be associativeBINOP-1V2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  have " for F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for F3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F3)) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2),F3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix F1 assume [ty]: "F1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix F2 assume [ty]: "F2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix F3 assume [ty]: "F3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    let ?o = "addpfuncRFUNCT-3K13 D"
    have "addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F3)) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F3)"
      using rfunct_3_def_4 sorry
    also have "... = F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> (F2 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F3)"
      using rfunct_3_def_4 sorry
    also have "... = (F1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F3"
      using rfunct_1_th_8 sorry
    also have "... = addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> F3"
      using rfunct_3_def_4 sorry
    also have "... = addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2),F3)"
      using rfunct_3_def_4 sorry
    finally show "addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F2,F3)) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(F1,F2),F3)"
       sorry
  qed "sorry"
  thus "addpfuncRFUNCT-3K13 D be associativeBINOP-1V2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
    using binop_1_def_3 sorry
qed "sorry"

mtheorem rfunct_3_th_16:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  let ?F = "[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> ?F =XBOOLE-0R4 D"
    using funcop_1_th_13 sorry
  have A2: " for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(G,[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =FUNCT-1R1 G"
  proof(rule ballI)
    fix G assume [ty]: "G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    have A3: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))) implies (G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 d =HIDDENR1 G .FUNCT-1K1 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ?F)"
      then have "(G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 d =HIDDENR1 G .FUNCT-1K1 d +XCMPLX-0K2 ([#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)).FUNCT-1K1 d"
        using valued_1_def_1 sorry
      also have "... = G .FUNCT-1K1 d +XCMPLX-0K2 0NUMBERSK6"
        using funcop_1_th_7 sorry
      also have "... = G .FUNCT-1K1 d"
         sorry
      finally show "(G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2))).FUNCT-1K1 d =HIDDENR1 G .FUNCT-1K1 d"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> G /\\SUBSET-1K8\<^bsub>(D)\<^esub> D =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> G"
      using xboole_1_th_28 sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> (G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ?F) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> G"
      using A1 valued_1_def_1 sorry
    then have "G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> ?F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
      using A3 partfun1_th_5 sorry
    thus "addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(G,[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)) =FUNCT-1R1 G"
      using rfunct_3_def_4 sorry
  qed "sorry"
  have "addpfuncRFUNCT-3K13 D be commutativeBINOP-1V1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
    using rfunct_3_th_14 sorry
  thus "[#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6 is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
    using A2 binop_1_th_5 sorry
qed "sorry"

mtheorem rfunct_3_th_17:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds the-unity-wrtBINOP-1K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  have "[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
    using rfunct_3_th_16 sorry
  thus "the-unity-wrtBINOP-1K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
    using binop_1_def_8 sorry
qed "sorry"

mtheorem rfunct_3_th_18:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds addpfuncRFUNCT-3K13 D be having-a-unitySETWISEOV1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  have "[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
  proof-
    show "[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) is-a-unity-wrtBINOP-1R3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> addpfuncRFUNCT-3K13 D"
      using rfunct_3_th_16 sorry
  qed
  thus "addpfuncRFUNCT-3K13 D be having-a-unitySETWISEOV1\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
    using bexI[of _ "[#]SUBSET-1K2 D -->RFUNCT-3K4\<^bsub>(D,REALNUMBERSK2)\<^esub> InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"] setwiseo_def_2 sorry
qed "sorry"

mdef rfunct_3_def_5 ("SumRFUNCT-3K14\<^bsub>'( _ ')\<^esub>  _ " [0,260]260 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
"func SumRFUNCT-3K14\<^bsub>(D)\<^esub> f \<rightarrow> ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) equals
  addpfuncRFUNCT-3K13 D $$SETWOP-2K5\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f"
proof-
  (*coherence*)
    show "addpfuncRFUNCT-3K13 D $$SETWOP-2K5\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem rfunct_3_th_19:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2)) =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
proof(rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  let ?o = "addpfuncRFUNCT-3K13 D"
  let ?o0 = "[#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
  have "the-unity-wrtBINOP-1K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> ?o =FUNCT-1R1 ?o0"
    using rfunct_3_th_17 sorry
  thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2)) =FUNCT-1R1 [#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6"
    using rfunct_3_th_18 finsop_1_th_10 sorry
qed "sorry"

mtheorem rfunct_3_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> f +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    let ?o = "addpfuncRFUNCT-3K13 D"
    have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(addpfuncRFUNCT-3K13 D $$SETWOP-2K5\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f,G)"
      using rfunct_3_th_18 finsop_1_th_4 sorry
    also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> f +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
      using rfunct_3_def_4 sorry
    finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> f +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f2) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for f2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f2) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    let ?o = "addpfuncRFUNCT-3K13 D"
    have "?o be associativeBINOP-1V2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>"
      using rfunct_3_th_15 sorry
    then have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f2) =HIDDENR1 addpfuncRFUNCT-3K13 D .BINOP-1K4\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub>(SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1,SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2)"
      using rfunct_3_th_18 finsop_1_th_5 sorry
    also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2"
      using rfunct_3_def_4 sorry
    finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f2) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> f1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f) =HIDDENR1 G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
      using rfunct_3_th_21 sorry
    also have "... = G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
      using finsop_1_th_11 sorry
    finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f) =HIDDENR1 G +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) =HIDDENR1 G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G1 assume [ty]: "G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix G2 assume [ty]: "G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1*>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G2*>))"
      using finseq_1_def_9 sorry
    also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1*>) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
      using rfunct_3_th_20 sorry
    also have "... = G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
      using finsop_1_th_11 sorry
    finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) =HIDDENR1 G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2,G3 *>) =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for G3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2,G3 *>) =HIDDENR1 (G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix G1 assume [ty]: "G1 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix G2 assume [ty]: "G2 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    fix G3 assume [ty]: "G3 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2,G3 *>) =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> ((<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>)^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G3*>))"
      using finseq_1_th_43 sorry
    also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2 *>) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
      using rfunct_3_th_20 sorry
    also have "... = (G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
      using rfunct_3_th_23 sorry
    finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-4K3\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G1,G2,G3 *>) =HIDDENR1 (G1 +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G2)+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  let ?P = "\<lambda>Lamb1.  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =COMPLEX1R1 Lamb1 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  assume A1: "(f,g)are-fiberwise-equipotentCLASSES1R2"
  have A2: "lenFINSEQ-1K4 f =COMPLEX1R1 lenFINSEQ-1K4 f"
     sorry
  have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =COMPLEX1R1 n implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g) implies ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> g)"
    proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A4: "?P(n)"
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      assume A5: "(f,g)are-fiberwise-equipotentCLASSES1R2"
        and A6: "lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have A7: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using A6 finseq_3_th_25 sorry
      then obtain a where 
        [ty]:"a be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and aDef:"a = f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using finseq_2_th_11 sorry
      have "rngRELSET-1K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> f =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> g"
        using A5 classes1_th_75 sorry
      then have "a inTARSKIR2 rngRELSET-1K2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> g"
        using A7 funct_1_def_3 sorry
      then obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A8: "m inTARSKIR2 domFINSEQ-1K5 g"and A9: "g .FUNCT-1K1 m =FUNCT-1R1 a"
        using finseq_2_th_10 sorry
      have A10: "g =FINSEQ-1R1 g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)"
        using rfinseq_th_8 sorry
      let ?gg = "g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m"
      let ?gm = "g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m"
      have "m <=XXREAL-0R1 lenFINSEQ-1K4 g"
        using A8 finseq_3_th_25 sorry
      then have A11: "lenFINSEQ-1K4 ?gm =COMPLEX1R1 m"
        using finseq_1_th_59 sorry
      let ?fn = "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n"
      have A12: "f =FINSEQ-1R1 ?fn ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)"
        using A6 rfinseq_th_7 sorry
      have A13: "\<one>\<^sub>M <=XXREAL-0R1 m"
        using A8 finseq_3_th_25 sorry
      then have "maxXXREAL-0K5(0NUMBERSK6,m -XCMPLX-0K6 \<one>\<^sub>M) =COMPLEX1R1 m -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_4 sorry
      then obtain m1 where 
        [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m -XCMPLX-0K6 \<one>\<^sub>M"
        using finseq_2_th_5 sorry
      have A14: "m =COMPLEX1R1 m1 +NAT-1K1 \<one>\<^sub>M"
         sorry
      then have "m1 <=XXREAL-0R1 m"
        using nat_1_th_11 sorry
      then have A15: "SegFINSEQ-1K2 m1 c=MEMBEREDR6 SegFINSEQ-1K2 m"
        using finseq_1_th_5 sorry
      have "m inTARSKIR2 SegFINSEQ-1K2 m"
        using A13 finseq_1_th_1 sorry
      then have "?gm .FUNCT-1K1 m =FUNCT-1R1 a"
        using A8 A9 rfinseq_th_6 sorry
      then have A16: "?gm =FINSEQ-1R1 ?gm  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)"
        using A11 A14 rfinseq_th_7 sorry
      have A17: "?gm  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 =HIDDENR1 ?gm  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> SegFINSEQ-1K2 m1"
        using finseq_1_def_15 sorry
      also have "... = (g  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> SegFINSEQ-1K2 m) |PARTFUN1K2\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> SegFINSEQ-1K2 m1"
        using finseq_1_def_15 sorry
      also have "... = g  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (SegFINSEQ-1K2 m /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> SegFINSEQ-1K2 m1)"
        using relat_1_th_71 sorry
      also have "... = g  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> SegFINSEQ-1K2 m1"
        using A15 xboole_1_th_28 sorry
      also have "... = g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1"
        using finseq_1_def_15 sorry
      finally have "?gm  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 =HIDDENR1 g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1"
         sorry
      have " for x be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m),x))"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "cardCARD-1K1 (CoimRELAT-1K13(f,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g,x))"
          using A5 classes1_def_10 sorry
        then have "cardCARD-1K4 (?fn \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 (((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>))^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m))\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
          using A10 A16 A17 A12 finseq_3_th_57 sorry
        also have "... = cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>))\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        also have "... = (cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}))+NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        also have "... = (cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}))+NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
           sorry
        also have "... = cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m))\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
          using finseq_3_th_57 sorry
        finally have "cardCARD-1K4 (?fn \<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) =HIDDENR1 cardCARD-1K4 ((g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m))\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> {TARSKIK1 x})"
           sorry
        thus "cardCARD-1K1 (CoimRELAT-1K13(f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m),x))"
           sorry
      qed "sorry"
      then have A18: "(?fn,g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m))are-fiberwise-equipotentCLASSES1R2"
        using classes1_def_10 sorry
      have "lenFINSEQ-1K4 ?fn =COMPLEX1R1 n"
        using A6 finseq_1_th_59 nat_1_th_11 sorry
      then have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> ?gg)"
        using A4 A18 sorry
      then have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1 ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)"
        using A12 rfunct_3_th_21 sorry
      also have "... = (SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m))+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>)"
        using rfunct_3_th_21 sorry
      also have "... = (SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m1) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> a*>))+RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)"
        using rfunct_1_th_8 sorry
      also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m) +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> (g /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> m)"
        using A16 A17 rfunct_3_th_21 sorry
      also have "... = SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
        using A10 rfunct_3_th_21 sorry
      finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A19: "?P(0NUMBERSK6)"
  proof-
    have " for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =COMPLEX1R1 0NUMBERSK6 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
    proof(rule ballI,rule ballI,rule impI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      assume "(f,g)are-fiberwise-equipotentCLASSES1R2 & lenFINSEQ-1K4 f =COMPLEX1R1 0NUMBERSK6"
      then have A20: "lenFINSEQ-1K4 g =COMPLEX1R1 0NUMBERSK6 & f =FINSEQ-1R1 <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2))"
        using rfinseq_th_3 sorry
      then have "g =FINSEQ-1R1 <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2))"
         sorry
      thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
        using A20 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A19 A3 sorry
  thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> g"
    using A1 A2 sorry
qed "sorry"

mdef rfunct_3_def_6 ("CHIRFUNCT-3K15'( _ , _ ')" [0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M1"
"func CHIRFUNCT-3K15(f,D) \<rightarrow> FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
    proof-
      have " ex tVar3 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 tVar3 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar3 implies tVar3 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
      proof-
        let ?F = "\<lambda>Lamb1. chiRFUNCT-1K7(f .FUNCT-1K1 Lamb1,D)"
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M1" and 
          A1: "lenFINSEQ-1K4 p =COMPLEX1R1 lenFINSEQ-1K4 f"and A2: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 n =XBOOLE-0R4 ?F(n)"
          using finseq_1_sch_2 sorry
        have "rngFUNCT-1K2 p c=TARSKIR1 PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 p implies x inHIDDENR3 PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 p"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              A3: "n inTARSKIR2 domFINSEQ-1K5 p & p .FUNCT-1K1 n =HIDDENR1 x"
              using finseq_2_th_10 sorry
            have "x =HIDDENR1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
              using A2 A3 sorry
            thus "x inHIDDENR3 PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
              using partfun1_th_45 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 p c=TARSKIR1 PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
            using tarski_def_3 sorry
        qed
        then have 
          [ty]:"p be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
          using finseq_1_def_4 sorry
        show " ex tVar3 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 tVar3 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar3 implies tVar3 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule impI)
          show "lenFINSEQ-1K4 p =COMPLEX1R1 lenFINSEQ-1K4 f"
            using A1 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n inTARSKIR2 domFINSEQ-1K5 p"
          thus "p .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D))) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for p2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 p1 =COMPLEX1R1 lenFINSEQ-1K4 f & (( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)) & (lenFINSEQ-1K4 p2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies p2 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)))) implies p1 =HIDDENR1 p2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        assume A4: "lenFINSEQ-1K4 p1 =COMPLEX1R1 lenFINSEQ-1K4 f"
          and A5: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
          and A6: "lenFINSEQ-1K4 p2 =COMPLEX1R1 lenFINSEQ-1K4 f"
          and A7: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies p2 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
        have A8: "domFINSEQ-1K5 p1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1) & domFINSEQ-1K5 p2 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p2)"
          using finseq_1_def_3 sorry
        have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =FUNCT-1R1 p2 .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A9: "n inTARSKIR2 domFINSEQ-1K5 p1"
          then have "p1 .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
            using A5 sorry
          thus "p1 .FUNCT-1K1 n =FUNCT-1R1 p2 .FUNCT-1K1 n"
            using A4 A6 A7 A8 A9 sorry
        qed "sorry"
        thus "p1 =HIDDENR1 p2"
          using A4 A6 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef rfunct_3_def_7 (" _ '(#')RFUNCT-3K16\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)", "R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
"func R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f \<rightarrow> FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 it =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))"
    proof-
      have " ex tVar5 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 tVar5 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar5 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  not ((r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n) &  not tVar5 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 Lamb1 & F =FUNCT-1R1 f .FUNCT-1K1 Lamb1 implies Lamb2 =XBOOLE-0R4 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
        let ?m = "minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f)"
        have A1: "?m <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using xxreal_0_th_17 sorry
        have A2: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 ?m implies ( ex x be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st ?P(n,x))"
        proof-
          have " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 (minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f)) implies ( ex tVar4 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies tVar4 =XBOOLE-0R4 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            obtain r where 
              [ty]:"r be RealXREAL-0M1" and rDef:"r = R .FUNCT-1K1 n"
               sorry
            assume A3: "n inTARSKIR2 SegFINSEQ-1K2 ?m"
            then have "n <=XXREAL-0R1 ?m"
              using finseq_1_th_1 sorry
            then have A4: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A1 xxreal_0_th_2 sorry
            have "\<one>\<^sub>M <=XXREAL-0R1 n"
              using A3 finseq_1_th_1 sorry
            then have "n inTARSKIR2 domFINSEQ-1K5 f"
              using A4 finseq_3_th_25 sorry
            then obtain F where 
              [ty]:"F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and FDef:"F = f .FUNCT-1K1 n"
              using finseq_2_th_11 sorry
            obtain a where 
              [ty]:"a be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and aDef:"a = r (#)RFUNCT-3K12\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
               sorry
            show " ex tVar4 be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies tVar4 =XBOOLE-0R4 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
            proof(rule bexI[of _ "a"])
              show " for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies a =XBOOLE-0R4 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
                 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and 
          A5: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 ?m & ( for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 ?m implies ?P(n,p .FUNCT-1K1 n))"
          using finseq_1_sch_5 A2 sorry
        show " ex tVar5 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) st lenFINSEQ-1K4 tVar5 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 tVar5 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  not ((r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n) &  not tVar5 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule impI)
          show "lenFINSEQ-1K4 p =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f)"
            using A5 finseq_1_def_3 sorry
          fix n assume [ty]: "n be NatNAT-1M1"
          assume "n inTARSKIR2 domFINSEQ-1K5 p"
          thus " for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  not ((r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n) &  not p .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
            using A5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for it2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it1 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies it2 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F))) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for p2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 p1 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & (( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies p1 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)) & (lenFINSEQ-1K4 p2 =COMPLEX1R1 minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f) & ( for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies p2 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)))) implies p1 =HIDDENR1 p2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        let ?m = "minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f)"
        fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        assume A6: "lenFINSEQ-1K4 p1 =COMPLEX1R1 ?m"
          and A7: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies p1 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
          and A8: "lenFINSEQ-1K4 p2 =COMPLEX1R1 ?m"
          and A9: " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds r =COMPLEX1R1 R .FUNCT-1K1 n & F =FUNCT-1R1 f .FUNCT-1K1 n implies p2 .FUNCT-1K1 n =FUNCT-1R1 r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
        have A10: "domFINSEQ-1K5 p1 =MEMBEREDR12 SegFINSEQ-1K2 ?m"
          using A6 finseq_1_def_3 sorry
        have A11: "domFINSEQ-1K5 p1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1) & domFINSEQ-1K5 p2 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p2)"
          using finseq_1_def_3 sorry
        have A12: "?m <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using xxreal_0_th_17 sorry
        have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =FUNCT-1R1 p2 .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          obtain r where 
            [ty]:"r be RealXREAL-0M1" and rDef:"r = R .FUNCT-1K1 n"
             sorry
          assume A13: "n inTARSKIR2 domFINSEQ-1K5 p1"
          then have "n <=XXREAL-0R1 ?m"
            using A10 finseq_1_th_1 sorry
          then have A14: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
            using A12 xxreal_0_th_2 sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 n"
            using A10 A13 finseq_1_th_1 sorry
          then have "n inTARSKIR2 domFINSEQ-1K5 f"
            using A14 finseq_3_th_25 sorry
          then obtain F where 
            [ty]:"F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and FDef:"F = f .FUNCT-1K1 n"
            using finseq_2_th_11 sorry
          have "p1 .FUNCT-1K1 n =FUNCT-1R1 r (#)RFUNCT-3K12\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
            using A7 A13 sorry
          thus "p1 .FUNCT-1K1 n =FUNCT-1R1 p2 .FUNCT-1K1 n"
            using A6 A8 A9 A11 A13 sorry
        qed "sorry"
        thus "p1 =HIDDENR1 p2"
          using A6 A8 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef rfunct_3_def_8 (" _ #RFUNCT-3K17\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)", "d be ElementSUBSET-1M1-of D"
"func f #RFUNCT-3K17\<^bsub>(D)\<^esub> d \<rightarrow> FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 it =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
    proof-
      have " ex tVar7 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar7 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (n inTARSKIR2 domFINSEQ-1K5 tVar7 &  not tVar7 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d))"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 =XBOOLE-0R4 (f .FUNCT-1K1 Lamb1).FUNCT-1K1 d"
        have A1: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) implies ( ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,x))"
        proof-
          have " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) implies ( ex tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 & tVar6 =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
            then have "n inTARSKIR2 domFINSEQ-1K5 f"
              using finseq_1_def_3 sorry
            then obtain G where 
              [ty]:"G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and GDef:"G = f .FUNCT-1K1 n"
              using finseq_2_th_11 sorry
            show " ex tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar6 be ElementSUBSET-1M1-of REALNUMBERSK2 & tVar6 =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d"
            proof(rule bexI[of _ "G .FUNCT-1K1 d"])
              show "G .FUNCT-1K1 d be ElementSUBSET-1M1-of REALNUMBERSK2 & G .FUNCT-1K1 d =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d"
                using xreal_0_def_1 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain p where
          [ty]:"p be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and 
          A2: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"and A3: " for n be NatNAT-1M1 holds n inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) implies ?P(n,p .FUNCT-1K1 n)"
          using finseq_1_sch_5 A1 sorry
        show " ex tVar7 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st lenFINSEQ-1K4 tVar7 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (n inTARSKIR2 domFINSEQ-1K5 tVar7 &  not tVar7 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d))"
        proof(rule bexI[of _ "p"],rule conjMI)
          show "lenFINSEQ-1K4 p =COMPLEX1R1 lenFINSEQ-1K4 f"
            using A2 finseq_1_def_3 sorry
          show " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (n inTARSKIR2 domFINSEQ-1K5 p &  not p .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)"
            using A2 A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 it1 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)) & (lenFINSEQ-1K4 it2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d)) implies it1 =HIDDENR1 it2"
    proof-
      have " for p1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for p2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 p1 =COMPLEX1R1 lenFINSEQ-1K4 f & (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d) & (lenFINSEQ-1K4 p2 =COMPLEX1R1 lenFINSEQ-1K4 f & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies p2 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d))) implies p1 =HIDDENR1 p2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
        assume A4: "lenFINSEQ-1K4 p1 =COMPLEX1R1 lenFINSEQ-1K4 f"
          and A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d"
          and A6: "lenFINSEQ-1K4 p2 =COMPLEX1R1 lenFINSEQ-1K4 f"
          and A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 p2 implies p2 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d"
        have A8: "domFINSEQ-1K5 p1 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
          using finseq_1_def_3 sorry
        have A9: "domFINSEQ-1K5 p2 =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p2)"
          using finseq_1_def_3 sorry
        have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 p1 implies p1 .FUNCT-1K1 n =COMPLEX1R1 p2 .FUNCT-1K1 n"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A10: "n inTARSKIR2 domFINSEQ-1K5 p1"
          then have "p1 .FUNCT-1K1 n =XBOOLE-0R4 (f .FUNCT-1K1 n).FUNCT-1K1 d"
            using A5 sorry
          thus "p1 .FUNCT-1K1 n =COMPLEX1R1 p2 .FUNCT-1K1 n"
            using A4 A6 A7 A8 A9 A10 sorry
        qed "sorry"
        thus "p1 =HIDDENR1 p2"
          using A4 A6 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef rfunct_3_def_9 (" _ is-common-for-domRFUNCT-3R1\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C)", "d be ElementSUBSET-1M1-of D"
"pred d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f means
   for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 n)"..

mtheorem rfunct_3_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f & n <>HIDDENR2 0NUMBERSK6 implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,C))\<^esub> n"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,D2) holds  for d1 be ElementSUBSET-1M1-of D1 holds  for n be NatNAT-1M1 holds d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f & n <>HIDDENR2 0NUMBERSK6 implies d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,D2)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f"
      and A2: "n <>HIDDENR2 0NUMBERSK6"
    have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n) implies d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume A3: "m inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n)"
      let ?G = "(f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m"
      show "d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
      proof-
        have cases: "n >=XXREAL-0R2 lenFINSEQ-1K4 f or n <XXREAL-0R3 lenFINSEQ-1K4 f"
           sorry
        have case1: "n >=XXREAL-0R2 lenFINSEQ-1K4 f implies d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
        proof(rule impI)
          assume "n >=XXREAL-0R2 lenFINSEQ-1K4 f"
          then have "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n =FINSEQ-1R1 f"
            using rfunct_3_lm_1 sorry
          thus "d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
            using A1 A3 sorry
        qed
        have case2: "n <XXREAL-0R3 lenFINSEQ-1K4 f implies d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
        proof(rule impI)
          assume A4: "n <XXREAL-0R3 lenFINSEQ-1K4 f"
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using A2 nat_1_th_13 sorry
          then have A5: "n inTARSKIR2 domFINSEQ-1K5 f"
            using A4 finseq_3_th_25 sorry
          have "domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n)) & lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n) =COMPLEX1R1 n"
            using A4 finseq_1_th_59 finseq_1_def_3 sorry
          then have "?G =FUNCT-1R1 f .FUNCT-1K1 m & m inTARSKIR2 domFINSEQ-1K5 f"
            using A3 A5 rfinseq_th_6 sorry
          thus "d1 inTARSKIR2 domRELAT-1K1 ((f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
            using A1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n"
      using rfunct_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,C) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,C)\<^esub> f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D,C))\<^esub> n"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,D2) holds  for d1 be ElementSUBSET-1M1-of D1 holds  for n be NatNAT-1M1 holds d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f implies d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,D2)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f"
    have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n) implies d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      let ?fn = "f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n"
      assume A2: "m inTARSKIR2 domFINSEQ-1K5 ?fn"
      let ?G = "?fn .FUNCT-1K1 m"
      have "lenFINSEQ-1K4 f <XXREAL-0R3 n & d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m) or n <=XXREAL-0R1 lenFINSEQ-1K4 f & (n <=XXREAL-0R1 lenFINSEQ-1K4 f implies d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m))"
      proof-
        show "lenFINSEQ-1K4 f <XXREAL-0R3 n & d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m) or n <=XXREAL-0R1 lenFINSEQ-1K4 f & (n <=XXREAL-0R1 lenFINSEQ-1K4 f implies d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m))"
        proof-
          have cases: "lenFINSEQ-1K4 f <XXREAL-0R3 n or n <=XXREAL-0R1 lenFINSEQ-1K4 f"
             sorry
          have case1: "lenFINSEQ-1K4 f <XXREAL-0R3 n implies d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
          proof(rule impI)
            assume "lenFINSEQ-1K4 f <XXREAL-0R3 n"
            thus "d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
              using A2 relat_1_th_38 rfinseq_def_1 sorry
          qed
          have case2: "n <=XXREAL-0R1 lenFINSEQ-1K4 f implies d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
          proof(rule impI)
            assume A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
            have "\<one>\<^sub>M <=XXREAL-0R1 m & m <=XXREAL-0R1 m +XCMPLX-0K2 n"
              using A2 finseq_3_th_25 nat_1_th_11 sorry
            then have A4: "\<one>\<^sub>M <=XXREAL-0R1 m +XCMPLX-0K2 n"
              using xxreal_0_th_2 sorry
            have A5: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?fn"
              using A2 finseq_3_th_25 sorry
            have "lenFINSEQ-1K4 ?fn =COMPLEX1R1 lenFINSEQ-1K4 f -XCMPLX-0K6 n"
              using A3 rfinseq_def_1 sorry
            then have "m +XCMPLX-0K2 n <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A5 xreal_1_th_19 sorry
            then have A6: "m +XCMPLX-0K2 n inTARSKIR2 domFINSEQ-1K5 f"
              using A4 finseq_3_th_25 sorry
            have "?G =FUNCT-1R1 f .FUNCT-1K1 (m +XCMPLX-0K2 n)"
              using A2 A3 rfinseq_def_1 sorry
            thus "d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
              using A1 A6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "d1 inTARSKIR2 domRELAT-1K1 ((f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n).FUNCT-1K1 m)"
         sorry
    qed "sorry"
    thus "d1 is-common-for-domRFUNCT-3R1\<^bsub>(D1,D2)\<^esub> f /^RFINSEQK2\<^bsub>(PFuncsRFUNCT-3K3(D1,D2))\<^esub> n"
      using rfunct_3_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f iff d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies  not (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f &  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) &  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f &  not d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    let ?P = "\<lambda>Lamb1.  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 Lamb1 & lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f iff d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f)"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
    assume A1: "lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 n & lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f iff d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f)) implies ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6 implies  not (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f &  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) &  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f &  not d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f))"
      proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "?P(n)"
        fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
        assume A4: "lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          and "lenFINSEQ-1K4 f <>HIDDENR2 0NUMBERSK6"
        have A5: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
          using finseq_1_def_3 sorry
        have "n =COMPLEX1R1 0NUMBERSK6 & ((d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f))"
        proof-
          show "n =COMPLEX1R1 0NUMBERSK6 & ((d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f))"
          proof-
            have cases: "n =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "n =COMPLEX1R1 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)"
            proof(rule impI,rule conjMI,rule impI)
              assume A6: "n =COMPLEX1R1 0NUMBERSK6"
              then have A7: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                using A4 finseq_3_th_25 sorry
              then obtain G where 
                [ty]:"G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and GDef:"G = f .FUNCT-1K1 \<one>\<^sub>M"
                using finseq_2_th_11 sorry
              have "f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>"
                using A4 A6 finseq_1_th_40 sorry
              then have A8: "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
                using finsop_1_th_11 sorry
              thus "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
                using A7 sorry
              assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
              then have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                using A4 A5 A6 A8 finseq_1_th_2 tarski_def_1 sorry
              thus "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
                 sorry
            qed
            have case2: "n <>HIDDENR2 0NUMBERSK6 implies (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)"
            proof(rule impI,rule conjMI,rule impI)
              assume A9: "n <>HIDDENR2 0NUMBERSK6"
              have A10: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_11 sorry
              have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using A9 nat_1_th_13 sorry
              then have A11: "n inTARSKIR2 domFINSEQ-1K5 f"
                using A4 A10 finseq_3_th_25 sorry
              have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              then have A12: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
                using A4 finseq_3_th_25 sorry
              then obtain G where 
                [ty]:"G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and GDef:"G = f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                using finseq_2_th_11 sorry
              let ?fn = "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n"
              have A13: "lenFINSEQ-1K4 ?fn =COMPLEX1R1 n"
                using A4 finseq_1_th_59 nat_1_th_11 sorry
              have "f =FINSEQ-1R1 ?fn ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)"
                using A4 rfinseq_th_7 sorry
              then have A14: "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
                using rfunct_3_th_20 sorry
              show "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
              proof(rule impI)
                assume A15: "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
                then have "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> ?fn"
                  using A9 rfunct_3_th_26 sorry
                then have A16: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn"
                  using A3 A9 A13 sorry
                have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> G"
                  using A12 A15 sorry
                then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> G"
                  using A16 xboole_0_def_4 sorry
                thus "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
                  using A14 valued_1_def_1 sorry
              qed
              assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f"
              then have A17: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> G"
                using A14 valued_1_def_1 sorry
              then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn"
                using xboole_0_def_4 sorry
              then have A18: "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> ?fn"
                using A3 A9 A13 sorry
              have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
              proof(rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A19: "m inTARSKIR2 domFINSEQ-1K5 f"
                let ?F = "f .FUNCT-1K1 m"
                have A20: "m <=XXREAL-0R1 lenFINSEQ-1K4 f"
                  using A19 finseq_3_th_25 sorry
                have A21: "\<one>\<^sub>M <=XXREAL-0R1 m"
                  using A19 finseq_3_th_25 sorry
                have "m =COMPLEX1R1 lenFINSEQ-1K4 f & d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m) or m <>HIDDENR2 lenFINSEQ-1K4 f & (m <>HIDDENR2 lenFINSEQ-1K4 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m))"
                proof-
                  show "m =COMPLEX1R1 lenFINSEQ-1K4 f & d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m) or m <>HIDDENR2 lenFINSEQ-1K4 f & (m <>HIDDENR2 lenFINSEQ-1K4 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m))"
                  proof-
                    have cases: "m =COMPLEX1R1 lenFINSEQ-1K4 f or m <>HIDDENR2 lenFINSEQ-1K4 f"
                       sorry
                    have case1: "m =COMPLEX1R1 lenFINSEQ-1K4 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                    proof(rule impI)
                      assume "m =COMPLEX1R1 lenFINSEQ-1K4 f"
                      thus "d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                        using A4 A17 xboole_0_def_4 sorry
                    qed
                    have case2: "m <>HIDDENR2 lenFINSEQ-1K4 f implies d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                    proof(rule impI)
                      assume "m <>HIDDENR2 lenFINSEQ-1K4 f"
                      then have "m <XXREAL-0R3 lenFINSEQ-1K4 f"
                        using A20 xxreal_0_th_1 sorry
                      then have "m <=XXREAL-0R1 n"
                        using A4 nat_1_th_13 sorry
                      then have A22: "m inTARSKIR2 SegFINSEQ-1K2 n"
                        using A21 finseq_1_th_1 sorry
                      then have "domFINSEQ-1K5 ?fn =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fn) & ?F =FUNCT-1R1 ?fn .FUNCT-1K1 m"
                        using A11 finseq_1_def_3 rfinseq_th_6 sorry
                      thus "d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                        using A13 A18 A22 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "d inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 m)"
                   sorry
              qed "sorry"
              thus "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " not (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f &  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) &  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f &  not d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A23: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A23 A2 sorry
    thus " not (d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f &  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f) &  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> f &  not d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds  for n be NatNAT-1M1 holds f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D)\<^esub> d =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
proof-
  have " for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,REALNUMBERSK2) holds  for d1 be ElementSUBSET-1M1-of D1 holds  for n be NatNAT-1M1 holds f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D1,REALNUMBERSK2)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) =COMPLEX1R1 lenFINSEQ-1K4 f"
      using rfunct_3_def_8 sorry
    have A2: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) =COMPLEX1R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n)"
      using rfunct_3_def_8 sorry
    have "lenFINSEQ-1K4 f <=XXREAL-0R1 n & f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n or n <XXREAL-0R3 lenFINSEQ-1K4 f & (n <XXREAL-0R3 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)"
    proof-
      show "lenFINSEQ-1K4 f <=XXREAL-0R1 n & f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n or n <XXREAL-0R3 lenFINSEQ-1K4 f & (n <XXREAL-0R3 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      proof-
        have cases: "lenFINSEQ-1K4 f <=XXREAL-0R1 n or n <XXREAL-0R3 lenFINSEQ-1K4 f"
           sorry
        have case1: "lenFINSEQ-1K4 f <=XXREAL-0R1 n implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume A3: "lenFINSEQ-1K4 f <=XXREAL-0R1 n"
          then have "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n =FINSEQ-1R1 f"
            using rfunct_3_lm_1 sorry
          thus "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
            using A1 A3 rfunct_3_lm_1 sorry
        qed
        have case2: "n <XXREAL-0R3 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
        proof(rule impI)
          assume A4: "n <XXREAL-0R3 lenFINSEQ-1K4 f"
          then have A5: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n) =COMPLEX1R1 n"
            using finseq_1_th_59 sorry
          have A6: "lenFINSEQ-1K4 ((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n) =COMPLEX1R1 n"
            using A1 A4 finseq_1_th_59 sorry
          have A7: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) & domFINSEQ-1K5 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1))"
            using finseq_1_def_3 sorry
          have A8: "domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1))"
            using finseq_1_def_3 sorry
          have "n =COMPLEX1R1 0NUMBERSK6 & f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)"
          proof-
            show "n =COMPLEX1R1 0NUMBERSK6 & f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)"
            proof-
              have cases: "n =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
                 sorry
              have case1: "n =COMPLEX1R1 0NUMBERSK6 implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
              proof(rule impI)
                assume A9: "n =COMPLEX1R1 0NUMBERSK6"
                show "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
                  using A2 A9 sorry
              qed
              have case2: "n <>HIDDENR2 0NUMBERSK6 implies f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
              proof(rule impI)
                assume A10: "n <>HIDDENR2 0NUMBERSK6"
                have A11: "domFINSEQ-1K5 ((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n))"
                  using A5 A6 finseq_1_def_3 sorry
                have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using A10 nat_1_th_13 sorry
                then have A12: "n inTARSKIR2 domFINSEQ-1K5 f"
                  using A4 finseq_3_th_25 sorry
                have " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 ((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 m =COMPLEX1R1 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1).FUNCT-1K1 m"
                proof(rule ballI,rule impI)
                  fix m assume [ty]: "m be NatNAT-1M1"
                  assume A13: "m inTARSKIR2 domFINSEQ-1K5 ((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)"
                  then have A14: "m inTARSKIR2 domFINSEQ-1K5 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1)"
                    using A1 A5 A7 A12 A11 rfinseq_th_6 sorry
                  then obtain G where 
                    [ty]:"G be ElementRFUNCT-3M3\<^bsub>(D1,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D1,REALNUMBERSK2)" and GDef:"G = f .FUNCT-1K1 m"
                    using A1 A7 finseq_2_th_11 sorry
                  have "((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 m =COMPLEX1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1).FUNCT-1K1 m"
                    using A1 A5 A7 A12 A11 A13 rfinseq_th_6 sorry
                  then have A15: "((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 m =COMPLEX1R1 G .FUNCT-1K1 d1"
                    using A14 rfunct_3_def_8 sorry
                  have "(f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n).FUNCT-1K1 m =FUNCT-1R1 G"
                    using A5 A12 A11 A13 rfinseq_th_6 sorry
                  thus "((f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 m =COMPLEX1R1 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1).FUNCT-1K1 m"
                    using A2 A8 A11 A13 A15 rfunct_3_def_8 sorry
                qed "sorry"
                thus "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
                  using A2 A5 A6 finseq_2_th_9 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D1,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1 =FINSEQ-1R1 (f #RFUNCT-3K17\<^bsub>(D1)\<^esub> d1) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds  for d be ElementSUBSET-1M1-of D holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> CHIRFUNCT-3K15(f,D)"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 (CHIRFUNCT-3K15(f,D)) implies d inTARSKIR2 domRELAT-1K1 (CHIRFUNCT-3K15(f,D) .FUNCT-1K1 n)"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n inTARSKIR2 domFINSEQ-1K5 (CHIRFUNCT-3K15(f,D))"
    then have "CHIRFUNCT-3K15(f,D) .FUNCT-1K1 n =FUNCT-1R1 chiRFUNCT-1K7(f .FUNCT-1K1 n,D)"
      using rfunct_3_def_6 sorry
    then have "domRELAT-1K1 (CHIRFUNCT-3K15(f,D) .FUNCT-1K1 n) =XBOOLE-0R4 D"
      using rfunct_1_th_61 sorry
    thus "d inTARSKIR2 domRELAT-1K1 (CHIRFUNCT-3K15(f,D) .FUNCT-1K1 n)"
       sorry
  qed "sorry"
  thus "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> CHIRFUNCT-3K15(f,D)"
    using rfunct_3_def_9 sorry
qed "sorry"

mtheorem rfunct_3_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds  for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  fix R assume [ty]: "R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
  assume A1: "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
  let ?m = "minNAT-1K4(lenFINSEQ-1K4 R,lenFINSEQ-1K4 f)"
  have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 (R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f) implies d inTARSKIR2 domRELAT-1K1 ((R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f).FUNCT-1K1 n)"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A2: "n inTARSKIR2 domFINSEQ-1K5 (R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f)"
    let ?G = "(R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f).FUNCT-1K1 n"
    have "lenFINSEQ-1K4 (R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f) =COMPLEX1R1 ?m"
      using rfunct_3_def_7 sorry
    then have "?m <=XXREAL-0R1 lenFINSEQ-1K4 f & n <=XXREAL-0R1 ?m"
      using A2 finseq_3_th_25 xxreal_0_th_17 sorry
    then have A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using xxreal_0_th_2 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 n"
      using A2 finseq_3_th_25 sorry
    then have A4: "n inTARSKIR2 domFINSEQ-1K5 f"
      using A3 finseq_3_th_25 sorry
    then obtain F where 
      [ty]:"F be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and FDef:"F = f .FUNCT-1K1 n"
      using finseq_2_th_11 sorry
    have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using A1 A4 sorry
    obtain r where 
      [ty]:"r be RealXREAL-0M1" and rDef:"r = R .FUNCT-1K1 n"
       sorry
    have "?G =FUNCT-1R1 r (#)RFUNCT-3K12\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A2 rfunct_3_def_7 sorry
    thus "d inTARSKIR2 domRELAT-1K1 ((R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f).FUNCT-1K1 n)"
      using A5 valued_1_def_5 sorry
  qed "sorry"
  thus "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> f"
    using rfunct_3_def_9 sorry
qed "sorry"

mtheorem rfunct_3_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M1 holds  for R be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for d be ElementSUBSET-1M1-of D holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> R (#)RFUNCT-3K16\<^bsub>(D)\<^esub> CHIRFUNCT-3K15(f,D)"
  using rfunct_3_th_30 rfunct_3_th_31 sorry

mtheorem rfunct_3_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  let ?P = "\<lambda>Lamb1.  for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 Lamb1 & d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
  assume A1: "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
  have A2: "lenFINSEQ-1K4 f =COMPLEX1R1 lenFINSEQ-1K4 f"
     sorry
  have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for n be NatNAT-1M1 holds ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 n & d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)) implies ( for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d))"
    proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A4: "?P(n)"
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      assume A5: "lenFINSEQ-1K4 f =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
        and A6: "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
      let ?fn = "f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n"
      have A7: "lenFINSEQ-1K4 ?fn =COMPLEX1R1 n"
        using A5 finseq_1_th_59 nat_1_th_11 sorry
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have A8: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using A5 finseq_3_th_25 sorry
      then obtain G where 
        [ty]:"G be ElementRFUNCT-3M3\<^bsub>(D,REALNUMBERSK2)\<^esub>-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)" and GDef:"G = f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using finseq_2_th_11 sorry
      have A9: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) & domFINSEQ-1K5 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d))"
        using finseq_1_def_3 sorry
      have "f =FINSEQ-1R1 ?fn ^FINSEQ-1K9\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> (<*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>)"
        using A5 rfinseq_th_7 sorry
      then have A10: "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G"
        using rfunct_3_th_20 sorry
      have A11: "lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) =COMPLEX1R1 lenFINSEQ-1K4 f"
        using rfunct_3_def_8 sorry
      have A12: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> G"
        using A6 A8 sorry
      have "n =COMPLEX1R1 0NUMBERSK6 & SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d))"
      proof-
        show "n =COMPLEX1R1 0NUMBERSK6 & SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) or n <>HIDDENR2 0NUMBERSK6 & (n <>HIDDENR2 0NUMBERSK6 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d))"
        proof-
          have cases: "n =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
             sorry
          have case1: "n =COMPLEX1R1 0NUMBERSK6 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
          proof(rule impI)
            assume A13: "n =COMPLEX1R1 0NUMBERSK6"
            then have A14: "lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) =COMPLEX1R1 \<one>\<^sub>M"
              using A5 rfunct_3_def_8 sorry
            then have A15: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
              using finseq_3_th_25 sorry
            have A16: " for m be NatNAT-1M1 holds m inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M implies (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d).FUNCT-1K1 m =HIDDENR1 (<*FINSEQ-1K10 G .FUNCT-1K1 d*>).FUNCT-1K1 m"
            proof(rule ballI,rule impI)
              fix m assume [ty]: "m be NatNAT-1M1"
              assume "m inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
              then have A17: "m =COMPLEX1R1 \<one>\<^sub>M"
                using finseq_1_th_2 tarski_def_1 sorry
              then have "(f #RFUNCT-3K17\<^bsub>(D)\<^esub> d).FUNCT-1K1 m =HIDDENR1 G .FUNCT-1K1 d"
                using A13 A15 rfunct_3_def_8 sorry
              also have "... = (<*FINSEQ-1K10 G .FUNCT-1K1 d*>).FUNCT-1K1 m"
                using A17 finseq_1_th_40 sorry
              finally show "(f #RFUNCT-3K17\<^bsub>(D)\<^esub> d).FUNCT-1K1 m =HIDDENR1 (<*FINSEQ-1K10 G .FUNCT-1K1 d*>).FUNCT-1K1 m"
                 sorry
            qed "sorry"
            have "lenFINSEQ-1K4 (<*FINSEQ-1K10 G .FUNCT-1K1 d*>) =COMPLEX1R1 \<one>\<^sub>M & domFINSEQ-1K5 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) =MEMBEREDR12 SegFINSEQ-1K2 \<one>\<^sub>M"
              using A14 finseq_1_th_40 finseq_1_def_3 sorry
            then have A18: "f #RFUNCT-3K17\<^bsub>(D)\<^esub> d =FINSEQ-1R1 <*FINSEQ-1K10 G .FUNCT-1K1 d*>"
              using A14 A16 finseq_2_th_9 sorry
            have A19: "G .FUNCT-1K1 d inTARSKIR2 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            have "f =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> G*>"
              using A5 A13 finseq_1_th_40 sorry
            then have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 G .FUNCT-1K1 d"
              using finsop_1_th_11 sorry
            also have "... = SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
              using A18 A19 finsop_1_th_11 sorry
            finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
               sorry
          qed
          have case2: "n <>HIDDENR2 0NUMBERSK6 implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
          proof(rule impI)
            assume A20: "n <>HIDDENR2 0NUMBERSK6"
            have A21: "(f #RFUNCT-3K17\<^bsub>(D)\<^esub> d).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 G .FUNCT-1K1 d"
              using A9 A11 A8 rfunct_3_def_8 sorry
            have "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> ?fn"
              using A6 A20 rfunct_3_th_26 sorry
            then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn"
              using A7 A20 rfunct_3_th_28 sorry
            then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> G"
              using A12 xboole_0_def_4 sorry
            then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (SumRFUNCT-3K14\<^bsub>(D)\<^esub> ?fn +RFUNCT-3K5\<^bsub>(D,REALNUMBERSK2)\<^esub> G)"
              using valued_1_def_1 sorry
            then have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRFUNCT-3K14\<^bsub>(D)\<^esub> (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n) .FUNCT-1K1 d +XCMPLX-0K2 G .FUNCT-1K1 d"
              using A10 valued_1_def_1 sorry
            also have "... = SumRVSUM-1K22 (f  |FINSEQ-1K18\<^bsub>(PFuncsRFUNCT-3K3(D,REALNUMBERSK2))\<^esub> n #RFUNCT-3K17\<^bsub>(D)\<^esub> d) +XCMPLX-0K2 G .FUNCT-1K1 d"
              using A4 A6 A7 A20 rfunct_3_th_26 sorry
            also have "... = SumRVSUM-1K22 ((f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n) +XCMPLX-0K2 G .FUNCT-1K1 d"
              using rfunct_3_th_29 sorry
            also have "... = SumRVSUM-1K20 ((f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 G .FUNCT-1K1 d*>))"
              using rvsum_1_th_74 sorry
            also have "... = SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
              using A5 A11 A21 rfinseq_th_7 sorry
            finally show "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A22: "?P(0NUMBERSK6)"
  proof-
    have " for f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2) holds lenFINSEQ-1K4 f =COMPLEX1R1 0NUMBERSK6 & d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f implies SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
    proof(rule ballI,rule impMI ,rule impI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of PFuncsRFUNCT-3K3(D,REALNUMBERSK2)"
      assume A23: "lenFINSEQ-1K4 f =COMPLEX1R1 0NUMBERSK6"
        and "d is-common-for-domRFUNCT-3R1\<^bsub>(D,REALNUMBERSK2)\<^esub> f"
      have "f =FINSEQ-1R1 <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2))"
        using A23 sorry
      then have A24: "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 ([#]SUBSET-1K2 D -->FUNCOP-1K7 0NUMBERSK6).FUNCT-1K1 d"
        using rfunct_3_th_19 sorry
      also have "... = 0NUMBERSK6"
        using funcop_1_th_7 sorry
      finally have "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =HIDDENR1 0NUMBERSK6"
         sorry
      have "lenFINSEQ-1K4 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d) =COMPLEX1R1 0NUMBERSK6"
        using A23 rfunct_3_def_8 sorry
      then have "f #RFUNCT-3K17\<^bsub>(D)\<^esub> d =FINSEQ-1R1 <*>FINSEQ-1K7 (PFuncsRFUNCT-3K3(D,REALNUMBERSK2))"
         sorry
      thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
        using A24 rvsum_1_th_72 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A22 A3 sorry
  thus "SumRFUNCT-3K14\<^bsub>(D)\<^esub> f .FUNCT-1K1 d =COMPLEX1R1 SumRVSUM-1K22 (f #RFUNCT-3K17\<^bsub>(D)\<^esub> d)"
    using A1 A2 sorry
qed "sorry"

mdef rfunct_3_def_10 ("max+RFUNCT-3K18\<^bsub>'( _ ')\<^esub>  _ " [0,300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
    proof-
      have " ex tVar8 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar8 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar8 implies tVar8 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
      proof-
        let ?Q = "\<lambda>Lamb1. InSUBSET-1K10(max+RFUNCT-3K1 (F .FUNCT-1K1 Lamb1),REALNUMBERSK2)"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f iff ?P(d)"and A2: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 d =COMPLEX1R1 ?Q(d)"
          using seq_1_sch_3 sorry
        show " ex tVar8 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar8 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar8 implies tVar8 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
          show "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          proof-
            have "domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F & domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            proof(rule conjMI)
              show "domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                using A1 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F implies x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                  using A1 sorry
              qed "sorry"
              thus "domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                using tarski_def_3 sorry
            qed
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
              using xboole_0_def_10 sorry
          qed
          fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
          assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f"
          then have "f .FUNCT-1K1 d =COMPLEX1R1 ?Q(d)"
            using A2 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d))) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for VarFor2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((((domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 &  not VarFor1 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)))) & domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F) & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 &  not VarFor2 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?F = "\<lambda>Lamb1. max+RFUNCT-3K1 (F .FUNCT-1K1 Lamb1)"
        have " for f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for c be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 c =COMPLEX1R1 ?F(c))) & (domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for c be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> g implies g .FUNCT-1K1 c =COMPLEX1R1 ?F(c))) implies f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> g"
          using seq_1_sch_4 sorry
        thus " for VarFor1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for VarFor2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((((domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 &  not VarFor1 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)))) & domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F) & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 &  not VarFor2 .FUNCT-1K1 d =COMPLEX1R1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef rfunct_3_def_11 ("max-RFUNCT-3K19\<^bsub>'( _ ')\<^esub>  _ " [0,300]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"func max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<rightarrow> PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> it =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it implies it .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
    proof-
      have " ex tVar9 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 implies tVar9 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
      proof-
        let ?F = "\<lambda>Lamb1. InSUBSET-1K10(max-RFUNCT-3K2 (F .FUNCT-1K1 Lamb1),REALNUMBERSK2)"
        let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)" and 
          A3: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f iff ?P(d)"and A4: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 d =COMPLEX1R1 ?F(d)"
          using seq_1_sch_3 sorry
        show " ex tVar9 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> tVar9 implies tVar9 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
          show "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          proof-
            have "domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F & domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
            proof(rule conjMI)
              show "domRELSET-1K1\<^bsub>(D)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                using A3 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F implies x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                  using A3 sorry
              qed "sorry"
              thus "domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> f"
                using tarski_def_3 sorry
            qed
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
              using xboole_0_def_10 sorry
          qed
          fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
          assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f"
          then have "f .FUNCT-1K1 d =COMPLEX1R1 ?F(d)"
            using A4 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> it1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it1 implies it1 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))) & (domRELSET-1K1\<^bsub>(D)\<^esub> it2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> it2 implies it2 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d))) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for VarFor2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((((domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 &  not VarFor1 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)))) & domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F) & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 &  not VarFor2 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?F = "\<lambda>Lamb1. max-RFUNCT-3K2 (F .FUNCT-1K1 Lamb1)"
        have " for f be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for g be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(D)\<^esub> f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for c be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> f implies f .FUNCT-1K1 c =COMPLEX1R1 ?F(c))) & (domRELSET-1K1\<^bsub>(D)\<^esub> g =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for c be ElementSUBSET-1M1-of D holds c inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> g implies g .FUNCT-1K1 c =COMPLEX1R1 ?F(c))) implies f =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> g"
          using seq_1_sch_4 sorry
        thus " for VarFor1 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for VarFor2 be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((((domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor1 &  not VarFor1 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)))) & domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F) & ( for d be ElementSUBSET-1M1-of D holds  not (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> VarFor2 &  not VarFor2 .FUNCT-1K1 d =COMPLEX1R1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem rfunct_3_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds (F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F & absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F) & \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F & (absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F & \<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
  proof(rule ballI,rule ballI,rule conjMI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F"
       sorry
    have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using rfunct_3_def_10 sorry
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using rfunct_3_def_11 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
      using valued_1_def_5 sorry
    then have A4: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F))"
      using A2 A3 A1 valued_1_def_1 sorry
    have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      then have "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d -XCMPLX-0K6 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A4 valued_1_th_13 sorry
      also have "... = max+RFUNCT-3K1 (F .FUNCT-1K1 d) -XCMPLX-0K6 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A2 A5 rfunct_3_def_10 sorry
      also have "... = max+RFUNCT-3K1 (F .FUNCT-1K1 d) -XCMPLX-0K6 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
        using A3 A5 rfunct_3_def_11 sorry
      also have "... = F .FUNCT-1K1 d"
        using rfunct_3_th_1 sorry
      finally show "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
         sorry
    qed "sorry"
    thus "F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
      using A4 partfun1_th_5 sorry
    have A6: "domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using valued_1_def_11 sorry
    then have A7: "domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F)"
      using A2 A3 A1 valued_1_def_1 sorry
    have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F implies (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume A8: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      then have "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d +XCMPLX-0K2 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A7 valued_1_def_1 sorry
      also have "... = max+RFUNCT-3K1 (F .FUNCT-1K1 d) +XCMPLX-0K2 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A2 A6 A8 rfunct_3_def_10 sorry
      also have "... = max+RFUNCT-3K1 (F .FUNCT-1K1 d) +XCMPLX-0K2 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
        using A3 A6 A8 rfunct_3_def_11 sorry
      also have "... =  |.COMPLEX1K10 F .FUNCT-1K1 d.|"
        using rfunct_3_th_2 sorry
      also have "... = absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 d"
        using valued_1_th_18 sorry
      finally show "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 d"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
      using A7 partfun1_th_5 sorry
    have A9: "domRELSET-1K1\<^bsub>(D)\<^esub> (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F"
      using valued_1_def_5 sorry
    then have A10: "domRELSET-1K1\<^bsub>(D)\<^esub> (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
      using A2 A6 A1 valued_1_def_1 sorry
    have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies (\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume A11: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      then have "(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A2 A9 valued_1_def_5 sorry
      also have "... = \<two>\<^sub>M *XCMPLX-0K3 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
        using A2 A11 rfunct_3_def_10 sorry
      also have "... = F .FUNCT-1K1 d +XCMPLX-0K2  |.COMPLEX1K10 F .FUNCT-1K1 d.|"
        using rfunct_3_th_3 sorry
      also have "... = F .FUNCT-1K1 d +XCMPLX-0K2 absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F .FUNCT-1K1 d"
        using valued_1_th_18 sorry
      also have "... = (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
        using A2 A9 A10 A11 valued_1_def_1 sorry
      finally show "(\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F).FUNCT-1K1 d =HIDDENR1 (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
         sorry
    qed "sorry"
    thus "\<two>\<^sub>M (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
      using A2 A9 A10 partfun1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_10 sorry
  assume A2: "0NUMBERSK6 <XXREAL-0R3 r"
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} & max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} implies x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
          using A3 funct_1_def_7 sorry
        then have A4: "F .FUNCT-1K1 d =COMPLEX1R1 r"
          using tarski_def_1 sorry
        have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A3 funct_1_def_7 sorry
        then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
          using A1 rfunct_3_def_10 sorry
        also have "... = r"
          using A2 A4 xxreal_0_def_10 sorry
        finally have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 r"
           sorry
        then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
          using A1 A5 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
        using A6 funct_1_def_7 sorry
      then have A7: "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 r"
        using tarski_def_1 sorry
      have A8: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A1 A6 funct_1_def_7 sorry
      then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_10 sorry
      also have "... = maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      then have "F .FUNCT-1K1 d =COMPLEX1R1 r"
        using A2 A7 xxreal_0_th_16 sorry
      then have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof(rule ballI,rule ballI)
  let ?li = "left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_10 sorry
  have A2: "?li =XBOOLE-0R4 {s where s be RealXREAL-0M1 : s <=XXREAL-0R1 0NUMBERSK6 }"
    using xxreal_1_th_231 sorry
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6))"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) implies x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?li"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "F .FUNCT-1K1 d inTARSKIR2 ?li"
          using A3 funct_1_def_7 sorry
        then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 F .FUNCT-1K1 d & s <=XXREAL-0R1 0NUMBERSK6"
          using A2 sorry
        then have A4: "maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A3 funct_1_def_7 sorry
        then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
          using A1 rfunct_3_def_10 sorry
        also have "... = maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
           sorry
        finally have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
           sorry
        then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A4 tarski_def_1 sorry
        thus "x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using A1 A5 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) c=TARSKIR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using A6 funct_1_def_7 sorry
      then have A7: "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      have A8: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A1 A6 funct_1_def_7 sorry
      then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_10 sorry
      also have "... = maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      then have "F .FUNCT-1K1 d <=XXREAL-0R1 0NUMBERSK6"
        using A7 xxreal_0_def_10 sorry
      then have "F .FUNCT-1K1 d inTARSKIR2 ?li"
        using A2 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6))"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6))"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)) =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds 0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_10 sorry
  show "0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
  proof-
    have cases: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F or  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
       sorry
    have case1: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies 0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
    proof(rule impI)
      assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      then have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_10 sorry
      also have "... = maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using xxreal_0_th_25 sorry
    qed
    have case2: " not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies 0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
    proof(rule impI)
      assume " not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      thus "0NUMBERSK6 <=XXREAL-0R1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A1 funct_1_def_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rfunct_3_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_11 sorry
  assume A2: "0NUMBERSK6 <XXREAL-0R3 r"
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} & max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r }"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } implies x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r }"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 -XCMPLX-0K4 r }"
          using A3 funct_1_def_7 sorry
        then have A4: "F .FUNCT-1K1 d =COMPLEX1R1 -XCMPLX-0K4 r"
          using tarski_def_1 sorry
        have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A3 funct_1_def_7 sorry
        then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
          using A1 rfunct_3_def_11 sorry
        also have "... = r"
          using A2 A4 xxreal_0_def_10 sorry
        finally have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 r"
           sorry
        then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
          using A1 A5 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 r}"
        using A6 funct_1_def_7 sorry
      then have A7: "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 r"
        using tarski_def_1 sorry
      have A8: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A1 A6 funct_1_def_7 sorry
      then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_11 sorry
      also have "... = maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      then have "-XCMPLX-0K4 F .FUNCT-1K1 d =COMPLEX1R1 r"
        using A2 A7 xxreal_0_th_16 sorry
      then have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 -XCMPLX-0K4 r }"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r }"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r }"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 -XCMPLX-0K4 r } =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
proof(rule ballI,rule ballI)
  let ?li = "right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_11 sorry
  have A2: "?li =XBOOLE-0R4 {s where s be RealXREAL-0M1 : 0NUMBERSK6 <=XXREAL-0R1 s }"
    using xxreal_1_th_232 sorry
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6))"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) implies x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A3: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?li"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have "F .FUNCT-1K1 d inTARSKIR2 ?li"
          using A3 funct_1_def_7 sorry
        then have " ex s be RealXREAL-0M1 st s =COMPLEX1R1 F .FUNCT-1K1 d & 0NUMBERSK6 <=XXREAL-0R1 s"
          using A2 sorry
        then have A4: "maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
          using xxreal_0_def_10 sorry
        have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A3 funct_1_def_7 sorry
        then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
          using A1 rfunct_3_def_11 sorry
        also have "... = maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
           sorry
        finally have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
           sorry
        then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
          using A4 tarski_def_1 sorry
        thus "x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
          using A1 A5 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) c=TARSKIR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A6: "x inHIDDENR3 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 0NUMBERSK6 }"
        using A6 funct_1_def_7 sorry
      then have A7: "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 0NUMBERSK6"
        using tarski_def_1 sorry
      have A8: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A1 A6 funct_1_def_7 sorry
      then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_11 sorry
      also have "... = maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      then have "-XCMPLX-0K4 F .FUNCT-1K1 d <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
        using A7 xxreal_0_def_10 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 F .FUNCT-1K1 d"
        using xreal_1_th_24 sorry
      then have "F .FUNCT-1K1 d inTARSKIR2 ?li"
        using A2 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6))"
        using A8 funct_1_def_7 sorry
    qed "sorry"
    thus "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6))"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)) =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds 0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_11 sorry
  show "0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
  proof-
    have cases: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F or  not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
       sorry
    have case1: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies 0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
    proof(rule impI)
      assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      then have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
        using A1 rfunct_3_def_11 sorry
      also have "... = maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      finally have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 maxXXREAL-0K5(-XCMPLX-0K4 F .FUNCT-1K1 d,0NUMBERSK6)"
         sorry
      thus "0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using xxreal_0_th_25 sorry
    qed
    have case2: " not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies 0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
    proof(rule impI)
      assume " not d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      thus "0NUMBERSK6 <=XXREAL-0R1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
        using A1 funct_1_def_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem rfunct_3_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  let ?li = "left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
  have A2: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r))"
  proof(rule ballI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r)) or r =COMPLEX1R1 0NUMBERSK6 & (r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
    proof-
      show "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r)) or r =COMPLEX1R1 0NUMBERSK6 & (r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 r or r =COMPLEX1R1 0NUMBERSK6) or r <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r implies cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r))"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then have "CoimRELAT-1K13(F,r) =XBOOLE-0R4 CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r) & CoimRELAT-1K13(G,r) =XBOOLE-0R4 CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r)"
            using rfunct_3_th_35 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r))"
            using A1 classes1_def_10 sorry
        qed
        have case2: "r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume A3: "r =COMPLEX1R1 0NUMBERSK6"
          have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?li =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?li =XBOOLE-0R4 max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
            using rfunct_3_th_36 sorry
          thus "cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A1 A3 classes1_th_78 sorry
        qed
        have case3: "r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume A4: "r <XXREAL-0R3 0NUMBERSK6"
          have "r inTARSKIR2 rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F implies  False "
          proof(rule impI)
            assume "r inTARSKIR2 rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F"
            then have " ex d be ElementSUBSET-1M1-of D st d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F & max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 r"
              using partfun1_th_3 sorry
            thus " False "
              using A4 rfunct_3_th_37 sorry
          qed
          then have A5: "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 {}XBOOLE-0K1"
            using rfunct_3_lm_2 sorry
          have "r inTARSKIR2 rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(C)\<^esub> G implies  False "
          proof(rule impI)
            assume "r inTARSKIR2 rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(C)\<^esub> G"
            then have " ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> max+RFUNCT-3K18\<^bsub>(C)\<^esub> G & max+RFUNCT-3K18\<^bsub>(C)\<^esub> G .FUNCT-1K1 c =COMPLEX1R1 r"
              using partfun1_th_3 sorry
            thus " False "
              using A4 rfunct_3_th_37 sorry
          qed
          thus "cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A5 rfunct_3_lm_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r))"
       sorry
  qed "sorry"
  have "rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 max+RFUNCT-3K18\<^bsub>(C)\<^esub> G c=MEMBEREDR3 REALNUMBERSK2"
     sorry
  thus "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    using A2 classes1_th_79 sorry
qed "sorry"

mtheorem rfunct_3_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (F,G)are-fiberwise-equipotentCLASSES1R2 implies (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  let ?li = "right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  assume A1: "(F,G)are-fiberwise-equipotentCLASSES1R2"
  have A2: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r))"
  proof(rule ballI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
    have "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r)) or r =COMPLEX1R1 0NUMBERSK6 & (r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
    proof-
      show "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r)) or r =COMPLEX1R1 0NUMBERSK6 & (r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 r or r =COMPLEX1R1 0NUMBERSK6) or r <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r implies cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r))"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then have "CoimRELAT-1K13(F,-REAL-1K1 r) =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} & CoimRELAT-1K13(G,-REAL-1K1 r) =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}"
            using rfunct_3_th_38 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r))"
            using A1 classes1_def_10 sorry
        qed
        have case2: "r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume A3: "r =COMPLEX1R1 0NUMBERSK6"
          have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?li =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 } & G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?li =XBOOLE-0R4 max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
            using rfunct_3_th_39 sorry
          thus "cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A1 A3 classes1_th_78 sorry
        qed
        have case3: "r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume A4: "r <XXREAL-0R3 0NUMBERSK6"
          have "r inTARSKIR2 rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F implies  False "
          proof(rule impI)
            assume "r inTARSKIR2 rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
            then have " ex d be ElementSUBSET-1M1-of D st d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F & max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =COMPLEX1R1 r"
              using partfun1_th_3 sorry
            thus " False "
              using A4 rfunct_3_th_40 sorry
          qed
          then have A5: "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 {}XBOOLE-0K1"
            using rfunct_3_lm_2 sorry
          have "r inTARSKIR2 rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(C)\<^esub> G implies  False "
          proof(rule impI)
            assume "r inTARSKIR2 rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(C)\<^esub> G"
            then have " ex c be ElementSUBSET-1M1-of C st c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> max-RFUNCT-3K19\<^bsub>(C)\<^esub> G & max-RFUNCT-3K19\<^bsub>(C)\<^esub> G .FUNCT-1K1 c =COMPLEX1R1 r"
              using partfun1_th_3 sorry
            thus " False "
              using A4 rfunct_3_th_40 sorry
          qed
          thus "cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =XBOOLE-0R4 cardCARD-1K1 (max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A5 rfunct_3_lm_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,r))"
       sorry
  qed "sorry"
  have "rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 max-RFUNCT-3K19\<^bsub>(C)\<^esub> G c=MEMBEREDR3 REALNUMBERSK2"
     sorry
  thus "(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    using A2 classes1_th_79 sorry
qed "sorry"

mtheorem rfunct_3_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"cluster max+RFUNCT-3K18\<^bsub>(D)\<^esub> F as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
  proof-
    have "domRELSET-1K1\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
       sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
      using rfunct_3_def_10 sorry
    thus "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem rfunct_3_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
"cluster max-RFUNCT-3K19\<^bsub>(D)\<^esub> F as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
  proof-
    have "domRELSET-1K1\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
       sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
      using rfunct_3_def_11 sorry
    thus "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F be finiteFINSET-1V1"
      using finset_1_th_10 sorry
  qed
qed "sorry"

mtheorem rfunct_3_th_43:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2 & (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2 implies (F,G)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix G assume [ty]: "G be finiteFINSET-1V1\<bar>PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  assume A1: "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,max+RFUNCT-3K18\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
    and A2: "(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,max-RFUNCT-3K19\<^bsub>(C)\<^esub> G)are-fiberwise-equipotentCLASSES1R2"
  let ?lh = "left-closed-halflineLIMFUNC1K2 (0NUMBERSK6)"
  let ?rh = "right-closed-halflineLIMFUNC1K3 (0NUMBERSK6)"
  let ?fp0 = "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  let ?fm0 = "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  let ?gp0 = "max+RFUNCT-3K18\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  let ?gm0 = "max-RFUNCT-3K19\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 0NUMBERSK6 }"
  have A3: "?lh /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?rh =HIDDENR1 [.RCOMP-1K1 0NUMBERSK6,0NUMBERSK6 .]"
    using xxreal_1_th_272 sorry
  also have "... = {TARSKIK1 0NUMBERSK6 }"
    using xxreal_1_th_17 sorry
  finally have "?lh /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?rh =HIDDENR1 {TARSKIK1 0NUMBERSK6 }"
     sorry
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> (rngRVSUM-1K1 F) c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using relat_1_th_143 sorry
  then have A4: "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F & domRELSET-1K1\<^bsub>(D)\<^esub> F c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using relat_1_th_132 relat_1_th_134 sorry
  have A5: "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?lh =XBOOLE-0R4 ?fp0 & F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?rh =XBOOLE-0R4 ?fm0"
    using rfunct_3_th_36 rfunct_3_th_39 sorry
  have "G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> (rngRVSUM-1K1 G) c=TARSKIR1 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using relat_1_th_143 sorry
  then have A6: "G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> G & domRELSET-1K1\<^bsub>(C)\<^esub> G c=TARSKIR1 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using relat_1_th_132 relat_1_th_134 sorry
  have A7: "G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?lh =XBOOLE-0R4 ?gp0 & G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?rh =XBOOLE-0R4 ?gm0"
    using rfunct_3_th_36 rfunct_3_th_39 sorry
  obtain fp0 fm0 gp0 gm0 where 
    [ty]:"fp0 be finiteFINSET-1V1\<bar>setHIDDENM2" and fp0Def:"fp0 = ?fp0" and
    [ty]:"fm0 be finiteFINSET-1V1\<bar>setHIDDENM2" and fm0Def:"fm0 = ?fm0" and
    [ty]:"gp0 be finiteFINSET-1V1\<bar>setHIDDENM2" and gp0Def:"gp0 = ?gp0" and
    [ty]:"gm0 be finiteFINSET-1V1\<bar>setHIDDENM2" and gm0Def:"gm0 = ?gm0"
     sorry
  have A8: "?lh \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ?rh =HIDDENR1 REALNUMBERSK2 \\SUBSET-1K6 ].RCOMP-1K2 0NUMBERSK6,0NUMBERSK6 .["
    using xxreal_1_th_398 sorry
  also have "... = REALNUMBERSK2 \\SUBSET-1K6 {}XBOOLE-0K1"
    using xxreal_1_th_28 sorry
  also have "... = REALNUMBERSK2"
     sorry
  finally have "?lh \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ?rh =HIDDENR1 REALNUMBERSK2"
     sorry
  then have "fp0 \\/XBOOLE-0K2 fm0 =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> REALNUMBERSK2"
    using A5 relat_1_th_140 sorry
  then have A9: "fp0 \\/XBOOLE-0K2 fm0 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using A4 sorry
  have "gp0 \\/XBOOLE-0K2 gm0 =XBOOLE-0R4 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> (?lh \\/SUBSET-1K4\<^bsub>(REALNUMBERSK2)\<^esub> ?rh)"
    using A7 relat_1_th_140 sorry
  then have A10: "gp0 \\/XBOOLE-0K2 gm0 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> G"
    using A8 A6 sorry
  have "cardCARD-1K4 (fp0 \\/XBOOLE-0K2 fm0) =COMPLEX1R1 (cardCARD-1K4 fp0 +NAT-1K1 cardCARD-1K4 fm0)-XCMPLX-0K6 cardCARD-1K4 (fp0 /\\XBOOLE-0K3 fm0)"
    using card_2_th_45 sorry
  then have A11: "cardCARD-1K4 (fp0 /\\XBOOLE-0K3 fm0) =COMPLEX1R1 (cardCARD-1K4 fp0 +NAT-1K1 cardCARD-1K4 fm0)-XCMPLX-0K6 cardCARD-1K4 (fp0 \\/XBOOLE-0K2 fm0)"
     sorry
  have "cardCARD-1K4 (gp0 \\/XBOOLE-0K2 gm0) =COMPLEX1R1 (cardCARD-1K4 gp0 +NAT-1K1 cardCARD-1K4 gm0)-XCMPLX-0K6 cardCARD-1K4 (gp0 /\\XBOOLE-0K3 gm0)"
    using card_2_th_45 sorry
  then have A12: "cardCARD-1K4 (gp0 /\\XBOOLE-0K3 gm0) =COMPLEX1R1 (cardCARD-1K4 gp0 +NAT-1K1 cardCARD-1K4 gm0)-XCMPLX-0K6 cardCARD-1K4 (gp0 \\/XBOOLE-0K2 gm0)"
     sorry
  have A13: "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F & domRELSET-1K1\<^bsub>(C)\<^esub> G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> max+RFUNCT-3K18\<^bsub>(C)\<^esub> G"
    using rfunct_3_def_10 sorry
  have A14: " for r be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
  proof(rule ballI)
    fix r assume [ty]: "r be ElementSUBSET-1M1-of REALNUMBERSK2"
    have A15: "cardCARD-1K4 fp0 =COMPLEX1R1 cardCARD-1K4 gp0 & cardCARD-1K4 fm0 =COMPLEX1R1 cardCARD-1K4 gm0"
      using A1 A2 classes1_th_78 sorry
    have "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r)) or 0NUMBERSK6 =COMPLEX1R1 r & (0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K4 (F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =COMPLEX1R1 cardCARD-1K4 (G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r)))"
    proof-
      show "(0NUMBERSK6 <XXREAL-0R3 r & cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r)) or 0NUMBERSK6 =COMPLEX1R1 r & (0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K4 (F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =COMPLEX1R1 cardCARD-1K4 (G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r}))) or r <XXREAL-0R3 0NUMBERSK6 & (r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r)))"
      proof-
        have cases: "(0NUMBERSK6 <XXREAL-0R3 r or 0NUMBERSK6 =COMPLEX1R1 r) or r <XXREAL-0R3 0NUMBERSK6"
           sorry
        have case1: "0NUMBERSK6 <XXREAL-0R3 r implies cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
        proof(rule impI)
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then have "CoimRELAT-1K13(F,r) =XBOOLE-0R4 CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,r) & CoimRELAT-1K13(G,r) =XBOOLE-0R4 CoimRELAT-1K13(max+RFUNCT-3K18\<^bsub>(C)\<^esub> G,r)"
            using rfunct_3_th_35 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
            using A1 classes1_def_10 sorry
        qed
        have case2: "0NUMBERSK6 =COMPLEX1R1 r implies cardCARD-1K4 (F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =COMPLEX1R1 cardCARD-1K4 (G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
        proof(rule impI)
          assume "0NUMBERSK6 =COMPLEX1R1 r"
          then have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?lh /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> ?rh & G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r} =XBOOLE-0R4 G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?lh /\\SUBSET-1K9\<^bsub>(C)\<^esub> G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> ?rh"
            using A3 funct_1_th_68 sorry
          thus "cardCARD-1K4 (F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 r}) =COMPLEX1R1 cardCARD-1K4 (G \<inverse>RELSET-1K8\<^bsub>(C,REALNUMBERSK2)\<^esub> {TARSKIK1 r})"
            using A1 A13 A5 A7 A11 A12 A9 A10 A15 classes1_th_81 sorry
        qed
        have case3: "r <XXREAL-0R3 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
        proof(rule impI)
          assume A16: "r <XXREAL-0R3 0NUMBERSK6"
          have A17: "-REAL-1K1 (-REAL-1K1 r) =COMPLEX1R1 r"
             sorry
          have "0NUMBERSK6 <XXREAL-0R3 -REAL-1K1 r"
            using A16 xreal_1_th_58 sorry
          then have "CoimRELAT-1K13(F,r) =XBOOLE-0R4 CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F,-REAL-1K1 r) & CoimRELAT-1K13(G,r) =XBOOLE-0R4 CoimRELAT-1K13(max-RFUNCT-3K19\<^bsub>(C)\<^esub> G,-REAL-1K1 r)"
            using A17 rfunct_3_th_38 sorry
          thus "cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
            using A2 classes1_def_10 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "cardCARD-1K1 (CoimRELAT-1K13(F,r)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(G,r))"
       sorry
  qed "sorry"
  have "rngRVSUM-1K1 F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 G c=MEMBEREDR3 REALNUMBERSK2"
     sorry
  thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
    using A14 classes1_th_79 sorry
qed "sorry"

mtheorem rfunct_3_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using relat_1_th_61 sorry
  have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using rfunct_3_def_10 sorry
  also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using relat_1_th_61 sorry
  finally have "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
     sorry
  have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using rfunct_3_def_10 sorry
  have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A4: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    then have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F"
      using A1 xboole_0_def_4 sorry
    have "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
      using A4 funct_1_th_47 sorry
    also have "... = max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
      using A5 rfunct_3_def_10 sorry
    also have "... = max+RFUNCT-3K1 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d)"
      using A1 A2 A4 funct_1_th_47 sorry
    also have "... = max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
      using A1 A2 A3 A4 rfunct_3_def_10 sorry
    finally show "(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
       sorry
  qed "sorry"
  thus "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using A2 A3 partfun1_th_5 relat_1_th_61 sorry
qed "sorry"

mtheorem rfunct_3_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using relat_1_th_61 sorry
  have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using rfunct_3_def_11 sorry
  also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using relat_1_th_61 sorry
  finally have "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
     sorry
  have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using rfunct_3_def_11 sorry
  have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A4: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    then have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F"
      using A1 xboole_0_def_4 sorry
    have "(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d"
      using A4 funct_1_th_47 sorry
    also have "... = max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
      using A5 rfunct_3_def_11 sorry
    also have "... = max-RFUNCT-3K2 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d)"
      using A1 A2 A4 funct_1_th_47 sorry
    also have "... = max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
      using A1 A2 A3 A4 rfunct_3_def_11 sorry
    finally show "(max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) .FUNCT-1K1 d"
       sorry
  qed "sorry"
  thus "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using A2 A3 partfun1_th_5 relat_1_th_61 sorry
qed "sorry"

mtheorem rfunct_3_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6) implies max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
proof(rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_10 sorry
  assume A2: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
  have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A3: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    then have A4: "F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
      using A2 sorry
    have "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max+RFUNCT-3K1 (F .FUNCT-1K1 d)"
      using A1 A3 rfunct_3_def_10 sorry
    also have "... = F .FUNCT-1K1 d"
      using A4 xxreal_0_def_10 sorry
    finally show "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
       sorry
  qed "sorry"
  thus "max+RFUNCT-3K18\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
    using A1 partfun1_th_5 sorry
qed "sorry"

mtheorem rfunct_3_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d <=XXREAL-0R1 0NUMBERSK6) implies max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
proof(rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using rfunct_3_def_11 sorry
  assume A2: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies F .FUNCT-1K1 d <=XXREAL-0R1 0NUMBERSK6"
  have A3: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A4: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    then have A5: "F .FUNCT-1K1 d <=XXREAL-0R1 0NUMBERSK6"
      using A2 sorry
    have "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 max-RFUNCT-3K2 (F .FUNCT-1K1 d)"
      using A1 A4 rfunct_3_def_11 sorry
    also have "... = -XCMPLX-0K4 F .FUNCT-1K1 d"
      using A5 xxreal_0_def_10 sorry
    also have "... = (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
      using valued_1_th_8 sorry
    finally show "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F .FUNCT-1K1 d =HIDDENR1 (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 d"
       sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(D)\<^esub> F =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (-VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F)"
    using valued_1_th_8 sorry
  thus "max-RFUNCT-3K19\<^bsub>(D)\<^esub> F =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> -VALUED-1K34\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
    using A1 A3 partfun1_th_5 sorry
qed "sorry"

mtheorem rfunct_3_th_48:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6 =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have A1: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6).FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6).FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d -XCMPLX-0K6 0NUMBERSK6"
      using valued_1_th_3 sorry
    also have "... = F .FUNCT-1K1 d"
       sorry
    finally show "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6).FUNCT-1K1 d =HIDDENR1 F .FUNCT-1K1 d"
       sorry
  qed "sorry"
  have "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using valued_1_th_3 sorry
  thus "F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> 0NUMBERSK6 =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F"
    using A1 partfun1_th_5 sorry
qed "sorry"

mtheorem rfunct_3_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using valued_1_th_3 sorry
  have A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using relat_1_th_61 sorry
  have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using valued_1_th_3 sorry
  also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    using relat_1_th_61 sorry
  finally have "domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
     sorry
  have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) implies (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =HIDDENR1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d"
  proof(rule ballI,rule impI)
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    assume A4: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
    then have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using A1 A2 xboole_0_def_4 sorry
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d -XCMPLX-0K6 r"
      using A1 A4 valued_1_th_3 sorry
    also have "... = F .FUNCT-1K1 d -XCMPLX-0K6 r"
      using A1 A4 funct_1_th_47 sorry
    also have "... = (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d"
      using A5 valued_1_th_3 sorry
    also have "... = ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d"
      using A1 A2 A3 A4 funct_1_th_47 sorry
    finally show "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =HIDDENR1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d"
       sorry
  qed "sorry"
  thus "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using A2 A3 partfun1_th_5 valued_1_th_3 sorry
qed "sorry"

mtheorem rfunct_3_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } =XBOOLE-0R4 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix r assume [ty]: "r be RealXREAL-0M1"
  fix s assume [ty]: "s be RealXREAL-0M1"
  have "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } c=TARSKIR1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} & (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r }"
  proof(rule conjMI)
    show "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } c=TARSKIR1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } implies x inHIDDENR3 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r }"
        then obtain d where 
          [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
           sorry
        have A2: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A1 funct_1_def_7 sorry
        have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s +XCMPLX-0K2 r }"
          using A1 funct_1_def_7 sorry
        then have "F .FUNCT-1K1 d =COMPLEX1R1 s +XCMPLX-0K2 r"
          using tarski_def_1 sorry
        then have "F .FUNCT-1K1 d -XCMPLX-0K6 r =COMPLEX1R1 s"
           sorry
        then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 s"
          using A2 valued_1_th_3 sorry
        then have A3: "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s}"
          using tarski_def_1 sorry
        have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
          using A2 valued_1_th_3 sorry
        thus "x inHIDDENR3 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
          using A3 funct_1_def_7 sorry
      qed "sorry"
      thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } c=TARSKIR1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
        using tarski_def_3 sorry
    qed
    have " for x be objectHIDDENM1 holds x inHIDDENR3 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} implies x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r }"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A4: "x inHIDDENR3 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
      then obtain d where 
        [ty]:"d be ElementSUBSET-1M1-of D" and dDef:"d = x"
         sorry
      have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
        using A4 funct_1_def_7 sorry
      then have A5: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using valued_1_th_3 sorry
      have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s}"
        using A4 funct_1_def_7 sorry
      then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 s"
        using tarski_def_1 sorry
      then have "F .FUNCT-1K1 d -XCMPLX-0K6 r =COMPLEX1R1 s"
        using A5 valued_1_th_3 sorry
      then have "F .FUNCT-1K1 d inTARSKIR2 {TARSKIK1 s +XCMPLX-0K2 r }"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r }"
        using A5 funct_1_def_7 sorry
    qed "sorry"
    thus "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s} c=TARSKIR1 F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r }"
      using tarski_def_3 sorry
  qed
  thus "F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s +XCMPLX-0K2 r } =XBOOLE-0R4 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 s}"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem rfunct_3_th_51:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds (F,G)are-fiberwise-equipotentCLASSES1R2 iff (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds ((F,G)are-fiberwise-equipotentCLASSES1R2 implies (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2) & ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2 implies (F,G)are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "rngRVSUM-1K1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 (G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r) c=MEMBEREDR3 REALNUMBERSK2"
       sorry
    show "(F,G)are-fiberwise-equipotentCLASSES1R2 implies (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
    proof(rule impI)
      assume A2: "(F,G)are-fiberwise-equipotentCLASSES1R2"
      have " for s be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,s))"
      proof(rule ballI)
        fix s assume [ty]: "s be ElementSUBSET-1M1-of REALNUMBERSK2"
        have "cardCARD-1K1 (CoimRELAT-1K13(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(F,s +XCMPLX-0K2 r))"
          using rfunct_3_th_50 sorry
        also have "... = cardCARD-1K1 (CoimRELAT-1K13(G,s +XCMPLX-0K2 r))"
          using A2 classes1_def_10 sorry
        also have "... = cardCARD-1K1 (CoimRELAT-1K13(G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,s))"
          using rfunct_3_th_50 sorry
        finally show "cardCARD-1K1 (CoimRELAT-1K13(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,s))"
           sorry
      qed "sorry"
      thus "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
        using A1 classes1_th_79 sorry
    qed
    assume A3: "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r)are-fiberwise-equipotentCLASSES1R2"
    have A4: " for s be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(F,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(G,s))"
    proof(rule ballI)
      fix s assume [ty]: "s be ElementSUBSET-1M1-of REALNUMBERSK2"
      have A5: "s =COMPLEX1R1 (s -XCMPLX-0K6 r)+XCMPLX-0K2 r"
         sorry
      then have "cardCARD-1K1 (CoimRELAT-1K13(F,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,s -XCMPLX-0K6 r))"
        using rfunct_3_th_50 sorry
      also have "... = cardCARD-1K1 (CoimRELAT-1K13(G -VALUED-1K16\<^bsub>(C,REALNUMBERSK2)\<^esub> r,s -XCMPLX-0K6 r))"
        using A3 classes1_def_10 sorry
      also have "... = cardCARD-1K1 (CoimRELAT-1K13(G,s))"
        using A5 rfunct_3_th_50 sorry
      finally show "cardCARD-1K1 (CoimRELAT-1K13(F,s)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(G,s))"
         sorry
    qed "sorry"
    have "rngRVSUM-1K1 F c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 G c=MEMBEREDR3 REALNUMBERSK2"
       sorry
    thus "(F,G)are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rfunct_3_def_12 (" _ is-convex-onRFUNCT-3R2  _ " [50,50]50 ) where
  mlet "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"pred F is-convex-onRFUNCT-3R2 X means
  X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds (r inHIDDENR3 X & s inHIDDENR3 X) & p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s inTARSKIR2 X implies F .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 s))"..

mtheorem rfunct_3_th_52:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds F is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for r be RealXREAL-0M1 holds  for s be RealXREAL-0M1 holds r inHIDDENR3 [.RCOMP-1K1 a,b .] & s inHIDDENR3 [.RCOMP-1K1 a,b .] implies F .FUNCT-1K1 (p *XCMPLX-0K3 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 s) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 r +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 s))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))) & ([.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)) implies f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    let ?ab = "{r where r be RealXREAL-0M1 : a <=XXREAL-0R1 r & r <=XXREAL-0R1 b }"
    have A1: "[.RCOMP-1K1 a,b .] =XBOOLE-0R4 ?ab"
      using rcomp_1_def_1 sorry
    show "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))"
    proof(rule impI,rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      assume A2: "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .]"
      thus "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
         sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A3: "0NUMBERSK6 <=XXREAL-0R1 p"
        and A4: "p <=XXREAL-0R1 \<one>\<^sub>M"
      have A5: "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 p"
        using A4 xreal_1_th_48 sorry
      have A6: "p *XCMPLX-0K3 b +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =COMPLEX1R1 b"
         sorry
      have A7: "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a =COMPLEX1R1 a"
         sorry
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 [.RCOMP-1K1 a,b .]"
        and A9: "y inHIDDENR3 [.RCOMP-1K1 a,b .]"
      have A10: " ex r2 be RealXREAL-0M1 st (r2 =COMPLEX1R1 y & a <=XXREAL-0R1 r2) & r2 <=XXREAL-0R1 b"
        using A1 A9 sorry
      then have A11: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b"
        using A5 xreal_1_th_64 sorry
      have A12: " ex r1 be RealXREAL-0M1 st (r1 =COMPLEX1R1 x & a <=XXREAL-0R1 r1) & r1 <=XXREAL-0R1 b"
        using A1 A8 sorry
      then have "p *XCMPLX-0K3 x <=XXREAL-0R1 p *XCMPLX-0K3 b"
        using A3 xreal_1_th_64 sorry
      then have A13: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <=XXREAL-0R1 b"
        using A11 A6 xreal_1_th_7 sorry
      have A14: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
        using A5 A10 xreal_1_th_64 sorry
      have "p *XCMPLX-0K3 a <=XXREAL-0R1 p *XCMPLX-0K3 x"
        using A3 A12 xreal_1_th_64 sorry
      then have "a <=XXREAL-0R1 p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
        using A14 A7 xreal_1_th_7 sorry
      then have "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 ?ab"
        using A13 sorry
      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
        using A1 A2 A3 A4 A8 A9 sorry
    qed "sorry"
    assume A15: "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A16: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
    have "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]) & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y))"
    proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      show "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A15 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A17: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      assume A18: "x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .]"
        and "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 [.RCOMP-1K1 a,b .]"
      show "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
        using A16 A17 A18 sorry
    qed "sorry"
    thus "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .]"
      using rfunct_3_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds F is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] iff [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (F .FUNCT-1K1 x1 -XCMPLX-0K6 F .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (F .FUNCT-1K1 x2 -XCMPLX-0K6 F .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3))"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3))) & ([.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3)) implies f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .])"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3))"
    proof-
      have "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .] implies [.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds ((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & (x1 <XXREAL-0R3 x2 & x2 <XXREAL-0R3 x3) implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3))"
      proof(rule impI,rule conjMI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        assume A1: "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .]"
        thus "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
           sorry
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        fix x3 assume [ty]: "x3 be RealXREAL-0M1"
        assume A2: "(x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]"
          and A3: "x1 <XXREAL-0R3 x2"
          and A4: "x2 <XXREAL-0R3 x3"
        have A5: "x2 -XCMPLX-0K6 x3 <XXREAL-0R3 0NUMBERSK6"
          using A4 xreal_1_th_49 sorry
        let ?r = "(x2 -XCMPLX-0K6 x3)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3)"
        have A6: "?r *XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1) =COMPLEX1R1 ?r *XCMPLX-0K3 f .FUNCT-1K1 x2 -XCMPLX-0K6 ?r *XCMPLX-0K3 f .FUNCT-1K1 x1 & (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 (f .FUNCT-1K1 x3 -XCMPLX-0K6 f .FUNCT-1K1 x2) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 f .FUNCT-1K1 x3 -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 f .FUNCT-1K1 x2"
           sorry
        have A7: "(x1 -XCMPLX-0K6 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3) =COMPLEX1R1 (x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2)"
          using xcmplx_0_def_9 sorry
        have "x1 <XXREAL-0R3 x3"
          using A3 A4 xxreal_0_th_2 sorry
        then have A8: "x1 -XCMPLX-0K6 x3 <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        have A9: "?r +XCMPLX-0K2 (x1 -XCMPLX-0K6 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3) =HIDDENR1 ((x1 -XCMPLX-0K6 x2)+XCMPLX-0K2 (x2 -XCMPLX-0K6 x3))/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3)"
          using xcmplx_1_th_62 sorry
        also have "... = \<one>\<^sub>M"
          using A8 xcmplx_1_th_60 sorry
        finally have "?r +XCMPLX-0K2 (x1 -XCMPLX-0K6 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3) =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have A10: "?r *XCMPLX-0K3 x1 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 x3 =HIDDENR1 (x1 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3) +XCMPLX-0K2 x3 *XCMPLX-0K3 ((x1 -XCMPLX-0K6 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3))"
          using xcmplx_1_th_74 sorry
        also have "... = (x1 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3) +XCMPLX-0K2 (x3 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2))/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3)"
          using xcmplx_1_th_74 sorry
        also have "... = ((x2 *XCMPLX-0K3 x1 -XCMPLX-0K6 x3 *XCMPLX-0K3 x1)+XCMPLX-0K2 (x1 -XCMPLX-0K6 x2)*XCMPLX-0K3 x3)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3)"
          using xcmplx_1_th_62 sorry
        also have "... = (x2 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x3))/XCMPLX-0K7 (x1 -XCMPLX-0K6 x3)"
           sorry
        also have "... = x2"
          using A8 xcmplx_1_th_89 sorry
        finally have "?r *XCMPLX-0K3 x1 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 x3 =HIDDENR1 x2"
           sorry
        have A11: "x1 -XCMPLX-0K6 x2 <XXREAL-0R3 0NUMBERSK6"
          using A3 xreal_1_th_49 sorry
        then have "?r <=XXREAL-0R1 \<one>\<^sub>M"
          using A8 A9 xreal_1_th_29 xreal_1_th_140 sorry
        then have "?r *XCMPLX-0K3 f .FUNCT-1K1 x2 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 f .FUNCT-1K1 x2 <=XXREAL-0R1 ?r *XCMPLX-0K3 f .FUNCT-1K1 x1 +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 f .FUNCT-1K1 x3"
          using A1 A2 A5 A8 A10 sorry
        then have "?r *XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1) <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 (f .FUNCT-1K1 x3 -XCMPLX-0K6 f .FUNCT-1K1 x2)"
          using A6 xreal_1_th_21 sorry
        then have "-XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 (f .FUNCT-1K1 x3 -XCMPLX-0K6 f .FUNCT-1K1 x2) <=XXREAL-0R1 -XCMPLX-0K4 ?r *XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1)"
          using xreal_1_th_24 sorry
        then have "(\<one>\<^sub>M -XCMPLX-0K6 ?r)*XCMPLX-0K3 (-XCMPLX-0K4 (f .FUNCT-1K1 x3 -XCMPLX-0K6 f .FUNCT-1K1 x2)) <=XXREAL-0R1 ?r *XCMPLX-0K3 (-XCMPLX-0K4 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1))"
           sorry
        then have "((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2))*XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3) <=XXREAL-0R1 ((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))*XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)"
          using A9 A7 xcmplx_0_def_9 sorry
        then have A12: "(x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))*XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)) <=XXREAL-0R1 (x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2))*XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3))"
          using A8 xreal_1_th_65 sorry
        let ?v = "(x1 -XCMPLX-0K6 x2)*XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)"
        let ?u = "(x2 -XCMPLX-0K6 x3)*XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)"
        have A13: "(x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2))*XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)) =HIDDENR1 ((x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ?v"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 ?v"
          using A8 xcmplx_0_def_7 sorry
        also have "... = ?v"
           sorry
        finally have "(x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2))*XCMPLX-0K3 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)) =HIDDENR1 ?v"
           sorry
        have "(x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))*XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)) =HIDDENR1 ((x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ?u"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 ?u"
          using A8 xcmplx_0_def_7 sorry
        also have "... = ?u"
           sorry
        finally have "(x1 -XCMPLX-0K6 x3)*XCMPLX-0K3 (((x1 -XCMPLX-0K6 x3)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x2 -XCMPLX-0K6 x3))*XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)) =HIDDENR1 ?u"
           sorry
        thus "(f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3)"
          using A5 A11 A12 A13 xreal_1_th_103 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A14: "[.RCOMP-1K1 a,b .] c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A15: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  for x3 be RealXREAL-0M1 holds (((x1 inHIDDENR3 [.RCOMP-1K1 a,b .] & x2 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x3 inHIDDENR3 [.RCOMP-1K1 a,b .]) & x1 <XXREAL-0R3 x2) & x2 <XXREAL-0R3 x3 implies (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2)/XCMPLX-0K7 (x1 -XCMPLX-0K6 x2) <=XXREAL-0R1 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x3)/XCMPLX-0K7 (x2 -XCMPLX-0K6 x3)"
    have " for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 [.RCOMP-1K1 a,b .] & y inHIDDENR3 [.RCOMP-1K1 a,b .] implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
    proof(rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A16: "0NUMBERSK6 <=XXREAL-0R1 p"
        and A17: "p <=XXREAL-0R1 \<one>\<^sub>M"
      have A18: "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 p"
        using A17 xreal_1_th_48 sorry
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      let ?r = "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
      assume A19: "x inHIDDENR3 [.RCOMP-1K1 a,b .]"
        and A20: "y inHIDDENR3 [.RCOMP-1K1 a,b .]"
      have A21: "p *XCMPLX-0K3 y +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y =COMPLEX1R1 y"
         sorry
      have A22: "{s where s be RealXREAL-0M1 : a <=XXREAL-0R1 s & s <=XXREAL-0R1 b } =XBOOLE-0R4 [.RCOMP-1K1 a,b .]"
        using rcomp_1_def_1 sorry
      then have A23: " ex t be RealXREAL-0M1 st (t =COMPLEX1R1 y & a <=XXREAL-0R1 t) & t <=XXREAL-0R1 b"
        using A20 sorry
      then have A24: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b"
        using A18 xreal_1_th_64 sorry
      have A25: " ex t be RealXREAL-0M1 st (t =COMPLEX1R1 x & a <=XXREAL-0R1 t) & t <=XXREAL-0R1 b"
        using A22 A19 sorry
      then have "p *XCMPLX-0K3 b +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 b =COMPLEX1R1 b & p *XCMPLX-0K3 x <=XXREAL-0R1 p *XCMPLX-0K3 b"
        using A16 xreal_1_th_64 sorry
      then have A26: "?r <=XXREAL-0R1 b"
        using A24 xreal_1_th_7 sorry
      have A27: "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
        using A18 A23 xreal_1_th_64 sorry
      have "p *XCMPLX-0K3 a +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 a =COMPLEX1R1 a & p *XCMPLX-0K3 a <=XXREAL-0R1 p *XCMPLX-0K3 x"
        using A16 A25 xreal_1_th_64 sorry
      then have "a <=XXREAL-0R1 ?r"
        using A27 xreal_1_th_7 sorry
      then have A28: "?r inTARSKIR2 [.RCOMP-1K1 a,b .]"
        using A22 A26 sorry
      have A29: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 x =COMPLEX1R1 x"
         sorry
      have "x =COMPLEX1R1 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or x <>HIDDENR2 y & (x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
      proof-
        show "x =COMPLEX1R1 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or x <>HIDDENR2 y & (x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
        proof-
          have cases: "x =COMPLEX1R1 y or x <>HIDDENR2 y"
             sorry
          have case1: "x =COMPLEX1R1 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
          proof(rule impI)
            assume "x =COMPLEX1R1 y"
            thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
               sorry
          qed
          have case2: "x <>HIDDENR2 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
          proof(rule impI)
            assume A30: "x <>HIDDENR2 y"
            have "p =COMPLEX1R1 0NUMBERSK6 & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or p <>HIDDENR2 0NUMBERSK6 & (p <>HIDDENR2 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
            proof-
              show "p =COMPLEX1R1 0NUMBERSK6 & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or p <>HIDDENR2 0NUMBERSK6 & (p <>HIDDENR2 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
              proof-
                have cases: "p =COMPLEX1R1 0NUMBERSK6 or p <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "p =COMPLEX1R1 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                proof(rule impI)
                  assume "p =COMPLEX1R1 0NUMBERSK6"
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                     sorry
                qed
                have case2: "p <>HIDDENR2 0NUMBERSK6 implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                proof(rule impI)
                  assume A31: "p <>HIDDENR2 0NUMBERSK6"
                  have "p =COMPLEX1R1 \<one>\<^sub>M & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or p <>HIDDENR2 \<one>\<^sub>M & (p <>HIDDENR2 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
                  proof-
                    show "p =COMPLEX1R1 \<one>\<^sub>M & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or p <>HIDDENR2 \<one>\<^sub>M & (p <>HIDDENR2 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
                    proof-
                      have cases: "p =COMPLEX1R1 \<one>\<^sub>M or p <>HIDDENR2 \<one>\<^sub>M"
                         sorry
                      have case1: "p =COMPLEX1R1 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                      proof(rule impI)
                        assume "p =COMPLEX1R1 \<one>\<^sub>M"
                        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                           sorry
                      qed
                      have case2: "p <>HIDDENR2 \<one>\<^sub>M implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                      proof(rule impI)
                        assume "p <>HIDDENR2 \<one>\<^sub>M"
                        then have "p <XXREAL-0R3 \<one>\<^sub>M"
                          using A17 xxreal_0_th_1 sorry
                        then have A32: "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 p"
                          using xreal_1_th_50 sorry
                        have "x <XXREAL-0R3 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or y <XXREAL-0R3 x & (y <XXREAL-0R3 x implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
                        proof-
                          show "x <XXREAL-0R3 y & f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y or y <XXREAL-0R3 x & (y <XXREAL-0R3 x implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y)"
                          proof-
                            have cases: "x <XXREAL-0R3 y or y <XXREAL-0R3 x"
                              using A30 xxreal_0_th_1 sorry
                            have case1: "x <XXREAL-0R3 y implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                            proof(rule impI)
                              assume A33: "x <XXREAL-0R3 y"
                              then have "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 x <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
                                using A32 xreal_1_th_68 sorry
                              then have A34: "x <XXREAL-0R3 ?r"
                                using A29 xreal_1_th_8 sorry
                              then have A35: "x -XCMPLX-0K6 ?r <XXREAL-0R3 0NUMBERSK6"
                                using xreal_1_th_49 sorry
                              have "p *XCMPLX-0K3 x <XXREAL-0R3 p *XCMPLX-0K3 y"
                                using A16 A31 A33 xreal_1_th_68 sorry
                              then have A36: "?r <XXREAL-0R3 y"
                                using A21 xreal_1_th_8 sorry
                              then have A37: "?r -XCMPLX-0K6 y <XXREAL-0R3 0NUMBERSK6"
                                using xreal_1_th_49 sorry
                              have A38: "x -XCMPLX-0K6 y <XXREAL-0R3 0NUMBERSK6"
                                using A33 xreal_1_th_49 sorry
                              have "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?r)/XCMPLX-0K7 (x -XCMPLX-0K6 ?r) <=XXREAL-0R1 (f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 y)/XCMPLX-0K7 (?r -XCMPLX-0K6 y)"
                                using A15 A19 A20 A28 A36 A34 sorry
                              then have "(f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 (p *XCMPLX-0K3 (x -XCMPLX-0K6 y)) <=XXREAL-0R1 (f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 y)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (x -XCMPLX-0K6 y))"
                                using A37 A35 xreal_1_th_107 sorry
                              then have "(((f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 p)*XCMPLX-0K3 (x -XCMPLX-0K6 y))/XCMPLX-0K7 (x -XCMPLX-0K6 y) >=XXREAL-0R2 (((f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 y)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 y))/XCMPLX-0K7 (x -XCMPLX-0K6 y)"
                                using A38 xreal_1_th_73 sorry
                              then have "(((f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 y)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p))*XCMPLX-0K3 (x -XCMPLX-0K6 y))/XCMPLX-0K7 (x -XCMPLX-0K6 y) <=XXREAL-0R1 (f .FUNCT-1K1 x -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 p"
                                using A38 xcmplx_1_th_89 sorry
                              then have "f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) -XCMPLX-0K6 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) <=XXREAL-0R1 f .FUNCT-1K1 x *XCMPLX-0K3 p -XCMPLX-0K6 f .FUNCT-1K1 ?r *XCMPLX-0K3 p"
                                using A38 xcmplx_1_th_89 sorry
                              then have "f .FUNCT-1K1 ?r *XCMPLX-0K3 p +XCMPLX-0K2 (f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) -XCMPLX-0K6 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p)) <=XXREAL-0R1 f .FUNCT-1K1 x *XCMPLX-0K3 p"
                                using xreal_1_th_19 sorry
                              then have "(f .FUNCT-1K1 ?r *XCMPLX-0K3 p +XCMPLX-0K2 f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p))-XCMPLX-0K6 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) <=XXREAL-0R1 f .FUNCT-1K1 x *XCMPLX-0K3 p"
                                 sorry
                              thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                                using xreal_1_th_20 sorry
                            qed
                            have case2: "y <XXREAL-0R3 x implies f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                            proof(rule impI)
                              assume A39: "y <XXREAL-0R3 x"
                              then have "(\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 x"
                                using A32 xreal_1_th_68 sorry
                              then have A40: "?r <XXREAL-0R3 x"
                                using A29 xreal_1_th_8 sorry
                              then have A41: "?r -XCMPLX-0K6 x <XXREAL-0R3 0NUMBERSK6"
                                using xreal_1_th_49 sorry
                              have "p *XCMPLX-0K3 y <XXREAL-0R3 p *XCMPLX-0K3 x"
                                using A16 A31 A39 xreal_1_th_68 sorry
                              then have A42: "y <XXREAL-0R3 ?r"
                                using A21 xreal_1_th_8 sorry
                              then have A43: "y -XCMPLX-0K6 ?r <XXREAL-0R3 0NUMBERSK6"
                                using xreal_1_th_49 sorry
                              have A44: "y -XCMPLX-0K6 x <XXREAL-0R3 0NUMBERSK6"
                                using A39 xreal_1_th_49 sorry
                              have "(f .FUNCT-1K1 y -XCMPLX-0K6 f .FUNCT-1K1 ?r)/XCMPLX-0K7 (y -XCMPLX-0K6 ?r) <=XXREAL-0R1 (f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 x)/XCMPLX-0K7 (?r -XCMPLX-0K6 x)"
                                using A15 A19 A20 A28 A42 A40 sorry
                              then have "(f .FUNCT-1K1 y -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (y -XCMPLX-0K6 x)) <=XXREAL-0R1 (f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 x)*XCMPLX-0K3 (p *XCMPLX-0K3 (y -XCMPLX-0K6 x))"
                                using A43 A41 xreal_1_th_107 sorry
                              then have "(((f .FUNCT-1K1 y -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p))*XCMPLX-0K3 (y -XCMPLX-0K6 x))/XCMPLX-0K7 (y -XCMPLX-0K6 x) >=XXREAL-0R2 (((f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 x)*XCMPLX-0K3 p)*XCMPLX-0K3 (y -XCMPLX-0K6 x))/XCMPLX-0K7 (y -XCMPLX-0K6 x)"
                                using A44 xreal_1_th_73 sorry
                              then have "(((f .FUNCT-1K1 ?r -XCMPLX-0K6 f .FUNCT-1K1 x)*XCMPLX-0K3 p)*XCMPLX-0K3 (y -XCMPLX-0K6 x))/XCMPLX-0K7 (y -XCMPLX-0K6 x) <=XXREAL-0R1 (f .FUNCT-1K1 y -XCMPLX-0K6 f .FUNCT-1K1 ?r)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p)"
                                using A44 xcmplx_1_th_89 sorry
                              then have "f .FUNCT-1K1 ?r *XCMPLX-0K3 p -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 p <=XXREAL-0R1 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) -XCMPLX-0K6 f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p)"
                                using A44 xcmplx_1_th_89 sorry
                              then have "(f .FUNCT-1K1 ?r *XCMPLX-0K3 p -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 p)+XCMPLX-0K2 f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p) <=XXREAL-0R1 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p)"
                                using xreal_1_th_19 sorry
                              then have "(f .FUNCT-1K1 ?r *XCMPLX-0K3 p +XCMPLX-0K2 f .FUNCT-1K1 ?r *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p))-XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 p <=XXREAL-0R1 f .FUNCT-1K1 y *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 p)"
                                 sorry
                              thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                                using xreal_1_th_20 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                        thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                           sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed
                  thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 f .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 f .FUNCT-1K1 y"
         sorry
    qed "sorry"
    thus "f is-convex-onRFUNCT-3R2 [.RCOMP-1K1 a,b .]"
      using A14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_54:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X & Y c=TARSKIR1 X implies F is-convex-onRFUNCT-3R2 Y"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  assume A1: "F is-convex-onRFUNCT-3R2 X"
    and A2: "Y c=TARSKIR1 X"
  have Cut2307: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
    using A1 sorry
  have "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds (x inHIDDENR3 Y & y inHIDDENR3 Y) & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 Y implies F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y))"
  proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
    show "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
      using A2 Cut2307 sorry
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A3: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "(x inHIDDENR3 Y & y inHIDDENR3 Y) & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 Y"
    thus "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
      using A1 A2 A3 sorry
  qed "sorry"
  thus "F is-convex-onRFUNCT-3R2 Y"
    using rfunct_3_def_12 sorry
qed "sorry"

mtheorem rfunct_3_th_55:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds F is-convex-onRFUNCT-3R2 X iff F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X"
proof-
  have " for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds (F is-convex-onRFUNCT-3R2 X implies F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X) & (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X implies F is-convex-onRFUNCT-3R2 X)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
      using valued_1_th_3 sorry
    show "F is-convex-onRFUNCT-3R2 X implies F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X"
    proof(rule impI)
      assume A2: "F is-convex-onRFUNCT-3R2 X"
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y))"
      proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
          using A1 A2 sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A4: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        assume A5: "x inHIDDENR3 X"
          and A6: "y inHIDDENR3 X"
          and A7: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
        have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
          using A2 A4 A5 A6 A7 sorry
        then have A8: "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) -XCMPLX-0K6 r <=XXREAL-0R1 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r"
          using xreal_1_th_9 sorry
        have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r =HIDDENR1 p *XCMPLX-0K3 (F .FUNCT-1K1 x -XCMPLX-0K6 r) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y -XCMPLX-0K6 r)"
           sorry
        also have "... = p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y -XCMPLX-0K6 r)"
          using A1 A3 A5 valued_1_th_3 sorry
        also have "... = p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
          using A1 A3 A6 valued_1_th_3 sorry
        finally have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r =HIDDENR1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
           sorry
        thus "(F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
          using A1 A3 A7 A8 valued_1_th_3 sorry
      qed "sorry"
      thus "F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X"
        using rfunct_3_def_12 sorry
    qed
    assume A9: "F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r is-convex-onRFUNCT-3R2 X"
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y))"
    proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
        using A1 A9 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A11: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 X"
        and A13: "y inHIDDENR3 X"
        and A14: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
      have "(F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
        using A9 A11 A12 A13 A14 sorry
      then have A15: "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) -XCMPLX-0K6 r <=XXREAL-0R1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
        using A10 A14 valued_1_th_3 sorry
      have "p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y =HIDDENR1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y -XCMPLX-0K6 r)"
        using A10 A13 valued_1_th_3 sorry
      also have "... = p *XCMPLX-0K3 (F .FUNCT-1K1 x -XCMPLX-0K6 r) +XCMPLX-0K2 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 r)"
        using A10 A12 valued_1_th_3 sorry
      also have "... = (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r"
         sorry
      finally have "p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y =HIDDENR1 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r"
         sorry
      thus "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
        using A15 xreal_1_th_9 sorry
    qed "sorry"
    thus "F is-convex-onRFUNCT-3R2 X"
      using rfunct_3_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_56:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies (F is-convex-onRFUNCT-3R2 X iff r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X)"
proof-
  have " for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies (F is-convex-onRFUNCT-3R2 X implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X) & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X implies F is-convex-onRFUNCT-3R2 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 r"
    have A2: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F)"
      using valued_1_def_5 sorry
    show "F is-convex-onRFUNCT-3R2 X implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
    proof(rule impI)
      assume A3: "F is-convex-onRFUNCT-3R2 X"
      then have A4: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
         sorry
      have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y))"
      proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F)"
          using A2 A3 sorry
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume A5: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
        fix x assume [ty]: "x be RealXREAL-0M1"
        fix y assume [ty]: "y be RealXREAL-0M1"
        assume A6: "x inHIDDENR3 X"
          and A7: "y inHIDDENR3 X"
          and A8: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
        have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
          using A3 A5 A6 A7 A8 sorry
        then have "r *XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 r *XCMPLX-0K3 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)"
          using A1 xreal_1_th_64 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r *XCMPLX-0K3 F .FUNCT-1K1 x) +XCMPLX-0K2 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 r)*XCMPLX-0K3 F .FUNCT-1K1 y"
          using A2 A4 A8 valued_1_def_5 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r *XCMPLX-0K3 F .FUNCT-1K1 y)"
          using A2 A4 A6 valued_1_def_5 sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
          using A2 A4 A7 valued_1_def_5 sorry
      qed "sorry"
      thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
        using rfunct_3_def_12 sorry
    qed
    assume A9: "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
    then have A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F)"
       sorry
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y))"
    proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
        using valued_1_def_5 A10 sorry
      fix p assume [ty]: "p be RealXREAL-0M1"
      assume A11: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      fix y assume [ty]: "y be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 X"
        and A13: "y inHIDDENR3 X"
        and A14: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
      have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
        using A9 A11 A12 A13 A14 sorry
      then have "r *XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
        using A10 A14 valued_1_def_5 sorry
      then have "r *XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r *XCMPLX-0K3 F .FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
        using A10 A12 valued_1_def_5 sorry
      then have "r *XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (r *XCMPLX-0K3 F .FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (r *XCMPLX-0K3 F .FUNCT-1K1 y)"
        using A10 A13 valued_1_def_5 sorry
      then have "(r *XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y))/XCMPLX-0K7 r <=XXREAL-0R1 (r *XCMPLX-0K3 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y))/XCMPLX-0K7 r"
        using A1 xreal_1_th_72 sorry
      then have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 (r *XCMPLX-0K3 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y))/XCMPLX-0K7 r"
        using A1 xcmplx_1_th_89 sorry
      thus "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
        using A1 xcmplx_1_th_89 sorry
    qed "sorry"
    thus "F is-convex-onRFUNCT-3R2 X"
      using rfunct_3_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_57:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F implies (0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
  have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y))"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F)"
      using valued_1_def_5 A1 sorry
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-0R1 p"
      and "p <=XXREAL-0R1 \<one>\<^sub>M"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A2: "x inHIDDENR3 X"
      and A3: "y inHIDDENR3 X"
      and A4: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
    have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F)"
      using valued_1_def_5 sorry
    then have A6: "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y)"
      using A1 A4 valued_1_def_5 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) =HIDDENR1 0NUMBERSK6"
       sorry
    have "p *XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y =HIDDENR1 p *XCMPLX-0K3 ((0NUMBERSK6)*XCMPLX-0K3 F .FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
      using A1 A5 A2 valued_1_def_5 sorry
    also have "... = p *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)*XCMPLX-0K3 F .FUNCT-1K1 y)"
      using A1 A5 A3 valued_1_def_5 sorry
    also have "... = 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
       sorry
    finally have "p *XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y =HIDDENR1 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
       sorry
    thus "((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 ((0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F).FUNCT-1K1 y"
      using A6 sorry
  qed "sorry"
  thus "(0NUMBERSK6)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
    using rfunct_3_def_12 sorry
qed "sorry"

mtheorem rfunct_3_th_58:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X & G is-convex-onRFUNCT-3R2 X implies F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G is-convex-onRFUNCT-3R2 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> G"
    using valued_1_def_1 sorry
  assume A2: "F is-convex-onRFUNCT-3R2 X & G is-convex-onRFUNCT-3R2 X"
  then have Cut2457: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> G"
     sorry
  have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 y))"
  proof(rule conjMI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    show A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G)"
      using A1 xboole_1_th_19 Cut2457 sorry
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A4: "0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A5: "x inHIDDENR3 X"
      and A6: "y inHIDDENR3 X"
      and A7: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
    have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y & G .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 G .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y"
      using A2 A4 A5 A6 A7 sorry
    then have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) +XCMPLX-0K2 G .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (p *XCMPLX-0K3 G .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y)"
      using xreal_1_th_7 sorry
    then have A8: "(F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (p *XCMPLX-0K3 G .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y)"
      using A3 A7 valued_1_def_1 sorry
    have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (p *XCMPLX-0K3 G .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y) =HIDDENR1 (p *XCMPLX-0K3 (F .FUNCT-1K1 x +XCMPLX-0K2 G .FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y"
       sorry
    also have "... = (p *XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y"
      using A3 A5 valued_1_def_1 sorry
    also have "... = p *XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y +XCMPLX-0K2 G .FUNCT-1K1 y)"
       sorry
    finally have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)+XCMPLX-0K2 (p *XCMPLX-0K3 G .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 G .FUNCT-1K1 y) =HIDDENR1 p *XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y +XCMPLX-0K2 G .FUNCT-1K1 y)"
       sorry
    thus "(F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 y"
      using A3 A6 A8 valued_1_def_1 sorry
  qed "sorry"
  thus "F +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G is-convex-onRFUNCT-3R2 X"
    using rfunct_3_def_12 sorry
qed "sorry"

mtheorem rfunct_3_th_59:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds F is-convex-onRFUNCT-3R2 X implies max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) is-convex-onRFUNCT-3R2 X"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  fix r assume [ty]: "r be RealXREAL-0M1"
  assume A1: "F is-convex-onRFUNCT-3R2 X"
  then have A2: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F"
     sorry
  have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> F =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) =MEMBEREDR9 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
    using rfunct_3_def_10 valued_1_th_3 sorry
  have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 X & (y inHIDDENR3 X & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X) implies max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 y))"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    show "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r)"
      using A1 A3 sorry
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume A4: "0NUMBERSK6 <=XXREAL-0R1 p"
      and A5: "p <=XXREAL-0R1 \<one>\<^sub>M"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A6: "x inHIDDENR3 X"
      and A7: "y inHIDDENR3 X"
      and A8: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 X"
    have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y"
      using A1 A4 A5 A6 A7 A8 sorry
    then have "F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) -XCMPLX-0K6 r <=XXREAL-0R1 (p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r"
      using xreal_1_th_9 sorry
    then have A9: "max+RFUNCT-3K1 (F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) -XCMPLX-0K6 r) <=XXREAL-0R1 maxXXREAL-0K5((p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r,0NUMBERSK6)"
      using xxreal_0_th_26 sorry
    have "0NUMBERSK6 +XCMPLX-0K2 p <=XXREAL-0R1 \<one>\<^sub>M"
      using A5 sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 p"
      using xreal_1_th_19 sorry
    then have A10: "max+RFUNCT-3K1 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y) =COMPLEX1R1 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using rfunct_3_th_4 sorry
    have A11: "max+RFUNCT-3K1 (p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y) <=XXREAL-0R1 max+RFUNCT-3K1 (p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x) +XCMPLX-0K2 max+RFUNCT-3K1 ((\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using rfunct_3_th_5 sorry
    have A12: "max+RFUNCT-3K1 (p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x) =COMPLEX1R1 p *XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x)"
      using A4 rfunct_3_th_4 sorry
    obtain pc where 
      [ty]:"pc be ElementSUBSET-1M1-of REALNUMBERSK2" and pcDef:"pc = p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y"
      using xreal_0_def_1 sorry
    have 
      [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and
      [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r =HIDDENR1 p *XCMPLX-0K3 (F .FUNCT-1K1 x -XCMPLX-0K6 r) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y -XCMPLX-0K6 r)"
       sorry
    also have "... = p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F .FUNCT-1K1 y -XCMPLX-0K6 r)"
      using A6 A2 valued_1_th_3 sorry
    also have "... = p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
      using A7 A2 valued_1_th_3 sorry
    finally have "(p *XCMPLX-0K3 F .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 F .FUNCT-1K1 y)-XCMPLX-0K6 r =HIDDENR1 p *XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y"
       sorry
    then have "max+RFUNCT-3K1 (F .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) -XCMPLX-0K6 r) <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using A9 A11 A12 A10 xxreal_0_th_2 sorry
    then have "max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 pc) <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using A8 A2 valued_1_th_3 sorry
    then have "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 pc <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 x) +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using A3 A8 A2 rfunct_3_def_10 sorry
    then have "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 pc <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K1 ((F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 y)"
      using A3 A6 A2 rfunct_3_def_10 sorry
    thus "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) .FUNCT-1K1 y"
      using A3 A7 A2 rfunct_3_def_10 sorry
  qed "sorry"
  thus "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) is-convex-onRFUNCT-3R2 X"
    using rfunct_3_def_12 sorry
qed "sorry"

mtheorem rfunct_3_th_60:
" for F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for X be setHIDDENM2 holds F is-convex-onRFUNCT-3R2 X implies max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
proof(rule ballI,rule ballI,rule impI)
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  assume "F is-convex-onRFUNCT-3R2 X"
  then have "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (F -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> 0NUMBERSK6) is-convex-onRFUNCT-3R2 X"
    using rfunct_3_th_59 sorry
  thus "max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> F is-convex-onRFUNCT-3R2 X"
    using rfunct_3_th_48 sorry
qed "sorry"

mtheorem rfunct_3_th_61:
"idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) is-convex-onRFUNCT-3R2 REALNUMBERSK2"
proof-
  let ?i = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2)"
  have "REALNUMBERSK2 c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2)) & ( for p be RealXREAL-0M1 holds 0NUMBERSK6 <=XXREAL-0R1 p & p <=XXREAL-0R1 \<one>\<^sub>M implies ( for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 & (y inHIDDENR3 REALNUMBERSK2 & p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 REALNUMBERSK2) implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 y))"
  proof(rule conjMI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    show "REALNUMBERSK2 c=MEMBEREDR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2))"
      using funct_1_th_17 sorry
    fix p assume [ty]: "p be RealXREAL-0M1"
    assume "0NUMBERSK6 <=XXREAL-0R1 p"
      and "p <=XXREAL-0R1 \<one>\<^sub>M"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "x inHIDDENR3 REALNUMBERSK2"
      and A2: "y inHIDDENR3 REALNUMBERSK2"
      and A3: "p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y inTARSKIR2 REALNUMBERSK2"
    have "?i .FUNCT-1K1 x =COMPLEX1R1 x & ?i .FUNCT-1K1 y =COMPLEX1R1 y"
      using A1 A2 funct_1_th_17 sorry
    thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 (p *XCMPLX-0K3 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 y) <=XXREAL-0R1 p *XCMPLX-0K3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 x +XCMPLX-0K2 (\<one>\<^sub>M -XCMPLX-0K6 p)*XCMPLX-0K3 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) .FUNCT-1K1 y"
      using A3 funct_1_th_17 sorry
  qed "sorry"
  thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) is-convex-onRFUNCT-3R2 REALNUMBERSK2"
    using rfunct_3_def_12 sorry
qed

mtheorem rfunct_3_th_62:
" for r be RealXREAL-0M1 holds max+RFUNCT-3K18\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> ([#]SUBSET-1K2 REALNUMBERSK2) -VALUED-1K16\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r) is-convex-onRFUNCT-3R2 REALNUMBERSK2"
  using rfunct_3_th_59 rfunct_3_th_61 sorry

mdef rfunct_3_def_13 ("FinSRFUNCT-3K20\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]300 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"assume domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 func FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) \<rightarrow> non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 means
  \<lambda>it. (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it)are-fiberwise-equipotentCLASSES1R2"
proof-
  (*existence*)
    show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies ( ex it be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it)are-fiberwise-equipotentCLASSES1R2)"
    proof(rule impI)
      assume Assume: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
        using Assume sorry
      show " ex it be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it)are-fiberwise-equipotentCLASSES1R2"
      proof-
        have " ex tVar10 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,tVar10)are-fiberwise-equipotentCLASSES1R2"
        proof-
          let ?x = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          obtain b where
            [ty]:"b be FinSequenceFINSEQ-1M1" and 
            A2: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x,b)are-fiberwise-equipotentCLASSES1R2"
            using A1 rfinseq_th_5 sorry
          have "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x) =XBOOLE-0R4 rngFUNCT-1K2 b"
            using A2 classes1_th_75 sorry
          then have 
            [ty]:"b be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
            using finseq_1_def_4 sorry
          obtain a where
            [ty]:"a be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and 
            A3: "(b,a)are-fiberwise-equipotentCLASSES1R2"
            using rfinseq_th_22 sorry
          show " ex tVar10 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 st (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,tVar10)are-fiberwise-equipotentCLASSES1R2"
          proof(rule bexI[of _ "a"])
            have "?x =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
              using relat_1_th_61 sorry
            then have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_71 sorry
            also have "... = F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
              using relat_1_th_68 sorry
            finally have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
               sorry
            thus "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,a)are-fiberwise-equipotentCLASSES1R2"
              using A2 A3 classes1_th_76 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies ( for it1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it1)are-fiberwise-equipotentCLASSES1R2 & (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it2)are-fiberwise-equipotentCLASSES1R2 implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      have A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
        using Assume sorry
      show " for it1 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds  for it2 be non-increasingRFINSEQV1\<bar>FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it1)are-fiberwise-equipotentCLASSES1R2 & (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,it2)are-fiberwise-equipotentCLASSES1R2 implies it1 =HIDDENR1 it2"
        using classes1_th_76 rfinseq_th_23 sorry
    qed
qed "sorry"

mtheorem rfunct_3_th_63:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X)"
    using relat_1_th_61 sorry
  also have "... = (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using relat_1_th_71 sorry
  also have "... = F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using relat_1_th_68 sorry
  finally have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
     sorry
  assume A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
  then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
    using rfunct_3_def_13 sorry
  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    using A2 A1 rfunct_3_def_13 sorry
qed "sorry"

mtheorem rfunct_3_th_64:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix X assume [ty]: "X be setHIDDENM2"
  have A1: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using relat_1_th_72 sorry
  assume A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
  then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
    using rfunct_3_def_13 sorry
  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    using A2 A1 rfunct_3_def_13 sorry
qed "sorry"

mtheorem rfunct_3_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds X be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((X be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) &  not (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2)"
  proof-
    have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be finiteFINSET-1V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
    proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
      fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      fix X assume [ty]: "X be finiteFINSET-1V1\<bar>setHIDDENM2"
      fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
      fix x assume [ty]: "x be objectHIDDENM1"
      let ?Y = "X \\SUBSET-1K6 {TARSKIK1 x}"
      let ?A = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      then have A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
        using relat_1_th_61 sorry
      then have "x inHIDDENR3 X"
        using xboole_0_def_4 sorry
      then have A2: "{TARSKIK1 x} c=TARSKIR1 X"
        using zfmisc_1_th_31 sorry
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using A1 xboole_0_def_4 sorry
      then have A3: "{TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
        using zfmisc_1_th_31 sorry
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y) be finiteFINSET-1V1"
         sorry
      then have A4: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y,FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y))are-fiberwise-equipotentCLASSES1R2"
        using rfunct_3_def_13 sorry
      have " for y be objectHIDDENM1 holds cardCARD-1K1 (CoimRELAT-1K13(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,y)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),y))"
      proof(rule ballI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have A5: "?Y missesXBOOLE-0R1 {TARSKIK1 x}"
          using xboole_1_th_79 sorry
        have A6: "cardCARD-1K1 (CoimRELAT-1K13(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y,y)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y),y))"
          using A4 classes1_def_10 sorry
        have A7: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =XBOOLE-0R4 {TARSKIK1 x}"
          using A3 relat_1_th_62 sorry
        have A8: "domFINSEQ-1K5 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>) =MEMBEREDR12 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_th_2 finseq_1_th_38 sorry
        have A9: "y =HIDDENR1 F .FUNCT-1K1 x & cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}) or y <>HIDDENR2 F .FUNCT-1K1 x & (y <>HIDDENR2 F .FUNCT-1K1 x implies cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}))"
        proof-
          show "y =HIDDENR1 F .FUNCT-1K1 x & cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}) or y <>HIDDENR2 F .FUNCT-1K1 x & (y <>HIDDENR2 F .FUNCT-1K1 x implies cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}))"
          proof-
            have cases: "y =HIDDENR1 F .FUNCT-1K1 x or y <>HIDDENR2 F .FUNCT-1K1 x"
               sorry
            have case1: "y =HIDDENR1 F .FUNCT-1K1 x implies cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y})"
            proof(rule impI)
              assume A10: "y =HIDDENR1 F .FUNCT-1K1 x"
              have A11: "{TARSKIK1 x} c=TARSKIR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
              proof-
                have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 x} implies z inHIDDENR3 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
                proof(rule ballI,rule impI)
                  fix z assume [ty]: "z be objectHIDDENM1"
                  have A12: "y inHIDDENR3 {TARSKIK1 y}"
                    using tarski_def_1 sorry
                  assume A13: "z inHIDDENR3 {TARSKIK1 x}"
                  then have "z =HIDDENR1 x"
                    using tarski_def_1 sorry
                  then have "y =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}).FUNCT-1K1 z"
                    using A7 A10 A13 funct_1_th_47 sorry
                  thus "z inHIDDENR3 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
                    using A7 A13 A12 funct_1_def_7 sorry
                qed "sorry"
                thus "{TARSKIK1 x} c=TARSKIR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
                  using tarski_def_3 sorry
              qed
              have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 x}"
                using A7 relat_1_th_132 sorry
              then have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
                using A11 sorry
              then have A14: "cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 \<one>\<^sub>M"
                using card_1_th_30 sorry
              have A15: "{TARSKIK1 \<one>\<^sub>M} c=MEMBEREDR6 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}"
              proof-
                have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} implies z inHIDDENR3 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}"
                proof(rule ballI,rule impI)
                  fix z assume [ty]: "z be objectHIDDENM1"
                  have A16: "y inHIDDENR3 {TARSKIK1 y}"
                    using tarski_def_1 sorry
                  assume A17: "z inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
                  then have "z =HIDDENR1 \<one>\<^sub>M"
                    using tarski_def_1 sorry
                  then have "y =HIDDENR1 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>).FUNCT-1K1 z"
                    using A10 finseq_1_th_40 sorry
                  thus "z inHIDDENR3 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}"
                    using A8 A17 A16 funct_1_def_7 sorry
                qed "sorry"
                thus "{TARSKIK1 \<one>\<^sub>M} c=MEMBEREDR6 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}"
                  using tarski_def_3 sorry
              qed
              have "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y} c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M}"
                using A8 relat_1_th_132 sorry
              then have "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
                using A15 sorry
              thus "cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y})"
                using A14 card_1_th_30 sorry
            qed
            have case2: "y <>HIDDENR2 F .FUNCT-1K1 x implies cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y})"
            proof(rule impI)
              assume A18: "y <>HIDDENR2 F .FUNCT-1K1 x"
              have A19: "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1 implies  False "
              proof(rule impI)
                let ?z = "the ElementSUBSET-1M1-of (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}"
                assume A20: "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
                then have "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>).FUNCT-1K1 ?z inTARSKIR2 {TARSKIK1 y}"
                  using funct_1_def_7 sorry
                then have A21: "(<*FINSEQ-1K10 F .FUNCT-1K1 x*>).FUNCT-1K1 ?z =HIDDENR1 y"
                  using tarski_def_1 sorry
                have "?z inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
                  using A8 A20 funct_1_def_7 sorry
                then have "?z =XBOOLE-0R4 \<one>\<^sub>M"
                  using tarski_def_1 sorry
                thus " False "
                  using A18 A21 finseq_1_th_40 sorry
              qed
              have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1 implies  False "
              proof(rule impI)
                let ?z = "the ElementSUBSET-1M1-of (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
                assume A22: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} <>HIDDENR2 {}XBOOLE-0K1"
                then have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}).FUNCT-1K1 ?z inTARSKIR2 {TARSKIK1 y}"
                  using funct_1_def_7 sorry
                then have A23: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}).FUNCT-1K1 ?z =HIDDENR1 y"
                  using tarski_def_1 sorry
                have A24: "?z inTARSKIR2 {TARSKIK1 x}"
                  using A7 A22 funct_1_def_7 sorry
                then have "?z =HIDDENR1 x"
                  using tarski_def_1 sorry
                thus " False "
                  using A7 A18 A24 A23 funct_1_th_47 sorry
              qed
              thus "cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) =COMPLEX1R1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y})"
                using A19 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A25: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} \\/SUBSET-1K4\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} =HIDDENR1 ?Y /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} \\/SUBSET-1K4\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using funct_1_th_70 sorry
        also have "... = ?Y /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} \\/SUBSET-1K4\<^bsub>(D)\<^esub> {TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using funct_1_th_70 sorry
        also have "... = (?Y \\/XBOOLE-0K2 {TARSKIK1 x})/\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using xboole_1_th_23 sorry
        also have "... = (X \\/XBOOLE-0K2 {TARSKIK1 x})/\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using xboole_1_th_39 sorry
        also have "... = X /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using A2 xboole_1_th_12 sorry
        also have "... = (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using funct_1_th_70 sorry
        finally have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} \\/SUBSET-1K4\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
           sorry
        have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} /\\SUBSET-1K9\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} =HIDDENR1 (?Y /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y})/\\SUBSET-1K9\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using funct_1_th_70 sorry
        also have "... = (?Y /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y})/\\SUBSET-1K9\<^bsub>(D)\<^esub> ({TARSKIK1 x} /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y})"
          using funct_1_th_70 sorry
        also have "... = ((F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} /\\SUBSET-1K9\<^bsub>(X)\<^esub> ?Y)/\\SUBSET-1K8\<^bsub>(X)\<^esub> {TARSKIK1 x})/\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using xboole_1_th_16 sorry
        also have "... = (F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} /\\SUBSET-1K9\<^bsub>(X)\<^esub> (?Y /\\SUBSET-1K8\<^bsub>(X)\<^esub> {TARSKIK1 x}))/\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using xboole_1_th_16 sorry
        also have "... = {}XBOOLE-0K1 /\\SUBSET-1K9\<^bsub>(D)\<^esub> F \<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}"
          using A5 sorry
        also have "... = {}XBOOLE-0K1"
           sorry
        finally have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} /\\SUBSET-1K9\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x})\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y} =HIDDENR1 {}XBOOLE-0K1"
           sorry
        then have "cardCARD-1K1 (CoimRELAT-1K13(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,y)) =HIDDENR1 (cardCARD-1K4 ((F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 y}) +NAT-1K1 cardCARD-1K4 ((<*FINSEQ-1K10 F .FUNCT-1K1 x*>)\<inverse>FUNCT-1K6 {TARSKIK1 y}))-XCMPLX-0K6 cardCARD-1K4 ({}XBOOLE-0K1)"
          using A25 A9 card_2_th_45 sorry
        also have "... = cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),y))"
          using A6 finseq_3_th_57 sorry
        finally show "cardCARD-1K1 (CoimRELAT-1K13(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,y)) =HIDDENR1 cardCARD-1K1 (CoimRELAT-1K13(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),y))"
           sorry
      qed "sorry"
      thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
        using classes1_def_10 sorry
    qed "sorry"
    thus " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  not ((X be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) &  not (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2)"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_66:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for X be setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  fix X assume [ty]: "X be setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  let ?dx = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
  assume A1: "?dx be finiteFINSET-1V1"
    and A2: "d inTARSKIR2 ?dx"
  let ?Y = "X \\SUBSET-1K6 {TARSKIK1 d}"
  let ?dy = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)"
  have A3: "?dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> ?Y"
    using relat_1_th_61 sorry
  have A4: "?dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
    using relat_1_th_61 sorry
  have A5: "?dy =XBOOLE-0R4 ?dx \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
  proof-
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
    proof-
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
      proof(rule conjMI)
        show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A6: "y inHIDDENR3 ?dy"
            then have "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 d}"
              using A3 xboole_0_def_4 sorry
            then have A7: " not y inHIDDENR3 {TARSKIK1 d}"
              using xboole_0_def_5 sorry
            have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
              using A3 A6 xboole_0_def_4 sorry
            then have "y inHIDDENR3 ?dx"
              using A3 A4 A6 xboole_0_def_4 sorry
            thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
              using A7 xboole_0_def_5 sorry
          qed "sorry"
          thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
            using tarski_def_3 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A8: "y inHIDDENR3 ?dx \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
          then have A9: " not y inHIDDENR3 {TARSKIK1 d}"
            using xboole_0_def_5 sorry
          have A10: "y inHIDDENR3 ?dx"
            using A8 xboole_0_def_5 sorry
          then have "y inHIDDENR3 X"
            using A4 xboole_0_def_4 sorry
          then have A11: "y inHIDDENR3 ?Y"
            using A9 xboole_0_def_5 sorry
          have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
            using A4 A10 xboole_0_def_4 sorry
          thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
            using A3 A11 xboole_0_def_4 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
          using tarski_def_3 sorry
      qed
      thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
        using xboole_0_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?dx =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X)"
    using relat_1_th_61 sorry
  also have "... = (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using relat_1_th_71 sorry
  also have "... = F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
    using relat_1_th_68 sorry
  finally have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?dx =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
     sorry
  then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?dx \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
    using A1 A2 rfunct_3_th_65 sorry
  thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
    using A1 A5 rfunct_3_th_63 sorry
qed "sorry"

mtheorem rfunct_3_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 cardCARD-1K4 Y"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies cardCARD-1K4 Y =HIDDENR1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
    obtain fs where 
      [ty]:"fs be finiteFINSET-1V1\<bar>setHIDDENM2" and fsDef:"fs = domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
       sorry
    have A1: "domFINSEQ-1K5 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X))"
      using finseq_1_def_3 sorry
    assume A2: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using A2 rfunct_3_def_13 sorry
    then have "cardCARD-1K4 Y =HIDDENR1 cardCARD-1K4 fs"
      using A2 classes1_th_81 sorry
    also have "... = lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
      using A1 finseq_1_th_57 sorry
    finally show "cardCARD-1K4 Y =HIDDENR1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_68:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {}XBOOLE-0K1) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> {}XBOOLE-0K1"
    using relat_1_th_61 sorry
  also have "... = {}XBOOLE-0K1"
     sorry
  finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {}XBOOLE-0K1) =HIDDENR1 {}XBOOLE-0K1"
     sorry
  then have "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =COMPLEX1R1 0NUMBERSK6"
    using rfunct_3_th_67 card_1_th_27 sorry
  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
     sorry
qed "sorry"

mtheorem rfunct_3_th_69:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =FINSEQ-1R1 <*FINSEQ-1K10 F .FUNCT-1K1 d*>"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
  then have "{TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    using zfmisc_1_th_31 sorry
  then have A1: "{TARSKIK1 d} =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> {TARSKIK1 d}"
    using xboole_1_th_28 sorry
  also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
    using relat_1_th_61 sorry
  finally have "{TARSKIK1 d} =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
     sorry
  then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})are-fiberwise-equipotentCLASSES1R2"
    using rfunct_3_def_13 sorry
  then have A2: "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
    using classes1_th_75 sorry
  have A3: "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) =MEMBEREDR9 {TARSKIK1 F .FUNCT-1K1 d }"
  proof-
    have "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) c=MEMBEREDR3 {TARSKIK1 F .FUNCT-1K1 d } & {TARSKIK1 F .FUNCT-1K1 d } c=TARSKIR1 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
    proof(rule conjMI)
      show "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) c=MEMBEREDR3 {TARSKIK1 F .FUNCT-1K1 d }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) implies x inHIDDENR3 {TARSKIK1 F .FUNCT-1K1 d }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
          then obtain e where
            [ty]:"e be ElementSUBSET-1M1-of D" and 
            A4: "e inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"and A5: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}).FUNCT-1K1 e =HIDDENR1 x"
            using partfun1_th_3 sorry
          have "e =XBOOLE-0R4 d"
            using A1 A4 tarski_def_1 sorry
          then have "x =HIDDENR1 F .FUNCT-1K1 d"
            using A4 A5 funct_1_th_47 sorry
          thus "x inHIDDENR3 {TARSKIK1 F .FUNCT-1K1 d }"
            using tarski_def_1 sorry
        qed "sorry"
        thus "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) c=MEMBEREDR3 {TARSKIK1 F .FUNCT-1K1 d }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 F .FUNCT-1K1 d } implies x inHIDDENR3 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A6: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
          using A1 tarski_def_1 sorry
        assume "x inHIDDENR3 {TARSKIK1 F .FUNCT-1K1 d }"
        then have "x =HIDDENR1 F .FUNCT-1K1 d"
          using tarski_def_1 sorry
        then have "x =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}).FUNCT-1K1 d"
          using A6 funct_1_th_47 sorry
        thus "x inHIDDENR3 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
          using A6 funct_1_def_3 sorry
      qed "sorry"
      thus "{TARSKIK1 F .FUNCT-1K1 d } c=TARSKIR1 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d})"
        using tarski_def_3 sorry
    qed
    thus "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 d}) =MEMBEREDR9 {TARSKIK1 F .FUNCT-1K1 d }"
      using xboole_0_def_10 sorry
  qed
  have "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =HIDDENR1 cardCARD-1K4 {TARSKIK1 d}"
    using A1 rfunct_3_th_67 sorry
  also have "... = \<one>\<^sub>M"
    using card_1_th_30 sorry
  finally have "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =HIDDENR1 \<one>\<^sub>M"
     sorry
  thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =FINSEQ-1R1 <*FINSEQ-1K10 F .FUNCT-1K1 d*>"
    using A2 A3 finseq_1_th_39 sorry
qed "sorry"

mtheorem rfunct_3_th_70:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & (d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    let ?dx = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?fx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    let ?fy = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d})"
    assume A1: "?dx be finiteFINSET-1V1"
      and A2: "d inTARSKIR2 ?dx"
      and A3: "?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx =COMPLEX1R1 F .FUNCT-1K1 d"
    have A4: "(?fx,F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using A1 rfunct_3_def_13 sorry
    then have "rngRVSUM-1K1 ?fx =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using classes1_th_75 sorry
    then have "?fx <>HIDDENR2 {}XBOOLE-0K1"
      using A2 funct_1_th_3 relat_1_th_38 sorry
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fx"
      using nat_1_th_13 sorry
    then have "maxXXREAL-0K5(0NUMBERSK6,lenFINSEQ-1K4 ?fx -XCMPLX-0K6 \<one>\<^sub>M) =COMPLEX1R1 lenFINSEQ-1K4 ?fx -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_2_th_4 sorry
    then obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = lenFINSEQ-1K4 ?fx -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_2_th_5 sorry
    have "lenFINSEQ-1K4 ?fx =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have A5: "?fx =FINSEQ-1R1 ?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
      using A3 rfinseq_th_7 sorry
    have A6: "?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n be non-increasingRFINSEQV1"
      using rfinseq_th_20 sorry
    have "(?fy ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using A1 A2 rfunct_3_th_66 sorry
    then have "(?fx,?fy ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>))are-fiberwise-equipotentCLASSES1R2"
      using A4 classes1_th_76 sorry
    then have "(?fy,?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)are-fiberwise-equipotentCLASSES1R2"
      using A5 rfinseq_th_1 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
      using A5 A6 rfinseq_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rfunct_3_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & 0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) implies (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & (Y c=TARSKIR1 X & (0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2))) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A1: "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
    assume A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      and "Y c=TARSKIR1 X"
      and A3: "0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z"
      and " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
    have A4: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 {}XBOOLE-0K1"
      using A1 A3 sorry
    have A5: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Y)"
      using relat_1_th_61 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
      using relat_1_th_61 sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {}XBOOLE-0K1"
      using A5 A4 xboole_1_th_50 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
       sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
       sorry
    then have A6: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X))"
      using A2 rfunct_3_th_63 sorry
    also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
      using A2 rfunct_3_th_63 sorry
    finally have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
       sorry
    have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1)"
      using A4 rfunct_3_th_63 sorry
    also have "... = {}XBOOLE-0K1"
      using rfunct_3_th_68 sorry
    finally have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) =HIDDENR1 {}XBOOLE-0K1"
       sorry
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
      using A6 finseq_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma rfunct_3_lm_4:
" for n be NatNAT-1M1 holds ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)) implies ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y))"
proof-
  have " for n be NatNAT-1M1 holds ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)) implies ( for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for dy be finiteFINSET-1V1\<bar>setHIDDENM2 holds dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & (Y c=TARSKIR1 X & (n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 dy & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)))) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y))"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?dx = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?dxy = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y))"
    let ?fy = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y)"
    let ?fxy = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
    fix dy assume [ty]: "dy be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A2: "dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      and A3: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      and A4: "Y c=TARSKIR1 X"
      and A5: "n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 dy"
      and A6: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 ?dxy implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
    have A7: "lenFINSEQ-1K4 ?fy =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using A2 A5 rfunct_3_th_67 sorry
    have A8: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y,?fy)are-fiberwise-equipotentCLASSES1R2"
      using A2 rfunct_3_def_13 sorry
    then have A9: "rngRVSUM-1K1 ?fy =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      using classes1_th_75 sorry
    have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    then have A10: "lenFINSEQ-1K4 ?fy inTARSKIR2 domFINSEQ-1K5 ?fy"
      using A7 finseq_3_th_25 sorry
    then have "?fy .FUNCT-1K1 lenFINSEQ-1K4 ?fy inTARSKIR2 rngRVSUM-1K1 ?fy"
      using funct_1_def_3 sorry
    then obtain d where
      [ty]:"d be ElementSUBSET-1M1-of D" and 
      A11: "d inTARSKIR2 dy"and A12: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 d =COMPLEX1R1 ?fy .FUNCT-1K1 lenFINSEQ-1K4 ?fy"
      using A2 A9 partfun1_th_3 sorry
    have A13: "?dxy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 Y)"
      using relat_1_th_61 sorry
    have A14: "dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
      using A2 relat_1_th_61 sorry
    then have A15: "d inTARSKIR2 Y"
      using A11 xboole_0_def_4 sorry
    then have A16: "{TARSKIK1 d} c=TARSKIR1 X"
      using A4 zfmisc_1_th_31 sorry
    have A17: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using A14 A11 xboole_0_def_4 sorry
    then have A18: "{TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using zfmisc_1_th_31 sorry
    have A19: "{TARSKIK1 d} c=TARSKIR1 Y"
      using A15 zfmisc_1_th_31 sorry
    have A20: "(?fxy ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy)are-fiberwise-equipotentCLASSES1R2"
      using rfinseq_th_2 sorry
    let ?Yd = "Y \\SUBSET-1K6 {TARSKIK1 d}"
    let ?dyd = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Yd)"
    let ?xyd = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 ?Yd))"
    have A21: "?xyd =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> (X \\SUBSET-1K6 ?Yd)"
      using relat_1_th_61 sorry
    have A22: "?dyd =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(Y)\<^esub> ?Yd"
      using relat_1_th_61 sorry
    have A23: "?dyd =XBOOLE-0R4 dy \\SUBSET-1K6 {TARSKIK1 d}"
    proof-
      have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 dy \\SUBSET-1K6 {TARSKIK1 d}"
      proof-
        have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 dy \\SUBSET-1K6 {TARSKIK1 d} & dy \\SUBSET-1K6 {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d}))"
        proof(rule conjMI)
          show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 dy \\SUBSET-1K6 {TARSKIK1 d}"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) implies y inHIDDENR3 dy \\SUBSET-1K6 {TARSKIK1 d}"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              assume A24: "y inHIDDENR3 ?dyd"
              then have "y inHIDDENR3 Y \\SUBSET-1K6 {TARSKIK1 d}"
                using A22 xboole_0_def_4 sorry
              then have A25: " not y inHIDDENR3 {TARSKIK1 d}"
                using xboole_0_def_5 sorry
              have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                using A22 A24 xboole_0_def_4 sorry
              then have "y inHIDDENR3 dy"
                using A14 A22 A24 xboole_0_def_4 sorry
              thus "y inHIDDENR3 dy \\SUBSET-1K6 {TARSKIK1 d}"
                using A25 xboole_0_def_5 sorry
            qed "sorry"
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 dy \\SUBSET-1K6 {TARSKIK1 d}"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 dy \\SUBSET-1K6 {TARSKIK1 d} implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d}))"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A26: "y inHIDDENR3 dy \\SUBSET-1K6 {TARSKIK1 d}"
            then have " not y inHIDDENR3 {TARSKIK1 d} & y inHIDDENR3 Y"
              using A14 xboole_0_def_4 xboole_0_def_5 sorry
            then have A27: "y inHIDDENR3 ?Yd"
              using xboole_0_def_5 sorry
            have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
              using A14 A26 xboole_0_def_4 sorry
            thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d}))"
              using A22 A27 xboole_0_def_4 sorry
          qed "sorry"
          thus "dy \\SUBSET-1K6 {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d}))"
            using tarski_def_3 sorry
        qed
        thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 dy \\SUBSET-1K6 {TARSKIK1 d}"
          using xboole_0_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A28: "F .FUNCT-1K1 d =COMPLEX1R1 ?fy .FUNCT-1K1 lenFINSEQ-1K4 ?fy"
      using A2 A11 A12 funct_1_th_47 sorry
    then have A29: "?fy =FINSEQ-1R1 ?fy  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
      using A7 rfinseq_th_7 sorry
    obtain dyd where 
      [ty]:"dyd be finiteFINSET-1V1\<bar>setHIDDENM2" and dydDef:"dyd = ?dyd"
      using A23 sorry
    have A30: "X \\SUBSET-1K6 ?Yd =HIDDENR1 (X \\SUBSET-1K6 Y)\\/XBOOLE-0K2 X /\\XBOOLE-0K3 {TARSKIK1 d}"
      using xboole_1_th_52 sorry
    also have "... = (X \\SUBSET-1K6 Y)\\/XBOOLE-0K2 {TARSKIK1 d}"
      using A16 xboole_1_th_28 sorry
    finally have "X \\SUBSET-1K6 ?Yd =HIDDENR1 (X \\SUBSET-1K6 Y)\\/XBOOLE-0K2 {TARSKIK1 d}"
       sorry
    then have A31: "?xyd =HIDDENR1 ?dxy \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> {TARSKIK1 d}"
      using A13 A21 xboole_1_th_23 sorry
    also have "... = ?dxy \\/XBOOLE-0K2 {TARSKIK1 d}"
      using A18 xboole_1_th_28 sorry
    finally have "?xyd =HIDDENR1 ?dxy \\/XBOOLE-0K2 {TARSKIK1 d}"
       sorry
    have A32: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 dyd & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 (Y \\SUBSET-1K6 {TARSKIK1 d}))) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
      fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
      assume A33: "d1 inTARSKIR2 dyd"
        and A34: "d2 inTARSKIR2 ?xyd"
      have "d2 inTARSKIR2 ?dxy & F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2 or d2 inTARSKIR2 {TARSKIK1 d} & (d2 inTARSKIR2 {TARSKIK1 d} implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)"
      proof-
        show "d2 inTARSKIR2 ?dxy & F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2 or d2 inTARSKIR2 {TARSKIK1 d} & (d2 inTARSKIR2 {TARSKIK1 d} implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)"
        proof-
          have cases: "d2 inTARSKIR2 ?dxy or d2 inTARSKIR2 {TARSKIK1 d}"
            using A31 A34 xboole_0_def_3 sorry
          have case1: "d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
          proof(rule impI)
            assume "d2 inTARSKIR2 ?dxy"
            thus "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
              using A2 A6 A23 A33 sorry
          qed
          have case2: "d2 inTARSKIR2 {TARSKIK1 d} implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
          proof(rule impI)
            assume "d2 inTARSKIR2 {TARSKIK1 d}"
            then have A35: "d2 =XBOOLE-0R4 d"
              using tarski_def_1 sorry
            have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 d1 inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
              using A2 A23 A33 funct_1_def_3 sorry
            then have "F .FUNCT-1K1 d1 inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
              using A2 A23 A33 funct_1_th_47 sorry
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A36: "m inTARSKIR2 domFINSEQ-1K5 ?fy"and A37: "?fy .FUNCT-1K1 m =COMPLEX1R1 F .FUNCT-1K1 d1"
              using A9 finseq_2_th_10 sorry
            have A38: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?fy"
              using A36 finseq_3_th_25 sorry
            have "m =COMPLEX1R1 lenFINSEQ-1K4 ?fy & F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2 or m <>HIDDENR2 lenFINSEQ-1K4 ?fy & (m <>HIDDENR2 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)"
            proof-
              show "m =COMPLEX1R1 lenFINSEQ-1K4 ?fy & F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2 or m <>HIDDENR2 lenFINSEQ-1K4 ?fy & (m <>HIDDENR2 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)"
              proof-
                have cases: "m =COMPLEX1R1 lenFINSEQ-1K4 ?fy or m <>HIDDENR2 lenFINSEQ-1K4 ?fy"
                   sorry
                have case1: "m =COMPLEX1R1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
                proof(rule impI)
                  assume "m =COMPLEX1R1 lenFINSEQ-1K4 ?fy"
                  thus "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
                    using A2 A11 A12 A35 A37 funct_1_th_47 sorry
                qed
                have case2: "m <>HIDDENR2 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
                proof(rule impI)
                  assume "m <>HIDDENR2 lenFINSEQ-1K4 ?fy"
                  then have "m <XXREAL-0R3 lenFINSEQ-1K4 ?fy"
                    using A38 xxreal_0_th_1 sorry
                  thus "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
                    using A10 A28 A35 A36 A37 rfinseq_th_19 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
         sorry
    qed "sorry"
    have "?dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    then have A39: "?dxy be finiteFINSET-1V1"
      using A3 A13 finset_1_th_1 xboole_1_th_26 sorry
    then have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y),?fxy)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_def_13 sorry
    then have A40: "rngRVSUM-1K1 ?fxy =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y))"
      using classes1_th_75 sorry
    have A41: "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy be non-increasingRFINSEQV1"
    proof-
      have "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y) be non-increasingRFINSEQV1"
      proof-
        let ?xfy = "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy"
        have " for n be NatNAT-1M1 holds n inTARSKIR2 domFINSEQ-1K5 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)) & n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)) implies ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        proof(rule ballI,rule impMI ,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A42: "n inTARSKIR2 domFINSEQ-1K5 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy)"
            and A43: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy)"
          have A44: "\<one>\<^sub>M <=XXREAL-0R1 n"
            using A42 finseq_3_th_25 sorry
          then have "maxXXREAL-0K5(0NUMBERSK6,n -XCMPLX-0K6 \<one>\<^sub>M) =COMPLEX1R1 n -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_4 sorry
          then obtain n1 where 
            [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and n1Def:"n1 = n -XCMPLX-0K6 \<one>\<^sub>M"
            using finseq_2_th_5 sorry
          let ?r = "?xfy .FUNCT-1K1 n"
          let ?s = "?xfy .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          have A45: "lenFINSEQ-1K4 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>) =COMPLEX1R1 \<one>\<^sub>M"
            using finseq_1_th_40 sorry
          then have "lenFINSEQ-1K4 ?xfy =COMPLEX1R1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 ?fxy"
            using finseq_1_th_22 sorry
          then have A46: "lenFINSEQ-1K4 ?fxy =COMPLEX1R1 lenFINSEQ-1K4 ?xfy -XCMPLX-0K6 \<one>\<^sub>M"
             sorry
          have A47: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?xfy"
            using A43 finseq_3_th_25 sorry
          then have "n1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fxy"
            using A46 xreal_1_th_19 sorry
          then have A48: "n1 +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?fxy"
            using A44 finseq_3_th_25 sorry
          then have "?fxy .FUNCT-1K1 (n1 +NAT-1K1 \<one>\<^sub>M) inTARSKIR2 rngRVSUM-1K1 ?fxy"
            using funct_1_def_3 sorry
          then obtain d1 where
            [ty]:"d1 be ElementSUBSET-1M1-of D" and 
            A49: "d1 inTARSKIR2 ?dxy & (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)).FUNCT-1K1 d1 =COMPLEX1R1 ?fxy .FUNCT-1K1 (n1 +NAT-1K1 \<one>\<^sub>M)"
            using A40 partfun1_th_3 sorry
          have "\<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A44 nat_1_th_13 sorry
          then have A50: "?xfy .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?fxy .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A45 A47 finseq_1_th_24 sorry
          also have "... = ?fxy .FUNCT-1K1 (n1 +NAT-1K1 \<one>\<^sub>M)"
             sorry
          finally have "?xfy .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?fxy .FUNCT-1K1 (n1 +NAT-1K1 \<one>\<^sub>M)"
             sorry
          have A51: "n <=XXREAL-0R1 lenFINSEQ-1K4 ?xfy"
            using A42 finseq_3_th_25 sorry
          then have A52: "n1 <=XXREAL-0R1 lenFINSEQ-1K4 ?fxy"
            using A46 xreal_1_th_9 sorry
          have A53: "F .FUNCT-1K1 d1 =COMPLEX1R1 ?fxy .FUNCT-1K1 (n1 +NAT-1K1 \<one>\<^sub>M) & F .FUNCT-1K1 d >=XXREAL-0R2 F .FUNCT-1K1 d1"
            using A2 A6 A11 A49 funct_1_th_47 sorry
          have "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
          proof-
            show "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have cases: "n =COMPLEX1R1 \<one>\<^sub>M or n <>HIDDENR2 \<one>\<^sub>M"
                 sorry
              have case1: "n =COMPLEX1R1 \<one>\<^sub>M implies ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "n =COMPLEX1R1 \<one>\<^sub>M"
                thus "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A50 A53 finseq_1_th_41 sorry
              qed
              have case2: "n <>HIDDENR2 \<one>\<^sub>M implies ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
              proof(rule impI)
                assume "n <>HIDDENR2 \<one>\<^sub>M"
                then have A54: "\<one>\<^sub>M <XXREAL-0R3 n"
                  using A44 xxreal_0_th_1 sorry
                then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                  using nat_1_th_13 sorry
                then have "\<one>\<^sub>M <=XXREAL-0R1 n1"
                  using xreal_1_th_19 sorry
                then have A55: "n1 inTARSKIR2 domFINSEQ-1K5 ?fxy"
                  using A52 finseq_3_th_25 sorry
                have "?xfy .FUNCT-1K1 n =COMPLEX1R1 ?fxy .FUNCT-1K1 n1"
                  using A45 A51 A54 finseq_1_th_24 sorry
                thus "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
                  using A48 A50 A55 rfinseq_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 n >=XXREAL-0R2 ((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed "sorry"
        thus "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y) be non-increasingRFINSEQV1"
          using rfinseq_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A56: "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using rvsum_1_th_145 sorry
    have "d inTARSKIR2 {TARSKIK1 d}"
      using tarski_def_1 sorry
    then have "d inTARSKIR2 X \\SUBSET-1K6 ?Yd"
      using A30 xboole_0_def_3 sorry
    then have A57: "d inTARSKIR2 ?xyd"
      using A21 A17 xboole_0_def_4 sorry
    have "(X \\SUBSET-1K6 ?Yd)\\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 d} =HIDDENR1 X \\SUBSET-1K6 (?Yd \\/XBOOLE-0K2 {TARSKIK1 d})"
      using xboole_1_th_41 sorry
    also have "... = X \\SUBSET-1K6 (Y \\/XBOOLE-0K2 {TARSKIK1 d})"
      using xboole_1_th_39 sorry
    also have "... = X \\SUBSET-1K6 Y"
      using A19 xboole_1_th_12 sorry
    finally have "(X \\SUBSET-1K6 ?Yd)\\SUBSET-1K7\<^bsub>(X)\<^esub> {TARSKIK1 d} =HIDDENR1 X \\SUBSET-1K6 Y"
       sorry
    then have "(?fxy ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 ?Yd))are-fiberwise-equipotentCLASSES1R2"
      using A39 A31 A57 rfunct_3_th_66 sorry
    then have "((<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy,F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 ?Yd))are-fiberwise-equipotentCLASSES1R2"
      using A20 classes1_th_76 sorry
    then have A58: "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>)^FINSEQ-1K8 ?fxy =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 ?Yd)"
      using A39 A31 A41 rfunct_3_def_13 A56 sorry
    have "{TARSKIK1 d} c=TARSKIR1 dy"
      using A11 zfmisc_1_th_31 sorry
    then have "cardCARD-1K4 dyd =HIDDENR1 cardCARD-1K4 dy -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 d}"
      using A23 card_2_th_44 sorry
    also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using A5 card_1_th_30 sorry
    also have "... = n"
       sorry
    finally have "cardCARD-1K4 dyd =HIDDENR1 n"
       sorry
    then have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Yd) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 ?Yd)"
      using A1 A3 A4 A32 xboole_1_th_1 sorry
    then have A59: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Yd) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>))^FINSEQ-1K8 ?fxy"
      using A58 finseq_1_th_32 sorry
    have A60: "?fy  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n be non-increasingRFINSEQV1"
      using rfinseq_th_20 sorry
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y,FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Yd) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>))are-fiberwise-equipotentCLASSES1R2"
      using A2 A11 rfunct_3_th_66 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Yd) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>),?fy)are-fiberwise-equipotentCLASSES1R2"
      using A8 classes1_th_76 sorry
    then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Yd),?fy  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)are-fiberwise-equipotentCLASSES1R2"
      using A29 rfinseq_th_1 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
      using A59 A29 A60 rfinseq_th_23 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_71:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & Y c=TARSKIR1 X) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & (Y c=TARSKIR1 X & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2)) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    have A1: " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds (((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1) & Y c=TARSKIR1 X) & n =COMPLEX1R1 cardCARD-1K4 Z) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
      using nat_1_sch_2 rfunct_3_lm_3 rfunct_3_lm_4 sorry
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      and A3: "Y c=TARSKIR1 X"
      and A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & d2 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 Y)) implies F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d2"
    have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y c=RELSET-1R1\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using A3 relat_1_th_75 sorry
    then obtain dFY where 
      [ty]:"dFY be finiteFINSET-1V1\<bar>setHIDDENM2" and dFYDef:"dFY = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      using A2 finset_1_th_1 relat_1_th_11 sorry
    have "cardCARD-1K4 dFY =COMPLEX1R1 cardCARD-1K4 dFY"
       sorry
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 Y)"
      using A1 A2 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_72:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d iff FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d) & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) <>HIDDENR2 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d implies  False )"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    let ?dx = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?drx = "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?frx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X)"
    let ?fx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    assume A1: "?dx be finiteFINSET-1V1"
      and A2: "d inTARSKIR2 ?dx"
    obtain dx where 
      [ty]:"dx be finiteFINSET-1V1\<bar>setHIDDENM2" and dxDef:"dx = ?dx"
      using A1 sorry
    have A3: "?drx =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using valued_1_th_3 sorry
    also have "... = dx"
      using relat_1_th_61 sorry
    finally have "?drx =HIDDENR1 dx"
       sorry
    then have "(?fx,F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using rfunct_3_def_13 sorry
    then have A4: "rngRVSUM-1K1 ?fx =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using classes1_th_75 sorry
    then have "?fx <>HIDDENR2 {}XBOOLE-0K1"
      using A2 funct_1_th_3 relat_1_th_38 sorry
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ?fx"
      using nat_1_th_13 sorry
    then have A5: "lenFINSEQ-1K4 ?fx inTARSKIR2 domFINSEQ-1K5 ?fx"
      using finseq_3_th_25 sorry
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A2 funct_1_def_3 sorry
    then have "F .FUNCT-1K1 d inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A2 funct_1_th_47 sorry
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A6: "n inTARSKIR2 domFINSEQ-1K5 ?fx"and A7: "?fx .FUNCT-1K1 n =COMPLEX1R1 F .FUNCT-1K1 d"
      using A4 finseq_2_th_10 sorry
    have A8: "domFINSEQ-1K5 ?fx =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fx)"
      using finseq_1_def_3 sorry
    have "(?frx,(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using A3 rfunct_3_def_13 sorry
    then have A9: "rngRVSUM-1K1 ?frx =MEMBEREDR9 rngRVSUM-1K1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using classes1_th_75 sorry
    have A10: "lenFINSEQ-1K4 ?fx =COMPLEX1R1 cardCARD-1K4 dx & domFINSEQ-1K5 ?frx =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?frx)"
      using rfunct_3_th_67 finseq_1_def_3 sorry
    have A11: "lenFINSEQ-1K4 ?frx =COMPLEX1R1 cardCARD-1K4 dx"
      using A3 rfunct_3_th_67 sorry
    then have "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx inTARSKIR2 rngRVSUM-1K1 ?frx"
      using A10 A8 A5 funct_1_def_3 sorry
    then obtain d1 where
      [ty]:"d1 be ElementSUBSET-1M1-of D" and 
      A12: "d1 inTARSKIR2 ?drx"and A13: "((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d1 =COMPLEX1R1 ?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx"
      using A9 partfun1_th_3 sorry
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d1 =COMPLEX1R1 F .FUNCT-1K1 d1"
      using A3 A12 funct_1_th_47 sorry
    then have "F .FUNCT-1K1 d1 inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A3 A12 funct_1_def_3 sorry
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A14: "m inTARSKIR2 domFINSEQ-1K5 ?fx"and A15: "?fx .FUNCT-1K1 m =COMPLEX1R1 F .FUNCT-1K1 d1"
      using A4 finseq_2_th_10 sorry
    have A16: "domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F"
      using valued_1_th_3 sorry
    have A17: "?drx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    then have A18: "d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using A12 xboole_0_def_4 sorry
    have A19: "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx =HIDDENR1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d1"
      using A12 A13 funct_1_th_47 sorry
    also have "... = F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
      using A16 A18 valued_1_th_3 sorry
    finally have "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx =HIDDENR1 F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
       sorry
    have A20: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
      using A2 A3 A17 xboole_0_def_4 sorry
    then have A21: "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 F .FUNCT-1K1 d -XCMPLX-0K6 r"
      using A16 valued_1_th_3 sorry
    have A22: "n <=XXREAL-0R1 lenFINSEQ-1K4 ?fx"
      using A6 finseq_3_th_25 sorry
    show "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 F .FUNCT-1K1 d"
    proof-
      have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d & FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) .FUNCT-1K1 lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) <>HIDDENR2 F .FUNCT-1K1 d implies  False "
      proof(rule impMI ,rule impI)
        have "?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx inTARSKIR2 rngRVSUM-1K1 ?fx"
          using A5 funct_1_def_3 sorry
        then obtain d1 where
          [ty]:"d1 be ElementSUBSET-1M1-of D" and 
          A23: "d1 inTARSKIR2 dx"and A24: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d1 =COMPLEX1R1 ?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx"
          using A4 partfun1_th_3 sorry
        have A25: "d1 inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
          using A3 A17 A23 xboole_0_def_4 sorry
        have A26: "F .FUNCT-1K1 d1 =COMPLEX1R1 ?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx"
          using A23 A24 funct_1_th_47 sorry
        have "((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d1 =HIDDENR1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d1"
          using A3 A23 funct_1_th_47 sorry
        also have "... = F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
          using A16 A25 valued_1_th_3 sorry
        finally have "((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d1 =HIDDENR1 F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
           sorry
        then have "F .FUNCT-1K1 d1 -XCMPLX-0K6 r inTARSKIR2 rngRVSUM-1K1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using A3 A23 funct_1_def_3 sorry
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A27: "m inTARSKIR2 domFINSEQ-1K5 ?frx"and A28: "?frx .FUNCT-1K1 m =COMPLEX1R1 F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
          using A9 finseq_2_th_10 sorry
        have A29: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?frx"
          using A27 finseq_3_th_25 sorry
        assume A30: "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx =COMPLEX1R1 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d"
          and A31: "?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx <>HIDDENR2 F .FUNCT-1K1 d"
        have "n <XXREAL-0R3 lenFINSEQ-1K4 ?fx"
          using A7 A22 A31 xxreal_0_th_1 sorry
        then have A32: "F .FUNCT-1K1 d >=XXREAL-0R2 F .FUNCT-1K1 d1"
          using A5 A6 A7 A26 rfinseq_th_19 sorry
        have "lenFINSEQ-1K4 ?frx =COMPLEX1R1 m &  False  or lenFINSEQ-1K4 ?frx <>HIDDENR2 m & (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) <>HIDDENR2 m implies  False )"
        proof-
          show "lenFINSEQ-1K4 ?frx =COMPLEX1R1 m &  False  or lenFINSEQ-1K4 ?frx <>HIDDENR2 m & (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) <>HIDDENR2 m implies  False )"
          proof-
            have cases: "lenFINSEQ-1K4 ?frx =COMPLEX1R1 m or lenFINSEQ-1K4 ?frx <>HIDDENR2 m"
               sorry
            have case1: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 m implies  False "
            proof(rule impI)
              assume "lenFINSEQ-1K4 ?frx =COMPLEX1R1 m"
              then have "F .FUNCT-1K1 d1 +XCMPLX-0K2 (-XCMPLX-0K4 r) =COMPLEX1R1 F .FUNCT-1K1 d -XCMPLX-0K6 r"
                using A16 A20 A30 A28 valued_1_th_3 sorry
              thus " False "
                using A31 A23 A24 funct_1_th_47 sorry
            qed
            have case2: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) <>HIDDENR2 m implies  False "
            proof(rule impI)
              assume "lenFINSEQ-1K4 ?frx <>HIDDENR2 m"
              then have "m <XXREAL-0R3 lenFINSEQ-1K4 ?frx"
                using A29 xxreal_0_th_1 sorry
              then have "F .FUNCT-1K1 d1 -XCMPLX-0K6 r >=XXREAL-0R2 F .FUNCT-1K1 d -XCMPLX-0K6 r"
                using A11 A10 A8 A21 A5 A30 A27 A28 rfinseq_th_19 sorry
              then have "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d"
                using xreal_1_th_9 sorry
              thus " False "
                using A31 A26 A32 xxreal_0_th_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " False "
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A33: "?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx =COMPLEX1R1 F .FUNCT-1K1 d"
      and A34: "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx <>HIDDENR2 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d"
    have "((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d inTARSKIR2 rngRVSUM-1K1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A2 A3 funct_1_def_3 sorry
    then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d inTARSKIR2 rngRVSUM-1K1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A2 A3 funct_1_th_47 sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A35: "n1 inTARSKIR2 domFINSEQ-1K5 ?frx"and A36: "?frx .FUNCT-1K1 n1 =COMPLEX1R1 F .FUNCT-1K1 d -XCMPLX-0K6 r"
      using A9 A21 finseq_2_th_10 sorry
    have "n1 <=XXREAL-0R1 lenFINSEQ-1K4 ?frx"
      using A35 finseq_3_th_25 sorry
    then have "n1 <XXREAL-0R3 lenFINSEQ-1K4 ?frx"
      using A21 A34 A36 xxreal_0_th_1 sorry
    then have "F .FUNCT-1K1 d -XCMPLX-0K6 r >=XXREAL-0R2 F .FUNCT-1K1 d1 -XCMPLX-0K6 r"
      using A11 A10 A8 A5 A19 A35 A36 rfinseq_th_19 sorry
    then have A37: "F .FUNCT-1K1 d >=XXREAL-0R2 F .FUNCT-1K1 d1"
      using xreal_1_th_9 sorry
    have A38: "m <=XXREAL-0R1 lenFINSEQ-1K4 ?fx"
      using A14 finseq_3_th_25 sorry
    have "lenFINSEQ-1K4 ?fx =COMPLEX1R1 m &  False  or lenFINSEQ-1K4 ?fx <>HIDDENR2 m & (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) <>HIDDENR2 m implies  False )"
    proof-
      show "lenFINSEQ-1K4 ?fx =COMPLEX1R1 m &  False  or lenFINSEQ-1K4 ?fx <>HIDDENR2 m & (lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) <>HIDDENR2 m implies  False )"
      proof-
        have cases: "lenFINSEQ-1K4 ?fx =COMPLEX1R1 m or lenFINSEQ-1K4 ?fx <>HIDDENR2 m"
           sorry
        have case1: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 m implies  False "
        proof(rule impI)
          assume "lenFINSEQ-1K4 ?fx =COMPLEX1R1 m"
          thus " False "
            using A16 A20 A33 A34 A19 A15 valued_1_th_3 sorry
        qed
        have case2: "lenFINSEQ-1K4 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) <>HIDDENR2 m implies  False "
        proof(rule impI)
          assume "lenFINSEQ-1K4 ?fx <>HIDDENR2 m"
          then have "m <XXREAL-0R3 lenFINSEQ-1K4 ?fx"
            using A38 xxreal_0_th_1 sorry
          then have "F .FUNCT-1K1 d1 >=XXREAL-0R2 F .FUNCT-1K1 d"
            using A5 A33 A14 A15 rfinseq_th_19 sorry
          thus " False "
            using A21 A34 A19 A37 xxreal_0_th_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_73:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 Z  |->FINSEQ-2K2 r"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for G be finiteFINSET-1V1\<bar>setHIDDENM2 holds G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix X assume [ty]: "X be setHIDDENM2"
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
      using xreal_0_def_1 sorry
    let ?P = "\<lambda>Lamb1.  for X be setHIDDENM2 holds  for G be finiteFINSET-1V1\<bar>setHIDDENM2 holds G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & Lamb1 =COMPLEX1R1 cardCARD-1K4 G implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for X be setHIDDENM2 holds  for G be finiteFINSET-1V1\<bar>setHIDDENM2 holds G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & n =COMPLEX1R1 cardCARD-1K4 G implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r) implies ( for X be setHIDDENM2 holds  for G be finiteFINSET-1V1\<bar>setHIDDENM2 holds G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 G implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r))"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule impI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: "?P(n)"
        fix X assume [ty]: "X be setHIDDENM2"
        fix G assume [ty]: "G be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A3: "G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        let ?frx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> rr,X)"
        let ?fx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
        have A4: "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using valued_1_th_3 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
           sorry
        then have A5: "lenFINSEQ-1K4 ?frx =COMPLEX1R1 cardCARD-1K4 G"
          using A3 rfunct_3_th_67 sorry
        have A6: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X),(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A3 A4 rfunct_3_def_13 sorry
        then have A7: "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =MEMBEREDR9 rngRVSUM-1K1 ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using classes1_th_75 sorry
        assume A8: "n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 G"
        then have A9: "lenFINSEQ-1K4 ?fx =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using A3 rfunct_3_th_67 sorry
        have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "lenFINSEQ-1K4 ?frx inTARSKIR2 domFINSEQ-1K5 ?frx"
          using A8 A5 finseq_3_th_25 sorry
        then have "?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx inTARSKIR2 rngRVSUM-1K1 ?frx"
          using funct_1_def_3 sorry
        then obtain d where
          [ty]:"d be ElementSUBSET-1M1-of D" and 
          A10: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"and A11: "((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =COMPLEX1R1 ?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx"
          using A7 partfun1_th_3 sorry
        let ?Y = "X \\SUBSET-1K6 {TARSKIK1 d}"
        let ?dx = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        let ?dy = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)"
        let ?fry = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,?Y)"
        let ?fy = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y)"
        let ?n1r = "(n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr"
        let ?nr = "n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr"
        have A12: "{TARSKIK1 d} c=TARSKIR1 ?dx"
          using A4 A10 zfmisc_1_th_31 sorry
        have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 ?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx"
          using A10 A11 funct_1_th_47 sorry
        then have A13: "?fx .FUNCT-1K1 lenFINSEQ-1K4 ?fx =COMPLEX1R1 F .FUNCT-1K1 d"
          using A3 A4 A10 rfunct_3_th_72 sorry
        have "lenFINSEQ-1K4 ?fx =COMPLEX1R1 cardCARD-1K4 G"
          using A3 rfunct_3_th_67 sorry
        then have A14: "?fx =FINSEQ-1R1 ?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
          using A8 A13 rfinseq_th_7 sorry
        have "?fx =FINSEQ-1R1 ?fy ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>)"
          using A3 A4 A10 A13 rfunct_3_th_70 sorry
        then have A15: "?fy =FINSEQ-1R1 ?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A14 finseq_1_th_33 sorry
        have A16: "domFINSEQ-1K5 (?fy -RVSUM-1K9 ?nr) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (?fy -RVSUM-1K9 ?nr))"
          using finseq_1_def_3 sorry
        have A17: "?dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> ?Y"
          using relat_1_th_61 sorry
        have A18: "?dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using relat_1_th_61 sorry
        have A19: "?dy =XBOOLE-0R4 ?dx \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
        proof-
          have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
          proof-
            have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
            proof(rule conjMI)
              show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume A20: "y inHIDDENR3 ?dy"
                  then have "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 d}"
                    using A17 xboole_0_def_4 sorry
                  then have A21: " not y inHIDDENR3 {TARSKIK1 d}"
                    using xboole_0_def_5 sorry
                  have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                    using A17 A20 xboole_0_def_4 sorry
                  then have "y inHIDDENR3 ?dx"
                    using A17 A18 A20 xboole_0_def_4 sorry
                  thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
                    using A21 xboole_0_def_5 sorry
                qed "sorry"
                thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
                  using tarski_def_3 sorry
              qed
              have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A22: "y inHIDDENR3 ?dx \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
                then have A23: " not y inHIDDENR3 {TARSKIK1 d}"
                  using xboole_0_def_5 sorry
                have A24: "y inHIDDENR3 ?dx"
                  using A22 xboole_0_def_5 sorry
                then have "y inHIDDENR3 X"
                  using A18 xboole_0_def_4 sorry
                then have A25: "y inHIDDENR3 ?Y"
                  using A23 xboole_0_def_5 sorry
                have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                  using A18 A24 xboole_0_def_4 sorry
                thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
                  using A17 A25 xboole_0_def_4 sorry
              qed "sorry"
              thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d}))"
                using tarski_def_3 sorry
            qed
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 d})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 d}"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain dx dy where 
          [ty]:"dx be finiteFINSET-1V1\<bar>setHIDDENM2" and dxDef:"dx = ?dx" and
          [ty]:"dy be finiteFINSET-1V1\<bar>setHIDDENM2" and dyDef:"dy = ?dy"
          using A3 sorry
        have A26: "cardCARD-1K4 dy =HIDDENR1 cardCARD-1K4 dx -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 d}"
          using A12 A19 card_2_th_44 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A3 A8 card_1_th_30 sorry
        also have "... = n"
           sorry
        finally have "cardCARD-1K4 dy =HIDDENR1 n"
           sorry
        then have "lenFINSEQ-1K4 ?nr =COMPLEX1R1 n & lenFINSEQ-1K4 ?fy =COMPLEX1R1 n"
          using rfunct_3_th_67 card_1_def_7 sorry
        then have A27: "lenFINSEQ-1K4 (?fy -RVSUM-1K9 ?nr) =COMPLEX1R1 n"
          using finseq_2_th_72 sorry
        have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 ?frx .FUNCT-1K1 lenFINSEQ-1K4 ?frx"
          using A10 A11 funct_1_th_47 sorry
        then have A28: "?frx =FINSEQ-1R1 ?frx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n ^FINSEQ-1K8 (<*FINSEQ-1K10 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d*>)"
          using A8 A5 rfinseq_th_7 sorry
        have "(?fry ^FINSEQ-1K8 (<*FINSEQ-1K10 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d*>),(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A3 A4 A10 rfunct_3_th_66 sorry
        then have "(?fry ^FINSEQ-1K8 (<*FINSEQ-1K10 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d*>),?frx)are-fiberwise-equipotentCLASSES1R2"
          using A6 classes1_th_76 sorry
        then have "?frx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n be non-increasingRFINSEQV1 & (?fry,?frx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n)are-fiberwise-equipotentCLASSES1R2"
          using A28 rfinseq_th_1 rfinseq_th_20 sorry
        then have A29: "?fry =FINSEQ-1R1 ?frx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using rfinseq_th_23 sorry
        have "lenFINSEQ-1K4 ?n1r =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using card_1_def_7 sorry
        then have A30: "lenFINSEQ-1K4 (?fx -RVSUM-1K9 ?n1r) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using A9 finseq_2_th_72 sorry
        then have A31: "domFINSEQ-1K5 (?fx -RVSUM-1K9 ?n1r) =MEMBEREDR12 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using finseq_1_def_3 sorry
        have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using relat_1_th_61 sorry
        then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r)"
          using A10 xboole_0_def_4 sorry
        then have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using valued_1_th_3 sorry
        then have "(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d =COMPLEX1R1 F .FUNCT-1K1 d -XCMPLX-0K6 r"
          using valued_1_th_3 sorry
        then have A32: "<*FINSEQ-1K10 (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r).FUNCT-1K1 d*> =FINSEQ-1R1 <*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>"
          using rvsum_1_th_29 sorry
        have A33: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        have A34: "domFINSEQ-1K5 ?fx =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fx)"
          using finseq_1_def_3 sorry
        obtain Fd rr where 
          [ty]:"Fd be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and FdDef:"Fd = <*FINSEQ-1K10 F .FUNCT-1K1 d*>" and
          [ty]:"rr be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and rrDef:"rr = <*FINSEQ-1K10 r*>"
          using rvsum_1_th_145 sorry
        have "lenFINSEQ-1K4 (<*FINSEQ-1K10 F .FUNCT-1K1 d*>) =COMPLEX1R1 \<one>\<^sub>M & lenFINSEQ-1K4 (<*FINSEQ-1K10 r*>) =COMPLEX1R1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        then have A35: "lenFINSEQ-1K4 (Fd -RVSUM-1K9 rr) =COMPLEX1R1 \<one>\<^sub>M"
          using finseq_2_th_72 sorry
        then have A36: "lenFINSEQ-1K4 ((?fy -RVSUM-1K9 ?nr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          using A27 finseq_1_th_22 sorry
        have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 \<one>\<^sub>M"
          using finseq_1_th_1 sorry
        then have A37: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)"
          using A35 finseq_1_def_3 sorry
        have A38: "(<*FINSEQ-1K10 F .FUNCT-1K1 d*>).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 F .FUNCT-1K1 d & (<*FINSEQ-1K10 r*>).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 r"
          using finseq_1_th_40 sorry
        have A39: " for m be NatNAT-1M1 holds m inTARSKIR2 domFINSEQ-1K5 (?fx -RVSUM-1K9 ?n1r) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m =COMPLEX1R1 ((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m"
        proof(rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          assume A40: "m inTARSKIR2 domFINSEQ-1K5 (?fx -RVSUM-1K9 ?n1r)"
          show "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m =COMPLEX1R1 ((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m"
          proof-
            have cases: "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M or m <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
               sorry
            have case1: "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m =COMPLEX1R1 ((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m"
            proof(rule impI)
              assume A41: "m =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
              then have A42: "?n1r .FUNCT-1K1 m =COMPLEX1R1 r"
                using finseq_1_th_4 funcop_1_th_7 sorry
              have "((?fy -RVSUM-1K9 ?nr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =HIDDENR1 (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>).FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 n)"
                using A27 A36 A33 A41 finseq_1_th_24 sorry
              also have "... = F .FUNCT-1K1 d -XCMPLX-0K6 r"
                using A38 A37 valued_1_th_13 sorry
              finally have "((?fy -RVSUM-1K9 ?nr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =HIDDENR1 F .FUNCT-1K1 d -XCMPLX-0K6 r"
                 sorry
              thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m =COMPLEX1R1 ((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m"
                using A13 A9 A40 A41 A42 valued_1_th_13 sorry
            qed
            have case2: "m <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M implies ((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =HIDDENR1 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m"
            proof(rule impI)
              assume A43: "m <>HIDDENR2 n +NAT-1K1 \<one>\<^sub>M"
              have "m <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using A31 A40 finseq_1_th_1 sorry
              then have "m <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                using A43 xxreal_0_th_1 sorry
              then have A44: "m <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              obtain s where 
                [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = ?fx .FUNCT-1K1 m"
                using xreal_0_def_1 sorry
              have A45: "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_11 sorry
              have A46: "?n1r .FUNCT-1K1 m =COMPLEX1R1 r"
                using A31 A40 funcop_1_th_7 sorry
              have A47: "\<one>\<^sub>M <=XXREAL-0R1 m"
                using A31 A40 finseq_1_th_1 sorry
              then have A48: "m inTARSKIR2 SegFINSEQ-1K2 n"
                using A44 finseq_1_th_1 sorry
              then have A49: "m inTARSKIR2 domFINSEQ-1K5 (?fy -RVSUM-1K9 ?nr)"
                using A27 finseq_1_def_3 sorry
              have "\<one>\<^sub>M <=XXREAL-0R1 n"
                using A47 A44 xxreal_0_th_2 sorry
              then have "n inTARSKIR2 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
                using A45 finseq_1_th_1 sorry
              then have A50: "(?fx  |FINSEQ-1K18\<^bsub>(REALNUMBERSK2)\<^esub> n).FUNCT-1K1 m =COMPLEX1R1 ?fx .FUNCT-1K1 m"
                using A9 A34 A48 rfinseq_th_6 sorry
              have "((?fy -RVSUM-1K9 ?nr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =COMPLEX1R1 (?fy -RVSUM-1K9 ?nr).FUNCT-1K1 m & ?nr .FUNCT-1K1 m =COMPLEX1R1 r"
                using A27 A16 A48 finseq_1_def_7 funcop_1_th_7 sorry
              then have "((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =HIDDENR1 s -XCMPLX-0K6 r"
                using A15 A50 A49 valued_1_th_13 sorry
              also have "... = (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m"
                using A40 A46 valued_1_th_13 sorry
              finally show "((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\SUBSET-1K6 {TARSKIK1 d}) -RVSUM-1K9 n  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (<*FINSEQ-1K10 F .FUNCT-1K1 d*> -RVSUM-1K9 <*FINSEQ-1K10 r*>)).FUNCT-1K1 m =HIDDENR1 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 (n +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr).FUNCT-1K1 m"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        have "?fry =FINSEQ-1R1 ?fy -RVSUM-1K9 ?nr"
          using A2 A26 sorry
        thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
          using A8 A28 A29 A32 A30 A36 A39 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A51: "?P(0NUMBERSK6)"
    proof-
      have " for X be setHIDDENM2 holds  for G be finiteFINSET-1V1\<bar>setHIDDENM2 holds G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 G implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix X assume [ty]: "X be setHIDDENM2"
        fix G assume [ty]: "G be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A52: "G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        assume "0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 G"
        then have A53: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A52 sorry
        then have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1)"
          using rfunct_3_th_63 sorry
        also have "... = <*>FINSEQ-1K7 REALNUMBERSK2"
          using rfunct_3_th_68 sorry
        finally have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 <*>FINSEQ-1K7 REALNUMBERSK2"
           sorry
        then have A54: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr =FINSEQ-1R1 <*>FINSEQ-1K7 REALNUMBERSK2"
          using finseq_2_th_73 sorry
        have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using valued_1_th_3 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
           sorry
        then have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,{}XBOOLE-0K1)"
          using A53 rfunct_3_th_63 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
          using A54 rfunct_3_th_68 sorry
        finally show "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A55: " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A51 A1 sorry
    fix G assume [ty]: "G be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume "G =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) -RVSUM-1K9 cardCARD-1K4 G  |->FINSEQ-2K2 r"
      using A55 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_74:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & ( for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6) implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,X)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      and A2: " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
    have " for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
      assume A3: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      then have "F .FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
        using A2 sorry
      thus "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d >=XXREAL-0R2 0NUMBERSK6"
        using A3 funct_1_th_47 sorry
    qed "sorry"
    then have A4: "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using rfunct_3_th_46 sorry
    also have "... = max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using rfunct_3_th_44 sorry
    finally have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =HIDDENR1 max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
       sorry
    then have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,X)"
      using A1 rfunct_3_th_64 sorry
    also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,X)"
      using A1 A4 rfunct_3_th_64 sorry
    finally show "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(max+RFUNCT-3K18\<^bsub>(D)\<^esub> F,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_75:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {TARSKIK1 r} implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 cardCARD-1K4 Z  |->FINSEQ-2K2 r"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for dx be finiteFINSET-1V1\<bar>setHIDDENM2 holds dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {TARSKIK1 r} implies FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 cardCARD-1K4 dx  |->FINSEQ-2K2 r)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix dx assume [ty]: "dx be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A1: "dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?fx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    assume A2: "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {TARSKIK1 r}"
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,?fx)are-fiberwise-equipotentCLASSES1R2"
      using A1 rfunct_3_def_13 sorry
    then have A3: "rngRVSUM-1K1 ?fx =MEMBEREDR9 {TARSKIK1 r}"
      using A2 classes1_th_75 sorry
    have A4: "domFINSEQ-1K5 ?fx =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?fx)"
      using finseq_1_def_3 sorry
    have "lenFINSEQ-1K4 ?fx =COMPLEX1R1 cardCARD-1K4 dx"
      using A1 rfunct_3_th_67 sorry
    thus "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 cardCARD-1K4 dx  |->FINSEQ-2K2 r"
      using A3 A4 funcop_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_76:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 implies  not (X missesXBOOLE-0R1 Y &  not (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1"
    have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y c=RELSET-1R1\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)"
      using relat_1_th_75 xboole_1_th_7 sorry
    then obtain dfy where 
      [ty]:"dfy be finiteFINSET-1V1\<bar>setHIDDENM2" and dfyDef:"dfy = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      using A1 finset_1_th_1 relat_1_th_11 sorry
    let ?P = "\<lambda>Lamb1.  for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds ((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1) & X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1) & Lamb1 =COMPLEX1R1 cardCARD-1K4 Z implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
    have A2: "cardCARD-1K4 dfy =COMPLEX1R1 cardCARD-1K4 dfy"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds ((Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1) & X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1) & n =COMPLEX1R1 cardCARD-1K4 Z implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2) implies ( for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & (X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 Z)) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2)"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "?P(n)"
        fix Y assume [ty]: "Y be setHIDDENM2"
        fix Z assume [ty]: "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A5: "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
          and A6: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1"
          and A7: "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
          and A8: "n +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 cardCARD-1K4 Z"
        let ?x = "the ElementSUBSET-1M1-of domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
        obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of D" and xDef:"x = ?x"
          using A5 A8 card_1_th_27 tarski_def_3 sorry
        let ?y1 = "Y \\SUBSET-1K6 {TARSKIK1 x}"
        have A9: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using relat_1_th_61 sorry
        have "x inTARSKIR2 X implies  False "
        proof(rule impI)
          assume A10: "x inTARSKIR2 X"
          have "x inTARSKIR2 Y"
            using A5 A8 A9 card_1_th_27 xboole_0_def_4 sorry
          thus " False "
            using A7 A10 xboole_0_def_4 sorry
        qed
        then have "X \\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 X"
          using zfmisc_1_th_57 sorry
        then have A11: "(X \\/XBOOLE-0K2 Y)\\SUBSET-1K6 {TARSKIK1 x} =XBOOLE-0R4 X \\/XBOOLE-0K2 ?y1"
          using xboole_1_th_42 sorry
        have A12: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?y1) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(Y)\<^esub> ?y1"
          using relat_1_th_61 sorry
        have A13: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?y1) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
        proof-
          have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
          proof-
            have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x} & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x}))"
            proof(rule conjMI)
              show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume A14: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?y1)"
                  then have "y inHIDDENR3 Y \\SUBSET-1K6 {TARSKIK1 x}"
                    using A12 xboole_0_def_4 sorry
                  then have A15: " not y inHIDDENR3 {TARSKIK1 x}"
                    using xboole_0_def_5 sorry
                  have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                    using A12 A14 xboole_0_def_4 sorry
                  then have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
                    using A12 A9 A14 xboole_0_def_4 sorry
                  thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
                    using A15 xboole_0_def_5 sorry
                qed "sorry"
                thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
                  using tarski_def_3 sorry
              qed
              have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x} implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x}))"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A16: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
                then have A17: " not y inHIDDENR3 {TARSKIK1 x}"
                  using xboole_0_def_5 sorry
                have A18: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
                  using A16 xboole_0_def_5 sorry
                then have "y inHIDDENR3 Y"
                  using A9 xboole_0_def_4 sorry
                then have A19: "y inHIDDENR3 ?y1"
                  using A17 xboole_0_def_5 sorry
                have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                  using A9 A18 xboole_0_def_4 sorry
                thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x}))"
                  using A12 A19 xboole_0_def_4 sorry
              qed "sorry"
              thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x}))"
                using tarski_def_3 sorry
            qed
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (Y \\SUBSET-1K6 {TARSKIK1 x})) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) \\SUBSET-1K7\<^bsub>(D)\<^esub> {TARSKIK1 x}"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain dFy where 
          [ty]:"dFy be finiteFINSET-1V1\<bar>setHIDDENM2" and dFyDef:"dFy = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?y1)"
          using A5 sorry
        have "{TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
          using A5 A8 card_1_th_27 zfmisc_1_th_31 sorry
        then have A20: "cardCARD-1K4 dFy =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 x}"
          using A5 A8 A13 card_2_th_44 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using card_1_th_30 sorry
        also have "... = n"
           sorry
        finally have "cardCARD-1K4 dFy =HIDDENR1 n"
           sorry
        have "X \\/XBOOLE-0K2 ?y1 c=TARSKIR1 X \\/XBOOLE-0K2 Y"
          using xboole_1_th_13 sorry
        then have "domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 ?y1) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
          using xboole_1_th_27 sorry
        then have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 ?y1)) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
          using relat_1_th_61 sorry
        then have A21: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 ?y1)) c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))"
          using relat_1_th_61 sorry
        have A22: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))are-fiberwise-equipotentCLASSES1R2"
          using A6 rfunct_3_def_13 sorry
        have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using xboole_1_th_23 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
          using relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
           sorry
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))"
          using A5 A8 card_1_th_27 xboole_0_def_3 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))are-fiberwise-equipotentCLASSES1R2"
          using A6 A11 rfunct_3_th_66 sorry
        then have A23: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y))are-fiberwise-equipotentCLASSES1R2"
          using A22 classes1_th_76 sorry
        have "X /\\SUBSET-1K9\<^bsub>(Y)\<^esub> ?y1 c=TARSKIR1 X /\\XBOOLE-0K3 Y"
          using xboole_1_th_27 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1))are-fiberwise-equipotentCLASSES1R2"
          using A4 A6 A7 A21 A20 xboole_1_th_3 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1))^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>))are-fiberwise-equipotentCLASSES1R2"
          using rfinseq_th_1 sorry
        then have A24: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K8 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)))are-fiberwise-equipotentCLASSES1R2"
          using finseq_1_th_32 sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)are-fiberwise-equipotentCLASSES1R2"
          using A5 A8 rfunct_3_def_13 rfunct_3_th_66 card_1_th_27 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
          using classes1_th_76 sorry
        then have A25: "((FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>))^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X))are-fiberwise-equipotentCLASSES1R2"
          using rfinseq_th_1 sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K8 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)),(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>))^FINSEQ-1K8 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X))are-fiberwise-equipotentCLASSES1R2"
          using rfinseq_th_2 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K8 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X))are-fiberwise-equipotentCLASSES1R2"
          using A25 classes1_th_76 rfinseq_th_2 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K8 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>)),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
          using classes1_th_76 sorry
        then have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 ?y1) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
          using A24 classes1_th_76 sorry
        thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
          using A23 classes1_th_76 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A26: "?P(0NUMBERSK6)"
    proof-
      have " for Y be setHIDDENM2 holds  for Z be finiteFINSET-1V1\<bar>setHIDDENM2 holds Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) & (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & (X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 & 0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z)) implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        fix Z assume [ty]: "Z be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A27: "Z =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
          and A28: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1"
          and "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
          and A29: "0NUMBERSK6 =COMPLEX1R1 cardCARD-1K4 Z"
        have A30: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using xboole_1_th_23 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
          using relat_1_th_61 sorry
        also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
          using relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
           sorry
        then have A31: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
          using A28 finset_1_th_1 xboole_1_th_7 sorry
        have A32: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A27 A29 sorry
        then have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X))"
          using A28 A30 rfunct_3_th_63 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
          using A31 rfunct_3_th_63 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> <*>FINSEQ-1K7 REALNUMBERSK2"
          using finseq_1_th_34 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y))"
          using A32 rfunct_3_th_68 sorry
        also have "... = FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y)"
          using A27 rfunct_3_th_63 sorry
        finally have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y)"
           sorry
        thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A33: " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A26 A3 sorry
    have "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1 implies (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
    proof(rule impI)
      assume "X /\\XBOOLE-0K3 Y =XBOOLE-0R4 {}XBOOLE-0K1"
      thus "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2"
        using A1 A33 A2 sorry
    qed
    thus " not (X missesXBOOLE-0R1 Y &  not (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y),FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))are-fiberwise-equipotentCLASSES1R2)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef rfunct_3_def_14 ("SumRFUNCT-3K21\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]260 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)", "X be setHIDDENM2"
"func SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) \<rightarrow> RealXREAL-0M1 equals
  SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
proof-
  (*coherence*)
    show "SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) be RealXREAL-0M1"
       sorry
qed "sorry"

mtheorem rfunct_3_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X) =COMPLEX1R1 r *XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X) =HIDDENR1 r *XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?x = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    obtain rr where 
      [ty]:"rr be RealXREAL-0M1" and rrDef:"rr = r"
       sorry
    assume A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
    then obtain FX where 
      [ty]:"FX be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and FXDef:"FX = F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using finset_1_th_10 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using rfunct_1_th_49 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using valued_1_def_5 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
       sorry
    then obtain rFX where 
      [ty]:"rFX be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1" and rFXDef:"rFX = (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using A1 finset_1_th_10 sorry
    obtain b where
      [ty]:"b be FinSequenceFINSEQ-1M1" and 
      A2: "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x,b)are-fiberwise-equipotentCLASSES1R2"
      using A1 rfinseq_th_5 sorry
    have "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x) =XBOOLE-0R4 rngFUNCT-1K2 b"
      using A2 classes1_th_75 sorry
    then have 
      [ty]:"b be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      using finseq_1_def_4 sorry
    have "?x =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    then have A3: "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x =HIDDENR1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using relat_1_th_71 sorry
    also have "... = F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
      using relat_1_th_68 sorry
    finally have "F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?x =HIDDENR1 F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
       sorry
    then have A4: "rngRVSUM-1K1 b =MEMBEREDR9 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using A2 classes1_th_75 sorry
    have A5: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x))"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      have A6: "lenFINSEQ-1K4 (r *RVSUM-1K12 b) =COMPLEX1R1 lenFINSEQ-1K4 b"
        using finseq_2_th_33 sorry
      have " not x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) & cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}) or x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) & (x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) implies cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
      proof-
        show " not x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) & cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}) or x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) & (x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) implies cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}))"
        proof-
          have cases: " not x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) or x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b)"
             sorry
          have case1: " not x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) implies cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
          proof(rule impI)
            assume A7: " not x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b)"
            have A8: "x inTARSKIR2 rngRVSUM-1K1 ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies  False "
            proof(rule impI)
              assume "x inTARSKIR2 rngRVSUM-1K1 ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
              then have "x inTARSKIR2 rngRVSUM-1K1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
                using rfunct_1_th_49 sorry
              then obtain d where
                [ty]:"d be ElementSUBSET-1M1-of D" and 
                A9: "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"and A10: "(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d =COMPLEX1R1 x"
                using partfun1_th_3 sorry
              have "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
                using A9 valued_1_def_5 sorry
              then have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d inTARSKIR2 rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
                using funct_1_def_3 sorry
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A11: "n inTARSKIR2 domFINSEQ-1K5 b"and A12: "b .FUNCT-1K1 n =COMPLEX1R1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d"
                using A4 finseq_2_th_10 sorry
              have "x =COMPLEX1R1 r *XCMPLX-0K3 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 d"
                using A9 A10 valued_1_def_5 sorry
              then have A13: "x =COMPLEX1R1 (r *RVSUM-1K12 b).FUNCT-1K1 n"
                using A12 rvsum_1_th_44 sorry
              have "n inTARSKIR2 domFINSEQ-1K5 (r *RVSUM-1K12 b)"
                using A6 A11 finseq_3_th_29 sorry
              thus " False "
                using A7 A13 funct_1_def_3 sorry
            qed
            have "(r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} =MEMBEREDR12 {}XBOOLE-0K1"
              using A7 rfunct_3_lm_2 sorry
            thus "cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
              using A8 rfunct_3_lm_2 sorry
          qed
          have case2: "x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b) implies cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
          proof(rule impI)
            assume "x inTARSKIR2 rngRVSUM-1K1 (r *RVSUM-1K12 b)"
            then obtain n where
              [ty]:"n be NatNAT-1M1" and 
              "n inTARSKIR2 domFINSEQ-1K5 (r *RVSUM-1K12 b)"and A14: "(r *RVSUM-1K12 b).FUNCT-1K1 n =COMPLEX1R1 x"
              using finseq_2_th_10 sorry
            obtain p where 
              [ty]:"p be RealXREAL-0M1" and pDef:"p = b .FUNCT-1K1 n"
               sorry
            have A15: "x =COMPLEX1R1 r *XCMPLX-0K3 p"
              using A14 rvsum_1_th_44 sorry
            have "r =COMPLEX1R1 0NUMBERSK6 & cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}) or r <>HIDDENR2 0NUMBERSK6 & (r <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x)))"
            proof-
              show "r =COMPLEX1R1 0NUMBERSK6 & cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x}) or r <>HIDDENR2 0NUMBERSK6 & (r <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x)))"
              proof-
                have cases: "r =COMPLEX1R1 0NUMBERSK6 or r <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "r =COMPLEX1R1 0NUMBERSK6 implies cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
                proof(rule impI)
                  assume A16: "r =COMPLEX1R1 0NUMBERSK6"
                  then have A17: "(r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x} =MEMBEREDR12 domFINSEQ-1K5 b"
                    using A15 rfinseq_th_25 sorry
                  have "domRELAT-1K1 FX =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    using A15 A16 rfunct_3_th_7 sorry
                  also have "... = ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    using rfunct_1_th_49 sorry
                  finally have "domRELAT-1K1 FX =HIDDENR1 ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                     sorry
                  thus "cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
                    using A2 A3 A17 classes1_th_81 sorry
                qed
                have case2: "r <>HIDDENR2 0NUMBERSK6 implies cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x))"
                proof(rule impI)
                  assume A18: "r <>HIDDENR2 0NUMBERSK6"
                  then have A19: "CoimRELAT-1K13(rr *RVSUM-1K12 b,x) =XBOOLE-0R4 CoimRELAT-1K13(b,x /XCMPLX-0K7 rr)"
                    using rfinseq_th_24 sorry
                  have "CoimRELAT-1K13((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,x) =HIDDENR1 (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(D,REALNUMBERSK2)\<^esub> {TARSKIK1 x}"
                    using rfunct_1_th_49 sorry
                  also have "... = CoimRELAT-1K13(FX,x /XCMPLX-0K7 r)"
                    using A18 rfunct_3_th_6 sorry
                  finally have "CoimRELAT-1K13((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,x) =HIDDENR1 CoimRELAT-1K13(FX,x /XCMPLX-0K7 r)"
                     sorry
                  thus "cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x))"
                    using A2 A3 A19 classes1_def_10 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "cardCARD-1K4 ((r *RVSUM-1K12 b)\<inverse>RELSET-1K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> {TARSKIK1 x}) =COMPLEX1R1 cardCARD-1K4 (rFX \<inverse>FUNCT-1K6 {TARSKIK1 x})"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "cardCARD-1K1 (CoimRELAT-1K13(r *RVSUM-1K12 b,x)) =XBOOLE-0R4 cardCARD-1K1 (CoimRELAT-1K13(rFX,x))"
         sorry
    qed "sorry"
    have "rngRVSUM-1K1 (r *RVSUM-1K12 b) c=MEMBEREDR3 REALNUMBERSK2 & rngRVSUM-1K1 ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) c=MEMBEREDR3 REALNUMBERSK2"
       sorry
    then have A20: "(r *RVSUM-1K12 b,(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
      using A5 classes1_th_79 sorry
    have "(F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X))are-fiberwise-equipotentCLASSES1R2"
      using A1 rfunct_3_def_13 sorry
    then have A21: "SumRVSUM-1K22 b =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
      using A2 A3 classes1_th_76 rfinseq_th_9 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using valued_1_def_5 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
       sorry
    then have "((r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X,FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X))are-fiberwise-equipotentCLASSES1R2"
      using A1 rfunct_3_def_13 sorry
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X) =HIDDENR1 SumRVSUM-1K22 (r *RVSUM-1K12 b)"
      using A20 classes1_th_76 rfinseq_th_9 sorry
    also have "... = r *XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
      using A21 rvsum_1_th_87 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(r (#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> F,X) =HIDDENR1 r *XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies (domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
    assume A1: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    let ?P = "\<lambda>Lamb1.  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds (cardCARD-1K4 Y =COMPLEX1R1 Lamb1 & Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
    have A2: "cardCARD-1K4 Y =COMPLEX1R1 cardCARD-1K4 Y"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds (cardCARD-1K4 Y =COMPLEX1R1 n & Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)) implies ( for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for dx be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 dx =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & (dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X))"
      proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "?P(n)"
        fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
        fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
        fix X assume [ty]: "X be setHIDDENM2"
        fix dx assume [ty]: "dx be finiteFINSET-1V1\<bar>setHIDDENM2"
        let ?gx = "domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        assume A5: "cardCARD-1K4 dx =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
          and A6: "dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          and A7: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        let ?x = "the ElementSUBSET-1M1-of dx"
        obtain x where 
          [ty]:"x be ElementSUBSET-1M1-of D" and xDef:"x = ?x"
          using A5 A6 card_1_th_27 tarski_def_3 sorry
        have A8: "dx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using A6 relat_1_th_61 sorry
        then have A9: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
          using A5 card_1_th_27 xboole_0_def_4 sorry
        let ?Y = "X \\SUBSET-1K6 {TARSKIK1 x}"
        let ?dy = "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)"
        let ?gy = "domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> ?Y)"
        have A10: "?gx =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> G /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using relat_1_th_61 sorry
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> G"
          using A5 A6 A7 card_1_th_27 xboole_0_def_4 sorry
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> G"
          using A9 xboole_0_def_4 sorry
        then have A11: "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G)"
          using valued_1_def_1 sorry
        have A12: "?dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(X)\<^esub> ?Y"
          using relat_1_th_61 sorry
        have A13: "?dy =XBOOLE-0R4 dx \\SUBSET-1K6 {TARSKIK1 x}"
        proof-
          have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) =XBOOLE-0R4 dx \\SUBSET-1K6 {TARSKIK1 x}"
          proof-
            have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 dx \\SUBSET-1K6 {TARSKIK1 x} & dx \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
            proof(rule conjMI)
              show "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 dx \\SUBSET-1K6 {TARSKIK1 x}"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) implies y inHIDDENR3 dx \\SUBSET-1K6 {TARSKIK1 x}"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume A14: "y inHIDDENR3 ?dy"
                  then have "y inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
                    using A12 xboole_0_def_4 sorry
                  then have A15: " not y inHIDDENR3 {TARSKIK1 x}"
                    using xboole_0_def_5 sorry
                  have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                    using A12 A14 xboole_0_def_4 sorry
                  then have "y inHIDDENR3 dx"
                    using A12 A8 A14 xboole_0_def_4 sorry
                  thus "y inHIDDENR3 dx \\SUBSET-1K6 {TARSKIK1 x}"
                    using A15 xboole_0_def_5 sorry
                qed "sorry"
                thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 dx \\SUBSET-1K6 {TARSKIK1 x}"
                  using tarski_def_3 sorry
              qed
              have " for y be objectHIDDENM1 holds y inHIDDENR3 dx \\SUBSET-1K6 {TARSKIK1 x} implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A16: "y inHIDDENR3 dx \\SUBSET-1K6 {TARSKIK1 x}"
                then have " not y inHIDDENR3 {TARSKIK1 x} & y inHIDDENR3 X"
                  using A8 xboole_0_def_4 xboole_0_def_5 sorry
                then have A17: "y inHIDDENR3 ?Y"
                  using xboole_0_def_5 sorry
                have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                  using A8 A16 xboole_0_def_4 sorry
                thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
                  using A12 A17 xboole_0_def_4 sorry
              qed "sorry"
              thus "dx \\SUBSET-1K6 {TARSKIK1 x} c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
                using tarski_def_3 sorry
            qed
            thus "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) =XBOOLE-0R4 dx \\SUBSET-1K6 {TARSKIK1 x}"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then obtain dy where 
          [ty]:"dy be finiteFINSET-1V1\<bar>setHIDDENM2" and dyDef:"dy = ?dy"
           sorry
        have A18: "?gy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> G /\\SUBSET-1K9\<^bsub>(X)\<^esub> ?Y"
          using relat_1_th_61 sorry
        have A19: "dy =XBOOLE-0R4 ?gy"
        proof-
          have "dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
          proof-
            have "dy c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) & domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 dy"
            proof(rule conjMI)
              show "dy c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 dy implies y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  assume A20: "y inHIDDENR3 dy"
                  then have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                    using A12 xboole_0_def_4 sorry
                  then have "y inHIDDENR3 ?gx"
                    using A6 A7 A12 A8 A20 xboole_0_def_4 sorry
                  then have A21: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> G"
                    using A10 xboole_0_def_4 sorry
                  have "y inHIDDENR3 ?Y"
                    using A12 A20 xboole_0_def_4 sorry
                  thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
                    using A18 A21 xboole_0_def_4 sorry
                qed "sorry"
                thus "dy c=TARSKIR1 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
                  using tarski_def_3 sorry
              qed
              have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) implies y inHIDDENR3 dy"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A22: "y inHIDDENR3 ?gy"
                then have "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> G"
                  using A18 xboole_0_def_4 sorry
                then have "y inHIDDENR3 dx"
                  using A6 A7 A18 A10 A22 xboole_0_def_4 sorry
                then have A23: "y inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> F"
                  using A8 xboole_0_def_4 sorry
                have "y inHIDDENR3 ?Y"
                  using A18 A22 xboole_0_def_4 sorry
                thus "y inHIDDENR3 dy"
                  using A12 A23 xboole_0_def_4 sorry
              qed "sorry"
              thus "domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x})) c=TARSKIR1 dy"
                using tarski_def_3 sorry
            qed
            thus "dy =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\SUBSET-1K6 {TARSKIK1 x}))"
              using xboole_0_def_10 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "{TARSKIK1 x} c=TARSKIR1 dx"
          using A5 card_1_th_27 zfmisc_1_th_31 sorry
        then have "cardCARD-1K4 dy =HIDDENR1 cardCARD-1K4 dx -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 x}"
          using A13 card_2_th_44 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using A5 card_1_th_30 sorry
        also have "... = n"
           sorry
        finally have "cardCARD-1K4 dy =HIDDENR1 n"
           sorry
        then have A24: "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,?Y) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,?Y) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,?Y)"
          using A4 A19 sorry
        have A25: "domRELSET-1K1\<^bsub>(D)\<^esub> ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using rfunct_1_th_44 sorry
        also have "... = dx /\\SUBSET-1K9\<^bsub>(D)\<^esub> ?gx"
          using A6 valued_1_def_1 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 dx /\\SUBSET-1K9\<^bsub>(D)\<^esub> ?gx"
           sorry
        then have A26: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X),(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using rfunct_3_def_13 sorry
        have "x inTARSKIR2 X"
          using A5 A8 card_1_th_27 xboole_0_def_4 sorry
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
          using A11 xboole_0_def_4 sorry
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using relat_1_th_61 sorry
        then have A27: "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,?Y) ^FINSEQ-1K8 (<*FINSEQ-1K10 (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x*>),(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A25 rfunct_3_th_66 sorry
        obtain Fx Gx FGx where 
          [ty]:"Fx be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and FxDef:"Fx = <*FINSEQ-1K10 F .FUNCT-1K1 x*>" and
          [ty]:"Gx be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and GxDef:"Gx = <*FINSEQ-1K10 G .FUNCT-1K1 x*>" and
          [ty]:"FGx be FinSequenceFINSEQ-1M3-of REALNUMBERSK2" and FGxDef:"FGx = <*FINSEQ-1K10 (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x*>"
          using rvsum_1_th_145 sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y) ^FINSEQ-1K8 (<*FINSEQ-1K10 F .FUNCT-1K1 x*>),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A5 A6 rfunct_3_def_13 rfunct_3_th_66 card_1_th_27 sorry
        then have A28: "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 SumRVSUM-1K22 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,?Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Fx)"
          using classes1_th_76 rfinseq_th_9 sorry
        also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,?Y) +XCMPLX-0K2 F .FUNCT-1K1 x"
          using rvsum_1_th_74 sorry
        finally have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,?Y) +XCMPLX-0K2 F .FUNCT-1K1 x"
           sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(G,?Y) ^FINSEQ-1K8 (<*FINSEQ-1K10 G .FUNCT-1K1 x*>),G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2 & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(G,X),G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A5 A6 A7 rfunct_3_def_13 rfunct_3_th_66 card_1_th_27 sorry
        then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =HIDDENR1 SumRVSUM-1K22 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(G,?Y) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Gx)"
          using classes1_th_76 rfinseq_th_9 sorry
        also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,?Y) +XCMPLX-0K2 G .FUNCT-1K1 x"
          using rvsum_1_th_74 sorry
        finally have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,?Y) +XCMPLX-0K2 G .FUNCT-1K1 x"
           sorry
        then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =HIDDENR1 SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X \\SUBSET-1K6 {TARSKIK1 x}) +XCMPLX-0K2 (F .FUNCT-1K1 x +XCMPLX-0K2 G .FUNCT-1K1 x)"
          using A24 A28 sorry
        also have "... = SumRVSUM-1K22 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X \\SUBSET-1K6 {TARSKIK1 x}) +XCMPLX-0K2 (F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G).FUNCT-1K1 x"
          using A11 valued_1_def_1 sorry
        also have "... = SumRVSUM-1K22 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X \\SUBSET-1K6 {TARSKIK1 x}) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FGx)"
          using rvsum_1_th_74 sorry
        also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X)"
          using A27 A26 classes1_th_76 rfinseq_th_9 sorry
        finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A29: "?P(0NUMBERSK6)"
    proof-
      have " for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds cardCARD-1K4 Y =COMPLEX1R1 0NUMBERSK6 & (Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
        fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
        fix X assume [ty]: "X be setHIDDENM2"
        fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
        assume A30: "cardCARD-1K4 Y =COMPLEX1R1 0NUMBERSK6"
          and A31: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          and A32: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
        have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A30 A31 sorry
        then have A33: "rngRVSUM-1K1 (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {}XBOOLE-0K1"
          using relat_1_th_42 sorry
        have "(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(D,REALNUMBERSK2)\<^esub> F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X"
          using rfunct_1_th_44 sorry
        then have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
          using valued_1_def_1 sorry
        also have "... = {}XBOOLE-0K1"
          using A30 A31 A32 sorry
        finally have "domRELSET-1K1\<^bsub>(D)\<^esub> ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 {}XBOOLE-0K1"
           sorry
        then have "rngRVSUM-1K1 ((F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {}XBOOLE-0K1 & (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X),(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using rfunct_3_def_13 relat_1_th_42 sorry
        then have A34: "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =MEMBEREDR9 {}XBOOLE-0K1"
          using classes1_th_75 sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X),F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A31 rfunct_3_def_13 sorry
        then have "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =MEMBEREDR9 {}XBOOLE-0K1"
          using A33 classes1_th_75 sorry
        then have A35: "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) =COMPLEX1R1 0NUMBERSK6"
          using relat_1_th_41 rvsum_1_th_72 sorry
        have "domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 {}XBOOLE-0K1"
          using A30 A31 A32 sorry
        then have A36: "rngRVSUM-1K1 (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =MEMBEREDR9 {}XBOOLE-0K1"
          using relat_1_th_42 sorry
        have "(FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(G,X),G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)are-fiberwise-equipotentCLASSES1R2"
          using A31 A32 rfunct_3_def_13 sorry
        then have "rngRVSUM-1K1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(G,X) =MEMBEREDR9 {}XBOOLE-0K1"
          using A36 classes1_th_75 sorry
        then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X) =COMPLEX1R1 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
          using A35 relat_1_th_41 rvsum_1_th_72 sorry
        thus "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
          using A34 relat_1_th_41 rvsum_1_th_72 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A37: " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A29 A3 sorry
    assume "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    thus "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F +VALUED-1K3\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
      using A1 A37 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix G assume [ty]: "G be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G) /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> G /\\SUBSET-1K8\<^bsub>(D)\<^esub> X"
      using valued_1_def_5 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G) |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (G  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
       sorry
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(D,REALNUMBERSK2)\<^esub> G,X)"
      using A1 rfunct_3_th_78 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
      using A1 rfunct_3_th_77 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
       sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K49\<^bsub>(D,REALNUMBERSK2,REALNUMBERSK2)\<^esub> G,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(G,X)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_80:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 r *XCMPLX-0K3 cardCARD-1K4 Y"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for Y be finiteFINSET-1V1\<bar>setHIDDENM2 holds Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 r *XCMPLX-0K3 cardCARD-1K4 Y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    let ?fx = "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X)"
    fix Y assume [ty]: "Y be finiteFINSET-1V1\<bar>setHIDDENM2"
    obtain rr where 
      [ty]:"rr be ElementSUBSET-1M1-of REALNUMBERSK2" and rrDef:"rr = r"
      using xreal_0_def_1 sorry
    let ?dr = "cardCARD-1K4 Y  |->FINSEQ-2K5\<^bsub>(REALNUMBERSK2)\<^esub> rr"
    assume A1: "Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X)"
    then have "lenFINSEQ-1K4 ?fx =COMPLEX1R1 cardCARD-1K4 Y"
      using rfunct_3_th_67 sorry
    then obtain xf rd where 
      [ty]:"xf be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (cardCARD-1K4 Y)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and xfDef:"xf = ?fx" and
      [ty]:"rd be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (cardCARD-1K4 Y)-tuples-onFINSEQ-2K4 REALNUMBERSK2" and rdDef:"rd = ?dr"
      using finseq_2_th_92 sorry
    have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =FINSEQ-1R1 ?fx -RVSUM-1K9 ?dr"
      using A1 rfunct_3_th_73 sorry
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 SumRVSUM-1K22 xf -XCMPLX-0K6 SumRVSUM-1K22 rd"
      using rvsum_1_th_90 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 r *XCMPLX-0K3 cardCARD-1K4 Y"
      using rvsum_1_th_80 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F -VALUED-1K16\<^bsub>(D,REALNUMBERSK2)\<^esub> r,X) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) -XCMPLX-0K6 r *XCMPLX-0K3 cardCARD-1K4 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_81:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{}XBOOLE-0K1) =COMPLEX1R1 0NUMBERSK6"
  using rfunct_3_th_68 rvsum_1_th_72 sorry

mtheorem rfunct_3_th_82:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =COMPLEX1R1 F .FUNCT-1K1 d"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for d be ElementSUBSET-1M1-of D holds d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =HIDDENR1 F .FUNCT-1K1 d"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    obtain Fd where 
      [ty]:"Fd be ElementSUBSET-1M1-of REALNUMBERSK2" and FdDef:"Fd = F .FUNCT-1K1 d"
      using xreal_0_def_1 sorry
    assume "d inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> F"
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =HIDDENR1 SumRVSUM-1K22 (<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> Fd*>)"
      using rfunct_3_th_69 sorry
    also have "... = F .FUNCT-1K1 d"
      using finsop_1_th_11 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,{TARSKIK1 d}) =HIDDENR1 F .FUNCT-1K1 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_83:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & X missesXBOOLE-0R1 Y"
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRVSUM-1K22 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))"
      using rfunct_3_th_76 rfinseq_th_9 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
      using rvsum_1_th_75 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem rfunct_3_th_84:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =COMPLEX1R1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2) holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1 & domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) implies SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be PartFuncPARTFUN1M1-of(D,REALNUMBERSK2)"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) be finiteFINSET-1V1"
      and A2: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
    have A3: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> X \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
      using xboole_1_th_23 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> Y"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) \\/SUBSET-1K4\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y)"
       sorry
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X) be finiteFINSET-1V1"
      using A1 finset_1_th_1 xboole_1_th_7 sorry
    then have A4: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> X))"
      using rfunct_3_th_63 sorry
    have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y) be finiteFINSET-1V1"
      using A1 A3 finset_1_th_1 xboole_1_th_7 sorry
    then have A5: "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> Y))"
      using rfunct_3_th_63 sorry
    have A6: "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))"
      using relat_1_th_61 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> (domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y))"
      using relat_1_th_61 sorry
    also have "... = (domRELSET-1K1\<^bsub>(D)\<^esub> F /\\SUBSET-1K9\<^bsub>(D)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> F)/\\SUBSET-1K8\<^bsub>(D)\<^esub> (X \\/XBOOLE-0K2 Y)"
      using xboole_1_th_16 sorry
    also have "... = domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))"
      using relat_1_th_61 sorry
    finally have "domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))) =HIDDENR1 domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y))"
       sorry
    have "FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =FINSEQ-1R1 FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,domRELSET-1K1\<^bsub>(D)\<^esub> (F  |PARTFUN1K2\<^bsub>(D,REALNUMBERSK2)\<^esub> (X \\/XBOOLE-0K2 Y)))"
      using A1 rfunct_3_th_63 sorry
    then have "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRVSUM-1K22 (FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,X) ^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> FinSRFUNCT-3K20\<^bsub>(D)\<^esub>(F,Y))"
      using A1 A2 A3 A4 A5 A6 rfunct_3_th_76 rfinseq_th_9 sorry
    also have "... = SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
      using rvsum_1_th_75 sorry
    finally show "SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X \\/XBOOLE-0K2 Y) =HIDDENR1 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,X) +XCMPLX-0K2 SumRFUNCT-3K21\<^bsub>(D)\<^esub>(F,Y)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
