theory valued_1
  imports xxreal_2 square_1 funct_4 finseq_3 fraenkel recdef_1 nat_d
   "../mizar_extension/E_number"
begin
(*begin*)
mlemma valued_1_lm_1:
" for f be FinSequenceFINSEQ-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domFINSEQ-1K5 f implies h be FinSequenceFINSEQ-1M1"
proof(rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domFINSEQ-1K5 f"
  have "h be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
    proof-
      show "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
        using A1 finseq_1_def_3 sorry
    qed
    thus "h be FinSequence-likeFINSEQ-1V1"
      using bexI[of _ "lenFINSEQ-1K4 f"] finseq_1_def_2 sorry
  qed
  thus "h be FinSequenceFINSEQ-1M1"
     sorry
qed "sorry"

mlemma valued_1_lm_2:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domFINSEQ-1K5 f /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domFINSEQ-1K5 g implies h be FinSequenceFINSEQ-1M1"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
  fix h assume [ty]: "h be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domFINSEQ-1K5 f /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domFINSEQ-1K5 g"
  obtain n where
    [ty]:"n be NatNAT-1M1" and 
    A2: "domFINSEQ-1K5 f =MEMBEREDR12 SegFINSEQ-1K2 n"
    using finseq_1_def_2 sorry
  obtain m where
    [ty]:"m be NatNAT-1M1" and 
    A3: "domFINSEQ-1K5 g =MEMBEREDR12 SegFINSEQ-1K2 m"
    using finseq_1_def_2 sorry
  have "h be FinSequence-likeFINSEQ-1V1"
  proof-
    show "h be FinSequence-likeFINSEQ-1V1"
    proof-
      have cases: "n <=XXREAL-0R1 m or m <=XXREAL-0R1 n"
         sorry
      have case1: "n <=XXREAL-0R1 m implies h be FinSequence-likeFINSEQ-1V1"
      proof(rule impI)
        assume A4: "n <=XXREAL-0R1 m"
        have "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 n"
        proof-
          show "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 n"
            using A1 A2 A3 A4 finseq_1_th_7 sorry
        qed
        thus "h be FinSequence-likeFINSEQ-1V1"
          using bexI[of _ "n"] finseq_1_def_2 sorry
      qed
      have case2: "m <=XXREAL-0R1 n implies h be FinSequence-likeFINSEQ-1V1"
      proof(rule impI)
        assume A5: "m <=XXREAL-0R1 n"
        have "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 m"
        proof-
          show "domRELAT-1K1 h =HIDDENR1 SegFINSEQ-1K2 m"
            using A1 A2 A3 A5 finseq_1_th_7 sorry
        qed
        thus "h be FinSequence-likeFINSEQ-1V1"
          using bexI[of _ "m"] finseq_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus "h be FinSequenceFINSEQ-1M1"
     sorry
qed "sorry"

mtheorem valued_1_cl_1:
"cluster complex-valuedVALUED-0V5 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be complex-valuedVALUED-0V5"
  proof-
    have " ex tVar4 be FinSequenceFINSEQ-1M1 st tVar4 be complex-valuedVALUED-0V5"
    proof-
      show " ex tVar4 be FinSequenceFINSEQ-1M1 st tVar4 be complex-valuedVALUED-0V5"
      proof(rule bexI[of _ "<*>FINSEQ-1K7 (COMPLEXNUMBERSK3)"])
        show "<*>FINSEQ-1K7 (COMPLEXNUMBERSK3) be complex-valuedVALUED-0V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_2:
  mlet "r be RationalRAT-1M1"
"cluster  |.COMPLEX1K10 r.| as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show " |.COMPLEX1K10 r.| be rationalRAT-1V1"
  proof-
    have " |.COMPLEX1K10 r.| =COMPLEX1R1 -XCMPLX-0K4 r or  |.COMPLEX1K10 r.| =COMPLEX1R1 r"
      using complex1_th_71 sorry
    thus " |.COMPLEX1K10 r.| be rationalRAT-1V1"
       sorry
  qed
qed "sorry"

mdef valued_1_def_1 (" _ +VALUED-1K1  _ " [132,132]132 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 +VALUED-1K1 f2 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)"
    proof-
      let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 +XCMPLX-0K2 f2 .FUNCT-1K1 Lamb1"
      let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c))))"
        proof-
          have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 ?X & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 +XCMPLX-0K2 f2 .FUNCT-1K1 Lamb1"
      let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
      proof-
        have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c))) implies f =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix f assume [ty]: "f be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A1: "domRELAT-1K1 f =XBOOLE-0R4 ?X"
            and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
            and A3: "domRELAT-1K1 g =XBOOLE-0R4 ?X"
            and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 f"
            then have "f .FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
              using A2 sorry
            also have "... = g .FUNCT-1K1 x"
              using A1 A3 A4 A5 sorry
            finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "f =HIDDENR1 g"
            using A1 A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem VALUED_1K1_commutativity:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 +VALUED-1K1 f2 =HIDDENR1 f2 +VALUED-1K1 f1"
proof-
  have " for it be FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 +VALUED-1K1 f2 implies it =HIDDENR1 f2 +VALUED-1K1 f1"
  proof-
    let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 +XCMPLX-0K2 f2 .FUNCT-1K1 Lamb1"
    let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
    have " for it be FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c) implies domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f1 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f2 .FUNCT-1K1 c +XCMPLX-0K2 f1 .FUNCT-1K1 c)"
       sorry
    thus " ?thesis "
      using valued_1_def_1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_3:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be complex-valuedVALUED-0V5"
  proof-
    have "f1 +VALUED-1K1 f2 be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        then have "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
          using valued_1_def_1 sorry
        thus "(f1 +VALUED-1K1 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "f1 +VALUED-1K1 f2 be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_4:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be real-valuedVALUED-0V7"
  proof-
    have "f1 +VALUED-1K1 f2 be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        then have "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
          using valued_1_def_1 sorry
        thus "(f1 +VALUED-1K1 f2).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "f1 +VALUED-1K1 f2 be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_5:
  mlet "f1 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (f1 +VALUED-1K1 f2) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (f1 +VALUED-1K1 f2)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"and A2: "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A1 valued_1_def_1 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus "f1 +VALUED-1K1 f2 be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_6:
  mlet "f1 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be INTINT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (f1 +VALUED-1K1 f2) implies y inHIDDENR3 INTINT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (f1 +VALUED-1K1 f2)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"and A2: "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
        using A1 valued_1_def_1 sorry
      thus "y inHIDDENR3 INTINT-1K1"
        using A2 int_1_def_2 sorry
    qed "sorry"
    thus "f1 +VALUED-1K1 f2 be INTINT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_7:
  mlet "f1 be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1", "f2 be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be natural-valuedVALUED-0V8"
  proof-
    have "f1 +VALUED-1K1 f2 be natural-valuedVALUED-0V4"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2) implies (f1 +VALUED-1K1 f2).FUNCT-1K1 x be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 +VALUED-1K1 f2)"
        then have "(f1 +VALUED-1K1 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x +XCMPLX-0K2 f2 .FUNCT-1K1 x"
          using valued_1_def_1 sorry
        thus "(f1 +VALUED-1K1 f2).FUNCT-1K1 x be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus "f1 +VALUED-1K1 f2 be natural-valuedVALUED-0V4"
        using valued_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax VALUED_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K2\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 +VALUED-1K1 f2"

mtheorem valued_1_add_1:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 +VALUED-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f1 +VALUED-1K1 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngFUNCT-1K2 (f1 +VALUED-1K1 f2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_1 valued_0_def_1 sorry
    thus "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K3\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 +VALUED-1K1 f2"

mtheorem valued_1_add_2:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 +VALUED-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_1 valued_0_def_3 sorry
    thus "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K4\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 +VALUED-1K1 f2"

mtheorem valued_1_add_3:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 +VALUED-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_1 relat_1_def_19 sorry
    thus "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K5\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 +VALUED-1K1 f2"

mtheorem valued_1_add_4:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 +VALUED-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_1 relat_1_def_19 sorry
    thus "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K6\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 +VALUED-1K1 f2"

mtheorem valued_1_add_5:
  mlet "C be setHIDDENM2", "D1 be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "D2 be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 +VALUED-1K1 f2 as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR6 NATNUMBERSK1"
      using valued_1_def_1 valued_0_def_6 sorry
    thus "f1 +VALUED-1K1 f2 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_8:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_1 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_9:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_1 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_10:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_1 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K4\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_11:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_1 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K5\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_12:
  mlet "C be setHIDDENM2", "D1 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1 f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_1 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K6\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_th_1:
" for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds  for c be ElementSUBSET-1M1-of C holds (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix C assume [ty]: "C be setHIDDENM2"
  fix D1 assume [ty]: "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D2 assume [ty]: "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C,D1)"
  fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C,D2)"
  have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 C"
    using funct_2_def_1 sorry
  fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
  show "(f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
  proof-
    have cases: "C be  non emptyXBOOLE-0V1 or C be emptyXBOOLE-0V1"
       sorry
    have case1: "C be  non emptyXBOOLE-0V1 implies (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
    proof(rule impI)
      assume "C be  non emptyXBOOLE-0V1"
      thus "(f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A1 valued_1_def_1 sorry
    qed
    have case2: "C be emptyXBOOLE-0V1 implies (f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
    proof(rule impI)
      assume A2: "C be emptyXBOOLE-0V1"
      then have "f1 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
         sorry
      thus "(f1 +VALUED-1K2\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c +XCMPLX-0K2 f2 .FUNCT-1K1 c"
        using A2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_13:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 (f1 +VALUED-1K1 f2) =XBOOLE-0R4 domFINSEQ-1K5 f1 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domFINSEQ-1K5 f2"
      using valued_1_def_1 sorry
    thus "f1 +VALUED-1K1 f2 be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_2 sorry
  qed
qed "sorry"

(*begin*)
mdef valued_1_def_2 (" _ +VALUED-1K7  _ " [132,132]132 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"func r +VALUED-1K7 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)"
    proof-
      let ?F = "\<lambda>Lamb1. r +XCMPLX-0K2 f .FUNCT-1K1 Lamb1"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c))))"
        proof-
          have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. r +XCMPLX-0K2 f .FUNCT-1K1 Lamb1"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
      proof-
        have " for h be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 c))) implies h =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
            and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
            and A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
            and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 h"
            then have "h .FUNCT-1K1 x =HIDDENR1 r +XCMPLX-0K2 f .FUNCT-1K1 x"
              using A2 sorry
            also have "... = g .FUNCT-1K1 x"
              using A1 A3 A4 A5 sorry
            finally show "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "h =HIDDENR1 g"
            using A1 A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

abbreviation(input) VALUED_1K8(" _ +VALUED-1K8  _ " [132,132]132) where
  "f +VALUED-1K8 r \<equiv> r +VALUED-1K7 f"

mtheorem valued_1_cl_14:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K7 f as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "r +VALUED-1K7 f be complex-valuedVALUED-0V5"
  proof-
    have "r +VALUED-1K7 f be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f) implies (r +VALUED-1K7 f).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f)"
        then have "(r +VALUED-1K7 f).FUNCT-1K1 x =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-1K1 x"
          using valued_1_def_2 sorry
        thus "(r +VALUED-1K7 f).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "r +VALUED-1K7 f be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_15:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be RealXREAL-0M1"
"cluster r +VALUED-1K7 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "r +VALUED-1K7 f be real-valuedVALUED-0V7"
  proof-
    have "r +VALUED-1K7 f be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f) implies (r +VALUED-1K7 f).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f)"
        then have "(r +VALUED-1K7 f).FUNCT-1K1 x =COMPLEX1R1 r +XCMPLX-0K2 f .FUNCT-1K1 x"
          using valued_1_def_2 sorry
        thus "(r +VALUED-1K7 f).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "r +VALUED-1K7 f be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_16:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be RationalRAT-1M1"
"cluster r +VALUED-1K7 f as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "r +VALUED-1K7 f be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (r +VALUED-1K7 f) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (r +VALUED-1K7 f)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f)"and A2: "(r +VALUED-1K7 f).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(r +VALUED-1K7 f).FUNCT-1K1 x =COMPLEX1R1 r +XCMPLX-0K2 f .FUNCT-1K1 x"
        using A1 valued_1_def_2 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus "r +VALUED-1K7 f be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_17:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be IntegerINT-1M1"
"cluster r +VALUED-1K7 f as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "r +VALUED-1K7 f be INTINT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (r +VALUED-1K7 f) implies y inHIDDENR3 INTINT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (r +VALUED-1K7 f)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f)"and A2: "(r +VALUED-1K7 f).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(r +VALUED-1K7 f).FUNCT-1K1 x =COMPLEX1R1 r +XCMPLX-0K2 f .FUNCT-1K1 x"
        using A1 valued_1_def_2 sorry
      thus "y inHIDDENR3 INTINT-1K1"
        using A2 int_1_def_2 sorry
    qed "sorry"
    thus "r +VALUED-1K7 f be INTINT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_18:
  mlet "f be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1", "r be NatNAT-1M1"
"cluster r +VALUED-1K7 f as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "r +VALUED-1K7 f be natural-valuedVALUED-0V8"
  proof-
    have "r +VALUED-1K7 f be natural-valuedVALUED-0V4"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f) implies (r +VALUED-1K7 f).FUNCT-1K1 x be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r +VALUED-1K7 f)"
        then have "(r +VALUED-1K7 f).FUNCT-1K1 x =COMPLEX1R1 r +XCMPLX-0K2 f .FUNCT-1K1 x"
          using valued_1_def_2 sorry
        thus "(r +VALUED-1K7 f).FUNCT-1K1 x be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus "r +VALUED-1K7 f be natural-valuedVALUED-0V4"
        using valued_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax VALUED_1K9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K9\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "r +VALUED-1K9\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r +VALUED-1K7 f"

mtheorem valued_1_add_6:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K7 f as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (r +VALUED-1K7 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 (r +VALUED-1K7 f) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_2 valued_0_def_1 sorry
    thus "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K10 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K10\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "r +VALUED-1K10\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r +VALUED-1K7 f"

mtheorem valued_1_add_7:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RealXREAL-0M1"
"cluster r +VALUED-1K7 f as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_2 valued_0_def_3 sorry
    thus "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K11 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K11\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "r +VALUED-1K11\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r +VALUED-1K7 f"

mtheorem valued_1_add_8:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RationalRAT-1M1"
"cluster r +VALUED-1K7 f as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K10\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (r +VALUED-1K10\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_2 relat_1_def_19 sorry
    thus "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K12 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K12\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "r +VALUED-1K12\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r +VALUED-1K7 f"

mtheorem valued_1_add_9:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be IntegerINT-1M1"
"cluster r +VALUED-1K7 f as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K11\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (r +VALUED-1K11\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_2 relat_1_def_19 sorry
    thus "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ +VALUED-1K13\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "r +VALUED-1K13\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r +VALUED-1K7 f"

mtheorem valued_1_add_10:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be NatNAT-1M1"
"cluster r +VALUED-1K7 f as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K12\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (r +VALUED-1K12\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR6 NATNUMBERSK1"
      using valued_1_def_2 valued_0_def_6 sorry
    thus "r +VALUED-1K7 f be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_19:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K9\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 r +VALUED-1K9\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K9\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_2 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K9\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_20:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RealXREAL-0M1"
"cluster r +VALUED-1K10\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 r +VALUED-1K10\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K10\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K10\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_2 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K10\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K10\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_21:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RationalRAT-1M1"
"cluster r +VALUED-1K11\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 r +VALUED-1K11\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K11\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K11\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_2 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K11\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K11\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_22:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be IntegerINT-1M1"
"cluster r +VALUED-1K12\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 r +VALUED-1K12\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K12\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K12\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_2 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K12\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K12\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_23:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be NatNAT-1M1"
"cluster r +VALUED-1K13\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1 r +VALUED-1K13\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K13\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K13\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_2 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K13\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 r +VALUED-1K13\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_th_2:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for r be ComplexXCMPLX-0M1 holds  for c be ElementSUBSET-1M1-of C holds (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D assume [ty]: "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  have "domRELSET-1K1\<^bsub>(C)\<^esub> (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 C"
    using funct_2_def_1 sorry
  thus " for c be ElementSUBSET-1M1-of C holds (r +VALUED-1K9\<^bsub>(C,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 r +XCMPLX-0K2 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
    using valued_1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_24:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K7 f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "r +VALUED-1K7 f be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 (r +VALUED-1K7 f) =XBOOLE-0R4 domFINSEQ-1K5 f"
      using valued_1_def_2 sorry
    thus "r +VALUED-1K7 f be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_1 sorry
  qed
qed "sorry"

(*begin*)
mdef valued_1_def_3 (" _ -VALUED-1K14  _ " [132,132]132 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"func f -VALUED-1K14 r \<rightarrow> FunctionFUNCT-1M1 equals
  (-XCMPLX-0K4 r)+VALUED-1K7 f"
proof-
  (*coherence*)
    show "(-XCMPLX-0K4 r)+VALUED-1K7 f be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_1_th_3:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds domRELAT-1K1 (f -VALUED-1K14 r) =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies (f -VALUED-1K14 r).FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c -XCMPLX-0K6 r)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds domRELAT-1K1 (f -VALUED-1K14 r) =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 f &  not (f -VALUED-1K14 r).FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c -XCMPLX-0K6 r))"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    have "domRELAT-1K1 (f -VALUED-1K14 r) =XBOOLE-0R4 domRELAT-1K1 f"
      using valued_1_def_2 sorry
    thus "domRELAT-1K1 (f -VALUED-1K14 r) =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 f &  not (f -VALUED-1K14 r).FUNCT-1K1 c =XBOOLE-0R4 f .FUNCT-1K1 c -XCMPLX-0K6 r))"
      using valued_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_25:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K14 r as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f -VALUED-1K14 r be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_26:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be RealXREAL-0M1"
"cluster f -VALUED-1K14 r as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f -VALUED-1K14 r be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_1_cl_27:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be RationalRAT-1M1"
"cluster f -VALUED-1K14 r as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f -VALUED-1K14 r be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_28:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be IntegerINT-1M1"
"cluster f -VALUED-1K14 r as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f -VALUED-1K14 r be INTINT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

syntax VALUED_1K15 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K15\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "f -VALUED-1K15\<^bsub>(C,D)\<^esub> r" \<rightharpoonup> "f -VALUED-1K14 r"

mtheorem valued_1_add_11:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K14 r as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f -VALUED-1K14 r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 (f -VALUED-1K14 r) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_2 valued_0_def_1 sorry
    thus "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K16 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K16\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "f -VALUED-1K16\<^bsub>(C,D)\<^esub> r" \<rightharpoonup> "f -VALUED-1K14 r"

mtheorem valued_1_add_12:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RealXREAL-0M1"
"cluster f -VALUED-1K14 r as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f -VALUED-1K15\<^bsub>(C,D)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f -VALUED-1K15\<^bsub>(C,D)\<^esub> r) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_2 valued_0_def_3 sorry
    thus "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K17\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "f -VALUED-1K17\<^bsub>(C,D)\<^esub> r" \<rightharpoonup> "f -VALUED-1K14 r"

mtheorem valued_1_add_13:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RationalRAT-1M1"
"cluster f -VALUED-1K14 r as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f -VALUED-1K16\<^bsub>(C,D)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f -VALUED-1K16\<^bsub>(C,D)\<^esub> r) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_2 relat_1_def_19 sorry
    thus "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K18 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K18\<^bsub>'( _ , _ ')\<^esub>  _ " [132,0,0,132]132)
translations "f -VALUED-1K18\<^bsub>(C,D)\<^esub> r" \<rightharpoonup> "f -VALUED-1K14 r"

mtheorem valued_1_add_14:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be IntegerINT-1M1"
"cluster f -VALUED-1K14 r as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f -VALUED-1K17\<^bsub>(C,D)\<^esub> r) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f -VALUED-1K17\<^bsub>(C,D)\<^esub> r) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_2 relat_1_def_19 sorry
    thus "f -VALUED-1K14 r be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_29:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K15\<^bsub>(C,D)\<^esub> r as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f -VALUED-1K15\<^bsub>(C,D)\<^esub> r implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_30:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RealXREAL-0M1"
"cluster f -VALUED-1K16\<^bsub>(C,D)\<^esub> r as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f -VALUED-1K16\<^bsub>(C,D)\<^esub> r implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_31:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RationalRAT-1M1"
"cluster f -VALUED-1K17\<^bsub>(C,D)\<^esub> r as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f -VALUED-1K17\<^bsub>(C,D)\<^esub> r implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_32:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be IntegerINT-1M1"
"cluster f -VALUED-1K18\<^bsub>(C,D)\<^esub> r as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 f -VALUED-1K18\<^bsub>(C,D)\<^esub> r implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for r be ComplexXCMPLX-0M1 holds  for c be ElementSUBSET-1M1-of C holds (f -VALUED-1K15\<^bsub>(C,D)\<^esub> r).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c -XCMPLX-0K6 r"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D assume [ty]: "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  have "domRELSET-1K1\<^bsub>(C)\<^esub> (f -VALUED-1K15\<^bsub>(C,D)\<^esub> r) =XBOOLE-0R4 C"
    using funct_2_def_1 sorry
  thus " for c be ElementSUBSET-1M1-of C holds (f -VALUED-1K15\<^bsub>(C,D)\<^esub> r).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c -XCMPLX-0K6 r"
    using valued_1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_33:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K14 r as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f -VALUED-1K14 r be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

(*begin*)
mdef valued_1_def_4 (" _ '(#')VALUED-1K19  _ " [164,164]164 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 (#)VALUED-1K19 f2 \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
    proof-
      let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 f2 .FUNCT-1K1 Lamb1"
      let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c))))"
        proof-
          have " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 ?X & ( for x be objectHIDDENM1 holds x inHIDDENR3 ?X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 f2 .FUNCT-1K1 Lamb1"
      let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
      proof-
        have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c))) implies f =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix f assume [ty]: "f be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A1: "domRELAT-1K1 f =XBOOLE-0R4 ?X"
            and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
            and A3: "domRELAT-1K1 g =XBOOLE-0R4 ?X"
            and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 f"
            then have "f .FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
              using A2 sorry
            also have "... = g .FUNCT-1K1 x"
              using A1 A3 A4 A5 sorry
            finally show "f .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "f =HIDDENR1 g"
            using A1 A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem VALUED_1K19_commutativity:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds f1 (#)VALUED-1K19 f2 =HIDDENR1 f2 (#)VALUED-1K19 f1"
proof-
  have " for it be FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f1 (#)VALUED-1K19 f2 implies it =HIDDENR1 f2 (#)VALUED-1K19 f1"
  proof-
    let ?F = "\<lambda>Lamb1. f1 .FUNCT-1K1 Lamb1 *XCMPLX-0K3 f2 .FUNCT-1K1 Lamb1"
    let ?X = "domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
    have " for it be FunctionFUNCT-1M1 holds  for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c) implies domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f2 /\\XBOOLE-0K3 domRELAT-1K1 f1 & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 f2 .FUNCT-1K1 c *XCMPLX-0K3 f1 .FUNCT-1K1 c)"
       sorry
    thus " ?thesis "
      using valued_1_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_5:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
proof(rule ballI,rule ballI,rule ballI)
  fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix c assume [ty]: "c be objectHIDDENM1"
  have A1: "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
    using valued_1_def_4 sorry
  show "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
  proof-
    have cases: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) or  not c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
       sorry
    have case1: "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
    proof(rule impI)
      assume "c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
      thus "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using valued_1_def_4 sorry
    qed
    have case2: " not c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies (f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
    proof(rule impI)
      assume A2: " not c inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
      then have " not c inHIDDENR3 domRELAT-1K1 f1 or  not c inHIDDENR3 domRELAT-1K1 f2"
        using A1 xboole_0_def_4 sorry
      then have "f1 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 or f2 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
        using funct_1_def_2 sorry
      thus "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 .FUNCT-1K1 c"
        using A2 funct_1_def_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_34:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be complex-valuedVALUED-0V5"
  proof-
    have "f1 (#)VALUED-1K19 f2 be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies (f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        then have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =XBOOLE-0R4 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
          using valued_1_def_4 sorry
        thus "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "f1 (#)VALUED-1K19 f2 be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_35:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be real-valuedVALUED-0V7"
  proof-
    have "f1 (#)VALUED-1K19 f2 be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies (f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        then have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
          using valued_1_def_4 sorry
        thus "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "f1 (#)VALUED-1K19 f2 be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_36:
  mlet "f1 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (f1 (#)VALUED-1K19 f2) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (f1 (#)VALUED-1K19 f2)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"and A2: "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A1 valued_1_def_4 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K19 f2 be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_37:
  mlet "f1 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be INTINT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (f1 (#)VALUED-1K19 f2) implies y inHIDDENR3 INTINT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (f1 (#)VALUED-1K19 f2)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"and A2: "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A1 valued_1_def_4 sorry
      thus "y inHIDDENR3 INTINT-1K1"
        using A2 int_1_def_2 sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K19 f2 be INTINT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_38:
  mlet "f1 be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1", "f2 be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be natural-valuedVALUED-0V8"
  proof-
    have "f1 (#)VALUED-1K19 f2 be natural-valuedVALUED-0V4"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2) implies (f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f1 (#)VALUED-1K19 f2)"
        then have "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x =COMPLEX1R1 f1 .FUNCT-1K1 x *XCMPLX-0K3 f2 .FUNCT-1K1 x"
          using valued_1_def_4 sorry
        thus "(f1 (#)VALUED-1K19 f2).FUNCT-1K1 x be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus "f1 (#)VALUED-1K19 f2 be natural-valuedVALUED-0V4"
        using valued_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax VALUED_1K20 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K20\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 (#)VALUED-1K19 f2"

mtheorem valued_1_add_15:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 (#)VALUED-1K19 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngFUNCT-1K2 (f1 (#)VALUED-1K19 f2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_4 valued_0_def_1 sorry
    thus "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K21 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K21\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 (#)VALUED-1K19 f2"

mtheorem valued_1_add_16:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 (#)VALUED-1K19 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_4 valued_0_def_3 sorry
    thus "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K22 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K22\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 (#)VALUED-1K19 f2"

mtheorem valued_1_add_17:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 (#)VALUED-1K19 f2 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_4 relat_1_def_19 sorry
    thus "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K23 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K23\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 (#)VALUED-1K19 f2"

mtheorem valued_1_add_18:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 (#)VALUED-1K19 f2 as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_4 relat_1_def_19 sorry
    thus "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K24 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K24\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 (#)VALUED-1K19 f2"

mtheorem valued_1_add_19:
  mlet "C be setHIDDENM2", "D1 be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "D2 be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 (#)VALUED-1K19 f2 as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR6 NATNUMBERSK1"
      using valued_1_def_4 valued_0_def_6 sorry
    thus "f1 (#)VALUED-1K19 f2 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_39:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_4 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K20\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_40:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_4 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_41:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_4 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K22\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_42:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_4 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K23\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_43:
  mlet "C be setHIDDENM2", "D1 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1 f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> f1 =XBOOLE-0R4 C & domRELSET-1K1\<^bsub>(C)\<^esub> f2 =XBOOLE-0R4 C"
        using funct_2_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C /\\XBOOLE-0K3 C"
        using valued_1_def_4 sorry
      also have "... = C"
         sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K24\<^bsub>(C,D1,D2)\<^esub> f2 &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_44:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) =XBOOLE-0R4 domFINSEQ-1K5 f1 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domFINSEQ-1K5 f2"
      using valued_1_def_4 sorry
    thus "f1 (#)VALUED-1K19 f2 be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_2 sorry
  qed
qed "sorry"

(*begin*)
mdef valued_1_def_5 (" _ '(#')VALUED-1K25  _ " [164,164]164 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"func r (#)VALUED-1K25 f \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)"
    proof-
      let ?F = "\<lambda>Lamb1. r *XCMPLX-0K3 f .FUNCT-1K1 Lamb1"
      show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)"
      proof-
        have " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c))))"
        proof-
          have " ex g be FunctionFUNCT-1M1 st domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x))"
            using funct_1_sch_3 sorry
          thus " not ( for VarFor1 be FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c))))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. r *XCMPLX-0K3 f .FUNCT-1K1 Lamb1"
      show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c)) implies it1 =HIDDENR1 it2"
      proof-
        have " for h be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c))) implies h =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix h assume [ty]: "h be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A1: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
            and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
            and A3: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
            and A4: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =XBOOLE-0R4 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A5: "x inHIDDENR3 domRELAT-1K1 h"
            then have "h .FUNCT-1K1 x =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-1K1 x"
              using A2 sorry
            also have "... = g .FUNCT-1K1 x"
              using A1 A3 A4 A5 sorry
            finally show "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "h =HIDDENR1 g"
            using A1 A3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

abbreviation(input) VALUED_1K26(" _ '(#')VALUED-1K26  _ " [164,164]164) where
  "f (#)VALUED-1K26 r \<equiv> r (#)VALUED-1K25 f"

mtheorem valued_1_th_6:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for r be ComplexXCMPLX-0M1 holds  for c be objectHIDDENM1 holds (r (#)VALUED-1K25 f).FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c"
proof(rule ballI,rule ballI,rule ballI)
  fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  fix c assume [ty]: "c be objectHIDDENM1"
  have A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (r (#)VALUED-1K25 f)"
    using valued_1_def_5 sorry
  show "(r (#)VALUED-1K25 f).FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c"
  proof-
    have cases: "c inHIDDENR3 domRELAT-1K1 f or  not c inHIDDENR3 domRELAT-1K1 f"
       sorry
    have case1: "c inHIDDENR3 domRELAT-1K1 f implies (r (#)VALUED-1K25 f).FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c"
    proof(rule impI)
      assume "c inHIDDENR3 domRELAT-1K1 f"
      thus "(r (#)VALUED-1K25 f).FUNCT-1K1 c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 c"
        using A1 valued_1_def_5 sorry
    qed
    have case2: " not c inHIDDENR3 domRELAT-1K1 f implies (r (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
    proof(rule impI)
      assume A2: " not c inHIDDENR3 domRELAT-1K1 f"
      then have "(r (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 (0NUMBERSK6)"
        using A1 funct_1_def_2 sorry
      also have "... = r *XCMPLX-0K3 f .FUNCT-1K1 c"
        using A2 funct_1_def_2 sorry
      finally show "(r (#)VALUED-1K25 f).FUNCT-1K1 c =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-1K1 c"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_45:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K25 f as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be complex-valuedVALUED-0V5"
  proof-
    have "r (#)VALUED-1K25 f be complex-valuedVALUED-0V1"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 x be complexXCMPLX-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        then have "(r (#)VALUED-1K25 f).FUNCT-1K1 x =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-1K1 x"
          using valued_1_def_5 sorry
        thus "(r (#)VALUED-1K25 f).FUNCT-1K1 x be complexXCMPLX-0V1"
           sorry
      qed "sorry"
      thus "r (#)VALUED-1K25 f be complex-valuedVALUED-0V1"
        using valued_0_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_46:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be real-valuedVALUED-0V7"
  proof-
    have "r (#)VALUED-1K25 f be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        then have "(r (#)VALUED-1K25 f).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 x"
          using valued_1_def_5 sorry
        thus "(r (#)VALUED-1K25 f).FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "r (#)VALUED-1K25 f be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_47:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be RationalRAT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K25 f) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K25 f)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"and A2: "(r (#)VALUED-1K25 f).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(r (#)VALUED-1K25 f).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 x"
        using A1 valued_1_def_5 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 f be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_48:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "r be IntegerINT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be INTINT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K25 f) implies y inHIDDENR3 INTINT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (r (#)VALUED-1K25 f)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"and A2: "(r (#)VALUED-1K25 f).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "(r (#)VALUED-1K25 f).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 x"
        using A1 valued_1_def_5 sorry
      thus "y inHIDDENR3 INTINT-1K1"
        using A2 int_1_def_2 sorry
    qed "sorry"
    thus "r (#)VALUED-1K25 f be INTINT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_49:
  mlet "f be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1", "r be NatNAT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be natural-valuedVALUED-0V8"
  proof-
    have "r (#)VALUED-1K25 f be natural-valuedVALUED-0V4"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f) implies (r (#)VALUED-1K25 f).FUNCT-1K1 x be naturalORDINAL1V7"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (r (#)VALUED-1K25 f)"
        then have "(r (#)VALUED-1K25 f).FUNCT-1K1 x =COMPLEX1R1 r *XCMPLX-0K3 f .FUNCT-1K1 x"
          using valued_1_def_5 sorry
        thus "(r (#)VALUED-1K25 f).FUNCT-1K1 x be naturalORDINAL1V7"
           sorry
      qed "sorry"
      thus "r (#)VALUED-1K25 f be natural-valuedVALUED-0V4"
        using valued_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax VALUED_1K27 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K27\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r (#)VALUED-1K25 f"

mtheorem valued_1_add_20:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K25 f as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (r (#)VALUED-1K25 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 (r (#)VALUED-1K25 f) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_5 valued_0_def_1 sorry
    thus "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K28 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K28\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r (#)VALUED-1K25 f"

mtheorem valued_1_add_21:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K25 f as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_5 valued_0_def_3 sorry
    thus "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K29 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K29\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r (#)VALUED-1K25 f"

mtheorem valued_1_add_22:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be RationalRAT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_5 relat_1_def_19 sorry
    thus "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K30 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K30\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r (#)VALUED-1K25 f"

mtheorem valued_1_add_23:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be IntegerINT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_5 relat_1_def_19 sorry
    thus "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K31 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '(#')VALUED-1K31\<^bsub>'( _ , _ ')\<^esub>  _ " [164,0,0,164]164)
translations "r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "r (#)VALUED-1K25 f"

mtheorem valued_1_add_24:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)", "r be NatNAT-1M1"
"cluster r (#)VALUED-1K25 f as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR6 NATNUMBERSK1"
      using valued_1_def_5 valued_0_def_6 sorry
    thus "r (#)VALUED-1K25 f be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_50:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_5 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_51:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_5 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K28\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_52:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be RationalRAT-1M1"
"cluster r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_5 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K29\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_53:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be IntegerINT-1M1"
"cluster r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_5 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K30\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_54:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)", "r be NatNAT-1M1"
"cluster r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1 r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_5 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K31\<^bsub>(C,D)\<^esub> f &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_th_7:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for r be ComplexXCMPLX-0M1 holds  for g be FunctionFUNCT-2M1-of(C,COMPLEXNUMBERSK3) holds ( for c be ElementSUBSET-1M1-of C holds g .FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) implies g =FUNCT-2R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D assume [ty]: "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
  fix r assume [ty]: "r be ComplexXCMPLX-0M1"
  fix g assume [ty]: "g be FunctionFUNCT-2M1-of(C,COMPLEXNUMBERSK3)"
  assume A1: " for c be ElementSUBSET-1M1-of C holds g .FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> c =XBOOLE-0R4 r *XCMPLX-0K3 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
  have " for x be ElementSUBSET-1M1-of C holds g .FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x"
  proof(rule ballI)
    fix x assume [ty]: "x be ElementSUBSET-1M1-of C"
    have "g .FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> x"
      using A1 sorry
    also have "... = (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x"
      using valued_1_th_6 sorry
    finally show "g .FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f).FUNCT-2K3\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> x"
       sorry
  qed "sorry"
  thus "g =FUNCT-2R2\<^bsub>(C,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(C,D)\<^esub> f"
    using funct_2_def_8 sorry
qed "sorry"

mtheorem valued_1_cl_55:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K25 f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 (r (#)VALUED-1K25 f) =XBOOLE-0R4 domFINSEQ-1K5 f"
      using valued_1_def_5 sorry
    thus "r (#)VALUED-1K25 f be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_1 sorry
  qed
qed "sorry"

(*begin*)
mdef valued_1_def_6 ("-VALUED-1K32  _ " [132]132 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func -VALUED-1K32 f \<rightarrow> complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 equals
  (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 f"
proof-
  (*coherence*)
    show "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem VALUED_1K32_involutiveness:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds -VALUED-1K32 (-VALUED-1K32 f) =HIDDENR1 f"
proof-
  have " for it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 -VALUED-1K32 f implies f =HIDDENR1 -VALUED-1K32 it"
  proof-
    have " for it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 f implies f =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 it"
    proof-
      have " for r be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds r =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 h implies h =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r"
      proof(rule ballI,rule ballI,rule impI)
        fix r assume [ty]: "r be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
        fix h assume [ty]: "h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
        assume A1: "r =FUNCT-1R1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 h"
        have "domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r) =HIDDENR1 domRELAT-1K1 h & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r).FUNCT-1K1 c)"
        proof(rule conjMI,rule ballI,rule impI)
          have "domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r) =HIDDENR1 domRELAT-1K1 r"
            using valued_1_def_5 sorry
          also have "... = domRELAT-1K1 h"
            using A1 valued_1_def_5 sorry
          finally show "domRELAT-1K1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r) =HIDDENR1 domRELAT-1K1 h"
             sorry
          fix c assume [ty]: "c be objectHIDDENM1"
          assume "c inHIDDENR3 domRELAT-1K1 h"
          obtain a where 
            [ty]:"a be ComplexXCMPLX-0M1" and aDef:"a = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 h .FUNCT-1K1 c"
             sorry
          have "h .FUNCT-1K1 c =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 a"
             sorry
          also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 r .FUNCT-1K1 c"
            using A1 valued_1_th_6 sorry
          also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r).FUNCT-1K1 c"
            using valued_1_th_6 sorry
          finally show "h .FUNCT-1K1 c =HIDDENR1 ((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r).FUNCT-1K1 c"
             sorry
        qed "sorry"
        thus "h =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K25 r"
          using funct_1_def_11 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using valued_1_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_8:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds (-VALUED-1K32 f).FUNCT-1K1 c =COMPLEX1R1 -XCMPLX-0K4 f .FUNCT-1K1 c)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds (-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c)"
  proof(rule ballI,rule conjMI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    show A1: "domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELAT-1K1 f"
      using valued_1_def_5 sorry
    fix c assume [ty]: "c be objectHIDDENM1"
    show "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
    proof-
      have cases: "c inHIDDENR3 domRELAT-1K1 f or  not c inHIDDENR3 domRELAT-1K1 f"
         sorry
      have case1: "c inHIDDENR3 domRELAT-1K1 f implies (-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
      proof(rule impI)
        assume "c inHIDDENR3 domRELAT-1K1 f"
        then have "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 f .FUNCT-1K1 c"
          using A1 valued_1_def_5 sorry
        also have "... = -XCMPLX-0K4 f .FUNCT-1K1 c"
           sorry
        finally show "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
           sorry
      qed
      have case2: " not c inHIDDENR3 domRELAT-1K1 f implies (-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
      proof(rule impI)
        assume A2: " not c inHIDDENR3 domRELAT-1K1 f"
        then have "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 0NUMBERSK6"
          using A1 funct_1_def_2 sorry
        also have "... = -XCMPLX-0K4 f .FUNCT-1K1 c"
          using A2 funct_1_def_2 sorry
        finally show "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_9:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c) implies g =FUNCT-1R1 -VALUED-1K32 f"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix g assume [ty]: "g be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 g"
    and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
  have "domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELAT-1K1 g & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies (-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 g .FUNCT-1K1 c)"
  proof(rule conjMI,rule ballI,rule impI)
    show "domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELAT-1K1 g"
      using A1 valued_1_def_5 sorry
    fix c assume [ty]: "c be objectHIDDENM1"
    assume A3: "c inHIDDENR3 domRELAT-1K1 g"
    have "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 -XCMPLX-0K4 f .FUNCT-1K1 c"
      using valued_1_th_8 sorry
    also have "... = g .FUNCT-1K1 c"
      using A1 A2 A3 sorry
    finally show "(-VALUED-1K32 f).FUNCT-1K1 c =HIDDENR1 g .FUNCT-1K1 c"
       sorry
  qed "sorry"
  thus "g =FUNCT-1R1 -VALUED-1K32 f"
    using funct_1_def_11 sorry
qed "sorry"

mtheorem valued_1_cl_56:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "-VALUED-1K32 f be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_57:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "-VALUED-1K32 f be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_1_cl_58:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "-VALUED-1K32 f be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_59:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "-VALUED-1K32 f be INTINT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

syntax VALUED_1K33 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-VALUED-1K33\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-VALUED-1K33\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "-VALUED-1K32 f"

mtheorem valued_1_add_25:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster -VALUED-1K32 f as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 (-VALUED-1K32 f) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_5 valued_0_def_1 sorry
    thus "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K34 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-VALUED-1K34\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-VALUED-1K34\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "-VALUED-1K32 f"

mtheorem valued_1_add_26:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster -VALUED-1K32 f as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_5 valued_0_def_3 sorry
    thus "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K35 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-VALUED-1K35\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-VALUED-1K35\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "-VALUED-1K32 f"

mtheorem valued_1_add_27:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster -VALUED-1K32 f as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K34\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_5 relat_1_def_19 sorry
    thus "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K36 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("-VALUED-1K36\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,132]132)
translations "-VALUED-1K36\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> "-VALUED-1K32 f"

mtheorem valued_1_add_28:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster -VALUED-1K32 f as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K35\<^bsub>(C,D)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (-VALUED-1K35\<^bsub>(C,D)\<^esub> f) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_def_5 relat_1_def_19 sorry
    thus "-VALUED-1K32 f be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_60:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster -VALUED-1K33\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 -VALUED-1K33\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_61:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster -VALUED-1K34\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 -VALUED-1K34\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_62:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster -VALUED-1K35\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 -VALUED-1K35\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_63:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster -VALUED-1K36\<^bsub>(C,D)\<^esub> f as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 -VALUED-1K36\<^bsub>(C,D)\<^esub> f implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_64:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster -VALUED-1K32 f as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "-VALUED-1K32 f be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

(*begin*)
mdef valued_1_def_7 (" _ \<inverse>VALUED-1K37" [228]228 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f \<inverse>VALUED-1K37 \<rightarrow> complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
proof-
  (*existence*)
    show " ex it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
    proof-
      let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
      show " ex it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
      proof-
        have " not ( for VarFor1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
        proof-
          obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A1: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =HIDDENR1 ?F(x))"
            using funct_1_sch_3 sorry
          have "g be complex-valuedVALUED-0V5"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x be complexXCMPLX-0V1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELAT-1K1 g"
              then have "g .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
                using A1 sorry
              thus "g .FUNCT-1K1 x be complexXCMPLX-0V1"
                 sorry
            qed "sorry"
            thus "g be complex-valuedVALUED-0V5"
              using valued_0_def_7 sorry
          qed
          thus " not ( for VarFor1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))))"
            using A1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for it2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
      show " for it1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for it2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)) implies it1 =HIDDENR1 it2"
      proof-
        have " for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5))) implies h =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix h assume [ty]: "h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
          fix g assume [ty]: "g be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
          assume A2: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
            and A3: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =COMPLEX1R1 ?F(c)"
            and A4: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
            and A5: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =COMPLEX1R1 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A6: "x inHIDDENR3 domRELAT-1K1 h"
            then have "h .FUNCT-1K1 x =HIDDENR1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
              using A3 sorry
            also have "... = g .FUNCT-1K1 x"
              using A2 A4 A5 A6 sorry
            finally show "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "h =HIDDENR1 g"
            using A2 A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem VALUED_1K37_involutiveness:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds (f \<inverse>VALUED-1K37)\<inverse>VALUED-1K37 =HIDDENR1 f"
proof-
  have " for it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 f \<inverse>VALUED-1K37 implies f =HIDDENR1 it \<inverse>VALUED-1K37"
  proof-
    let ?F = "\<lambda>Lamb1. (f .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
    have " for it be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) implies domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 it & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =COMPLEX1R1 (it .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
    proof-
      have " for r be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 r implies r .FUNCT-1K1 c =COMPLEX1R1 (h .FUNCT-1K1 c)\<inverse>XCMPLX-0K5) implies domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =HIDDENR1 (r .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
        fix r assume [ty]: "r be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
        fix h assume [ty]: "h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
        assume A7: "domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h"
          and A8: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 r implies r .FUNCT-1K1 c =COMPLEX1R1 (h .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        show "domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h"
          using A7 sorry
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A9: "c inHIDDENR3 domRELAT-1K1 h"
        have "h .FUNCT-1K1 c =HIDDENR1 ((h .FUNCT-1K1 c)\<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = (r .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
          using A7 A8 A9 sorry
        finally show "h .FUNCT-1K1 c =HIDDENR1 (r .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using valued_1_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_10:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds f \<inverse>VALUED-1K37 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix c assume [ty]: "c be objectHIDDENM1"
  have A1: "domRELAT-1K1 (f \<inverse>VALUED-1K37) =XBOOLE-0R4 domRELAT-1K1 f"
    using valued_1_def_7 sorry
  show "f \<inverse>VALUED-1K37 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
  proof-
    have cases: "c inHIDDENR3 domRELAT-1K1 f or  not c inHIDDENR3 domRELAT-1K1 f"
       sorry
    have case1: "c inHIDDENR3 domRELAT-1K1 f implies f \<inverse>VALUED-1K37 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
    proof(rule impI)
      assume "c inHIDDENR3 domRELAT-1K1 f"
      thus "f \<inverse>VALUED-1K37 .FUNCT-1K1 c =COMPLEX1R1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A1 valued_1_def_7 sorry
    qed
    have case2: " not c inHIDDENR3 domRELAT-1K1 f implies f \<inverse>VALUED-1K37 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
    proof(rule impI)
      assume A2: " not c inHIDDENR3 domRELAT-1K1 f"
      then have "f \<inverse>VALUED-1K37 .FUNCT-1K1 c =HIDDENR1 (0NUMBERSK6)\<inverse>XCMPLX-0K5"
        using A1 funct_1_def_2 sorry
      also have "... = (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
        using A2 funct_1_def_2 sorry
      finally show "f \<inverse>VALUED-1K37 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)\<inverse>XCMPLX-0K5"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_65:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f \<inverse>VALUED-1K37 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be real-valuedVALUED-0V7"
  proof-
    have "f \<inverse>VALUED-1K37 be real-valuedVALUED-0V3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (f \<inverse>VALUED-1K37) implies f \<inverse>VALUED-1K37 .FUNCT-1K1 x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (f \<inverse>VALUED-1K37)"
        then have "f \<inverse>VALUED-1K37 .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using valued_1_def_7 sorry
        thus "f \<inverse>VALUED-1K37 .FUNCT-1K1 x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "f \<inverse>VALUED-1K37 be real-valuedVALUED-0V3"
        using valued_0_def_9 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_66:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f \<inverse>VALUED-1K37 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (f \<inverse>VALUED-1K37) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 (f \<inverse>VALUED-1K37)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 (f \<inverse>VALUED-1K37)"and A2: "f \<inverse>VALUED-1K37 .FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "f \<inverse>VALUED-1K37 .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
        using A1 valued_1_def_7 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus "f \<inverse>VALUED-1K37 be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

syntax VALUED_1K38 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>VALUED-1K38\<^bsub>'( _ , _ ')\<^esub>" [228,0,0]228)
translations "f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f \<inverse>VALUED-1K37"

mtheorem valued_1_add_29:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f \<inverse>VALUED-1K37 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f \<inverse>VALUED-1K37) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 (f \<inverse>VALUED-1K37) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_def_7 valued_0_def_1 sorry
    thus "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K39 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>VALUED-1K39\<^bsub>'( _ , _ ')\<^esub>" [228,0,0]228)
translations "f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f \<inverse>VALUED-1K37"

mtheorem valued_1_add_30:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f \<inverse>VALUED-1K37 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub>) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_7 valued_0_def_3 sorry
    thus "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K40 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>VALUED-1K40\<^bsub>'( _ , _ ')\<^esub>" [228,0,0]228)
translations "f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f \<inverse>VALUED-1K37"

mtheorem valued_1_add_31:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f \<inverse>VALUED-1K37 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub>) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_7 relat_1_def_19 sorry
    thus "f \<inverse>VALUED-1K37 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_67:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_7 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub>) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K38\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_68:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_7 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub>) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K39\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_69:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_7 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> (f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub>) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1 f \<inverse>VALUED-1K40\<^bsub>(C,D)\<^esub> &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_70:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f \<inverse>VALUED-1K37 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 (f \<inverse>VALUED-1K37) =XBOOLE-0R4 domFINSEQ-1K5 f"
      using valued_1_def_7 sorry
    thus "f \<inverse>VALUED-1K37 be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_1 sorry
  qed
qed "sorry"

(*begin*)
mdef valued_1_def_8 (" _ ^2VALUED-1K41" [354]354 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f ^2VALUED-1K41 \<rightarrow> FunctionFUNCT-1M1 equals
  f (#)VALUED-1K19 f"
proof-
  (*coherence*)
    show "f (#)VALUED-1K19 f be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_1_th_11:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 f ^2VALUED-1K41 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds f ^2VALUED-1K41 .FUNCT-1K1 c =XBOOLE-0R4 (f .FUNCT-1K1 c)^2SQUARE-1K1)"
proof-
  have " for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 f ^2VALUED-1K41 =HIDDENR1 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds f ^2VALUED-1K41 .FUNCT-1K1 c =XBOOLE-0R4 (f .FUNCT-1K1 c)^2SQUARE-1K1)"
  proof(rule ballI,rule conjMI,rule ballI)
    fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have A1: "domRELAT-1K1 f ^2VALUED-1K41 =HIDDENR1 domRELAT-1K1 f /\\XBOOLE-0K3 domRELAT-1K1 f"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f"
       sorry
    finally show "domRELAT-1K1 f ^2VALUED-1K41 =HIDDENR1 domRELAT-1K1 f"
       sorry
    fix c assume [ty]: "c be objectHIDDENM1"
    show "f ^2VALUED-1K41 .FUNCT-1K1 c =XBOOLE-0R4 (f .FUNCT-1K1 c)^2SQUARE-1K1"
    proof-
      have cases: "c inHIDDENR3 domRELAT-1K1 f or  not c inHIDDENR3 domRELAT-1K1 f"
         sorry
      have case1: "c inHIDDENR3 domRELAT-1K1 f implies f ^2VALUED-1K41 .FUNCT-1K1 c =XBOOLE-0R4 (f .FUNCT-1K1 c)^2SQUARE-1K1"
      proof(rule impI)
        assume "c inHIDDENR3 domRELAT-1K1 f"
        thus "f ^2VALUED-1K41 .FUNCT-1K1 c =XBOOLE-0R4 (f .FUNCT-1K1 c)^2SQUARE-1K1"
          using A1 valued_1_def_4 sorry
      qed
      have case2: " not c inHIDDENR3 domRELAT-1K1 f implies f ^2VALUED-1K41 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)^2SQUARE-1K1"
      proof(rule impI)
        assume A2: " not c inHIDDENR3 domRELAT-1K1 f"
        then have "f ^2VALUED-1K41 .FUNCT-1K1 c =HIDDENR1 (0NUMBERSK6)^2SQUARE-1K1"
          using A1 funct_1_def_2 sorry
        also have "... = (f .FUNCT-1K1 c)^2SQUARE-1K1"
          using A2 funct_1_def_2 sorry
        finally show "f ^2VALUED-1K41 .FUNCT-1K1 c =HIDDENR1 (f .FUNCT-1K1 c)^2SQUARE-1K1"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_71:
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_72:
  mlet "f be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_1_cl_73:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_74:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be INTINT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_75:
  mlet "f be natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be natural-valuedVALUED-0V8"
     sorry
qed "sorry"

syntax VALUED_1K42 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^2VALUED-1K42\<^bsub>'( _ , _ ')\<^esub>" [354,0,0]354)
translations "f ^2VALUED-1K42\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^2VALUED-1K41"

mtheorem valued_1_add_32:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^2VALUED-1K41 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 f ^2VALUED-1K41 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 f ^2VALUED-1K41 c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_th_11 valued_0_def_1 sorry
    thus "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K43 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^2VALUED-1K43\<^bsub>'( _ , _ ')\<^esub>" [354,0,0]354)
translations "f ^2VALUED-1K43\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^2VALUED-1K41"

mtheorem valued_1_add_33:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^2VALUED-1K41 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f ^2VALUED-1K42\<^bsub>(C,D)\<^esub> =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f ^2VALUED-1K42\<^bsub>(C,D)\<^esub> c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_th_11 valued_0_def_3 sorry
    thus "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K44 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^2VALUED-1K44\<^bsub>'( _ , _ ')\<^esub>" [354,0,0]354)
translations "f ^2VALUED-1K44\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^2VALUED-1K41"

mtheorem valued_1_add_34:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^2VALUED-1K41 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f ^2VALUED-1K43\<^bsub>(C,D)\<^esub> =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f ^2VALUED-1K43\<^bsub>(C,D)\<^esub> c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_th_11 relat_1_def_19 sorry
    thus "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K45 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^2VALUED-1K45\<^bsub>'( _ , _ ')\<^esub>" [354,0,0]354)
translations "f ^2VALUED-1K45\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^2VALUED-1K41"

mtheorem valued_1_add_35:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^2VALUED-1K41 as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f ^2VALUED-1K44\<^bsub>(C,D)\<^esub> =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> f ^2VALUED-1K44\<^bsub>(C,D)\<^esub> c=MEMBEREDR4 INTINT-1K1"
      using valued_1_th_11 relat_1_def_19 sorry
    thus "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K46 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^2VALUED-1K46\<^bsub>'( _ , _ ')\<^esub>" [354,0,0]354)
translations "f ^2VALUED-1K46\<^bsub>(C,D)\<^esub>" \<rightharpoonup> "f ^2VALUED-1K41"

mtheorem valued_1_add_36:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster f ^2VALUED-1K41 as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> f ^2VALUED-1K45\<^bsub>(C,D)\<^esub> =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> f ^2VALUED-1K45\<^bsub>(C,D)\<^esub> c=MEMBEREDR6 NATNUMBERSK1"
      using valued_1_th_11 valued_0_def_6 sorry
    thus "f ^2VALUED-1K41 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_76:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f ^2VALUED-1K42\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f ^2VALUED-1K42\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_77:
  mlet "C be setHIDDENM2", "D be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f ^2VALUED-1K43\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f ^2VALUED-1K43\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_78:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f ^2VALUED-1K44\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f ^2VALUED-1K44\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_79:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f ^2VALUED-1K45\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 f ^2VALUED-1K45\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_80:
  mlet "C be setHIDDENM2", "D be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster f ^2VALUED-1K46\<^bsub>(C,D)\<^esub> as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1 f ^2VALUED-1K46\<^bsub>(C,D)\<^esub> implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_81:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f ^2VALUED-1K41 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

(*begin*)
mdef valued_1_def_9 (" _ -VALUED-1K47  _ " [132,132]132 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 -VALUED-1K47 f2 \<rightarrow> FunctionFUNCT-1M1 equals
  f1 +VALUED-1K1 (-VALUED-1K32 f2)"
proof-
  (*coherence*)
    show "f1 +VALUED-1K1 (-VALUED-1K32 f2) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_1_cl_82:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_83:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_1_cl_84:
  mlet "f1 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_85:
  mlet "f1 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is INTINT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be INTINT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_th_12:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 -VALUED-1K47 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (-VALUED-1K32 f2)"
      using valued_1_def_1 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_5 sorry
    finally show "domRELAT-1K1 (f1 -VALUED-1K47 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_13:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) implies (f1 -VALUED-1K47 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2) implies (f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix c assume [ty]: "c be objectHIDDENM1"
    assume "c inHIDDENR3 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
    then have "(f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c +XCMPLX-0K2 (-VALUED-1K32 f2).FUNCT-1K1 c"
      using valued_1_def_1 sorry
    also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
      using valued_1_th_8 sorry
    finally show "(f1 -VALUED-1K47 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_14:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f1 -VALUED-1K47 f2) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c) implies f =FUNCT-1R1 f1 -VALUED-1K47 f2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
    and A2: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
  have "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f1 -VALUED-1K47 f2) & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 c =HIDDENR1 (f1 -VALUED-1K47 f2).FUNCT-1K1 c)"
  proof(rule conjMI,rule ballI,rule impI)
    show "domRELAT-1K1 f =XBOOLE-0R4 domRELAT-1K1 (f1 -VALUED-1K47 f2)"
      using A1 sorry
    fix c assume [ty]: "c be objectHIDDENM1"
    assume A3: "c inHIDDENR3 domRELAT-1K1 f"
    then have "f .FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
      using A2 sorry
    also have "... = f1 .FUNCT-1K1 c +XCMPLX-0K2 (-VALUED-1K32 f2).FUNCT-1K1 c"
      using valued_1_th_8 sorry
    also have "... = (f1 -VALUED-1K47 f2).FUNCT-1K1 c"
      using A1 A3 valued_1_def_1 sorry
    finally show "f .FUNCT-1K1 c =HIDDENR1 (f1 -VALUED-1K47 f2).FUNCT-1K1 c"
       sorry
  qed "sorry"
  thus "f =FUNCT-1R1 f1 -VALUED-1K47 f2"
    using funct_1_def_11 sorry
qed "sorry"

syntax VALUED_1K48 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K48\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 -VALUED-1K47 f2"

mtheorem valued_1_add_37:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 -VALUED-1K47 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f1 -VALUED-1K47 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngFUNCT-1K2 (f1 -VALUED-1K47 f2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_th_12 valued_0_def_1 sorry
    thus "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K49 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K49\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 -VALUED-1K49\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 -VALUED-1K47 f2"

mtheorem valued_1_add_38:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 -VALUED-1K47 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_th_12 valued_0_def_3 sorry
    thus "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K50 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K50\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 -VALUED-1K50\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 -VALUED-1K47 f2"

mtheorem valued_1_add_39:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 -VALUED-1K47 f2 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_th_12 relat_1_def_19 sorry
    thus "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K51 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ -VALUED-1K51\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [132,0,0,0,132]132)
translations "f1 -VALUED-1K51\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 -VALUED-1K47 f2"

mtheorem valued_1_add_40:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 -VALUED-1K47 f2 as-term-is PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K50\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> (f1 -VALUED-1K50\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR4 INTINT-1K1"
      using valued_1_th_12 relat_1_def_19 sorry
    thus "f1 -VALUED-1K47 f2 be PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mlemma valued_1_lm_3:
" for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 C"
proof-
  have " for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be setHIDDENM2"
    fix D1 assume [ty]: "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C,D2)"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,D2)\<^esub> f2)"
      using valued_1_def_1 sorry
    also have "... = C /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> (-VALUED-1K33\<^bsub>(C,D2)\<^esub> f2)"
      using funct_2_def_1 sorry
    also have "... = C /\\XBOOLE-0K3 C"
      using funct_2_def_1 sorry
    also have "... = C"
       sorry
    finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_86:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_3 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_87:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 -VALUED-1K49\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f1 -VALUED-1K49\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_3 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_88:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 -VALUED-1K50\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f1 -VALUED-1K50\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_3 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_89:
  mlet "C be setHIDDENM2", "D1 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 -VALUED-1K51\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,INTINT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,INTINT-1K1) holds it =HIDDENR1 f1 -VALUED-1K51\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_3 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_th_15:
" for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds  for c be ElementSUBSET-1M1-of C holds (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
proof-
  have " for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds  for c be ElementSUBSET-1M1-of C holds (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be setHIDDENM2"
    fix D1 assume [ty]: "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C,D2)"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    have A1: "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 C"
      using funct_2_def_1 sorry
    show "(f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
    proof-
      have cases: "C be  non emptyXBOOLE-0V1 or C be emptyXBOOLE-0V1"
         sorry
      have case1: "C be  non emptyXBOOLE-0V1 implies (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
      proof(rule impI)
        assume "C be  non emptyXBOOLE-0V1"
        then have "(f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c +XCMPLX-0K2 (-VALUED-1K33\<^bsub>(C,D2)\<^esub> f2).FUNCT-1K1 c"
          using A1 valued_1_def_1 sorry
        also have "... = f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
          using valued_1_th_8 sorry
        finally show "(f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
           sorry
      qed
      have case2: "C be emptyXBOOLE-0V1 implies (f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
      proof(rule impI)
        assume A2: "C be emptyXBOOLE-0V1"
        then have "f2 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
           sorry
        thus "(f1 -VALUED-1K48\<^bsub>(C,D1,D2)\<^esub> f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c -XCMPLX-0K6 f2 .FUNCT-1K1 c"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_90:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

(*begin*)
mdef valued_1_def_10 (" _ '/\<inverse>VALUED-1K52  _ " [164,164]164 ) where
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func f1 /\<inverse>VALUED-1K52 f2 \<rightarrow> FunctionFUNCT-1M1 equals
  f1 (#)VALUED-1K19 f2 \<inverse>VALUED-1K37"
proof-
  (*coherence*)
    show "f1 (#)VALUED-1K19 f2 \<inverse>VALUED-1K37 be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_1_th_16:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
  proof(rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    have "domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 (f2 \<inverse>VALUED-1K37)"
      using valued_1_def_4 sorry
    also have "... = domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_def_7 sorry
    finally show "domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =HIDDENR1 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_17:
" for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds (f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =XBOOLE-0R4 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
proof-
  have " for f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds (f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix f1 assume [ty]: "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix f2 assume [ty]: "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
    fix c assume [ty]: "c be objectHIDDENM1"
    have A1: "domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\XBOOLE-0K3 domRELAT-1K1 f2"
      using valued_1_th_16 sorry
    show "(f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
    proof-
      have cases: "c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) or  not c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2)"
         sorry
      have case1: "c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) implies (f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
      proof(rule impI)
        assume "c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2)"
        then have "(f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c *XCMPLX-0K3 f2 \<inverse>VALUED-1K37 .FUNCT-1K1 c"
          using valued_1_def_4 sorry
        also have "... = f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
          using valued_1_th_10 sorry
        finally show "(f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
           sorry
      qed
      have case2: " not c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) implies (f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
      proof(rule impI)
        assume A2: " not c inHIDDENR3 domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2)"
        then have " not c inHIDDENR3 domRELAT-1K1 f1 or  not c inHIDDENR3 domRELAT-1K1 f2"
          using A1 xboole_0_def_4 sorry
        then have A3: "f1 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6 or f2 .FUNCT-1K1 c =COMPLEX1R1 0NUMBERSK6"
          using funct_1_def_2 sorry
        have "(f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 (0NUMBERSK6)/XCMPLX-0K7 (0NUMBERSK6)"
          using A2 funct_1_def_2 sorry
        also have "... = f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
          using A3 sorry
        finally show "(f1 /\<inverse>VALUED-1K52 f2).FUNCT-1K1 c =HIDDENR1 f1 .FUNCT-1K1 c /XCMPLX-0K7 f2 .FUNCT-1K1 c"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_91:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is complex-valuedVALUED-0V5"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be complex-valuedVALUED-0V5"
     sorry
qed "sorry"

mtheorem valued_1_cl_92:
  mlet "f1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1", "f2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is real-valuedVALUED-0V7"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be real-valuedVALUED-0V7"
     sorry
qed "sorry"

mtheorem valued_1_cl_93:
  mlet "f1 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "f2 be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be RATRAT-1K1 -valuedRELAT-1V5"
     sorry
qed "sorry"

syntax VALUED_1K53 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/\<inverse>VALUED-1K53\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 /\<inverse>VALUED-1K52 f2"

mtheorem valued_1_add_41:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
  proof-
    have "domRELAT-1K1 (f1 /\<inverse>VALUED-1K52 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngFUNCT-1K2 (f1 /\<inverse>VALUED-1K52 f2) c=MEMBEREDR1 COMPLEXNUMBERSK3"
      using valued_1_th_16 valued_0_def_1 sorry
    thus "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K54 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/\<inverse>VALUED-1K54\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 /\<inverse>VALUED-1K54\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 /\<inverse>VALUED-1K52 f2"

mtheorem valued_1_add_42:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_th_16 valued_0_def_3 sorry
    thus "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K55 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ '/\<inverse>VALUED-1K55\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "f1 /\<inverse>VALUED-1K55\<^bsub>(C,D1,D2)\<^esub> f2" \<rightharpoonup> "f1 /\<inverse>VALUED-1K52 f2"

mtheorem valued_1_add_43:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f1 be PartFuncPARTFUN1M1-of(C,D1)", "f2 be PartFuncPARTFUN1M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K54\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /\<inverse>VALUED-1K54\<^bsub>(C,D1,D2)\<^esub> f2) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_th_16 relat_1_def_19 sorry
    thus "f1 /\<inverse>VALUED-1K52 f2 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

mlemma valued_1_lm_4:
" for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) =XBOOLE-0R4 C"
proof-
  have " for C be setHIDDENM2 holds  for D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of(C,D1) holds  for f2 be FunctionFUNCT-2M1-of(C,D2) holds domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be setHIDDENM2"
    fix D1 assume [ty]: "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(C,D1)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(C,D2)"
    have "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using valued_1_th_16 sorry
    also have "... = C /\\SUBSET-1K9\<^bsub>(C)\<^esub> domRELSET-1K1\<^bsub>(C)\<^esub> f2"
      using funct_2_def_1 sorry
    also have "... = C /\\XBOOLE-0K3 C"
      using funct_2_def_1 sorry
    also have "... = C"
       sorry
    finally show "domRELSET-1K1\<^bsub>(C)\<^esub> (f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2) =HIDDENR1 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_94:
  mlet "C be setHIDDENM2", "D1 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,COMPLEXNUMBERSK3) holds it =HIDDENR1 f1 /\<inverse>VALUED-1K53\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_4 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_95:
  mlet "C be setHIDDENM2", "D1 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be real-memberedMEMBEREDV3\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K54\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1 f1 /\<inverse>VALUED-1K54\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_4 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_96:
  mlet "C be setHIDDENM2", "D1 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "D2 be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f1 be FunctionFUNCT-2M1-of(C,D1)", "f2 be FunctionFUNCT-2M1-of(C,D2)"
"cluster f1 /\<inverse>VALUED-1K55\<^bsub>(C,D1,D2)\<^esub> f2 as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1 f1 /\<inverse>VALUED-1K55\<^bsub>(C,D1,D2)\<^esub> f2 implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
    using valued_1_lm_4 partfun1_def_2 sorry
qed "sorry"

mtheorem valued_1_cl_97:
  mlet "f1 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1", "f2 be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be FinSequence-likeFINSEQ-1V1"
     sorry
qed "sorry"

(*begin*)
mdef valued_1_def_11 (" |.VALUED-1K56  _ .|" [0]164 ) where
  mlet "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"func  |.VALUED-1K56 f.| \<rightarrow> real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
proof-
  (*existence*)
    show " ex it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
    proof-
      let ?F = "\<lambda>Lamb1.  |.COMPLEX1K10 f .FUNCT-1K1 Lamb1.|"
      show " ex it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)"
      proof-
        have " not ( for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|))))"
        proof-
          obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A1: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =HIDDENR1 ?F(x))"
            using funct_1_sch_3 sorry
          have "g be real-valuedVALUED-0V7"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 x be realXREAL-0V1"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 domRELAT-1K1 g"
              then have "g .FUNCT-1K1 x =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x.|"
                using A1 sorry
              thus "g .FUNCT-1K1 x be realXREAL-0V1"
                 sorry
            qed "sorry"
            thus "g be real-valuedVALUED-0V7"
              using valued_0_def_9 sorry
          qed
          thus " not ( for VarFor1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds  not (c inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|))))"
            using A1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for it2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)) implies it1 =HIDDENR1 it2"
    proof-
      let ?F = "\<lambda>Lamb1.  |.COMPLEX1K10 f .FUNCT-1K1 Lamb1.|"
      show " for it1 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for it2 be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|)) implies it1 =HIDDENR1 it2"
      proof-
        have " for h be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f & (( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|) & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|))) implies h =HIDDENR1 g"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix h assume [ty]: "h be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
          fix g assume [ty]: "g be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
          assume A2: "domRELAT-1K1 h =XBOOLE-0R4 domRELAT-1K1 f"
            and A3: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 c =COMPLEX1R1 ?F(c)"
            and A4: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
            and A5: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 g implies g .FUNCT-1K1 c =COMPLEX1R1 ?F(c)"
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h implies h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A6: "x inHIDDENR3 domRELAT-1K1 h"
            then have "h .FUNCT-1K1 x =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x.|"
              using A3 sorry
            also have "... = g .FUNCT-1K1 x"
              using A2 A4 A5 A6 sorry
            finally show "h .FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus "h =HIDDENR1 g"
            using A2 A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem VALUED_1K56_projectivity:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  |.VALUED-1K56  |.VALUED-1K56 f.| .| =HIDDENR1  |.VALUED-1K56 f.|"
proof-
  have " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1  |.VALUED-1K56 f.| implies it =HIDDENR1  |.VALUED-1K56 it.|"
  proof-
    let ?F = "\<lambda>Lamb1.  |.COMPLEX1K10 f .FUNCT-1K1 Lamb1.|"
    have " for it be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 f & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|) implies domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 it & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 it .FUNCT-1K1 c.|)"
    proof-
      have " for r be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1 holds  for h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 r implies r .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 h .FUNCT-1K1 c.|) implies domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 r & ( for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 r implies r .FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 r .FUNCT-1K1 c.|)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
        fix r assume [ty]: "r be real-valuedVALUED-0V7\<bar>FunctionFUNCT-1M1"
        fix h assume [ty]: "h be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
        assume "domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 h"
          and A7: " for c be objectHIDDENM1 holds c inHIDDENR3 domRELAT-1K1 r implies r .FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 h .FUNCT-1K1 c.|"
        show "domRELAT-1K1 r =XBOOLE-0R4 domRELAT-1K1 r"
           sorry
        fix c assume [ty]: "c be objectHIDDENM1"
        assume A8: "c inHIDDENR3 domRELAT-1K1 r"
        then have "r .FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 h .FUNCT-1K1 c.| .|"
          using A7 sorry
        also have "... =  |.COMPLEX1K10 r .FUNCT-1K1 c.|"
          using A7 A8 sorry
        finally show "r .FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 r .FUNCT-1K1 c.|"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using valued_1_def_11 sorry
  qed
  thus " ?thesis "
     sorry
qed

abbreviation(input) VALUED_1K57("absVALUED-1K57  _ " [250]250) where
  "absVALUED-1K57 f \<equiv>  |.VALUED-1K56 f.|"

mtheorem valued_1_th_18:
" for f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1 holds  for c be objectHIDDENM1 holds ( |.VALUED-1K56 f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
  fix c assume [ty]: "c be objectHIDDENM1"
  have A1: "domRELAT-1K1 ( |.VALUED-1K56 f.|) =XBOOLE-0R4 domRELAT-1K1 f"
    using valued_1_def_11 sorry
  show "( |.VALUED-1K56 f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
  proof-
    have cases: "c inHIDDENR3 domRELAT-1K1 f or  not c inHIDDENR3 domRELAT-1K1 f"
       sorry
    have case1: "c inHIDDENR3 domRELAT-1K1 f implies ( |.VALUED-1K56 f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
    proof(rule impI)
      assume "c inHIDDENR3 domRELAT-1K1 f"
      thus "( |.VALUED-1K56 f.|).FUNCT-1K1 c =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using A1 valued_1_def_11 sorry
    qed
    have case2: " not c inHIDDENR3 domRELAT-1K1 f implies ( |.VALUED-1K56 f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
    proof(rule impI)
      assume A2: " not c inHIDDENR3 domRELAT-1K1 f"
      then have "( |.VALUED-1K56 f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 .|"
        using A1 complex1_th_44 funct_1_def_2 sorry
      also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
        using A2 funct_1_def_2 sorry
      finally show "( |.VALUED-1K56 f.|).FUNCT-1K1 c =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 c.|"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_98:
  mlet "f be RATRAT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster  |.VALUED-1K56 f.| as-term-is RATRAT-1K1 -valuedRELAT-1V5"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be RATRAT-1K1 -valuedRELAT-1V5"
  proof-
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 ( |.VALUED-1K56 f.|) implies y inHIDDENR3 RATRAT-1K1"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 ( |.VALUED-1K56 f.|)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A1: "x inHIDDENR3 domRELAT-1K1 ( |.VALUED-1K56 f.|)"and A2: "( |.VALUED-1K56 f.|).FUNCT-1K1 x =HIDDENR1 y"
        using funct_1_def_3 sorry
      have "( |.VALUED-1K56 f.|).FUNCT-1K1 x =COMPLEX1R1  |.COMPLEX1K10 f .FUNCT-1K1 x.|"
        using A1 valued_1_def_11 sorry
      thus "y inHIDDENR3 RATRAT-1K1"
        using A2 rat_1_def_2 sorry
    qed "sorry"
    thus " |.VALUED-1K56 f.| be RATRAT-1K1 -valuedRELAT-1V5"
      using tarski_def_3 relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_99:
  mlet "f be INTINT-1K1 -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1"
"cluster  |.VALUED-1K56 f.| as-term-is natural-valuedVALUED-0V8"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be natural-valuedVALUED-0V8"
  proof-
    have " |.VALUED-1K56 f.| be natural-valuedVALUED-0V4"
    proof-
      have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 ( |.VALUED-1K56 f.|) &  not ( |.VALUED-1K56 f.|).FUNCT-1K1 x be naturalORDINAL1V7)"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have " |.INT-2K1 f .FUNCT-1K1 x.| be naturalORDINAL1V7"
           sorry
        thus " not (x inHIDDENR3 domRELAT-1K1 ( |.VALUED-1K56 f.|) &  not ( |.VALUED-1K56 f.|).FUNCT-1K1 x be naturalORDINAL1V7)"
          using valued_1_def_11 sorry
      qed "sorry"
      thus " |.VALUED-1K56 f.| be natural-valuedVALUED-0V4"
        using valued_0_def_12 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax VALUED_1K58 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" |.VALUED-1K58\<^bsub>'( _ , _ ')\<^esub>  _ .|" [0,0,0]164)
translations " |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_44:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "domRELAT-1K1 ( |.VALUED-1K56 f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngFUNCT-1K2 ( |.VALUED-1K56 f.|) c=MEMBEREDR3 REALNUMBERSK2"
      using valued_1_def_11 valued_0_def_3 sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K59 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-1K59\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-1K59\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_45:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
  proof-
    have "absVALUED-1K57 f =FUNCT-1R1  |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|"
       sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
       sorry
  qed
qed "sorry"

syntax VALUED_1K60 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" |.VALUED-1K60\<^bsub>'( _ , _ ')\<^esub>  _ .|" [0,0,0]164)
translations " |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_46:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|) c=MEMBEREDR3 RATRAT-1K1"
      using valued_1_def_11 relat_1_def_19 sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K61 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-1K61\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-1K61\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_47:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
  proof-
    have "absVALUED-1K59\<^bsub>(C,D)\<^esub> f =FUNCT-1R1  |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|"
       sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
       sorry
  qed
qed "sorry"

syntax VALUED_1K62 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" |.VALUED-1K62\<^bsub>'( _ , _ ')\<^esub>  _ .|" [0,0,0]164)
translations " |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.|" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_48:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(C)\<^esub> f & rngRELSET-1K2\<^bsub>(RATRAT-1K1)\<^esub> ( |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|) c=MEMBEREDR4 NATNUMBERSK1"
      using valued_1_def_11 valued_0_def_6 sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
      using relset_1_th_4 sorry
  qed
qed "sorry"

syntax VALUED_1K63 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("absVALUED-1K63\<^bsub>'( _ , _ ')\<^esub>  _ " [0,0,250]250)
translations "absVALUED-1K63\<^bsub>(C,D)\<^esub> f" \<rightharpoonup> " |.VALUED-1K56 f.|"

mtheorem valued_1_add_49:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(C,D)"
"cluster  |.VALUED-1K56 f.| as-term-is PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
  proof-
    have "absVALUED-1K61\<^bsub>(C,D)\<^esub> f =FUNCT-1R1  |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.|"
       sorry
    thus " |.VALUED-1K56 f.| be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_100:
  mlet "C be setHIDDENM2", "D be complex-memberedMEMBEREDV1\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster  |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.| as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds it =HIDDENR1  |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.| implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_11 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K58\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_101:
  mlet "C be setHIDDENM2", "D be rational-memberedMEMBEREDV4\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster  |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.| as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,RATRAT-1K1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds it =HIDDENR1  |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.| implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_11 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,RATRAT-1K1) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K60\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_102:
  mlet "C be setHIDDENM2", "D be integer-memberedMEMBEREDV5\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FunctionFUNCT-2M1-of(C,D)"
"cluster  |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.| as-term-is totalPARTFUN1V1\<^bsub>(C)\<^esub> for PartFuncPARTFUN1M1-of(C,NATNUMBERSK1)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds it =HIDDENR1  |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.| implies it be totalPARTFUN1V1\<^bsub>(C)\<^esub>"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
    proof-
      have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
        using valued_1_def_11 sorry
      also have "... = C"
        using funct_2_def_1 sorry
      finally have "domRELSET-1K1\<^bsub>(C)\<^esub> ( |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.|) =HIDDENR1 C"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(C,NATNUMBERSK1) holds  not (VarFor1 =HIDDENR1  |.VALUED-1K62\<^bsub>(C,D)\<^esub> f.| &  not VarFor1 be totalPARTFUN1V1\<^bsub>(C)\<^esub>)"
        using partfun1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_103:
  mlet "f be complex-valuedVALUED-0V5\<bar>FinSequenceFINSEQ-1M1"
"cluster  |.VALUED-1K56 f.| as-term-is FinSequence-likeFINSEQ-1V1"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be FinSequence-likeFINSEQ-1V1"
  proof-
    have "domRELAT-1K1 absVALUED-1K57 f =XBOOLE-0R4 domFINSEQ-1K5 f"
      using valued_1_def_11 sorry
    thus " |.VALUED-1K56 f.| be FinSequence-likeFINSEQ-1V1"
      using valued_1_lm_1 sorry
  qed
qed "sorry"

mtheorem valued_1_th_19:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds  for h be FunctionFUNCT-1M1 holds domRELAT-1K1 h =XBOOLE-0R4 domFINSEQ-1K5 f /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domFINSEQ-1K5 g implies h be FinSequenceFINSEQ-1M1"
  using valued_1_lm_2 sorry

(*begin*)
reserve m, j, p, q, n, l for "ElementSUBSET-1M1-of NATNUMBERSK1"
mdef valued_1_def_12 ("ShiftVALUED-1K64'( _ , _ ')" [0,0]164 ) where
  mlet "p be FunctionFUNCT-1M1", "k be NatNAT-1M1"
"func ShiftVALUED-1K64(p,k) \<rightarrow> FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies it .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies it .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)"
    proof-
      have " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies tVar6 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex m be NatNAT-1M1 st Lamb1 =HIDDENR1 m +XCMPLX-0K2 k & Lamb2 =HIDDENR1 p .FUNCT-1K1 m"
        let ?A = "{m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
        have A1: " for e be objectHIDDENM1 holds e inHIDDENR3 ?A implies ( ex u be objectHIDDENM1 st ?P(e,u))"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } implies ( ex tVar5 be objectHIDDENM1 st  ex mc be NatNAT-1M1 st e =HIDDENR1 mc +XCMPLX-0K2 k & tVar5 =HIDDENR1 p .FUNCT-1K1 mc)"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 ?A"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A2: "e =HIDDENR1 m +XCMPLX-0K2 k"and "m inTARSKIR2 domRELAT-1K1 p"
               sorry
            show " ex tVar5 be objectHIDDENM1 st  ex mc be NatNAT-1M1 st e =HIDDENR1 mc +XCMPLX-0K2 k & tVar5 =HIDDENR1 p .FUNCT-1K1 mc"
            proof(rule bexI[of _ "p .FUNCT-1K1 m"])
              show " ex mc be NatNAT-1M1 st e =HIDDENR1 mc +XCMPLX-0K2 k & p .FUNCT-1K1 m =HIDDENR1 p .FUNCT-1K1 mc"
                using A2 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A3: "domRELAT-1K1 f =XBOOLE-0R4 ?A"and A4: " for e be objectHIDDENM1 holds e inHIDDENR3 ?A implies ?P(e,f .FUNCT-1K1 e)"
          using classes1_sch_1 A1 sorry
        show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies tVar6 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI)
          show "domRELAT-1K1 f =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
            using A3 sorry
          fix m assume [ty]: "m be NatNAT-1M1"
          assume "m inTARSKIR2 domRELAT-1K1 p"
          then have "m +XCMPLX-0K2 k inTARSKIR2 ?A"
             sorry
          then have " ex j be NatNAT-1M1 st m +XCMPLX-0K2 k =COMPLEX1R1 j +XCMPLX-0K2 k & f .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 j"
            using A4 sorry
          thus "f .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-1M1 holds  for it2 be FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies it1 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)) & (domRELAT-1K1 it2 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies it2 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m)) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be FunctionFUNCT-1M1 holds  for IT2 be FunctionFUNCT-1M1 holds domRELAT-1K1 IT1 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & (( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies IT1 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m) & (domRELAT-1K1 IT2 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p } & ( for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies IT2 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m))) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be FunctionFUNCT-1M1"
        fix IT2 assume [ty]: "IT2 be FunctionFUNCT-1M1"
        assume A5: "domRELAT-1K1 IT1 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
          and A6: " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies IT1 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m"
          and A7: "domRELAT-1K1 IT2 =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
          and A8: " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 p implies IT2 .FUNCT-1K1 (m +XCMPLX-0K2 k) =XBOOLE-0R4 p .FUNCT-1K1 m"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT1 implies IT1 .FUNCT-1K1 x =XBOOLE-0R4 IT2 .FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT1 implies IT1 .FUNCT-1K1 x =HIDDENR1 IT2 .FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 IT1"
            then obtain m where
              [ty]:"m be NatNAT-1M1" and 
              A9: "x =HIDDENR1 m +XCMPLX-0K2 k & m inTARSKIR2 domRELAT-1K1 p"
              using A5 sorry
            have "IT1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 m"
              using A6 A9 sorry
            also have "... = IT2 .FUNCT-1K1 x"
              using A8 A9 sorry
            finally show "IT1 .FUNCT-1K1 x =HIDDENR1 IT2 .FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "IT1 =HIDDENR1 IT2"
          using A5 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem valued_1_cl_104:
  mlet "p be FunctionFUNCT-1M1", "k be NatNAT-1M1"
"cluster ShiftVALUED-1K64(p,k) as-term-is NATNUMBERSK1 -definedRELAT-1V4"
proof
(*coherence*)
  show "ShiftVALUED-1K64(p,k) be NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have A1: "domRELAT-1K1 (ShiftVALUED-1K64(p,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
      using valued_1_def_12 sorry
    have "ShiftVALUED-1K64(p,k) be NATNUMBERSK1 -definedRELAT-1V4"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(p,k)) implies x inHIDDENR3 NATNUMBERSK1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 (ShiftVALUED-1K64(p,k))"
        then have " ex m be NatNAT-1M1 st x =HIDDENR1 m +XCMPLX-0K2 k & m inTARSKIR2 domRELAT-1K1 p"
          using A1 sorry
        thus "x inHIDDENR3 NATNUMBERSK1"
          using ordinal1_def_12 sorry
      qed "sorry"
      thus "ShiftVALUED-1K64(p,k) be NATNUMBERSK1 -definedRELAT-1V4"
        using tarski_def_3 relat_1_def_18 sorry
    qed
    thus "ShiftVALUED-1K64(p,k) be NATNUMBERSK1 -definedRELAT-1V4"
       sorry
  qed
qed "sorry"

mtheorem valued_1_th_20:
" for P be FunctionFUNCT-1M1 holds  for Q be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds P c=RELAT-1R2 Q implies ShiftVALUED-1K64(P,k) c=RELAT-1R2 ShiftVALUED-1K64(Q,k)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix P assume [ty]: "P be FunctionFUNCT-1M1"
  fix Q assume [ty]: "Q be FunctionFUNCT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  assume A1: "P c=RELAT-1R2 Q"
  then have A2: "domRELAT-1K1 P c=TARSKIR1 domRELAT-1K1 Q"
    using grfunc_1_th_2 sorry
  have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(P,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 P }"
    using valued_1_def_12 sorry
  have A4: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(Q,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 Q }"
    using valued_1_def_12 sorry
  have A5: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(P,k)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(Q,k))"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(P,k))"
    then have " ex m1 be NatNAT-1M1 st x =HIDDENR1 m1 +XCMPLX-0K2 k & m1 inTARSKIR2 domRELAT-1K1 P"
      using A3 sorry
    thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(Q,k))"
      using A2 A4 sorry
  qed "sorry"
  have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(P,k)) implies (ShiftVALUED-1K64(P,k)).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(Q,k)).FUNCT-1K1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(P,k))"
    then obtain m1 where
      [ty]:"m1 be NatNAT-1M1" and 
      A6: "x =HIDDENR1 m1 +XCMPLX-0K2 k"and A7: "m1 inTARSKIR2 domRELAT-1K1 P"
      using A3 sorry
    have "(ShiftVALUED-1K64(P,k)).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(P,k)).FUNCT-1K1 (m1 +XCMPLX-0K2 k)"
      using A6 sorry
    also have "... = P .FUNCT-1K1 m1"
      using A7 valued_1_def_12 sorry
    also have "... = Q .FUNCT-1K1 m1"
      using A1 A7 grfunc_1_th_2 sorry
    also have "... = (ShiftVALUED-1K64(Q,k)).FUNCT-1K1 (m1 +XCMPLX-0K2 k)"
      using A2 A7 valued_1_def_12 sorry
    also have "... = (ShiftVALUED-1K64(Q,k)).FUNCT-1K1 x"
      using A6 sorry
    finally show "(ShiftVALUED-1K64(P,k)).FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(Q,k)).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus "ShiftVALUED-1K64(P,k) c=RELAT-1R2 ShiftVALUED-1K64(Q,k)"
    using A5 grfunc_1_th_2 tarski_def_3 sorry
qed "sorry"

mtheorem valued_1_th_21:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for I be FunctionFUNCT-1M1 holds ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n) =FUNCT-1R1 ShiftVALUED-1K64(I,m +XCMPLX-0K2 n)"
proof(rule ballI,rule ballI,rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix I assume [ty]: "I be FunctionFUNCT-1M1"
  let ?A = "{l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I }"
  have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,m)) =XBOOLE-0R4 ?A"
    using valued_1_def_12 sorry
  have A2: " for l be NatNAT-1M1 holds l inTARSKIR2 domRELAT-1K1 I implies (ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n)).FUNCT-1K1 (l +XCMPLX-0K2 (m +XCMPLX-0K2 n)) =HIDDENR1 I .FUNCT-1K1 l"
  proof(rule ballI,rule impI)
    fix l assume [ty]: "l be NatNAT-1M1"
    assume A3: "l inTARSKIR2 domRELAT-1K1 I"
    then have A4: "l +XCMPLX-0K2 m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,m))"
      using A1 sorry
    have "(ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n)).FUNCT-1K1 (l +XCMPLX-0K2 (m +XCMPLX-0K2 n)) =HIDDENR1 (ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n)).FUNCT-1K1 ((l +XCMPLX-0K2 m)+XCMPLX-0K2 n)"
       sorry
    also have "... = (ShiftVALUED-1K64(I,m)).FUNCT-1K1 (l +XCMPLX-0K2 m)"
      using A4 valued_1_def_12 sorry
    also have "... = I .FUNCT-1K1 l"
      using A3 valued_1_def_12 sorry
    finally show "(ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n)).FUNCT-1K1 (l +XCMPLX-0K2 (m +XCMPLX-0K2 n)) =HIDDENR1 I .FUNCT-1K1 l"
       sorry
  qed "sorry"
  have "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 ?A } =XBOOLE-0R4 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
  proof-
    have "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } =XBOOLE-0R4 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
    proof-
      have "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } c=TARSKIR1 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I } & {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I } c=TARSKIR1 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } }"
      proof(rule conjMI)
        show "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } c=TARSKIR1 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } implies x inHIDDENR3 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 ?A }"
            then obtain p where
              [ty]:"p be NatNAT-1M1" and 
              A5: "x =HIDDENR1 p +XCMPLX-0K2 n"and A6: "p inTARSKIR2 ?A"
               sorry
            obtain l where
              [ty]:"l be NatNAT-1M1" and 
              A7: "p =COMPLEX1R1 l +XCMPLX-0K2 m"and A8: "l inTARSKIR2 domRELAT-1K1 I"
              using A6 sorry
            have "x =HIDDENR1 l +XCMPLX-0K2 (m +XCMPLX-0K2 n)"
              using A5 A7 sorry
            thus "x inHIDDENR3 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
              using A8 sorry
          qed "sorry"
          thus "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } c=TARSKIR1 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I } implies x inHIDDENR3 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
          then obtain q where
            [ty]:"q be NatNAT-1M1" and 
            A9: "x =HIDDENR1 q +XCMPLX-0K2 (m +XCMPLX-0K2 n) & q inTARSKIR2 domRELAT-1K1 I"
             sorry
          have "x =HIDDENR1 (q +XCMPLX-0K2 m)+XCMPLX-0K2 n & q +XCMPLX-0K2 m inTARSKIR2 ?A"
            using A9 sorry
          thus "x inHIDDENR3 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } }"
             sorry
        qed "sorry"
        thus "{q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I } c=TARSKIR1 {p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } }"
          using tarski_def_3 sorry
      qed
      thus "{p +XCMPLX-0K2 n where p be NatNAT-1M1 : p inTARSKIR2 {l +XCMPLX-0K2 m where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I } } =XBOOLE-0R4 {q +XCMPLX-0K2 (m +XCMPLX-0K2 n) where q be NatNAT-1M1 : q inTARSKIR2 domRELAT-1K1 I }"
        using xboole_0_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n)) =XBOOLE-0R4 {l +XCMPLX-0K2 (m +XCMPLX-0K2 n) where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I }"
    using A1 valued_1_def_12 sorry
  thus "ShiftVALUED-1K64(ShiftVALUED-1K64(I,m),n) =FUNCT-1R1 ShiftVALUED-1K64(I,m +XCMPLX-0K2 n)"
    using A2 valued_1_def_12 sorry
qed "sorry"

mtheorem valued_1_th_22:
" for s be FunctionFUNCT-1M1 holds  for f be FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(f *FUNCT-1K3 s,n) =FUNCT-1R1 f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))"
proof(rule ballI,rule ballI,rule ballI)
  fix s assume [ty]: "s be FunctionFUNCT-1M1"
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  have A1: "domRELAT-1K1 (f *FUNCT-1K3 s) c=TARSKIR1 domRELAT-1K1 s"
    using relat_1_th_25 sorry
  have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 s }"
    using valued_1_def_12 sorry
  have " for e be objectHIDDENM1 holds (e inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) } implies e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n)) & (ShiftVALUED-1K64(s,n)).FUNCT-1K1 e inTARSKIR2 domRELAT-1K1 f) & (e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n)) implies ((ShiftVALUED-1K64(s,n)).FUNCT-1K1 e inTARSKIR2 domRELAT-1K1 f implies e inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) }))"
  proof(rule ballI,rule conjMI,rule impI,rule impI)
    fix e assume [ty]: "e be objectHIDDENM1"
    show "e inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) } implies e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n)) & (ShiftVALUED-1K64(s,n)).FUNCT-1K1 e inTARSKIR2 domRELAT-1K1 f"
    proof(rule impI,rule conjMI)
      assume "e inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) }"
      then obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A3: "e =HIDDENR1 m +XCMPLX-0K2 n"and A4: "m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s)"
         sorry
      show "e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n))"
        using A2 A1 A3 A4 sorry
      have "(ShiftVALUED-1K64(s,n)).FUNCT-1K1 e =XBOOLE-0R4 s .FUNCT-1K1 m"
        using A1 A3 A4 valued_1_def_12 sorry
      thus "(ShiftVALUED-1K64(s,n)).FUNCT-1K1 e inTARSKIR2 domRELAT-1K1 f"
        using A4 funct_1_th_11 sorry
    qed
    assume "e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n))"
    then obtain m0 where
      [ty]:"m0 be NatNAT-1M1" and 
      A5: "e =HIDDENR1 m0 +XCMPLX-0K2 n"and A6: "m0 inTARSKIR2 domRELAT-1K1 s"
      using A2 sorry
    assume "(ShiftVALUED-1K64(s,n)).FUNCT-1K1 e inTARSKIR2 domRELAT-1K1 f"
    then have "s .FUNCT-1K1 m0 inTARSKIR2 domRELAT-1K1 f"
      using A5 A6 valued_1_def_12 sorry
    then have "m0 inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s)"
      using A6 funct_1_th_11 sorry
    thus "e inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) }"
      using A5 sorry
  qed "sorry"
  then have "(ShiftVALUED-1K64(s,n))\<inverse>FUNCT-1K6 (domRELAT-1K1 f) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) }"
    using funct_1_def_7 sorry
  then have A7: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) }"
    using relat_1_th_147 sorry
  have " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) implies (f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (f *FUNCT-1K3 s).FUNCT-1K1 m"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A8: "m inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s)"
    then have "m +XCMPLX-0K2 n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(s,n))"
      using A2 A1 sorry
    then have "(f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 f .FUNCT-1K1 ((ShiftVALUED-1K64(s,n)).FUNCT-1K1 (m +XCMPLX-0K2 n))"
      using funct_1_th_13 sorry
    also have "... = f .FUNCT-1K1 (s .FUNCT-1K1 m)"
      using A1 A8 valued_1_def_12 sorry
    also have "... = (f *FUNCT-1K3 s).FUNCT-1K1 m"
      using A8 funct_1_th_12 sorry
    finally show "(f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (f *FUNCT-1K3 s).FUNCT-1K1 m"
       sorry
  qed "sorry"
  thus "ShiftVALUED-1K64(f *FUNCT-1K3 s,n) =FUNCT-1R1 f *FUNCT-1K3 (ShiftVALUED-1K64(s,n))"
    using A7 valued_1_def_12 sorry
qed "sorry"

mtheorem valued_1_th_23:
" for I be FunctionFUNCT-1M1 holds  for J be FunctionFUNCT-1M1 holds  for n be NatNAT-1M1 holds ShiftVALUED-1K64(I +*FUNCT-4K1 J,n) =FUNCT-1R1 (ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))"
proof(rule ballI,rule ballI,rule ballI)
  fix I assume [ty]: "I be FunctionFUNCT-1M1"
  fix J assume [ty]: "J be FunctionFUNCT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 J }"
    using valued_1_def_12 sorry
  have A2: " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 (I +*FUNCT-4K1 J) implies ((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
  proof(rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    assume A3: "m inTARSKIR2 domRELAT-1K1 (I +*FUNCT-4K1 J)"
    show "((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
    proof-
      have cases: "m inTARSKIR2 domRELAT-1K1 J or  not m inTARSKIR2 domRELAT-1K1 J"
         sorry
      have case1: "m inTARSKIR2 domRELAT-1K1 J implies ((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
      proof(rule impI)
        assume A4: "m inTARSKIR2 domRELAT-1K1 J"
        then have "m +XCMPLX-0K2 n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
          using A1 sorry
        then have "((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (ShiftVALUED-1K64(J,n)).FUNCT-1K1 (m +XCMPLX-0K2 n)"
          using funct_4_th_13 sorry
        also have "... = J .FUNCT-1K1 m"
          using A4 valued_1_def_12 sorry
        also have "... = (I +*FUNCT-4K1 J).FUNCT-1K1 m"
          using A4 funct_4_th_13 sorry
        finally show "((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
           sorry
      qed
      have case2: " not m inTARSKIR2 domRELAT-1K1 J implies ((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
      proof(rule impI)
        assume A5: " not m inTARSKIR2 domRELAT-1K1 J"
        have "m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J"
          using A3 funct_4_def_1 sorry
        then have A6: "m inTARSKIR2 domRELAT-1K1 I"
          using A5 xboole_0_def_3 sorry
        have " not ( ex l be NatNAT-1M1 st m +XCMPLX-0K2 n =COMPLEX1R1 l +XCMPLX-0K2 n & l inTARSKIR2 domRELAT-1K1 J)"
          using A5 sorry
        then have " not m +XCMPLX-0K2 n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
          using A1 sorry
        then have "((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (ShiftVALUED-1K64(I,n)).FUNCT-1K1 (m +XCMPLX-0K2 n)"
          using funct_4_th_11 sorry
        also have "... = I .FUNCT-1K1 m"
          using A6 valued_1_def_12 sorry
        also have "... = (I +*FUNCT-4K1 J).FUNCT-1K1 m"
          using A5 funct_4_th_11 sorry
        finally show "((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))).FUNCT-1K1 (m +XCMPLX-0K2 n) =HIDDENR1 (I +*FUNCT-4K1 J).FUNCT-1K1 m"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  have A7: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I }"
    using valued_1_def_12 sorry
  have A8: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }"
  proof-
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n)) implies x inHIDDENR3 {l +XCMPLX-0K2 n where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }) & {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n)) implies x inHIDDENR3 {l +XCMPLX-0K2 n where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) or x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
          using xboole_0_def_3 sorry
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A9: "x =HIDDENR1 m +XCMPLX-0K2 n & m inTARSKIR2 domRELAT-1K1 J or x =HIDDENR1 m +XCMPLX-0K2 n & m inTARSKIR2 domRELAT-1K1 I"
          using A1 A7 sorry
        have "m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J"
          using A9 xboole_0_def_3 sorry
        thus "x inHIDDENR3 {l +XCMPLX-0K2 n where l be NatNAT-1M1 : l inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }"
          using A9 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J } implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A10: "x =HIDDENR1 m +XCMPLX-0K2 n"and A11: "m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J"
           sorry
        have "m inTARSKIR2 domRELAT-1K1 I or m inTARSKIR2 domRELAT-1K1 J"
          using A11 xboole_0_def_3 sorry
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) or x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
          using A1 A7 A10 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
          using xboole_0_def_3 sorry
      qed "sorry"
      thus "{m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n))"
        using tarski_def_3 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(I,n)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(J,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J }"
      using tarski_def_3 xboole_0_def_10 sorry
  qed
  have "domRELAT-1K1 (I +*FUNCT-4K1 J) =XBOOLE-0R4 domRELAT-1K1 I \\/XBOOLE-0K2 domRELAT-1K1 J"
    using funct_4_def_1 sorry
  then have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ((ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (I +*FUNCT-4K1 J) }"
    using A8 funct_4_def_1 sorry
  thus "ShiftVALUED-1K64(I +*FUNCT-4K1 J,n) =FUNCT-1R1 (ShiftVALUED-1K64(I,n))+*FUNCT-4K1 (ShiftVALUED-1K64(J,n))"
    using A2 valued_1_def_12 sorry
qed "sorry"

mtheorem valued_1_th_24:
" for p be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds  for il be NatNAT-1M1 holds il inTARSKIR2 domRELAT-1K1 p implies il +XCMPLX-0K2 k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k))"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix p assume [ty]: "p be FunctionFUNCT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  fix il assume [ty]: "il be NatNAT-1M1"
  assume A1: "il inTARSKIR2 domRELAT-1K1 p"
  have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) =XBOOLE-0R4 {loc +XCMPLX-0K2 k where loc be NatNAT-1M1 : loc inTARSKIR2 domRELAT-1K1 p }"
    using valued_1_def_12 sorry
  thus "il +XCMPLX-0K2 k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k))"
    using A1 sorry
qed "sorry"

mtheorem valued_1_th_25:
" for p be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) c=TARSKIR1 rngFUNCT-1K2 p"
proof(rule ballI,rule ballI)
  fix p assume [ty]: "p be FunctionFUNCT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) implies y inHIDDENR3 rngFUNCT-1K2 p"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "y inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k))"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k))"and A2: "y =HIDDENR1 (ShiftVALUED-1K64(p,k)).FUNCT-1K1 x"
      using funct_1_def_3 sorry
    have "x inHIDDENR3 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 p }"
      using A1 valued_1_def_12 sorry
    then obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "x =HIDDENR1 m +XCMPLX-0K2 k"and A4: "m inTARSKIR2 domRELAT-1K1 p"
       sorry
    have "p .FUNCT-1K1 m =XBOOLE-0R4 (ShiftVALUED-1K64(p,k)).FUNCT-1K1 x"
      using A3 A4 valued_1_def_12 sorry
    thus "y inHIDDENR3 rngFUNCT-1K2 p"
      using A2 A4 funct_1_def_3 sorry
  qed "sorry"
  thus "rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) c=TARSKIR1 rngFUNCT-1K2 p"
    using tarski_def_3 sorry
qed "sorry"

mtheorem valued_1_th_26:
" for p be FunctionFUNCT-1M1 holds domRELAT-1K1 p c=TARSKIR1 NATNUMBERSK1 implies ( for k be NatNAT-1M1 holds rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) =XBOOLE-0R4 rngFUNCT-1K2 p)"
proof(rule ballI,rule impI,rule ballI)
  fix p assume [ty]: "p be FunctionFUNCT-1M1"
  assume A1: "domRELAT-1K1 p c=TARSKIR1 NATNUMBERSK1"
  fix k assume [ty]: "k be NatNAT-1M1"
  have "rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) c=TARSKIR1 rngFUNCT-1K2 p & rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k))"
  proof(rule conjMI)
    show "rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) c=TARSKIR1 rngFUNCT-1K2 p"
      using valued_1_th_25 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 p implies y inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k))"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 p"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "x inHIDDENR3 domRELAT-1K1 p"and A3: "y =HIDDENR1 p .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have 
        [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A1 A2 sorry
      have "x +XCMPLX-0K2 k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) & (ShiftVALUED-1K64(p,k)).FUNCT-1K1 (x +XCMPLX-0K2 k) =HIDDENR1 y"
        using A2 A3 valued_1_def_12 valued_1_th_24 sorry
      thus "y inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k))"
        using funct_1_def_3 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 p c=TARSKIR1 rngFUNCT-1K2 (ShiftVALUED-1K64(p,k))"
      using tarski_def_3 sorry
  qed
  thus "rngFUNCT-1K2 (ShiftVALUED-1K64(p,k)) =XBOOLE-0R4 rngFUNCT-1K2 p"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem valued_1_cl_105:
  mlet "p be finiteFINSET-1V1\<bar>FunctionFUNCT-1M1", "k be NatNAT-1M1"
"cluster ShiftVALUED-1K64(p,k) as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "ShiftVALUED-1K64(p,k) be finiteFINSET-1V1"
  proof-
    let ?F = "\<lambda>Lamb1. Lamb1 +XCMPLX-0K2 k"
    have A1: "domRELAT-1K1 p be finiteFINSET-1V1"
       sorry
    have A2: "{?F(w) where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p } be finiteFINSET-1V1"
      using fraenkel_sch_21 A1 sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) c=MEMBEREDR6 {?F(w) where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p }"
    proof-
      have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) c=MEMBEREDR6 {w +XCMPLX-0K2 k where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p }"
      proof-
        have " for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) implies e inHIDDENR3 {w +XCMPLX-0K2 k where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p }"
        proof(rule ballI,rule impI)
          fix e assume [ty]: "e be objectHIDDENM1"
          assume "e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k))"
          then have "e inHIDDENR3 {?F(i) where i be NatNAT-1M1 : i inTARSKIR2 domRELAT-1K1 p }"
            using valued_1_def_12 sorry
          then obtain i where
            [ty]:"i be NatNAT-1M1" and 
            A3: "e =HIDDENR1 ?F(i) & i inTARSKIR2 domRELAT-1K1 p"
             sorry
          have 
            [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "e =HIDDENR1 ?F(i) & i inTARSKIR2 domRELAT-1K1 p"
            using A3 sorry
          thus "e inHIDDENR3 {w +XCMPLX-0K2 k where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p }"
             sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,k)) c=MEMBEREDR6 {?F(w) where w be ElementSUBSET-1M1-of NATNUMBERSK1 : w inTARSKIR2 domRELAT-1K1 p }"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "ShiftVALUED-1K64(p,k) be finiteFINSET-1V1"
      using A2 finset_1_th_10 sorry
  qed
qed "sorry"

reserve e1, e2 for "ExtRealXXREAL-0M1"
syntax VALUED_1V1 :: " Set \<Rightarrow> Ty" ("increasingVALUED-1V1\<^bsub>'( _ ')\<^esub>" [0]70)
translations "increasingVALUED-1V1\<^bsub>(X)\<^esub>" \<rightharpoonup> "increasingVALUED-0V9"

mtheorem valued_1_def_13:
  mlet "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"redefine attr increasingVALUED-1V1\<^bsub>(X)\<^esub> for sequenceNAT-1M2-of X means
  (\<lambda>s.  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for s be sequenceNAT-1M2-of X holds s be increasingVALUED-1V1\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    show "s be increasingVALUED-1V1\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have "(s be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) & (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies s be increasingVALUED-0V9)"
      proof(rule conjMI,rule impI)
        show "s be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        proof-
          have "s be increasingVALUED-0V9 implies ( for n be NatNAT-1M1 holds  not s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI,rule ballI)
            assume A1: "s be increasingVALUED-0V9"
            fix n assume [ty]: "n be NatNAT-1M1"
            have A2: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s =MEMBEREDR12 NATNUMBERSK1 & n inTARSKIR2 NATNUMBERSK1"
              using funct_2_def_1 ordinal1_def_12 sorry
            thus " not s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using A1 A2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        assume A3: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s implies (e1 <XXREAL-0R3 e2 implies  not s .FUNCT-1K1 e2 <=XXREAL-0R1 s .FUNCT-1K1 e1)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s"
          then obtain m n where 
            [ty]:"m be NatNAT-1M1" and mDef:"m = e1" and
            [ty]:"n be NatNAT-1M1" and nDef:"n = e2"
             sorry
          let ?P = "\<lambda>Lamb1. m <XXREAL-0R3 Lamb1 implies s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> Lamb1"
          have A4: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for j be NatNAT-1M1 holds (m <XXREAL-0R3 j implies s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> j) implies (m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M implies  not s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M))"
            proof(rule ballI,rule impI,rule impI)
              fix j assume [ty]: "j be NatNAT-1M1"
              assume A5: "?P(j)"
              assume "m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M"
              then have "m <=XXREAL-0R1 j"
                using nat_1_th_13 sorry
              then have "s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> j or m =COMPLEX1R1 j"
                using A5 xxreal_0_th_1 sorry
              thus " not s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A3 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          assume A6: "e1 <XXREAL-0R3 e2"
          have A7: "?P(0NUMBERSK6)"
             sorry
          have " for j be NatNAT-1M1 holds ?P(j)"
            using nat_1_sch_2 A7 A4 sorry
          then have "s .NAT-1K8\<^bsub>(X)\<^esub> m <XXREAL-0R3 s .NAT-1K8\<^bsub>(X)\<^esub> n"
            using A6 sorry
          thus " not s .FUNCT-1K1 e2 <=XXREAL-0R1 s .FUNCT-1K1 e1"
             sorry
        qed "sorry"
        thus "s be increasingVALUED-0V9"
          using valued_0_def_13 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

syntax VALUED_1V2 :: " Set \<Rightarrow> Ty" ("decreasingVALUED-1V2\<^bsub>'( _ ')\<^esub>" [0]70)
translations "decreasingVALUED-1V2\<^bsub>(X)\<^esub>" \<rightharpoonup> "decreasingVALUED-0V10"

mtheorem valued_1_def_14:
  mlet "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"redefine attr decreasingVALUED-1V2\<^bsub>(X)\<^esub> for sequenceNAT-1M2-of X means
  (\<lambda>s.  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for s be sequenceNAT-1M2-of X holds s be decreasingVALUED-1V2\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    show "s be decreasingVALUED-1V2\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have "(s be decreasingVALUED-0V10 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) & (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies s be decreasingVALUED-0V10)"
      proof(rule conjMI,rule impI)
        show "s be decreasingVALUED-0V10 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        proof-
          have "s be decreasingVALUED-0V10 implies ( for n be NatNAT-1M1 holds  not s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          proof(rule impI,rule ballI)
            assume A8: "s be decreasingVALUED-0V10"
            fix n assume [ty]: "n be NatNAT-1M1"
            have A9: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s =MEMBEREDR12 NATNUMBERSK1 & n inTARSKIR2 NATNUMBERSK1"
              using funct_2_def_1 ordinal1_def_12 sorry
            thus " not s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using A8 A9 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        assume A10: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s implies (e1 <XXREAL-0R3 e2 implies  not s .FUNCT-1K1 e1 <=XXREAL-0R1 s .FUNCT-1K1 e2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s"
          then obtain m n where 
            [ty]:"m be NatNAT-1M1" and mDef:"m = e1" and
            [ty]:"n be NatNAT-1M1" and nDef:"n = e2"
             sorry
          let ?P = "\<lambda>Lamb1. m <XXREAL-0R3 Lamb1 implies s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> Lamb1"
          have A11: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for j be NatNAT-1M1 holds (m <XXREAL-0R3 j implies s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> j) implies (m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M implies  not s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M))"
            proof(rule ballI,rule impI,rule impI)
              fix j assume [ty]: "j be NatNAT-1M1"
              assume A12: "?P(j)"
              assume "m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M"
              then have "m <=XXREAL-0R1 j"
                using nat_1_th_13 sorry
              then have "s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> j or m =COMPLEX1R1 j"
                using A12 xxreal_0_th_1 sorry
              thus " not s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A10 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          assume A13: "e1 <XXREAL-0R3 e2"
          have A14: "?P(0NUMBERSK6)"
             sorry
          have " for j be NatNAT-1M1 holds ?P(j)"
            using nat_1_sch_2 A14 A11 sorry
          then have "s .NAT-1K8\<^bsub>(X)\<^esub> m >XXREAL-0R4 s .NAT-1K8\<^bsub>(X)\<^esub> n"
            using A13 sorry
          thus " not s .FUNCT-1K1 e1 <=XXREAL-0R1 s .FUNCT-1K1 e2"
             sorry
        qed "sorry"
        thus "s be decreasingVALUED-0V10"
          using valued_0_def_14 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

syntax VALUED_1V3 :: " Set \<Rightarrow> Ty" ("non-decreasingVALUED-1V3\<^bsub>'( _ ')\<^esub>" [0]70)
translations "non-decreasingVALUED-1V3\<^bsub>(X)\<^esub>" \<rightharpoonup> "non-decreasingVALUED-0V11"

mtheorem valued_1_def_15:
  mlet "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"redefine attr non-decreasingVALUED-1V3\<^bsub>(X)\<^esub> for sequenceNAT-1M2-of X means
  (\<lambda>s.  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for s be sequenceNAT-1M2-of X holds s be non-decreasingVALUED-1V3\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    show "s be non-decreasingVALUED-1V3\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have "(s be non-decreasingVALUED-0V11 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) & (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies s be non-decreasingVALUED-0V11)"
      proof(rule conjMI,rule impI)
        show "s be non-decreasingVALUED-0V11 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule impI,rule ballI)
          assume A15: "s be non-decreasingVALUED-0V11"
          fix n assume [ty]: "n be NatNAT-1M1"
          have A16: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_13 sorry
          have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s =MEMBEREDR12 NATNUMBERSK1 & n inTARSKIR2 NATNUMBERSK1"
            using funct_2_def_1 ordinal1_def_12 sorry
          thus "s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using A15 A16 sorry
        qed "sorry"
        assume A17: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s implies (e1 <=XXREAL-0R1 e2 implies s .FUNCT-1K1 e1 <=XXREAL-0R1 s .FUNCT-1K1 e2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s"
          then obtain m n where 
            [ty]:"m be NatNAT-1M1" and mDef:"m = e1" and
            [ty]:"n be NatNAT-1M1" and nDef:"n = e2"
             sorry
          let ?P = "\<lambda>Lamb1. m <=XXREAL-0R1 Lamb1 implies s .NAT-1K8\<^bsub>(X)\<^esub> m <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> Lamb1"
          have A18: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for j be NatNAT-1M1 holds (m <=XXREAL-0R1 j implies s .NAT-1K8\<^bsub>(X)\<^esub> m <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> j) implies (m <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(X)\<^esub> m <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M))"
            proof(rule ballI,rule impI,rule impI)
              fix j assume [ty]: "j be NatNAT-1M1"
              assume A19: "?P(j)"
              assume "m <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
              then have A20: "m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M or m =COMPLEX1R1 j +NAT-1K1 \<one>\<^sub>M"
                using xxreal_0_th_1 sorry
              have "s .NAT-1K8\<^bsub>(X)\<^esub> j <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A17 sorry
              thus "s .NAT-1K8\<^bsub>(X)\<^esub> m <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A19 A20 nat_1_th_13 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          assume A21: "e1 <=XXREAL-0R1 e2"
          have A22: "?P(0NUMBERSK6)"
             sorry
          have " for j be NatNAT-1M1 holds ?P(j)"
            using nat_1_sch_2 A22 A18 sorry
          then have "s .NAT-1K8\<^bsub>(X)\<^esub> m <=XXREAL-0R1 s .NAT-1K8\<^bsub>(X)\<^esub> n"
            using A21 sorry
          thus "s .FUNCT-1K1 e1 <=XXREAL-0R1 s .FUNCT-1K1 e2"
             sorry
        qed "sorry"
        thus "s be non-decreasingVALUED-0V11"
          using valued_0_def_15 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

syntax VALUED_1V4 :: " Set \<Rightarrow> Ty" ("non-increasingVALUED-1V4\<^bsub>'( _ ')\<^esub>" [0]70)
translations "non-increasingVALUED-1V4\<^bsub>(X)\<^esub>" \<rightharpoonup> "non-increasingVALUED-0V12"

mtheorem valued_1_def_16:
  mlet "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "s be sequenceNAT-1M2-of X"
"redefine attr non-increasingVALUED-1V4\<^bsub>(X)\<^esub> for sequenceNAT-1M2-of X means
  (\<lambda>s.  for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
proof
(*compatibility*)
  show " for s be sequenceNAT-1M2-of X holds s be non-increasingVALUED-1V4\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix s assume [ty]: "s be sequenceNAT-1M2-of X"
    show "s be non-increasingVALUED-1V4\<^bsub>(X)\<^esub> iff ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
    proof-
      have "(s be non-increasingVALUED-0V12 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) & (( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) implies s be non-increasingVALUED-0V12)"
      proof(rule conjMI,rule impI)
        show "s be non-increasingVALUED-0V12 implies ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule impI,rule ballI)
          assume A23: "s be non-increasingVALUED-0V12"
          fix n assume [ty]: "n be NatNAT-1M1"
          have A24: "n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using nat_1_th_13 sorry
          have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s =MEMBEREDR12 NATNUMBERSK1 & n inTARSKIR2 NATNUMBERSK1"
            using funct_2_def_1 ordinal1_def_12 sorry
          thus "s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            using A23 A24 sorry
        qed "sorry"
        assume A25: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(X)\<^esub> n >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        have " for e1 be ExtRealXXREAL-0M1 holds  for e2 be ExtRealXXREAL-0M1 holds e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s implies (e1 <=XXREAL-0R1 e2 implies s .FUNCT-1K1 e2 <=XXREAL-0R1 s .FUNCT-1K1 e1)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix e1 assume [ty]: "e1 be ExtRealXXREAL-0M1"
          fix e2 assume [ty]: "e2 be ExtRealXXREAL-0M1"
          assume "e1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s & e2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> s"
          then obtain m n where 
            [ty]:"m be NatNAT-1M1" and mDef:"m = e1" and
            [ty]:"n be NatNAT-1M1" and nDef:"n = e2"
             sorry
          let ?P = "\<lambda>Lamb1. m <=XXREAL-0R1 Lamb1 implies s .NAT-1K8\<^bsub>(X)\<^esub> m >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> Lamb1"
          have A26: " for j be NatNAT-1M1 holds ?P(j) implies ?P(j +NAT-1K1 \<one>\<^sub>M)"
          proof-
            have " for j be NatNAT-1M1 holds (m <=XXREAL-0R1 j implies s .NAT-1K8\<^bsub>(X)\<^esub> m >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> j) implies (m <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(X)\<^esub> m >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M))"
            proof(rule ballI,rule impI,rule impI)
              fix j assume [ty]: "j be NatNAT-1M1"
              assume A27: "?P(j)"
              assume "m <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M"
              then have A28: "m <XXREAL-0R3 j +NAT-1K1 \<one>\<^sub>M or m =COMPLEX1R1 j +NAT-1K1 \<one>\<^sub>M"
                using xxreal_0_th_1 sorry
              have "s .NAT-1K8\<^bsub>(X)\<^esub> j >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A25 sorry
              thus "s .NAT-1K8\<^bsub>(X)\<^esub> m >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
                using A27 A28 nat_1_th_13 xxreal_0_th_2 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          assume A29: "e1 <=XXREAL-0R1 e2"
          have A30: "?P(0NUMBERSK6)"
             sorry
          have " for j be NatNAT-1M1 holds ?P(j)"
            using nat_1_sch_2 A30 A26 sorry
          then have "s .NAT-1K8\<^bsub>(X)\<^esub> m >=XXREAL-0R2 s .NAT-1K8\<^bsub>(X)\<^esub> n"
            using A29 sorry
          thus "s .FUNCT-1K1 e2 <=XXREAL-0R1 s .FUNCT-1K1 e1"
             sorry
        qed "sorry"
        thus "s be non-increasingVALUED-0V12"
          using valued_0_def_16 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

theorem valued_1_sch_1:
  fixes Xf0 Sf0 Pp1 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Sf0 be sequenceNAT-1M2-of Xf0" and
   A1: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> m)"
  shows " ex S1 be subsequenceVALUED-0M2\<^bsub>(Xf0)\<^esub>-of Sf0 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
  proof-
    have " ex tVar9 be subsequenceVALUED-0M2\<^bsub>(Xf0)\<^esub>-of Sf0 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp1(tVar9 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
    proof-
      let ?P1 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds m =XBOOLE-0R4 Lamb2 & k =XBOOLE-0R4 Lamb3 implies m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k))"
      obtain n0 where
        [ty]:"n0 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        "0NUMBERSK6 <=XXREAL-0R1 n0"and A2: "Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> n0)"
        using A1 sorry
      have A3: " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex y be setHIDDENM2 st ?P1(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be setHIDDENM2 holds  ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((m =XBOOLE-0R4 x & k =XBOOLE-0R4 tVar7) &  not ( not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k))))"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be setHIDDENM2"
          show " ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((m =XBOOLE-0R4 x & k =XBOOLE-0R4 tVar7) &  not ( not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k))))"
          proof-
            have cases: "x inTARSKIR2 NATNUMBERSK1 or  not x inTARSKIR2 NATNUMBERSK1"
               sorry
            have case1: "x inTARSKIR2 NATNUMBERSK1 implies ( ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((m =XBOOLE-0R4 x & k =XBOOLE-0R4 tVar7) &  not ( not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)))))"
            proof(rule impI)
              assume "x inTARSKIR2 NATNUMBERSK1"
              then obtain mx where 
                [ty]:"mx be ElementSUBSET-1M1-of NATNUMBERSK1" and mxDef:"mx = x"
                 sorry
              obtain my where
                [ty]:"my be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A4: "mx +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 my & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> my)"
                using A1 sorry
              show " ex tVar7 be setHIDDENM2 st tVar7 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((m =XBOOLE-0R4 x & k =XBOOLE-0R4 tVar7) &  not ( not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k))))"
              proof(rule bexI[of _ "my"],rule conjMI)
                show "my inTARSKIR2 NATNUMBERSK1"
                   sorry
                show " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ((m =XBOOLE-0R4 x & k =XBOOLE-0R4 my) &  not ( not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)))"
                  using A4 nat_1_th_13 sorry
              qed "sorry"
            qed
            have case2: " not x inTARSKIR2 NATNUMBERSK1 implies ( ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds m =XBOOLE-0R4 x & k =COMPLEX1R1 tVar8 implies  not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)))"
            proof(rule impI)
              assume A5: " not x inTARSKIR2 NATNUMBERSK1"
              show " ex tVar8 be setHIDDENM2 st tVar8 inTARSKIR2 NATNUMBERSK1 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds m =XBOOLE-0R4 x & k =COMPLEX1R1 tVar8 implies  not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k))"
              proof(rule bexI[of _ "0NUMBERSK6"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
                let ?y = "0NUMBERSK6"
                show "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
                   sorry
                fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
                fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
                assume A6: "m =XBOOLE-0R4 x"
                  and "k =COMPLEX1R1 ?y"
                show " not m <XXREAL-0R3 k & Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)"
                  using A5 A6 sorry
              qed "sorry"
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        A7: "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1"and A8: "g .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 n0"and A9: " for n be NatNAT-1M1 holds ?P1(n,g .FUNCT-1K1 n,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using recdef_1_sch_1 A3 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 NATNUMBERSK1"
      proof-
        let ?P = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1 inTARSKIR2 NATNUMBERSK1"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 g implies y inHIDDENR3 NATNUMBERSK1"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngFUNCT-1K2 g"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A10: "x inHIDDENR3 domRELAT-1K1 g"and A11: "g .FUNCT-1K1 x =HIDDENR1 y"
            using funct_1_def_3 sorry
          obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
            using A7 A10 sorry
          have A12: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
            using A9 sorry
          have A13: "?P(0NUMBERSK6)"
            using A8 sorry
          have " for k be NatNAT-1M1 holds ?P(k)"
            using nat_1_sch_2 A13 A12 sorry
          then have "g .FUNCT-1K1 n inTARSKIR2 NATNUMBERSK1"
             sorry
          thus "y inHIDDENR3 NATNUMBERSK1"
            using A11 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 g c=TARSKIR1 NATNUMBERSK1"
          using tarski_def_3 sorry
      qed
      then have 
        [ty]:"g be sequenceNAT-1M2-of NATNUMBERSK1"
        using A7 funct_2_th_2 sorry
      have "g be increasingVALUED-0V9"
        using A9 sorry
      then have 
        [ty]:"g be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
         sorry
      obtain S1 where 
        [ty]:"S1 be sequenceNAT-1M2-of Xf0" and S1Def:"S1 = Sf0 *VALUED-0K2\<^bsub>(Xf0)\<^esub> g"
         sorry
      have A14: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> S1 =MEMBEREDR12 NATNUMBERSK1"
        using funct_2_def_1 sorry
      have 
        [ty]:"S1 be subsequenceVALUED-0M2\<^bsub>(Xf0)\<^esub>-of Sf0"
         sorry
      show " ex tVar9 be subsequenceVALUED-0M2\<^bsub>(Xf0)\<^esub>-of Sf0 st  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp1(tVar9 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
      proof(rule bexI[of _ "S1"])
        show " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          show "Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
          proof-
            have cases: "n =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "n =COMPLEX1R1 0NUMBERSK6 implies Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
            proof(rule impI)
              assume "n =COMPLEX1R1 0NUMBERSK6"
              thus "Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
                using A2 A8 A14 funct_1_th_12 sorry
            qed
            have case2: "n <>HIDDENR2 0NUMBERSK6 implies Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
            proof(rule impI)
              assume "n <>HIDDENR2 0NUMBERSK6"
              then have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              then obtain n9 where 
                [ty]:"n9 be ElementSUBSET-1M1-of NATNUMBERSK1" and n9Def:"n9 = n -XCMPLX-0K6 \<one>\<^sub>M"
                using int_1_th_5 sorry
              obtain k where 
                [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = g .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n9 +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds m =COMPLEX1R1 g .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> n9 & k =COMPLEX1R1 g .NAT-1K8\<^bsub>(NATNUMBERSK1)\<^esub> (n9 +NAT-1K1 \<one>\<^sub>M) implies Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)"
                using A9 sorry
              then have "Pp1(Sf0 .NAT-1K8\<^bsub>(Xf0)\<^esub> k)"
                 sorry
              thus "Pp1(S1 .NAT-1K8\<^bsub>(Xf0)\<^esub> n)"
                using A14 funct_1_th_12 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem valued_1_th_27:
" for k be NatNAT-1M1 holds  for F be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F,domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)))are-equipotentTARSKIR3"
proof(rule ballI,rule ballI)
  fix k assume [ty]: "k be NatNAT-1M1"
  fix F assume [ty]: "F be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
  let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex il be ElementSUBSET-1M1-of NATNUMBERSK1 st Lamb1 =HIDDENR1 il & Lamb2 =HIDDENR1 k +NAT-1K1 il"
  have A1: " for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies ( ex u be objectHIDDENM1 st ?P(e,u))"
  proof-
    have " for e be objectHIDDENM1 holds e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies ( ex tVar10 be objectHIDDENM1 st  ex tVar11 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar11 =HIDDENR1 tVar11 & k +NAT-1K1 tVar11 =HIDDENR1 k +NAT-1K1 tVar11)"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
      then have 
        [ty]:"e be ElementSUBSET-1M1-of NATNUMBERSK1"
         sorry
      show " ex tVar10 be objectHIDDENM1 st  ex tVar11 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar11 =HIDDENR1 tVar11 & k +NAT-1K1 tVar11 =HIDDENR1 k +NAT-1K1 tVar11"
      proof(rule bexI[of _ "k +NAT-1K1 e"])
        show " ex tVar11 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar11 =HIDDENR1 tVar11 & k +NAT-1K1 tVar11 =HIDDENR1 k +NAT-1K1 tVar11"
        proof(rule bexI[of _ "e"])
          show "e =HIDDENR1 e & k +NAT-1K1 e =HIDDENR1 k +NAT-1K1 e"
             sorry
        qed "sorry"
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  obtain f where
    [ty]:"f be FunctionFUNCT-1M1" and 
    A2: "domRELAT-1K1 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"and A3: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies ?P(x,f .FUNCT-1K1 x)"
    using classes1_sch_1 A1 sorry
  have "( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2) & (domRELAT-1K1 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F & rngRELAT-1K2 f =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)))"
  proof(rule conjMI,rule conjMI)
    show " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELAT-1K1 f & (x2 inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A4: "x1 inHIDDENR3 domRELAT-1K1 f"
        and A5: "x2 inHIDDENR3 domRELAT-1K1 f"
        and A6: "f .FUNCT-1K1 x1 =XBOOLE-0R4 f .FUNCT-1K1 x2"
      obtain i1 where
        [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A7: "x1 =HIDDENR1 i1"and A8: "f .FUNCT-1K1 x1 =XBOOLE-0R4 k +NAT-1K1 i1"
        using A2 A3 A4 sorry
      obtain i2 where
        [ty]:"i2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A9: "x2 =HIDDENR1 i2"and A10: "f .FUNCT-1K1 x2 =XBOOLE-0R4 k +NAT-1K1 i2"
        using A2 A3 A5 sorry
      show "x1 =HIDDENR1 x2"
        using A7 A6 A8 A10 A9 sorry
    qed "sorry"
    show "domRELAT-1K1 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
      using A2 sorry
    have A11: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
      using valued_1_def_12 sorry
    have "( for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))) & domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) c=TARSKIR1 rngRELAT-1K2 f"
    proof(rule conjMI)
      show " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 f"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A12: "x inHIDDENR3 domRELAT-1K1 f"and A13: "f .FUNCT-1K1 x =HIDDENR1 y"
          using funct_1_def_3 sorry
        obtain il where
          [ty]:"il be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A14: "x =HIDDENR1 il"and A15: "f .FUNCT-1K1 x =XBOOLE-0R4 k +NAT-1K1 il"
          using A2 A3 A12 sorry
        show "y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
          using A2 A11 A12 A13 A14 A15 sorry
      qed "sorry"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) implies y inHIDDENR3 rngRELAT-1K2 f"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A16: "y =HIDDENR1 m +XCMPLX-0K2 k"and A17: "m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          using A11 sorry
        obtain il where
          [ty]:"il be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A18: "m =COMPLEX1R1 il"and A19: "f .FUNCT-1K1 m =XBOOLE-0R4 k +NAT-1K1 il"
          using A3 A17 sorry
        show "y inHIDDENR3 rngRELAT-1K2 f"
          using A2 A16 A17 A18 A19 funct_1_def_3 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) c=TARSKIR1 rngRELAT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "rngRELAT-1K2 f =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
      using tarski_def_3 xboole_0_def_10 sorry
  qed
  then have "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F) & rngRELAT-1K2 f =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
    using funct_1_def_4 sorry
  thus "(domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F,domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)))are-equipotentTARSKIR3"
    using bexI[of _ "f"] wellord2_def_4 sorry
qed "sorry"

mtheorem valued_1_reduce_1:
  mlet "F be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"reduce ShiftVALUED-1K64(F,0NUMBERSK6) to F"
proof
(*reducibility*)
  show "ShiftVALUED-1K64(F,0NUMBERSK6) =HIDDENR1 F"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =XBOOLE-0R4 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
    proof-
      have "( for a be objectHIDDENM1 holds a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies a inHIDDENR3 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }) & {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
      proof(rule conjMI)
        show " for a be objectHIDDENM1 holds a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies a inHIDDENR3 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume A2: "a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          then obtain l where 
            [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = a"
             sorry
          have "a =HIDDENR1 l +XCMPLX-0K2 0NUMBERSK6"
             sorry
          thus "a inHIDDENR3 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
            using A2 sorry
        qed "sorry"
        have " for a be objectHIDDENM1 holds a inHIDDENR3 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F } implies a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
          then have " ex m be NatNAT-1M1 st a =HIDDENR1 m +XCMPLX-0K2 0NUMBERSK6 & m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
             sorry
          thus "a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
             sorry
        qed "sorry"
        thus "{m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          using tarski_def_3 sorry
      qed
      thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =XBOOLE-0R4 {m +XCMPLX-0K2 0NUMBERSK6 where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
        using tarski_def_3 xboole_0_def_10 sorry
    qed
    have " for m be NatNAT-1M1 holds m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies F .FUNCT-1K1 (m +XCMPLX-0K2 0NUMBERSK6) =XBOOLE-0R4 F .FUNCT-1K1 m"
       sorry
    thus "ShiftVALUED-1K64(F,0NUMBERSK6) =HIDDENR1 F"
      using A1 valued_1_def_12 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_106:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be X -valuedRELAT-1V5\<bar>FunctionFUNCT-1M1", "k be NatNAT-1M1"
"cluster ShiftVALUED-1K64(F,k) as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "ShiftVALUED-1K64(F,k) be X -valuedRELAT-1V5"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 F }"
      using valued_1_def_12 sorry
    have "rngFUNCT-1K2 (ShiftVALUED-1K64(F,k)) c=TARSKIR1 X"
    proof-
      show "rngFUNCT-1K2 (ShiftVALUED-1K64(F,k)) c=TARSKIR1 X"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(F,k)) implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 rngFUNCT-1K2 (ShiftVALUED-1K64(F,k))"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A2: "y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"and A3: "x =HIDDENR1 (ShiftVALUED-1K64(F,k)).FUNCT-1K1 y"
            using funct_1_def_3 sorry
          obtain m where
            [ty]:"m be NatNAT-1M1" and 
            A4: "y =HIDDENR1 m +XCMPLX-0K2 k"and A5: "m inTARSKIR2 domRELAT-1K1 F"
            using A2 A1 sorry
          have "(ShiftVALUED-1K64(F,k)).FUNCT-1K1 (m +XCMPLX-0K2 k) =HIDDENR1 F .FUNCT-1K1 m"
            using A5 valued_1_def_12 sorry
          also have "... = F /.PARTFUN1K7\<^bsub>(X)\<^esub> m"
            using A5 partfun1_def_6 sorry
          finally have "(ShiftVALUED-1K64(F,k)).FUNCT-1K1 (m +XCMPLX-0K2 k) =HIDDENR1 F /.PARTFUN1K7\<^bsub>(X)\<^esub> m"
             sorry
          thus "x inHIDDENR3 X"
            using A3 A4 sorry
        qed "sorry"
        thus "rngFUNCT-1K2 (ShiftVALUED-1K64(F,k)) c=TARSKIR1 X"
          using tarski_def_3 sorry
      qed
    qed
    thus "ShiftVALUED-1K64(F,k) be X -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_107:
"cluster  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4"
  proof-
    have " ex tVar13 be FunctionFUNCT-1M1 st  not tVar13 be emptyXBOOLE-0V1 & tVar13 be NATNUMBERSK1 -definedRELAT-1V4"
    proof-
      show " ex tVar13 be FunctionFUNCT-1M1 st  not tVar13 be emptyXBOOLE-0V1 & tVar13 be NATNUMBERSK1 -definedRELAT-1V4"
      proof(rule bexI[of _ "idPARTFUN1K6 NATNUMBERSK1"])
        show " not idPARTFUN1K6 NATNUMBERSK1 be emptyXBOOLE-0V1 & idPARTFUN1K6 NATNUMBERSK1 be NATNUMBERSK1 -definedRELAT-1V4"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_108:
  mlet "F be emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1", "k be NatNAT-1M1"
"cluster ShiftVALUED-1K64(F,k) as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "ShiftVALUED-1K64(F,k) be emptyXBOOLE-0V1"
  proof-
    have "ShiftVALUED-1K64(F,k) be  non emptyXBOOLE-0V1 implies  not  True "
    proof(rule impI)
      have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domFINSEQ-1K5 F }"
        using valued_1_def_12 sorry
      assume "ShiftVALUED-1K64(F,k) be  non emptyXBOOLE-0V1"
      then obtain f where 
        [ty]:"f be  non emptyXBOOLE-0V1\<bar>FunctionFUNCT-1M1" and fDef:"f = ShiftVALUED-1K64(F,k)"
         sorry
      have "domRELAT-1K1 f be  non emptyXBOOLE-0V1"
         sorry
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A2: "a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
         sorry
      have " ex m be NatNAT-1M1 st a =HIDDENR1 m +XCMPLX-0K2 k & m inTARSKIR2 domFINSEQ-1K5 F"
        using A1 A2 sorry
      thus " not  True "
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_109:
  mlet "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1", "k be NatNAT-1M1"
"cluster ShiftVALUED-1K64(F,k) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "ShiftVALUED-1K64(F,k) be  non emptyXBOOLE-0V1"
  proof-
    have " not ShiftVALUED-1K64(F,k) be emptyXBOOLE-0V1"
    proof-
      have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F }"
        using valued_1_def_12 sorry
      obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A2: "a inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
        using xboole_0_def_1 sorry
      have 
        [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1"
        using A2 sorry
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A3: "a =COMPLEX1R1 m"
         sorry
      have 
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
        using ordinal1_def_12 sorry
      have "m +XCMPLX-0K2 k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
        using A1 A2 A3 sorry
      thus " not ShiftVALUED-1K64(F,k) be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem valued_1_th_29:
" for F be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 implies  not 0NUMBERSK6 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
proof-
  have " for F be FunctionFUNCT-1M1 holds  for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & 0NUMBERSK6 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix F assume [ty]: "F be FunctionFUNCT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "k >XXREAL-0R4 0NUMBERSK6"
      and A2: "0NUMBERSK6 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k))"
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(F,k)) =XBOOLE-0R4 {m +XCMPLX-0K2 k where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 F }"
      using valued_1_def_12 sorry
    then have " ex m be NatNAT-1M1 st 0NUMBERSK6 =COMPLEX1R1 m +XCMPLX-0K2 k & m inTARSKIR2 domRELAT-1K1 F"
      using A2 sorry
    thus " False "
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_cl_110:
"cluster NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex f be setHIDDENM2 st (f be NATNUMBERSK1 -definedRELAT-1V4 & f be finiteFINSET-1V1) &  not f be emptyXBOOLE-0V1"
    proof-
      obtain f where 
        [ty]:"f be setHIDDENM2" and fDef:"f = (0NUMBERSK6).-->FUNCOP-1K17 (0NUMBERSK6)"
         sorry
      show " ex f be setHIDDENM2 st (f be NATNUMBERSK1 -definedRELAT-1V4 & f be finiteFINSET-1V1) &  not f be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "f"])
        have Cut3190: "domRELSET-1K1\<^bsub>({TARSKIK1 0NUMBERSK6 })\<^esub> f =MEMBEREDR12 {TARSKIK1 0NUMBERSK6 }"
          using funcop_1_th_13 sorry
        have "domRELSET-1K1\<^bsub>({TARSKIK1 0NUMBERSK6 })\<^esub> f c=MEMBEREDR6 NATNUMBERSK1 & (f be finiteFINSET-1V1 &  not f be emptyXBOOLE-0V1)"
        proof(rule conjMI)
          show "domRELSET-1K1\<^bsub>({TARSKIK1 0NUMBERSK6 })\<^esub> f c=MEMBEREDR6 NATNUMBERSK1"
            using zfmisc_1_th_31 Cut3190 sorry
          show "f be finiteFINSET-1V1 &  not f be emptyXBOOLE-0V1"
             sorry
        qed
        thus "(f be NATNUMBERSK1 -definedRELAT-1V4 & f be finiteFINSET-1V1) &  not f be emptyXBOOLE-0V1"
          using relat_1_def_18 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_111:
  mlet "F be NATNUMBERSK1 -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F as-term-is natural-memberedMEMBEREDV6"
proof
(*coherence*)
  show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F be natural-memberedMEMBEREDV6"
     sorry
qed "sorry"

mdef valued_1_def_17 ("LastLocVALUED-1K65  _ " [164]164 ) where
  mlet "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"func LastLocVALUED-1K65 F \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  maxXXREAL-2K6 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F)"
proof-
  (*coherence*)
    show "maxXXREAL-2K6 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F) be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
qed "sorry"

mdef valued_1_def_18 ("CutLastLocVALUED-1K66  _ " [164]164 ) where
  mlet "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"func CutLastLocVALUED-1K66 F \<rightarrow> FunctionFUNCT-1M1 equals
  F \\SUBSET-1K6 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
proof-
  (*coherence*)
    show "F \\SUBSET-1K6 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F) be FunctionFUNCT-1M1"
       sorry
qed "sorry"

mtheorem valued_1_cl_112:
  mlet "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem valued_1_th_30:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds LastLocVALUED-1K65 F inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
  using xxreal_2_def_8 sorry

mtheorem valued_1_th_31:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds F c=RELAT-1R2 G implies LastLocVALUED-1K65 F <=XXREAL-0R1 LastLocVALUED-1K65 G"
  using relat_1_th_11 xxreal_2_th_59 sorry

mtheorem valued_1_th_32:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for l be ElementSUBSET-1M1-of NATNUMBERSK1 holds l inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies l <=XXREAL-0R1 LastLocVALUED-1K65 F"
  using xxreal_2_def_8 sorry

mdef valued_1_def_19 ("FirstLocVALUED-1K67  _ " [164]164 ) where
  mlet "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
"func FirstLocVALUED-1K67 F \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  minXXREAL-2K5 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F)"
proof-
  (*coherence*)
    show "minXXREAL-2K5 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F) be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
qed "sorry"

mtheorem valued_1_th_33:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds FirstLocVALUED-1K67 F inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
  using xxreal_2_def_7 sorry

mtheorem valued_1_th_34:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds F c=RELAT-1R2 G implies FirstLocVALUED-1K67 G <=XXREAL-0R1 FirstLocVALUED-1K67 F"
  using relat_1_th_11 xxreal_2_th_60 sorry

mtheorem valued_1_th_35:
" for l1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds l1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F implies FirstLocVALUED-1K67 F <=XXREAL-0R1 l1"
  using xxreal_2_def_7 sorry

mtheorem valued_1_th_36:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
proof(rule ballI)
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
  have A1: "domRELSET-1K1\<^bsub>({TARSKIK1 LastLocVALUED-1K65 F })\<^esub> ((LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)) =MEMBEREDR12 {TARSKIK1 LastLocVALUED-1K65 F }"
    using funcop_1_th_13 sorry
  obtain R where 
    [ty]:"R be RelationRELAT-1M1" and RDef:"R = {TARSKIK1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] }"
     sorry
  have A2: "R =RELAT-1R1 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
    using funct_4_th_82 sorry
  then have A3: "domRELAT-1K1 R =XBOOLE-0R4 {TARSKIK1 LastLocVALUED-1K65 F }"
    using funcop_1_th_13 sorry
  have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F } & domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F)"
  proof(rule conjMI)
    show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,y ] inHIDDENR3 F \\SUBSET-1K6 R"
          using A2 xtuple_0_def_12 sorry
        have A5: " not [TARSKIK4 x,y ] inHIDDENR3 R"
          using A4 xboole_0_def_5 sorry
        have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          using A4 xtuple_0_def_12 sorry
        show "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
        proof-
          have cases: "x <>HIDDENR2 LastLocVALUED-1K65 F or y <>HIDDENR2 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
            using A5 tarski_def_1 sorry
          have case1: "x <>HIDDENR2 LastLocVALUED-1K65 F implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
          proof(rule impI)
            assume "x <>HIDDENR2 LastLocVALUED-1K65 F"
            then have " not x inHIDDENR3 domRELAT-1K1 R"
              using A3 tarski_def_1 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
              using A1 A2 A6 xboole_0_def_5 sorry
          qed
          have case2: "y <>HIDDENR2 F .FUNCT-1K1 (LastLocVALUED-1K65 F) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
          proof(rule impI)
            assume A7: "y <>HIDDENR2 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
            have "x inHIDDENR3 domRELAT-1K1 R implies  False "
            proof(rule impI)
              assume "x inHIDDENR3 domRELAT-1K1 R"
              then have "x =HIDDENR1 LastLocVALUED-1K65 F"
                using A3 tarski_def_1 sorry
              thus " False "
                using A4 A7 funct_1_th_1 sorry
            qed
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
              using A1 A2 A6 xboole_0_def_5 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
        using tarski_def_3 sorry
    qed
    show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F)"
      using A1 xtuple_0_th_25 sorry
  qed
  thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem valued_1_th_37:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) \\/XBOOLE-0K2 {TARSKIK1 LastLocVALUED-1K65 F }"
proof(rule ballI)
  fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
  have "LastLocVALUED-1K65 F inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
    using xxreal_2_def_8 sorry
  then have A1: "{TARSKIK1 LastLocVALUED-1K65 F } c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
    using zfmisc_1_th_31 sorry
  have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F \\SUBSET-1K7\<^bsub>(NATNUMBERSK1)\<^esub> {TARSKIK1 LastLocVALUED-1K65 F }"
    using valued_1_th_36 sorry
  thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (CutLastLocVALUED-1K66 F) \\/XBOOLE-0K2 {TARSKIK1 LastLocVALUED-1K65 F }"
    using A1 xboole_1_th_45 sorry
qed "sorry"

mtheorem valued_1_cl_113:
"cluster \<one>\<^sub>M -elementCARD-1V3\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be \<one>\<^sub>M -elementCARD-1V3\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1"
  proof-
    have " ex tVar15 be FunctionFUNCT-1M1 st (tVar15 be \<one>\<^sub>M -elementCARD-1V3 & tVar15 be NATNUMBERSK1 -definedRELAT-1V4) & tVar15 be finiteFINSET-1V1"
    proof-
      show " ex tVar15 be FunctionFUNCT-1M1 st (tVar15 be \<one>\<^sub>M -elementCARD-1V3 & tVar15 be NATNUMBERSK1 -definedRELAT-1V4) & tVar15 be finiteFINSET-1V1"
      proof(rule bexI[of _ "(0NUMBERSK6).-->FUNCOP-1K17 (0NUMBERSK6)"])
        show "((0NUMBERSK6).-->FUNCOP-1K17 (0NUMBERSK6) be \<one>\<^sub>M -elementCARD-1V3 & (0NUMBERSK6).-->FUNCOP-1K17 (0NUMBERSK6) be NATNUMBERSK1 -definedRELAT-1V4) & (0NUMBERSK6).-->FUNCOP-1K17 (0NUMBERSK6) be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_114:
  mlet "F be \<one>\<^sub>M -elementCARD-1V3\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be emptyXBOOLE-0V1"
  proof-
    have " not CutLastLocVALUED-1K66 F be emptyXBOOLE-0V1 implies  not  True "
    proof(rule impI)
      have "LastLocVALUED-1K65 F inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
        using xxreal_2_def_8 sorry
      then have A1: "[TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] inHIDDENR3 F"
        using funct_1_def_2 sorry
      assume " not CutLastLocVALUED-1K66 F be emptyXBOOLE-0V1"
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A2: "a inHIDDENR3 CutLastLocVALUED-1K66 F"
         sorry
      have A3: "a =HIDDENR1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ]"
        using A1 A2 zfmisc_1_def_10 sorry
      have " not a inHIDDENR3 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
        using A2 xboole_0_def_5 sorry
      then have " not a inHIDDENR3 {TARSKIK1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] }"
        using funct_4_th_82 sorry
      thus " not  True "
        using A3 tarski_def_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_th_38:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds cardCARD-1K4 (CutLastLocVALUED-1K66 F) =COMPLEX1R1 cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M"
proof-
  have " for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M"
  proof(rule ballI)
    fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    have "(LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F) c=RELAT-1R2 F"
    proof-
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F) implies [TARSKIK4 a,b ] inHIDDENR3 F"
      proof(rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume "[TARSKIK4 a,b ] inHIDDENR3 (LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F)"
        then have "[TARSKIK4 a,b ] inHIDDENR3 {TARSKIK1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] }"
          using funct_4_th_82 sorry
        then have A1: "[TARSKIK4 a,b ] =HIDDENR1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ]"
          using tarski_def_1 sorry
        have "LastLocVALUED-1K65 F inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F"
          using xxreal_2_def_8 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 F"
          using A1 funct_1_def_2 sorry
      qed "sorry"
      thus "(LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F) c=RELAT-1R2 F"
        using relat_1_def_3 sorry
    qed
    then have "cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -XCMPLX-0K6 cardCARD-1K4 ((LastLocVALUED-1K65 F).-->FUNCOP-1K17 F .FUNCT-1K1 (LastLocVALUED-1K65 F))"
      using card_2_th_44 sorry
    also have "... = cardCARD-1K4 F -XCMPLX-0K6 cardCARD-1K4 {TARSKIK1 [TARSKIK4 LastLocVALUED-1K65 F,F .FUNCT-1K1 (LastLocVALUED-1K65 F) ] }"
      using funct_4_th_82 sorry
    also have "... = cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M"
      using card_1_th_30 sorry
    finally show "cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem valued_1_cl_115:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "-VALUED-1K32 f be X -definedRELAT-1V4"
  proof-
    have A1: "domRELAT-1K1 (-VALUED-1K32 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_5 sorry
    have "domRELAT-1K1 (-VALUED-1K32 f) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (-VALUED-1K32 f) c=TARSKIR1 X"
        using A1 sorry
    qed
    thus "-VALUED-1K32 f be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_116:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f \<inverse>VALUED-1K37 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be X -definedRELAT-1V4"
  proof-
    have A2: "domRELAT-1K1 (f \<inverse>VALUED-1K37) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_7 sorry
    have "domRELAT-1K1 (f \<inverse>VALUED-1K37) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (f \<inverse>VALUED-1K37) c=TARSKIR1 X"
        using A2 sorry
    qed
    thus "f \<inverse>VALUED-1K37 be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_117:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be X -definedRELAT-1V4"
  proof-
    have A3: "domRELAT-1K1 f ^2VALUED-1K41 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_th_11 sorry
    have "domRELAT-1K1 f ^2VALUED-1K41 c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 f ^2VALUED-1K41 c=TARSKIR1 X"
        using A3 sorry
    qed
    thus "f ^2VALUED-1K41 be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_118:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster  |.VALUED-1K56 f.| as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be X -definedRELAT-1V4"
  proof-
    have A4: "domRELAT-1K1 ( |.VALUED-1K56 f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_11 sorry
    have "domRELAT-1K1 ( |.VALUED-1K56 f.|) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 ( |.VALUED-1K56 f.|) c=TARSKIR1 X"
        using A4 sorry
    qed
    thus " |.VALUED-1K56 f.| be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_119:
  mlet "X be setHIDDENM2"
"cluster totalPARTFUN1V1\<^bsub>(X)\<^esub> for X -definedRELAT-1V4\<bar>natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be X -definedRELAT-1V4\<bar>natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1 st it be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have " ex tVar16 be X -definedRELAT-1V4\<bar>natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1 st tVar16 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
    proof-
      show " ex tVar16 be X -definedRELAT-1V4\<bar>natural-valuedVALUED-0V8\<bar>FunctionFUNCT-1M1 st tVar16 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      proof(rule bexI[of _ "the totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,NATNUMBERSK1)"])
        show "the totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>PartFuncPARTFUN1M1-of(X,NATNUMBERSK1) be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem valued_1_cl_120:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster -VALUED-1K32 f as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "-VALUED-1K32 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> (-VALUED-1K32 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_5 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "-VALUED-1K32 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A1 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_121:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f \<inverse>VALUED-1K37 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f \<inverse>VALUED-1K37 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (f \<inverse>VALUED-1K37) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_7 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "f \<inverse>VALUED-1K37 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A2 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_122:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f ^2VALUED-1K41 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f ^2VALUED-1K41 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A3: "domRELSET-1K1\<^bsub>(X)\<^esub> f ^2VALUED-1K41 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_th_11 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "f ^2VALUED-1K41 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A3 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_123:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster  |.VALUED-1K56 f.| as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show " |.VALUED-1K56 f.| be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A4: "domRELSET-1K1\<^bsub>(X)\<^esub> ( |.VALUED-1K56 f.|) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_11 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus " |.VALUED-1K56 f.| be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A4 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_124:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K7 f as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "r +VALUED-1K7 f be X -definedRELAT-1V4"
  proof-
    have A1: "domRELAT-1K1 (r +VALUED-1K7 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_2 sorry
    have "domRELAT-1K1 (r +VALUED-1K7 f) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (r +VALUED-1K7 f) c=TARSKIR1 X"
        using A1 sorry
    qed
    thus "r +VALUED-1K7 f be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_125:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K14 r as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f -VALUED-1K14 r be X -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem valued_1_cl_126:
  mlet "X be setHIDDENM2", "f be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K25 f as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be X -definedRELAT-1V4"
  proof-
    have A2: "domRELAT-1K1 (r (#)VALUED-1K25 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_5 sorry
    have "domRELAT-1K1 (r (#)VALUED-1K25 f) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (r (#)VALUED-1K25 f) c=TARSKIR1 X"
        using A2 sorry
    qed
    thus "r (#)VALUED-1K25 f be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_127:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r +VALUED-1K7 f as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "r +VALUED-1K7 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> (r +VALUED-1K7 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_2 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "r +VALUED-1K7 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A1 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_128:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster f -VALUED-1K14 r as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f -VALUED-1K14 r be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_129:
  mlet "X be setHIDDENM2", "f be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "r be ComplexXCMPLX-0M1"
"cluster r (#)VALUED-1K25 f as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "r (#)VALUED-1K25 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (r (#)VALUED-1K25 f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f"
      using valued_1_def_5 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "r (#)VALUED-1K25 f be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A2 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_130:
  mlet "X be setHIDDENM2", "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be X -definedRELAT-1V4"
  proof-
    have A1: "domRELAT-1K1 (f1 +VALUED-1K1 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f2"
      using valued_1_def_1 sorry
    have "domRELAT-1K1 (f1 +VALUED-1K1 f2) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (f1 +VALUED-1K1 f2) c=TARSKIR1 X"
        using A1 sorry
    qed
    thus "f1 +VALUED-1K1 f2 be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_131:
  mlet "X be setHIDDENM2", "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be X -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem valued_1_cl_132:
  mlet "X be setHIDDENM2", "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be X -definedRELAT-1V4"
  proof-
    have A2: "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) =XBOOLE-0R4 domRELAT-1K1 f1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f2"
      using valued_1_def_4 sorry
    have "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (f1 (#)VALUED-1K19 f2) c=TARSKIR1 X"
        using A2 sorry
    qed
    thus "f1 (#)VALUED-1K19 f2 be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_133:
  mlet "X be setHIDDENM2", "f1 be complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be X -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem valued_1_cl_134:
  mlet "X be setHIDDENM2", "f1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 +VALUED-1K1 f2 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f1 +VALUED-1K1 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A1: "domRELSET-1K1\<^bsub>(X)\<^esub> (f1 +VALUED-1K1 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f2"
      using valued_1_def_1 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "f1 +VALUED-1K1 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A1 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_135:
  mlet "X be setHIDDENM2", "f1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 -VALUED-1K47 f2 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f1 -VALUED-1K47 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_136:
  mlet "X be setHIDDENM2", "f1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 (#)VALUED-1K19 f2 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f1 (#)VALUED-1K19 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
  proof-
    have A2: "domRELSET-1K1\<^bsub>(X)\<^esub> (f1 (#)VALUED-1K19 f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> f2"
      using valued_1_def_4 sorry
    have "domRELSET-1K1\<^bsub>(X)\<^esub> f1 =XBOOLE-0R4 X & domRELSET-1K1\<^bsub>(X)\<^esub> f2 =XBOOLE-0R4 X"
      using partfun1_def_2 sorry
    thus "f1 (#)VALUED-1K19 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
      using A2 partfun1_def_2 sorry
  qed
qed "sorry"

mtheorem valued_1_cl_137:
  mlet "X be setHIDDENM2", "f1 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1", "f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>\<bar>X -definedRELAT-1V4\<bar>complex-valuedVALUED-0V5\<bar>FunctionFUNCT-1M1"
"cluster f1 /\<inverse>VALUED-1K52 f2 as-term-is totalPARTFUN1V1\<^bsub>(X)\<^esub>"
proof
(*coherence*)
  show "f1 /\<inverse>VALUED-1K52 f2 be totalPARTFUN1V1\<^bsub>(X)\<^esub>"
     sorry
qed "sorry"

mtheorem valued_1_cl_138:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "F be X -valuedRELAT-1V5\<bar> non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
"cluster CutLastLocVALUED-1K66 F as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "CutLastLocVALUED-1K66 F be X -valuedRELAT-1V5"
     sorry
qed "sorry"

mtheorem valued_1_th_39:
" for f be FunctionFUNCT-1M1 holds  for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(f,n)) implies ( ex j be NatNAT-1M1 st j inTARSKIR2 domRELAT-1K1 f & i =COMPLEX1R1 j +XCMPLX-0K2 n)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(f,n)) =XBOOLE-0R4 {m +XCMPLX-0K2 n where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 f }"
    using valued_1_def_12 sorry
  assume "i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(f,n))"
  then have " ex m be NatNAT-1M1 st i =COMPLEX1R1 m +XCMPLX-0K2 n & m inTARSKIR2 domRELAT-1K1 f"
    using A1 sorry
  thus " ex j be NatNAT-1M1 st j inTARSKIR2 domRELAT-1K1 f & i =COMPLEX1R1 j +XCMPLX-0K2 n"
     sorry
qed "sorry"

mtheorem valued_1_cl_139:
  mlet "p be FinSubsequenceFINSEQ-1M4", "i be NatNAT-1M1"
"cluster ShiftVALUED-1K64(p,i) as-term-is FinSubsequence-likeFINSEQ-1V2"
proof
(*coherence*)
  show "ShiftVALUED-1K64(p,i) be FinSubsequence-likeFINSEQ-1V2"
  proof-
    let ?X = "{k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p }"
    let ?f = "ShiftVALUED-1K64(p,i)"
    obtain K where
      [ty]:"K be NatNAT-1M1" and 
      A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p c=MEMBEREDR6 SegFINSEQ-1K2 K"
      using finseq_1_def_12 sorry
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f =XBOOLE-0R4 ?X"
      using valued_1_def_12 sorry
    have "?X c=TARSKIR1 SegFINSEQ-1K2 (i +XCMPLX-0K2 K)"
    proof-
      have "{k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p } c=TARSKIR1 SegFINSEQ-1K2 (i +XCMPLX-0K2 K)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p } implies x inHIDDENR3 SegFINSEQ-1K2 (i +XCMPLX-0K2 K)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A3: "x =HIDDENR1 k +XCMPLX-0K2 i"and A4: "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
             sorry
          have A5: "i +XCMPLX-0K2 k >=XXREAL-0R2 k"
            using nat_1_th_11 sorry
          have A6: "k >=XXREAL-0R2 \<one>\<^sub>M"
            using A1 A4 finseq_1_th_1 sorry
          have A7: "k <=XXREAL-0R1 K"
            using A1 A4 finseq_1_th_1 sorry
          have "i +XCMPLX-0K2 k >=XXREAL-0R2 \<one>\<^sub>M"
            using A5 A6 xxreal_0_th_2 sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 (i +XCMPLX-0K2 K)"
            using A3 A7 finseq_1_th_1 xreal_1_th_6 sorry
        qed "sorry"
        thus "{k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p } c=TARSKIR1 SegFINSEQ-1K2 (i +XCMPLX-0K2 K)"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "ShiftVALUED-1K64(p,i) be FinSubsequence-likeFINSEQ-1V2"
      using A2 sorry
  qed
qed "sorry"

reserve i for "NatNAT-1M1"
reserve k, k1, k2, j1 for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve x, x1, x2, y for "setHIDDENM2"
mtheorem valued_1_th_40:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 p =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p }"
       sorry
    finally have "domFINSEQ-1K5 p =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p }"
       sorry
    let ?X = "{j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {k1 +XCMPLX-0K2 i where k1 be NatNAT-1M1 : k1 inTARSKIR2 domFINSEQ-1K5 p }"
      using valued_1_def_12 sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) c=MEMBEREDR6 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p } & {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
    proof(rule conjMI)
      show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) c=MEMBEREDR6 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) implies x inHIDDENR3 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
          then obtain k1 where
            [ty]:"k1 be NatNAT-1M1" and 
            A3: "x =HIDDENR1 k1 +XCMPLX-0K2 i"and A4: "k1 inTARSKIR2 domFINSEQ-1K5 p"
            using A2 sorry
          obtain k where
            [ty]:"k be NatNAT-1M1" and 
            A5: "k1 =COMPLEX1R1 k"and A6: "\<one>\<^sub>M <=XXREAL-0R1 k"and A7: "k <=XXREAL-0R1 lenFINSEQ-1K4 p"
            using A1 A4 sorry
          have A8: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 k"
            using A6 xreal_1_th_7 sorry
          have "i +XCMPLX-0K2 k <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p"
            using A7 xreal_1_th_7 sorry
          thus "x inHIDDENR3 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
            using A3 A5 A8 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) c=MEMBEREDR6 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p } implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 ?X"
        then obtain j1 where
          [ty]:"j1 be NatNAT-1M1" and 
          A9: "x =HIDDENR1 j1"and A10: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1"and A11: "j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p"
           sorry
        have "i +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        then obtain k2 where
          [ty]:"k2 be NatNAT-1M1" and 
          A12: "j1 =COMPLEX1R1 i +XCMPLX-0K2 k2"
          using A10 nat_1_th_10 xxreal_0_th_2 sorry
        have A13: "\<one>\<^sub>M <=XXREAL-0R1 k2"
          using A10 A12 xreal_1_th_6 sorry
        have "k2 <=XXREAL-0R1 lenFINSEQ-1K4 p"
          using A11 A12 xreal_1_th_6 sorry
        then have "k2 inTARSKIR2 domFINSEQ-1K5 p"
          using A1 A13 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
          using A2 A9 A12 sorry
      qed "sorry"
      thus "{j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p } c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
        using tarski_def_3 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {j1 where j1 be NatNAT-1M1 : i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j1 & j1 <=XXREAL-0R1 i +NAT-1K1 lenFINSEQ-1K4 p }"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_41:
" for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds  ex ss be FinSubsequenceFINSEQ-1M4 st ((domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q & rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k)) & ss be one-to-oneFUNCT-1V2"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds  not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (((domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q & rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q &  not ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k))) & ss be one-to-oneFUNCT-1V2))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 SegFINSEQ-1K2 n"
      using finseq_1_def_12 sorry
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 i +NAT-1K1 k"
    have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ( ex y be objectHIDDENM1 st ?P(x,y))"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ( ex tVar17 be objectHIDDENM1 st  ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =HIDDENR1 x & tVar17 =HIDDENR1 i +NAT-1K1 k)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
        then have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
           sorry
        show " ex tVar17 be objectHIDDENM1 st  ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =HIDDENR1 x & tVar17 =HIDDENR1 i +NAT-1K1 k"
        proof(rule bexI[of _ "i +NAT-1K1 x"])
          show " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =HIDDENR1 x & i +NAT-1K1 x =HIDDENR1 i +NAT-1K1 k"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 f =XBOOLE-0R4 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ?P(x,f .FUNCT-1K1 x)"
      using classes1_sch_1 A2 sorry
    obtain ss where 
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and ssDef:"ss = f"
      using A1 A3 finseq_1_def_12 sorry
    have A5: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q }"
      using valued_1_def_12 sorry
    have A6: "rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
    proof-
      have "rngFUNCT-1K2 ss c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) & domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=TARSKIR1 rngFUNCT-1K2 ss"
      proof(rule conjMI)
        show "rngFUNCT-1K2 ss c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
        proof-
          have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 ss implies y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 rngFUNCT-1K2 ss"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A7: "x inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss"and A8: "y =HIDDENR1 ss .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have " ex k1 be ElementSUBSET-1M1-of NATNUMBERSK1 st k1 =HIDDENR1 x & ss .FUNCT-1K1 x =XBOOLE-0R4 i +NAT-1K1 k1"
              using A3 A4 A7 sorry
            thus "y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
              using A3 A5 A7 A8 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 ss c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
            using tarski_def_3 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) implies y inHIDDENR3 rngFUNCT-1K2 ss"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
          then obtain k2 where
            [ty]:"k2 be NatNAT-1M1" and 
            A9: "y =HIDDENR1 k2 +XCMPLX-0K2 i"and A10: "k2 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
            using A5 sorry
          have " ex k3 be ElementSUBSET-1M1-of NATNUMBERSK1 st k3 =COMPLEX1R1 k2 & ss .FUNCT-1K1 k2 =XBOOLE-0R4 i +NAT-1K1 k3"
            using A4 A10 sorry
          thus "y inHIDDENR3 rngFUNCT-1K2 ss"
            using A3 A9 A10 funct_1_def_3 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=TARSKIR1 rngFUNCT-1K2 ss"
          using tarski_def_3 sorry
      qed
      thus "rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
        using xboole_0_def_10 sorry
    qed
    have A11: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
      then have " ex k1 be ElementSUBSET-1M1-of NATNUMBERSK1 st k1 =COMPLEX1R1 k & ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k1"
        using A4 sorry
      thus "ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k"
         sorry
    qed "sorry"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss) & ss .FUNCT-1K1 x1 =XBOOLE-0R4 ss .FUNCT-1K1 x2 implies x1 =HIDDENR1 x2"
    proof-
      have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss & ss .FUNCT-1K1 x1 =XBOOLE-0R4 ss .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix x1 assume [ty]: "x1 be objectHIDDENM1"
        fix x2 assume [ty]: "x2 be objectHIDDENM1"
        assume A12: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss"
          and A13: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss"
          and A14: "ss .FUNCT-1K1 x1 =XBOOLE-0R4 ss .FUNCT-1K1 x2"
        have A15: " ex k1 be ElementSUBSET-1M1-of NATNUMBERSK1 st k1 =HIDDENR1 x1 & ss .FUNCT-1K1 x1 =XBOOLE-0R4 i +NAT-1K1 k1"
          using A3 A4 A12 sorry
        have " ex k2 be ElementSUBSET-1M1-of NATNUMBERSK1 st k2 =HIDDENR1 x2 & ss .FUNCT-1K1 x2 =XBOOLE-0R4 i +NAT-1K1 k2"
          using A3 A4 A13 sorry
        thus "x1 =HIDDENR1 x2"
          using A14 A15 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "ss be one-to-oneFUNCT-1V2"
       sorry
    thus " not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (((domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q & rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q &  not ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k))) & ss be one-to-oneFUNCT-1V2))"
      using A3 A6 A11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma valued_1_lm_5:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  ex fs be FinSequenceFINSEQ-1M1 st ((domFINSEQ-1K5 fs =MEMBEREDR12 domFINSEQ-1K5 p & rngFUNCT-1K2 fs =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k inTARSKIR2 domFINSEQ-1K5 p implies fs .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k)) & fs be one-to-oneFUNCT-1V2"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds  not ( for fs be FinSequenceFINSEQ-1M1 holds  not (((domFINSEQ-1K5 fs =MEMBEREDR12 domFINSEQ-1K5 p & rngFUNCT-1K2 fs =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not fs .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k))) & fs be one-to-oneFUNCT-1V2))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    obtain ss where
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and 
      A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domFINSEQ-1K5 p"and A2: "rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"and A3: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k inTARSKIR2 domFINSEQ-1K5 p implies ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k"and A4: "ss be one-to-oneFUNCT-1V2"
      using valued_1_th_41 sorry
    have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using A1 finseq_1_def_3 sorry
    then obtain fs where 
      [ty]:"fs be FinSequenceFINSEQ-1M1" and fsDef:"fs = ss"
      using finseq_1_def_2 sorry
    have "domFINSEQ-1K5 fs =MEMBEREDR12 domFINSEQ-1K5 p"
      using A1 sorry
    thus " not ( for fs be FinSequenceFINSEQ-1M1 holds  not (((domFINSEQ-1K5 fs =MEMBEREDR12 domFINSEQ-1K5 p & rngFUNCT-1K2 fs =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (k inTARSKIR2 domFINSEQ-1K5 p &  not fs .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k))) & fs be one-to-oneFUNCT-1V2))"
      using A2 A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_42:
" for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds cardCARD-1K4 q =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q,i))"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds cardCARD-1K4 q =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q,i))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    have " ex ss be FinSubsequenceFINSEQ-1M4 st ((domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q & rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ss .FUNCT-1K1 k =XBOOLE-0R4 i +NAT-1K1 k)) & ss be one-to-oneFUNCT-1V2"
      using valued_1_th_41 sorry
    then have A1: "(domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q,domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)))are-equipotentTARSKIR3"
       sorry
    have A2: "cardCARD-1K4 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) =COMPLEX1R1 cardCARD-1K4 q"
      using card_1_th_62 sorry
    have "cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q,i))"
      using card_1_th_62 sorry
    thus "cardCARD-1K4 q =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q,i))"
      using A1 A2 card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_43:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 p =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)))"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 p =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have A1: "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
      using finseq_1_th_50 sorry
    have A2: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have A3: "domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))))"
      using finseq_1_def_3 sorry
    have " ex k be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) c=MEMBEREDR6 SegFINSEQ-1K2 k"
      using finseq_1_def_12 sorry
    then have A4: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))) =COMPLEX1R1 cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))"
      using finseq_3_th_39 sorry
    have "cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(p,i))"
      using card_1_th_62 sorry
    then have "cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) =COMPLEX1R1 lenFINSEQ-1K4 p"
      using valued_1_th_42 sorry
    thus "domFINSEQ-1K5 p =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)))"
      using A1 A2 A3 A4 relat_1_th_27 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_44:
" for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 k"
proof-
  have " for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 p"
    obtain fs where
      [ty]:"fs be FinSequenceFINSEQ-1M1" and 
      A2: "domFINSEQ-1K5 fs =MEMBEREDR12 domFINSEQ-1K5 p"and A3: "rngFUNCT-1K2 fs =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"and A4: " for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds j inTARSKIR2 domFINSEQ-1K5 p implies fs .FUNCT-1K1 j =XBOOLE-0R4 i +NAT-1K1 j"and "fs be one-to-oneFUNCT-1V2"
      using valued_1_lm_5 sorry
    have A5: " ex l be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) c=MEMBEREDR6 SegFINSEQ-1K2 l"
      using finseq_1_def_12 sorry
    have 
      [ty]:"fs be FinSequenceFINSEQ-1M3-of NATNUMBERSK1"
      using A3 finseq_1_def_4 sorry
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 fs) & k1 =COMPLEX1R1 fs .FUNCT-1K1 n) & k2 =COMPLEX1R1 fs .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
    proof-
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & (n <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 fs & (k1 =COMPLEX1R1 fs .FUNCT-1K1 n & k2 =COMPLEX1R1 fs .FUNCT-1K1 m))) implies  not k1 <XXREAL-0R3 k2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        fix k1 assume [ty]: "k1 be NatNAT-1M1"
        fix k2 assume [ty]: "k2 be NatNAT-1M1"
        assume A6: "\<one>\<^sub>M <=XXREAL-0R1 n"
          and A7: "n <XXREAL-0R3 m"
          and A8: "m <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          and A9: "k1 =COMPLEX1R1 fs .FUNCT-1K1 n"
          and A10: "k2 =COMPLEX1R1 fs .FUNCT-1K1 m"
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A11: "domFINSEQ-1K5 fs =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 fs)"
          using finseq_1_def_3 sorry
        also have "... = {n1 where n1 be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 n1 & n1 <=XXREAL-0R1 lenFINSEQ-1K4 fs }"
           sorry
        finally have "domFINSEQ-1K5 fs =HIDDENR1 {n1 where n1 be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 n1 & n1 <=XXREAL-0R1 lenFINSEQ-1K4 fs }"
           sorry
        have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using A7 int_1_th_7 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using A8 xxreal_0_th_2 sorry
        then have A12: "n <=XXREAL-0R1 lenFINSEQ-1K4 fs -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_19 sorry
        have "lenFINSEQ-1K4 fs +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 lenFINSEQ-1K4 fs +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        then have "lenFINSEQ-1K4 fs -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using xreal_1_th_20 sorry
        then have "n <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using A12 xxreal_0_th_2 sorry
        then have A13: "n inTARSKIR2 domFINSEQ-1K5 p"
          using A2 A6 A11 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 m"
          using A6 A7 xxreal_0_th_2 sorry
        then have A14: "m inTARSKIR2 domFINSEQ-1K5 p"
          using A2 A8 A11 sorry
        have A15: "k1 =COMPLEX1R1 i +NAT-1K1 n"
          using A4 A9 A13 sorry
        have "k2 =COMPLEX1R1 i +NAT-1K1 m"
          using A4 A10 A14 sorry
        thus " not k1 <XXREAL-0R3 k2"
          using A7 A15 xreal_1_th_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "fs =FINSEQ-1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))"
      using A3 A5 finseq_1_def_13 sorry
    thus "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 k"
      using A1 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_45:
" for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
proof-
  have " for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for p be FinSequenceFINSEQ-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 p"
    then have A2: "k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)))"
      using valued_1_th_43 sorry
    have "((ShiftVALUED-1K64(p,i))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))).FUNCT-1K1 k =HIDDENR1 (ShiftVALUED-1K64(p,i)).FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))) .FUNCT-1K1 k)"
      using A2 funct_1_th_12 sorry
    also have "... = (ShiftVALUED-1K64(p,i)).FUNCT-1K1 (i +NAT-1K1 k)"
      using A1 valued_1_th_44 sorry
    finally have "((ShiftVALUED-1K64(p,i))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)))).FUNCT-1K1 k =HIDDENR1 (ShiftVALUED-1K64(p,i)).FUNCT-1K1 (i +NAT-1K1 k)"
       sorry
    thus "SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) .FUNCT-1K1 k =XBOOLE-0R4 p .FUNCT-1K1 k"
      using A1 valued_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_46:
" for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) =FINSEQ-1R1 p"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M1 holds SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) =FINSEQ-1R1 p"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i))) =MEMBEREDR12 domFINSEQ-1K5 p"
      using valued_1_th_43 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 p implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) .FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x"
      using valued_1_th_45 sorry
    thus "SeqFINSEQ-1K16 (ShiftVALUED-1K64(p,i)) =FINSEQ-1R1 p"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve p1, p2 for "FinSequenceFINSEQ-1M1"
mlemma valued_1_lm_6:
" for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l or l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k implies \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix j assume [ty]: "j be NatNAT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  fix l assume [ty]: "l be NatNAT-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l or l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
  show "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
  proof-
    have cases: "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l or l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
      using A1 sorry
    have case1: "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l implies \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
    proof(rule impI)
      assume A2: "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l"
      have "l +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 l +XCMPLX-0K2 k"
        using xreal_1_th_7 sorry
      thus "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
        using A2 xxreal_0_th_2 sorry
    qed
    have case2: "l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k implies \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
    proof(rule impI)
      assume A3: "l +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
      have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 l +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_7 sorry
      thus "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 l +XCMPLX-0K2 k"
        using A3 xxreal_0_th_2 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem valued_1_th_47:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
  proof(rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =MEMBEREDR12 domFINSEQ-1K5 p1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
      using xtuple_0_th_23 sorry
    have A2: "domFINSEQ-1K5 p1 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
      using finseq_1_def_3 sorry
    also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
       sorry
    finally have "domFINSEQ-1K5 p1 =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
       sorry
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =XBOOLE-0R4 {k1 where k1 be NatNAT-1M1 : lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2 }"
      using valued_1_th_40 sorry
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2) & SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2) c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
    proof(rule conjMI)
      show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
          then have A4: "x inHIDDENR3 domFINSEQ-1K5 p1 or x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
            using A1 xboole_0_def_3 sorry
          then have A5: " ex k3 be NatNAT-1M1 st (x =HIDDENR1 k3 & \<one>\<^sub>M <=XXREAL-0R1 k3) & k3 <=XXREAL-0R1 lenFINSEQ-1K4 p1 or (x =HIDDENR1 k3 & lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k3) & k3 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
            using A2 A3 sorry
          have 
            [ty]:"x be NatNAT-1M1"
            using A4 sorry
          have A6: "\<one>\<^sub>M <=XXREAL-0R1 x"
            using A5 valued_1_lm_6 sorry
          have "x <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
            using A5 valued_1_lm_6 sorry
          thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
            using A6 sorry
        qed "sorry"
        thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
          using tarski_def_3 sorry
      qed
      have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
        then obtain j where
          [ty]:"j be NatNAT-1M1" and 
          A7: "x =HIDDENR1 j"and A8: "\<one>\<^sub>M <=XXREAL-0R1 j"and A9: "j <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
           sorry
        obtain i0 where 
          [ty]:"i0 be IntegerINT-1M1" and i0Def:"i0 = lenFINSEQ-1K4 p1"
           sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 i0 or i0 +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 i0 +XCMPLX-0K2 lenFINSEQ-1K4 p2"
          using A8 A9 int_1_th_7 sorry
        then have "x inHIDDENR3 domFINSEQ-1K5 p1 or x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
          using A2 A3 A7 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
          using A1 xboole_0_def_3 sorry
      qed "sorry"
      thus "SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2) c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
        using tarski_def_3 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_48:
" for i be NatNAT-1M1 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSubsequenceFINSEQ-1M4 holds lenFINSEQ-1K4 p1 <=XXREAL-0R1 i implies domFINSEQ-1K5 p1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
proof-
  have " for i be NatNAT-1M1 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSubsequenceFINSEQ-1M4 holds lenFINSEQ-1K4 p1 <=XXREAL-0R1 i implies domFINSEQ-1K5 p1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "lenFINSEQ-1K4 p1 <=XXREAL-0R1 i"
    have A2: "domFINSEQ-1K5 p1 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
      using finseq_1_def_3 sorry
    also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
       sorry
    finally have "domFINSEQ-1K5 p1 =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
       sorry
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p2 }"
      using valued_1_def_12 sorry
    have Cut3842: " not ( ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i)))"
    proof-
      have "( ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))) implies  False "
      proof(rule impI)
        assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A4: "x inHIDDENR3 domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
           sorry
        have A5: "x inHIDDENR3 domFINSEQ-1K5 p1"
          using A4 xboole_0_def_4 sorry
        have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
          using A4 xboole_0_def_4 sorry
        have A7: " ex k1 be NatNAT-1M1 st (x =HIDDENR1 k1 & \<one>\<^sub>M <=XXREAL-0R1 k1) & k1 <=XXREAL-0R1 lenFINSEQ-1K4 p1"
          using A2 A5 sorry
        obtain k2 where
          [ty]:"k2 be NatNAT-1M1" and 
          A8: "x =HIDDENR1 k2 +XCMPLX-0K2 i"and A9: "k2 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p2"
          using A3 A6 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A10: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p2 c=MEMBEREDR6 SegFINSEQ-1K2 n"
          using finseq_1_def_12 sorry
        have A11: "k2 inTARSKIR2 SegFINSEQ-1K2 n"
          using A9 A10 sorry
        have A12: " ex m be NatNAT-1M1 st (k2 =COMPLEX1R1 m & \<one>\<^sub>M <=XXREAL-0R1 m) & m <=XXREAL-0R1 n"
          using A11 sorry
        have 
          [ty]:"x be ElementSUBSET-1M1-of NATNUMBERSK1"
          using A4 sorry
        have "lenFINSEQ-1K4 p1 +XCMPLX-0K2 k2 <=XXREAL-0R1 i +XCMPLX-0K2 k2"
          using A1 xreal_1_th_7 sorry
        then have "(lenFINSEQ-1K4 p1 +XCMPLX-0K2 k2)-XCMPLX-0K6 k2 <XXREAL-0R3 x -XCMPLX-0K6 0NUMBERSK6"
          using A8 A12 xreal_1_th_15 sorry
        thus " False "
          using A7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i)) =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      show "domFINSEQ-1K5 p1 /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i)) =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_0_def_1 Cut3842 sorry
    qed
    thus "domFINSEQ-1K5 p1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_49:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 ^FINSEQ-1K8 p2 =RELAT-1R1 p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds p1 ^FINSEQ-1K8 p2 =RELAT-1R1 p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
  proof(rule ballI,rule ballI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
      using valued_1_th_47 sorry
    have "domFINSEQ-1K5 p1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
      using valued_1_th_48 sorry
    then obtain p where 
      [ty]:"p be FinSequenceFINSEQ-1M1" and pDef:"p = p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
      using A1 finseq_1_def_2 grfunc_1_th_13 sorry
    have A2: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
      using valued_1_th_47 sorry
    have A3: " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p1 implies p .FUNCT-1K1 k =XBOOLE-0R4 p1 .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k inTARSKIR2 domFINSEQ-1K5 p1"
      then have "[TARSKIK4 k,p1 .FUNCT-1K1 k ] inHIDDENR3 p1"
        using funct_1_def_2 sorry
      then have "[TARSKIK4 k,p1 .FUNCT-1K1 k ] inHIDDENR3 p"
        using xboole_0_def_3 sorry
      thus "p .FUNCT-1K1 k =XBOOLE-0R4 p1 .FUNCT-1K1 k"
        using funct_1_th_1 sorry
    qed "sorry"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p2 implies p .FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k) =XBOOLE-0R4 p2 .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "k inTARSKIR2 domFINSEQ-1K5 p2"
      have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =XBOOLE-0R4 {j +NAT-1K1 lenFINSEQ-1K4 p1 where j be NatNAT-1M1 : j inTARSKIR2 domFINSEQ-1K5 p2 }"
        using valued_1_def_12 sorry
      then have "lenFINSEQ-1K4 p1 +XCMPLX-0K2 k inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
        using A4 sorry
      then have "[TARSKIK4 lenFINSEQ-1K4 p1 +XCMPLX-0K2 k,(ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)).FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k) ] inHIDDENR3 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
        using funct_1_def_2 sorry
      then have "[TARSKIK4 lenFINSEQ-1K4 p1 +XCMPLX-0K2 k,(ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)).FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k) ] inHIDDENR3 p"
        using xboole_0_def_3 sorry
      then have "p .FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k) =XBOOLE-0R4 (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)).FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k)"
        using funct_1_th_1 sorry
      thus "p .FUNCT-1K1 (lenFINSEQ-1K4 p1 +XCMPLX-0K2 k) =XBOOLE-0R4 p2 .FUNCT-1K1 k"
        using A4 valued_1_def_12 sorry
    qed "sorry"
    thus "p1 ^FINSEQ-1K8 p2 =RELAT-1R1 p1 \\/XBOOLE-0K2 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
      using A2 A3 finseq_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_50:
" for i be NatNAT-1M1 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSubsequenceFINSEQ-1M4 holds i >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies p1 missesXBOOLE-0R1 ShiftVALUED-1K64(p2,i)"
proof-
  have " for i be NatNAT-1M1 holds  for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSubsequenceFINSEQ-1M4 holds i >=XXREAL-0R2 lenFINSEQ-1K4 p1 implies p1 missesXBOOLE-0R1 ShiftVALUED-1K64(p2,i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSubsequenceFINSEQ-1M4"
    assume "i >=XXREAL-0R2 lenFINSEQ-1K4 p1"
    then have "domFINSEQ-1K5 p1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,i))"
      using valued_1_th_48 sorry
    thus "p1 missesXBOOLE-0R1 ShiftVALUED-1K64(p2,i)"
      using relat_1_th_179 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_51:
" for F be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ShiftVALUED-1K64(p,n) c=RELAT-1R2 F implies ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies F .FUNCT-1K1 (n +NAT-1K1 i) =XBOOLE-0R4 p .FUNCT-1K1 i)"
proof-
  have " for F be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for p be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ShiftVALUED-1K64(p,n) c=RELAT-1R2 F implies ( for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p implies F .FUNCT-1K1 (n +NAT-1K1 i) =HIDDENR1 p .FUNCT-1K1 i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix F assume [ty]: "F be totalPARTFUN1V1\<^bsub>(NATNUMBERSK1)\<^esub>\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    fix p assume [ty]: "p be NATNUMBERSK1 -definedRELAT-1V4\<bar>FunctionFUNCT-1M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "ShiftVALUED-1K64(p,n) c=RELAT-1R2 F"
    fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A2: "i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> p"
    then have "n +NAT-1K1 i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,n))"
      using valued_1_th_24 sorry
    then have "F .FUNCT-1K1 (n +NAT-1K1 i) =HIDDENR1 (ShiftVALUED-1K64(p,n)).FUNCT-1K1 (n +NAT-1K1 i)"
      using A1 grfunc_1_th_2 sorry
    also have "... = p .FUNCT-1K1 i"
      using A2 valued_1_def_12 sorry
    finally show "F .FUNCT-1K1 (n +NAT-1K1 i) =HIDDENR1 p .FUNCT-1K1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_52:
" for i be NatNAT-1M1 holds  for p be FinSubsequenceFINSEQ-1M4 holds  for q be FinSubsequenceFINSEQ-1M4 holds q c=RELAT-1R2 p implies ShiftVALUED-1K64(q,i) c=RELAT-1R2 ShiftVALUED-1K64(p,i)"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSubsequenceFINSEQ-1M4 holds  for q be FinSubsequenceFINSEQ-1M4 holds q c=RELAT-1R2 p implies ShiftVALUED-1K64(q,i) c=RELAT-1R2 ShiftVALUED-1K64(p,i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSubsequenceFINSEQ-1M4"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    assume A1: "q c=RELAT-1R2 p"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q }"
      using valued_1_def_12 sorry
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p }"
      using valued_1_def_12 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i) implies [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(p,i)"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume A4: "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i)"
      then have A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
        using funct_1_th_1 sorry
      have A6: "y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
        using A4 funct_1_th_1 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A7: "x =HIDDENR1 k +XCMPLX-0K2 i"and A8: "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
        using A2 A5 sorry
      have A9: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
        using A1 grfunc_1_th_2 sorry
      then have A10: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
        using A3 A7 A8 sorry
      have "y =HIDDENR1 q .FUNCT-1K1 k"
        using A6 A7 A8 valued_1_def_12 sorry
      also have "... = p .FUNCT-1K1 k"
        using A1 A8 grfunc_1_th_2 sorry
      also have "... = (ShiftVALUED-1K64(p,i)).FUNCT-1K1 x"
        using A7 A8 A9 valued_1_def_12 sorry
      finally have "y =HIDDENR1 (ShiftVALUED-1K64(p,i)).FUNCT-1K1 x"
         sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(p,i)"
        using A10 funct_1_th_1 sorry
    qed "sorry"
    thus "ShiftVALUED-1K64(q,i) c=RELAT-1R2 ShiftVALUED-1K64(p,i)"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_53:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1) c=RELAT-1R2 p1 ^FINSEQ-1K8 p2"
proof(rule ballI,rule ballI)
  fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
  fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
  have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =XBOOLE-0R4 {k +NAT-1K1 lenFINSEQ-1K4 p1 where k be NatNAT-1M1 : k inTARSKIR2 domFINSEQ-1K5 p2 }"
    using valued_1_def_12 sorry
  have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =XBOOLE-0R4 {k where k be NatNAT-1M1 : lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2 }"
    using valued_1_th_40 sorry
  have A3: "domFINSEQ-1K5 (p1 ^FINSEQ-1K8 p2) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2)"
    using finseq_1_def_7 sorry
  also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2 }"
     sorry
  finally have "domFINSEQ-1K5 (p1 ^FINSEQ-1K8 p2) =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2 }"
     sorry
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1) implies [TARSKIK4 x,y ] inHIDDENR3 p1 ^FINSEQ-1K8 p2"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A4: "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)"
    then have A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
      using funct_1_th_1 sorry
    have A6: "y =HIDDENR1 (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)).FUNCT-1K1 x"
      using A4 funct_1_th_1 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A7: "x =HIDDENR1 k"and A8: "lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"and A9: "k <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
      using A2 A5 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M"
      using int_1_th_6 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 k"
      using A8 xxreal_0_th_2 sorry
    then have A10: "x inHIDDENR3 domFINSEQ-1K5 (p1 ^FINSEQ-1K8 p2)"
      using A3 A7 A9 sorry
    obtain j where
      [ty]:"j be NatNAT-1M1" and 
      A11: "x =HIDDENR1 j +NAT-1K1 lenFINSEQ-1K4 p1"and A12: "j inTARSKIR2 domFINSEQ-1K5 p2"
      using A1 A5 sorry
    have "y =HIDDENR1 p2 .FUNCT-1K1 j"
      using A6 A11 A12 valued_1_def_12 sorry
    also have "... = (p1 ^FINSEQ-1K8 p2).FUNCT-1K1 x"
      using A11 A12 finseq_1_def_7 sorry
    finally have "y =HIDDENR1 (p1 ^FINSEQ-1K8 p2).FUNCT-1K1 x"
       sorry
    thus "[TARSKIK4 x,y ] inHIDDENR3 p1 ^FINSEQ-1K8 p2"
      using A10 funct_1_th_1 sorry
  qed "sorry"
  thus "ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1) c=RELAT-1R2 p1 ^FINSEQ-1K8 p2"
    using relat_1_def_3 sorry
qed "sorry"

reserve q, q1, q2, q3, q4 for "FinSubsequenceFINSEQ-1M4"
mtheorem valued_1_th_54:
" for i be NatNAT-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2 implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
proof-
  have " for i be NatNAT-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2 implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 }"
      using valued_1_def_12 sorry
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2 }"
      using valued_1_def_12 sorry
    have Cut3992: "( ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))) implies  False "
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
         sorry
      have A5: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i))"
        using A4 xboole_0_def_4 sorry
      have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
        using A4 xboole_0_def_4 sorry
      have A7: " ex k1 be NatNAT-1M1 st x =HIDDENR1 k1 +XCMPLX-0K2 i & k1 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1"
        using A2 A5 sorry
      obtain k2 where
        [ty]:"k2 be NatNAT-1M1" and 
        A8: "x =HIDDENR1 k2 +XCMPLX-0K2 i"and A9: "k2 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
        using A3 A6 sorry
      have "k2 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 /\\SUBSET-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
        using A7 A8 A9 xboole_0_def_4 sorry
      thus " False "
        using A1 sorry
    qed
    have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) =XBOOLE-0R4 {}XBOOLE-0K1"
    proof-
      show "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) /\\SUBSET-1K9\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) =XBOOLE-0R4 {}XBOOLE-0K1"
        using xboole_0_def_1 Cut3992 sorry
    qed
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_55:
" for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q =RELAT-1R1 q1 \\/XBOOLE-0K2 q2 & q1 missesXBOOLE-0R1 q2 implies ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i) =RELAT-1R1 ShiftVALUED-1K64(q,i)"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q =RELAT-1R1 q1 \\/XBOOLE-0K2 q2 & q1 missesXBOOLE-0R1 q2 implies ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i) =RELAT-1R1 ShiftVALUED-1K64(q,i)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "q =RELAT-1R1 q1 \\/XBOOLE-0K2 q2"
      and A2: "q1 missesXBOOLE-0R1 q2"
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q }"
      using valued_1_def_12 sorry
    have A4: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 }"
      using valued_1_def_12 sorry
    have A5: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2 }"
      using valued_1_def_12 sorry
    have A6: "q1 c=RELAT-1R2 q"
      using A1 xboole_1_th_7 sorry
    have A7: "q2 c=RELAT-1R2 q"
      using A1 xboole_1_th_7 sorry
    have A8: "ShiftVALUED-1K64(q1,i) c=RELAT-1R2 ShiftVALUED-1K64(q,i)"
      using A1 valued_1_th_52 xboole_1_th_7 sorry
    have A9: "ShiftVALUED-1K64(q2,i) c=RELAT-1R2 ShiftVALUED-1K64(q,i)"
      using A1 valued_1_th_52 xboole_1_th_7 sorry
    have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 missesMEMBEREDR18 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
      using A2 A6 A7 funct_1_th_112 sorry
    then have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
      using valued_1_th_54 sorry
    then obtain q3 where 
      [ty]:"q3 be FunctionFUNCT-1M1" and q3Def:"q3 = ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i)"
      using grfunc_1_th_13 sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i) implies [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i)) & ([TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i) implies [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i))"
    proof(rule ballI,rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      show "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i) implies [TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i)"
      proof(rule impI)
        assume A10: "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i)"
        then have "x inHIDDENR3 domRELAT-1K1 q3"
          using funct_1_th_1 sorry
        then have A11: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
          using xtuple_0_th_23 sorry
        have A12: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) & y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
        proof(rule impI)
          assume A13: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i))"
          have A14: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
            using A8 grfunc_1_th_2 sorry
          have "(ShiftVALUED-1K64(q1,i)).FUNCT-1K1 x =XBOOLE-0R4 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
            using A8 A13 grfunc_1_th_2 sorry
          then have "[TARSKIK4 x,(ShiftVALUED-1K64(q,i)).FUNCT-1K1 x ] inHIDDENR3 ShiftVALUED-1K64(q1,i)"
            using A13 funct_1_def_2 sorry
          then have "[TARSKIK4 x,(ShiftVALUED-1K64(q,i)).FUNCT-1K1 x ] inHIDDENR3 q3"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) & y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
            using A10 A13 A14 funct_1_def_1 sorry
        qed
        have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) & y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
        proof(rule impI)
          assume A15: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
          have A16: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
            using A9 grfunc_1_th_2 sorry
          have "(ShiftVALUED-1K64(q2,i)).FUNCT-1K1 x =XBOOLE-0R4 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
            using A9 A15 grfunc_1_th_2 sorry
          then have "[TARSKIK4 x,(ShiftVALUED-1K64(q,i)).FUNCT-1K1 x ] inHIDDENR3 ShiftVALUED-1K64(q2,i)"
            using A15 funct_1_def_2 sorry
          then have "[TARSKIK4 x,(ShiftVALUED-1K64(q,i)).FUNCT-1K1 x ] inHIDDENR3 q3"
            using xboole_0_def_3 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) & y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
            using A10 A15 A16 funct_1_def_1 sorry
        qed
        thus "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i)"
          using A11 A12 funct_1_th_1 xboole_0_def_3 sorry
      qed
      assume A17: "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q,i)"
      then have A18: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
        using funct_1_th_1 sorry
      have A19: "y =HIDDENR1 (ShiftVALUED-1K64(q,i)).FUNCT-1K1 x"
        using A17 funct_1_th_1 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A20: "x =HIDDENR1 k +XCMPLX-0K2 i"and A21: "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
        using A3 A18 sorry
      have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(omegaORDINAL1K4)\<^esub> domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
        using A1 xtuple_0_th_23 sorry
      then have A22: "k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 or k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
        using A21 xboole_0_def_3 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) or x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
        using A4 A5 A20 sorry
      then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
        using xboole_0_def_3 sorry
      then have A23: "x inHIDDENR3 domRELAT-1K1 q3"
        using xtuple_0_th_23 sorry
      have A24: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i)) implies y =HIDDENR1 q3 .FUNCT-1K1 x"
      proof(rule impI)
        assume A25: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q1,i))"
        then have A26: " ex k1 be NatNAT-1M1 st x =HIDDENR1 k1 +XCMPLX-0K2 i & k1 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1"
          using A4 sorry
        have "y =HIDDENR1 q .FUNCT-1K1 k"
          using A19 A20 A21 valued_1_def_12 sorry
        also have "... = q1 .FUNCT-1K1 k"
          using A1 A20 A26 grfunc_1_th_15 sorry
        also have "... = (ShiftVALUED-1K64(q1,i)).FUNCT-1K1 x"
          using A20 A26 valued_1_def_12 sorry
        also have "... = q3 .FUNCT-1K1 x"
          using A25 grfunc_1_th_15 sorry
        finally show "y =HIDDENR1 q3 .FUNCT-1K1 x"
           sorry
      qed
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i)) implies y =HIDDENR1 q3 .FUNCT-1K1 x"
      proof(rule impI)
        assume A27: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,i))"
        then have A28: " ex k2 be NatNAT-1M1 st x =HIDDENR1 k2 +XCMPLX-0K2 i & k2 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2"
          using A5 sorry
        have "y =HIDDENR1 q .FUNCT-1K1 k"
          using A19 A20 A21 valued_1_def_12 sorry
        also have "... = q2 .FUNCT-1K1 k"
          using A1 A20 A28 grfunc_1_th_15 sorry
        also have "... = (ShiftVALUED-1K64(q2,i)).FUNCT-1K1 x"
          using A20 A28 valued_1_def_12 sorry
        also have "... = q3 .FUNCT-1K1 x"
          using A27 grfunc_1_th_15 sorry
        finally show "y =HIDDENR1 q3 .FUNCT-1K1 x"
           sorry
      qed
      thus "[TARSKIK4 x,y ] inHIDDENR3 ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i)"
        using A4 A5 A20 A22 A23 A24 funct_1_th_1 sorry
    qed "sorry"
    thus "ShiftVALUED-1K64(q1,i) \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,i) =RELAT-1R1 ShiftVALUED-1K64(q,i)"
      using relat_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_56:
" for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    have A1: "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q) =COMPLEX1R1 cardCARD-1K4 q"
      using finseq_3_th_158 sorry
    have A2: "lenFINSEQ-1K4 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i))) =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q,i))"
      using finseq_3_th_158 sorry
    have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q))"
      using finseq_1_def_3 sorry
    also have "... = domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
      using valued_1_th_42 A1 A2 finseq_1_def_3 sorry
    finally show "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve l1 for "NatNAT-1M1"
mtheorem valued_1_th_57:
" for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies ( ex j be ElementSUBSET-1M1-of NATNUMBERSK1 st j =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 k & SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 j)"
proof-
  have " for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies  not ( for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (j =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 k & SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 j))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q)"
    obtain ss where
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and 
      A2: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"and A3: "rngFUNCT-1K2 ss =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"and A4: " for l be ElementSUBSET-1M1-of NATNUMBERSK1 holds l inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q implies ss .FUNCT-1K1 l =XBOOLE-0R4 i +NAT-1K1 l"and "ss be one-to-oneFUNCT-1V2"
      using valued_1_th_41 sorry
    have A5: "rngFUNCT-1K2 (SeqFINSEQ-1K16 ss) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
      using A3 finseq_1_th_101 sorry
    have A6: "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q)) =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
      using finseq_1_th_50 sorry
    have A7: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (q *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
       sorry
    also have "... = domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
      using A6 relat_1_th_27 sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
       sorry
    have A8: " for l1 be NatNAT-1M1 holds l1 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies ( ex j1 be ElementSUBSET-1M1-of NATNUMBERSK1 st j1 =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1 & SeqFINSEQ-1K16 ss .FUNCT-1K1 l1 =XBOOLE-0R4 i +NAT-1K1 j1)"
    proof-
      have " for l1 be NatNAT-1M1 holds l1 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies  not ( for j1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (j1 =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1 & SeqFINSEQ-1K16 ss .FUNCT-1K1 l1 =XBOOLE-0R4 i +NAT-1K1 j1))"
      proof(rule ballI,rule impI)
        fix l1 assume [ty]: "l1 be NatNAT-1M1"
        assume A9: "l1 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q)"
        have A10: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1 inTARSKIR2 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
          using A7 A9 funct_1_def_3 sorry
        then have A11: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
          using finseq_1_th_50 sorry
        obtain j1 where 
          [ty]:"j1 be ElementSUBSET-1M1-of NATNUMBERSK1" and j1Def:"j1 = SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1"
          using A10 sorry
        have "SeqFINSEQ-1K16 ss .FUNCT-1K1 l1 =HIDDENR1 (ss *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss)).FUNCT-1K1 l1"
           sorry
        also have "... = ss .FUNCT-1K1 j1"
          using A2 A7 A9 funct_1_th_13 sorry
        also have "... = i +NAT-1K1 j1"
          using A4 A11 sorry
        finally have "SeqFINSEQ-1K16 ss .FUNCT-1K1 l1 =HIDDENR1 i +NAT-1K1 j1"
           sorry
        thus " not ( for j1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (j1 =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 l1 & SeqFINSEQ-1K16 ss .FUNCT-1K1 l1 =XBOOLE-0R4 i +NAT-1K1 j1))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: "rngFUNCT-1K2 ss =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))))"
      using A3 finseq_1_th_50 sorry
    have "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)))) c=MEMBEREDR6 NATNUMBERSK1"
       sorry
    then have "rngFUNCT-1K2 (SeqFINSEQ-1K16 ss) c=TARSKIR1 NATNUMBERSK1"
      using A12 finseq_1_th_101 sorry
    then obtain fs where 
      [ty]:"fs be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and fsDef:"fs = SeqFINSEQ-1K16 ss"
      using finseq_1_def_4 sorry
    have A13: " ex l2 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 SegFINSEQ-1K2 l2"
      using finseq_1_def_12 sorry
    have A14: "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =HIDDENR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (ss *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss))"
       sorry
    also have "... = domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
      using A2 A6 relat_1_th_27 sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =HIDDENR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
       sorry
    have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds (((\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 m) & m <=XXREAL-0R1 lenFINSEQ-1K4 fs) & k1 =COMPLEX1R1 fs .FUNCT-1K1 n) & k2 =COMPLEX1R1 fs .FUNCT-1K1 m implies k1 <XXREAL-0R3 k2"
    proof-
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & (n <XXREAL-0R3 m & (m <=XXREAL-0R1 lenFINSEQ-1K4 fs & (k1 =COMPLEX1R1 fs .FUNCT-1K1 n & k2 =COMPLEX1R1 fs .FUNCT-1K1 m))) implies  not k1 <XXREAL-0R3 k2"
      proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        fix k1 assume [ty]: "k1 be NatNAT-1M1"
        fix k2 assume [ty]: "k2 be NatNAT-1M1"
        assume A15: "\<one>\<^sub>M <=XXREAL-0R1 n"
          and A16: "n <XXREAL-0R3 m"
          and A17: "m <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          and A18: "k1 =COMPLEX1R1 fs .FUNCT-1K1 n"
          and A19: "k2 =COMPLEX1R1 fs .FUNCT-1K1 m"
        have 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A20: "domFINSEQ-1K5 fs =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 fs)"
          using finseq_1_def_3 sorry
        also have "... = {l3 where l3 be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 l3 & l3 <=XXREAL-0R1 lenFINSEQ-1K4 fs }"
           sorry
        finally have "domFINSEQ-1K5 fs =HIDDENR1 {l3 where l3 be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 l3 & l3 <=XXREAL-0R1 lenFINSEQ-1K4 fs }"
           sorry
        have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using A16 int_1_th_7 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using A17 xxreal_0_th_2 sorry
        then have A21: "n <=XXREAL-0R1 lenFINSEQ-1K4 fs -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_19 sorry
        have "lenFINSEQ-1K4 fs +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 lenFINSEQ-1K4 fs +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        then have "lenFINSEQ-1K4 fs -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using xreal_1_th_20 sorry
        then have "n <=XXREAL-0R1 lenFINSEQ-1K4 fs"
          using A21 xxreal_0_th_2 sorry
        then have A22: "n inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q)"
          using A7 A14 A15 A20 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 m"
          using A15 A16 xxreal_0_th_2 sorry
        then have A23: "m inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q)"
          using A7 A14 A17 A20 sorry
        obtain j2 where
          [ty]:"j2 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A24: "j2 =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 n"and A25: "fs .FUNCT-1K1 n =COMPLEX1R1 i +NAT-1K1 j2"
          using A8 A22 sorry
        obtain j3 where
          [ty]:"j3 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A26: "j3 =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 m"and A27: "fs .FUNCT-1K1 m =COMPLEX1R1 i +NAT-1K1 j3"
          using A8 A23 sorry
        have A28: " ex l3 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 SegFINSEQ-1K2 l3"
          using finseq_1_def_12 sorry
        have "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 fs)"
          using finseq_1_def_3 sorry
        then have "lenFINSEQ-1K4 fs =COMPLEX1R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
          using A14 finseq_1_def_3 sorry
        then have "j2 <XXREAL-0R3 j3"
          using A15 A16 A17 A24 A26 A28 finseq_1_def_13 sorry
        thus " not k1 <XXREAL-0R3 k2"
          using A18 A19 A25 A27 xreal_1_th_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "fs =FINSEQ-1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)))"
      using A5 A13 finseq_1_def_13 sorry
    thus " not ( for j be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (j =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 k & SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 j))"
      using A1 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_58:
" for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 k =XBOOLE-0R4 SeqFINSEQ-1K16 q .FUNCT-1K1 k"
proof-
  have " for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 k =XBOOLE-0R4 SeqFINSEQ-1K16 q .FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    assume A1: "k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q)"
    then obtain j where
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A2: "j =COMPLEX1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q) .FUNCT-1K1 k"and A3: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) .FUNCT-1K1 k =COMPLEX1R1 i +NAT-1K1 j"
      using valued_1_th_57 sorry
    have A4: "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q)) =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
      using finseq_1_th_50 sorry
    have A5: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
      using valued_1_th_56 sorry
    also have "... = domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ((ShiftVALUED-1K64(q,i))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))))"
       sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ((ShiftVALUED-1K64(q,i))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))))"
       sorry
    have A6: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> (q *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
       sorry
    also have "... = domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
      using A4 relat_1_th_27 sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =HIDDENR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
       sorry
    then have "j inTARSKIR2 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q))"
      using A1 A2 funct_1_def_3 sorry
    then have A7: "j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
      using finseq_1_th_50 sorry
    have "SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 k =HIDDENR1 ((ShiftVALUED-1K64(q,i))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)))).FUNCT-1K1 k"
       sorry
    also have "... = (ShiftVALUED-1K64(q,i)).FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))) .FUNCT-1K1 k)"
      using A1 A5 funct_1_th_12 sorry
    also have "... = q .FUNCT-1K1 j"
      using A3 A7 valued_1_def_12 sorry
    also have "... = (q *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q)).FUNCT-1K1 k"
      using A1 A2 A6 funct_1_th_13 sorry
    also have "... = SeqFINSEQ-1K16 q .FUNCT-1K1 k"
       sorry
    finally have "SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 k =HIDDENR1 SeqFINSEQ-1K16 q .FUNCT-1K1 k"
       sorry
    thus "SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 k =XBOOLE-0R4 SeqFINSEQ-1K16 q .FUNCT-1K1 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_59:
" for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds SeqFINSEQ-1K16 q =FINSEQ-1R1 SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i))"
proof-
  have " for i be NatNAT-1M1 holds  for q be FinSubsequenceFINSEQ-1M4 holds SeqFINSEQ-1K16 q =FINSEQ-1R1 SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    have A1: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q) =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)))"
      using valued_1_th_56 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q) implies SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i)) .FUNCT-1K1 x =XBOOLE-0R4 SeqFINSEQ-1K16 q .FUNCT-1K1 x"
      using valued_1_th_58 sorry
    thus "SeqFINSEQ-1K16 q =FINSEQ-1R1 SeqFINSEQ-1K16 (ShiftVALUED-1K64(q,i))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_60:
" for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 SegFINSEQ-1K2 k implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 SegFINSEQ-1K2 (i +NAT-1K1 k)"
proof-
  have " for i be NatNAT-1M1 holds  for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for q be FinSubsequenceFINSEQ-1M4 holds domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 SegFINSEQ-1K2 k implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 SegFINSEQ-1K2 (i +NAT-1K1 k)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    assume A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 SegFINSEQ-1K2 k"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) =XBOOLE-0R4 {j +XCMPLX-0K2 i where j be NatNAT-1M1 : j inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q }"
      using valued_1_def_12 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) implies x inHIDDENR3 SegFINSEQ-1K2 (i +NAT-1K1 k)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
      then obtain j1 where
        [ty]:"j1 be NatNAT-1M1" and 
        A3: "x =HIDDENR1 j1 +XCMPLX-0K2 i"and A4: "j1 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
        using A2 sorry
      have "j1 inTARSKIR2 SegFINSEQ-1K2 k"
        using A1 A4 sorry
      then have A5: " ex j2 be NatNAT-1M1 st (j1 =COMPLEX1R1 j2 & \<one>\<^sub>M <=XXREAL-0R1 j2) & j2 <=XXREAL-0R1 k"
         sorry
      have A6: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 j1"
        using A5 xreal_1_th_7 sorry
      have "i +XCMPLX-0K2 j1 <=XXREAL-0R1 i +NAT-1K1 k"
        using A5 xreal_1_th_7 sorry
      thus "x inHIDDENR3 SegFINSEQ-1K2 (i +NAT-1K1 k)"
        using A3 A6 sorry
    qed "sorry"
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 SegFINSEQ-1K2 (i +NAT-1K1 k)"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_61:
" for p be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p implies ( ex ss be FinSubsequenceFINSEQ-1M4 st ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p))"
proof-
  have " for p be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p implies ( ex tVar18 be FinSubsequenceFINSEQ-1M4 st tVar18 =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M1"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume "q1 c=RELAT-1R2 p"
    then have A1: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 domFINSEQ-1K5 p"
      using grfunc_1_th_2 sorry
    have "domFINSEQ-1K5 p missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p))"
      using valued_1_th_48 sorry
    then obtain ss where 
      [ty]:"ss be FunctionFUNCT-1M1" and ssDef:"ss = q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)"
      using A1 grfunc_1_th_13 xboole_1_th_63 sorry
    have A2: "domFINSEQ-1K5 p =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    obtain k where
      [ty]:"k be NatNAT-1M1" and 
      A3: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q2 c=MEMBEREDR6 SegFINSEQ-1K2 k"
      using finseq_1_def_12 sorry
    have "k inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    then have A4: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using A3 valued_1_th_60 sorry
    have "lenFINSEQ-1K4 p +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 lenFINSEQ-1K4 p +XCMPLX-0K2 k"
      using xreal_1_th_7 sorry
    then have "SegFINSEQ-1K2 (lenFINSEQ-1K4 p) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using finseq_1_th_5 sorry
    then have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using A1 A2 sorry
    then have "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using A4 xboole_1_th_8 sorry
    then have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)) c=MEMBEREDR6 SegFINSEQ-1K2 (lenFINSEQ-1K4 p +XCMPLX-0K2 k)"
      using xtuple_0_th_23 sorry
    then have 
      [ty]:"ss be FinSubsequenceFINSEQ-1M4"
      using finseq_1_def_12 sorry
    show " ex tVar18 be FinSubsequenceFINSEQ-1M4 st tVar18 =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)"
    proof(rule bexI[of _ "ss"])
      show "ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p)"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma valued_1_lm_7:
" for i be NatNAT-1M1 holds  for p be FinSubsequenceFINSEQ-1M4 holds  for q be FinSubsequenceFINSEQ-1M4 holds q c=RELAT-1R2 p implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
proof-
  have " for i be NatNAT-1M1 holds  for p be FinSubsequenceFINSEQ-1M4 holds  for q be FinSubsequenceFINSEQ-1M4 holds q c=RELAT-1R2 p implies domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSubsequenceFINSEQ-1M4"
    fix q assume [ty]: "q be FinSubsequenceFINSEQ-1M4"
    assume A1: "q c=RELAT-1R2 p"
    have A2: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q }"
      using valued_1_def_12 sorry
    have A3: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i)) =XBOOLE-0R4 {k +XCMPLX-0K2 i where k be NatNAT-1M1 : k inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p }"
      using valued_1_def_12 sorry
    have A4: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q c=MEMBEREDR6 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> p"
      using A1 grfunc_1_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i))"
      then have " ex k1 be NatNAT-1M1 st x =HIDDENR1 k1 +XCMPLX-0K2 i & k1 inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q"
        using A2 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
        using A3 A4 sorry
    qed "sorry"
    thus "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q,i)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p,i))"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma valued_1_lm_8:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) =FINSEQ-1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
  fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
  fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
  fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
  assume A1: "q1 c=RELAT-1R2 p1"
    and A2: "q2 c=RELAT-1R2 p2"
  have A3: " ex k1 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 SegFINSEQ-1K2 k1"
    using finseq_1_def_12 sorry
  have A4: " ex k2 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 k2"
    using finseq_1_def_12 sorry
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 & n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) implies m <XXREAL-0R3 n"
  proof-
    have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 & n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) implies  not m <XXREAL-0R3 n"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A5: "m inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1"
        and A6: "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))"
      have A7: "domFINSEQ-1K5 p1 =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 p1)"
        using finseq_1_def_3 sorry
      also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
         sorry
      finally have "domFINSEQ-1K5 p1 =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 }"
         sorry
      have A8: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1)) =XBOOLE-0R4 {k where k be NatNAT-1M1 : lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2 }"
        using valued_1_th_40 sorry
      have A9: "domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 domFINSEQ-1K5 p1"
        using A1 grfunc_1_th_2 sorry
      have A10: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
        using A2 valued_1_lm_7 sorry
      have A11: "m inTARSKIR2 domFINSEQ-1K5 p1"
        using A5 A9 sorry
      have A12: "n inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(p2,lenFINSEQ-1K4 p1))"
        using A6 A10 sorry
      obtain k3 where
        [ty]:"k3 be NatNAT-1M1" and 
        A13: "k3 =COMPLEX1R1 m"and "\<one>\<^sub>M <=XXREAL-0R1 k3"and A14: "k3 <=XXREAL-0R1 lenFINSEQ-1K4 p1"
        using A7 A11 sorry
      obtain k4 where
        [ty]:"k4 be NatNAT-1M1" and 
        A15: "k4 =COMPLEX1R1 n"and A16: "lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k4"and "k4 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 lenFINSEQ-1K4 p2"
        using A8 A12 sorry
      have "lenFINSEQ-1K4 p1 <XXREAL-0R3 lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_29 sorry
      then have "k3 <=XXREAL-0R1 lenFINSEQ-1K4 p1 +NAT-1K1 \<one>\<^sub>M"
        using A14 xxreal_0_th_2 sorry
      then have A17: "k3 <=XXREAL-0R1 k4"
        using A16 xxreal_0_th_2 sorry
      have "k3 <>HIDDENR2 k4"
        using A5 A6 A9 A13 A15 valued_1_th_48 xboole_0_th_3 sorry
      thus " not m <XXREAL-0R3 n"
        using A13 A15 A17 xxreal_0_th_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) =FINSEQ-1R1 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))"
    using A3 A4 finseq_3_th_42 sorry
qed "sorry"

mtheorem valued_1_th_62:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies ( ex ss be FinSubsequenceFINSEQ-1M4 st ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)))"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies  not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "q1 c=RELAT-1R2 p1"
      and A2: "q2 c=RELAT-1R2 p2"
    obtain ss where
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and 
      A3: "ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)"
      using A1 valued_1_th_61 sorry
    have A4: " ex k1 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 SegFINSEQ-1K2 k1"
      using finseq_1_def_12 sorry
    have A5: " ex k2 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 k2"
      using finseq_1_def_12 sorry
    have A6: "rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss)) =MEMBEREDR12 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss"
      using finseq_1_th_50 sorry
    have A7: "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =HIDDENR1 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss))"
      using A6 relat_1_th_27 sorry
    also have "... = domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
      using A3 xtuple_0_th_23 sorry
    also have "... = domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
      using A1 A2 valued_1_lm_8 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)) +NAT-1K1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))))"
      using finseq_1_def_7 sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)) +NAT-1K1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))))"
       sorry
    have A8: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))) =COMPLEX1R1 cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))"
      using A5 finseq_3_th_39 sorry
    have A9: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)) =COMPLEX1R1 cardCARD-1K4 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)"
      using A4 finseq_3_th_39 sorry
    have "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))) =COMPLEX1R1 cardCARD-1K4 (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))"
      using A8 card_1_th_62 sorry
    then have A10: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))) =COMPLEX1R1 cardCARD-1K4 q2"
      using valued_1_th_42 sorry
    have A11: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)) =COMPLEX1R1 cardCARD-1K4 q1"
      using A9 card_1_th_62 sorry
    have A12: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))) =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
      using A10 finseq_3_th_158 sorry
    have "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)) =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)"
      using A11 finseq_3_th_158 sorry
    thus " not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))))"
      using A3 A7 A12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_63:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies ( ex ss be FinSubsequenceFINSEQ-1M4 st (ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))) & SeqFINSEQ-1K16 ss =RELAT-1R1 SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies  not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not ((ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))) & SeqFINSEQ-1K16 ss =RELAT-1R1 SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "q1 c=RELAT-1R2 p1"
      and A2: "q2 c=RELAT-1R2 p2"
    obtain ss where
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and 
      A3: "ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)"and A4: "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
      using A1 A2 valued_1_th_62 sorry
    have A5: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))"
      using finseq_1_def_3 sorry
    also have "... = {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) }"
       sorry
    finally have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) =HIDDENR1 {k where k be NatNAT-1M1 : \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) }"
       sorry
    have A6: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) =XBOOLE-0R4 {k where k be NatNAT-1M1 : lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2) }"
      using valued_1_th_40 sorry
    have A7: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
    proof-
      have "SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) c=MEMBEREDR6 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) & domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
      proof(rule conjMI)
        show "SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) c=MEMBEREDR6 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) implies x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
            then obtain k1 where
              [ty]:"k1 be NatNAT-1M1" and 
              A8: "x =HIDDENR1 k1"and A9: "\<one>\<^sub>M <=XXREAL-0R1 k1"and A10: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
               sorry
            have A11: "\<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) implies k1 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1)"
              using A5 sorry
            have "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k1 & k1 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2) implies k1 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
              using A6 sorry
            thus "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
              using A8 A9 A10 A11 int_1_th_7 xboole_0_def_3 sorry
          qed "sorry"
          thus "SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) c=MEMBEREDR6 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A12: "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
          have A13: "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
          proof(rule impI)
            assume "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1)"
            then obtain k1 where
              [ty]:"k1 be NatNAT-1M1" and 
              A14: "x =HIDDENR1 k1"and A15: "\<one>\<^sub>M <=XXREAL-0R1 k1"and A16: "k1 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)"
              using A5 sorry
            have "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
              using xreal_1_th_7 sorry
            then have "k1 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
              using A16 xxreal_0_th_2 sorry
            thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
              using A14 A15 sorry
          qed
          have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) implies x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
          proof(rule impI)
            assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
            then obtain k2 where
              [ty]:"k2 be NatNAT-1M1" and 
              A17: "x =HIDDENR1 k2"and A18: "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k2"and A19: "k2 <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
              using A6 sorry
            have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_7 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 k2"
              using A18 xxreal_0_th_2 sorry
            thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
              using A17 A19 sorry
          qed
          thus "x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
            using A12 A13 xboole_0_def_3 sorry
        qed "sorry"
        thus "domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
          using tarski_def_3 sorry
      qed
      thus "SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)) =MEMBEREDR12 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
        using xboole_0_def_10 sorry
    qed
    have A20: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
      using xtuple_0_th_23 sorry
    have "domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) missesMEMBEREDR18 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
      using valued_1_th_48 sorry
    then obtain ss1 where 
      [ty]:"ss1 be FunctionFUNCT-1M1" and ss1Def:"ss1 = SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))"
      using grfunc_1_th_13 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A21: "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 ss)"
      have A22: "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 (ss *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss)).FUNCT-1K1 x"
         sorry
      also have "... = ss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> ss) .FUNCT-1K1 x)"
        using A21 funct_1_th_12 sorry
      also have "... = ss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 \\/SUBSET-1K4\<^bsub>(NATNUMBERSK1)\<^esub> domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) .FUNCT-1K1 x)"
        using A3 xtuple_0_th_23 sorry
      also have "... = ss .FUNCT-1K1 ((SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))).FUNCT-1K1 x)"
        using A1 A2 valued_1_lm_8 sorry
      finally have "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 ss .FUNCT-1K1 ((SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) ^FINSEQ-1K9\<^bsub>(omegaORDINAL1K4)\<^esub> SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))).FUNCT-1K1 x)"
         sorry
      have A23: "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
      proof(rule impI)
        assume A24: "x inHIDDENR3 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1)"
        then have A25: "x inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1))"
          using finseq_1_th_100 sorry
        then have "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1))"
          using funct_1_def_3 sorry
        then have A26: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1"
          using finseq_1_th_50 sorry
        have "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 ss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) .FUNCT-1K1 x)"
          using A22 A25 finseq_1_def_7 sorry
        also have "... = q1 .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) .FUNCT-1K1 x)"
          using A3 A26 grfunc_1_th_15 sorry
        also have "... = (q1 *FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1)).FUNCT-1K1 x"
          using A25 funct_1_th_13 sorry
        also have "... = SeqFINSEQ-1K16 q1 .FUNCT-1K1 x"
           sorry
        finally have "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 SeqFINSEQ-1K16 q1 .FUNCT-1K1 x"
           sorry
        thus "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
          using A24 grfunc_1_th_15 sorry
      qed
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
      proof(rule impI)
        assume A27: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
        have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) =XBOOLE-0R4 {j +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) where j be NatNAT-1M1 : j inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) }"
          using valued_1_def_12 sorry
        then obtain j where
          [ty]:"j be NatNAT-1M1" and 
          A28: "x =HIDDENR1 j +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)"and A29: "j inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2)"
          using A27 sorry
        have A30: "ss1 .FUNCT-1K1 x =HIDDENR1 (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))).FUNCT-1K1 x"
          using A27 grfunc_1_th_15 sorry
        also have "... = SeqFINSEQ-1K16 q2 .FUNCT-1K1 j"
          using A28 A29 valued_1_def_12 sorry
        finally have "ss1 .FUNCT-1K1 x =HIDDENR1 SeqFINSEQ-1K16 q2 .FUNCT-1K1 j"
           sorry
        have A31: " ex l1 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1 c=MEMBEREDR6 SegFINSEQ-1K2 l1"
          using finseq_1_def_12 sorry
        have A32: " ex l2 be NatNAT-1M1 st domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) c=MEMBEREDR6 SegFINSEQ-1K2 l2"
          using finseq_1_def_12 sorry
        have "cardCARD-1K4 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1) =COMPLEX1R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1))"
          using A31 finseq_3_th_39 sorry
        then have A33: "cardCARD-1K4 q1 =COMPLEX1R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(omegaORDINAL1K4)\<^esub> q1))"
          using card_1_th_62 sorry
        have A34: "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) =COMPLEX1R1 cardCARD-1K4 q1"
          using finseq_3_th_158 sorry
        have A35: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"
          using finseq_1_def_3 sorry
        have "cardCARD-1K4 q2 =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
          using finseq_3_th_158 sorry
        then have A36: "cardCARD-1K4 (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
          using valued_1_th_42 sorry
        then have A37: "cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
          using card_1_th_62 sorry
        have A38: "cardCARD-1K4 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) =COMPLEX1R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
          using A32 finseq_3_th_39 sorry
        have A39: "lenFINSEQ-1K4 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))) =COMPLEX1R1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2)"
          using A32 A37 finseq_3_th_39 sorry
        have A40: "domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) =MEMBEREDR12 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
          using A35 A36 A38 card_1_th_62 finseq_1_def_3 sorry
        have A41: "j inTARSKIR2 domFINSEQ-1K5 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
          using A29 A35 A39 finseq_1_def_3 sorry
        have "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) .FUNCT-1K1 j inTARSKIR2 rngRELSET-1K2\<^bsub>(omegaORDINAL1K4)\<^esub> (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))))"
          using A29 A40 funct_1_def_3 sorry
        then have A42: "SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) .FUNCT-1K1 j inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))"
          using finseq_1_th_50 sorry
        have "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 ss .FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) .FUNCT-1K1 j)"
          using A22 A28 A33 A34 A41 finseq_1_def_7 sorry
        also have "... = (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)).FUNCT-1K1 (SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))) .FUNCT-1K1 j)"
          using A3 A42 grfunc_1_th_15 sorry
        also have "... = ((ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1))*FUNCT-1K3 SgmFINSEQ-1K15 (domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)))).FUNCT-1K1 j"
          using A29 A40 funct_1_th_13 sorry
        also have "... = SeqFINSEQ-1K16 (ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)) .FUNCT-1K1 j"
           sorry
        also have "... = SeqFINSEQ-1K16 q2 .FUNCT-1K1 j"
          using A29 valued_1_th_58 sorry
        finally have "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =HIDDENR1 SeqFINSEQ-1K16 q2 .FUNCT-1K1 j"
           sorry
        thus "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
          using A30 sorry
      qed
      thus "SeqFINSEQ-1K16 ss .FUNCT-1K1 x =XBOOLE-0R4 ss1 .FUNCT-1K1 x"
        using A4 A7 A21 A23 xboole_0_def_3 sorry
    qed "sorry"
    then have "SeqFINSEQ-1K16 ss =FUNCT-1R1 ss1"
      using A4 A7 A20 sorry
    thus " not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not ((ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))) & SeqFINSEQ-1K16 ss =RELAT-1R1 SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))))"
      using A3 A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_64:
" for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies ( ex ss be FinSubsequenceFINSEQ-1M4 st ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & SeqFINSEQ-1K16 q1 ^FINSEQ-1K8 SeqFINSEQ-1K16 q2 =FINSEQ-1R1 SeqFINSEQ-1K16 ss)"
proof-
  have " for p1 be FinSequenceFINSEQ-1M1 holds  for p2 be FinSequenceFINSEQ-1M1 holds  for q1 be FinSubsequenceFINSEQ-1M4 holds  for q2 be FinSubsequenceFINSEQ-1M4 holds q1 c=RELAT-1R2 p1 & q2 c=RELAT-1R2 p2 implies  not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & SeqFINSEQ-1K16 q1 ^FINSEQ-1K8 SeqFINSEQ-1K16 q2 =FINSEQ-1R1 SeqFINSEQ-1K16 ss))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix p1 assume [ty]: "p1 be FinSequenceFINSEQ-1M1"
    fix p2 assume [ty]: "p2 be FinSequenceFINSEQ-1M1"
    fix q1 assume [ty]: "q1 be FinSubsequenceFINSEQ-1M4"
    fix q2 assume [ty]: "q2 be FinSubsequenceFINSEQ-1M4"
    assume A1: "q1 c=RELAT-1R2 p1"
      and A2: "q2 c=RELAT-1R2 p2"
    obtain ss where
      [ty]:"ss be FinSubsequenceFINSEQ-1M4" and 
      A3: "ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1)"and A4: "domFINSEQ-1K5 (SeqFINSEQ-1K16 ss) =MEMBEREDR12 SegFINSEQ-1K2 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q2))"and A5: "SeqFINSEQ-1K16 ss =RELAT-1R1 SeqFINSEQ-1K16 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))"
      using A1 A2 valued_1_th_63 sorry
    have A6: " for j1 be NatNAT-1M1 holds j1 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q1) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 j1 =XBOOLE-0R4 SeqFINSEQ-1K16 q1 .FUNCT-1K1 j1"
      using A5 grfunc_1_th_15 sorry
    have " for j2 be NatNAT-1M1 holds j2 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2) =XBOOLE-0R4 SeqFINSEQ-1K16 q2 .FUNCT-1K1 j2"
    proof-
      have " for j2 be NatNAT-1M1 holds j2 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) implies SeqFINSEQ-1K16 ss .FUNCT-1K1 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2) =HIDDENR1 SeqFINSEQ-1K16 q2 .FUNCT-1K1 j2"
      proof(rule ballI,rule impI)
        fix j2 assume [ty]: "j2 be NatNAT-1M1"
        assume A7: "j2 inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2)"
        have "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))) =XBOOLE-0R4 {k +NAT-1K1 lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) where k be NatNAT-1M1 : k inTARSKIR2 domFINSEQ-1K5 (SeqFINSEQ-1K16 q2) }"
          using valued_1_def_12 sorry
        then have "lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2 inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1)))"
          using A7 sorry
        then have "SeqFINSEQ-1K16 ss .FUNCT-1K1 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2) =HIDDENR1 (ShiftVALUED-1K64(SeqFINSEQ-1K16 q2,lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1))).FUNCT-1K1 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2)"
          using A5 grfunc_1_th_15 sorry
        also have "... = SeqFINSEQ-1K16 q2 .FUNCT-1K1 j2"
          using A7 valued_1_def_12 sorry
        finally show "SeqFINSEQ-1K16 ss .FUNCT-1K1 (lenFINSEQ-1K4 (SeqFINSEQ-1K16 q1) +XCMPLX-0K2 j2) =HIDDENR1 SeqFINSEQ-1K16 q2 .FUNCT-1K1 j2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "SeqFINSEQ-1K16 ss =FINSEQ-1R1 SeqFINSEQ-1K16 q1 ^FINSEQ-1K8 SeqFINSEQ-1K16 q2"
      using A4 A6 finseq_1_def_7 sorry
    thus " not ( for ss be FinSubsequenceFINSEQ-1M4 holds  not (ss =RELAT-1R1 q1 \\/XBOOLE-0K2 ShiftVALUED-1K64(q2,lenFINSEQ-1K4 p1) & SeqFINSEQ-1K16 q1 ^FINSEQ-1K8 SeqFINSEQ-1K16 q2 =FINSEQ-1R1 SeqFINSEQ-1K16 ss))"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_65:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds cardCARD-1K4 (CutLastLocVALUED-1K66 F) =COMPLEX1R1 cardCARD-1K4 F -'XREAL-0K1 \<one>\<^sub>M"
proof-
  have " for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -'XREAL-0K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    have A1: "cardCARD-1K4 F >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have "cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -XCMPLX-0K6 \<one>\<^sub>M"
      using valued_1_th_38 sorry
    also have "... = cardCARD-1K4 F -'XREAL-0K1 \<one>\<^sub>M"
      using A1 xreal_1_th_233 sorry
    finally show "cardCARD-1K4 (CutLastLocVALUED-1K66 F) =HIDDENR1 cardCARD-1K4 F -'XREAL-0K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_66:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =MEMBEREDR12 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G implies LastLocVALUED-1K65 F =COMPLEX1R1 LastLocVALUED-1K65 G"
   sorry

mtheorem valued_1_th_67:
" for i be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds ShiftVALUED-1K64(f +~FUNCT-4K8(x,y),i) =FUNCT-1R1 (ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)"
proof-
  have " for i be NatNAT-1M1 holds  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds ShiftVALUED-1K64(f +~FUNCT-4K8(x,y),i) =FUNCT-1R1 (ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1"
    have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f =XBOOLE-0R4 domRELAT-1K1 (f +~FUNCT-4K8(x,y))"
      using funct_4_th_99 sorry
    have A2: "domRELAT-1K1 ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)) =HIDDENR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(f,i))"
      using funct_4_th_99 sorry
    also have "... = {m +XCMPLX-0K2 i where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y)) }"
      using A1 valued_1_def_12 sorry
    finally have "domRELAT-1K1 ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)) =HIDDENR1 {m +XCMPLX-0K2 i where m be NatNAT-1M1 : m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y)) }"
       sorry
    have " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y)) implies ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =XBOOLE-0R4 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
    proof-
      have " for m be NatNAT-1M1 holds m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y)) implies ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y))"
        then have A3: "m +XCMPLX-0K2 i inTARSKIR2 domRELAT-1K1 ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y))"
          using A2 sorry
        then have A4: "m +XCMPLX-0K2 i inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (ShiftVALUED-1K64(f,i))"
          using funct_4_th_99 sorry
        obtain mm where
          [ty]:"mm be NatNAT-1M1" and 
          A5: "m +XCMPLX-0K2 i =COMPLEX1R1 mm +XCMPLX-0K2 i"and A6: "mm inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y))"
          using A2 A3 sorry
        have "m =COMPLEX1R1 mm"
          using A5 sorry
        then have "m inTARSKIR2 domRELAT-1K1 (f +~FUNCT-4K8(x,y))"
          using A6 sorry
        then have A7: "m inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> f"
          using funct_4_th_99 sorry
        then have A8: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) =XBOOLE-0R4 f .FUNCT-1K1 m"
          using valued_1_def_12 sorry
        show "((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
        proof-
          have cases: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) =XBOOLE-0R4 x or (ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) <>HIDDENR2 x"
             sorry
          have case1: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) =XBOOLE-0R4 x implies ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
          proof(rule impI)
            assume A9: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) =XBOOLE-0R4 x"
            then have "((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 y"
              using A4 funct_4_th_106 sorry
            also have "... = (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
              using A7 funct_4_th_106 A9 A8 sorry
            finally show "((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
               sorry
          qed
          have case2: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) <>HIDDENR2 x implies ((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
          proof(rule impI)
            assume A10: "(ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i) <>HIDDENR2 x"
            then have "((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (ShiftVALUED-1K64(f,i)).FUNCT-1K1 (m +XCMPLX-0K2 i)"
              using funct_4_th_105 sorry
            also have "... = (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
              using A10 A8 funct_4_th_105 sorry
            finally show "((ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)).FUNCT-1K1 (m +XCMPLX-0K2 i) =HIDDENR1 (f +~FUNCT-4K8(x,y)).FUNCT-1K1 m"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "ShiftVALUED-1K64(f +~FUNCT-4K8(x,y),i) =FUNCT-1R1 (ShiftVALUED-1K64(f,i))+~FUNCT-4K8(x,y)"
      using A2 valued_1_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem valued_1_th_68:
" for F be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds  for G be  non emptyXBOOLE-0V1\<bar>NATNUMBERSK1 -definedRELAT-1V4\<bar>finiteFINSET-1V1\<bar>FunctionFUNCT-1M1 holds domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F c=MEMBEREDR6 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> G implies LastLocVALUED-1K65 F <=XXREAL-0R1 LastLocVALUED-1K65 G"
  using xxreal_2_th_59 sorry

end
