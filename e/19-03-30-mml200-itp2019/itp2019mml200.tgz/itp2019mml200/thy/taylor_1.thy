theory taylor_1
  imports irrat_1 seqfunc card_4
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n for "NatNAT-1M1"
reserve i for "IntegerINT-1M1"
reserve p, x, x0, y for "RealXREAL-0M1"
reserve q for "RationalRAT-1M1"
reserve f for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef taylor_1_def_1 ("#ZTAYLOR-1K1  _ " [220]220 ) where
  mlet "q be IntegerINT-1M1"
"func #ZTAYLOR-1K1 q \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q"
    proof-
      have " ex tVar1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar1 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q"
      proof-
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 #ZPREPOWERK3 q,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using funct_2_sch_4 sorry
        show " ex tVar1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for d be RealXREAL-0M1 holds tVar1 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q"
        proof(rule bexI[of _ "f"],rule ballI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          have "d inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          then have "f .FUNCT-1K1 d =COMPLEX1R1 ?U(d)"
            using A1 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds it1 .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q) & ( for x be RealXREAL-0M1 holds it2 .FUNCT-1K1 x =COMPLEX1R1 x #ZPREPOWERK3 q) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q) & ( for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q) implies f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for d be RealXREAL-0M1 holds f1 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q"
          and A3: " for d be RealXREAL-0M1 holds f2 .FUNCT-1K1 d =COMPLEX1R1 d #ZPREPOWERK3 q"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
          proof(rule ballI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            have "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 d #ZPREPOWERK3 q"
              using A2 sorry
            also have "... = f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
              using A3 sorry
            finally show "f1 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =HIDDENR1 f2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem taylor_1_th_1:
" for x be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
proof-
  have " for x be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    show "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
    proof-
      have cases: "x <>HIDDENR2 0NUMBERSK6 or x =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "x <>HIDDENR2 0NUMBERSK6 implies x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
      proof(rule impI)
        assume "x <>HIDDENR2 0NUMBERSK6"
        thus "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
          using prepower_th_44 sorry
      qed
      have case2: "x =COMPLEX1R1 0NUMBERSK6 implies x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
      proof(rule impI)
        assume A1: "x =COMPLEX1R1 0NUMBERSK6"
        show "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
        proof-
          have A2: "(0NUMBERSK6)#ZPREPOWERK3 (n +XCMPLX-0K2 m) =HIDDENR1 (0NUMBERSK6) |^NEWTONK1 ( |.COMPLEX1K10 n +XCMPLX-0K2 m .|)"
            using prepower_def_3 sorry
          also have "... = (0NUMBERSK6) |^NEWTONK1 (n +XCMPLX-0K2 m)"
            using absvalue_def_1 sorry
          also have "... = (0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6) |^NEWTONK1 m"
            using newton_th_8 sorry
          finally have "(0NUMBERSK6)#ZPREPOWERK3 (n +XCMPLX-0K2 m) =HIDDENR1 (0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6) |^NEWTONK1 m"
             sorry
          show "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
          proof-
            have cases: "(n =COMPLEX1R1 0NUMBERSK6 & m =COMPLEX1R1 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6) or m <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "n =COMPLEX1R1 0NUMBERSK6 & m =COMPLEX1R1 0NUMBERSK6 implies x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
            proof(rule impI)
              assume A3: "n =COMPLEX1R1 0NUMBERSK6 & m =COMPLEX1R1 0NUMBERSK6"
              have "x #ZPREPOWERK3 (0NUMBERSK6 +NAT-1K1 0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x #ZPREPOWERK3 (0NUMBERSK6)"
                 sorry
              also have "... = x #ZPREPOWERK3 (0NUMBERSK6) *XCMPLX-0K3 x #ZPREPOWERK3 (0NUMBERSK6)"
                using prepower_th_34 sorry
              finally have "x #ZPREPOWERK3 (0NUMBERSK6 +NAT-1K1 0NUMBERSK6) =HIDDENR1 x #ZPREPOWERK3 (0NUMBERSK6) *XCMPLX-0K3 x #ZPREPOWERK3 (0NUMBERSK6)"
                 sorry
              thus "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
                using A3 sorry
            qed
            have case2: "n <>HIDDENR2 0NUMBERSK6 implies x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
            proof(rule impI)
              assume "n <>HIDDENR2 0NUMBERSK6"
              then have A4: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              have A5: "(0NUMBERSK6)#ZPREPOWERK3 n *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m =HIDDENR1 (0NUMBERSK6) |^NEWTONK1 ( |.COMPLEX1K10 n.|) *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m"
                using prepower_def_3 sorry
              also have "... = (0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m"
                using absvalue_def_1 sorry
              also have "... = (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m"
                using A4 newton_th_11 sorry
              finally have "(0NUMBERSK6)#ZPREPOWERK3 n *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m"
                 sorry
              have "(0NUMBERSK6)#ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) |^NEWTONK1 m"
                using A2 A4 newton_th_11 sorry
              thus "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
                using A1 A5 sorry
            qed
            have case3: "m <>HIDDENR2 0NUMBERSK6 implies x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
            proof(rule impI)
              assume "m <>HIDDENR2 0NUMBERSK6"
              then have A6: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
                using nat_1_th_13 sorry
              have A7: "(0NUMBERSK6)#ZPREPOWERK3 n *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m =HIDDENR1 (0NUMBERSK6) |^NEWTONK1 ( |.COMPLEX1K10 m.|) *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 n"
                using prepower_def_3 sorry
              also have "... = (0NUMBERSK6) |^NEWTONK1 m *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 n"
                using absvalue_def_1 sorry
              also have "... = (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 n"
                using A6 newton_th_11 sorry
              finally have "(0NUMBERSK6)#ZPREPOWERK3 n *XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 m =HIDDENR1 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6)#ZPREPOWERK3 n"
                 sorry
              have "(0NUMBERSK6)#ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 (0NUMBERSK6) |^NEWTONK1 n"
                using A2 A6 newton_th_11 sorry
              thus "x #ZPREPOWERK3 (n +XCMPLX-0K2 m) =COMPLEX1R1 x #ZPREPOWERK3 n *XCMPLX-0K3 x #ZPREPOWERK3 m"
                using A1 A7 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 sorry
          qed
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_2:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 n,x) =COMPLEX1R1 n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 n,x) =COMPLEX1R1 n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1.  for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 Lamb1 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 Lamb1,x) =COMPLEX1R1 Lamb1 *XCMPLX-0K3 x #ZPREPOWERK3 (Lamb1 -XCMPLX-0K6 \<one>\<^sub>M)"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 k is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 k,x) =COMPLEX1R1 k *XCMPLX-0K3 x #ZPREPOWERK3 (k -XCMPLX-0K6 \<one>\<^sub>M)) implies ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          assume "x inHIDDENR3 REALNUMBERSK2"
          have "#ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 \<one>\<^sub>M"
            using taylor_1_def_1 sorry
          also have "... = \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
            using prepower_th_35 sorry
          finally show "#ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
             sorry
        qed "sorry"
        have A3: "[#]SUBSET-1K2 REALNUMBERSK2 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
           sorry
        have A4: "REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<one>\<^sub>M)"
          using funct_2_def_1 sorry
        then have A5: "#ZTAYLOR-1K1 \<one>\<^sub>M is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
          using A2 A3 fdiff_1_th_23 sorry
        have A6: " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 \<one>\<^sub>M is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 \<one>\<^sub>M,x) =COMPLEX1R1 \<one>\<^sub>M"
        proof-
          have " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 \<one>\<^sub>M is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 \<one>\<^sub>M,x) =HIDDENR1 \<one>\<^sub>M"
          proof(rule ballI,rule conjMI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            have A7: "x inHIDDENR3 REALNUMBERSK2"
              using xreal_0_def_1 sorry
            thus "#ZTAYLOR-1K1 \<one>\<^sub>M is-differentiable-inFDIFF-1R1 x"
              using A3 A5 fdiff_1_th_9 sorry
            have "diffFDIFF-1K1(#ZTAYLOR-1K1 \<one>\<^sub>M,x) =HIDDENR1 (#ZTAYLOR-1K1 \<one>\<^sub>M `|FDIFF-1K2 REALNUMBERSK2).FUNCT-1K1 x"
              using A5 A7 fdiff_1_def_7 sorry
            also have "... = \<one>\<^sub>M"
              using A2 A4 A3 A7 fdiff_1_th_23 sorry
            finally show "diffFDIFF-1K1(#ZTAYLOR-1K1 \<one>\<^sub>M,x) =HIDDENR1 \<one>\<^sub>M"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A8: "?P(k)"
        have "k =COMPLEX1R1 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)))"
        proof-
          show "k =COMPLEX1R1 0NUMBERSK6 & ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)) or k <>HIDDENR2 0NUMBERSK6 & (k <>HIDDENR2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)))"
          proof-
            have cases: "k =COMPLEX1R1 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "k =COMPLEX1R1 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))"
            proof(rule impI)
              assume A9: "k =COMPLEX1R1 0NUMBERSK6"
              show " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
              proof-
                have " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
                proof(rule ballI,rule conjMI)
                  fix x assume [ty]: "x be RealXREAL-0M1"
                  show "#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x"
                    using A6 A9 sorry
                  have "diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 \<one>\<^sub>M"
                    using A6 A9 sorry
                  also have "... = (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
                    using A9 prepower_th_34 sorry
                  finally show "diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
                     sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
            qed
            have case2: "k <>HIDDENR2 0NUMBERSK6 implies ( for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))"
            proof(rule impI,rule ballI,rule conjMI)
              assume "k <>HIDDENR2 0NUMBERSK6"
              then have "\<one>\<^sub>M <=XXREAL-0R1 k"
                using nat_1_th_14 sorry
              then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 k -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_13 sorry
              then obtain k1 where 
                [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = k -XCMPLX-0K6 \<one>\<^sub>M"
                using int_1_th_3 sorry
              fix x assume [ty]: "x be RealXREAL-0M1"
              have A10: "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                using funct_2_def_1 sorry
              have A11: "x be RealXREAL-0M1 & #ZTAYLOR-1K1 k is-differentiable-inFDIFF-1R1 x"
                using A8 sorry
              have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 x =COMPLEX1R1 #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M)) implies #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                  then obtain x1 where 
                    [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
                     sorry
                  have "#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 x =HIDDENR1 x1 #ZPREPOWERK3 (k +NAT-1K1 \<one>\<^sub>M)"
                    using taylor_1_def_1 sorry
                  also have "... = x1 #ZPREPOWERK3 k *XCMPLX-0K3 x1 #ZPREPOWERK3 \<one>\<^sub>M"
                    using taylor_1_th_1 sorry
                  also have "... = #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 x1 #ZPREPOWERK3 \<one>\<^sub>M"
                    using taylor_1_def_1 sorry
                  also have "... = #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                    using taylor_1_def_1 sorry
                  finally show "#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 x =HIDDENR1 #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                     sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A13: "#ZTAYLOR-1K1 \<one>\<^sub>M is-differentiable-inFDIFF-1R1 x"
                using A6 sorry
              have A14: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 k) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<one>\<^sub>M) =HIDDENR1 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<one>\<^sub>M)"
                using funct_2_def_1 sorry
              also have "... = [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
                using funct_2_def_1 sorry
              finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 k) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 \<one>\<^sub>M) =HIDDENR1 [#]SUBSET-1K2 REALNUMBERSK2 /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
                 sorry
              then have "#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 k (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 \<one>\<^sub>M"
                using A10 A12 valued_1_def_4 sorry
              thus "#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x"
                using A11 A13 fdiff_1_th_16 sorry
              have "diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 k (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> #ZTAYLOR-1K1 \<one>\<^sub>M,x)"
                using A14 A10 A12 valued_1_def_4 sorry
              also have "... = #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 \<one>\<^sub>M,x)) +XCMPLX-0K2 (diffFDIFF-1K1(#ZTAYLOR-1K1 k,x))*XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                using A11 A13 fdiff_1_th_16 sorry
              also have "... = #ZTAYLOR-1K1 k .FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (diffFDIFF-1K1(#ZTAYLOR-1K1 k,x))*XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                using A6 sorry
              also have "... = x #ZPREPOWERK3 k *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (diffFDIFF-1K1(#ZTAYLOR-1K1 k,x))*XCMPLX-0K3 #ZTAYLOR-1K1 \<one>\<^sub>M .FUNCT-1K1 x"
                using taylor_1_def_1 sorry
              also have "... = x #ZPREPOWERK3 k *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (diffFDIFF-1K1(#ZTAYLOR-1K1 k,x))*XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M"
                using taylor_1_def_1 sorry
              also have "... = x #ZPREPOWERK3 k +XCMPLX-0K2 (k *XCMPLX-0K3 x #ZPREPOWERK3 k1)*XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M"
                using A8 sorry
              also have "... = x #ZPREPOWERK3 k +XCMPLX-0K2 k *XCMPLX-0K3 (x #ZPREPOWERK3 k1 *XCMPLX-0K3 x #ZPREPOWERK3 \<one>\<^sub>M)"
                 sorry
              also have "... = x #ZPREPOWERK3 k +XCMPLX-0K2 k *XCMPLX-0K3 x #ZPREPOWERK3 (k1 +NAT-1K1 \<one>\<^sub>M)"
                using taylor_1_th_1 sorry
              also have "... = (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
                 sorry
              finally show "diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =HIDDENR1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
                 sorry
            qed "sorry"
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (k +NAT-1K1 \<one>\<^sub>M),x) =COMPLEX1R1 (k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x #ZPREPOWERK3 ((k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A15: "?P(0NUMBERSK6)"
    proof-
      have " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (0NUMBERSK6) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (0NUMBERSK6),x) =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 x #ZPREPOWERK3 (0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M)"
      proof(rule ballI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        let ?f = "#ZTAYLOR-1K1 (0NUMBERSK6)"
        have " for y be objectHIDDENM1 holds y inHIDDENR3 {TARSKIK1 \<one>\<^sub>M} implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (0NUMBERSK6))"
        proof(rule ballI,rule impI)
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 REALNUMBERSK2"
            using funct_2_def_1 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A16: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
            using xboole_0_def_1 sorry
          obtain x1 where 
            [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x"
            using A16 sorry
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A17: "y inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
          have "?f .FUNCT-1K1 x =HIDDENR1 x1 #ZPREPOWERK3 (0NUMBERSK6)"
            using taylor_1_def_1 sorry
          also have "... = \<one>\<^sub>M"
            using prepower_th_34 sorry
          also have "... = y"
            using A17 tarski_def_1 sorry
          finally have "?f .FUNCT-1K1 x =HIDDENR1 y"
             sorry
          thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (0NUMBERSK6))"
            using A16 funct_1_def_3 sorry
        qed "sorry"
        then have A18: "{TARSKIK1 \<one>\<^sub>M} c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
          using tarski_def_3 sorry
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (0NUMBERSK6)) implies y inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A19: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"and A20: "y =HIDDENR1 ?f .FUNCT-1K1 x"
            using funct_1_def_3 sorry
          have 
            [ty]:"x be RealXREAL-0M1"
            using A19 sorry
          have "?f .FUNCT-1K1 x =HIDDENR1 x #ZPREPOWERK3 (0NUMBERSK6)"
            using taylor_1_def_1 sorry
          also have "... = \<one>\<^sub>M"
            using prepower_th_34 sorry
          finally have "?f .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M"
             sorry
          thus "y inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
            using A20 tarski_def_1 sorry
        qed "sorry"
        then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M}"
          using tarski_def_3 sorry
        then have A21: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
          using A18 xboole_0_def_10 sorry
        have A22: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
          using funct_2_def_1 sorry
        then have A23: "?f is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
          using A21 fdiff_1_th_11 sorry
        have A24: "x inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        then have "(?f `|FDIFF-1K2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f).FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6"
          using A21 A22 fdiff_1_th_11 sorry
        thus "#ZTAYLOR-1K1 (0NUMBERSK6) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (0NUMBERSK6),x) =COMPLEX1R1 (0NUMBERSK6)*XCMPLX-0K3 x #ZPREPOWERK3 (0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M)"
          using A24 A23 A22 fdiff_1_th_9 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A15 A1 sorry
    thus "#ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 n,x) =COMPLEX1R1 n *XCMPLX-0K3 x #ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_3:
" for n be NatNAT-1M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (n *XCMPLX-0K3 (f .FUNCT-1K1 x0)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
proof-
  have " for n be NatNAT-1M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (n *XCMPLX-0K3 (f .FUNCT-1K1 x0)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
    have A2: "#ZTAYLOR-1K1 n is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x0 & x0 be RealXREAL-0M1"
      using taylor_1_th_2 sorry
    thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A1 fdiff_2_th_13 sorry
    have "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(#ZTAYLOR-1K1 n,f .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A1 A2 fdiff_2_th_13 sorry
    also have "... = (n *XCMPLX-0K3 (f .FUNCT-1K1 x0)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using taylor_1_th_2 sorry
    finally show "diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (n *XCMPLX-0K3 (f .FUNCT-1K1 x0)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_1:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 n =COMPLEX1R1 exp-RSIN-COSK24 (n *XCMPLX-0K3 x)"
proof-
  have " for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 n =COMPLEX1R1 exp-RSIN-COSK24 (n *XCMPLX-0K3 x)"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have 
      [ty]:"x be RealXREAL-0M1"
       sorry
    let ?P = "\<lambda>Lamb1. (exp-RSIN-COSK24 x)#RPREPOWERK6 Lamb1 =COMPLEX1R1 exp-RSIN-COSK24 (Lamb1 *XCMPLX-0K3 x)"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 k =COMPLEX1R1 exp-RSIN-COSK24 (k *XCMPLX-0K3 x) implies (exp-RSIN-COSK24 x)#RPREPOWERK6 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 exp-RSIN-COSK24 ((k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "?P(k)"
        obtain k1 where 
          [ty]:"k1 be ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = k"
          using ordinal1_def_12 sorry
        have "(exp-RSIN-COSK24 x)#RPREPOWERK6 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 k *XCMPLX-0K3 (exp-RSIN-COSK24 x)#RPREPOWERK6 \<one>\<^sub>M"
          using prepower_th_75 sin_cos_th_55 sorry
        also have "... = (exp-RSIN-COSK24 x)#RPREPOWERK6 k *XCMPLX-0K3 (exp-RSIN-COSK24 x)"
          using prepower_th_72 sin_cos_th_55 sorry
        also have "... = exp-RSIN-COSK24 (k1 *XCMPLX-0K3 x +XCMPLX-0K2 x)"
          using A2 sin_cos_th_50 sorry
        also have "... = exp-RSIN-COSK24 ((k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x)"
           sorry
        finally show "(exp-RSIN-COSK24 x)#RPREPOWERK6 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 exp-RSIN-COSK24 ((k +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 x)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: "?P(0NUMBERSK6)"
      using prepower_th_71 sin_cos_th_51 sin_cos_th_55 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 n =COMPLEX1R1 exp-RSIN-COSK24 (n *XCMPLX-0K3 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_4:
" for x be RealXREAL-0M1 holds exp-RSIN-COSK24 (-XCMPLX-0K4 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
proof-
  have " for x be RealXREAL-0M1 holds exp-RSIN-COSK24 (-XCMPLX-0K4 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have 
      [ty]:"x be RealXREAL-0M1"
       sorry
    have "(exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (exp-RSIN-COSK24 x) =HIDDENR1 exp-RSIN-COSK24 ((-XCMPLX-0K4 x)+XCMPLX-0K2 x)"
      using sin_cos_th_50 sorry
    also have "... = \<one>\<^sub>M"
      using sin_cos_th_51 sorry
    finally have "(exp-RSIN-COSK24 (-XCMPLX-0K4 x))*XCMPLX-0K3 (exp-RSIN-COSK24 x) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "exp-RSIN-COSK24 (-XCMPLX-0K4 x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x)"
      using xcmplx_1_th_73 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_2:
" for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
proof-
  have " for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "i =COMPLEX1R1 n or i =COMPLEX1R1 -XCMPLX-0K4 n"
      using int_1_th_2 sorry
    have "i =COMPLEX1R1 n & (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x) or i =COMPLEX1R1 -XCMPLX-0K4 n & (i =COMPLEX1R1 -XCMPLX-0K4 n implies exp-RSIN-COSK24 (i *XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 i)"
    proof-
      show "i =COMPLEX1R1 n & (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x) or i =COMPLEX1R1 -XCMPLX-0K4 n & (i =COMPLEX1R1 -XCMPLX-0K4 n implies exp-RSIN-COSK24 (i *XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 i)"
      proof-
        have cases: "i =COMPLEX1R1 n or i =COMPLEX1R1 -XCMPLX-0K4 n"
          using A1 sorry
        have case1: "i =COMPLEX1R1 n implies (exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
        proof(rule impI)
          assume "i =COMPLEX1R1 n"
          thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
            using taylor_1_lm_1 sorry
        qed
        have case2: "i =COMPLEX1R1 -XCMPLX-0K4 n implies exp-RSIN-COSK24 (i *XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 i"
        proof(rule impI)
          assume A2: "i =COMPLEX1R1 -XCMPLX-0K4 n"
          then have "exp-RSIN-COSK24 (i *XCMPLX-0K3 x) =HIDDENR1 exp-RSIN-COSK24 (-XCMPLX-0K4 n *XCMPLX-0K3 x)"
             sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 (n *XCMPLX-0K3 x))"
            using taylor_1_th_4 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 (exp-RSIN-COSK24 x)#RPREPOWERK6 n"
            using taylor_1_lm_1 sorry
          also have "... = (exp-RSIN-COSK24 x)#RPREPOWERK6 i"
            using A2 prepower_th_76 sin_cos_th_55 sorry
          finally show "exp-RSIN-COSK24 (i *XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 i"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 i =COMPLEX1R1 exp-RSIN-COSK24 (i *XCMPLX-0K3 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_5:
" for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =COMPLEX1R1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
proof-
  have " for i be IntegerINT-1M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =HIDDENR1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    let ?n = "i"
    show "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =HIDDENR1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
    proof-
      have cases: "?n <>HIDDENR2 0NUMBERSK6 or ?n =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "i <>HIDDENR2 0NUMBERSK6 implies (exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =HIDDENR1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
      proof(rule impI)
        assume A1: "?n <>HIDDENR2 0NUMBERSK6"
        then have "exp-RSIN-COSK24 x =HIDDENR1 exp-RSIN-COSK24 ((x /XCMPLX-0K7 ?n)*XCMPLX-0K3 ?n)"
          using xcmplx_1_th_87 sorry
        also have "... = (exp-RSIN-COSK24 (x /XCMPLX-0K7 ?n))#RPREPOWERK6 ?n"
          using taylor_1_lm_2 sorry
        finally have "exp-RSIN-COSK24 x =HIDDENR1 (exp-RSIN-COSK24 (x /XCMPLX-0K7 ?n))#RPREPOWERK6 ?n"
           sorry
        then have "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =HIDDENR1 (exp-RSIN-COSK24 (x /XCMPLX-0K7 i))#RPREPOWERK6 (i *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 i))"
          using prepower_th_91 sin_cos_th_55 sorry
        also have "... = (exp-RSIN-COSK24 (x /XCMPLX-0K7 i))#RPREPOWERK6 \<one>\<^sub>M"
          using A1 xcmplx_1_th_106 sorry
        also have "... = exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
          using prepower_th_72 sin_cos_th_55 sorry
        finally show "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =HIDDENR1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
           sorry
      qed
      have case2: "i =COMPLEX1R1 0NUMBERSK6 implies (exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =COMPLEX1R1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
      proof(rule impI)
        assume A2: "?n =COMPLEX1R1 0NUMBERSK6"
        have "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6)) =HIDDENR1 exp-RSIN-COSK24 (0NUMBERSK6)"
          using prepower_th_71 sin_cos_th_51 sin_cos_th_55 sorry
        also have "... = exp-RSIN-COSK24 (x /XCMPLX-0K7 (0NUMBERSK6))"
          using xcmplx_1_th_49 sorry
        finally have "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6)) =HIDDENR1 exp-RSIN-COSK24 (x /XCMPLX-0K7 (0NUMBERSK6))"
           sorry
        thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 i) =COMPLEX1R1 exp-RSIN-COSK24 (x /XCMPLX-0K7 i)"
          using A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_6:
" for x be RealXREAL-0M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 (m /XCMPLX-0K7 n) =COMPLEX1R1 exp-RSIN-COSK24 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 x)"
proof-
  have " for x be RealXREAL-0M1 holds  for m be IntegerINT-1M1 holds  for n be IntegerINT-1M1 holds exp-RSIN-COSK24 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 (m /XCMPLX-0K7 n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix m assume [ty]: "m be IntegerINT-1M1"
    fix n assume [ty]: "n be IntegerINT-1M1"
    have "exp-RSIN-COSK24 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 x) =HIDDENR1 exp-RSIN-COSK24 ((x /XCMPLX-0K7 n)*XCMPLX-0K3 m)"
      using xcmplx_1_th_75 sorry
    also have "... = (exp-RSIN-COSK24 (x /XCMPLX-0K7 n))#RPREPOWERK6 m"
      using taylor_1_lm_2 sorry
    also have "... = ((exp-RSIN-COSK24 x)#RPREPOWERK6 (\<one>\<^sub>M /XCMPLX-0K7 n))#RPREPOWERK6 m"
      using taylor_1_th_5 sorry
    also have "... = (exp-RSIN-COSK24 x)#RPREPOWERK6 ((\<one>\<^sub>M /XCMPLX-0K7 n)*XCMPLX-0K3 m)"
      using prepower_th_91 sin_cos_th_55 sorry
    also have "... = (exp-RSIN-COSK24 x)#RPREPOWERK6 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 \<one>\<^sub>M)"
      using xcmplx_1_th_75 sorry
    also have "... = (exp-RSIN-COSK24 x)#RPREPOWERK6 (m /XCMPLX-0K7 n)"
       sorry
    finally show "exp-RSIN-COSK24 ((m /XCMPLX-0K7 n)*XCMPLX-0K3 x) =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 (m /XCMPLX-0K7 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_3:
" for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
proof-
  have " for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have " ex m be IntegerINT-1M1 st  ex n be NatNAT-1M1 st n <>HIDDENR2 0NUMBERSK6 & q =COMPLEX1R1 m /XCMPLX-0K7 n"
      using rat_1_th_8 sorry
    thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
      using taylor_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_7:
" for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#QPREPOWERK4 q =COMPLEX1R1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
proof-
  have " for x be RealXREAL-0M1 holds  for q be RationalRAT-1M1 holds (exp-RSIN-COSK24 x)#QPREPOWERK4 q =HIDDENR1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have "(exp-RSIN-COSK24 x)#QPREPOWERK4 q =HIDDENR1 (exp-RSIN-COSK24 x)#RPREPOWERK6 q"
      using prepower_th_74 sin_cos_th_55 sorry
    also have "... = exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
      using taylor_1_lm_3 sorry
    finally show "(exp-RSIN-COSK24 x)#QPREPOWERK4 q =HIDDENR1 exp-RSIN-COSK24 (q *XCMPLX-0K3 x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_8:
" for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 p =COMPLEX1R1 exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
proof-
  have " for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (exp-RSIN-COSK24 x)#RPREPOWERK6 p =COMPLEX1R1 exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "exp-RSIN-COSK24 x >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_55 sorry
    then obtain s where
      [ty]:"s be Rational-SequencePREPOWERM1" and 
      A1: "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 p"and "(exp-RSIN-COSK24 x)#QPREPOWERK5 s be convergentSEQ-2V5"and A2: "limSEQ-2K1 (exp-RSIN-COSK24 x)#QPREPOWERK5 s =COMPLEX1R1 (exp-RSIN-COSK24 x)#RPREPOWERK6 p"
      using prepower_def_7 sorry
    have A3: "exp-RSIN-COSK23 is-continuous-inFCONT-1R1 x *XCMPLX-0K3 p & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using fdiff_1_th_24 sin_cos_th_47 sin_cos_th_65 sorry
    have A4: " for ii be objectHIDDENM1 holds ii inHIDDENR3 NATNUMBERSK1 implies (exp-RSIN-COSK24 x)#QPREPOWERK5 s .FUNCT-1K1 ii =HIDDENR1 (exp-RSIN-COSK23)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) .FUNCT-1K1 ii"
    proof(rule ballI,rule impI)
      fix ii assume [ty]: "ii be objectHIDDENM1"
      assume "ii inHIDDENR3 NATNUMBERSK1"
      then obtain i where 
        [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and iDef:"i = ii"
         sorry
      have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
        using sin_cos_th_47 sorry
      have "(exp-RSIN-COSK24 x)#QPREPOWERK5 s .FUNCT-1K1 ii =HIDDENR1 (exp-RSIN-COSK24 x)#QPREPOWERK4 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> i)"
        using prepower_def_6 sorry
      also have "... = exp-RSIN-COSK24 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> i *XCMPLX-0K3 x)"
        using taylor_1_th_7 sorry
      also have "... = exp-RSIN-COSK24 (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> i"
        using seq_1_th_9 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> i)"
        using sin_cos_def_23 sorry
      also have "... = (exp-RSIN-COSK23)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) .FUNCT-1K1 ii"
        using A5 funct_2_th_108 sorry
      finally show "(exp-RSIN-COSK24 x)#QPREPOWERK5 s .FUNCT-1K1 ii =HIDDENR1 (exp-RSIN-COSK23)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) .FUNCT-1K1 ii"
         sorry
    qed "sorry"
    have "x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5 & limSEQ-2K1 (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) =COMPLEX1R1 x *XCMPLX-0K3 p"
      using A1 seq_2_th_7 seq_2_th_8 sorry
    then have "limSEQ-2K1 (exp-RSIN-COSK23)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (x *XCMPLX-0K3 p)"
      using A3 fcont_1_def_1 sorry
    also have "... = exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
      using sin_cos_def_23 sorry
    finally have "limSEQ-2K1 (exp-RSIN-COSK23)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (x (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s) =HIDDENR1 exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
       sorry
    thus "(exp-RSIN-COSK24 x)#RPREPOWERK6 p =COMPLEX1R1 exp-RSIN-COSK24 (p *XCMPLX-0K3 x)"
      using A2 A4 funct_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_9:
" for x be RealXREAL-0M1 holds (((exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x & (exp-RSIN-COSK24 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x"
proof-
  have " for x be RealXREAL-0M1 holds exp-RSIN-COSK24 x =HIDDENR1 (exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x & (((exp-RSIN-COSK24 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x)"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have A1: "exp-RSIN-COSK24 x =HIDDENR1 exp-RSIN-COSK24 (x *XCMPLX-0K3 \<one>\<^sub>M)"
       sorry
    also have "... = (exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x"
      using taylor_1_th_8 sorry
    finally show "exp-RSIN-COSK24 x =HIDDENR1 (exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x"
       sorry
    have "exp-RSIN-COSK24 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using sin_cos_th_55 sorry
    thus "((exp-RSIN-COSK24 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 exp-RSIN-COSK24 x"
      using A1 irrat_1_def_7 power_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_10:
" for x be RealXREAL-0M1 holds ((((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)#RPREPOWERK6 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x & ((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)to-powerPOWERK2 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x) & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x) & (number-ePOWERK4)#RPREPOWERK6 x =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
proof-
  have " for x be RealXREAL-0M1 holds ((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)#RPREPOWERK6 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x & (((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)to-powerPOWERK2 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x & ((number-ePOWERK4)to-powerPOWERK2 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x & (number-ePOWERK4)#RPREPOWERK6 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x))"
  proof(rule ballI,rule conjMI,rule conjMI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)#RPREPOWERK6 x =HIDDENR1 (exp-RSIN-COSK24 \<one>\<^sub>M)#RPREPOWERK6 x"
      using sin_cos_def_23 sorry
    also have "... = exp-RSIN-COSK24 x"
      using taylor_1_th_9 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
      using sin_cos_def_23 sorry
    finally show "((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)#RPREPOWERK6 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
       sorry
    have "((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)to-powerPOWERK2 x =HIDDENR1 (exp-RSIN-COSK24 \<one>\<^sub>M)to-powerPOWERK2 x"
      using sin_cos_def_23 sorry
    also have "... = exp-RSIN-COSK24 x"
      using taylor_1_th_9 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
      using sin_cos_def_23 sorry
    finally show "((exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M)to-powerPOWERK2 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
       sorry
    have "(number-ePOWERK4)to-powerPOWERK2 x =HIDDENR1 exp-RSIN-COSK24 x"
      using taylor_1_th_9 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
      using sin_cos_def_23 sorry
    finally show "(number-ePOWERK4)to-powerPOWERK2 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
       sorry
    have "(number-ePOWERK4)#RPREPOWERK6 x =HIDDENR1 exp-RSIN-COSK24 x"
      using taylor_1_th_9 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x"
      using sin_cos_def_23 sorry
    finally show "(number-ePOWERK4)#RPREPOWERK6 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_11:
"number-ePOWERK4 >XXREAL-0R4 \<two>\<^sub>M"
proof-
  have " not number-ePOWERK4 >XXREAL-0R4 \<two>\<^sub>M"
  proof-
    have A1: "number-ePOWERK4 be irrationalIRRAT-1V1"
      using irrat_1_th_41 sorry
    have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds \<one>\<^sub>M <=XXREAL-0R1 n implies Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<two>\<^sub>M"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (\<one>\<^sub>M <=XXREAL-0R1 n &  not Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<two>\<^sub>M)"
      proof-
        let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .FUNCT-1K1 Lamb1 >=XXREAL-0R2 \<two>\<^sub>M"
        have A6: " for ni be IntegerINT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 ni implies (?X(ni) implies ?X(ni +XCMPLX-0K2 \<one>\<^sub>M))"
        proof-
          have " for ni be IntegerINT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 ni implies (Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .FUNCT-1K1 ni >=XXREAL-0R2 \<two>\<^sub>M implies Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .FUNCT-1K1 (ni +XCMPLX-0K2 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M)"
          proof(rule ballI,rule impI,rule impI)
            fix ni assume [ty]: "ni be IntegerINT-1M1"
            assume "\<one>\<^sub>M <=XXREAL-0R1 ni"
            then obtain n where 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = ni"
              using int_1_th_3 sorry
            have A7: "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +REAL-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
              using series_1_def_1 sorry
            also have "... = Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using sin_cos_def_5 sorry
            finally have "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
               sorry
            have A8: "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) >XXREAL-0R4 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
              using xreal_1_th_29 xreal_1_th_139 sorry
            assume "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .FUNCT-1K1 ni >=XXREAL-0R2 \<two>\<^sub>M"
            thus "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .FUNCT-1K1 (ni +XCMPLX-0K2 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M"
              using A7 A8 xxreal_0_th_2 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (\<one>\<^sub>M rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +REAL-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
          using series_1_def_1 sorry
        also have "... = (\<one>\<^sub>M rExpSeqSIN-COSK5).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M !SIN-COSK3)"
          using sin_cos_def_5 sorry
        also have "... = \<one>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M !SIN-COSK3)"
          using sin_cos_def_5 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M !SIN-COSK3)"
          using newton_th_12 sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
          using newton_th_13 sorry
        also have "... = \<two>\<^sub>M"
           sorry
        finally have "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M"
           sorry
        then have A9: "?X(\<one>\<^sub>M)"
           sorry
        have " for n be IntegerINT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n implies ?X(n)"
          using int_1_sch_2 A9 A6 sorry
        thus " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (\<one>\<^sub>M <=XXREAL-0R1 n &  not Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<two>\<^sub>M)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A10: " for n be NatNAT-1M1 holds (Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) ^\\NAT-1K7\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<two>\<^sub>M"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) ^\\NAT-1K7\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_def_3 sorry
      thus "(Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) ^\\NAT-1K7\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 \<two>\<^sub>M"
        using A5 nat_1_th_11 sorry
    qed "sorry"
    have "\<one>\<^sub>M rExpSeqSIN-COSK5 be summableSERIES-1V1"
      using sin_cos_th_45 sorry
    then have A11: "Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) be convergentSEQ-2V5"
      using series_1_def_2 sorry
    have "limSEQ-2K1 Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) =COMPLEX1R1 SumSERIES-1K4 (\<one>\<^sub>M rExpSeqSIN-COSK5)"
      using series_1_def_3 sorry
    then have "limSEQ-2K1 (Partial-SumsSERIES-1K3 (\<one>\<^sub>M rExpSeqSIN-COSK5) ^\\NAT-1K7\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =COMPLEX1R1 SumSERIES-1K4 (\<one>\<^sub>M rExpSeqSIN-COSK5)"
      using A11 seq_4_th_20 sorry
    then have "SumSERIES-1K4 (\<one>\<^sub>M rExpSeqSIN-COSK5) >=XXREAL-0R2 \<two>\<^sub>M"
      using A10 A11 sin_cos_th_38 sorry
    then have "(exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<two>\<^sub>M"
      using sin_cos_def_22 sorry
    then have "number-ePOWERK4 >=XXREAL-0R2 \<two>\<^sub>M"
      using irrat_1_def_7 sin_cos_def_23 sorry
    then have "number-ePOWERK4 >XXREAL-0R4 \<two>\<^sub>M or number-ePOWERK4 =COMPLEX1R1 \<two>\<^sub>M"
      using xxreal_0_th_1 sorry
    thus " not number-ePOWERK4 >XXREAL-0R4 \<two>\<^sub>M"
      using A1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_4:
"number-ePOWERK4 >XXREAL-0R4 \<one>\<^sub>M"
  using xxreal_0_th_2 sorry

mtheorem taylor_1_th_12:
" for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,exp-RSIN-COSK24 x) =COMPLEX1R1 x"
proof-
  have " for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,exp-RSIN-COSK24 x) =COMPLEX1R1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "exp-RSIN-COSK24 x >XXREAL-0R4 0NUMBERSK6 & (number-ePOWERK4)to-powerPOWERK2 x =COMPLEX1R1 exp-RSIN-COSK24 x"
      using taylor_1_th_9 sin_cos_th_55 sorry
    thus "logPOWERK3(number-ePOWERK4,exp-RSIN-COSK24 x) =COMPLEX1R1 x"
      using taylor_1_lm_4 power_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_13:
" for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 x) =COMPLEX1R1 x"
proof-
  have " for x be RealXREAL-0M1 holds logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 x) =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    have "logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 x) =HIDDENR1 logPOWERK3(number-ePOWERK4,exp-RSIN-COSK24 x)"
      using sin_cos_def_23 sorry
    also have "... = x"
      using taylor_1_th_12 sorry
    finally show "logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 x) =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_14:
" for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies exp-RSIN-COSK24 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
proof-
  have " for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies exp-RSIN-COSK24 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "y >XXREAL-0R4 0NUMBERSK6"
    then have "(number-ePOWERK4)to-powerPOWERK2 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
      using taylor_1_lm_4 power_def_3 sorry
    thus "exp-RSIN-COSK24 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
      using taylor_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_15:
" for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y) =COMPLEX1R1 y"
proof-
  have " for y be RealXREAL-0M1 holds y >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y) =HIDDENR1 y"
  proof(rule ballI,rule impI)
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: "y >XXREAL-0R4 0NUMBERSK6"
    have "(exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y) =HIDDENR1 exp-RSIN-COSK24 logPOWERK3(number-ePOWERK4,y)"
      using sin_cos_def_23 sorry
    also have "... = y"
      using A1 taylor_1_th_14 sorry
    finally show "(exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y) =HIDDENR1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_16:
"(((((exp-RSIN-COSK23 be one-to-oneFUNCT-1V2 & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2) & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & ( for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x)) & ( for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(exp-RSIN-COSK23,x))) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
proof-
  have "exp-RSIN-COSK23 be one-to-oneFUNCT-1V2 & ((exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2) & (( for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x) & (( for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) >XXREAL-0R4 0NUMBERSK6) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)))))"
  proof(rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) & (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) & (exp-RSIN-COSK23).FUNCT-1K1 x1 =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A1: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
        and A2: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
        and A3: "(exp-RSIN-COSK23).FUNCT-1K1 x1 =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x2"
      obtain p2 where 
        [ty]:"p2 be RealXREAL-0M1" and p2Def:"p2 = x2"
        using A2 sorry
      obtain p1 where 
        [ty]:"p1 be RealXREAL-0M1" and p1Def:"p1 = x1"
        using A1 sorry
      have "x1 =HIDDENR1 logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 p1)"
        using taylor_1_th_13 sorry
      also have "... = logPOWERK3(number-ePOWERK4,(exp-RSIN-COSK23).FUNCT-1K1 p2)"
        using A3 sorry
      also have "... = x2"
        using taylor_1_th_13 sorry
      finally show "x1 =HIDDENR1 x2"
         sorry
    qed "sorry"
    thus "exp-RSIN-COSK23 be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
    show "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 REALNUMBERSK2 & exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 [#]SUBSET-1K2 REALNUMBERSK2"
      using sin_cos_th_66 sorry
    show " for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
      using sin_cos_th_66 sorry
    show " for x be RealXREAL-0M1 holds diffFDIFF-1K1(exp-RSIN-COSK23,x) >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have "diffFDIFF-1K1(exp-RSIN-COSK23,x) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using sin_cos_th_66 sorry
      thus "diffFDIFF-1K1(exp-RSIN-COSK23,x) >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
    qed "sorry"
    show "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
      using sin_cos_th_47 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) implies y inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"and A5: "y =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using funct_1_def_3 sorry
      obtain y1 where 
        [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
        using A5 sorry
      have 
        [ty]:"x be RealXREAL-0M1"
        using A4 sorry
      have "(exp-RSIN-COSK23).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using sin_cos_th_54 sorry
      then have "y1 inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
        using A5 sorry
      thus "y inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using xxreal_1_th_230 sorry
    qed "sorry"
    then have A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) c=TARSKIR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using tarski_def_3 sorry
    have " for y be objectHIDDENM1 holds y inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      then have "y inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
        using xxreal_1_th_230 sorry
      then have A7: " ex g be RealXREAL-0M1 st y =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
         sorry
      then obtain y1 where 
        [ty]:"y1 be RealXREAL-0M1" and y1Def:"y1 = y"
         sorry
      have A8: "logPOWERK3(number-ePOWERK4,y1) inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "y1 =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,y1)"
        using A7 taylor_1_th_15 sorry
      thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
        using funct_1_def_3 sin_cos_th_47 A8 sorry
    qed "sorry"
    then have "right-open-halflineLIMFUNC1K4 (0NUMBERSK6) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using tarski_def_3 sorry
    thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using A6 xboole_0_def_10 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_cl_1:
"cluster exp-RSIN-COSK23 as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "exp-RSIN-COSK23 be one-to-oneFUNCT-1V2"
    using taylor_1_th_16 sorry
qed "sorry"

mtheorem taylor_1_th_17:
"(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) implies diffFDIFF-1K1((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)"
proof(rule conjMI,rule ballI,rule impI)
  show "(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
    using taylor_1_th_16 fdiff_2_th_45 sorry
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
  have A2: "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
    using A1 funct_1_th_33 sorry
  have "diffFDIFF-1K1(exp-RSIN-COSK23,(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x)"
    using taylor_1_th_16 sorry
  also have "... = x"
    using A2 funct_1_th_35 sorry
  finally have "diffFDIFF-1K1(exp-RSIN-COSK23,(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 x) =HIDDENR1 x"
     sorry
  thus "diffFDIFF-1K1((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x"
    using A1 taylor_1_th_16 fdiff_2_th_45 sorry
qed "sorry"

mtheorem taylor_1_cl_2:
"cluster right-open-halflineLIMFUNC1K4 (0NUMBERSK6) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "right-open-halflineLIMFUNC1K4 (0NUMBERSK6) be  non emptyXBOOLE-0V1"
  proof-
    have " not right-open-halflineLIMFUNC1K4 (0NUMBERSK6) be emptyXBOOLE-0V1"
    proof-
      have "\<one>\<^sub>M inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
         sorry
      thus " not right-open-halflineLIMFUNC1K4 (0NUMBERSK6) be emptyXBOOLE-0V1"
        using xxreal_1_th_230 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef taylor_1_def_2 ("log-TAYLOR-1K2  _ " [164]164 ) where
  mlet "a be RealXREAL-0M1"
"func log-TAYLOR-1K2 a \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
    proof-
      have " ex tVar2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds tVar2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        have 
          [ty]:"a be RealXREAL-0M1"
           sorry
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(logPOWERK3(a,Lamb1),REALNUMBERSK2)"
        obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f iff ?X(d)"and A2: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using partfun2_sch_2 sorry
        show " ex tVar2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds tVar2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
          have " for x be objectHIDDENM1 holds x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          then have A3: "right-open-halflineLIMFUNC1K4 (0NUMBERSK6) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using A1 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using tarski_def_3 sorry
          thus A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using A3 xboole_0_def_10 sorry
          fix d assume [ty]: "d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          have "f /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
            using A2 A4 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d)"
            using A4 partfun1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it1 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & (( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f1 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d)))) implies f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          and A6: " for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f1 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d)"
          and A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          and A8: " for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f2 .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(a,d)"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies f1 .FUNCT-1K1 d =COMPLEX1R1 f2 .FUNCT-1K1 d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies f1 .FUNCT-1K1 d =HIDDENR1 f2 .FUNCT-1K1 d"
          proof(rule ballI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A9: "d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            have "f1 .FUNCT-1K1 d =HIDDENR1 logPOWERK3(a,d)"
              using A6 A9 sorry
            also have "... = f2 .FUNCT-1K1 d"
              using A8 A9 sorry
            finally show "f1 .FUNCT-1K1 d =HIDDENR1 f2 .FUNCT-1K1 d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          using A5 A7 partfun1_th_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef taylor_1_def_3 ("lnTAYLOR-1K3" 164 ) where
"func lnTAYLOR-1K3 \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) equals
  log-TAYLOR-1K2 (number-ePOWERK4)"
proof-
  (*coherence*)
    show "log-TAYLOR-1K2 (number-ePOWERK4) be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
       sorry
qed "sorry"

mtheorem taylor_1_th_18:
"((((((lnTAYLOR-1K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> & lnTAYLOR-1K3 be one-to-oneFUNCT-1V2) & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 REALNUMBERSK2) & lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & ( for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds diffFDIFF-1K1(lnTAYLOR-1K3,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x))"
proof-
  have "lnTAYLOR-1K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> & (lnTAYLOR-1K3 be one-to-oneFUNCT-1V2 & (((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 REALNUMBERSK2) & lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & ( for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x))) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds diffFDIFF-1K1(lnTAYLOR-1K3,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds  not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x))))"
  proof(rule conjMI,rule conjMI)
    have A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies (exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 d =COMPLEX1R1 (lnTAYLOR-1K3).FUNCT-1K1 d"
    proof(rule ballI,rule impI)
      fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
      assume A2: "d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      have "(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(number-ePOWERK4,d)"
      proof-
        have A3: "logPOWERK3(number-ePOWERK4,d) inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "d inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
          using A2 xxreal_1_th_230 sorry
        then have " ex g be RealXREAL-0M1 st g =COMPLEX1R1 d & g >XXREAL-0R4 0NUMBERSK6"
           sorry
        then have "d =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,d)"
          using taylor_1_th_15 sorry
        thus "(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 d =COMPLEX1R1 logPOWERK3(number-ePOWERK4,d)"
          using taylor_1_th_16 funct_1_th_32 A3 sorry
      qed
      thus "(exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .FUNCT-1K1 d =COMPLEX1R1 (lnTAYLOR-1K3).FUNCT-1K1 d"
        using A2 taylor_1_def_2 sorry
    qed "sorry"
    have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using taylor_1_th_16 funct_1_th_33 sorry
    then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using taylor_1_def_2 sorry
    thus A5: "lnTAYLOR-1K3 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>"
      using A4 A1 partfun1_th_5 sorry
    have A6: " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x >XXREAL-0R4 0NUMBERSK6"
      then have "x inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
         sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using xxreal_1_th_230 sorry
      thus "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A4 A5 taylor_1_th_17 fdiff_1_th_9 sorry
    qed "sorry"
    have A7: " for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x)"
    proof-
      have " for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds  not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x)"
      proof(rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        have "x inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
           sorry
        then have "x inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
          using xxreal_1_th_230 sorry
        then have A8: " ex g be RealXREAL-0M1 st x =COMPLEX1R1 g & 0NUMBERSK6 <XXREAL-0R3 g"
           sorry
        have "\<one>\<^sub>M /XCMPLX-0K7 x =COMPLEX1R1 x \<inverse>REAL-1K2"
          using xcmplx_1_th_215 sorry
        thus " not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x)"
          using A4 A5 A8 taylor_1_th_17 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show "lnTAYLOR-1K3 be one-to-oneFUNCT-1V2"
      using A5 funct_1_th_40 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using taylor_1_def_2 sorry
    thus "((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) =XBOOLE-0R4 REALNUMBERSK2) & lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)) & ( for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x))) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds diffFDIFF-1K1(lnTAYLOR-1K3,x) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 x)) & ( for x be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds  not 0NUMBERSK6 <XXREAL-0R3 diffFDIFF-1K1(lnTAYLOR-1K3,x))"
      using A5 A6 A7 taylor_1_th_16 taylor_1_th_17 funct_1_th_33 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_19:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x0) *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x0) *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
    have A2: "x0 be RealXREAL-0M1 & exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x0"
      using taylor_1_th_16 fdiff_1_th_9 xreal_0_def_1 sorry
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A1 fdiff_2_th_13 sorry
    have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,f .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A1 A2 fdiff_2_th_13 sorry
    also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x0) *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using taylor_1_th_16 sorry
    finally show "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 (f .FUNCT-1K1 x0) *XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_20:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
      and A2: "f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6"
    have "f .FUNCT-1K1 x0 inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
      using A2 sorry
    then have A3: "f .FUNCT-1K1 x0 inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using xxreal_1_th_230 sorry
    then have A4: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x0"
      using taylor_1_th_18 fdiff_1_th_9 sorry
    show "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A1 A4 fdiff_2_th_13 sorry
    have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(lnTAYLOR-1K3,f .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A1 A4 fdiff_2_th_13 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 f .FUNCT-1K1 x0)*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A3 taylor_1_th_18 sorry
    also have "... = ((diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0)*XCMPLX-0K3 \<one>\<^sub>M"
      using xcmplx_1_th_75 sorry
    also have "... = (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0"
       sorry
    finally show "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(f,x0))/XCMPLX-0K7 f .FUNCT-1K1 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef taylor_1_def_4 ("#RTAYLOR-1K4  _ " [220]220 ) where
  mlet "p be RealXREAL-0M1"
"func #RTAYLOR-1K4 p \<rightarrow> PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
proof-
  (*existence*)
    show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
    proof-
      have " ex tVar3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar3 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds tVar3 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
      proof-
        let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        have 
          [ty]:"p be RealXREAL-0M1"
           sorry
        let ?U = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1 #RPREPOWERK6 p,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f iff ?X(d)"and A2: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using partfun2_sch_2 sorry
        show " ex tVar3 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar3 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds tVar3 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI)
          have " for x be objectHIDDENM1 holds x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A1 sorry
          then have A3: "right-open-halflineLIMFUNC1K4 (0NUMBERSK6) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using A1 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using tarski_def_3 sorry
          thus A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            using A3 xboole_0_def_10 sorry
          fix d assume [ty]: "d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          have "f /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
            using A2 A4 sorry
          thus "f .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p"
            using A4 partfun1_def_6 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it1 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> it2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds it2 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p)) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & (( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f1 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p) & (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) & ( for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f2 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p))) implies f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          and A6: " for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f1 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p"
          and A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          and A8: " for d be ElementSUBSET-1M3\<^bsub>(REALNUMBERSK2)\<^esub>-of right-open-halflineLIMFUNC1K4 (0NUMBERSK6) holds f2 .FUNCT-1K1 d =COMPLEX1R1 d #RPREPOWERK6 p"
        have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies f1 .FUNCT-1K1 d =COMPLEX1R1 f2 .FUNCT-1K1 d"
        proof-
          have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies f1 .FUNCT-1K1 d =HIDDENR1 f2 .FUNCT-1K1 d"
          proof(rule ballI,rule impI)
            fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
            assume A9: "d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
            have "f1 .FUNCT-1K1 d =HIDDENR1 d #RPREPOWERK6 p"
              using A6 A9 sorry
            also have "... = f2 .FUNCT-1K1 d"
              using A8 A9 sorry
            finally show "f1 .FUNCT-1K1 d =HIDDENR1 f2 .FUNCT-1K1 d"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2"
          using A5 A7 partfun1_th_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem taylor_1_th_21:
" for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies #RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#RTAYLOR-1K4 p,x) =COMPLEX1R1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
proof-
  have " for p be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  not ( not x >XXREAL-0R4 0NUMBERSK6 &  not (#RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#RTAYLOR-1K4 p,x) =COMPLEX1R1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    let ?f = "#RTAYLOR-1K4 p"
    have A1: " for x be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 x implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)),x) =COMPLEX1R1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
    proof-
      have " for x be RealXREAL-0M1 holds x >XXREAL-0R4 0NUMBERSK6 implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)),x) =HIDDENR1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
      proof(rule ballI,rule impI,rule conjMI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A2: "x >XXREAL-0R4 0NUMBERSK6"
        have A3: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
          using A2 taylor_1_th_18 sorry
        then have A4: "p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_15 sorry
        have "x inHIDDENR3 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
          using A2 sorry
        then have A5: "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using xxreal_1_th_230 sorry
        then have A6: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
          using taylor_1_th_18 valued_1_def_5 sorry
        have A7: "diffFDIFF-1K1(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 p *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
          using A3 fdiff_1_th_15 sorry
        also have "... = p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
          using A5 taylor_1_th_18 sorry
        finally have "diffFDIFF-1K1(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x)"
           sorry
        have A8: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)).FUNCT-1K1 x"
          using sin_cos_th_65 sorry
        thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) is-differentiable-inFDIFF-1R1 x"
          using A4 fdiff_2_th_13 sorry
        have "diffFDIFF-1K1(exp-RSIN-COSK23,(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)).FUNCT-1K1 x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)).FUNCT-1K1 x)"
          using taylor_1_th_16 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 x)"
          using A6 valued_1_def_5 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,x))"
          using A5 taylor_1_def_2 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,x to-powerPOWERK2 p)"
          using A2 taylor_1_lm_4 power_th_55 sorry
        also have "... = x to-powerPOWERK2 p"
          using A2 taylor_1_th_15 power_th_34 sorry
        finally have "diffFDIFF-1K1(exp-RSIN-COSK23,(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)).FUNCT-1K1 x) =HIDDENR1 x to-powerPOWERK2 p"
           sorry
        then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)),x) =HIDDENR1 x to-powerPOWERK2 p *XCMPLX-0K3 (p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))"
          using A4 A8 A7 fdiff_2_th_13 sorry
        also have "... = p *XCMPLX-0K3 (x to-powerPOWERK2 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x))"
           sorry
        also have "... = p *XCMPLX-0K3 (x to-powerPOWERK2 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x to-powerPOWERK2 \<one>\<^sub>M))"
          using power_th_25 sorry
        also have "... = p *XCMPLX-0K3 (x to-powerPOWERK2 p *XCMPLX-0K3 x to-powerPOWERK2 (-XCMPLX-0K4 \<one>\<^sub>M))"
          using A2 power_th_28 sorry
        also have "... = p *XCMPLX-0K3 x to-powerPOWERK2 (p +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))"
          using A2 power_th_27 sorry
        also have "... = p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
          using A2 power_def_2 sorry
        finally show "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)),x) =HIDDENR1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using taylor_1_th_16 sorry
    then have A9: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
      using relat_1_th_27 sorry
    also have "... = right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using taylor_1_th_18 valued_1_def_5 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))) =HIDDENR1 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
       sorry
    have A10: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))).FUNCT-1K1 d =COMPLEX1R1 ?f .FUNCT-1K1 d"
    proof-
      have " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6) implies ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))).FUNCT-1K1 d =HIDDENR1 #RTAYLOR-1K4 p .FUNCT-1K1 d"
      proof(rule ballI,rule impI)
        fix d assume [ty]: "d be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume A11: "d inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        have A12: "d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
          using A11 taylor_1_th_18 valued_1_def_5 sorry
        have "d inTARSKIR2 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
          using A11 xxreal_1_th_230 sorry
        then have A13: " ex g be RealXREAL-0M1 st g =COMPLEX1R1 d & g >XXREAL-0R4 0NUMBERSK6"
           sorry
        have "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))).FUNCT-1K1 d =HIDDENR1 ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)))/.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d"
          using A9 A11 partfun1_def_6 sorry
        also have "... = (exp-RSIN-COSK23)/.FUNCT-2K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))/.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d)"
          using A9 A11 partfun2_th_3 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 ((p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)).FUNCT-1K1 d)"
          using A12 partfun1_def_6 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 (lnTAYLOR-1K3).FUNCT-1K1 d)"
          using A12 valued_1_def_5 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 (p *XCMPLX-0K3 logPOWERK3(number-ePOWERK4,d))"
          using A11 taylor_1_def_2 sorry
        also have "... = (exp-RSIN-COSK23).FUNCT-1K1 logPOWERK3(number-ePOWERK4,d to-powerPOWERK2 p)"
          using A13 taylor_1_lm_4 power_th_55 sorry
        also have "... = d to-powerPOWERK2 p"
          using A13 taylor_1_th_15 power_th_34 sorry
        also have "... = d #RPREPOWERK6 p"
          using A13 power_def_2 sorry
        also have "... = #RTAYLOR-1K4 p .FUNCT-1K1 d"
          using A11 taylor_1_def_4 sorry
        finally show "((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))).FUNCT-1K1 d =HIDDENR1 #RTAYLOR-1K4 p .FUNCT-1K1 d"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f =XBOOLE-0R4 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
      using taylor_1_def_4 sorry
    then have "x be RealXREAL-0M1 & (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?f"
      using A9 A10 partfun1_th_5 sorry
    thus " not ( not x >XXREAL-0R4 0NUMBERSK6 &  not (#RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#RTAYLOR-1K4 p,x) =COMPLEX1R1 p *XCMPLX-0K3 x #RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M)))"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_22:
" for p be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies #RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =COMPLEX1R1 (p *XCMPLX-0K3 (f .FUNCT-1K1 x0)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
proof-
  have " for p be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-differentiable-inFDIFF-1R1 x0 & f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6 implies #RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0 & diffFDIFF-1K1(#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (p *XCMPLX-0K3 (f .FUNCT-1K1 x0)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-differentiable-inFDIFF-1R1 x0"
      and A2: "f .FUNCT-1K1 x0 >XXREAL-0R4 0NUMBERSK6"
    have A3: "#RTAYLOR-1K4 p is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x0"
      using A2 taylor_1_th_21 sorry
    thus "#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x0"
      using A1 fdiff_2_th_13 sorry
    have "diffFDIFF-1K1(#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (diffFDIFF-1K1(#RTAYLOR-1K4 p,f .FUNCT-1K1 x0))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A1 A3 fdiff_2_th_13 sorry
    also have "... = (p *XCMPLX-0K3 (f .FUNCT-1K1 x0)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
      using A2 taylor_1_th_21 sorry
    finally show "diffFDIFF-1K1(#RTAYLOR-1K4 p *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x0) =HIDDENR1 (p *XCMPLX-0K3 (f .FUNCT-1K1 x0)#RPREPOWERK6 (p -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x0))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef taylor_1_def_5 ("diffTAYLOR-1K5'( _ , _ ')" [0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
"func diffTAYLOR-1K5(f,Z) \<rightarrow> Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it. it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
proof-
  (*existence*)
    show " ex it be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) st it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
    proof-
      have " ex tVar4 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
      proof-
        obtain fZ where 
          [ty]:"fZ be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2)" and fZDef:"fZ = f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z"
          using partfun1_th_45 sorry
        let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  ex h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st Lamb2 =XBOOLE-0R4 h & Lamb3 =XBOOLE-0R4 h `|FDIFF-1K2 Z"
        have A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2) holds  ex y be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2) st ?R(n,x,y)"
        proof-
          have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2) holds  not ( for y be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2) holds  not ( ex h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st x =XBOOLE-0R4 h & y =XBOOLE-0R4 h `|FDIFF-1K2 Z))"
          proof(rule ballI,rule ballI)
            fix n assume [ty]: "n be NatNAT-1M1"
            fix x assume [ty]: "x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2)"
            obtain x9 where 
              [ty]:"x9 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and x9Def:"x9 = x"
              using partfun1_th_46 sorry
            obtain y where 
              [ty]:"y be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2)" and yDef:"y = x9 `|FDIFF-1K2 Z"
              using partfun1_th_45 sorry
            have " ex h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st x =XBOOLE-0R4 h & y =XBOOLE-0R4 h `|FDIFF-1K2 Z"
               sorry
            thus " not ( for y be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2) holds  not ( ex h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st x =XBOOLE-0R4 h & y =XBOOLE-0R4 h `|FDIFF-1K2 Z))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain g where
          [ty]:"g be sequenceNAT-1M2-of PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2)" and 
          A2: "g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 fZ & ( for n be NatNAT-1M1 holds ?R(n,g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n,g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
          using recdef_1_sch_2 A1 sorry
        have 
          [ty]:"g be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
           sorry
        show " ex tVar4 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar4 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)"
        proof(rule bexI[of _ "g"],rule conjMI,rule ballI)
          show "g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z"
            using A2 sorry
          fix i assume [ty]: "i be NatNAT-1M1"
          have "?R(i,g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i,g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M))"
            using A2 sorry
          thus "g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds (it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)) & (it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for i be NatNAT-1M1 holds it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> it2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i `|FDIFF-1K2 Z)) implies it1 =HIDDENR1 it2"
    proof-
      have " for seq1 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for seq2 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2) holds seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & (( for n be NatNAT-1M1 holds seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n `|FDIFF-1K2 Z) & (seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z & ( for n be NatNAT-1M1 holds seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n `|FDIFF-1K2 Z))) implies seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2))\<^esub> seq2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix seq1 assume [ty]: "seq1 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix seq2 assume [ty]: "seq2 be Functional-SequenceSEQFUNCM1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A3: "seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z"
          and A4: " for n be NatNAT-1M1 holds seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n `|FDIFF-1K2 Z"
          and A5: "seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z"
          and A6: " for n be NatNAT-1M1 holds seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n `|FDIFF-1K2 Z"
        let ?P = "\<lambda>Lamb1. seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1"
        have A7: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for k be NatNAT-1M1 holds seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k implies seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A8: "?P(k)"
            have "seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z"
              using A4 sorry
            also have "... = seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A6 A8 sorry
            finally show "seq1 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 seq2 .SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A9: "?P(0NUMBERSK6)"
          using A3 A5 sorry
        have " for n be NatNAT-1M1 holds ?P(n)"
          using nat_1_sch_2 A9 A7 sorry
        thus "seq1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,PFuncsPARTFUN1K4(REALNUMBERSK2,REALNUMBERSK2))\<^esub> seq2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef taylor_1_def_6 (" _ is-differentiable-onTAYLOR-1R1'( _ , _ ')" [50,0,0]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "n be NatNAT-1M1", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
"pred f is-differentiable-onTAYLOR-1R1(n,Z) means
   for i be NatNAT-1M1 holds i <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M implies (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i is-differentiable-onFDIFF-1R2 Z"..

mtheorem taylor_1_th_23:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for m be NatNAT-1M1 holds m <=XXREAL-0R1 n implies f is-differentiable-onTAYLOR-1R1(m,Z))"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "f is-differentiable-onTAYLOR-1R1(n,Z)"
  fix m assume [ty]: "m be NatNAT-1M1"
  assume A2: "m <=XXREAL-0R1 n"
  have " for i be NatNAT-1M1 holds i <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M implies (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i is-differentiable-onFDIFF-1R2 Z"
  proof(rule ballI,rule impI)
    have A3: "m -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_13 sorry
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "i <=XXREAL-0R1 m -XCMPLX-0K6 \<one>\<^sub>M"
    then have "i <=XXREAL-0R1 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 xxreal_0_th_2 sorry
    thus "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> i is-differentiable-onFDIFF-1R2 Z"
      using A1 sorry
  qed "sorry"
  thus "f is-differentiable-onTAYLOR-1R1(m,Z)"
     sorry
qed "sorry"

mdef taylor_1_def_7 ("TaylorTAYLOR-1K6'( _ , _ , _ , _ ')" [0,0,0,0]164 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "Z be SubsetSUBSET-1M2-of REALNUMBERSK2", "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"func TaylorTAYLOR-1K6(f,Z,a,b) \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      have " ex tVar5 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof-
        let ?F = "\<lambda>Lamb1. (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 Lamb1)/XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
        obtain seq where
          [ty]:"seq be Real-SequenceSEQ-1M1" and 
          A1: " for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          using seq_1_sch_1 sorry
        show " ex tVar5 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar5 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
        proof(rule bexI[of _ "seq"],rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          show "seq .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds it2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) implies it1 =HIDDENR1 it2"
    proof-
      have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) & ( for n be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)) implies s1 =HIDDENR1 s2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 Lamb1)/XCMPLX-0K7 (Lamb1 !SIN-COSK3)"
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
        assume A2: " for n be NatNAT-1M1 holds s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
          and A3: " for n be NatNAT-1M1 holds s2 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 ?F(n)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies s1 .FUNCT-1K1 x =HIDDENR1 s2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 NATNUMBERSK1"
          then obtain n where 
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = x"
             sorry
          have "s1 .FUNCT-1K1 x =HIDDENR1 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n).FUNCT-1K1 a *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
            using A2 sorry
          also have "... = s2 .FUNCT-1K1 x"
            using A3 sorry
          finally show "s1 .FUNCT-1K1 x =HIDDENR1 s2 .FUNCT-1K1 x"
             sorry
        qed "sorry"
        thus "s1 =HIDDENR1 s2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma taylor_1_lm_5:
" for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M))"
proof-
  have " for b be RealXREAL-0M1 holds  ex tVar6 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar6 =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds tVar6 .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x & ( for x be RealXREAL-0M1 holds tVar6 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tVar6,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M))"
  proof(rule ballI)
    let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 REALNUMBERSK2"
    fix b assume [ty]: "b be RealXREAL-0M1"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10(b -XCMPLX-0K6 Lamb1,REALNUMBERSK2)"
    obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g iff ?X(d)"and A2: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
      using partfun2_sch_2 sorry
    show " ex tVar6 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar6 =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds tVar6 .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x & ( for x be RealXREAL-0M1 holds tVar6 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tVar6,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M))"
    proof(rule bexI[of _ "g"])
      have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using A1 sorry
      then have A3: "REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using tarski_def_3 sorry
      then have A4: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
        using xboole_0_def_10 sorry
      have A5: " for d be RealXREAL-0M1 holds g .FUNCT-1K1 d =COMPLEX1R1 b -XCMPLX-0K6 d"
      proof(rule ballI)
        fix d assume [ty]: "d be RealXREAL-0M1"
        have 
          [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using A2 A4 sorry
        thus "g .FUNCT-1K1 d =COMPLEX1R1 b -XCMPLX-0K6 d"
          using A4 partfun1_def_6 sorry
      qed "sorry"
      have A6: " for d be RealXREAL-0M1 holds d inHIDDENR3 REALNUMBERSK2 implies g .FUNCT-1K1 d =COMPLEX1R1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 b"
      proof-
        have " for d be RealXREAL-0M1 holds d inHIDDENR3 REALNUMBERSK2 implies g .FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 b"
        proof(rule ballI,rule impI)
          fix d assume [ty]: "d be RealXREAL-0M1"
          assume "d inHIDDENR3 REALNUMBERSK2"
          have "g .FUNCT-1K1 d =HIDDENR1 b -XCMPLX-0K6 d"
            using A5 sorry
          also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 b"
             sorry
          finally show "g .FUNCT-1K1 d =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 d +XCMPLX-0K2 b"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A7: "g is-differentiable-onFDIFF-1R2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using A4 fdiff_1_th_23 sorry
      have " for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
      proof-
        have " for dd be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 dd & diffFDIFF-1K1(g,dd) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
        proof(rule ballI,rule conjMI)
          fix dd assume [ty]: "dd be RealXREAL-0M1"
          obtain d where 
            [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2" and dDef:"d = dd"
            using xreal_0_def_1 sorry
          have "g is-differentiable-inFDIFF-1R1 d"
            using A4 A7 fdiff_1_th_9 sorry
          thus "g is-differentiable-inFDIFF-1R1 dd"
             sorry
          have "diffFDIFF-1K1(g,dd) =HIDDENR1 (g `|FDIFF-1K2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g).FUNCT-1K1 d"
            using A4 A7 fdiff_1_def_7 sorry
          also have "... = -XCMPLX-0K4 \<one>\<^sub>M"
            using A4 A6 fdiff_1_th_23 sorry
          finally show "diffFDIFF-1K1(g,dd) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M))"
        using A3 A5 xboole_0_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_6:
" for n be NatNAT-1M1 holds  for l be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
proof-
  have " for n be NatNAT-1M1 holds  for l be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  ex tVar7 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar7 =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds tVar7 .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & ( for x be RealXREAL-0M1 holds tVar7 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tVar7,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
  proof(rule ballI,rule ballI,rule ballI)
    let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 REALNUMBERSK2"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix l assume [ty]: "l be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10((l *XCMPLX-0K3 (b -XCMPLX-0K6 Lamb1) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3),REALNUMBERSK2)"
    obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g iff ?X(d)"and A2: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
      using partfun2_sch_2 sorry
    show " ex tVar7 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar7 =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds tVar7 .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & ( for x be RealXREAL-0M1 holds tVar7 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tVar7,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
    proof(rule bexI[of _ "g"])
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
        A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A4: " for x be RealXREAL-0M1 holds f .FUNCT-1K1 x =COMPLEX1R1 b -XCMPLX-0K6 x"and A5: " for x be RealXREAL-0M1 holds f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(f,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
        using taylor_1_lm_5 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M)) =XBOOLE-0R4 REALNUMBERSK2 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 REALNUMBERSK2"
        using funct_2_def_1 sorry
      then have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using relat_1_th_27 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 REALNUMBERSK2 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using A1 sorry
      then have A7: "REALNUMBERSK2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using tarski_def_3 sorry
      then have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
        using xboole_0_def_10 sorry
      have A9: " for d be RealXREAL-0M1 holds g .FUNCT-1K1 d =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 d) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      proof(rule ballI)
        fix d assume [ty]: "d be RealXREAL-0M1"
        have 
          [ty]:"d be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
          using A2 A8 sorry
        thus "g .FUNCT-1K1 d =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 d) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using A8 partfun1_def_6 sorry
      qed "sorry"
      have A10: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) implies ((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
        assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
        then have "((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
          using valued_1_def_5 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> x"
          using A3 A6 partfun1_def_6 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 #ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) /.FUNCT-2K10\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> x)"
          using A3 A6 partfun2_th_3 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 #ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 (f .FUNCT-1K1 x)"
          using A3 partfun1_def_6 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (f .FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
          using taylor_1_def_1 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 f .FUNCT-1K1 x  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using prepower_th_36 sorry
        also have "... = (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using A4 sorry
        also have "... = (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using xcmplx_1_th_74 sorry
        also have "... = g .FUNCT-1K1 x"
          using A9 sorry
        finally show "((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed "sorry"
      have A11: " for x be RealXREAL-0M1 holds #ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =COMPLEX1R1 -XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x)#ZPREPOWERK3 n"
      proof-
        have " for xx be RealXREAL-0M1 holds #ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 xx & diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,xx) =HIDDENR1 -XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 xx)#ZPREPOWERK3 n"
        proof(rule ballI,rule conjMI)
          fix xx assume [ty]: "xx be RealXREAL-0M1"
          obtain x where 
            [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
             sorry
          have A12: "f is-differentiable-inFDIFF-1R1 x & #ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
            using A5 taylor_1_th_2 sorry
          thus "#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 xx"
            using fdiff_2_th_13 sorry
          have "diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 x) =COMPLEX1R1 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#ZPREPOWERK3 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using taylor_1_th_2 sorry
          then have "diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,xx) =HIDDENR1 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#ZPREPOWERK3 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
            using A12 fdiff_2_th_13 sorry
          also have "... = ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (f .FUNCT-1K1 x)#ZPREPOWERK3 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
            using A5 sorry
          also have "... = ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x)#ZPREPOWERK3 ((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
            using A4 sorry
          also have "... = -XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 xx)#ZPREPOWERK3 n"
             sorry
          finally show "diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,xx) =HIDDENR1 -XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 xx)#ZPREPOWERK3 n"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A13: " for x be RealXREAL-0M1 holds (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof(rule ballI,rule conjMI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        have A14: "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 (\<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n !SIN-COSK3)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
          using newton_th_15 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (n !SIN-COSK3)"
          using xcmplx_1_th_91 sorry
        finally have "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
        have A15: "#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
          using A11 sorry
        thus "(l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_15 sorry
        have "diffFDIFF-1K1((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 (l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))"
          using A15 fdiff_1_th_15 sorry
        also have "... = ((diffFDIFF-1K1(#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 l"
          using xcmplx_1_th_75 sorry
        also have "... = l *XCMPLX-0K3 ((-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x)#ZPREPOWERK3 n)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          using A11 sorry
        also have "... = l *XCMPLX-0K3 ((-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          using prepower_th_36 sorry
        also have "... = (l *XCMPLX-0K3 (-XCMPLX-0K4 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using xcmplx_1_th_74 sorry
        also have "... = ((-XCMPLX-0K4 l)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
           sorry
        also have "... = (-XCMPLX-0K4 l)*XCMPLX-0K3 (((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          using xcmplx_1_th_74 sorry
        also have "... = (-XCMPLX-0K4 l)*XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 n *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
          using xcmplx_1_th_74 sorry
        also have "... = (-XCMPLX-0K4 l)*XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 n /XCMPLX-0K7 (n !SIN-COSK3))"
          using A14 xcmplx_1_th_99 sorry
        also have "... = -XCMPLX-0K4 l *XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 n /XCMPLX-0K7 (n !SIN-COSK3))"
           sorry
        also have "... = -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
          using xcmplx_1_th_74 sorry
        finally show "diffFDIFF-1K1((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f),x) =HIDDENR1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using A8 A3 A6 valued_1_def_5 sorry
      then have "(l /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 (n +NAT-1K1 \<one>\<^sub>M) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> g"
        using A10 partfun1_th_5 sorry
      thus "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & ( for x be RealXREAL-0M1 holds g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
        using A7 A9 A13 xboole_0_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_7:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  ex tVar8 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar8 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar8 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix b assume [ty]: "b be RealXREAL-0M1"
    let ?X = "\<lambda>Lamb1. Lamb1 inTARSKIR2 Z"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,Lamb1,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,REALNUMBERSK2)"
    obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g iff ?X(d)"and A2: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds d inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g implies g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
      using partfun2_sch_2 sorry
    show " ex tVar8 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar8 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar8 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
    proof(rule bexI[of _ "g"])
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g implies x inHIDDENR3 Z"
        using A1 sorry
      then have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g c=TARSKIR1 Z"
        using tarski_def_3 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 Z implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using A1 sorry
      then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g"
        using tarski_def_3 sorry
      have " for d be RealXREAL-0M1 holds d inHIDDENR3 Z implies g .FUNCT-1K1 d =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,d,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      proof(rule ballI,rule impI)
        fix d assume [ty]: "d be RealXREAL-0M1"
        assume A5: "d inHIDDENR3 Z"
        have "g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =HIDDENR1 ?U(d)"
          using A2 A4 A5 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,d,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        finally have "g /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> d =HIDDENR1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,d,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
           sorry
        thus "g .FUNCT-1K1 d =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,d,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
          using A4 A5 partfun1_def_6 sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))"
        using A3 A4 xboole_0_def_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_24:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for k be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(k,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?P = "\<lambda>Lamb1. f is-differentiable-onTAYLOR-1R1(Lamb1,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1)"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (f is-differentiable-onTAYLOR-1R1(k,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k)) implies (f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule ballI,rule impI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "?P(k)"
        assume A3: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A4: "a <XXREAL-0R3 b"
          and A5: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
        have A6: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
          using A3 sorry
        then have A7: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A5 fdiff_1_th_26 sorry
        then have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)) =XBOOLE-0R4 ].RCOMP-1K2 a,b .["
          using fdiff_1_def_7 sorry
        have A9: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using relat_1_th_61 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A6 fdiff_1_def_7 sorry
        also have "... = ].RCOMP-1K2 a,b .["
          using A5 xboole_1_th_28 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 ].RCOMP-1K2 a,b .["
           sorry
        have A10: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) implies (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          assume A11: "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
          have "(((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z).FUNCT-1K1 x"
            using A9 A11 funct_1_th_49 sorry
          also have "... = diffFDIFF-1K1((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k,x)"
            using A5 A6 A9 A11 fdiff_1_def_7 sorry
          also have "... = ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A7 A9 A11 fdiff_1_def_7 sorry
          finally show "(((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
             sorry
        qed "sorry"
        have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using taylor_1_def_5 sorry
        also have "... = (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
          using A9 A8 A10 partfun1_th_5 sorry
        also have "... = ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
          using A7 fdiff_2_th_16 sorry
        also have "... = (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
          using A2 A3 A4 A5 taylor_1_th_23 nat_1_th_11 sorry
        also have "... = (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using taylor_1_def_5 sorry
        finally show "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: "?P(0NUMBERSK6)"
    proof-
      have "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
        assume "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume "a <XXREAL-0R3 b"
          and A13: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
        have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using taylor_1_def_5 sorry
        also have "... = f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A13 funct_1_th_51 sorry
        also have "... = (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using taylor_1_def_5 sorry
        finally show "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for k be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(k,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ].RCOMP-1K2 a,b .[ c=TARSKIR1 Z implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k)"
      using nat_1_sch_2 A12 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_8:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds  not (f is-differentiable-onTAYLOR-1R1(n,Z) &  not ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (((( not a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) &  not ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) &  not (((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))))))))"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    let ?P = "\<lambda>Lamb1. f is-differentiable-onTAYLOR-1R1(Lamb1,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(Lamb1 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1) implies ((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 Lamb1)/XCMPLX-0K7 (Lamb1 !SIN-COSK3))))"
    have A2: "?P(0NUMBERSK6)"
    proof-
      have "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)) implies g .FUNCT-1K1 b =HIDDENR1 0NUMBERSK6 & (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & (g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)))))))"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
        assume "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A3: "a <XXREAL-0R3 b"
          and A4: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
          and A5: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          and A6: "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
        have A7: "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
          using xxreal_1_th_25 sorry
        then have A8: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
          using A4 xboole_1_th_1 sorry
        fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A9: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z"
          and A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        have A11: "b inHIDDENR3 [.RCOMP-1K1 a,b .]"
          using A3 xxreal_1_th_1 sorry
        then have "g .FUNCT-1K1 b =HIDDENR1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using A4 A10 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,b,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 b *XCMPLX-0K3 (b -XCMPLX-0K6 b) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using taylor_1_def_7 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 b *XCMPLX-0K3 (b -XCMPLX-0K6 b) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using taylor_1_def_5 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (f .FUNCT-1K1 b *XCMPLX-0K3 (b -XCMPLX-0K6 b) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using A4 A11 funct_1_th_49 sorry
        also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 b *XCMPLX-0K3 \<one>\<^sub>M"
          using newton_th_4 newton_th_12 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "g .FUNCT-1K1 b =HIDDENR1 0NUMBERSK6"
           sorry
        obtain y where
          [ty]:"y be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> y =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A13: " for x be RealXREAL-0M1 holds y .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 x"and A14: " for x be RealXREAL-0M1 holds y is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using taylor_1_lm_5 sorry
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 REALNUMBERSK2"
           sorry
        then have A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A12 relat_1_th_27 sorry
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies y is-differentiable-inFDIFF-1R1 x"
          using A14 sorry
        then have "y is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
          using A12 fdiff_1_th_9 sorry
        then have "y  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
          using fdiff_1_th_25 sorry
        then have A16: "y  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) be continuousFCONT-1V1"
          using fcont_1_th_16 sorry
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> y"
          using A12 sorry
        then have A17: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using relat_1_th_27 sorry
        have A18: "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 A4 xboole_1_th_1 sorry
        then have A19: "].RCOMP-1K2 a,b .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A7 xboole_1_th_1 sorry
        have "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A6 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using taylor_1_def_5 sorry
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_9 sorry
        then have A20: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A19 fdiff_1_def_6 sorry
        have A21: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          proof(rule ballI,rule impI,rule conjMI)
            have A22: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using taylor_1_def_5 sorry
            also have "... = f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using taylor_1_def_5 sorry
            also have "... = f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using A20 fdiff_2_th_16 sorry
            finally have "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
               sorry
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A23: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            have A24: "f is-differentiable-inFDIFF-1R1 x"
              using A20 A23 fdiff_1_th_9 sorry
            have A25: "y is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
              using A14 sorry
            thus "y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
              using A24 fdiff_2_th_13 sorry
            have A26: "(b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) =COMPLEX1R1 \<one>\<^sub>M"
              using newton_th_4 newton_th_12 sorry
            have "diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(y,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
              using A25 A24 fdiff_2_th_13 sorry
            also have "... = (diffFDIFF-1K1(y,f .FUNCT-1K1 x))*XCMPLX-0K3 (f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A20 A23 fdiff_1_def_7 sorry
            also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x"
              using A14 A22 sorry
            also have "... = -XCMPLX-0K4 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
              using A26 sorry
            also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
              using xcmplx_1_th_74 sorry
            finally show "diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
           sorry
        then have A27: "y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A19 A17 fdiff_1_th_9 sorry
        have A28: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
          using relat_1_th_61 sorry
        also have "... = [.RCOMP-1K1 a,b .]"
          using A1 A4 A15 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
          using A4 xboole_1_th_28 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
          using A9 relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
           sorry
        have A29: " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) implies (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
        proof(rule ballI,rule impI)
          fix xx assume [ty]: "xx be objectHIDDENM1"
          assume A30: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
          obtain x where 
            [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
            using A30 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
            using relat_1_th_61 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) c=TARSKIR1 [.RCOMP-1K1 a,b .]"
            using xboole_1_th_17 sorry
          then have A31: "x inHIDDENR3 [.RCOMP-1K1 a,b .]"
            using A30 sorry
          have A32: "(b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) =COMPLEX1R1 \<one>\<^sub>M"
            using newton_th_4 newton_th_12 sorry
          have "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 g .FUNCT-1K1 x"
            using A30 funct_1_th_47 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using A4 A10 A31 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using series_1_def_1 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_5 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (f .FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A4 A31 funct_1_th_49 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
            using xcmplx_1_th_74 sorry
          also have "... = y .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A13 A32 sorry
          also have "... = (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
            using A18 A31 funct_1_th_13 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
            using A28 A30 funct_1_th_47 sorry
          finally show "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
             sorry
        qed "sorry"
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A5 taylor_1_def_5 sorry
        then have "((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using fcont_1_th_15 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A4 funct_1_th_51 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using fcont_1_th_15 sorry
        then have "(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A16 fcont_1_th_25 sorry
        thus "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A28 A29 funct_1_th_2 sorry
        have A33: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using relat_1_th_61 sorry
        also have "... = ].RCOMP-1K2 a,b .["
          using A7 A18 A17 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A4 A7 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
          using A9 relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
           sorry
        have " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) implies (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
        proof(rule ballI,rule impI)
          fix xx assume [ty]: "xx be objectHIDDENM1"
          assume A34: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
          obtain x where 
            [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
            using A34 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using relat_1_th_61 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) c=TARSKIR1 ].RCOMP-1K2 a,b .["
            using xboole_1_th_17 sorry
          then have A35: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            using A34 sorry
          have A36: "(b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) =COMPLEX1R1 \<one>\<^sub>M"
            using newton_th_4 newton_th_12 sorry
          have "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 g .FUNCT-1K1 x"
            using A34 funct_1_th_47 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using A10 A8 A35 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using series_1_def_1 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_5 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (f .FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A8 A35 funct_1_th_49 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 ((b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
            using xcmplx_1_th_74 sorry
          also have "... = y .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A13 A36 sorry
          also have "... = (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
            using A19 A35 funct_1_th_13 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
            using A33 A34 funct_1_th_47 sorry
          finally show "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
             sorry
        qed "sorry"
        then have A37: "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A33 funct_1_th_2 sorry
        then have "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A27 fdiff_2_th_16 sorry
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_9 sorry
        thus A38: "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A9 A8 fdiff_1_def_6 sorry
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
        proof(rule ballI,rule impI,rule conjMI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          assume A39: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
          show "g is-differentiable-inFDIFF-1R1 x"
            using A38 A39 fdiff_1_th_9 sorry
          have "diffFDIFF-1K1(g,x) =HIDDENR1 (g `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A38 A39 fdiff_1_def_7 sorry
          also have "... = (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A38 fdiff_2_th_16 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A37 A27 fdiff_2_th_16 sorry
          also have "... = diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
            using A27 A39 fdiff_1_def_7 sorry
          also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A21 A39 sorry
          finally show "diffFDIFF-1K1(g,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
             sorry
        qed "sorry"
        thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A40: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (f is-differentiable-onTAYLOR-1R1(k,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) implies ((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))))) implies (f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)))) &  not (((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))))))"
      proof(rule ballI,rule impI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A41: "?P(k)"
        assume A42: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A43: "a <XXREAL-0R3 b"
          and A44: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
          and A45: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          and A46: "f is-differentiable-onTAYLOR-1R1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
        have "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
          using A42 sorry
        then have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be continuousFCONT-1V1"
          using fdiff_1_th_25 sorry
        then have A47: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A44 fcont_1_th_16 sorry
        have A48: "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
          using xxreal_1_th_25 sorry
        then have A49: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
          using A44 xboole_1_th_1 sorry
        obtain gk where
          [ty]:"gk be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A50: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk =XBOOLE-0R4 Z"and A51: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using taylor_1_lm_7 sorry
        have A52: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
          using A46 taylor_1_th_23 nat_1_th_11 sorry
        then have A53: "gk is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A41 A42 A43 A44 A47 A50 A51 taylor_1_th_23 nat_1_th_11 sorry
        have A54: "gk  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A41 A42 A43 A44 A47 A52 A50 A51 taylor_1_th_23 nat_1_th_11 sorry
        have " for gk1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk1 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) implies gk1 .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & (gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & (gk1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
        proof(rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
          have A55: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
            using A42 sorry
          have "k <=XXREAL-0R1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A56: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A46 sorry
          have A57: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z"
            using taylor_1_def_5 sorry
          fix gk1 assume [ty]: "gk1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          assume A58: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 =XBOOLE-0R4 Z"
            and A59: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk1 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          have A60: "b inHIDDENR3 [.RCOMP-1K1 a,b .]"
            using A43 xxreal_1_th_1 sorry
          then have "gk1 .FUNCT-1K1 b =HIDDENR1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A44 A59 sorry
          also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,b,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            using series_1_def_1 sorry
          also have "... = (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,b,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          also have "... = gk .FUNCT-1K1 b -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,b,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A44 A51 A60 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,b,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A41 A42 A43 A44 A47 A52 A50 A51 taylor_1_th_23 nat_1_th_11 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 b *XCMPLX-0K3 (b -XCMPLX-0K6 b) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 b *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 k *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using newton_th_6 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally have "gk1 .FUNCT-1K1 b =HIDDENR1 0NUMBERSK6"
             sorry
          thus "gk1 .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"
             sorry
          obtain h where
            [ty]:"h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
            A61: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A62: " for x be RealXREAL-0M1 holds h .FUNCT-1K1 x =COMPLEX1R1 (\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"and A63: " for x be RealXREAL-0M1 holds h is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(h,x) =COMPLEX1R1 -XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3)"
            using taylor_1_lm_6 sorry
          have A64: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
            using valued_1_def_4 sorry
          also have "... = Z /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
            using A61 A57 A55 fdiff_1_def_7 sorry
          also have "... = Z"
            using xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z"
             sorry
          have A65: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
            using valued_1_th_12 sorry
          also have "... = Z"
            using A50 A64 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z"
             sorry
          show "gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          proof-
            let ?ghk = "gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies h is-differentiable-inFDIFF-1R1 x"
              using A63 sorry
            then have "h is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
              using A61 fdiff_1_th_9 sorry
            then have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
              using fdiff_1_th_25 sorry
            then have A66: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
              using fcont_1_th_16 sorry
            have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 Z implies gk1 .FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
              assume A67: "x inTARSKIR2 Z"
              have "gk1 .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A59 A67 sorry
              also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
                using series_1_def_1 sorry
              also have "... = (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A51 A67 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
                using taylor_1_def_7 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
                using xcmplx_1_th_74 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A62 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A65 A67 valued_1_th_13 sorry
              finally show "gk1 .FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                 sorry
            qed "sorry"
            then have A68: "gk1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?ghk"
              using A58 A65 partfun1_th_5 sorry
            have "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
              using A44 A57 A55 fdiff_1_def_7 sorry
            then have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (([.RCOMP-1K1 a,b .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) be continuousFCONT-1V1"
              using A45 A61 A66 fcont_1_th_19 sorry
            thus "gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
              using A44 A50 A54 A64 A68 fcont_1_th_19 sorry
          qed
          have A69: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
            using taylor_1_def_5 sorry
          let ?gfh = "gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
          have A70: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
            using valued_1_def_4 sorry
          also have "... = (].RCOMP-1K2 a,b .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
            using A61 A69 A56 fdiff_1_def_7 sorry
          also have "... = ].RCOMP-1K2 a,b .["
            using xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 ].RCOMP-1K2 a,b .["
             sorry
          then have A71: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using A50 valued_1_th_12 sorry
          also have "... = ].RCOMP-1K2 a,b .["
            using A44 A48 xboole_1_th_1 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 ].RCOMP-1K2 a,b .["
             sorry
          have A72: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =COMPLEX1R1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume A73: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
              have "(gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A71 A73 valued_1_th_13 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A42 A43 A44 A48 taylor_1_th_24 xboole_1_th_1 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A73 funct_1_th_49 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A49 A65 A73 valued_1_th_13 sorry
              finally show "(gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A74: " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) implies gk1 .FUNCT-1K1 xx =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
          proof(rule ballI,rule impI)
            fix xx assume [ty]: "xx be objectHIDDENM1"
            assume A75: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?gfh"
            obtain x where 
              [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
              using A75 sorry
            have "gk1 .FUNCT-1K1 xx =HIDDENR1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A49 A59 A71 A75 sorry
            also have "... = f .FUNCT-1K1 b -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
              using series_1_def_1 sorry
            also have "... = (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,b)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A49 A51 A71 A75 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using taylor_1_def_7 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
              using xcmplx_1_th_74 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
              using A62 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
              using valued_1_th_5 sorry
            also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
              using A49 A65 A71 A75 valued_1_th_13 sorry
            also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
              using A71 A72 A75 sorry
            finally show "gk1 .FUNCT-1K1 xx =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
               sorry
          qed "sorry"
          have A76: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A46 sorry
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies h is-differentiable-inFDIFF-1R1 x"
            using A63 sorry
          then have A77: "h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A61 fdiff_1_th_9 sorry
          then have A78: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A70 A76 fdiff_1_th_21 sorry
          then have A79: "?gfh is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A53 A71 fdiff_1_th_19 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?gfh =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using A44 A48 A58 A71 xboole_1_th_1 xboole_1_th_28 sorry
          then have A80: "(gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?gfh  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using A74 funct_1_th_46 sorry
          then have "?gfh  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using funct_1_th_51 sorry
          then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
            using A79 fdiff_1_def_6 sorry
          thus A81: "gk1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A49 A58 fdiff_1_def_6 sorry
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A82: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            have "diffFDIFF-1K1(gk1,x) =HIDDENR1 (gk1 `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A81 A82 fdiff_1_def_7 sorry
            also have "... = (gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A81 fdiff_2_th_16 sorry
            also have "... = ((gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A80 funct_1_th_51 sorry
            also have "... = ((gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A79 fdiff_2_th_16 sorry
            also have "... = diffFDIFF-1K1(gk,x) -XCMPLX-0K6 diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h,x)"
              using A53 A71 A78 A82 fdiff_1_th_19 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h,x)"
              using A41 A42 A43 A44 A47 A52 A50 A51 A82 taylor_1_th_23 nat_1_th_11 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A78 A82 fdiff_1_def_7 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 (h .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)) +XCMPLX-0K2 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x)))"
              using A70 A76 A77 A82 fdiff_1_th_21 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 h .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x))"
               sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x))"
              using A62 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))"
              using A63 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))+XCMPLX-0K2 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3)))-XCMPLX-0K6 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
               sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))+XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
              using xcmplx_1_th_74 sorry
            also have "... = -XCMPLX-0K4 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
               sorry
            also have "... = -XCMPLX-0K4 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A76 A82 fdiff_1_def_7 sorry
            also have "... = -XCMPLX-0K4 ((b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x"
              using taylor_1_def_5 sorry
            also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using xcmplx_1_th_74 sorry
            finally show "diffFDIFF-1K1(gk1,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
               sorry
          qed "sorry"
          thus " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
        qed "sorry"
        thus " for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)))) &  not (((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A2 A40 sorry
    thus " for n be NatNAT-1M1 holds  not (f is-differentiable-onTAYLOR-1R1(n,Z) &  not ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (((( not a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) &  not ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) &  not (((g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))))))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_9:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex tVar9 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar9 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar9 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & tVar9 .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & tVar9  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & tVar9 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(tVar9,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using taylor_1_lm_7 sorry
    show " ex tVar9 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar9 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar9 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & tVar9 .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & tVar9  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & tVar9 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(tVar9,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))"
    proof(rule bexI[of _ "g"])
      show "((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))"
        using A1 A2 A3 taylor_1_lm_8 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_25:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6 implies (((g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & (( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6) implies g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & (g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & (g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "a <XXREAL-0R3 b"
      and A3: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
      and A4: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    fix l assume [ty]: "l be RealXREAL-0M1"
    obtain p where
      [ty]:"p be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A6: " for x be RealXREAL-0M1 holds p .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"and A7: " for x be RealXREAL-0M1 holds p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(p,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      using taylor_1_lm_6 sorry
    obtain h where
      [ty]:"h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 Z"and A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies h .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"and A10: "h .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"and A11: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"and A12: "h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["and A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(h,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      using A1 A2 A3 A4 taylor_1_lm_9 sorry
    have A14: "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p"
      using A3 A8 A5 xboole_1_th_19 sorry
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
      and A16: " for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      and A17: "(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
    let ?hp = "h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"
    have A18: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p"
      using valued_1_th_12 sorry
    also have "... = Z"
      using A8 A5 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =HIDDENR1 Z"
       sorry
    have A19: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp implies ?hp .FUNCT-1K1 x =COMPLEX1R1 g .FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p) implies (h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A20: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp"
        obtain xx where 
          [ty]:"xx be RealXREAL-0M1" and xxDef:"xx = x"
          using A20 sorry
        have "(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 xx -XCMPLX-0K6 p .FUNCT-1K1 xx"
          using A20 valued_1_th_13 sorry
        also have "... = (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,xx,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 p .FUNCT-1K1 xx"
          using A9 A18 A20 sorry
        also have "... = (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,xx,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 xx) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using A6 sorry
        also have "... = g .FUNCT-1K1 x"
          using A16 sorry
        finally show "(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies p is-differentiable-inFDIFF-1R1 x"
      using A7 sorry
    then have "p is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
      using A5 fdiff_1_th_9 sorry
    then have "p  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using fdiff_1_th_25 sorry
    then have A21: "p  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using fcont_1_th_16 sorry
    have "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
      using xxreal_1_th_25 sorry
    then have A22: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
      using A3 xboole_1_th_1 sorry
    have A23: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z"
      using A15 A18 xboole_1_th_28 sorry
    then have A24: "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
      using A19 funct_1_th_46 sorry
    also have "... = g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
      using A22 funct_1_th_51 sorry
    finally have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
       sorry
    have A25: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(?hp,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof(rule ballI,rule impI,rule conjMI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A26: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
        have A27: "h is-differentiable-inFDIFF-1R1 x"
          using A12 A26 fdiff_1_th_9 sorry
        have A28: "p is-differentiable-inFDIFF-1R1 x"
          using A7 sorry
        thus "h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p is-differentiable-inFDIFF-1R1 x"
          using A27 fdiff_1_th_14 sorry
        have "diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 diffFDIFF-1K1(h,x) -XCMPLX-0K6 diffFDIFF-1K1(p,x)"
          using A27 A28 fdiff_1_th_14 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))-XCMPLX-0K6 diffFDIFF-1K1(p,x)"
          using A13 A26 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))-XCMPLX-0K6 (-XCMPLX-0K4 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
          using A7 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
        finally show "diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A29: "?hp is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
      using A18 A22 fdiff_1_th_9 sorry
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
      using fdiff_1_def_6 sorry
    thus A30: "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
      using A15 A24 fdiff_1_def_6 sorry
    obtain aa where 
      [ty]:"aa be RealXREAL-0M1" and aaDef:"aa = a"
       sorry
    have "g .FUNCT-1K1 aa =COMPLEX1R1 0NUMBERSK6"
      using A16 A17 sorry
    thus "g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"
       sorry
    have A31: "b inHIDDENR3 [.RCOMP-1K1 a,b .]"
      using A2 xxreal_1_th_1 sorry
    then have "g .FUNCT-1K1 b =HIDDENR1 ?hp .FUNCT-1K1 b"
      using A3 A18 A19 sorry
    also have "... = h .FUNCT-1K1 b -XCMPLX-0K6 p .FUNCT-1K1 b"
      using A3 A18 A31 valued_1_th_13 sorry
    also have "... = 0NUMBERSK6 -XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using A10 A6 sorry
    also have "... = 0NUMBERSK6 -XCMPLX-0K6 (l *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using newton_th_6 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "g .FUNCT-1K1 b =HIDDENR1 0NUMBERSK6"
       sorry
    thus "g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"
       sorry
    have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
      using A23 A19 funct_1_th_46 sorry
    also have "... = g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
      using A3 funct_1_th_51 sorry
    finally have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) =HIDDENR1 g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
       sorry
    thus "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using A11 A14 A21 fcont_1_th_18 sorry
    show " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A32: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
        have "diffFDIFF-1K1(g,x) =HIDDENR1 (g `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A30 A32 fdiff_1_def_7 sorry
        also have "... = (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A30 fdiff_2_th_16 sorry
        also have "... = ((h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A24 A29 fdiff_2_th_16 sorry
        also have "... = diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x)"
          using A29 A32 fdiff_1_def_7 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
          using A25 A32 sorry
        finally show "diffFDIFF-1K1(g,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_26:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  for l be RealXREAL-0M1 holds  ex g be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for b be RealXREAL-0M1 holds  for l be RealXREAL-0M1 holds  ex tVar10 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar10 .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix l assume [ty]: "l be RealXREAL-0M1"
    let ?U = "\<lambda>Lamb1. InSUBSET-1K10((f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,Lamb1,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 Lamb1) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3),REALNUMBERSK2)"
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A1: " for d be ElementSUBSET-1M1-of REALNUMBERSK2 holds g .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> d =COMPLEX1R1 ?U(d)"
      using funct_2_sch_4 sorry
    show " ex tVar10 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar10 .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
    proof(rule bexI[of _ "g"],rule ballI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have 
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "g .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?U(x)"
        using A1 sorry
      thus "g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_27:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 b =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & (([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) implies  not ( for c be RealXREAL-0M1 holds  not (c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 b =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "a <XXREAL-0R3 b"
      and A3: "([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    have "b -XCMPLX-0K6 a <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A4: "(b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    let ?F = "\<lambda>Lamb1. InSUBSET-1K10(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,Lamb1,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,REALNUMBERSK2)"
    obtain l where 
      [ty]:"l be RealXREAL-0M1" and lDef:"l = ?F(a) /XCMPLX-0K7 ((b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
       sorry
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A5: " for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using taylor_1_th_26 sorry
    have A6: "(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 ?F(a) -XCMPLX-0K6 (?F(a) /XCMPLX-0K7 ((b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))*XCMPLX-0K3 ((b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
      using xcmplx_1_th_74 sorry
    also have "... = ?F(a) -REAL-1K5 ?F(a)"
      using A4 xcmplx_1_th_50 xcmplx_1_th_87 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 0NUMBERSK6"
       sorry
    then have A7: "g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"
      using A5 sorry
    have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have A9: "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using A1 A2 A3 A5 A6 taylor_1_th_25 sorry
    have "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A5 A6 A8 taylor_1_th_25 sorry
    then obtain c where
      [ty]:"c be RealXREAL-0M1" and 
      A10: "c inHIDDENR3 ].RCOMP-1K2 a,b .["and A11: "diffFDIFF-1K1(g,c) =COMPLEX1R1 0NUMBERSK6"
      using A2 A8 A7 A9 rolle_th_1 sorry
    have "c inHIDDENR3 {r where r be RealXREAL-0M1 : a <XXREAL-0R3 r & r <XXREAL-0R3 b }"
      using A10 rcomp_1_def_2 sorry
    then have " ex r be RealXREAL-0M1 st (c =COMPLEX1R1 r & a <XXREAL-0R3 r) & r <XXREAL-0R3 b"
       sorry
    then have "b -XCMPLX-0K6 c <>HIDDENR2 0NUMBERSK6"
       sorry
    then have A12: "(b -XCMPLX-0K6 c) |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have "(-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A5 A6 A10 A11 taylor_1_th_25 sorry
    then have "((((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) -XCMPLX-0K6 ((l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 ((l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_87 sorry
    then have "(((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (b -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 (0NUMBERSK6)/XCMPLX-0K7 (b -XCMPLX-0K6 c) |^NEWTONK1 n"
      using xcmplx_1_th_87 sorry
    then have "(((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (b -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (b -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_120 sorry
    then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c -XCMPLX-0K6 (l *XCMPLX-0K3 (b -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (b -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
      using A12 xcmplx_1_th_89 sorry
    then have "(f .FUNCT-1K1 b -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
      using A6 A12 xcmplx_1_th_89 sorry
    then have "f .FUNCT-1K1 b =COMPLEX1R1 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
       sorry
    thus " not ( for c be RealXREAL-0M1 holds  not (c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 b =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,b)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (b -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_10:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( for n be NatNAT-1M1 holds  not (f is-differentiable-onTAYLOR-1R1(n,Z) &  not ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (((( not a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) &  not ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) &  not (((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))))))))"
  proof(rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    let ?P = "\<lambda>Lamb1. f is-differentiable-onTAYLOR-1R1(Lamb1,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(Lamb1 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1) implies ((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 Lamb1)/XCMPLX-0K7 (Lamb1 !SIN-COSK3))))"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (f is-differentiable-onTAYLOR-1R1(k,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k) implies ((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))))) implies (f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)))) &  not (((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))))))"
      proof(rule ballI,rule impI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        assume A4: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A5: "a <XXREAL-0R3 b"
          and A6: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
          and A7: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          and A8: "f is-differentiable-onTAYLOR-1R1((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
        have "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
          using A4 sorry
        then have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be continuousFCONT-1V1"
          using fdiff_1_th_25 sorry
        then have A9: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A6 fcont_1_th_16 sorry
        have A10: "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
          using xxreal_1_th_25 sorry
        then have A11: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
          using A6 xboole_1_th_1 sorry
        obtain gk where
          [ty]:"gk be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A12: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk =XBOOLE-0R4 Z"and A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k"
          using taylor_1_lm_7 sorry
        have A14: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
          using A8 taylor_1_th_23 nat_1_th_11 sorry
        then have A15: "gk is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A3 A4 A5 A6 A9 A12 A13 taylor_1_th_23 nat_1_th_11 sorry
        have A16: "gk  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A3 A4 A5 A6 A9 A14 A12 A13 taylor_1_th_23 nat_1_th_11 sorry
        have " for gk1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk1 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) implies gk1 .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & (gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & (gk1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
        proof(rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
          have A17: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
            using A4 sorry
          have "k <=XXREAL-0R1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
            using nat_1_th_11 sorry
          then have A18: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A8 sorry
          have A19: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z"
            using taylor_1_def_5 sorry
          fix gk1 assume [ty]: "gk1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
          assume A20: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 =XBOOLE-0R4 Z"
            and A21: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies gk1 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          have A22: "a inHIDDENR3 [.RCOMP-1K1 a,b .]"
            using A5 xxreal_1_th_1 sorry
          then have "gk1 .FUNCT-1K1 a =HIDDENR1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A6 A21 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,a,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
            using series_1_def_1 sorry
          also have "... = (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,a,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
             sorry
          also have "... = gk .FUNCT-1K1 a -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,a,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A6 A13 A22 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,a,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            using A3 A4 A5 A6 A9 A14 A12 A13 taylor_1_th_23 nat_1_th_11 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 a *XCMPLX-0K3 (a -XCMPLX-0K6 a) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = 0NUMBERSK6 -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 a *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 k *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using newton_th_6 sorry
          also have "... = 0NUMBERSK6"
             sorry
          finally have "gk1 .FUNCT-1K1 a =HIDDENR1 0NUMBERSK6"
             sorry
          thus "gk1 .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"
             sorry
          obtain h where
            [ty]:"h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
            A23: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A24: " for x be RealXREAL-0M1 holds h .FUNCT-1K1 x =COMPLEX1R1 (\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"and A25: " for x be RealXREAL-0M1 holds h is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(h,x) =COMPLEX1R1 -XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3)"
            using taylor_1_lm_6 sorry
          have A26: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
            using valued_1_def_4 sorry
          also have "... = Z /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
            using A23 A19 A17 fdiff_1_def_7 sorry
          also have "... = Z"
            using xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z"
             sorry
          have A27: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
            using valued_1_th_12 sorry
          also have "... = Z"
            using A12 A26 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z"
             sorry
          show "gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          proof-
            let ?ghk = "gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies h is-differentiable-inFDIFF-1R1 x"
              using A25 sorry
            then have "h is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
              using A23 fdiff_1_th_9 sorry
            then have "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
              using fdiff_1_th_25 sorry
            then have A28: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
              using fcont_1_th_16 sorry
            have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 Z implies gk1 .FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
              assume A29: "x inTARSKIR2 Z"
              have "gk1 .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A21 A29 sorry
              also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
                using series_1_def_1 sorry
              also have "... = (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                using A13 A29 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
                using taylor_1_def_7 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
                using xcmplx_1_th_74 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A24 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A27 A29 valued_1_th_13 sorry
              finally show "gk1 .FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                 sorry
            qed "sorry"
            then have A30: "gk1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?ghk"
              using A20 A27 partfun1_th_5 sorry
            have "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
              using A6 A19 A17 fdiff_1_def_7 sorry
            then have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (([.RCOMP-1K1 a,b .])/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) be continuousFCONT-1V1"
              using A7 A23 A28 fcont_1_th_19 sorry
            thus "gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
              using A6 A12 A16 A26 A30 fcont_1_th_19 sorry
          qed
          have A31: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
            using taylor_1_def_5 sorry
          let ?gfh = "gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h"
          have A32: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h"
            using valued_1_def_4 sorry
          also have "... = (].RCOMP-1K2 a,b .[)/\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> REALNUMBERSK2"
            using A23 A31 A18 fdiff_1_def_7 sorry
          also have "... = ].RCOMP-1K2 a,b .["
            using xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 ].RCOMP-1K2 a,b .["
             sorry
          have A33: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)"
            using A12 valued_1_th_12 sorry
          also have "... = ].RCOMP-1K2 a,b .["
            using A6 A10 A32 xboole_1_th_1 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) =HIDDENR1 ].RCOMP-1K2 a,b .["
             sorry
          have A34: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =COMPLEX1R1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
          proof-
            have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be RealXREAL-0M1"
              assume A35: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
              have "(gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A33 A35 valued_1_th_13 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A4 A5 A6 A10 taylor_1_th_24 xboole_1_th_1 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
                using A35 funct_1_th_49 sorry
              also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using valued_1_th_5 sorry
              also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                using A11 A27 A35 valued_1_th_13 sorry
              finally show "(gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A36: " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) implies gk1 .FUNCT-1K1 xx =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
          proof(rule ballI,rule impI)
            fix xx assume [ty]: "xx be objectHIDDENM1"
            assume A37: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?gfh"
            obtain x where 
              [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
              using A37 sorry
            have "gk1 .FUNCT-1K1 xx =HIDDENR1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A11 A21 A33 A37 sorry
            also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
              using series_1_def_1 sorry
            also have "... = (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k)-XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              using A11 A13 A33 A37 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using taylor_1_def_7 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
              using xcmplx_1_th_74 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 h .FUNCT-1K1 x"
              using A24 sorry
            also have "... = gk .FUNCT-1K1 x -XCMPLX-0K6 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
              using valued_1_th_5 sorry
            also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 x"
              using A11 A27 A33 A37 valued_1_th_13 sorry
            also have "... = (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
              using A33 A34 A37 sorry
            finally show "gk1 .FUNCT-1K1 xx =HIDDENR1 (gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h).FUNCT-1K1 xx"
               sorry
          qed "sorry"
          have A38: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A8 sorry
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies h is-differentiable-inFDIFF-1R1 x"
            using A25 sorry
          then have A39: "h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A23 fdiff_1_th_9 sorry
          then have A40: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A32 A38 fdiff_1_th_21 sorry
          then have A41: "?gfh is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A15 A33 fdiff_1_th_19 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?gfh =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> gk1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using A6 A10 A20 A33 xboole_1_th_1 xboole_1_th_28 sorry
          then have A42: "(gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?gfh  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using A36 funct_1_th_46 sorry
          then have "?gfh  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using funct_1_th_51 sorry
          then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
            using A41 fdiff_1_def_6 sorry
          thus A43: "gk1 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
            using A11 A20 fdiff_1_def_6 sorry
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A44: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            have "diffFDIFF-1K1(gk1,x) =HIDDENR1 (gk1 `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A43 A44 fdiff_1_def_7 sorry
            also have "... = (gk1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A43 fdiff_2_th_16 sorry
            also have "... = ((gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A42 funct_1_th_51 sorry
            also have "... = ((gk -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A41 fdiff_2_th_16 sorry
            also have "... = diffFDIFF-1K1(gk,x) -XCMPLX-0K6 diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h,x)"
              using A15 A33 A40 A44 fdiff_1_th_19 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h,x)"
              using A3 A4 A5 A6 A9 A14 A12 A13 A44 taylor_1_th_23 nat_1_th_11 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> h)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A40 A44 fdiff_1_def_7 sorry
            also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 (h .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)) +XCMPLX-0K2 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x)))"
              using A32 A38 A39 A44 fdiff_1_th_21 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 h .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x))"
               sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(h,x))"
              using A24 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x)))-XCMPLX-0K6 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 (\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))"
              using A25 sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))+XCMPLX-0K2 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((\<one>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3)))-XCMPLX-0K6 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
               sorry
            also have "... = ((-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))+XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 k)/XCMPLX-0K7 (k !SIN-COSK3))-XCMPLX-0K6 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
              using xcmplx_1_th_74 sorry
            also have "... = -XCMPLX-0K4 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 (diffFDIFF-1K1((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M),x))"
               sorry
            also have "... = -XCMPLX-0K4 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A38 A44 fdiff_1_def_7 sorry
            also have "... = -XCMPLX-0K4 ((a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x"
              using taylor_1_def_5 sorry
            also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using xcmplx_1_th_74 sorry
            finally show "diffFDIFF-1K1(gk1,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
               sorry
          qed "sorry"
          thus " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(gk1,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
             sorry
        qed "sorry"
        thus " for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)))) &  not (((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A45: "?P(0NUMBERSK6)"
    proof-
      have "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)) implies g .FUNCT-1K1 a =HIDDENR1 0NUMBERSK6 & (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & (g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)))))))"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI)
        assume "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z)"
        fix a assume [ty]: "a be RealXREAL-0M1"
        fix b assume [ty]: "b be RealXREAL-0M1"
        assume A46: "a <XXREAL-0R3 b"
          and A47: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
          and A48: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          and A49: "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
        have A50: "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
          using xxreal_1_th_25 sorry
        then have A51: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
          using A47 xboole_1_th_1 sorry
        fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A52: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z"
          and A53: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
        have A54: "a inHIDDENR3 [.RCOMP-1K1 a,b .]"
          using A46 xxreal_1_th_1 sorry
        then have "g .FUNCT-1K1 a =HIDDENR1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,a,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using A47 A53 sorry
        also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,a,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 a *XCMPLX-0K3 (a -XCMPLX-0K6 a) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using taylor_1_def_7 sorry
        also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 a *XCMPLX-0K3 (a -XCMPLX-0K6 a) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using taylor_1_def_5 sorry
        also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (f .FUNCT-1K1 a *XCMPLX-0K3 (a -XCMPLX-0K6 a) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          using A47 A54 funct_1_th_49 sorry
        also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 a *XCMPLX-0K3 \<one>\<^sub>M"
          using newton_th_4 newton_th_12 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally show "g .FUNCT-1K1 a =HIDDENR1 0NUMBERSK6"
           sorry
        obtain y where
          [ty]:"y be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A55: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> y =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A56: " for x be RealXREAL-0M1 holds y .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 x"and A57: " for x be RealXREAL-0M1 holds y is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y,x) =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
          using taylor_1_lm_5 sorry
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 REALNUMBERSK2"
           sorry
        then have A58: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A55 relat_1_th_27 sorry
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies y is-differentiable-inFDIFF-1R1 x"
          using A57 sorry
        then have "y is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
          using A55 fdiff_1_th_9 sorry
        then have "y  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
          using fdiff_1_th_25 sorry
        then have A59: "y  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) be continuousFCONT-1V1"
          using fcont_1_th_16 sorry
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> y"
          using A55 sorry
        then have A60: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using relat_1_th_27 sorry
        have A61: "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A1 A47 xboole_1_th_1 sorry
        then have A62: "].RCOMP-1K2 a,b .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using A50 xboole_1_th_1 sorry
        have "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A49 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using taylor_1_def_5 sorry
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_9 sorry
        then have A63: "f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A62 fdiff_1_def_6 sorry
        have A64: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
          proof(rule ballI,rule impI,rule conjMI)
            have A65: "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using taylor_1_def_5 sorry
            also have "... = f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using taylor_1_def_5 sorry
            also have "... = f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
              using A63 fdiff_2_th_16 sorry
            finally have "(diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)"
               sorry
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A66: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            have A67: "f is-differentiable-inFDIFF-1R1 x"
              using A63 A66 fdiff_1_th_9 sorry
            have A68: "y is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
              using A57 sorry
            thus "y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
              using A67 fdiff_2_th_13 sorry
            have A69: "(a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) =COMPLEX1R1 \<one>\<^sub>M"
              using newton_th_4 newton_th_12 sorry
            have "diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(y,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
              using A68 A67 fdiff_2_th_13 sorry
            also have "... = (diffFDIFF-1K1(y,f .FUNCT-1K1 x))*XCMPLX-0K3 (f `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
              using A63 A66 fdiff_1_def_7 sorry
            also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x"
              using A57 A65 sorry
            also have "... = -XCMPLX-0K4 ((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
              using A69 sorry
            also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
              using xcmplx_1_th_74 sorry
            finally show "diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
           sorry
        then have A70: "y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A62 A60 fdiff_1_th_9 sorry
        have A71: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
          using relat_1_th_61 sorry
        also have "... = [.RCOMP-1K1 a,b .]"
          using A1 A47 A58 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
          using A47 xboole_1_th_28 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
          using A52 relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
           sorry
        have A72: " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) implies (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
        proof(rule ballI,rule impI)
          fix xx assume [ty]: "xx be objectHIDDENM1"
          assume A73: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]))"
          obtain x where 
            [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
            using A73 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
            using relat_1_th_61 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) c=TARSKIR1 [.RCOMP-1K1 a,b .]"
            using xboole_1_th_17 sorry
          then have A74: "x inHIDDENR3 [.RCOMP-1K1 a,b .]"
            using A73 sorry
          have "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 g .FUNCT-1K1 x"
            using A73 funct_1_th_47 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using A47 A53 A74 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using series_1_def_1 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_5 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (f .FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A47 A74 funct_1_th_49 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M"
            using newton_th_4 newton_th_12 sorry
          also have "... = y .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A56 sorry
          also have "... = (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
            using A61 A74 funct_1_th_13 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
            using A71 A73 funct_1_th_47 sorry
          finally show "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])).FUNCT-1K1 xx"
             sorry
        qed "sorry"
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A48 taylor_1_def_5 sorry
        then have "((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using fcont_1_th_15 sorry
        then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A47 funct_1_th_51 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using fcont_1_th_15 sorry
        then have "(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A59 fcont_1_th_25 sorry
        thus "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
          using A71 A72 funct_1_th_2 sorry
        have A75: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using relat_1_th_61 sorry
        also have "... = ].RCOMP-1K2 a,b .["
          using A50 A61 A60 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A47 A50 xboole_1_th_1 xboole_1_th_28 sorry
        also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
          using A52 relat_1_th_61 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
           sorry
        have " for xx be objectHIDDENM1 holds xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) implies (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
        proof(rule ballI,rule impI)
          fix xx assume [ty]: "xx be objectHIDDENM1"
          assume A76: "xx inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[))"
          obtain x where 
            [ty]:"x be RealXREAL-0M1" and xDef:"x = xx"
            using A76 sorry
          have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
            using relat_1_th_61 sorry
          then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)) c=TARSKIR1 ].RCOMP-1K2 a,b .["
            using xboole_1_th_17 sorry
          then have A77: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
            using A76 sorry
          have A78: "(a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3) =COMPLEX1R1 \<one>\<^sub>M"
            using newton_th_4 newton_th_12 sorry
          have "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 g .FUNCT-1K1 x"
            using A76 funct_1_th_47 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using A53 A51 A77 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (TaylorTAYLOR-1K6(f,Z,x,a)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
            using series_1_def_1 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_7 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using taylor_1_def_5 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 (f .FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A51 A77 funct_1_th_49 sorry
          also have "... = f .FUNCT-1K1 a -XCMPLX-0K6 f .FUNCT-1K1 x *XCMPLX-0K3 ((a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6) /XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
            using xcmplx_1_th_74 sorry
          also have "... = y .FUNCT-1K1 (f .FUNCT-1K1 x)"
            using A56 A78 sorry
          also have "... = (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x"
            using A62 A77 funct_1_th_13 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
            using A75 A76 funct_1_th_47 sorry
          finally show "(g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx =HIDDENR1 ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)).FUNCT-1K1 xx"
             sorry
        qed "sorry"
        then have A79: "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
          using A75 funct_1_th_2 sorry
        then have "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A70 fdiff_2_th_16 sorry
        then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
          using fdiff_1_th_9 sorry
        thus A80: "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
          using A52 A51 fdiff_1_def_6 sorry
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies g is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(g,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
        proof(rule ballI,rule impI,rule conjMI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          assume A81: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
          show "g is-differentiable-inFDIFF-1R1 x"
            using A80 A81 fdiff_1_th_9 sorry
          have "diffFDIFF-1K1(g,x) =HIDDENR1 (g `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A80 A81 fdiff_1_def_7 sorry
          also have "... = (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A80 fdiff_2_th_16 sorry
          also have "... = ((y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
            using A79 A70 fdiff_2_th_16 sorry
          also have "... = diffFDIFF-1K1(y *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)"
            using A70 A81 fdiff_1_def_7 sorry
          also have "... = -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
            using A64 A81 sorry
          finally show "diffFDIFF-1K1(g,x) =HIDDENR1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
             sorry
        qed "sorry"
        thus " for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A45 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (f is-differentiable-onTAYLOR-1R1(n,Z) &  not ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  not (((( not a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) &  not ( for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) &  not (((g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))))))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma taylor_1_lm_11:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)) & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex tVar11 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar11 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar11 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & tVar11 .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & tVar11  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & tVar11 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(tVar11,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    obtain g where
      [ty]:"g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
      using taylor_1_lm_7 sorry
    show " ex tVar11 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st ((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> tVar11 =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not tVar11 .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & tVar11 .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & tVar11  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & tVar11 is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(tVar11,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))"
    proof(rule bexI[of _ "g"])
      show "((((domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not g .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n))) & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[) & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 ].RCOMP-1K2 a,b .[ &  not diffFDIFF-1K1(g,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))"
        using A1 A2 A3 taylor_1_lm_10 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_28:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & ( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) & (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6 implies (((g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6) & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6) & g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & ([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[))) implies ( for l be RealXREAL-0M1 holds  for g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2 & (( for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)) & (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6) implies g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & (g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6 & (g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6 & (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)))))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "a <XXREAL-0R3 b"
      and A3: "[.RCOMP-1K1 a,b .] c=TARSKIR1 Z"
      and A4: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1 & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    fix l assume [ty]: "l be RealXREAL-0M1"
    obtain p where
      [ty]:"p be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"and A6: " for x be RealXREAL-0M1 holds p .FUNCT-1K1 x =COMPLEX1R1 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"and A7: " for x be RealXREAL-0M1 holds p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(p,x) =COMPLEX1R1 -XCMPLX-0K4 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      using taylor_1_lm_6 sorry
    obtain h where
      [ty]:"h be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h =XBOOLE-0R4 Z"and A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies h .FUNCT-1K1 x =COMPLEX1R1 f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"and A10: "h .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"and A11: "h  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"and A12: "h is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["and A13: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(h,x) =COMPLEX1R1 -XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      using A1 A2 A3 A4 taylor_1_lm_11 sorry
    have A14: "[.RCOMP-1K1 a,b .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p"
      using A3 A8 A5 xboole_1_th_19 sorry
    fix g assume [ty]: "g be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A15: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 [#]SUBSET-1K2 REALNUMBERSK2"
      and A16: " for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      and A17: "(f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
    let ?hp = "h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p"
    have A18: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> h /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> p"
      using valued_1_th_12 sorry
    also have "... = Z"
      using A8 A5 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =HIDDENR1 Z"
       sorry
    have A19: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp implies ?hp .FUNCT-1K1 x =COMPLEX1R1 g .FUNCT-1K1 x"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p) implies (h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A20: "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp"
        obtain xx where 
          [ty]:"xx be RealXREAL-0M1" and xxDef:"xx = x"
          using A20 sorry
        have "(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 h .FUNCT-1K1 xx -XCMPLX-0K6 p .FUNCT-1K1 xx"
          using A20 valued_1_th_13 sorry
        also have "... = (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,xx,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 p .FUNCT-1K1 xx"
          using A9 A18 A20 sorry
        also have "... = (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,xx,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 xx) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
          using A6 sorry
        also have "... = g .FUNCT-1K1 x"
          using A16 sorry
        finally show "(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 REALNUMBERSK2 implies p is-differentiable-inFDIFF-1R1 x"
      using A7 sorry
    then have "p is-differentiable-onFDIFF-1R2 REALNUMBERSK2"
      using A5 fdiff_1_th_9 sorry
    then have "p  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using fdiff_1_th_25 sorry
    then have A21: "p  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using fcont_1_th_16 sorry
    have "].RCOMP-1K2 a,b .[ c=TARSKIR1 [.RCOMP-1K1 a,b .]"
      using xxreal_1_th_25 sorry
    then have A22: "].RCOMP-1K2 a,b .[ c=TARSKIR1 Z"
      using A3 xboole_1_th_1 sorry
    have A23: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?hp =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z"
      using A15 A18 xboole_1_th_28 sorry
    then have A24: "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
      using A19 funct_1_th_46 sorry
    also have "... = g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
      using A22 funct_1_th_51 sorry
    finally have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) =HIDDENR1 g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[)"
       sorry
    have A25: " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(?hp,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof(rule ballI,rule impI,rule conjMI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A26: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
        have A27: "h is-differentiable-inFDIFF-1R1 x"
          using A12 A26 fdiff_1_th_9 sorry
        have A28: "p is-differentiable-inFDIFF-1R1 x"
          using A7 sorry
        thus "h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p is-differentiable-inFDIFF-1R1 x"
          using A27 fdiff_1_th_14 sorry
        have "diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 diffFDIFF-1K1(h,x) -XCMPLX-0K6 diffFDIFF-1K1(p,x)"
          using A27 A28 fdiff_1_th_14 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))-XCMPLX-0K6 diffFDIFF-1K1(p,x)"
          using A13 A26 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))-XCMPLX-0K6 (-XCMPLX-0K4 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))"
          using A7 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
        finally show "diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A29: "?hp is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
      using A18 A22 fdiff_1_th_9 sorry
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies ?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) is-differentiable-inFDIFF-1R1 x"
      using fdiff_1_def_6 sorry
    thus A30: "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .["
      using A15 A24 fdiff_1_def_6 sorry
    show "g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"
      using A16 A17 sorry
    have A31: "a inHIDDENR3 [.RCOMP-1K1 a,b .]"
      using A2 xxreal_1_th_1 sorry
    then have "g .FUNCT-1K1 a =HIDDENR1 ?hp .FUNCT-1K1 a"
      using A3 A18 A19 sorry
    also have "... = h .FUNCT-1K1 a -XCMPLX-0K6 p .FUNCT-1K1 a"
      using A3 A18 A31 valued_1_th_13 sorry
    also have "... = 0NUMBERSK6 -XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using A10 A6 sorry
    also have "... = 0NUMBERSK6 -XCMPLX-0K6 (l *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using newton_th_6 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "g .FUNCT-1K1 a =HIDDENR1 0NUMBERSK6"
       sorry
    thus "g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"
       sorry
    have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) =HIDDENR1 (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
      using A23 A19 funct_1_th_46 sorry
    also have "... = g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
      using A3 funct_1_th_51 sorry
    finally have "?hp  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) =HIDDENR1 g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .])"
       sorry
    thus "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using A11 A14 A21 fcont_1_th_18 sorry
    show " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =COMPLEX1R1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies diffFDIFF-1K1(g,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A32: "x inHIDDENR3 ].RCOMP-1K2 a,b .["
        have "diffFDIFF-1K1(g,x) =HIDDENR1 (g `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A30 A32 fdiff_1_def_7 sorry
        also have "... = (g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 a,b .[) `|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A30 fdiff_2_th_16 sorry
        also have "... = ((h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p)`|FDIFF-1K2 (].RCOMP-1K2 a,b .[)).FUNCT-1K1 x"
          using A24 A29 fdiff_2_th_16 sorry
        also have "... = diffFDIFF-1K1(h -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> p,x)"
          using A29 A32 fdiff_1_def_7 sorry
        also have "... = (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
          using A25 A32 sorry
        finally show "diffFDIFF-1K1(g,x) =HIDDENR1 (-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_29:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds ((a <XXREAL-0R3 b & [.RCOMP-1K1 a,b .] c=TARSKIR1 Z) & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[) implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 a =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z) implies ( for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <XXREAL-0R3 b & (([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)) implies  not ( for c be RealXREAL-0M1 holds  not (c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 a =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-differentiable-onTAYLOR-1R1(n,Z)"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A2: "a <XXREAL-0R3 b"
      and A3: "([.RCOMP-1K1 a,b .] c=TARSKIR1 Z & ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 a,b .[)"
    obtain aa bb where 
      [ty]:"aa be RealXREAL-0M1" and aaDef:"aa = a" and
      [ty]:"bb be RealXREAL-0M1" and bbDef:"bb = b"
       sorry
    have "a -XCMPLX-0K6 b <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    then have A4: "(a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    let ?F = "\<lambda>Lamb1. InSUBSET-1K10(f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,Lamb1,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n,REALNUMBERSK2)"
    obtain l where 
      [ty]:"l be RealXREAL-0M1" and lDef:"l = ?F(bb) /XCMPLX-0K7 ((a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
       sorry
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
      A5: " for x be RealXREAL-0M1 holds g .FUNCT-1K1 x =COMPLEX1R1 (f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
      using taylor_1_th_26 sorry
    have A6: "(f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 ?F(bb) -XCMPLX-0K6 (?F(bb) /XCMPLX-0K7 ((a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))*XCMPLX-0K3 ((a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
      using xcmplx_1_th_74 sorry
    also have "... = ?F(bb) -REAL-1K5 ?F(bb)"
      using A4 xcmplx_1_th_50 xcmplx_1_th_87 sorry
    also have "... = 0NUMBERSK6"
       sorry
    finally have "(f .FUNCT-1K1 a -XCMPLX-0K6 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)-XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 0NUMBERSK6"
       sorry
    then have A7: "g .FUNCT-1K1 b =COMPLEX1R1 0NUMBERSK6"
      using A5 sorry
    have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have A9: "g  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 a,b .]) be continuousFCONT-1V1"
      using A1 A2 A3 A5 A6 taylor_1_th_28 sorry
    have "g is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 a,b .[ & g .FUNCT-1K1 a =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A5 A6 A8 taylor_1_th_28 sorry
    then obtain c where
      [ty]:"c be RealXREAL-0M1" and 
      A10: "c inHIDDENR3 ].RCOMP-1K2 a,b .["and A11: "diffFDIFF-1K1(g,c) =COMPLEX1R1 0NUMBERSK6"
      using A2 A8 A7 A9 rolle_th_1 sorry
    have "c inHIDDENR3 {r where r be RealXREAL-0M1 : a <XXREAL-0R3 r & r <XXREAL-0R3 b }"
      using A10 rcomp_1_def_2 sorry
    then have " ex r be RealXREAL-0M1 st (c =COMPLEX1R1 r & a <XXREAL-0R3 r) & r <XXREAL-0R3 b"
       sorry
    then have "a -XCMPLX-0K6 c <>HIDDENR2 0NUMBERSK6"
       sorry
    then have A12: "(a -XCMPLX-0K6 c) |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
      using card_4_th_3 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> g =XBOOLE-0R4 REALNUMBERSK2"
      using funct_2_def_1 sorry
    then have "(-XCMPLX-0K4 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))+XCMPLX-0K2 (l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
      using A1 A2 A3 A5 A6 A10 A11 taylor_1_th_28 sorry
    then have "((((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) -XCMPLX-0K6 ((l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
       sorry
    then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 ((l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (n !SIN-COSK3))*XCMPLX-0K3 (n !SIN-COSK3) =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_87 sorry
    then have "(((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (a -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 (0NUMBERSK6)/XCMPLX-0K7 (a -XCMPLX-0K6 c) |^NEWTONK1 n"
      using xcmplx_1_th_87 sorry
    then have "(((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (a -XCMPLX-0K6 c) |^NEWTONK1 n -XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (a -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
      using xcmplx_1_th_120 sorry
    then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c -XCMPLX-0K6 (l *XCMPLX-0K3 (a -XCMPLX-0K6 c) |^NEWTONK1 n)/XCMPLX-0K7 (a -XCMPLX-0K6 c) |^NEWTONK1 n =COMPLEX1R1 0NUMBERSK6"
      using A12 xcmplx_1_th_89 sorry
    then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c =COMPLEX1R1 l"
      using A12 xcmplx_1_th_89 sorry
    then have "f .FUNCT-1K1 a =COMPLEX1R1 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) +XCMPLX-0K2 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
      using A6 sorry
    thus " not ( for c be RealXREAL-0M1 holds  not (c inHIDDENR3 ].RCOMP-1K2 a,b .[ & f .FUNCT-1K1 a =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,b,a)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 a,b .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (a -XCMPLX-0K6 b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
      using A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_30:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z1 c=TARSKIR1 Z implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z1 c=TARSKIR1 Z implies ( for k be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(k,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix Z1 assume [ty]: "Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z1 c=TARSKIR1 Z"
    let ?P = "\<lambda>Lamb1. f is-differentiable-onTAYLOR-1R1(Lamb1,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Lamb1"
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds (f is-differentiable-onTAYLOR-1R1(k,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) implies (f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A3: "?P(k)"
        assume A4: "f is-differentiable-onTAYLOR-1R1(k +NAT-1K1 \<one>\<^sub>M,Z)"
        have A5: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
          using A4 sorry
        then have A6: "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z1"
          using A1 fdiff_1_th_26 sorry
        then have A7: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1) =XBOOLE-0R4 Z1"
          using fdiff_1_def_7 sorry
        have A8: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z1"
          using relat_1_th_61 sorry
        also have "... = Z /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Z1"
          using A5 fdiff_1_def_7 sorry
        also have "... = Z1"
          using A1 xboole_1_th_28 sorry
        finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1) =HIDDENR1 Z1"
           sorry
        have A9: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1) implies (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1).FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          assume A10: "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1)"
          have "(((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z).FUNCT-1K1 x"
            using A8 A10 funct_1_th_49 sorry
          also have "... = diffFDIFF-1K1((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k,x)"
            using A1 A5 A8 A10 fdiff_1_def_7 sorry
          also have "... = ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1).FUNCT-1K1 x"
            using A6 A8 A10 fdiff_1_def_7 sorry
          finally show "(((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1).FUNCT-1K1 x =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1).FUNCT-1K1 x"
             sorry
        qed "sorry"
        have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1"
          using taylor_1_def_5 sorry
        also have "... = (diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1"
          using A8 A7 A9 partfun1_th_5 sorry
        also have "... = (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k `|FDIFF-1K2 Z1"
          using A3 A4 A6 taylor_1_th_23 fdiff_2_th_16 nat_1_th_11 sorry
        also have "... = (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
          using taylor_1_def_5 sorry
        finally show "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A11: "?P(0NUMBERSK6)"
    proof-
      have "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      proof(rule impI)
        assume "f is-differentiable-onTAYLOR-1R1(0NUMBERSK6,Z)"
        have "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1"
          using taylor_1_def_5 sorry
        also have "... = f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1"
          using A1 funct_1_th_51 sorry
        also have "... = (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
          using taylor_1_def_5 sorry
        finally show "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =HIDDENR1 (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    show " for k be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(k,Z) implies ((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k"
      using nat_1_sch_2 A11 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem taylor_1_th_31:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z1 c=TARSKIR1 Z implies ( for n be NatNAT-1M1 holds f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z) implies f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z1))"
proof(rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix Z1 assume [ty]: "Z1 be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
  assume A1: "Z1 c=TARSKIR1 Z"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A2: "f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z)"
  have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M implies (diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z1"
  proof(rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A3: "k <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
    have "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 sorry
    then have "(diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z1"
      using A1 fdiff_1_th_26 sorry
    then have A4: "((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 is-differentiable-onFDIFF-1R2 Z1"
      using fdiff_2_th_16 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have "k <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A3 xxreal_0_th_2 sorry
    thus "(diffTAYLOR-1K5(f,Z1)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> k is-differentiable-onFDIFF-1R2 Z1"
      using A1 A2 A4 taylor_1_th_23 taylor_1_th_30 sorry
  qed "sorry"
  thus "f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,Z1)"
     sorry
qed "sorry"

mtheorem taylor_1_th_32:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Z be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ( for n be NatNAT-1M1 holds f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  fix Z assume [ty]: "Z be SubsetSUBSET-1M2-of REALNUMBERSK2"
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume A1: "x inHIDDENR3 Z"
  let ?P = "\<lambda>Lamb1. f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1"
  have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for k be NatNAT-1M1 holds f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k implies Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "?P(k)"
      have "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> k +REAL-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      also have "... = f .FUNCT-1K1 x +XCMPLX-0K2 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 (x -XCMPLX-0K6 x) |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using A3 taylor_1_def_7 sorry
      also have "... = f .FUNCT-1K1 x +XCMPLX-0K2 (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 x *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 k *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
        using newton_th_6 sorry
      also have "... = f .FUNCT-1K1 x"
         sorry
      finally show "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 (TaylorTAYLOR-1K6(f,Z,x,x)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
    using series_1_def_1 sorry
  also have "... = (((diffTAYLOR-1K5(f,Z)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (0NUMBERSK6)).FUNCT-1K1 x *XCMPLX-0K3 (x -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
    using taylor_1_def_7 sorry
  also have "... = ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 (x -XCMPLX-0K6 x) |^NEWTONK1 (0NUMBERSK6))/XCMPLX-0K7 ((0NUMBERSK6)!SIN-COSK3)"
    using taylor_1_def_5 sorry
  also have "... = ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z).FUNCT-1K1 x *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 \<one>\<^sub>M"
    using newton_th_4 newton_th_12 sorry
  also have "... = f .FUNCT-1K1 x"
    using A1 funct_1_th_49 sorry
  finally have "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 f .FUNCT-1K1 x"
     sorry
  then have A4: "?P(0NUMBERSK6)"
     sorry
  have " for k be NatNAT-1M1 holds ?P(k)"
    using nat_1_sch_2 A4 A2 sorry
  thus " for n be NatNAT-1M1 holds f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,Z,x,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
     sorry
qed "sorry"

(*\$N Taylor's Theorem*)
mtheorem taylor_1_th_33:
" for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & 0NUMBERSK6 <XXREAL-0R3 r) & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[) implies ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies ( ex s be RealXREAL-0M1 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
proof-
  have " for n be NatNAT-1M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (0NUMBERSK6 <XXREAL-0R3 r & f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)) implies ( for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ implies  not ( for s be RealXREAL-0M1 holds  not (( not 0NUMBERSK6 <XXREAL-0R3 s &  not s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    assume A1: "].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[ c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "0NUMBERSK6 <XXREAL-0R3 r"
      and A3: "f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A4: "x inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
    have "(x <XXREAL-0R3 x0 & ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) or x =COMPLEX1R1 x0 & (x =COMPLEX1R1 x0 implies ( ex s be setHIDDENM2 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x))) or x >XXREAL-0R4 x0 & (x >XXREAL-0R4 x0 implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
    proof-
      show "(x <XXREAL-0R3 x0 & ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))) or x =COMPLEX1R1 x0 & (x =COMPLEX1R1 x0 implies ( ex s be setHIDDENM2 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x))) or x >XXREAL-0R4 x0 & (x >XXREAL-0R4 x0 implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))))"
      proof-
        have cases: "(x <XXREAL-0R3 x0 or x =COMPLEX1R1 x0) or x >XXREAL-0R4 x0"
          using xxreal_0_th_1 sorry
        have case1: "x <XXREAL-0R3 x0 implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
        proof(rule impI)
          assume A5: "x <XXREAL-0R3 x0"
          have " |.COMPLEX1K10 x0 -XCMPLX-0K6 x0 .| =COMPLEX1R1 0NUMBERSK6"
            using absvalue_th_2 sorry
          then have "x0 inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A2 rcomp_1_th_1 sorry
          then have A6: "[.RCOMP-1K1 x,x0 .] c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A4 xxreal_2_def_12 sorry
          have "(diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A3 sorry
          then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[) be continuousFCONT-1V1"
            using fdiff_1_th_25 sorry
          then have A7: "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x,x0 .]) be continuousFCONT-1V1"
            using A6 fcont_1_th_16 sorry
          have A8: "f is-differentiable-onTAYLOR-1R1(n,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)"
            using A3 taylor_1_th_23 nat_1_th_11 sorry
          let ?t = "x0 -XCMPLX-0K6 x"
          have A9: "?t >XXREAL-0R4 0NUMBERSK6"
            using A5 xreal_1_th_50 sorry
          have A10: "].RCOMP-1K2 x,x0 .[ c=TARSKIR1 [.RCOMP-1K1 x,x0 .]"
            using xxreal_1_th_25 sorry
          then have "f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x,x0 .[)"
            using A3 A6 taylor_1_th_31 xboole_1_th_1 sorry
          then obtain c where
            [ty]:"c be RealXREAL-0M1" and 
            A11: "c inHIDDENR3 ].RCOMP-1K2 x,x0 .["and A12: "f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x,x0 .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using A1 A5 A6 A8 A7 taylor_1_th_29 sorry
          obtain s where 
            [ty]:"s be setHIDDENM2" and sDef:"s = (x0 -XCMPLX-0K6 c)/XCMPLX-0K7 ?t"
             sorry
          show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
            have A13: "x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) =HIDDENR1 x0 -XCMPLX-0K6 ((x0 -XCMPLX-0K6 c)/XCMPLX-0K7 ?t)*XCMPLX-0K3 ?t"
               sorry
            also have "... = x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 c)"
              using A9 xcmplx_1_th_87 sorry
            also have "... = c"
               sorry
            finally have "x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) =HIDDENR1 c"
               sorry
            have "c inHIDDENR3 {p where p be RealXREAL-0M1 : x0 -XCMPLX-0K6 ?t <XXREAL-0R3 p & p <XXREAL-0R3 x0 }"
              using A11 rcomp_1_def_2 sorry
            then have A14: " ex g be RealXREAL-0M1 st (g =COMPLEX1R1 c & x0 -XCMPLX-0K6 ?t <XXREAL-0R3 g) & g <XXREAL-0R3 x0"
               sorry
            then have "0NUMBERSK6 <XXREAL-0R3 x0 -XCMPLX-0K6 c"
              using xreal_1_th_50 sorry
            then have "(0NUMBERSK6)/XCMPLX-0K7 ?t <XXREAL-0R3 (x0 -XCMPLX-0K6 c)/XCMPLX-0K7 ?t"
              using A9 xreal_1_th_74 sorry
            thus "0NUMBERSK6 <XXREAL-0R3 s"
               sorry
            have "(x0 -XCMPLX-0K6 ?t)+XCMPLX-0K2 ?t <XXREAL-0R3 c +XCMPLX-0K2 ?t"
              using A14 xreal_1_th_8 sorry
            then have "x0 -XCMPLX-0K6 c <XXREAL-0R3 ?t"
              using xreal_1_th_19 sorry
            then have "(x0 -XCMPLX-0K6 c)/XCMPLX-0K7 ?t <XXREAL-0R3 ?t /XCMPLX-0K7 ?t"
              using A9 xreal_1_th_74 sorry
            thus "s <XXREAL-0R3 \<one>\<^sub>M"
              using A9 xcmplx_1_th_60 sorry
            have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x,x0 .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c =HIDDENR1 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x,x0 .[)).FUNCT-1K1 c"
              using A3 A6 A10 taylor_1_th_30 xboole_1_th_1 sorry
            also have "... = ((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c"
              using A11 funct_1_th_49 sorry
            finally have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x,x0 .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c =HIDDENR1 ((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c"
               sorry
            thus "f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using A12 A13 sorry
          qed "sorry"
        qed
        have case2: "x =COMPLEX1R1 x0 implies ( ex s be setHIDDENM2 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x)"
        proof(rule impI)
          assume A15: "x =COMPLEX1R1 x0"
          let ?s = "\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
          show " ex s be setHIDDENM2 st (0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M) & Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x"
          proof(rule bexI[of _ "s"],rule conjMI)
            show "0NUMBERSK6 <XXREAL-0R3 s & s <XXREAL-0R3 \<one>\<^sub>M"
               sorry
            let ?c = "x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)"
            have "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using A4 A15 taylor_1_th_32 sorry
            also have "... = f .FUNCT-1K1 x +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 ((0NUMBERSK6) |^NEWTONK1 n *XCMPLX-0K3 (0NUMBERSK6)))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using newton_th_6 sorry
            also have "... = f .FUNCT-1K1 x"
               sorry
            finally show "Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3) =HIDDENR1 f .FUNCT-1K1 x"
               sorry
          qed "sorry"
        qed
        have case3: "x >XXREAL-0R4 x0 implies ( ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
        proof(rule impI)
          assume A16: "x >XXREAL-0R4 x0"
          let ?t = "x -XCMPLX-0K6 x0"
          have A17: "f is-differentiable-onTAYLOR-1R1(n,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)"
            using A3 taylor_1_th_23 nat_1_th_11 sorry
          have " |.COMPLEX1K10 x0 -XCMPLX-0K6 x0 .| =COMPLEX1R1 0NUMBERSK6"
            using absvalue_th_2 sorry
          then have "x0 inHIDDENR3 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A2 rcomp_1_th_1 sorry
          then have A18: "[.RCOMP-1K1 x0,x .] c=TARSKIR1 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A4 xxreal_2_def_12 sorry
          have "(diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n is-differentiable-onFDIFF-1R2 ].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .["
            using A3 sorry
          then have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[) be continuousFCONT-1V1"
            using fdiff_1_th_25 sorry
          then have A19: "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> n) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 x0,x .]) be continuousFCONT-1V1"
            using A18 fcont_1_th_16 sorry
          have A20: "].RCOMP-1K2 x0,x .[ c=TARSKIR1 [.RCOMP-1K1 x0,x .]"
            using xxreal_1_th_25 sorry
          then have "f is-differentiable-onTAYLOR-1R1(n +NAT-1K1 \<one>\<^sub>M,].RCOMP-1K2 x0,x .[)"
            using A3 A18 taylor_1_th_31 xboole_1_th_1 sorry
          then obtain c where
            [ty]:"c be RealXREAL-0M1" and 
            A21: "c inHIDDENR3 ].RCOMP-1K2 x0,x .["and A22: "f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0,x .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
            using A1 A16 A18 A17 A19 taylor_1_th_27 sorry
          obtain s where 
            [ty]:"s be setHIDDENM2" and sDef:"s = (c -XCMPLX-0K6 x0)/XCMPLX-0K7 ?t"
             sorry
          show " ex s be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 s & (s <XXREAL-0R3 \<one>\<^sub>M & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3))"
          proof(rule bexI[of _ "s"],rule conjMI,rule conjMI)
            have A23: "?t >XXREAL-0R4 0NUMBERSK6"
              using A16 xreal_1_th_50 sorry
            then have A24: "x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) =HIDDENR1 x0 +XCMPLX-0K2 (c -XCMPLX-0K6 x0)"
              using xcmplx_1_th_87 sorry
            also have "... = c"
               sorry
            finally have "x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0) =HIDDENR1 c"
               sorry
            have "c inHIDDENR3 {p where p be RealXREAL-0M1 : x0 <XXREAL-0R3 p & p <XXREAL-0R3 x0 +XCMPLX-0K2 ?t }"
              using A21 rcomp_1_def_2 sorry
            then have A25: " ex g be RealXREAL-0M1 st (g =COMPLEX1R1 c & x0 <XXREAL-0R3 g) & g <XXREAL-0R3 x0 +XCMPLX-0K2 ?t"
               sorry
            then have "0NUMBERSK6 <XXREAL-0R3 c -XCMPLX-0K6 x0"
              using xreal_1_th_50 sorry
            then have "(0NUMBERSK6)/XCMPLX-0K7 ?t <XXREAL-0R3 (c -XCMPLX-0K6 x0)/XCMPLX-0K7 ?t"
              using A23 xreal_1_th_74 sorry
            thus "0NUMBERSK6 <XXREAL-0R3 s"
               sorry
            have "c -XCMPLX-0K6 x0 <XXREAL-0R3 ?t"
              using A25 xreal_1_th_19 sorry
            then have "(c -XCMPLX-0K6 x0)/XCMPLX-0K7 ?t <XXREAL-0R3 ?t /XCMPLX-0K7 ?t"
              using A23 xreal_1_th_74 sorry
            thus "s <XXREAL-0R3 \<one>\<^sub>M"
              using A23 xcmplx_1_th_60 sorry
            have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0,x .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c =HIDDENR1 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (].RCOMP-1K2 x0,x .[)).FUNCT-1K1 c"
              using A3 A18 A20 taylor_1_th_30 xboole_1_th_1 sorry
            also have "... = ((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c"
              using A21 funct_1_th_49 sorry
            finally have "((diffTAYLOR-1K5(f,].RCOMP-1K2 x0,x .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c =HIDDENR1 ((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 c"
               sorry
            thus "f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)"
              using A22 A24 sorry
          qed "sorry"
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus " not ( for s be RealXREAL-0M1 holds  not (( not 0NUMBERSK6 <XXREAL-0R3 s &  not s <XXREAL-0R3 \<one>\<^sub>M) & f .FUNCT-1K1 x =COMPLEX1R1 Partial-SumsSERIES-1K3 (TaylorTAYLOR-1K6(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[,x0,x)) .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (((diffTAYLOR-1K5(f,].RCOMP-1K2 x0 -XCMPLX-0K6 r,x0 +XCMPLX-0K2 r .[)).SEQFUNCK1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 (x0 +XCMPLX-0K2 s *XCMPLX-0K3 (x -XCMPLX-0K6 x0)) *XCMPLX-0K3 (x -XCMPLX-0K6 x0) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!SIN-COSK3)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
