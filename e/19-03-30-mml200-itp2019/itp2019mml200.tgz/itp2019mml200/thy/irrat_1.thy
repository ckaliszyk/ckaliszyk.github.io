theory irrat_1
  imports sin_cos rat_1 pepin finseq_5 limfunc1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k, m, n, p, K, N for "NatNAT-1M1"
reserve i for "IntegerINT-1M1"
reserve x, y, eps for "RealXREAL-0M1"
reserve seq, seq1, seq2 for "Real-SequenceSEQ-1M1"
reserve sq for "FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
syntax IRRAT_1V1 :: "Ty" ("irrationalIRRAT-1V1" 70)
translations "irrationalIRRAT-1V1" \<rightharpoonup> " non rationalRAT-1V1"

abbreviation(input) IRRAT_1K1(" _ ^IRRAT-1K1  _ " [164,164]164) where
  "x ^IRRAT-1K1 y \<equiv> x to-powerPOWERK2 y"

(*\$N The Irrationality of the Square Root of 2*)
mtheorem irrat_1_th_1:
" for p be NatNAT-1M1 holds p be primeINT-2V1 implies sqrtSQUARE-1K3 p be irrationalIRRAT-1V1"
proof-
  have " for p be NatNAT-1M1 holds p be primeINT-2V1 implies (sqrtSQUARE-1K3 p be rationalRAT-1V1 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
    then have A2: "p >XXREAL-0R4 \<one>\<^sub>M"
      using int_2_def_4 sorry
    assume "sqrtSQUARE-1K3 p be rationalRAT-1V1"
    then obtain i n where
      [ty]:"i be IntegerINT-1M1" "n be NatNAT-1M1" and 
      A3: "n <>HIDDENR2 0NUMBERSK6"and A4: "sqrtSQUARE-1K3 p =COMPLEX1R1 i /XCMPLX-0K7 n"and A5: " for i1 be IntegerINT-1M1 holds  for n1 be NatNAT-1M1 holds n1 <>HIDDENR2 0NUMBERSK6 & sqrtSQUARE-1K3 p =COMPLEX1R1 i1 /XCMPLX-0K7 n1 implies n <=XXREAL-0R1 n1"
      using rat_1_th_9 sorry
    have A6: "i =COMPLEX1R1 sqrtSQUARE-1K3 p *XCMPLX-0K3 n"
      using A3 A4 xcmplx_1_th_87 sorry
    have "sqrtSQUARE-1K3 p >=XXREAL-0R2 0NUMBERSK6"
      using square_1_def_2 sorry
    then obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = i"
      using A6 int_1_th_3 sorry
    have A7: "m ^2PEPINK1 =HIDDENR1 (sqrtSQUARE-1K3 p)^2SQUARE-1K1 *XCMPLX-0K3 n ^2PEPINK1"
      using A6 sorry
    also have "... = p *XCMPLX-0K3 n ^2PEPINK1"
      using square_1_def_2 sorry
    finally have "m ^2PEPINK1 =HIDDENR1 p *XCMPLX-0K3 n ^2PEPINK1"
       sorry
    then have "p dividesINT-1R1 m ^2PEPINK1"
      using nat_d_def_3 sorry
    then have "p dividesINT-1R1 m"
      using A1 newton_th_80 sorry
    then obtain m1 where
      [ty]:"m1 be NatNAT-1M1" and 
      A8: "m =COMPLEX1R1 p *XCMPLX-0K3 m1"
      using nat_d_def_3 sorry
    have "n ^2PEPINK1 =HIDDENR1 (p *XCMPLX-0K3 (p *XCMPLX-0K3 m1 ^2PEPINK1))/XCMPLX-0K7 p"
      using A2 A7 A8 xcmplx_1_th_89 sorry
    also have "... = p *XCMPLX-0K3 m1 ^2PEPINK1"
      using A2 xcmplx_1_th_89 sorry
    finally have "n ^2PEPINK1 =HIDDENR1 p *XCMPLX-0K3 m1 ^2PEPINK1"
       sorry
    then have "p dividesINT-1R1 n ^2PEPINK1"
      using nat_d_def_3 sorry
    then have "p dividesINT-1R1 n"
      using A1 newton_th_80 sorry
    then obtain n1 where
      [ty]:"n1 be NatNAT-1M1" and 
      A9: "n =COMPLEX1R1 p *XCMPLX-0K3 n1"
      using nat_d_def_3 sorry
    have 
      [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have A10: "m1 /XCMPLX-0K7 n1 =COMPLEX1R1 sqrtSQUARE-1K3 p"
      using A2 A4 A8 A9 xcmplx_1_th_91 sorry
    have A11: "n1 <>HIDDENR2 0NUMBERSK6"
      using A3 A9 sorry
    then have "p *XCMPLX-0K3 n1 >XXREAL-0R4 \<one>\<^sub>M *NAT-1K2 n1"
      using A2 xreal_1_th_98 sorry
    thus " False "
      using A5 A9 A11 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_2:
" ex x be RealXREAL-0M1 st  ex y be RealXREAL-0M1 st (x be irrationalIRRAT-1V1 & y be irrationalIRRAT-1V1) & x ^IRRAT-1K1 y be rationalRAT-1V1"
proof-
  have " ex tVar1 be RealXREAL-0M1 st  ex tVar2 be RealXREAL-0M1 st ( not tVar2 be irrationalIRRAT-1V1 &  not tVar2 be irrationalIRRAT-1V1) & tVar2 ^IRRAT-1K1 tVar2 be rationalRAT-1V1"
  proof-
    let ?w = "sqrtSQUARE-1K3 \<two>\<^sub>M"
    have A1: "(?w ^IRRAT-1K1 ?w)^IRRAT-1K1 ?w =HIDDENR1 ?w ^IRRAT-1K1 ?w ^2SQUARE-1K1"
      using power_th_33 square_1_th_19 sorry
    also have "... = ?w ^IRRAT-1K1 \<two>\<^sub>M"
      using square_1_def_2 sorry
    also have "... = ?w ^2SQUARE-1K1"
      using power_th_46 sorry
    also have "... = \<two>\<^sub>M"
      using square_1_def_2 sorry
    finally have "(?w ^IRRAT-1K1 ?w)^IRRAT-1K1 ?w =HIDDENR1 \<two>\<^sub>M"
       sorry
    obtain dwa where 
      [ty]:"dwa be RealXREAL-0M1" and dwaDef:"dwa = \<two>\<^sub>M"
       sorry
    show " ex tVar1 be RealXREAL-0M1 st  ex tVar2 be RealXREAL-0M1 st ( not tVar2 be irrationalIRRAT-1V1 &  not tVar2 be irrationalIRRAT-1V1) & tVar2 ^IRRAT-1K1 tVar2 be rationalRAT-1V1"
    proof-
      have cases: "?w ^IRRAT-1K1 ?w be rationalRAT-1V1 or ?w ^IRRAT-1K1 ?w be irrationalIRRAT-1V1"
         sorry
      have case1: "sqrtSQUARE-1K3 \<two>\<^sub>M ^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M be rationalRAT-1V1 implies ( ex tVar1 be RealXREAL-0M1 st  ex tVar2 be RealXREAL-0M1 st ( not tVar2 be irrationalIRRAT-1V1 &  not tVar2 be irrationalIRRAT-1V1) & tVar2 ^IRRAT-1K1 tVar2 be rationalRAT-1V1)"
      proof(rule impI)
        assume A2: "?w ^IRRAT-1K1 ?w be rationalRAT-1V1"
        show " ex tVar1 be RealXREAL-0M1 st  ex tVar2 be RealXREAL-0M1 st ( not tVar2 be irrationalIRRAT-1V1 &  not tVar2 be irrationalIRRAT-1V1) & tVar2 ^IRRAT-1K1 tVar2 be rationalRAT-1V1"
        proof(rule bexI[of _ "?w"])
          show " ex tVar2 be RealXREAL-0M1 st ( not tVar2 be irrationalIRRAT-1V1 &  not tVar2 be irrationalIRRAT-1V1) & tVar2 ^IRRAT-1K1 tVar2 be rationalRAT-1V1"
          proof(rule bexI[of _ "?w"])
            show "( not sqrtSQUARE-1K3 \<two>\<^sub>M be irrationalIRRAT-1V1 &  not sqrtSQUARE-1K3 \<two>\<^sub>M be irrationalIRRAT-1V1) & sqrtSQUARE-1K3 \<two>\<^sub>M ^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M be rationalRAT-1V1"
              using A2 irrat_1_th_1 int_2_th_28 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: "sqrtSQUARE-1K3 \<two>\<^sub>M ^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M be irrationalIRRAT-1V1 implies ( ex tVar3 be RealXREAL-0M1 st  ex tVar4 be RealXREAL-0M1 st ( not tVar4 ^IRRAT-1K1 tVar4 be irrationalIRRAT-1V1 &  not tVar4 be irrationalIRRAT-1V1) & (tVar4 ^IRRAT-1K1 tVar4)^IRRAT-1K1 tVar4 be rationalRAT-1V1)"
      proof(rule impI)
        assume A3: "?w ^IRRAT-1K1 ?w be irrationalIRRAT-1V1"
        show " ex tVar3 be RealXREAL-0M1 st  ex tVar4 be RealXREAL-0M1 st ( not tVar4 ^IRRAT-1K1 tVar4 be irrationalIRRAT-1V1 &  not tVar4 be irrationalIRRAT-1V1) & (tVar4 ^IRRAT-1K1 tVar4)^IRRAT-1K1 tVar4 be rationalRAT-1V1"
        proof(rule bexI[of _ "?w ^IRRAT-1K1 ?w"])
          show " ex tVar4 be RealXREAL-0M1 st ( not tVar4 ^IRRAT-1K1 tVar4 be irrationalIRRAT-1V1 &  not tVar4 be irrationalIRRAT-1V1) & (tVar4 ^IRRAT-1K1 tVar4)^IRRAT-1K1 tVar4 be rationalRAT-1V1"
          proof(rule bexI[of _ "?w"])
            show "( not sqrtSQUARE-1K3 \<two>\<^sub>M ^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M be irrationalIRRAT-1V1 &  not sqrtSQUARE-1K3 \<two>\<^sub>M be irrationalIRRAT-1V1) & (sqrtSQUARE-1K3 \<two>\<^sub>M ^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M)^IRRAT-1K1 sqrtSQUARE-1K3 \<two>\<^sub>M be rationalRAT-1V1"
              using A1 A3 irrat_1_th_1 int_2_th_28 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
  thus " ?thesis "
     sorry
qed

(*begin*)
theorem irrat_1_sch_1:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be RealXREAL-0M1"
  shows "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) implies seq1 =FUNCT-1R1 seq2)"
  proof-
    have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) implies (( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)) implies seq1 =FUNCT-1R1 seq2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      show " ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)"
        using seq_1_sch_1 sorry
      fix seq1 assume [ty]: "seq1 be Real-SequenceSEQ-1M1"
      fix seq2 assume [ty]: "seq2 be Real-SequenceSEQ-1M1"
      assume A1: " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)"
      assume A2: " for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 Ff1(n)"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .FUNCT-1K1 n =HIDDENR1 seq2 .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "seq1 .FUNCT-1K1 n =HIDDENR1 Ff1(n)"
          using A1 sorry
        also have "... = seq2 .FUNCT-1K1 n"
          using A2 sorry
        finally show "seq1 .FUNCT-1K1 n =HIDDENR1 seq2 .FUNCT-1K1 n"
           sorry
      qed "sorry"
      thus "seq1 =FUNCT-1R1 seq2"
        using funct_2_th_63 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

mdef irrat_1_def_1 ("aseqIRRAT-1K2  _ " [350]350 ) where
  mlet "k be NatNAT-1M1"
"func aseqIRRAT-1K2 k \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (Lamb1 -XCMPLX-0K6 k)/XCMPLX-0K7 Lamb1"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (Lamb1 -XCMPLX-0K6 k)/XCMPLX-0K7 Lamb1"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef irrat_1_def_2 ("bseqIRRAT-1K3  _ " [350]350 ) where
  mlet "k be NatNAT-1M1"
"func bseqIRRAT-1K3 k \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (Lamb1 chooseNEWTONK4 k)*XCMPLX-0K3 (Lamb1 ^IRRAT-1K1 (-XCMPLX-0K4 k))"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (Lamb1 chooseNEWTONK4 k)*XCMPLX-0K3 (Lamb1 ^IRRAT-1K1 (-XCMPLX-0K4 k))"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef irrat_1_def_3 ("cseqIRRAT-1K4  _ " [350]350 ) where
  mlet "n be NatNAT-1M1"
"func cseqIRRAT-1K4 n \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (n chooseNEWTONK4 Lamb1)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 Lamb1))"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds it1 .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) & ( for k be NatNAT-1M1 holds it2 .FUNCT-1K1 k =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (n chooseNEWTONK4 Lamb1)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 Lamb1))"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 n)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 n))) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem irrat_1_th_3:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 bseqIRRAT-1K3 k .FUNCT-1K1 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 bseqIRRAT-1K3 k .FUNCT-1K1 n"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
      using irrat_1_def_3 sorry
    also have "... = bseqIRRAT-1K3 k .FUNCT-1K1 n"
      using irrat_1_def_2 sorry
    finally show "cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 bseqIRRAT-1K3 k .FUNCT-1K1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef irrat_1_def_4 ("dseqIRRAT-1K5" 350 ) where
"func dseqIRRAT-1K5 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 Lamb1)^IRRAT-1K1 Lamb1"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 Lamb1)^IRRAT-1K1 Lamb1"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef irrat_1_def_5 ("eseqIRRAT-1K6" 350 ) where
"func eseqIRRAT-1K6 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for k be NatNAT-1M1 holds it .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 !NEWTONK7)"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for k be NatNAT-1M1 holds it1 .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & ( for k be NatNAT-1M1 holds it2 .FUNCT-1K1 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) implies it1 =HIDDENR1 it2"
    proof-
      have "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) implies seq1 =FUNCT-1R1 seq2)"
      proof-
        let ?F = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 !NEWTONK7)"
        show "( ex seq be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for seq1 be Real-SequenceSEQ-1M1 holds  for seq2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) & ( for n be NatNAT-1M1 holds seq2 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n !NEWTONK7)) implies seq1 =FUNCT-1R1 seq2)"
          using irrat_1_sch_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem irrat_1_th_4:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    have "n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 n ^IRRAT-1K1 ((-XCMPLX-0K4 k)-XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    also have "... = (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 (n ^IRRAT-1K1 \<one>\<^sub>M)"
      using A1 power_th_29 sorry
    also have "... = (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n"
       sorry
    finally show "n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_5:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    show "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
    proof-
      have cases: "(k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n or k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k <=XXREAL-0R1 n) or k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k >XXREAL-0R4 n"
         sorry
      have case1: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n implies n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
      proof(rule impI)
        assume A1: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
        then obtain l where 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n -XCMPLX-0K6 (k +NAT-1K1 \<one>\<^sub>M)"
          using int_1_th_5 sorry
        have "l +NAT-1K1 \<one>\<^sub>M =COMPLEX1R1 n -XCMPLX-0K6 k"
           sorry
        then obtain l1 where 
          [ty]:"l1 be ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = n -XCMPLX-0K6 k"
           sorry
        have "k <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A2: "k <=XXREAL-0R1 n"
          using A1 xxreal_0_th_2 sorry
        have "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 (((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)*NAT-1K2 (l !NEWTONK7))"
          using A1 newton_def_3 sorry
        also have "... = (n !NEWTONK7)/XCMPLX-0K7 (((k !NEWTONK7)*NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))*NAT-1K2 (l !NEWTONK7))"
          using newton_th_15 sorry
        also have "... = (n !NEWTONK7)/XCMPLX-0K7 (((k !NEWTONK7)*NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((l !NEWTONK7)*NAT-1K2 (l +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (l +NAT-1K1 \<one>\<^sub>M)))"
          using xcmplx_1_th_89 sorry
        also have "... = (n !NEWTONK7)/XCMPLX-0K7 (((k !NEWTONK7)*NAT-1K2 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (((l +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)/XCMPLX-0K7 (l +NAT-1K1 \<one>\<^sub>M)))"
          using newton_th_15 sorry
        also have "... = (l1 /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((n !NEWTONK7)/XCMPLX-0K7 ((k !NEWTONK7)*NAT-1K2 (l1 !NEWTONK7)))"
          using xcmplx_1_th_233 sorry
        also have "... = ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
          using A2 newton_def_3 sorry
        finally show "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
           sorry
      qed
      have case2: "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k <=XXREAL-0R1 n implies n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
      proof(rule impI)
        assume A3: "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k <=XXREAL-0R1 n"
        then have "k >=XXREAL-0R2 n"
          using nat_1_th_13 sorry
        then have "k =COMPLEX1R1 n"
          using A3 xxreal_0_th_1 sorry
        thus "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
          using A3 newton_def_3 sorry
      qed
      have case3: "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k >XXREAL-0R4 n implies n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
      proof(rule impI)
        assume A4: "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n & k >XXREAL-0R4 n"
        then have "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (0NUMBERSK6)"
          using newton_def_3 sorry
        also have "... = ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
          using A4 newton_def_3 sorry
        finally show "n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_6:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =COMPLEX1R1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    have "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 (n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)))"
      using irrat_1_def_2 sorry
    also have "... = (((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k))*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)))"
      using irrat_1_th_5 sorry
    also have "... = (((n -XCMPLX-0K6 k)/XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n chooseNEWTONK4 k))*XCMPLX-0K3 ((n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n)"
      using A1 irrat_1_th_4 sorry
    also have "... = (((n -XCMPLX-0K6 k)*XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (n chooseNEWTONK4 k))*XCMPLX-0K3 ((n ^IRRAT-1K1 (-XCMPLX-0K4 k))/XCMPLX-0K7 n)"
       sorry
    also have "... = (((n -XCMPLX-0K6 k)*XCMPLX-0K3 (k +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (n chooseNEWTONK4 k))*XCMPLX-0K3 ((n ^IRRAT-1K1 (-XCMPLX-0K4 k))*XCMPLX-0K3 n \<inverse>XCMPLX-0K5)"
       sorry
    also have "... = ((k +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))))*XCMPLX-0K3 ((n -XCMPLX-0K6 k)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5)"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))))*XCMPLX-0K3 ((n -XCMPLX-0K6 k)*XCMPLX-0K3 n \<inverse>XCMPLX-0K5)"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))))*XCMPLX-0K3 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 n)"
       sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 ((n -XCMPLX-0K6 k)/XCMPLX-0K7 n)"
      using irrat_1_def_2 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
      using irrat_1_def_1 sorry
    finally show "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_7:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies aseqIRRAT-1K2 k .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies aseqIRRAT-1K2 k .FUNCT-1K1 n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    have "aseqIRRAT-1K2 k .FUNCT-1K1 n =HIDDENR1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
      using irrat_1_def_1 sorry
    also have "... = n /XCMPLX-0K7 n -XCMPLX-0K6 k /XCMPLX-0K7 n"
       sorry
    also have "... = \<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n"
      using A1 xcmplx_1_th_60 sorry
    finally show "aseqIRRAT-1K2 k .FUNCT-1K1 n =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_8:
" for k be NatNAT-1M1 holds aseqIRRAT-1K2 k be convergentSEQ-2V5 & limSEQ-2K1 aseqIRRAT-1K2 k =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for k be NatNAT-1M1 holds aseqIRRAT-1K2 k be convergentSEQ-2V5 & limSEQ-2K1 aseqIRRAT-1K2 k =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix k assume [ty]: "k be NatNAT-1M1"
    have A1: " for eps be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 eps implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds N <=XXREAL-0R1 n implies  |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 eps)"
    proof-
      have " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar5 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar5 implies  not  |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 eps)"
      proof(rule ballI,rule impI)
        fix eps assume [ty]: "eps be RealXREAL-0M1"
        assume A2: "eps >XXREAL-0R4 0NUMBERSK6"
        obtain N where
          [ty]:"N be NatNAT-1M1" and 
          A3: "N >XXREAL-0R4 k /XCMPLX-0K7 eps"
          using seq_4_th_3 sorry
        show " ex tVar5 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar5 implies  not  |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 eps"
        proof(rule bexI[of _ "N"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A4: "n >=XXREAL-0R2 N"
          then have "n >XXREAL-0R4 k /XCMPLX-0K7 eps"
            using A3 xxreal_0_th_2 sorry
          then have "(k /XCMPLX-0K7 eps)*XCMPLX-0K3 eps <XXREAL-0R3 n *XCMPLX-0K3 eps"
            using A2 xreal_1_th_68 sorry
          then have A5: "k <XXREAL-0R3 n *XCMPLX-0K3 eps"
            using A2 xcmplx_1_th_87 sorry
          have A6: "n >XXREAL-0R4 0NUMBERSK6"
            using A2 A3 A4 sorry
          then have " |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 (\<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n)-XCMPLX-0K6 \<one>\<^sub>M .|"
            using irrat_1_th_7 sorry
          also have "... =  |.COMPLEX1K10 -XCMPLX-0K4 k /XCMPLX-0K7 n .|"
             sorry
          also have "... =  |.COMPLEX1K10 k /XCMPLX-0K7 n .|"
            using complex1_th_52 sorry
          also have "... = k /XCMPLX-0K7 n"
            using absvalue_def_1 sorry
          finally have " |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1 k /XCMPLX-0K7 n"
             sorry
          thus " not  |.COMPLEX1K10 aseqIRRAT-1K2 k .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 eps"
            using A6 A5 xreal_1_th_83 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show "aseqIRRAT-1K2 k be convergentSEQ-2V5"
      using A1 sorry
    thus "limSEQ-2K1 aseqIRRAT-1K2 k =COMPLEX1R1 \<one>\<^sub>M"
      using A1 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_9:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
proof-
  have " for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 x"
    have "x inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A2: "seq be constantVALUED-0V15"
      using A1 valued_0_def_18 sorry
    thus "seq be convergentSEQ-2V5"
       sorry
    have "limSEQ-2K1 seq =HIDDENR1 seq .FUNCT-1K1 (0NUMBERSK6)"
      using A2 seq_4_th_26 sorry
    also have "... = x"
      using A1 sorry
    finally show "limSEQ-2K1 seq =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_10:
" for n be NatNAT-1M1 holds bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 (n chooseNEWTONK4 (0NUMBERSK6))*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 0NUMBERSK6))"
      using irrat_1_def_2 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 0NUMBERSK6))"
      using newton_th_19 sorry
    also have "... = \<one>\<^sub>M"
      using power_th_24 sorry
    finally show "bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_11:
" for k be NatNAT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
proof-
  have " for k be NatNAT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
  proof(rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    have "(\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (k !NEWTONK7))"
      using xcmplx_1_th_102 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      using newton_th_15 sorry
    finally show "(\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_12:
" for k be NatNAT-1M1 holds (bseqIRRAT-1K3 k be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
proof-
  have " for k be NatNAT-1M1 holds (bseqIRRAT-1K3 k be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
  proof(rule ballI,rule conjMI)
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. bseqIRRAT-1K3 Lamb1 be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 Lamb1 =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 !NEWTONK7)"
    have A1: " for k be NatNAT-1M1 holds bseqIRRAT-1K3 k be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7) implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A2: "?P(k)"
      show "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      proof(rule conjMI)
        let ?F = "\<lambda>Lamb1. (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 Lamb1"
        obtain seq where
          [ty]:"seq be Real-SequenceSEQ-1M1" and 
          A3: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
          using seq_1_sch_1 sorry
        let ?G = "\<lambda>Lamb1. seq .FUNCT-1K1 Lamb1 *XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 Lamb1"
        obtain seq1 where
          [ty]:"seq1 be Real-SequenceSEQ-1M1" and 
          A4: " for n be NatNAT-1M1 holds seq1 .FUNCT-1K1 n =COMPLEX1R1 ?G(n)"
          using seq_1_sch_1 sorry
        have A5: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =COMPLEX1R1 seq1 .FUNCT-1K1 n"
        proof-
          have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 seq1 .FUNCT-1K1 n"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n >=XXREAL-0R2 \<one>\<^sub>M"
            then have "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
              using irrat_1_th_6 sorry
            also have "... = seq .FUNCT-1K1 n *XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
              using A3 sorry
            also have "... = seq1 .FUNCT-1K1 n"
              using A4 sorry
            finally show "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 seq1 .FUNCT-1K1 n"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A6: "seq =FUNCT-1R1 (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> bseqIRRAT-1K3 k"
          using A3 seq_1_th_9 sorry
        then have A7: "seq be convergentSEQ-2V5"
          using A2 sorry
        have A8: "limSEQ-2K1 seq =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7))"
          using A2 A6 seq_2_th_8 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          using irrat_1_th_11 sorry
        finally have "limSEQ-2K1 seq =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
        have A9: "aseqIRRAT-1K2 k be convergentSEQ-2V5"
          using irrat_1_th_8 sorry
        have A10: "seq1 =FUNCT-1R1 seq (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> aseqIRRAT-1K2 k"
          using A4 seq_1_th_8 sorry
        then have A11: "seq1 be convergentSEQ-2V5"
          using A7 A9 sorry
        thus "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) be convergentSEQ-2V5"
          using A5 seq_4_th_18 sorry
        have "limSEQ-2K1 seq1 =HIDDENR1 (limSEQ-2K1 seq)*XCMPLX-0K3 (limSEQ-2K1 aseqIRRAT-1K2 k)"
          using A7 A10 A9 seq_2_th_15 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          using A8 irrat_1_th_8 sorry
        finally have "limSEQ-2K1 seq1 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
           sorry
        thus "limSEQ-2K1 bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          using A11 A5 seq_4_th_19 sorry
      qed
    qed "sorry"
    have A12: "?P(0NUMBERSK6)"
    proof-
      have "bseqIRRAT-1K3 (0NUMBERSK6) be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((0NUMBERSK6)!NEWTONK7)"
      proof(rule conjMI)
        obtain jj where 
          [ty]:"jj be ElementSUBSET-1M1-of REALNUMBERSK2" and jjDef:"jj = \<one>\<^sub>M"
          using xreal_0_def_1 sorry
        let ?bseq0 = "seq-constSEQ-1K1 \<one>\<^sub>M"
        have A13: " for n be NatNAT-1M1 holds ?bseq0 .FUNCT-1K1 n =COMPLEX1R1 \<one>\<^sub>M"
          using seq_1_th_57 sorry
        have A14: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =COMPLEX1R1 ?bseq0 .FUNCT-1K1 n"
        proof-
          have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 (seq-constSEQ-1K1 \<one>\<^sub>M).FUNCT-1K1 n"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            assume "n >=XXREAL-0R2 \<one>\<^sub>M"
            have "bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 \<one>\<^sub>M"
              using irrat_1_th_10 sorry
            also have "... = (seq-constSEQ-1K1 \<one>\<^sub>M).FUNCT-1K1 n"
              using seq_1_th_57 sorry
            finally show "bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n =HIDDENR1 (seq-constSEQ-1K1 \<one>\<^sub>M).FUNCT-1K1 n"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "bseqIRRAT-1K3 (0NUMBERSK6) be convergentSEQ-2V5"
          using seq_4_th_18 sorry
        have "limSEQ-2K1 ?bseq0 =COMPLEX1R1 \<one>\<^sub>M"
          using A13 irrat_1_th_9 sorry
        thus "limSEQ-2K1 bseqIRRAT-1K3 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((0NUMBERSK6)!NEWTONK7)"
          using A14 newton_th_12 seq_4_th_19 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A12 A1 sorry
    thus "bseqIRRAT-1K3 k be convergentSEQ-2V5 & limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
       sorry
    thus "limSEQ-2K1 bseqIRRAT-1K3 k =COMPLEX1R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
      using irrat_1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_13:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <XXREAL-0R3 n implies 0NUMBERSK6 <XXREAL-0R3 aseqIRRAT-1K2 k .FUNCT-1K1 n & aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <XXREAL-0R3 n implies aseqIRRAT-1K2 k .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "aseqIRRAT-1K2 k .FUNCT-1K1 n =COMPLEX1R1 (n -XCMPLX-0K6 k)/XCMPLX-0K7 n"
      using irrat_1_def_1 sorry
    assume A2: "k <XXREAL-0R3 n"
    then have "n -XCMPLX-0K6 k >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_50 sorry
    thus "aseqIRRAT-1K2 k .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6"
      using A2 A1 xreal_1_th_139 sorry
    have "\<one>\<^sub>M -XCMPLX-0K6 k /XCMPLX-0K7 n <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 0NUMBERSK6"
      using xreal_1_th_6 sorry
    thus "aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M"
      using A2 irrat_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_14:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies ((((0NUMBERSK6 <=XXREAL-0R1 bseqIRRAT-1K3 k .FUNCT-1K1 n & bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k) & 0NUMBERSK6 <=XXREAL-0R1 cseqIRRAT-1K4 n .FUNCT-1K1 k) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <=XXREAL-0R1 bseqIRRAT-1K3 k .FUNCT-1K1 n & (bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7) & (bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k & ((0NUMBERSK6 <=XXREAL-0R1 cseqIRRAT-1K4 n .FUNCT-1K1 k & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k)))"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. bseqIRRAT-1K3 Lamb1 .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 !NEWTONK7)"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
    then have A2: "n ^IRRAT-1K1 (-XCMPLX-0K4 k) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    have A3: " for k be NatNAT-1M1 holds bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7) implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A4: "?P(k)"
      show "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
      proof-
        show "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
        proof-
          have cases: "k <XXREAL-0R3 n or k >=XXREAL-0R2 n"
             sorry
          have case1: "k <XXREAL-0R3 n implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          proof(rule impI)
            assume A5: "k <XXREAL-0R3 n"
            have "(\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 (\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7))"
              using A4 xreal_1_th_64 sorry
            then have A6: "(\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
              using irrat_1_th_11 sorry
            have "aseqIRRAT-1K2 k .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
              using A5 irrat_1_th_13 sorry
            then have A7: "((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 (\<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
              using A6 xreal_1_th_64 sorry
            have "aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M"
              using A5 irrat_1_th_13 sorry
            then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
              using xreal_1_th_153 sorry
            have "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =COMPLEX1R1 ((\<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 bseqIRRAT-1K3 k .FUNCT-1K1 n)*XCMPLX-0K3 aseqIRRAT-1K2 k .FUNCT-1K1 n"
              using A1 irrat_1_th_6 sorry
            thus "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
              using A7 A8 xxreal_0_th_2 sorry
          qed
          have case2: "k >=XXREAL-0R2 n implies bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
          proof(rule impI)
            assume "k >=XXREAL-0R2 n"
            then have A9: "k +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n"
              using nat_1_th_13 sorry
            have "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 (n chooseNEWTONK4 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)))"
              using irrat_1_def_2 sorry
            also have "... = (0NUMBERSK6)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 (k +NAT-1K1 \<one>\<^sub>M)))"
              using A9 newton_def_3 sorry
            also have "... = 0NUMBERSK6"
               sorry
            finally have "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n =HIDDENR1 0NUMBERSK6"
               sorry
            thus "bseqIRRAT-1K3 (k +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
    qed "sorry"
    have A10: "bseqIRRAT-1K3 k .FUNCT-1K1 n =COMPLEX1R1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
      using irrat_1_def_2 sorry
    thus "0NUMBERSK6 <=XXREAL-0R1 bseqIRRAT-1K3 k .FUNCT-1K1 n"
      using A2 sorry
    have A11: "?P(0NUMBERSK6)"
      using irrat_1_th_10 newton_th_12 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A11 A3 sorry
    thus A12: "bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
       sorry
    thus "bseqIRRAT-1K3 k .FUNCT-1K1 n <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
      using irrat_1_def_5 sorry
    thus "(0NUMBERSK6 <=XXREAL-0R1 cseqIRRAT-1K4 n .FUNCT-1K1 k & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)) & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
      using A10 A2 A12 irrat_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_15:
" for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1 implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1 implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =HIDDENR1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
  proof(rule ballI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1"
    thus "seq be summableSERIES-1V1"
      using series_1_th_13 sorry
    have "SumSERIES-1K4 seq =HIDDENR1 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6))"
      using A1 series_1_th_13 series_1_th_15 sorry
    also have "... = seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
      using series_1_def_1 sorry
    finally show "SumSERIES-1K4 seq =HIDDENR1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_16:
" for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for sq be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 sq implies (sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =XBOOLE-0R4 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for k be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for sq be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 k & k <XXREAL-0R3 lenFINSEQ-1K4 sq implies (sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =XBOOLE-0R4 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix sq assume [ty]: "sq be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 k"
      and A2: "k <XXREAL-0R3 lenFINSEQ-1K4 sq"
    have A3: "lenFINSEQ-1K4 sq =COMPLEX1R1 (lenFINSEQ-1K4 sq -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 sq"
      using A2 nat_1_th_13 sorry
    then have A4: "k <=XXREAL-0R1 lenFINSEQ-1K4 sq -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 xreal_1_th_6 sorry
    have A5: "lenFINSEQ-1K4 sq >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =COMPLEX1R1 lenFINSEQ-1K4 sq -XCMPLX-0K6 \<one>\<^sub>M"
      using rfinseq_def_1 sorry
    then have "k inHIDDENR3 domFINSEQ-1K5 (sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 A4 finseq_3_th_25 sorry
    thus "(sq /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =XBOOLE-0R4 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      using A5 rfinseq_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_17:
" for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 sq >XXREAL-0R4 0NUMBERSK6 implies SumRVSUM-1K22 sq =COMPLEX1R1 sq .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
proof-
  have " for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 sq >XXREAL-0R4 0NUMBERSK6 implies SumRVSUM-1K22 sq =HIDDENR1 sq .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix sq assume [ty]: "sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
    assume A1: "lenFINSEQ-1K4 sq >XXREAL-0R4 0NUMBERSK6"
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 sq"
      using nat_1_th_13 sorry
    then have A2: "\<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 sq"
      using finseq_3_th_25 sorry
    have "SumRVSUM-1K22 sq =HIDDENR1 SumRVSUM-1K22 ((<*FINSEQ-1K13\<^bsub>(REALNUMBERSK2)\<^esub> sq /.PARTFUN1K7\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M))"
      using A1 card_1_th_27 finseq_5_th_29 sorry
    also have "... = SumRVSUM-1K20 ((<*FINSEQ-1K10 sq .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M))"
      using A2 partfun1_def_6 sorry
    also have "... = sq .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
      using rvsum_1_th_76 sorry
    finally show "SumRVSUM-1K22 sq =HIDDENR1 sq .FUNCT-1K1 \<one>\<^sub>M +XCMPLX-0K2 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_18:
" for n be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
proof-
  have " for n be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
  proof-
    let ?P = "\<lambda>Lamb1.  for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 Lamb1 & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 Lamb1 implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 Lamb1 implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
    have " for n be NatNAT-1M1 holds ( for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq) implies ( for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 sq =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M & (( for k be NatNAT-1M1 holds k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6)) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =HIDDENR1 SumRVSUM-1K22 sq)"
    proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A1: " for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      fix sq assume [ty]: "sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      assume A2: "lenFINSEQ-1K4 sq =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
        and A3: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        and A4: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6"
      have A5: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have A6: "k +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        assume "k <XXREAL-0R3 n"
        then have A7: "k +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using nat_1_def_3 sorry
        also have "... = sq .FUNCT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A3 A7 sorry
        also have "... = (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A2 A7 A6 irrat_1_th_16 sorry
        finally show "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      have A8: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k >=XXREAL-0R2 n"
        then have A9: "k +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using nat_1_def_3 sorry
        also have "... = 0NUMBERSK6"
          using A4 A9 sorry
        finally show "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 0NUMBERSK6"
           sorry
      qed "sorry"
      have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      then have A10: "lenFINSEQ-1K4 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =HIDDENR1 lenFINSEQ-1K4 sq -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 rfinseq_def_1 sorry
      also have "... = n"
        using A2 sorry
      finally have "lenFINSEQ-1K4 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =HIDDENR1 n"
         sorry
      then have A11: "SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =COMPLEX1R1 SumRVSUM-1K22 (sq /^RFINSEQK2\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
        using A1 A5 A8 sorry
      have A12: "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1"
        using A1 A10 A5 A8 sorry
      thus "seq be summableSERIES-1V1"
        using irrat_1_th_15 sorry
      have "SumSERIES-1K4 seq =HIDDENR1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
        using A12 irrat_1_th_15 sorry
      also have "... = sq .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
        using A3 sorry
      also have "... = SumRVSUM-1K22 sq"
        using A2 A11 irrat_1_th_17 sorry
      finally show "SumSERIES-1K4 seq =HIDDENR1 SumRVSUM-1K22 sq"
         sorry
    qed "sorry"
    then have A13: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have " for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds lenFINSEQ-1K4 sq =COMPLEX1R1 0NUMBERSK6 & (( for k be NatNAT-1M1 holds k <XXREAL-0R3 0NUMBERSK6 implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 0NUMBERSK6 implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6)) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
      fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
      fix sq assume [ty]: "sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2"
      assume A14: "lenFINSEQ-1K4 sq =COMPLEX1R1 0NUMBERSK6"
        and " for k be NatNAT-1M1 holds k <XXREAL-0R3 0NUMBERSK6 implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        and A15: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 0NUMBERSK6 implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6"
      have "sq be ElementFINSEQ-2M2\<^bsub>(REALNUMBERSK2)\<^esub>-of (0NUMBERSK6)-tuples-onFINSEQ-2K4 REALNUMBERSK2"
        using A14 finseq_2_th_92 sorry
      then have A16: "SumRVSUM-1K22 sq =COMPLEX1R1 0NUMBERSK6"
        using rvsum_1_th_79 sorry
      let ?P = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 seq .FUNCT-1K1 Lamb1 =COMPLEX1R1 0NUMBERSK6"
      have A17: " for k be NatNAT-1M1 holds Partial-SumsSERIES-1K3 seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6 implies Partial-SumsSERIES-1K3 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        have A18: "Partial-SumsSERIES-1K3 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 k +XCMPLX-0K2 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        assume "?P(k)"
        thus "Partial-SumsSERIES-1K3 seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 0NUMBERSK6"
          using A15 A18 sorry
      qed "sorry"
      have "seq .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
        using A15 sorry
      then have A19: "?P(0NUMBERSK6)"
        using series_1_def_1 sorry
      have A20: " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A19 A17 sorry
      then have "Partial-SumsSERIES-1K3 seq be convergentSEQ-2V5"
        using irrat_1_th_9 sorry
      thus "seq be summableSERIES-1V1"
        using series_1_def_2 sorry
      have "limSEQ-2K1 Partial-SumsSERIES-1K3 seq =COMPLEX1R1 0NUMBERSK6"
        using A20 irrat_1_th_9 sorry
      thus "SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
        using A16 series_1_def_3 sorry
    qed "sorry"
    then have A21: "?P(0NUMBERSK6)"
       sorry
    show " for n be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds  for sq be FinSequenceFINSEQ-1M3-of REALNUMBERSK2 holds (lenFINSEQ-1K4 sq =COMPLEX1R1 n & ( for k be NatNAT-1M1 holds k <XXREAL-0R3 n implies seq .FUNCT-1K1 k =COMPLEX1R1 sq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))) & ( for k be NatNAT-1M1 holds k >=XXREAL-0R2 n implies seq .FUNCT-1K1 k =COMPLEX1R1 0NUMBERSK6) implies seq be summableSERIES-1V1 & SumSERIES-1K4 seq =COMPLEX1R1 SumRVSUM-1K22 sq"
      using nat_1_sch_2 A21 A13 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_19:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds k <=XXREAL-0R1 n implies ((x,y)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (x ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 (y ^IRRAT-1K1 k)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds k <=XXREAL-0R1 n implies ((x,y)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (x ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 (y ^IRRAT-1K1 k)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    obtain i1 where 
      [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and i1Def:"i1 = (k +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
      using ordinal1_def_12 sorry
    have A1: "k +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M & lenFINSEQ-1K4 ((x,y)In-PowerNEWTONK5 n) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using newton_def_4 xreal_1_th_6 sorry
    assume A2: "k <=XXREAL-0R1 n"
    then obtain l where 
      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = n -XCMPLX-0K6 i1"
      using int_1_th_5 sorry
    have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using A2 xreal_1_th_6 sorry
    then have "k +NAT-1K1 \<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 ((x,y)In-PowerNEWTONK5 n)"
      using A1 finseq_3_th_25 sorry
    then have "((x,y)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n chooseNEWTONK4 i1)*XCMPLX-0K3 (x ^IRRAT-1K1 l))*XCMPLX-0K3 y  |^NEWTONK1 i1"
      using newton_def_4 sorry
    also have "... = ((n chooseNEWTONK4 k)*XCMPLX-0K3 (x ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 (y ^IRRAT-1K1 k)"
       sorry
    finally show "((x,y)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (x ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 (y ^IRRAT-1K1 k)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_20:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 & k <=XXREAL-0R1 n implies cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 & k <=XXREAL-0R1 n implies ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 cseqIRRAT-1K4 n .FUNCT-1K1 k"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
      and A2: "k <=XXREAL-0R1 n"
    have "((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((n chooseNEWTONK4 k)*XCMPLX-0K3 (\<one>\<^sub>M ^IRRAT-1K1 (n -XCMPLX-0K6 k)))*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 k)"
      using A2 irrat_1_th_19 sorry
    also have "... = ((n chooseNEWTONK4 k)*NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 k)"
      using power_th_26 sorry
    also have "... = (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
      using A1 power_th_32 sorry
    also have "... = cseqIRRAT-1K4 n .FUNCT-1K1 k"
      using irrat_1_def_3 sorry
    finally show "((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 cseqIRRAT-1K4 n .FUNCT-1K1 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_21:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies (cseqIRRAT-1K4 n be summableSERIES-1V1 & SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n) & SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 dseqIRRAT-1K5 .FUNCT-1K1 n"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies cseqIRRAT-1K4 n be summableSERIES-1V1 & ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n =HIDDENR1 SumSERIES-1K4 cseqIRRAT-1K4 n & SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 dseqIRRAT-1K5 .FUNCT-1K1 n)"
  proof(rule ballI,rule impI,rule conjMI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M implies cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 0NUMBERSK6"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
      then have A2: "k >XXREAL-0R4 n"
        using nat_1_th_13 sorry
      have "cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 (n chooseNEWTONK4 k)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
        using irrat_1_def_3 sorry
      also have "... = (0NUMBERSK6)*XCMPLX-0K3 (n ^IRRAT-1K1 (-XCMPLX-0K4 k))"
        using A2 newton_def_3 sorry
      also have "... = 0NUMBERSK6"
         sorry
      finally show "cseqIRRAT-1K4 n .FUNCT-1K1 k =HIDDENR1 0NUMBERSK6"
         sorry
    qed "sorry"
    assume A3: "n >XXREAL-0R4 0NUMBERSK6"
    have A4: " for k be NatNAT-1M1 holds k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume "k <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      then have "k <=XXREAL-0R1 n"
        using nat_1_th_13 sorry
      thus "cseqIRRAT-1K4 n .FUNCT-1K1 k =COMPLEX1R1 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A3 irrat_1_th_20 sorry
    qed "sorry"
    have A5: "lenFINSEQ-1K4 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n) =COMPLEX1R1 n +NAT-1K1 \<one>\<^sub>M"
      using newton_def_4 sorry
    thus "cseqIRRAT-1K4 n be summableSERIES-1V1"
      using A4 A1 irrat_1_th_18 sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n =HIDDENR1 SumRVSUM-1K22 ((\<one>\<^sub>M,\<one>\<^sub>M /XCMPLX-0K7 n)In-PowerNEWTONK5 n)"
      using newton_th_30 sorry
    also have "... = SumSERIES-1K4 cseqIRRAT-1K4 n"
      using A5 A4 A1 irrat_1_th_18 sorry
    finally show "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n)^IRRAT-1K1 n =HIDDENR1 SumSERIES-1K4 cseqIRRAT-1K4 n"
       sorry
    thus "SumSERIES-1K4 cseqIRRAT-1K4 n =COMPLEX1R1 dseqIRRAT-1K5 .FUNCT-1K1 n"
      using irrat_1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_22:
"dseqIRRAT-1K5 be convergentSEQ-2V5 & limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 number-ePOWERK4"
proof(rule conjMI)
  have A1: " for n be NatNAT-1M1 holds (dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))^IRRAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "(dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =HIDDENR1 dseqIRRAT-1K5 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using nat_1_def_3 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))^IRRAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using irrat_1_def_4 sorry
    finally show "(dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))^IRRAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  then have A2: "dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be convergentSEQ-2V5"
    using power_th_59 sorry
  thus "dseqIRRAT-1K5 be convergentSEQ-2V5"
    using seq_4_th_21 sorry
  have " for n be NatNAT-1M1 holds (dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))^IRRAT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
    using A1 sorry
  then have "number-ePOWERK4 =COMPLEX1R1 limSEQ-2K1 (dseqIRRAT-1K5 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
    using power_def_4 sorry
  thus "limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 number-ePOWERK4"
    using A2 seq_4_th_22 sorry
qed

mtheorem irrat_1_th_23:
"eseqIRRAT-1K6 be summableSERIES-1V1 & SumSERIES-1K4 eseqIRRAT-1K6 =HIDDENR1 exp-RSIN-COSK24 \<one>\<^sub>M"
proof-
  have "eseqIRRAT-1K6 be summableSERIES-1V1 & exp-RSIN-COSK24 \<one>\<^sub>M =HIDDENR1 SumSERIES-1K4 eseqIRRAT-1K6"
  proof(rule conjMI)
    have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 (\<one>\<^sub>M rExpSeqSIN-COSK5).FUNCT-1K1 k"
    proof(rule ballI)
      fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7)"
        using irrat_1_def_5 sorry
      also have "... = \<one>\<^sub>M  |^NEWTONK11 k /XCMPLX-0K7 (k !NEWTONK7)"
         sorry
      also have "... = (\<one>\<^sub>M rExpSeqSIN-COSK5).FUNCT-1K1 k"
        using sin_cos_def_5 sorry
      finally show "eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 (\<one>\<^sub>M rExpSeqSIN-COSK5).FUNCT-1K1 k"
         sorry
    qed "sorry"
    then have A1: "eseqIRRAT-1K6 =FUNCT-1R1 \<one>\<^sub>M rExpSeqSIN-COSK5"
      using funct_2_th_63 sorry
    thus "eseqIRRAT-1K6 be summableSERIES-1V1"
      using sin_cos_th_45 sorry
    have "exp-RSIN-COSK24 \<one>\<^sub>M =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 \<one>\<^sub>M"
      using sin_cos_def_23 sorry
    also have "... = SumSERIES-1K4 eseqIRRAT-1K6"
      using A1 sin_cos_def_22 sorry
    finally show "exp-RSIN-COSK24 \<one>\<^sub>M =HIDDENR1 SumSERIES-1K4 eseqIRRAT-1K6"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_24:
" for K be NatNAT-1M1 holds  for dseqK be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K"
proof-
  have " for n be NatNAT-1M1 holds  for dseqK be Real-SequenceSEQ-1M1 holds ( for nc be NatNAT-1M1 holds dseqK .FUNCT-1K1 nc =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 nc) .FUNCT-1K1 n) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n"
  proof-
    let ?P = "\<lambda>Lamb1.  for dseqK be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 Lamb1) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 Lamb1"
    have " for K be NatNAT-1M1 holds ( for dseqK be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K) implies ( for dseqK1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK1 .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)) implies dseqK1 be convergentSEQ-2V5 & limSEQ-2K1 dseqK1 =HIDDENR1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M))"
    proof(rule ballI,rule impI,rule ballI,rule impI,rule conjMI)
      fix K assume [ty]: "K be NatNAT-1M1"
      let ?F = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 Lamb1) .FUNCT-1K1 K"
      obtain dseqK where
        [ty]:"dseqK be Real-SequenceSEQ-1M1" and 
        A1: " for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
        using seq_1_sch_1 sorry
      assume A2: " for dseqK be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K"
      then have A3: "dseqK be convergentSEQ-2V5"
        using A1 sorry
      fix dseqK1 assume [ty]: "dseqK1 be Real-SequenceSEQ-1M1"
      assume A4: " for n be NatNAT-1M1 holds dseqK1 .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds dseqK1 .FUNCT-1K1 n =HIDDENR1 (dseqK +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "dseqK1 .FUNCT-1K1 n =HIDDENR1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
          using A4 sorry
        also have "... = Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K +XCMPLX-0K2 cseqIRRAT-1K4 n .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = dseqK .FUNCT-1K1 n +XCMPLX-0K2 cseqIRRAT-1K4 n .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = dseqK .FUNCT-1K1 n +XCMPLX-0K2 bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M) .FUNCT-1K1 n"
          using irrat_1_th_3 sorry
        also have "... = (dseqK +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 n"
          using seq_1_th_7 sorry
        finally show "dseqK1 .FUNCT-1K1 n =HIDDENR1 (dseqK +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 n"
           sorry
      qed "sorry"
      then have A5: "dseqK1 =FUNCT-1R1 dseqK +SERIES-1K1\<^bsub>(REALNUMBERSK2)\<^esub> bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M)"
        using funct_2_th_63 sorry
      have A6: "limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K"
        using A2 A1 sorry
      have A7: "bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M) be convergentSEQ-2V5"
        using irrat_1_th_12 sorry
      thus "dseqK1 be convergentSEQ-2V5"
        using A3 A5 sorry
      have "limSEQ-2K1 dseqK1 =HIDDENR1 limSEQ-2K1 dseqK +XCMPLX-0K2 limSEQ-2K1 bseqIRRAT-1K3 (K +NAT-1K1 \<one>\<^sub>M)"
        using A3 A5 A7 seq_2_th_6 sorry
      also have "... = Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K +XCMPLX-0K2 eseqIRRAT-1K6 .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
        using A6 irrat_1_th_12 sorry
      also have "... = Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
        using series_1_def_1 sorry
      finally show "limSEQ-2K1 dseqK1 =HIDDENR1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (K +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    then have A8: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have " for dseq0 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds dseq0 .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (0NUMBERSK6)) implies dseq0 be convergentSEQ-2V5 & limSEQ-2K1 dseq0 =HIDDENR1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6)"
    proof(rule ballI,rule impI,rule conjMI)
      fix dseq0 assume [ty]: "dseq0 be Real-SequenceSEQ-1M1"
      assume A9: " for n be NatNAT-1M1 holds dseq0 .FUNCT-1K1 n =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (0NUMBERSK6)"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds dseq0 .FUNCT-1K1 n =HIDDENR1 bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "dseq0 .FUNCT-1K1 n =HIDDENR1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 (0NUMBERSK6)"
          using A9 sorry
        also have "... = cseqIRRAT-1K4 n .FUNCT-1K1 (0NUMBERSK6)"
          using series_1_def_1 sorry
        also have "... = bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n"
          using irrat_1_th_3 sorry
        finally show "dseq0 .FUNCT-1K1 n =HIDDENR1 bseqIRRAT-1K3 (0NUMBERSK6) .FUNCT-1K1 n"
           sorry
      qed "sorry"
      then have A10: "dseq0 =FUNCT-1R1 bseqIRRAT-1K3 (0NUMBERSK6)"
        using funct_2_th_63 sorry
      thus "dseq0 be convergentSEQ-2V5"
        using irrat_1_th_12 sorry
      have "limSEQ-2K1 dseq0 =HIDDENR1 eseqIRRAT-1K6 .FUNCT-1K1 (0NUMBERSK6)"
        using A10 irrat_1_th_12 sorry
      also have "... = Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6)"
        using series_1_def_1 sorry
      finally show "limSEQ-2K1 dseq0 =HIDDENR1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6)"
         sorry
    qed "sorry"
    then have A11: "?P(0NUMBERSK6)"
       sorry
    show " for n be NatNAT-1M1 holds  for dseqK be Real-SequenceSEQ-1M1 holds ( for nc be NatNAT-1M1 holds dseqK .FUNCT-1K1 nc =COMPLEX1R1 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 nc) .FUNCT-1K1 n) implies dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n"
      using nat_1_sch_2 A11 A8 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_25:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps))"
proof-
  have " for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar6 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar6 implies  not seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps))"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
    fix eps assume [ty]: "eps be RealXREAL-0M1"
    assume "eps >XXREAL-0R4 0NUMBERSK6"
    then obtain N where
      [ty]:"N be NatNAT-1M1" and 
      A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps"
      using A1 seq_2_def_7 sorry
    show " ex tVar6 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar6 implies  not seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps"
    proof(rule bexI[of _ "N"],rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume "n >=XXREAL-0R2 N"
      then have " |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps"
        using A2 sorry
      then have "seq .FUNCT-1K1 n -XCMPLX-0K6 x >XXREAL-0R4 -XCMPLX-0K4 eps"
        using seq_2_th_1 sorry
      then have "(seq .FUNCT-1K1 n -XCMPLX-0K6 x)+XCMPLX-0K2 x >XXREAL-0R4 (-XCMPLX-0K4 eps)+XCMPLX-0K2 x"
        using xreal_1_th_6 sorry
      thus " not seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_26:
" for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps)) & ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n <=XXREAL-0R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
proof-
  have " for x be RealXREAL-0M1 holds  for seq be Real-SequenceSEQ-1M1 holds ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps)) & ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n <=XXREAL-0R1 x) implies seq be convergentSEQ-2V5 & limSEQ-2K1 seq =COMPLEX1R1 x"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps)"
      and A2: " ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies seq .FUNCT-1K1 n <=XXREAL-0R1 x"
    have A3: " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps)"
    proof-
      have " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar7 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar7 implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps)"
      proof(rule ballI,rule impI)
        fix eps assume [ty]: "eps be RealXREAL-0M1"
        assume A4: "eps >XXREAL-0R4 0NUMBERSK6"
        then have A5: "x +XCMPLX-0K2 eps >XXREAL-0R4 x +XCMPLX-0K2 0NUMBERSK6"
          using xreal_1_th_6 sorry
        obtain N2 where
          [ty]:"N2 be NatNAT-1M1" and 
          A6: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 N2 implies seq .FUNCT-1K1 n <=XXREAL-0R1 x"
          using A2 sorry
        obtain N1 where
          [ty]:"N1 be NatNAT-1M1" and 
          A7: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 N1 implies seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps"
          using A1 A4 sorry
        obtain N where 
          [ty]:"N be NatNAT-1M1" and NDef:"N = maxXXREAL-0K5(N1,N2)"
          using tarski_th_1 sorry
        show " ex tVar7 be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 tVar7 implies  not  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps"
        proof(rule bexI[of _ "N"],rule ballI,rule impI)
          fix n assume [ty]: "n be NatNAT-1M1"
          assume A8: "n >=XXREAL-0R2 N"
          then have "n >=XXREAL-0R2 N1"
            using xxreal_0_th_30 sorry
          then have "seq .FUNCT-1K1 n >XXREAL-0R4 x -XCMPLX-0K6 eps"
            using A7 sorry
          then have A9: "seq .FUNCT-1K1 n -XCMPLX-0K6 x >XXREAL-0R4 (x -XCMPLX-0K6 eps)-XCMPLX-0K6 x"
            using xreal_1_th_9 sorry
          have "seq .FUNCT-1K1 n <=XXREAL-0R1 x"
            using A6 A8 xxreal_0_th_30 sorry
          then have "seq .FUNCT-1K1 n <XXREAL-0R3 x +XCMPLX-0K2 eps"
            using A5 xxreal_0_th_2 sorry
          then have "seq .FUNCT-1K1 n -XCMPLX-0K6 x <XXREAL-0R3 eps"
            using xreal_1_th_19 sorry
          thus " not  |.COMPLEX1K10 seq .FUNCT-1K1 n -XCMPLX-0K6 x .| <XXREAL-0R3 eps"
            using A9 seq_2_th_1 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "seq be convergentSEQ-2V5"
       sorry
    thus "limSEQ-2K1 seq =COMPLEX1R1 x"
      using A3 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_27:
" for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex K be NatNAT-1M1 st Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K >XXREAL-0R4 SumSERIES-1K4 seq -XCMPLX-0K6 eps))"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 implies ( for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar8 be NatNAT-1M1 st  not Partial-SumsSERIES-1K3 seq .FUNCT-1K1 tVar8 >XXREAL-0R4 SumSERIES-1K4 seq -XCMPLX-0K6 eps))"
  proof(rule ballI,rule impI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume "seq be summableSERIES-1V1"
    then have A1: "Partial-SumsSERIES-1K3 seq be convergentSEQ-2V5"
      using series_1_def_2 sorry
    fix eps assume [ty]: "eps be RealXREAL-0M1"
    assume "eps >XXREAL-0R4 0NUMBERSK6"
    then obtain K where
      [ty]:"K be NatNAT-1M1" and 
      A2: " for k be NatNAT-1M1 holds k >=XXREAL-0R2 K implies Partial-SumsSERIES-1K3 seq .FUNCT-1K1 k >XXREAL-0R4 limSEQ-2K1 Partial-SumsSERIES-1K3 seq -XCMPLX-0K6 eps"
      using A1 irrat_1_th_25 sorry
    show " ex tVar8 be NatNAT-1M1 st  not Partial-SumsSERIES-1K3 seq .FUNCT-1K1 tVar8 >XXREAL-0R4 SumSERIES-1K4 seq -XCMPLX-0K6 eps"
    proof(rule bexI[of _ "K"])
      have "SumSERIES-1K4 seq =COMPLEX1R1 limSEQ-2K1 Partial-SumsSERIES-1K3 seq"
        using series_1_def_3 sorry
      thus " not Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K >XXREAL-0R4 SumSERIES-1K4 seq -XCMPLX-0K6 eps"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_28:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies dseqIRRAT-1K5 .FUNCT-1K1 n <=XXREAL-0R1 SumSERIES-1K4 eseqIRRAT-1K6"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies dseqIRRAT-1K5 .FUNCT-1K1 n <=XXREAL-0R1 SumSERIES-1K4 eseqIRRAT-1K6"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    then have " for k be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 cseqIRRAT-1K4 n .FUNCT-1K1 k & cseqIRRAT-1K4 n .FUNCT-1K1 k <=XXREAL-0R1 eseqIRRAT-1K6 .FUNCT-1K1 k"
      using irrat_1_th_14 sorry
    then have "SumSERIES-1K4 cseqIRRAT-1K4 n <=XXREAL-0R1 SumSERIES-1K4 eseqIRRAT-1K6"
      using irrat_1_th_23 series_1_th_20 sorry
    thus "dseqIRRAT-1K5 .FUNCT-1K1 n <=XXREAL-0R1 SumSERIES-1K4 eseqIRRAT-1K6"
      using A1 irrat_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_29:
" for K be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for k be NatNAT-1M1 holds seq .FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6) implies SumSERIES-1K4 seq >=XXREAL-0R2 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K"
proof-
  have " for K be NatNAT-1M1 holds  for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for k be NatNAT-1M1 holds seq .FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6) implies SumSERIES-1K4 seq >=XXREAL-0R2 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix K assume [ty]: "K be NatNAT-1M1"
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be summableSERIES-1V1"
      and A2: " for k be NatNAT-1M1 holds seq .FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6"
    have A3: " for k be NatNAT-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k =COMPLEX1R1 seq .FUNCT-1K1 ((K +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      thus "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6"
        using A2 sorry
    qed "sorry"
    have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M) be summableSERIES-1V1"
      using A1 series_1_th_12 sorry
    then have "SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M)) >=XXREAL-0R2 0NUMBERSK6"
      using A3 series_1_th_18 sorry
    then have "Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (K +NAT-1K1 \<one>\<^sub>M)) >=XXREAL-0R2 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_6 sorry
    thus "SumSERIES-1K4 seq >=XXREAL-0R2 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 K"
      using A1 series_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_30:
"dseqIRRAT-1K5 be convergentSEQ-2V5 & limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 SumSERIES-1K4 eseqIRRAT-1K6"
proof-
  have " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N be NatNAT-1M1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies dseqIRRAT-1K5 .FUNCT-1K1 n >XXREAL-0R4 SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps)"
  proof-
    have " for eps be RealXREAL-0M1 holds eps >XXREAL-0R4 0NUMBERSK6 implies ( ex N1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N1 implies  not dseqIRRAT-1K5 .FUNCT-1K1 n >XXREAL-0R4 SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps)"
    proof(rule ballI,rule impI)
      fix eps assume [ty]: "eps be RealXREAL-0M1"
      assume A1: "eps >XXREAL-0R4 0NUMBERSK6"
      then obtain K where
        [ty]:"K be NatNAT-1M1" and 
        A2: "Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K >XXREAL-0R4 SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M"
        using irrat_1_th_23 irrat_1_th_27 xreal_1_th_139 sorry
      have A3: "Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 (SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M)-XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M"
        using A2 xreal_1_th_9 sorry
      let ?F = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 Lamb1) .FUNCT-1K1 K"
      obtain dseqK where
        [ty]:"dseqK be Real-SequenceSEQ-1M1" and 
        A4: " for n be NatNAT-1M1 holds dseqK .FUNCT-1K1 n =COMPLEX1R1 ?F(n)"
        using seq_1_sch_1 sorry
      have "dseqK be convergentSEQ-2V5 & limSEQ-2K1 dseqK =COMPLEX1R1 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K"
        using A4 irrat_1_th_24 sorry
      then obtain N where
        [ty]:"N be NatNAT-1M1" and 
        A5: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 N implies dseqK .FUNCT-1K1 n >XXREAL-0R4 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M"
        using A1 irrat_1_th_25 xreal_1_th_139 sorry
      obtain N1 where 
        [ty]:"N1 be ElementSUBSET-1M1-of NATNUMBERSK1" and N1Def:"N1 = N +NAT-1K1 \<one>\<^sub>M"
         sorry
      show " ex N1 be ElementSUBSET-1M1-of NATNUMBERSK1 st  for n be NatNAT-1M1 holds n >=XXREAL-0R2 N1 implies  not dseqIRRAT-1K5 .FUNCT-1K1 n >XXREAL-0R4 SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps"
      proof(rule bexI[of _ "N1"],rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A6: "n >=XXREAL-0R2 N1"
        then have "( for k be NatNAT-1M1 holds cseqIRRAT-1K4 n .FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6) & cseqIRRAT-1K4 n be summableSERIES-1V1"
          using irrat_1_th_14 irrat_1_th_21 sorry
        then have "SumSERIES-1K4 cseqIRRAT-1K4 n >=XXREAL-0R2 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K"
          using irrat_1_th_29 sorry
        then have "dseqIRRAT-1K5 .FUNCT-1K1 n >=XXREAL-0R2 Partial-SumsSERIES-1K3 (cseqIRRAT-1K4 n) .FUNCT-1K1 K"
          using A6 irrat_1_th_21 sorry
        then have A7: "dseqIRRAT-1K5 .FUNCT-1K1 n >=XXREAL-0R2 dseqK .FUNCT-1K1 n"
          using A4 sorry
        have "N +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 N +NAT-1K1 0NUMBERSK6"
          using xreal_1_th_6 sorry
        then have "n >=XXREAL-0R2 N"
          using A6 xxreal_0_th_2 sorry
        then have "dseqK .FUNCT-1K1 n >XXREAL-0R4 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M"
          using A5 sorry
        then have "dseqIRRAT-1K5 .FUNCT-1K1 n >XXREAL-0R4 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 K -XCMPLX-0K6 eps /XCMPLX-0K7 \<two>\<^sub>M"
          using A7 xxreal_0_th_2 sorry
        thus " not dseqIRRAT-1K5 .FUNCT-1K1 n >XXREAL-0R4 SumSERIES-1K4 eseqIRRAT-1K6 -XCMPLX-0K6 eps"
          using A3 xxreal_0_th_2 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "dseqIRRAT-1K5 be convergentSEQ-2V5 & limSEQ-2K1 dseqIRRAT-1K5 =COMPLEX1R1 SumSERIES-1K4 eseqIRRAT-1K6"
    using irrat_1_th_26 irrat_1_th_28 sorry
qed

abbreviation(input) IRRAT_1K7("number-eIRRAT-1K7" 164) where
  "number-eIRRAT-1K7 \<equiv> number-ePOWERK4"

mtheorem irrat_1_def_6:
"redefine func number-eIRRAT-1K7 \<rightarrow> objectHIDDENM1 equals
  SumSERIES-1K4 eseqIRRAT-1K6"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 number-eIRRAT-1K7 iff it =HIDDENR1 SumSERIES-1K4 eseqIRRAT-1K6"
    using irrat_1_th_22 irrat_1_th_30 sorry
qed "sorry"

abbreviation(input) IRRAT_1K8("number-eIRRAT-1K8" 164) where
  "number-eIRRAT-1K8 \<equiv> number-ePOWERK4"

mtheorem irrat_1_def_7:
"redefine func number-eIRRAT-1K8 \<rightarrow> objectHIDDENM1 equals
  exp-RSIN-COSK24 \<one>\<^sub>M"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 number-eIRRAT-1K8 iff it =HIDDENR1 exp-RSIN-COSK24 \<one>\<^sub>M"
    using irrat_1_th_23 sorry
qed "sorry"

(*begin*)
mtheorem irrat_1_th_31:
" for x be RealXREAL-0M1 holds x be rationalRAT-1V1 implies ( ex n be NatNAT-1M1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1)"
proof-
  have " for x be RealXREAL-0M1 holds x be rationalRAT-1V1 implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1)"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x be rationalRAT-1V1"
    then obtain i n where
      [ty]:"i be IntegerINT-1M1" "n be NatNAT-1M1" and 
      A1: "n <>HIDDENR2 0NUMBERSK6"and A2: "x =COMPLEX1R1 i /XCMPLX-0K7 n"
      using rat_1_th_8 sorry
    show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1"
    proof-
      have cases: "n <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M or n >=XXREAL-0R2 \<two>\<^sub>M"
         sorry
      have case1: "n <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M implies ( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1)"
      proof(rule impI)
        assume A3: "n <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
        have A4: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using A1 nat_1_th_13 sorry
        have "n <=XXREAL-0R1 \<one>\<^sub>M"
          using A3 nat_1_th_13 sorry
        then have "n =COMPLEX1R1 \<one>\<^sub>M"
          using A4 xxreal_0_th_1 sorry
        then obtain x1 where 
          [ty]:"x1 be IntegerINT-1M1" and x1Def:"x1 = x"
          using A2 sorry
        obtain n where 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = \<two>\<^sub>M"
           sorry
        show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1"
        proof(rule bexI[of _ "n"])
          have "(n !NEWTONK7)*XCMPLX-0K3 x1 be integerINT-1V1"
             sorry
          thus "n >=XXREAL-0R2 \<two>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1"
             sorry
        qed "sorry"
      qed
      have case2: "n >=XXREAL-0R2 \<two>\<^sub>M implies ( ex tVar11 be NatNAT-1M1 st tVar11 >=XXREAL-0R2 \<two>\<^sub>M & (tVar11 !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1)"
      proof(rule impI)
        assume A5: "n >=XXREAL-0R2 \<two>\<^sub>M"
        show " ex tVar11 be NatNAT-1M1 st tVar11 >=XXREAL-0R2 \<two>\<^sub>M & (tVar11 !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1"
        proof(rule bexI[of _ "n"],rule conjMI)
          show "n >=XXREAL-0R2 \<two>\<^sub>M"
            using A5 sorry
          obtain m where 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = n -XCMPLX-0K6 \<one>\<^sub>M"
            using A5 int_1_th_5 xxreal_0_th_2 sorry
          have "(n !NEWTONK7)*XCMPLX-0K3 x =HIDDENR1 ((m +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (m !NEWTONK7))*XCMPLX-0K3 x"
            using newton_th_15 sorry
          also have "... = (n *XCMPLX-0K3 x)*XCMPLX-0K3 (m !NEWTONK7)"
             sorry
          also have "... = i *XCMPLX-0K3 (m !NEWTONK7)"
            using A1 A2 xcmplx_1_th_87 sorry
          finally have "(n !NEWTONK7)*XCMPLX-0K3 x =HIDDENR1 i *XCMPLX-0K3 (m !NEWTONK7)"
             sorry
          thus "(n !NEWTONK7)*XCMPLX-0K3 x be integerINT-1V1"
             sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_32:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 k =COMPLEX1R1 (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "(n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (k !NEWTONK7))"
      using irrat_1_def_5 sorry
    also have "... = (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
       sorry
    finally show "(n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 k =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_33:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) >XXREAL-0R4 0NUMBERSK6"
  using xreal_1_th_139 sorry

mtheorem irrat_1_th_34:
" for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6) implies SumSERIES-1K4 seq >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for seq be Real-SequenceSEQ-1M1 holds seq be summableSERIES-1V1 & ( for n be NatNAT-1M1 holds seq .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6) implies  not SumSERIES-1K4 seq >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Real-SequenceSEQ-1M1"
    assume A1: "seq be summableSERIES-1V1"
      and A2: " for n be NatNAT-1M1 holds seq .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6"
    have A3: "SumSERIES-1K4 seq =HIDDENR1 Partial-SumsSERIES-1K3 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M))"
      using A1 series_1_th_15 sorry
    also have "... = seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
      using series_1_def_1 sorry
    finally have "SumSERIES-1K4 seq =HIDDENR1 seq .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)"
       sorry
    have A4: " for n be NatNAT-1M1 holds (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =COMPLEX1R1 seq .FUNCT-1K1 (\<one>\<^sub>M +XCMPLX-0K2 n)"
        using nat_1_def_3 sorry
      thus "(seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
        using A2 sorry
    qed "sorry"
    have "seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be summableSERIES-1V1"
      using A1 series_1_th_12 sorry
    then have "SumSERIES-1K4 (seq ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
      using A4 series_1_th_18 sorry
    then have "SumSERIES-1K4 seq >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 0NUMBERSK6"
      using A2 A3 xreal_1_th_8 sorry
    thus " not SumSERIES-1K4 seq >XXREAL-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_35:
" for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  not (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: " for k be NatNAT-1M1 holds (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k >XXREAL-0R4 0NUMBERSK6"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have "(eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k =HIDDENR1 eseqIRRAT-1K6 .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)"
        using irrat_1_def_5 sorry
      finally have "(eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)"
         sorry
      thus "(eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k >XXREAL-0R4 0NUMBERSK6"
         sorry
    qed "sorry"
    have "eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be summableSERIES-1V1"
      using irrat_1_th_23 series_1_th_12 sorry
    then have "n !NEWTONK7 >XXREAL-0R4 0NUMBERSK6 & SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 0NUMBERSK6"
      using A1 irrat_1_th_34 sorry
    thus " not (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_129 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_36:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies (n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. ((Lamb1 +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
    assume "k <=XXREAL-0R1 n"
    then obtain m where 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = n -XCMPLX-0K6 k"
      using int_1_th_5 sorry
    have A1: "n =COMPLEX1R1 m +XCMPLX-0K2 k"
       sorry
    have " for m be NatNAT-1M1 holds ((m +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1 implies (((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      have A2: "(((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) =HIDDENR1 (((m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)*NAT-1K2 ((m +XCMPLX-0K2 k)!NEWTONK7))*XCMPLX-0K3 (k !NEWTONK7)\<inverse>XCMPLX-0K5"
        using newton_th_15 sorry
      also have "... = ((m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (((m +XCMPLX-0K2 k)!NEWTONK7)*XCMPLX-0K3 (k !NEWTONK7)\<inverse>XCMPLX-0K5)"
         sorry
      also have "... = ((m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (((m +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7))"
         sorry
      finally have "(((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) =HIDDENR1 ((m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (((m +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7))"
         sorry
      assume "((m +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
      then obtain i where 
        [ty]:"i be IntegerINT-1M1" and iDef:"i = ((m +XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7)"
         sorry
      have "((m +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 i be IntegerINT-1M1"
         sorry
      thus "(((m +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)!NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
        using A2 sorry
    qed "sorry"
    then have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have A4: "?P(0NUMBERSK6)"
      using xcmplx_1_th_60 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A3 sorry
    thus "(n !NEWTONK7)/XCMPLX-0K7 (k !NEWTONK7) be integerINT-1V1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_37:
" for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n be integerINT-1V1"
proof-
  have " for n be NatNAT-1M1 holds (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n be integerINT-1V1"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 n implies (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 Lamb1 be integerINT-1V1"
    have " for k be NatNAT-1M1 holds (k <=XXREAL-0R1 n implies (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k be integerINT-1V1) implies (k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n implies (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) be integerINT-1V1)"
    proof(rule ballI,rule impI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A1: "k <=XXREAL-0R1 n implies (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k be integerINT-1V1"
      assume A2: "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
      have "k +NAT-1K1 0NUMBERSK6 <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      then obtain i where 
        [ty]:"i be IntegerINT-1M1" and iDef:"i = (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k"
        using A1 A2 xxreal_0_th_2 sorry
      have "(n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 (n !NEWTONK7)/XCMPLX-0K7 ((k +NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
        using irrat_1_th_32 sorry
      then obtain j where 
        [ty]:"j be IntegerINT-1M1" and jDef:"j = (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A2 irrat_1_th_36 sorry
      have A3: "i +XCMPLX-0K2 j be IntegerINT-1M1"
         sorry
      have "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 (Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k +XCMPLX-0K2 eseqIRRAT-1K6 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using series_1_def_1 sorry
      also have "... = (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k +XCMPLX-0K2 (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      finally have "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 k +XCMPLX-0K2 (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) be integerINT-1V1"
        using A3 sorry
    qed "sorry"
    then have A4: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
       sorry
    have "0NUMBERSK6 <=XXREAL-0R1 n implies (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6) be integerINT-1V1"
    proof(rule impI)
      assume "0NUMBERSK6 <=XXREAL-0R1 n"
      have "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 (0NUMBERSK6)"
        using series_1_def_1 sorry
      also have "... = (n !NEWTONK7)/XCMPLX-0K7 ((0NUMBERSK6)!NEWTONK7)"
        using irrat_1_th_32 sorry
      finally have "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 ((0NUMBERSK6)!NEWTONK7)"
         sorry
      thus "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 (0NUMBERSK6) be integerINT-1V1"
        using irrat_1_th_36 sorry
    qed
    then have A5: "?P(0NUMBERSK6)"
       sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A5 A4 sorry
    thus "(n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n be integerINT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_38:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 Lamb1)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    assume A1: "x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    have A2: " for k be NatNAT-1M1 holds (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "?P(k)"
      have A4: "(n !NEWTONK7)/XCMPLX-0K7 (((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 (((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)\<inverse>XCMPLX-0K5"
         sorry
      also have "... = (n !NEWTONK7)*XCMPLX-0K3 (((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))\<inverse>XCMPLX-0K5"
        using newton_th_15 sorry
      also have "... = (n !NEWTONK7)*XCMPLX-0K3 (((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)\<inverse>XCMPLX-0K5)"
        using xcmplx_1_th_204 sorry
      also have "... = ((n !NEWTONK7)*XCMPLX-0K3 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 ((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
         sorry
      also have "... = ((n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 ((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
         sorry
      finally have "(n !NEWTONK7)/XCMPLX-0K7 (((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) =HIDDENR1 ((n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))*XCMPLX-0K3 ((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
         sorry
      have "n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 n +NAT-1K1 0NUMBERSK6"
        using xreal_1_th_6 sorry
      then have "(n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      then have A5: "((n +NAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
        using xreal_1_th_85 sorry
      have "(x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 x =HIDDENR1 (x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (x ^IRRAT-1K1 \<one>\<^sub>M)"
         sorry
      also have "... = x ^IRRAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using A1 power_th_27 sorry
      finally have "(x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 x =HIDDENR1 x ^IRRAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "(n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 (k +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using A1 A3 A5 A4 xreal_1_th_66 sorry
    qed "sorry"
    have "(n !NEWTONK7)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n !NEWTONK7))"
      using newton_th_15 sorry
    also have "... = (n !NEWTONK7)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n !NEWTONK7))\<inverse>XCMPLX-0K5"
       sorry
    also have "... = (n !NEWTONK7)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (n !NEWTONK7)\<inverse>XCMPLX-0K5)"
      using xcmplx_1_th_204 sorry
    also have "... = ((n !NEWTONK7)*XCMPLX-0K3 (n !NEWTONK7)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
       sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
      using xcmplx_0_def_7 sorry
    also have "... = x"
      using A1 sorry
    finally have "(n !NEWTONK7)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)!NEWTONK7) =HIDDENR1 x"
       sorry
    then have A6: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A6 A2 sorry
    thus "(n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7) <=XXREAL-0R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_39:
" for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds n >XXREAL-0R4 0NUMBERSK6 & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)"
proof-
  have " for n be NatNAT-1M1 holds  for x be RealXREAL-0M1 holds n >XXREAL-0R4 0NUMBERSK6 & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume A1: "n >XXREAL-0R4 0NUMBERSK6"
      and A2: "x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    let ?F = "\<lambda>Lamb1. x ^IRRAT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain seq where
      [ty]:"seq be Real-SequenceSEQ-1M1" and 
      A3: " for k be NatNAT-1M1 holds seq .FUNCT-1K1 k =COMPLEX1R1 ?F(k)"
      using seq_1_sch_1 sorry
    have A4: " for k be NatNAT-1M1 holds ((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6 & ((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k <=XXREAL-0R1 seq .FUNCT-1K1 k"
    proof(rule ballI,rule conjMI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have A5: "((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)).FUNCT-1K1 k"
        using seq_1_th_9 sorry
      also have "... = (n !NEWTONK7)*XCMPLX-0K3 eseqIRRAT-1K6 .FUNCT-1K1 ((n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 k)"
        using nat_1_def_3 sorry
      also have "... = (n !NEWTONK7)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7))"
        using irrat_1_def_5 sorry
      also have "... = (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
         sorry
      finally have "((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k =HIDDENR1 (n !NEWTONK7)/XCMPLX-0K7 (((n +XCMPLX-0K2 k)+NAT-1K1 \<one>\<^sub>M)!NEWTONK7)"
         sorry
      thus "((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k >=XXREAL-0R2 0NUMBERSK6"
         sorry
      have "seq .FUNCT-1K1 k =COMPLEX1R1 x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A3 sorry
      thus "((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))).FUNCT-1K1 k <=XXREAL-0R1 seq .FUNCT-1K1 k"
        using A2 A5 irrat_1_th_38 sorry
    qed "sorry"
    have A6: "seq .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x ^IRRAT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using A3 sorry
    also have "... = x"
       sorry
    finally have "seq .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 x"
       sorry
    have A7: "eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be summableSERIES-1V1"
      using irrat_1_th_23 series_1_th_12 sorry
    have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A1 xreal_1_th_6 sorry
    then have A8: "x <XXREAL-0R3 \<one>\<^sub>M"
      using A2 xreal_1_th_212 sorry
    have A9: " for k be NatNAT-1M1 holds seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x *XCMPLX-0K3 seq .FUNCT-1K1 k"
    proof(rule ballI)
      fix k assume [ty]: "k be NatNAT-1M1"
      have "seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x ^IRRAT-1K1 ((k +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
        using A3 sorry
      also have "... = (x ^IRRAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
        using A2 power_th_27 sorry
      also have "... = x *XCMPLX-0K3 (x ^IRRAT-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
         sorry
      also have "... = x *XCMPLX-0K3 seq .FUNCT-1K1 k"
        using A3 sorry
      finally show "seq .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 x *XCMPLX-0K3 seq .FUNCT-1K1 k"
         sorry
    qed "sorry"
    have " |.COMPLEX1K10 x.| =COMPLEX1R1 x"
      using A2 absvalue_def_1 sorry
    then have "seq be summableSERIES-1V1"
      using A8 A9 series_1_th_25 sorry
    then have A10: "SumSERIES-1K4 ((n !NEWTONK7)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))) <=XXREAL-0R1 SumSERIES-1K4 seq"
      using A4 series_1_th_20 sorry
    have " |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
      using A2 A8 absvalue_def_1 sorry
    then have "SumSERIES-1K4 seq =COMPLEX1R1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)"
      using A6 A9 series_1_th_25 sorry
    thus "(n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x)"
      using A7 A10 series_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem irrat_1_th_40:
" for x be RealXREAL-0M1 holds  for n be RealXREAL-0M1 holds n >=XXREAL-0R2 \<two>\<^sub>M & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) implies x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for n be RealXREAL-0M1 holds n >=XXREAL-0R2 \<two>\<^sub>M & x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) implies  not x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix n assume [ty]: "n be RealXREAL-0M1"
    assume A1: "n >=XXREAL-0R2 \<two>\<^sub>M"
      and A2: "x =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M)"
    have "n +XCMPLX-0K2 \<one>\<^sub>M >XXREAL-0R4 n"
      using xreal_1_th_29 sorry
    then have "\<two>\<^sub>M <XXREAL-0R3 n +XCMPLX-0K2 \<one>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
    then have "\<two>\<^sub>M /XCMPLX-0K7 (n +XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_189 sorry
    then have "x +XCMPLX-0K2 x <XXREAL-0R3 \<one>\<^sub>M"
      using A2 sorry
    then have "x <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 x"
      using xreal_1_th_20 sorry
    thus " not x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 x) <XXREAL-0R3 \<one>\<^sub>M"
      using A1 A2 xreal_1_th_189 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Irrationality of e*)
mtheorem irrat_1_th_41:
"number-eIRRAT-1K8 be irrationalIRRAT-1V1"
proof-
  have "number-eIRRAT-1K8 be rationalRAT-1V1 implies  False "
  proof(rule impI)
    assume "number-eIRRAT-1K8 be rationalRAT-1V1"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A1: "n >=XXREAL-0R2 \<two>\<^sub>M"and A2: "(n !NEWTONK7)*XCMPLX-0K3 (number-eIRRAT-1K8) be integerINT-1V1"
      using irrat_1_th_31 sorry
    obtain ne where 
      [ty]:"ne be IntegerINT-1M1" and neDef:"ne = (n !NEWTONK7)*XCMPLX-0K3 (number-eIRRAT-1K8)"
      using A2 sorry
    let ?x = "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
    obtain ne1 where 
      [ty]:"ne1 be IntegerINT-1M1" and ne1Def:"ne1 = (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n"
      using irrat_1_th_37 sorry
    have "(n !NEWTONK7)*XCMPLX-0K3 (number-eIRRAT-1K8) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 (Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n +XCMPLX-0K2 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
      using irrat_1_th_23 series_1_th_15 sorry
    also have "... = (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n +XCMPLX-0K2 (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    finally have "(n !NEWTONK7)*XCMPLX-0K3 (number-eIRRAT-1K8) =HIDDENR1 (n !NEWTONK7)*XCMPLX-0K3 Partial-SumsSERIES-1K3 (eseqIRRAT-1K6) .FUNCT-1K1 n +XCMPLX-0K2 (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
    then have A3: "(n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) =COMPLEX1R1 ne -XCMPLX-0K6 ne1"
       sorry
    have "?x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 ?x) <XXREAL-0R3 \<one>\<^sub>M & (n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 ?x /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 ?x)"
      using A1 irrat_1_th_39 irrat_1_th_40 sorry
    then have "(n !NEWTONK7)*XCMPLX-0K3 SumSERIES-1K4 (eseqIRRAT-1K6 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xxreal_0_th_2 sorry
    thus " False "
      using A3 irrat_1_th_35 int_1_th_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

end
