theory comseq_1
  imports valued_1 xcmplx_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve f for "FunctionFUNCT-1M1"
reserve n, k, n1 for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve r, p for "ComplexXCMPLX-0M1"
reserve x, y for "setHIDDENM2"
syntax COMSEQ_1M1 :: "Ty" ("Complex-SequenceCOMSEQ-1M1" 70)
translations "Complex-SequenceCOMSEQ-1M1" \<rightharpoonup> "sequenceNAT-1M2-of COMPLEXNUMBERSK3"

reserve seq, seq1, seq2, seq3, seq9, seq19 for "Complex-SequenceCOMSEQ-1M1"
mtheorem comseq_1_th_1:
" for f be FunctionFUNCT-1M1 holds f be Complex-SequenceCOMSEQ-1M1 iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be Complex-SequenceCOMSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) implies f be Complex-SequenceCOMSEQ-1M1)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Complex-SequenceCOMSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
    proof(rule impI,rule conjMI,rule ballI,rule impI)
      assume A1: "f be Complex-SequenceCOMSEQ-1M1"
      thus A2: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
        using funct_2_def_1 sorry
      fix x assume [ty]: "x be setHIDDENM2"
      assume "x inTARSKIR2 NATNUMBERSK1"
      then have A3: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
        using A2 funct_1_def_3 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 COMPLEXNUMBERSK3"
        using A1 relat_1_def_19 sorry
      thus "f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        using A3 sorry
    qed "sorry"
    assume A4: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A5: " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 COMPLEXNUMBERSK3"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "y inHIDDENR3 rngFUNCT-1K2 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A6: "x inHIDDENR3 domRELAT-1K1 f"and A7: "y =HIDDENR1 f .FUNCT-1K1 x"
        using funct_1_def_3 sorry
      have "f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
        using A4 A5 A6 sorry
      thus "y inHIDDENR3 COMPLEXNUMBERSK3"
        using A7 sorry
    qed "sorry"
    then have "rngFUNCT-1K2 f c=TARSKIR1 COMPLEXNUMBERSK3"
      using tarski_def_3 sorry
    thus "f be Complex-SequenceCOMSEQ-1M1"
      using A4 funct_2_def_1 relset_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_2:
" for f be FunctionFUNCT-1M1 holds f be Complex-SequenceCOMSEQ-1M1 iff domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
proof-
  have " for f be FunctionFUNCT-1M1 holds (f be Complex-SequenceCOMSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)) & (domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3) implies f be Complex-SequenceCOMSEQ-1M1)"
  proof(rule ballI,rule conjMI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    show "f be Complex-SequenceCOMSEQ-1M1 implies domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3)"
      using comseq_1_th_1 sorry
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
      and A2: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 n be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
    have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      using A2 sorry
    thus "f be Complex-SequenceCOMSEQ-1M1"
      using A1 comseq_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem comseq_1_sch_1:
  fixes Ff1 
  assumes
[ty_func]: "\<And> x1. x1 be setHIDDENM2 \<Longrightarrow> Ff1(x1) be ComplexXCMPLX-0M1"
  shows " ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff1(n)"
  proof-
    have " ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff1(n)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2.  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 Lamb1 & Lamb2 =HIDDENR1 Ff1(n)"
      have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ( ex y be objectHIDDENM1 st  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 NATNUMBERSK1"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A2: "n =HIDDENR1 x"
           sorry
        obtain r2 where 
          [ty]:"r2 be objectHIDDENM1" and r2Def:"r2 = Ff1(n)"
           sorry
        obtain y where 
          [ty]:"y be objectHIDDENM1" and yDef:"y = r2"
           sorry
        show " ex y be objectHIDDENM1 st  ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n)"
        proof(rule bexI[of _ "y"])
          show " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =HIDDENR1 x & y =HIDDENR1 Ff1(n)"
            using A2 sorry
        qed "sorry"
      qed "sorry"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A3: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A4: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies ?P(x,f .FUNCT-1K1 x)"
        using classes1_sch_1 A1 sorry
      have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 NATNUMBERSK1"
        then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 x & f .FUNCT-1K1 x =HIDDENR1 Ff1(n)"
          using A4 sorry
        thus "f .FUNCT-1K1 x be ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
      qed "sorry"
      then have 
        [ty]:"f be Complex-SequenceCOMSEQ-1M1"
        using A3 comseq_1_th_1 sorry
      obtain seq where 
        [ty]:"seq be Complex-SequenceCOMSEQ-1M1" and seqDef:"seq = f"
         sorry
      show " ex seq be Complex-SequenceCOMSEQ-1M1 st  for n be NatNAT-1M1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff1(n)"
      proof(rule bexI[of _ "seq"],rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "n inTARSKIR2 NATNUMBERSK1"
          using ordinal1_def_12 sorry
        then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st k =COMPLEX1R1 n & seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff1(k)"
          using A4 sorry
        thus "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 Ff1(n)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem comseq_1_cl_1:
"cluster non-zeroORDINAL1V9 for Complex-SequenceCOMSEQ-1M1"
proof
(*existence*)
  show " ex it be Complex-SequenceCOMSEQ-1M1 st it be non-zeroORDINAL1V9"
  proof-
    have " ex s be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :]) st s be non-zeroORDINAL1V9"
    proof-
      obtain s where 
        [ty]:"s be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :])" and sDef:"s = NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> 1rCOMPLEX1K7"
         sorry
      show " ex s be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,COMPLEXNUMBERSK3 :]) st s be non-zeroORDINAL1V9"
      proof(rule bexI[of _ "s"])
        have Cut128: "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s =XBOOLE-0R4 {TARSKIK1 \<one>\<^sub>M}"
          using funcop_1_th_8 sorry
        have " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s"
        proof-
          show " not 0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> s"
            using tarski_def_1 Cut128 sorry
        qed
        thus "s be non-zeroORDINAL1V9"
          using ordinal1_def_15 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem comseq_1_th_3:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 iff ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds (seq be non-zeroORDINAL1V9 implies ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6)) & (( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6) implies seq be non-zeroORDINAL1V9)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 implies ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6)"
    proof-
      have "seq be non-zeroORDINAL1V9 implies ( for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies  not seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6)"
      proof(rule impI,rule ballI,rule impI)
        assume A1: "seq be non-zeroORDINAL1V9"
        fix x assume [ty]: "x be setHIDDENM2"
        assume "x inTARSKIR2 NATNUMBERSK1"
        then have "x inTARSKIR2 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq"
          using comseq_1_th_2 sorry
        then have "seq .FUNCT-1K1 x inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
          using funct_1_def_3 sorry
        thus " not seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A2: " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6"
    have "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq implies  False "
    proof(rule impI)
      assume "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
      then have "0NUMBERSK6 inTARSKIR2 rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq"
         sorry
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> seq & seq .FUNCT-1K1 x =COMPLEX1R1 0NUMBERSK6"
        using funct_1_def_3 sorry
      thus " False "
        using A2 sorry
    qed
    thus "seq be non-zeroORDINAL1V9"
      using ordinal1_def_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_4:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 iff ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds (seq be non-zeroORDINAL1V9 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6)) & (( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6) implies seq be non-zeroORDINAL1V9)"
  proof(rule ballI,rule conjMI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 implies ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6)"
      using comseq_1_th_3 sorry
    assume " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
    then have " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies seq .FUNCT-1K1 x <>HIDDENR2 0cCOMPLEX1K6"
       sorry
    thus "seq be non-zeroORDINAL1V9"
      using comseq_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_5:
" for IT be non-zeroORDINAL1V9\<bar>Complex-SequenceCOMSEQ-1M1 holds rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> IT c=TARSKIR1 COMPLEXNUMBERSK3 \\SUBSET-1K6 {TARSKIK1 0cCOMPLEX1K6 }"
  using ordinal1_def_15 zfmisc_1_th_34 sorry

mtheorem comseq_1_th_6:
" for r be ComplexXCMPLX-0M1 holds  ex seq be Complex-SequenceCOMSEQ-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> seq =XBOOLE-0R4 {TARSKIK1 r}"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  ex tVar4 be Complex-SequenceCOMSEQ-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar4 =XBOOLE-0R4 {TARSKIK1 r}"
  proof(rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 r}"
      using funct_1_th_5 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK1 r} implies x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then have "rngFUNCT-1K2 f c=TARSKIR1 COMPLEXNUMBERSK3"
      using A2 tarski_def_3 sorry
    then have 
      [ty]:"f be Complex-SequenceCOMSEQ-1M1"
      using A1 funct_2_def_1 relset_1_th_4 sorry
    show " ex tVar4 be Complex-SequenceCOMSEQ-1M1 st rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> tVar4 =XBOOLE-0R4 {TARSKIK1 r}"
    proof(rule bexI[of _ "f"])
      show "rngRELSET-1K2\<^bsub>(COMPLEXNUMBERSK3)\<^esub> f =XBOOLE-0R4 {TARSKIK1 r}"
        using A2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_7:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)+XCMPLX-0K2 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_8:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_9:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq3 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "((seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_10:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
  using comseq_1_th_9 sorry

mtheorem comseq_1_th_11:
" for seq be Complex-SequenceCOMSEQ-1M1 holds -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq"
   sorry

mtheorem comseq_1_th_12:
" for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = (r *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_13:
" for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_14:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have "(seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using comseq_1_th_9 sorry
    also have "... = seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
    also have "... = seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
      using comseq_1_th_12 sorry
    also have "... = seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
    finally show "(seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 =HIDDENR1 seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_15:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)"
  using comseq_1_th_14 sorry

mtheorem comseq_1_th_16:
" for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 r *XCMPLX-0K3 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = r *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_1 sorry
      also have "... = r *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 r *XCMPLX-0K3 seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n +XCMPLX-0K2 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_1 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_17:
" for r be ComplexXCMPLX-0M1 holds  for p be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for p be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix p assume [ty]: "p be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r *XCMPLX-0K3 p)*XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = r *XCMPLX-0K3 (p *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = r *XCMPLX-0K3 (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "((r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r *XCMPLX-0K3 p)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (p (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_18:
" for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_1_th_16 sorry
    also have "... = r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
       sorry
    also have "... = r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)*XCMPLX-0K3 r)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
      using comseq_1_th_17 sorry
    also have "... = r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)"
      using comseq_1_th_17 sorry
    also have "... = r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
       sorry
    finally show "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2) =HIDDENR1 r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_19:
" for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
       sorry
    also have "... = (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using comseq_1_th_12 sorry
    finally show "r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_20:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have "seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
       sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)"
      using comseq_1_th_16 sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)"
       sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3))"
       sorry
    also have "... = (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using comseq_1_th_7 sorry
    finally show "seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_21:
" for seq be Complex-SequenceCOMSEQ-1M1 holds 1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds 1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 1rCOMPLEX1K7 *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      also have "... = seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      finally show "(1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "1rCOMPLEX1K7 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_22:
" for seq be Complex-SequenceCOMSEQ-1M1 holds -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq"
   sorry

mtheorem comseq_1_th_23:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
   sorry

mtheorem comseq_1_th_24:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have "seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3)"
       sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)"
      using comseq_1_th_18 sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3)"
       sorry
    also have "... = seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3))"
       sorry
    also have "... = (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using comseq_1_th_7 sorry
    finally show "seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)+VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_25:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
proof-
  have " for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds  for seq3 be Complex-SequenceCOMSEQ-1M1 holds seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    fix seq3 assume [ty]: "seq3 be Complex-SequenceCOMSEQ-1M1"
    have "seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq3))"
       sorry
    also have "... = (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
      using comseq_1_th_7 sorry
    finally show "seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq2 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3) =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2)-VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_26:
" for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2 & seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq2) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq2"
  using comseq_1_th_12 sorry

mtheorem comseq_1_th_27:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 &  not seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9 implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: " not seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
    obtain n1 where
      [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A3: "seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1 =COMPLEX1R1 0cCOMPLEX1K6"
      using A2 comseq_1_th_4 sorry
    have "(seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1)\<inverse>XCMPLX-0K5 =COMPLEX1R1 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1"
      using valued_1_th_10 sorry
    thus " False "
      using A1 A3 comseq_1_th_4 xcmplx_1_th_202 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem comseq_1_th_29:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 iff seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9) & (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9 implies seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    show "seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
    proof(rule impI)
      assume A1: "seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9"
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have A2: "(seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
          using valued_1_th_5 sorry
        have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6 & seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
          using A1 comseq_1_th_4 sorry
        thus "(seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
          using A2 sorry
      qed "sorry"
      thus "seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
        using comseq_1_th_4 sorry
    qed
    assume A3: "seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      thus "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using A3 comseq_1_th_4 sorry
    qed "sorry"
    thus "seq be non-zeroORDINAL1V9"
      using comseq_1_th_4 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =COMPLEX1R1 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      thus "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using A3 comseq_1_th_4 sorry
    qed "sorry"
    thus "seq1 be non-zeroORDINAL1V9"
      using comseq_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_30:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_10 sorry
      also have "... = (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_10 sorry
      also have "... = (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = ((seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_5 sorry
      also have "... = (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "(seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_31:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1"
  proof(rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using A1 comseq_1_th_4 sorry
      have "((seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 1rCOMPLEX1K7"
        using A2 xcmplx_0_def_7 sorry
      also have "... = seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      finally show "((seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_32:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Complex-SequenceCOMSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 (seq19 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq19 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n))"
         sorry
      also have "... = seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq19 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = (seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq19 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      also have "... = (seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq19 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using comseq_1_th_30 sorry
      also have "... = (seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = ((seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "((seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq9 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_33:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq1 be non-zeroORDINAL1V9 implies seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq1 be non-zeroORDINAL1V9"
    have "seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> be non-zeroORDINAL1V9"
      using A2 comseq_1_th_27 sorry
    thus "seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 be non-zeroORDINAL1V9"
      using A1 comseq_1_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_34:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using comseq_1_th_30 sorry
      also have "... = (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      finally show "(seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_35:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have "seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_8 sorry
    also have "... = (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    finally show "seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_36:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using comseq_1_th_34 sorry
      also have "... = ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using comseq_1_th_8 sorry
      also have "... = ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
      finally show "(seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_37:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be non-zeroORDINAL1V9 implies seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq2 be Complex-SequenceCOMSEQ-1M1 holds seq1 be non-zeroORDINAL1V9 implies seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq2 assume [ty]: "seq2 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq1 be non-zeroORDINAL1V9"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n <>HIDDENR2 0cCOMPLEX1K6"
        using A1 comseq_1_th_4 sorry
      have "(seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 1rCOMPLEX1K7)*XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5))*XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using A2 xcmplx_0_def_7 sorry
      also have "... = (seq2 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)*XCMPLX-0K3 ((seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
         sorry
      also have "... = (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 ((seq1 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_5 sorry
      also have "... = (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)"
        using valued_1_th_10 sorry
      also have "... = (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      also have "... = (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using comseq_1_th_30 sorry
      also have "... = ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "(seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "seq2 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq2 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_38:
" for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds r <>HIDDENR2 0cCOMPLEX1K6 & seq be non-zeroORDINAL1V9 implies r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds r <>HIDDENR2 0cCOMPLEX1K6 & (seq be non-zeroORDINAL1V9 &  not r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    assume A1: "r <>HIDDENR2 0cCOMPLEX1K6"
      and A2: "seq be non-zeroORDINAL1V9"
      and A3: " not r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
    obtain n1 where
      [ty]:"n1 be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A4: "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1 =COMPLEX1R1 0cCOMPLEX1K6"
      using A3 comseq_1_th_4 sorry
    have A5: "r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1 =COMPLEX1R1 0cCOMPLEX1K6"
      using A4 valued_1_th_6 sorry
    have "seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n1 <>HIDDENR2 0cCOMPLEX1K6"
      using A2 comseq_1_th_4 sorry
    thus " False "
      using A1 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_39:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq be non-zeroORDINAL1V9"
  using comseq_1_th_38 sorry

mtheorem comseq_1_th_40:
" for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 ((r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_10 sorry
      also have "... = (r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_6 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_204 sorry
      also have "... = r \<inverse>XCMPLX-0K5 *XCMPLX-0K3 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_10 sorry
      also have "... = (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n =HIDDENR1 (r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n"
         sorry
    qed "sorry"
    thus "(r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r \<inverse>XCMPLX-0K5 (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_41:
" for seq be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  not (seq be non-zeroORDINAL1V9 &  not (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have "(-XCMPLX-0K4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 =COMPLEX1R1 -XCMPLX-0K4 \<one>\<^sub>M"
       sorry
    thus " not (seq be non-zeroORDINAL1V9 &  not (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using comseq_1_th_40 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_42:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 implies -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
    have "-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)"
       sorry
    also have "... = ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_12 sorry
    also have "... = (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    finally show "-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    have "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using A1 comseq_1_th_41 sorry
    also have "... = (-XCMPLX-0K4 1rCOMPLEX1K7)(#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using comseq_1_th_13 sorry
    also have "... = -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (-VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq) =HIDDENR1 -VALUED-1K33\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_43:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Complex-SequenceCOMSEQ-1M1"
    have "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_9 sorry
    also have "... = (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    have "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_14 sorry
    also have "... = (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq =HIDDENR1 (seq1 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_44:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq9 be non-zeroORDINAL1V9 implies seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds seq be non-zeroORDINAL1V9 & seq9 be non-zeroORDINAL1V9 implies seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) & seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Complex-SequenceCOMSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Complex-SequenceCOMSEQ-1M1"
    assume A1: "seq be non-zeroORDINAL1V9"
      and A2: "seq9 be non-zeroORDINAL1V9"
    have "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9"
      using A2 comseq_1_th_37 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
      using A1 comseq_1_th_37 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_9 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 +VALUED-1K2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
       sorry
    have "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9"
      using A2 comseq_1_th_37 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9) -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
      using A1 comseq_1_th_37 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_14 sorry
    also have "... = (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
       sorry
    finally show "seq1 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 =HIDDENR1 (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 -VALUED-1K48\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_45:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =RELSET-1R2\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq1 be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  for seq19 be Complex-SequenceCOMSEQ-1M1 holds (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq1 assume [ty]: "seq1 be Complex-SequenceCOMSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Complex-SequenceCOMSEQ-1M1"
    fix seq19 assume [ty]: "seq19 be Complex-SequenceCOMSEQ-1M1"
    have "(seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 (seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)\<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using comseq_1_th_30 sorry
    also have "... = ((seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_8 sorry
    also have "... = (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>))(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>"
      using comseq_1_th_8 sorry
    also have "... = seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> ((seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using comseq_1_th_8 sorry
    also have "... = seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq1 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>))"
      using comseq_1_th_8 sorry
    also have "... = (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)(#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>)"
      using comseq_1_th_8 sorry
    also have "... = (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
      using comseq_1_th_30 sorry
    finally show "(seq19 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1) =HIDDENR1 (seq19 (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq1)/\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_46:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n *XCMPLX-0K3 seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
        using valued_1_th_5 sorry
      also have "... = ( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
        using complex1_th_65 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.COMPLEX1K10 seq9 .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
        using valued_1_th_18 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_18 sorry
      also have "... = (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_5 sorry
      finally show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq (#)VALUED-1K20\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq9 .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem comseq_1_th_48:
" for seq be Complex-SequenceCOMSEQ-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|"
  proof(rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 (seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n)\<inverse>XCMPLX-0K5.|"
        using valued_1_th_10 sorry
      also have "... =  |.COMPLEX1K10 1rCOMPLEX1K7 /XCMPLX-0K7 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
        using xcmplx_1_th_215 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
        using complex1_th_48 complex1_th_67 sorry
      also have "... = ( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)\<inverse>XCMPLX-0K5"
        using xcmplx_1_th_215 sorry
      also have "... = (( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n)\<inverse>XCMPLX-0K5"
        using valued_1_th_18 sorry
      also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_10 sorry
      finally show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_49:
" for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
proof-
  have " for seq be Complex-SequenceCOMSEQ-1M1 holds  for seq9 be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
  proof(rule ballI,rule ballI)
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    fix seq9 assume [ty]: "seq9 be Complex-SequenceCOMSEQ-1M1"
    have " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)(#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq \<inverse>VALUED-1K38\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub>.|)"
      using comseq_1_th_46 sorry
    also have "... = ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
      using comseq_1_th_48 sorry
    finally show " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9 /\<inverse>VALUED-1K53\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3,COMPLEXNUMBERSK3)\<^esub> seq .| =HIDDENR1 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq9.|)/\<inverse>VALUED-1K54\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem comseq_1_th_50:
" for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
proof-
  have " for r be ComplexXCMPLX-0M1 holds  for seq be Complex-SequenceCOMSEQ-1M1 holds  |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
  proof(rule ballI,rule ballI)
    fix r assume [ty]: "r be ComplexXCMPLX-0M1"
    fix seq assume [ty]: "seq be Complex-SequenceCOMSEQ-1M1"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq).NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|"
        using valued_1_th_18 sorry
      also have "... =  |.COMPLEX1K10 r *XCMPLX-0K3 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n .|"
        using valued_1_th_6 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 seq .NAT-1K8\<^bsub>(COMPLEXNUMBERSK3)\<^esub> n.|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_18 sorry
      also have "... = (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        using valued_1_th_6 sorry
      finally show "( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .|).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =HIDDENR1 (( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)).NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
         sorry
    qed "sorry"
    thus " |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> r (#)VALUED-1K27\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq .| =RELSET-1R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.COMPLEX1K10 r.|)(#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ( |.VALUED-1K58\<^bsub>(NATNUMBERSK1,COMPLEXNUMBERSK3)\<^esub> seq.|)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
