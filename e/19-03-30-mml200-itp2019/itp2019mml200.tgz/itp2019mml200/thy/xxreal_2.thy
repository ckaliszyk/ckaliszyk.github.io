theory xxreal_2
  imports setwiseo rat_1 xxreal_1 classes1
   "../mizar_extension/E_number"
begin
(*begin*)
theorem xxreal_2_sch_1:
  fixes mf0 nf0 Ff1 Pp1 
  assumes
[ty]: "mf0 be IntegerINT-1M1" and
  [ty]: "nf0 be IntegerINT-1M1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1"
  shows "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
  proof-
    let ?F = "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) }"
    show "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
    proof-
      have cases: "nf0 <XXREAL-0R3 mf0 or mf0 <=XXREAL-0R1 nf0"
         sorry
      have case1: "nf0 <XXREAL-0R3 mf0 implies {Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
      proof(rule impI)
        assume A1: "nf0 <XXREAL-0R3 mf0"
        have "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } <>HIDDENR2 {}XBOOLE-0K1 implies  False "
        proof(rule impI)
          assume "?F <>HIDDENR2 {}XBOOLE-0K1"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A2: "x inHIDDENR3 ?F"
            using xboole_0_def_1 sorry
          have " ex i be ElementSUBSET-1M1-of INTINT-1K1 st ((x =HIDDENR1 Ff1(i) & mf0 <=XXREAL-0R1 i) & i <=XXREAL-0R1 nf0) & Pp1(i)"
            using A2 sorry
          thus " False "
            using A1 xxreal_0_th_2 sorry
        qed
        then obtain F where 
          [ty]:"F be emptyXBOOLE-0V1\<bar>setHIDDENM2" and FDef:"F = ?F"
           sorry
        have "F be finiteFINSET-1V1"
           sorry
        thus "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
           sorry
      qed
      have case2: "mf0 <=XXREAL-0R1 nf0 implies {Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
      proof(rule impI)
        assume "mf0 <=XXREAL-0R1 nf0"
        then obtain k where 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = nf0 -XCMPLX-0K6 mf0"
          using int_1_th_5 sorry
        let ?F = "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) }"
        let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex i be IntegerINT-1M1 st Lamb1 =HIDDENR1 i & Lamb2 =HIDDENR1 Ff1(i +XCMPLX-0K2 mf0)"
        have A3: " for e be objectHIDDENM1 holds e inHIDDENR3 k +NAT-1K1 \<one>\<^sub>M implies ( ex u be objectHIDDENM1 st ?Q(e,u))"
        proof-
          have " for e be objectHIDDENM1 holds e inHIDDENR3 k +NAT-1K1 \<one>\<^sub>M implies ( ex tVar1 be objectHIDDENM1 st  ex tVar2 be IntegerINT-1M1 st e =HIDDENR1 tVar2 & Ff1(tVar2 +XCMPLX-0K2 mf0) =HIDDENR1 Ff1(tVar2 +XCMPLX-0K2 mf0))"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume "e inHIDDENR3 k +NAT-1K1 \<one>\<^sub>M"
            then have "e inHIDDENR3 SegmCARD-1K5 (k +NAT-1K1 \<one>\<^sub>M)"
               sorry
            then obtain i where 
              [ty]:"i be NatNAT-1M1" and iDef:"i = e"
               sorry
            show " ex tVar1 be objectHIDDENM1 st  ex tVar2 be IntegerINT-1M1 st e =HIDDENR1 tVar2 & Ff1(tVar2 +XCMPLX-0K2 mf0) =HIDDENR1 Ff1(tVar2 +XCMPLX-0K2 mf0)"
            proof(rule bexI[of _ "Ff1(i +XCMPLX-0K2 mf0)"])
              show " ex tVar2 be IntegerINT-1M1 st e =HIDDENR1 tVar2 & Ff1(tVar2 +XCMPLX-0K2 mf0) =HIDDENR1 Ff1(tVar2 +XCMPLX-0K2 mf0)"
              proof(rule bexI[of _ "i"])
                show "e =HIDDENR1 i & Ff1(i +XCMPLX-0K2 mf0) =HIDDENR1 Ff1(i +XCMPLX-0K2 mf0)"
                   sorry
              qed "sorry"
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A4: "domRELAT-1K1 f =XBOOLE-0R4 k +NAT-1K1 \<one>\<^sub>M"and A5: " for i be objectHIDDENM1 holds i inHIDDENR3 k +NAT-1K1 \<one>\<^sub>M implies ?Q(i,f .FUNCT-1K1 i)"
          using classes1_sch_1 A3 sorry
        have A6: "?F c=TARSKIR1 rngFUNCT-1K2 f"
        proof-
          have "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } c=TARSKIR1 rngFUNCT-1K2 f"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 {Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } implies x inHIDDENR3 rngFUNCT-1K2 f"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 ?F"
              then obtain j where
                [ty]:"j be ElementSUBSET-1M1-of INTINT-1K1" and 
                A7: "x =HIDDENR1 Ff1(j)"and A8: "mf0 <=XXREAL-0R1 j"and A9: "j <=XXREAL-0R1 nf0"and "Pp1(j)"
                 sorry
              obtain l where 
                [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and lDef:"l = j -XCMPLX-0K6 mf0"
                using A8 int_1_th_5 sorry
              have "l <=XXREAL-0R1 k"
                using A9 xreal_1_th_9 sorry
              then have "l <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
                using nat_1_th_13 sorry
              then have A10: "l inTARSKIR2 SegmCARD-1K5 (k +NAT-1K1 \<one>\<^sub>M)"
                using nat_1_th_44 sorry
              then have "?Q(j -XCMPLX-0K6 mf0,f .FUNCT-1K1 (j -XCMPLX-0K6 mf0))"
                using A5 sorry
              then have "f .FUNCT-1K1 (j -XCMPLX-0K6 mf0) =HIDDENR1 Ff1((j +XCMPLX-0K2 mf0)-XCMPLX-0K6 mf0)"
                 sorry
              also have "... = Ff1(j)"
                 sorry
              finally have "f .FUNCT-1K1 (j -XCMPLX-0K6 mf0) =HIDDENR1 Ff1(j)"
                 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 f"
                using A4 A7 A10 funct_1_def_3 sorry
            qed "sorry"
            thus "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } c=TARSKIR1 rngFUNCT-1K2 f"
              using tarski_def_3 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "rngFUNCT-1K2 f be finiteFINSET-1V1"
          using A4 finset_1_th_8 sorry
        thus "{Ff1(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (mf0 <=XXREAL-0R1 i & i <=XXREAL-0R1 nf0) & Pp1(i) } be finiteFINSET-1V1"
          using A6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed

reserve x, y, z, r, s for "ExtRealXXREAL-0M1"
mdef xxreal_2_def_1 ("UpperBoundXXREAL-2M1-of  _ " [70]70 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"mode UpperBoundXXREAL-2M1-of X \<rightarrow> ExtRealXXREAL-0M1 means
  (\<lambda>it.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 it)"
proof-
  (*existence*)
    show " ex it be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 it"
    proof-
      have " ex tVar3 be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not x <=XXREAL-0R1 tVar3)"
      proof-
        show " ex tVar3 be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not x <=XXREAL-0R1 tVar3)"
        proof(rule bexI[of _ "+inftyXXREAL-0K1"])
          show " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not x <=XXREAL-0R1 +inftyXXREAL-0K1)"
            using xxreal_0_th_4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xxreal_2_def_2 ("LowerBoundXXREAL-2M2-of  _ " [70]70 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"mode LowerBoundXXREAL-2M2-of X \<rightarrow> ExtRealXXREAL-0M1 means
  (\<lambda>it.  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies it <=XXREAL-0R1 x)"
proof-
  (*existence*)
    show " ex it be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies it <=XXREAL-0R1 x"
    proof-
      have " ex tVar4 be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not tVar4 <=XXREAL-0R1 x)"
      proof-
        show " ex tVar4 be ExtRealXXREAL-0M1 st  for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not tVar4 <=XXREAL-0R1 x)"
        proof(rule bexI[of _ "-inftyXXREAL-0K2"])
          show " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not -inftyXXREAL-0K2 <=XXREAL-0R1 x)"
            using xxreal_0_th_5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xxreal_2_def_3 ("supXXREAL-2K1  _ " [300]300 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func supXXREAL-2K1 X \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it. it be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds it <=XXREAL-0R1 x)"
proof-
  (*existence*)
    show " ex it be ExtRealXXREAL-0M1 st it be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds it <=XXREAL-0R1 x)"
    proof-
      have " ex tVar5 be ExtRealXXREAL-0M1 st tVar5 be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds tVar5 <=XXREAL-0R1 x)"
      proof-
        let ?Q = "\<lambda>Lamb1. Lamb1 be UpperBoundXXREAL-2M1-of X"
        let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X"
        have A1: " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ?P(r) & ?Q(s) implies r <=XXREAL-0R1 s"
          using xxreal_2_def_1 sorry
        obtain s where
          [ty]:"s be ExtRealXXREAL-0M1" and 
          A2: " for r be ExtRealXXREAL-0M1 holds ?P(r) implies r <=XXREAL-0R1 s"and A3: " for r be ExtRealXXREAL-0M1 holds ?Q(r) implies s <=XXREAL-0R1 r"
          using xxreal_1_sch_1 A1 sorry
        show " ex tVar5 be ExtRealXXREAL-0M1 st tVar5 be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds tVar5 <=XXREAL-0R1 x)"
        proof(rule bexI[of _ "s"],rule conjMI)
          show "s be UpperBoundXXREAL-2M1-of X"
            using A2 xxreal_2_def_1 sorry
          show " for x be UpperBoundXXREAL-2M1-of X holds s <=XXREAL-0R1 x"
            using A3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (it1 be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds it1 <=XXREAL-0R1 x)) & (it2 be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds it2 <=XXREAL-0R1 x)) implies it1 =HIDDENR1 it2"
    proof-
      have " for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of X & (( for x be UpperBoundXXREAL-2M1-of X holds y <=XXREAL-0R1 x) & (z be UpperBoundXXREAL-2M1-of X & ( for x be UpperBoundXXREAL-2M1-of X holds z <=XXREAL-0R1 x))) implies y =HIDDENR1 z"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix y assume [ty]: "y be ExtRealXXREAL-0M1"
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A4: "y be UpperBoundXXREAL-2M1-of X"
          and A5: " for x be UpperBoundXXREAL-2M1-of X holds y <=XXREAL-0R1 x"
          and A6: "z be UpperBoundXXREAL-2M1-of X"
          and A7: " for x be UpperBoundXXREAL-2M1-of X holds z <=XXREAL-0R1 x"
        have A8: "y <=XXREAL-0R1 z"
          using A5 A6 sorry
        have "z <=XXREAL-0R1 y"
          using A4 A7 sorry
        thus "y =HIDDENR1 z"
          using A8 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xxreal_2_def_4 ("infXXREAL-2K2  _ " [228]228 ) where
  mlet "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func infXXREAL-2K2 X \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it. it be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 it)"
proof-
  (*existence*)
    show " ex it be ExtRealXXREAL-0M1 st it be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 it)"
    proof-
      have " ex tVar6 be ExtRealXXREAL-0M1 st tVar6 be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 tVar6)"
      proof-
        let ?Q = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X"
        let ?P = "\<lambda>Lamb1. Lamb1 be LowerBoundXXREAL-2M2-of X"
        have A9: " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds ?P(r) & ?Q(s) implies r <=XXREAL-0R1 s"
          using xxreal_2_def_2 sorry
        obtain s where
          [ty]:"s be ExtRealXXREAL-0M1" and 
          A10: " for r be ExtRealXXREAL-0M1 holds ?P(r) implies r <=XXREAL-0R1 s"and A11: " for r be ExtRealXXREAL-0M1 holds ?Q(r) implies s <=XXREAL-0R1 r"
          using xxreal_1_sch_1 A9 sorry
        show " ex tVar6 be ExtRealXXREAL-0M1 st tVar6 be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 tVar6)"
        proof(rule bexI[of _ "s"],rule conjMI)
          show "s be LowerBoundXXREAL-2M2-of X"
            using A11 xxreal_2_def_2 sorry
          show " for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 s"
            using A10 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ExtRealXXREAL-0M1 holds  for it2 be ExtRealXXREAL-0M1 holds (it1 be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 it1)) & (it2 be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 it2)) implies it1 =HIDDENR1 it2"
    proof-
      have " for y be ExtRealXXREAL-0M1 holds  for z be ExtRealXXREAL-0M1 holds y be LowerBoundXXREAL-2M2-of X & (( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 y) & (z be LowerBoundXXREAL-2M2-of X & ( for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 z))) implies y =HIDDENR1 z"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix y assume [ty]: "y be ExtRealXXREAL-0M1"
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A12: "y be LowerBoundXXREAL-2M2-of X"
          and A13: " for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 y"
          and A14: "z be LowerBoundXXREAL-2M2-of X"
          and A15: " for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 z"
        have A16: "z <=XXREAL-0R1 y"
          using A13 A14 sorry
        have "y <=XXREAL-0R1 z"
          using A12 A15 sorry
        thus "y =HIDDENR1 z"
          using A16 xxreal_0_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef xxreal_2_def_5 ("left-endXXREAL-2V1" 70 ) where
"attr left-endXXREAL-2V1 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>X. infXXREAL-2K2 X inHIDDENR3 X)"..

mdef xxreal_2_def_6 ("right-endXXREAL-2V2" 70 ) where
"attr right-endXXREAL-2V2 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>X. supXXREAL-2K1 X inHIDDENR3 X)"..

mtheorem xxreal_2_th_1:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of {TARSKIK1 x} iff x <=XXREAL-0R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (y be UpperBoundXXREAL-2M1-of {TARSKIK1 x} implies x <=XXREAL-0R1 y) & (x <=XXREAL-0R1 y implies y be UpperBoundXXREAL-2M1-of {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "y be UpperBoundXXREAL-2M1-of {TARSKIK1 x} implies x <=XXREAL-0R1 y"
      using xxreal_2_def_1 sorry
    assume A1: "x <=XXREAL-0R1 y"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 {TARSKIK1 x} implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 {TARSKIK1 x}"
      thus "z <=XXREAL-0R1 y"
        using A1 tarski_def_1 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of {TARSKIK1 x}"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_2:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be LowerBoundXXREAL-2M2-of {TARSKIK1 x} iff y <=XXREAL-0R1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds (y be LowerBoundXXREAL-2M2-of {TARSKIK1 x} implies y <=XXREAL-0R1 x) & (y <=XXREAL-0R1 x implies y be LowerBoundXXREAL-2M2-of {TARSKIK1 x})"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "x inHIDDENR3 {TARSKIK1 x}"
      using tarski_def_1 sorry
    thus "y be LowerBoundXXREAL-2M2-of {TARSKIK1 x} implies y <=XXREAL-0R1 x"
      using xxreal_2_def_2 sorry
    assume A1: "y <=XXREAL-0R1 x"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 {TARSKIK1 x} implies y <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 {TARSKIK1 x}"
      thus "y <=XXREAL-0R1 z"
        using A1 tarski_def_1 sorry
    qed "sorry"
    thus "y be LowerBoundXXREAL-2M2-of {TARSKIK1 x}"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_2_lm_1:
" for x be ExtRealXXREAL-0M1 holds supXXREAL-2K1 {TARSKIK1 x} =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds supXXREAL-2K1 {TARSKIK1 x} =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have A1: " for z be UpperBoundXXREAL-2M1-of {TARSKIK1 x} holds x <=XXREAL-0R1 z"
    proof(rule ballI)
      fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of {TARSKIK1 x}"
      have "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      thus "x <=XXREAL-0R1 z"
        using xxreal_2_def_1 sorry
    qed "sorry"
    have "x be UpperBoundXXREAL-2M1-of {TARSKIK1 x}"
      using xxreal_2_th_1 sorry
    thus "supXXREAL-2K1 {TARSKIK1 x} =HIDDENR1 x"
      using A1 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_2_lm_2:
" for x be ExtRealXXREAL-0M1 holds infXXREAL-2K2 {TARSKIK1 x} =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds infXXREAL-2K2 {TARSKIK1 x} =HIDDENR1 x"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have A1: " for z be LowerBoundXXREAL-2M2-of {TARSKIK1 x} holds z <=XXREAL-0R1 x"
    proof(rule ballI)
      fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of {TARSKIK1 x}"
      have "x inHIDDENR3 {TARSKIK1 x}"
        using tarski_def_1 sorry
      thus "z <=XXREAL-0R1 x"
        using xxreal_2_def_2 sorry
    qed "sorry"
    have "x be LowerBoundXXREAL-2M2-of {TARSKIK1 x}"
      using xxreal_2_th_2 sorry
    thus "infXXREAL-2K2 {TARSKIK1 x} =HIDDENR1 x"
      using A1 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_1:
"cluster note-that ext-real-memberedMEMBEREDV2 for ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3)"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds it be ext-real-memberedMEMBEREDV2"
  proof-
    have " for X be ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds X be ext-real-memberedMEMBEREDV2"
    proof(rule ballI)
      fix X assume [ty]: "X be ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3)"
      have "X c=TARSKIR1 ExtREALXXREAL-0K3"
        using finsub_1_def_5 sorry
      thus "X be ext-real-memberedMEMBEREDV2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve A, B for "ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
mtheorem xxreal_2_th_3:
" for x be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds x inHIDDENR3 A implies infXXREAL-2K2 A <=XXREAL-0R1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (x inHIDDENR3 A &  not infXXREAL-2K2 A <=XXREAL-0R1 x)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    have "infXXREAL-2K2 A be LowerBoundXXREAL-2M2-of A"
      using xxreal_2_def_4 sorry
    thus " not (x inHIDDENR3 A &  not infXXREAL-2K2 A <=XXREAL-0R1 x)"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_4:
" for x be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds x inHIDDENR3 A implies x <=XXREAL-0R1 supXXREAL-2K1 A"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  not (x inHIDDENR3 A &  not x <=XXREAL-0R1 supXXREAL-2K1 A)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    have "supXXREAL-2K1 A be UpperBoundXXREAL-2M1-of A"
      using xxreal_2_def_3 sorry
    thus " not (x inHIDDENR3 A &  not x <=XXREAL-0R1 supXXREAL-2K1 A)"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_5:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds B c=MEMBEREDR2 A implies ( for x be LowerBoundXXREAL-2M2-of A holds x be LowerBoundXXREAL-2M2-of B)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds B c=MEMBEREDR2 A implies ( for x be LowerBoundXXREAL-2M2-of A holds x be LowerBoundXXREAL-2M2-of B)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "B c=MEMBEREDR2 A"
    fix x assume [ty]: "x be LowerBoundXXREAL-2M2-of A"
    have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 B implies x <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "y inHIDDENR3 B"
      thus "x <=XXREAL-0R1 y"
        using A1 xxreal_2_def_2 sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of B"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_6:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds B c=MEMBEREDR2 A implies ( for x be UpperBoundXXREAL-2M1-of A holds x be UpperBoundXXREAL-2M1-of B)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds B c=MEMBEREDR2 A implies ( for x be UpperBoundXXREAL-2M1-of A holds x be UpperBoundXXREAL-2M1-of B)"
  proof(rule ballI,rule ballI,rule impI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "B c=MEMBEREDR2 A"
    fix x assume [ty]: "x be UpperBoundXXREAL-2M1-of A"
    have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 B implies y <=XXREAL-0R1 x"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "y inHIDDENR3 B"
      thus "y <=XXREAL-0R1 x"
        using A1 xxreal_2_def_1 sorry
    qed "sorry"
    thus "x be UpperBoundXXREAL-2M1-of B"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_7:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be LowerBoundXXREAL-2M2-of A holds  for y be LowerBoundXXREAL-2M2-of B holds minXXREAL-0K4(x,y) be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be LowerBoundXXREAL-2M2-of A holds  for y be LowerBoundXXREAL-2M2-of B holds minXXREAL-0K4(x,y) be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix x assume [ty]: "x be LowerBoundXXREAL-2M2-of A"
    fix y assume [ty]: "y be LowerBoundXXREAL-2M2-of B"
    let ?m = "minXXREAL-0K4(x,y)"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 A \\/XBOOLE-0K2 B implies minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume A1: "z inHIDDENR3 A \\/XBOOLE-0K2 B"
      show "minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
      proof-
        have cases: "z inHIDDENR3 A or z inHIDDENR3 B"
          using A1 xboole_0_def_3 sorry
        have case1: "z inHIDDENR3 A implies minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
        proof(rule impI)
          assume A2: "z inHIDDENR3 A"
          have A3: "?m <=XXREAL-0R1 x"
            using xxreal_0_th_17 sorry
          have "x <=XXREAL-0R1 z"
            using A2 xxreal_2_def_2 sorry
          thus "minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
            using A3 xxreal_0_th_2 sorry
        qed
        have case2: "z inHIDDENR3 B implies minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
        proof(rule impI)
          assume A4: "z inHIDDENR3 B"
          have A5: "?m <=XXREAL-0R1 y"
            using xxreal_0_th_17 sorry
          have "y <=XXREAL-0R1 z"
            using A4 xxreal_2_def_2 sorry
          thus "minXXREAL-0K4(x,y) <=XXREAL-0R1 z"
            using A5 xxreal_0_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "minXXREAL-0K4(x,y) be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_8:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be UpperBoundXXREAL-2M1-of A holds  for y be UpperBoundXXREAL-2M1-of B holds maxXXREAL-0K5(x,y) be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be UpperBoundXXREAL-2M1-of A holds  for y be UpperBoundXXREAL-2M1-of B holds maxXXREAL-0K5(x,y) be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix x assume [ty]: "x be UpperBoundXXREAL-2M1-of A"
    fix y assume [ty]: "y be UpperBoundXXREAL-2M1-of B"
    let ?m = "maxXXREAL-0K5(x,y)"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 A \\/XBOOLE-0K2 B implies z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume A1: "z inHIDDENR3 A \\/XBOOLE-0K2 B"
      show "z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
      proof-
        have cases: "z inHIDDENR3 A or z inHIDDENR3 B"
          using A1 xboole_0_def_3 sorry
        have case1: "z inHIDDENR3 A implies z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
        proof(rule impI)
          assume A2: "z inHIDDENR3 A"
          have A3: "x <=XXREAL-0R1 ?m"
            using xxreal_0_th_25 sorry
          have "z <=XXREAL-0R1 x"
            using A2 xxreal_2_def_1 sorry
          thus "z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
            using A3 xxreal_0_th_2 sorry
        qed
        have case2: "z inHIDDENR3 B implies z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
        proof(rule impI)
          assume A4: "z inHIDDENR3 B"
          have A5: "y <=XXREAL-0R1 ?m"
            using xxreal_0_th_25 sorry
          have "z <=XXREAL-0R1 y"
            using A4 xxreal_2_def_1 sorry
          thus "z <=XXREAL-0R1 maxXXREAL-0K5(x,y)"
            using A5 xxreal_0_th_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "maxXXREAL-0K5(x,y) be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_9:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds infXXREAL-2K2 (A \\/XBOOLE-0K2 B) =HIDDENR1 minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds infXXREAL-2K2 (A \\/XBOOLE-0K2 B) =HIDDENR1 minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    let ?m = "minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
    have A1: "infXXREAL-2K2 B be LowerBoundXXREAL-2M2-of B"
      using xxreal_2_def_4 sorry
    have A2: " for x be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B holds x <=XXREAL-0R1 ?m"
    proof-
      have " for x be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B holds x <=XXREAL-0R1 minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
      proof(rule ballI)
        fix x assume [ty]: "x be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B"
        have "x be LowerBoundXXREAL-2M2-of B"
          using xxreal_2_th_5 xboole_1_th_7 sorry
        then have A3: "x <=XXREAL-0R1 infXXREAL-2K2 B"
          using xxreal_2_def_4 sorry
        have "x be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_th_5 xboole_1_th_7 sorry
        then have "x <=XXREAL-0R1 infXXREAL-2K2 A"
          using xxreal_2_def_4 sorry
        thus "x <=XXREAL-0R1 minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
          using A3 xxreal_0_th_20 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "infXXREAL-2K2 A be LowerBoundXXREAL-2M2-of A"
      using xxreal_2_def_4 sorry
    then have "?m be LowerBoundXXREAL-2M2-of A \\/XBOOLE-0K2 B"
      using A1 xxreal_2_th_7 sorry
    thus "infXXREAL-2K2 (A \\/XBOOLE-0K2 B) =HIDDENR1 minXXREAL-0K4(infXXREAL-2K2 A,infXXREAL-2K2 B)"
      using A2 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_10:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 (A \\/XBOOLE-0K2 B) =HIDDENR1 maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 (A \\/XBOOLE-0K2 B) =HIDDENR1 maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    let ?m = "maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B)"
    have A1: "supXXREAL-2K1 B be UpperBoundXXREAL-2M1-of B"
      using xxreal_2_def_3 sorry
    have A2: " for x be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B holds ?m <=XXREAL-0R1 x"
    proof-
      have " for x be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B holds maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B) <=XXREAL-0R1 x"
      proof(rule ballI)
        fix x assume [ty]: "x be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B"
        have "x be UpperBoundXXREAL-2M1-of B"
          using xxreal_2_th_6 xboole_1_th_7 sorry
        then have A3: "supXXREAL-2K1 B <=XXREAL-0R1 x"
          using xxreal_2_def_3 sorry
        have "x be UpperBoundXXREAL-2M1-of A"
          using xxreal_2_th_6 xboole_1_th_7 sorry
        then have "supXXREAL-2K1 A <=XXREAL-0R1 x"
          using xxreal_2_def_3 sorry
        thus "maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B) <=XXREAL-0R1 x"
          using A3 xxreal_0_th_28 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "supXXREAL-2K1 A be UpperBoundXXREAL-2M1-of A"
      using xxreal_2_def_3 sorry
    then have "?m be UpperBoundXXREAL-2M1-of A \\/XBOOLE-0K2 B"
      using A1 xxreal_2_th_8 sorry
    thus "supXXREAL-2K1 (A \\/XBOOLE-0K2 B) =HIDDENR1 maxXXREAL-0K5(supXXREAL-2K1 A,supXXREAL-2K1 B)"
      using A2 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_2:
"cluster finiteFINSET-1V1 also-is left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 for  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be finiteFINSET-1V1 implies it be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
  proof-
    have " for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be finiteFINSET-1V1 implies X be left-endXXREAL-2V1 & X be right-endXXREAL-2V2"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
      let ?P = "\<lambda>Lamb1. Lamb1 be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
      assume A1: "X be finiteFINSET-1V1"
      have "X c=MEMBEREDR2 ExtREALXXREAL-0K3"
        using membered_th_2 sorry
      then have A2: "X be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3)"
        using A1 finsub_1_def_5 sorry
      have A3: " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds ?P(B1) & ?P(B2) implies ?P(B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2)"
      proof-
        have " for B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds  for B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds B1 be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 implies (B2 be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 implies B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2 be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix B1 assume [ty]: "B1 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3)"
          fix B2 assume [ty]: "B2 be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3)"
          assume A4: "?P(B1)"
          have "infXXREAL-2K2 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 minXXREAL-0K4(infXXREAL-2K2 B1,infXXREAL-2K2 B2)"
            using xxreal_2_th_9 sorry
          then have A5: "infXXREAL-2K2 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 infXXREAL-2K2 B1 or infXXREAL-2K2 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 infXXREAL-2K2 B2"
            using xxreal_0_th_15 sorry
          assume A6: "?P(B2)"
          then have A7: "infXXREAL-2K2 B2 inHIDDENR3 B2"
            using xxreal_2_def_5 sorry
          have Cut393: "infXXREAL-2K2 B1 inHIDDENR3 B1"
            using A4 xxreal_2_def_5 sorry
          have "infXXREAL-2K2 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) inHIDDENR3 B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2 & B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2 be right-endXXREAL-2V2"
          proof(rule conjMI)
            show "infXXREAL-2K2 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) inHIDDENR3 B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2"
              using A7 A5 xboole_0_def_3 Cut393 sorry
            have "supXXREAL-2K1 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 maxXXREAL-0K5(supXXREAL-2K1 B1,supXXREAL-2K1 B2)"
              using xxreal_2_th_10 sorry
            then have A8: "supXXREAL-2K1 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 supXXREAL-2K1 B1 or supXXREAL-2K1 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) =HIDDENR1 supXXREAL-2K1 B2"
              using xxreal_0_th_16 sorry
            have A9: "supXXREAL-2K1 B2 inHIDDENR3 B2"
              using A6 xxreal_2_def_6 sorry
            have Cut399: "supXXREAL-2K1 B1 inHIDDENR3 B1"
              using A4 xxreal_2_def_6 sorry
            have "supXXREAL-2K1 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) inHIDDENR3 B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2"
            proof-
              show "supXXREAL-2K1 (B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2) inHIDDENR3 B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2"
                using A9 A8 xboole_0_def_3 Cut399 sorry
            qed
            thus "B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2 be right-endXXREAL-2V2"
              using xxreal_2_def_6 sorry
          qed
          thus "?P(B1 \\/SETWISEOK8\<^bsub>(ExtREALXXREAL-0K3)\<^esub> B2)"
            using xxreal_2_def_5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A10: " for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds ?P({.SETWISEOK5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x.})"
      proof-
        have " for x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds {.SETWISEOK5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x.} be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
          have "supXXREAL-2K1 {TARSKIK1 x} =HIDDENR1 x"
            using xxreal_2_lm_1 sorry
          then have A11: "supXXREAL-2K1 {TARSKIK1 x} inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          have "infXXREAL-2K2 {TARSKIK1 x} =HIDDENR1 x"
            using xxreal_2_lm_2 sorry
          then have "infXXREAL-2K2 {TARSKIK1 x} inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          thus "{.SETWISEOK5\<^bsub>(ExtREALXXREAL-0K3)\<^esub> x.} be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
            using A11 xxreal_2_def_5 xxreal_2_def_6 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for B be  non emptyXBOOLE-0V1\<bar>ElementSUBSET-1M1-of FinFINSUB-1K5 (ExtREALXXREAL-0K3) holds ?P(B)"
        using setwiseo_sch_3 A10 A3 sorry
      thus "X be left-endXXREAL-2V1 & X be right-endXXREAL-2V2"
        using A2 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_3:
"cluster note-that left-endXXREAL-2V1 for  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2 holds it be left-endXXREAL-2V1"
  proof-
    have " for X be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2 holds X be left-endXXREAL-2V1"
    proof(rule ballI)
      fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
      have A1: " ex k be NatNAT-1M1 st ?P(k)"
        using membered_th_12 sorry
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A2: "?P(k)"and A3: " for n be NatNAT-1M1 holds ?P(n) implies k <=XXREAL-0R1 n"
        using nat_1_sch_5 A1 sorry
      have A4: "k be LowerBoundXXREAL-2M2-of X"
      proof-
        have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 X implies k <=XXREAL-0R1 y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be ExtRealXXREAL-0M1"
          assume "y inHIDDENR3 X"
          thus "k <=XXREAL-0R1 y"
            using A3 sorry
        qed "sorry"
        thus "k be LowerBoundXXREAL-2M2-of X"
          using xxreal_2_def_2 sorry
      qed
      have Cut434: " for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 k"
        using A2 xxreal_2_def_2 sorry
      have "infXXREAL-2K2 X inHIDDENR3 X"
      proof-
        show "infXXREAL-2K2 X inHIDDENR3 X"
          using A2 A4 xxreal_2_def_4 Cut434 sorry
      qed
      thus "X be left-endXXREAL-2V1"
        using xxreal_2_def_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_4:
"cluster right-endXXREAL-2V2 for  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2 st it be right-endXXREAL-2V2"
  proof-
    have " ex tVar7 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar7 be right-endXXREAL-2V2"
    proof-
      show " ex tVar7 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar7 be right-endXXREAL-2V2"
      proof(rule bexI[of _ "{TARSKIK1 0NUMBERSK6 }"])
        show "{TARSKIK1 0NUMBERSK6 } be right-endXXREAL-2V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) XXREAL_2K3("minXXREAL-2K3  _ " [228]228) where
  "minXXREAL-2K3 X \<equiv> infXXREAL-2K2 X"

abbreviation(input) XXREAL_2K4("maxXXREAL-2K4  _ " [228]228) where
  "maxXXREAL-2K4 X \<equiv> supXXREAL-2K1 X"

abbreviation(input) XXREAL_2K5("minXXREAL-2K5  _ " [228]228) where
  "minXXREAL-2K5 X \<equiv> infXXREAL-2K2 X"

mtheorem xxreal_2_def_7:
  mlet "X be left-endXXREAL-2V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"redefine func minXXREAL-2K5 X \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it. it inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies it <=XXREAL-0R1 x)"
proof
(*compatibility*)
  show " for it be ExtRealXXREAL-0M1 holds it =HIDDENR1 minXXREAL-2K5 X iff it inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies it <=XXREAL-0R1 x)"
  proof-
    have " for y be ExtRealXXREAL-0M1 holds (y =HIDDENR1 minXXREAL-2K3 X implies y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies y <=XXREAL-0R1 x)) & (y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies y <=XXREAL-0R1 x) implies y =HIDDENR1 infXXREAL-2K2 X)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      show "y =HIDDENR1 minXXREAL-2K3 X implies y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies y <=XXREAL-0R1 x)"
        using xxreal_2_def_5 xxreal_2_th_3 sorry
      assume A1: "y inHIDDENR3 X"
        and A2: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies y <=XXREAL-0R1 x"
      have A3: " for x be LowerBoundXXREAL-2M2-of X holds x <=XXREAL-0R1 y"
        using A1 xxreal_2_def_2 sorry
      have "y be LowerBoundXXREAL-2M2-of X"
        using A2 xxreal_2_def_2 sorry
      thus "y =HIDDENR1 infXXREAL-2K2 X"
        using A3 xxreal_2_def_4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) XXREAL_2K6("maxXXREAL-2K6  _ " [228]228) where
  "maxXXREAL-2K6 X \<equiv> supXXREAL-2K1 X"

mtheorem xxreal_2_def_8:
  mlet "X be right-endXXREAL-2V2\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"redefine func maxXXREAL-2K6 X \<rightarrow> ExtRealXXREAL-0M1 means
  \<lambda>it. it inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 it)"
proof
(*compatibility*)
  show " for it be ExtRealXXREAL-0M1 holds it =HIDDENR1 maxXXREAL-2K6 X iff it inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 it)"
  proof-
    have " for y be ExtRealXXREAL-0M1 holds (y =HIDDENR1 maxXXREAL-2K4 X implies y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 y)) & (y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 y) implies y =HIDDENR1 supXXREAL-2K1 X)"
    proof(rule ballI,rule conjMI,rule impMI ,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      show "y =HIDDENR1 maxXXREAL-2K4 X implies y inHIDDENR3 X & ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 y)"
        using xxreal_2_def_6 xxreal_2_th_4 sorry
      assume A1: "y inHIDDENR3 X"
        and A2: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 y"
      have A3: " for x be UpperBoundXXREAL-2M1-of X holds y <=XXREAL-0R1 x"
        using A1 xxreal_2_def_1 sorry
      have "y be UpperBoundXXREAL-2M1-of X"
        using A2 xxreal_2_def_1 sorry
      thus "y =HIDDENR1 supXXREAL-2K1 X"
        using A3 xxreal_2_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_11:
" for x be ExtRealXXREAL-0M1 holds maxXXREAL-2K6 {TARSKIK1 x} =HIDDENR1 x"
  using xxreal_2_lm_1 sorry

mlemma xxreal_2_lm_3:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies y be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies y be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-0R1 y"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 {TARSKIK2 x,y } implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 {TARSKIK2 x,y }"
      thus "z <=XXREAL-0R1 y"
        using A1 tarski_def_2 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_2_lm_4:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y } holds y <=XXREAL-0R1 z"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y } holds y <=XXREAL-0R1 z"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
    have "y inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "y <=XXREAL-0R1 z"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_12:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(x,y) =HIDDENR1 maxXXREAL-2K6 {TARSKIK2 x,y }"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds maxXXREAL-0K5(x,y) =HIDDENR1 maxXXREAL-2K6 {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "x <=XXREAL-0R1 y & maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 y or y <XXREAL-0R3 x & (y <XXREAL-0R3 x implies maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 x)"
    proof-
      show "x <=XXREAL-0R1 y & maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 y or y <XXREAL-0R3 x & (y <XXREAL-0R3 x implies maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 x)"
      proof-
        have cases: "x <=XXREAL-0R1 y or y <XXREAL-0R3 x"
           sorry
        have case1: "x <=XXREAL-0R1 y implies maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 y"
        proof(rule impI)
          assume A1: "x <=XXREAL-0R1 y"
          have A2: " for z be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y } holds y <=XXREAL-0R1 z"
            using xxreal_2_lm_4 sorry
          have "y be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
            using A1 xxreal_2_lm_3 sorry
          thus "maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 y"
            using A2 xxreal_2_def_3 sorry
        qed
        have case2: "y <XXREAL-0R3 x implies maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 x"
        proof(rule impI)
          assume A3: "y <XXREAL-0R3 x"
          have A4: " for z be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y } holds x <=XXREAL-0R1 z"
            using xxreal_2_lm_4 sorry
          have "x be UpperBoundXXREAL-2M1-of {TARSKIK2 x,y }"
            using A3 xxreal_2_lm_3 sorry
          thus "maxXXREAL-2K6 {TARSKIK2 x,y } =HIDDENR1 x"
            using A4 xxreal_2_def_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "maxXXREAL-0K5(x,y) =HIDDENR1 maxXXREAL-2K6 {TARSKIK2 x,y }"
      using xxreal_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_13:
" for x be ExtRealXXREAL-0M1 holds minXXREAL-2K5 {TARSKIK1 x} =HIDDENR1 x"
  using xxreal_2_lm_2 sorry

mlemma xxreal_2_lm_5:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y <=XXREAL-0R1 x implies y be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y <=XXREAL-0R1 x implies y be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "y <=XXREAL-0R1 x"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 {TARSKIK2 x,y } implies y <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 {TARSKIK2 x,y }"
      thus "y <=XXREAL-0R1 z"
        using A1 tarski_def_2 sorry
    qed "sorry"
    thus "y be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma xxreal_2_lm_6:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y } holds z <=XXREAL-0R1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for z be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y } holds z <=XXREAL-0R1 y"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
    have "y inHIDDENR3 {TARSKIK2 x,y }"
      using tarski_def_2 sorry
    thus "z <=XXREAL-0R1 y"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_14:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 minXXREAL-0K4(x,y)"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 minXXREAL-0K4(x,y)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have "y <=XXREAL-0R1 x & minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 y or x <XXREAL-0R3 y & (x <XXREAL-0R3 y implies minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 x)"
    proof-
      show "y <=XXREAL-0R1 x & minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 y or x <XXREAL-0R3 y & (x <XXREAL-0R3 y implies minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 x)"
      proof-
        have cases: "y <=XXREAL-0R1 x or x <XXREAL-0R3 y"
           sorry
        have case1: "y <=XXREAL-0R1 x implies minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 y"
        proof(rule impI)
          assume A1: "y <=XXREAL-0R1 x"
          have A2: " for z be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y } holds z <=XXREAL-0R1 y"
            using xxreal_2_lm_6 sorry
          have "y be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
            using A1 xxreal_2_lm_5 sorry
          thus "minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 y"
            using A2 xxreal_2_def_4 sorry
        qed
        have case2: "x <XXREAL-0R3 y implies minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 x"
        proof(rule impI)
          assume A3: "x <XXREAL-0R3 y"
          have A4: " for z be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y } holds z <=XXREAL-0R1 x"
            using xxreal_2_lm_6 sorry
          have "x be LowerBoundXXREAL-2M2-of {TARSKIK2 x,y }"
            using A3 xxreal_2_lm_5 sorry
          thus "minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 x"
            using A4 xxreal_2_def_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "minXXREAL-2K5 {TARSKIK2 x,y } =HIDDENR1 minXXREAL-0K4(x,y)"
      using xxreal_0_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef xxreal_2_def_9 ("bounded-belowXXREAL-2V3" 70 ) where
"attr bounded-belowXXREAL-2V3 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>X.  ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of X)"..

mdef xxreal_2_def_10 ("bounded-aboveXXREAL-2V4" 70 ) where
"attr bounded-aboveXXREAL-2V4 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>X.  ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of X)"..

mtheorem xxreal_2_cl_5:
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>natural-memberedMEMBEREDV6 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>natural-memberedMEMBEREDV6"
  proof-
    have " ex tVar8 be setHIDDENM2 st ( not tVar8 be emptyXBOOLE-0V1 & tVar8 be finiteFINSET-1V1) & tVar8 be natural-memberedMEMBEREDV6"
    proof-
      show " ex tVar8 be setHIDDENM2 st ( not tVar8 be emptyXBOOLE-0V1 & tVar8 be finiteFINSET-1V1) & tVar8 be natural-memberedMEMBEREDV6"
      proof(rule bexI[of _ "{TARSKIK1 0NUMBERSK6 }"])
        show "( not {TARSKIK1 0NUMBERSK6 } be emptyXBOOLE-0V1 & {TARSKIK1 0NUMBERSK6 } be finiteFINSET-1V1) & {TARSKIK1 0NUMBERSK6 } be natural-memberedMEMBEREDV6"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef xxreal_2_def_11 ("real-boundedXXREAL-2V5" 70 ) where
"attr real-boundedXXREAL-2V5 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>X. X be bounded-belowXXREAL-2V3\<bar>bounded-aboveXXREAL-2V4)"..

mtheorem xxreal_2_cl_6:
"cluster real-boundedXXREAL-2V5 also-is bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be real-boundedXXREAL-2V5 implies it be bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3"
     sorry
qed "sorry"

mtheorem xxreal_2_cl_7:
"cluster bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3 also-is real-boundedXXREAL-2V5 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be bounded-aboveXXREAL-2V4\<bar>bounded-belowXXREAL-2V3 implies it be real-boundedXXREAL-2V5"
     sorry
qed "sorry"

mtheorem xxreal_2_cl_8:
"cluster finiteFINSET-1V1 also-is real-boundedXXREAL-2V5 for real-memberedMEMBEREDV3\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds it be finiteFINSET-1V1 implies it be real-boundedXXREAL-2V5"
  proof-
    have " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be finiteFINSET-1V1 implies X be bounded-belowXXREAL-2V3"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
      assume A1: "X be finiteFINSET-1V1"
      show "X be bounded-belowXXREAL-2V3"
      proof-
        have cases: "X be emptyXBOOLE-0V1 or X be  non emptyXBOOLE-0V1"
           sorry
        have case1: "X be emptyXBOOLE-0V1 implies X be real-boundedXXREAL-2V5"
        proof(rule impI)
          assume A2: "X be emptyXBOOLE-0V1"
          have "X be bounded-belowXXREAL-2V3 & X be bounded-aboveXXREAL-2V4"
          proof(rule conjMI)
            show "X be bounded-belowXXREAL-2V3"
            proof-
              have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not 0NUMBERSK6 <=XXREAL-0R1 x)"
              proof(rule ballI)
                fix x assume [ty]: "x be ExtRealXXREAL-0M1"
                show " not (x inHIDDENR3 X &  not 0NUMBERSK6 <=XXREAL-0R1 x)"
                  using A2 sorry
              qed "sorry"
              then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
                using xxreal_2_def_2 sorry
              thus "X be bounded-belowXXREAL-2V3"
                using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
            qed
            have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not x <=XXREAL-0R1 0NUMBERSK6)"
            proof(rule ballI)
              fix x assume [ty]: "x be ExtRealXXREAL-0M1"
              show " not (x inHIDDENR3 X &  not x <=XXREAL-0R1 0NUMBERSK6)"
                using A2 sorry
            qed "sorry"
            then have "0NUMBERSK6 be UpperBoundXXREAL-2M1-of X"
              using xxreal_2_def_1 sorry
            thus "X be bounded-aboveXXREAL-2V4"
              using bexI[of _ "0NUMBERSK6"] xxreal_2_def_10 sorry
          qed
          thus "X be real-boundedXXREAL-2V5"
            using xxreal_2_def_11 sorry
        qed
        have case2: "X be  non emptyXBOOLE-0V1 implies X be real-boundedXXREAL-2V5"
        proof(rule impI)
          assume "X be  non emptyXBOOLE-0V1"
          then obtain Y where 
            [ty]:"Y be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2" and YDef:"Y = X"
            using A1 sorry
          have "infXXREAL-2K2 Y inHIDDENR3 X"
            using xxreal_2_def_5 sorry
          then obtain m where 
            [ty]:"m be RealXREAL-0M1" and mDef:"m = infXXREAL-2K2 X"
             sorry
          have "X be bounded-belowXXREAL-2V3 & X be bounded-aboveXXREAL-2V4"
          proof(rule conjMI)
            show "X be bounded-belowXXREAL-2V3"
            proof-
              have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies m <=XXREAL-0R1 x"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be ExtRealXXREAL-0M1"
                assume "x inHIDDENR3 X"
                thus "m <=XXREAL-0R1 x"
                  using xxreal_2_th_3 sorry
              qed "sorry"
              then have "m be LowerBoundXXREAL-2M2-of X"
                using xxreal_2_def_2 sorry
              thus "X be bounded-belowXXREAL-2V3"
                using bexI[of _ "m"] xxreal_2_def_9 sorry
            qed
            have "supXXREAL-2K1 Y inHIDDENR3 X"
              using xxreal_2_def_6 sorry
            then obtain m where 
              [ty]:"m be RealXREAL-0M1" and mDef:"m = supXXREAL-2K1 X"
               sorry
            have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 m"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be ExtRealXXREAL-0M1"
              assume "x inHIDDENR3 X"
              thus "x <=XXREAL-0R1 m"
                using xxreal_2_th_4 sorry
            qed "sorry"
            then have "m be UpperBoundXXREAL-2M1-of X"
              using xxreal_2_def_1 sorry
            thus "X be bounded-aboveXXREAL-2V4"
              using bexI[of _ "m"] xxreal_2_def_10 sorry
          qed
          thus "X be real-boundedXXREAL-2V5"
            using xxreal_2_def_11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_9:
"cluster real-boundedXXREAL-2V5 for  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2 st it be real-boundedXXREAL-2V5"
  proof-
    have " ex tVar13 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar13 be real-boundedXXREAL-2V5"
    proof-
      show " ex tVar13 be natural-memberedMEMBEREDV6\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar13 be real-boundedXXREAL-2V5"
      proof(rule bexI[of _ "{TARSKIK1 0NUMBERSK6 }"])
        show "{TARSKIK1 0NUMBERSK6 } be real-boundedXXREAL-2V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_15:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be bounded-belowXXREAL-2V3 implies infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  not (X be bounded-belowXXREAL-2V3 &  not infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    have "( ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of X) implies infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
    proof(rule impI)
      assume Given: " ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of X"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: "r be LowerBoundXXREAL-2M2-of X"
         sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A2: "s inHIDDENR3 X"
        using membered_th_9 sorry
      have A3: "infXXREAL-2K2 X <=XXREAL-0R1 s"
        using A2 xxreal_2_th_3 sorry
      have A4: "r inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have A5: "s inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "r <=XXREAL-0R1 infXXREAL-2K2 X"
        using A1 xxreal_2_def_4 sorry
      thus "infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
        using A4 A5 A3 xxreal_0_th_45 sorry
    qed
    thus " not (X be bounded-belowXXREAL-2V3 &  not infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2)"
      using xxreal_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_16:
" for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds X be bounded-aboveXXREAL-2V4 implies supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  not (X be bounded-aboveXXREAL-2V4 &  not supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
    have "( ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of X) implies supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
    proof(rule impI)
      assume Given: " ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of X"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: "r be UpperBoundXXREAL-2M1-of X"
         sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A2: "s inHIDDENR3 X"
        using membered_th_9 sorry
      have A3: "s <=XXREAL-0R1 supXXREAL-2K1 X"
        using A2 xxreal_2_th_4 sorry
      have A4: "r inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have A5: "s inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      have "supXXREAL-2K1 X <=XXREAL-0R1 r"
        using A1 xxreal_2_def_3 sorry
      thus "supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
        using A4 A5 A3 xxreal_0_th_45 sorry
    qed
    thus " not (X be bounded-aboveXXREAL-2V4 &  not supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2)"
      using xxreal_2_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_10:
  mlet "X be bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster supXXREAL-2K1 X as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "supXXREAL-2K1 X be realXREAL-0V1"
  proof-
    have "supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
      using xxreal_2_th_16 sorry
    thus "supXXREAL-2K1 X be realXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_11:
  mlet "X be bounded-belowXXREAL-2V3\<bar> non emptyXBOOLE-0V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster infXXREAL-2K2 X as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "infXXREAL-2K2 X be realXREAL-0V1"
  proof-
    have "infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
      using xxreal_2_th_15 sorry
    thus "infXXREAL-2K2 X be realXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_12:
"cluster bounded-aboveXXREAL-2V4 also-is right-endXXREAL-2V2 for  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds it be bounded-aboveXXREAL-2V4 implies it be right-endXXREAL-2V2"
  proof-
    have " for X be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds X be bounded-aboveXXREAL-2V4 implies X be right-endXXREAL-2V2"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
      assume "X be bounded-aboveXXREAL-2V4"
      then obtain Y where 
        [ty]:"Y be bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2" and YDef:"Y = X"
         sorry
      let ?s = "supXXREAL-2K1 Y"
      have A1: "[\\INT-1K2 ?s/] <=XXREAL-0R1 ?s"
        using int_1_def_6 sorry
      have "[\\INT-1K2 ?s/] be UpperBoundXXREAL-2M1-of X"
      proof-
        have "[\\INT-1K2 supXXREAL-2K1 Y/] be UpperBoundXXREAL-2M1-of X"
        proof-
          have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 [\\INT-1K2 supXXREAL-2K1 Y/]"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ExtRealXXREAL-0M1"
            assume "x inHIDDENR3 X"
            thus "x <=XXREAL-0R1 [\\INT-1K2 supXXREAL-2K1 Y/]"
              using xxreal_2_th_4 int_1_th_54 sorry
          qed "sorry"
          thus "[\\INT-1K2 supXXREAL-2K1 Y/] be UpperBoundXXREAL-2M1-of X"
            using xxreal_2_def_1 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have "?s <=XXREAL-0R1 [\\INT-1K2 ?s/]"
        using xxreal_2_def_3 sorry
      then obtain s where 
        [ty]:"s be IntegerINT-1M1" and sDef:"s = ?s"
        using A1 xxreal_0_th_1 sorry
      have " not supXXREAL-2K1 X inHIDDENR3 X implies  False "
      proof(rule impI)
        assume A2: " not supXXREAL-2K1 X inHIDDENR3 X"
        have "s -XCMPLX-0K6 \<one>\<^sub>M be UpperBoundXXREAL-2M1-of X"
        proof-
          have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 s -XCMPLX-0K6 \<one>\<^sub>M"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ExtRealXXREAL-0M1"
            assume A3: "x inHIDDENR3 X"
            then obtain i where 
              [ty]:"i be IntegerINT-1M1" and iDef:"i = x"
               sorry
            have "i <=XXREAL-0R1 s"
              using A3 xxreal_2_th_4 sorry
            then have "i <XXREAL-0R3 s"
              using A2 A3 xxreal_0_th_1 sorry
            thus "x <=XXREAL-0R1 s -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_52 sorry
          qed "sorry"
          thus "s -XCMPLX-0K6 \<one>\<^sub>M be UpperBoundXXREAL-2M1-of X"
            using xxreal_2_def_1 sorry
        qed
        then have "s -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 s"
          using xxreal_2_def_3 sorry
        thus " False "
          using xreal_1_th_146 sorry
      qed
      thus "X be right-endXXREAL-2V2"
        using xxreal_2_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_13:
"cluster bounded-belowXXREAL-2V3 also-is left-endXXREAL-2V1 for  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds it be bounded-belowXXREAL-2V3 implies it be left-endXXREAL-2V1"
  proof-
    have " for X be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds X be bounded-belowXXREAL-2V3 implies X be left-endXXREAL-2V1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
      assume "X be bounded-belowXXREAL-2V3"
      then obtain Y where 
        [ty]:"Y be bounded-belowXXREAL-2V3\<bar> non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2" and YDef:"Y = X"
         sorry
      let ?s = "infXXREAL-2K2 Y"
      have A1: "[/INT-1K3 ?s\\] >=XXREAL-0R2 ?s"
        using int_1_def_7 sorry
      have "[/INT-1K3 ?s\\] be LowerBoundXXREAL-2M2-of X"
      proof-
        have "[/INT-1K3 infXXREAL-2K2 Y\\] be LowerBoundXXREAL-2M2-of X"
        proof-
          have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies [/INT-1K3 infXXREAL-2K2 Y\\] <=XXREAL-0R1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ExtRealXXREAL-0M1"
            assume "x inHIDDENR3 X"
            thus "[/INT-1K3 infXXREAL-2K2 Y\\] <=XXREAL-0R1 x"
              using xxreal_2_th_3 int_1_th_65 sorry
          qed "sorry"
          thus "[/INT-1K3 infXXREAL-2K2 Y\\] be LowerBoundXXREAL-2M2-of X"
            using xxreal_2_def_2 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then have "[/INT-1K3 ?s\\] <=XXREAL-0R1 ?s"
        using xxreal_2_def_4 sorry
      then obtain s where 
        [ty]:"s be IntegerINT-1M1" and sDef:"s = ?s"
        using A1 xxreal_0_th_1 sorry
      have " not infXXREAL-2K2 X inHIDDENR3 X implies  False "
      proof(rule impI)
        assume A2: " not infXXREAL-2K2 X inHIDDENR3 X"
        have "s +XCMPLX-0K2 \<one>\<^sub>M be LowerBoundXXREAL-2M2-of X"
        proof-
          have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies s +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be ExtRealXXREAL-0M1"
            assume A3: "x inHIDDENR3 X"
            then obtain i where 
              [ty]:"i be IntegerINT-1M1" and iDef:"i = x"
               sorry
            have "i >=XXREAL-0R2 s"
              using A3 xxreal_2_th_3 sorry
            then have "s <XXREAL-0R3 i"
              using A2 A3 xxreal_0_th_1 sorry
            thus "s +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 x"
              using int_1_th_7 sorry
          qed "sorry"
          thus "s +XCMPLX-0K2 \<one>\<^sub>M be LowerBoundXXREAL-2M2-of X"
            using xxreal_2_def_2 sorry
        qed
        then have "s +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 s"
          using xxreal_2_def_4 sorry
        thus " False "
          using xreal_1_th_145 sorry
      qed
      thus "X be left-endXXREAL-2V1"
        using xxreal_2_def_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_14:
"cluster note-that bounded-belowXXREAL-2V3 for natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be natural-memberedMEMBEREDV6\<bar>setHIDDENM2 holds it be bounded-belowXXREAL-2V3"
  proof-
    have " for X be natural-memberedMEMBEREDV6\<bar>setHIDDENM2 holds X be bounded-belowXXREAL-2V3"
    proof(rule ballI)
      fix X assume [ty]: "X be natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies 0NUMBERSK6 <=XXREAL-0R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume "x inHIDDENR3 X"
        thus "0NUMBERSK6 <=XXREAL-0R1 x"
           sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_15:
  mlet "X be left-endXXREAL-2V1\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster minXXREAL-2K5 X as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "minXXREAL-2K5 X be realXREAL-0V1"
  proof-
    have "minXXREAL-2K5 X inHIDDENR3 X"
      using xxreal_2_def_7 sorry
    thus "minXXREAL-2K5 X be realXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_16:
  mlet "X be left-endXXREAL-2V1\<bar>rational-memberedMEMBEREDV4\<bar>setHIDDENM2"
"cluster minXXREAL-2K5 X as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "minXXREAL-2K5 X be rationalRAT-1V1"
  proof-
    have "minXXREAL-2K5 X inHIDDENR3 X"
      using xxreal_2_def_7 sorry
    thus "minXXREAL-2K5 X be rationalRAT-1V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_17:
  mlet "X be left-endXXREAL-2V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
"cluster minXXREAL-2K5 X as-term-is integerINT-1V1"
proof
(*coherence*)
  show "minXXREAL-2K5 X be integerINT-1V1"
  proof-
    have "minXXREAL-2K5 X inHIDDENR3 X"
      using xxreal_2_def_7 sorry
    thus "minXXREAL-2K5 X be integerINT-1V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_18:
  mlet "X be left-endXXREAL-2V1\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster minXXREAL-2K5 X as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "minXXREAL-2K5 X be naturalORDINAL1V7"
  proof-
    have "minXXREAL-2K5 X inHIDDENR3 X"
      using xxreal_2_def_7 sorry
    thus "minXXREAL-2K5 X be naturalORDINAL1V7"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_19:
  mlet "X be right-endXXREAL-2V2\<bar>real-memberedMEMBEREDV3\<bar>setHIDDENM2"
"cluster maxXXREAL-2K6 X as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "maxXXREAL-2K6 X be realXREAL-0V1"
  proof-
    have "maxXXREAL-2K6 X inHIDDENR3 X"
      using xxreal_2_def_8 sorry
    thus "maxXXREAL-2K6 X be realXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_20:
  mlet "X be right-endXXREAL-2V2\<bar>rational-memberedMEMBEREDV4\<bar>setHIDDENM2"
"cluster maxXXREAL-2K6 X as-term-is rationalRAT-1V1"
proof
(*coherence*)
  show "maxXXREAL-2K6 X be rationalRAT-1V1"
  proof-
    have "maxXXREAL-2K6 X inHIDDENR3 X"
      using xxreal_2_def_8 sorry
    thus "maxXXREAL-2K6 X be rationalRAT-1V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_21:
  mlet "X be right-endXXREAL-2V2\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
"cluster maxXXREAL-2K6 X as-term-is integerINT-1V1"
proof
(*coherence*)
  show "maxXXREAL-2K6 X be integerINT-1V1"
  proof-
    have "maxXXREAL-2K6 X inHIDDENR3 X"
      using xxreal_2_def_8 sorry
    thus "maxXXREAL-2K6 X be integerINT-1V1"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_22:
  mlet "X be right-endXXREAL-2V2\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
"cluster maxXXREAL-2K6 X as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "maxXXREAL-2K6 X be naturalORDINAL1V7"
  proof-
    have "maxXXREAL-2K6 X inHIDDENR3 X"
      using xxreal_2_def_8 sorry
    thus "maxXXREAL-2K6 X be naturalORDINAL1V7"
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_23:
"cluster left-endXXREAL-2V1 also-is bounded-belowXXREAL-2V3 for real-memberedMEMBEREDV3\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds it be left-endXXREAL-2V1 implies it be bounded-belowXXREAL-2V3"
  proof-
    have " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  not (X be left-endXXREAL-2V1 &  not X be bounded-belowXXREAL-2V3)"
    proof(rule ballI)
      fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
      have "infXXREAL-2K2 X inHIDDENR3 X implies X be bounded-belowXXREAL-2V3"
      proof(rule impI)
        assume "infXXREAL-2K2 X inHIDDENR3 X"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = infXXREAL-2K2 X"
           sorry
        have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not r <=XXREAL-0R1 x)"
        proof(rule ballI)
          fix x assume [ty]: "x be ExtRealXXREAL-0M1"
          show " not (x inHIDDENR3 X &  not r <=XXREAL-0R1 x)"
            using xxreal_2_th_3 sorry
        qed "sorry"
        then have "r be LowerBoundXXREAL-2M2-of X"
          using xxreal_2_def_2 sorry
        thus "X be bounded-belowXXREAL-2V3"
          using bexI[of _ "r"] xxreal_2_def_9 sorry
      qed
      thus " not (X be left-endXXREAL-2V1 &  not X be bounded-belowXXREAL-2V3)"
        using xxreal_2_def_5 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_24:
"cluster right-endXXREAL-2V2 also-is bounded-aboveXXREAL-2V4 for real-memberedMEMBEREDV3\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds it be right-endXXREAL-2V2 implies it be bounded-aboveXXREAL-2V4"
  proof-
    have " for X be real-memberedMEMBEREDV3\<bar>setHIDDENM2 holds  not (X be right-endXXREAL-2V2 &  not X be bounded-aboveXXREAL-2V4)"
    proof(rule ballI)
      fix X assume [ty]: "X be real-memberedMEMBEREDV3\<bar>setHIDDENM2"
      have "supXXREAL-2K1 X inHIDDENR3 X implies X be bounded-aboveXXREAL-2V4"
      proof(rule impI)
        assume "supXXREAL-2K1 X inHIDDENR3 X"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = supXXREAL-2K1 X"
           sorry
        have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 X &  not x <=XXREAL-0R1 r)"
        proof(rule ballI)
          fix x assume [ty]: "x be ExtRealXXREAL-0M1"
          show " not (x inHIDDENR3 X &  not x <=XXREAL-0R1 r)"
            using xxreal_2_th_4 sorry
        qed "sorry"
        then have "r be UpperBoundXXREAL-2M1-of X"
          using xxreal_2_def_1 sorry
        thus "X be bounded-aboveXXREAL-2V4"
          using bexI[of _ "r"] xxreal_2_def_10 sorry
      qed
      thus " not (X be right-endXXREAL-2V2 &  not X be bounded-aboveXXREAL-2V4)"
        using xxreal_2_def_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_17:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .]"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .]"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies x <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
      thus "x <=XXREAL-0R1 z"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .]"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_18:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .]"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .]"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 ].XXREAL-1K3 x,y .] implies x <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 ].XXREAL-1K3 x,y .]"
      thus "x <=XXREAL-0R1 z"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .]"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_19:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .["
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .["
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K2 x,y .[ implies x <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 [.XXREAL-1K2 x,y .["
      thus "x <=XXREAL-0R1 z"
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .["
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_20:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .["
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .["
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 ].XXREAL-1K4 x,y .[ implies x <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 ].XXREAL-1K4 x,y .["
      thus "x <=XXREAL-0R1 z"
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .["
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_21:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .]"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .]"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
      thus "z <=XXREAL-0R1 y"
        using xxreal_1_th_1 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .]"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_22:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .]"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .]"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 ].XXREAL-1K3 x,y .] implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 ].XXREAL-1K3 x,y .]"
      thus "z <=XXREAL-0R1 y"
        using xxreal_1_th_2 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .]"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_23:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .["
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .["
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K2 x,y .[ implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 [.XXREAL-1K2 x,y .["
      thus "z <=XXREAL-0R1 y"
        using xxreal_1_th_3 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .["
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_24:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .["
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds y be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .["
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 ].XXREAL-1K4 x,y .[ implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 ].XXREAL-1K4 x,y .["
      thus "z <=XXREAL-0R1 y"
        using xxreal_1_th_4 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .["
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_25:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies infXXREAL-2K2 ([.XXREAL-1K1 x,y .]) =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies infXXREAL-2K2 ([.XXREAL-1K1 x,y .]) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-0R1 y"
    have A2: " for z be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .] holds z <=XXREAL-0R1 x"
    proof(rule ballI)
      fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .]"
      have "x inHIDDENR3 [.XXREAL-1K1 x,y .]"
        using A1 xxreal_1_th_1 sorry
      thus "z <=XXREAL-0R1 x"
        using xxreal_2_def_2 sorry
    qed "sorry"
    have "x be LowerBoundXXREAL-2M2-of [.XXREAL-1K1 x,y .]"
      using xxreal_2_th_17 sorry
    thus "infXXREAL-2K2 ([.XXREAL-1K1 x,y .]) =HIDDENR1 x"
      using A2 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_26:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 ([.XXREAL-1K2 x,y .[) =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 ([.XXREAL-1K2 x,y .[) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .[ holds z <=XXREAL-0R1 x"
    proof(rule ballI)
      fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .["
      have "x inHIDDENR3 [.XXREAL-1K2 x,y .["
        using A1 xxreal_1_th_3 sorry
      thus "z <=XXREAL-0R1 x"
        using xxreal_2_def_2 sorry
    qed "sorry"
    have "x be LowerBoundXXREAL-2M2-of [.XXREAL-1K2 x,y .["
      using xxreal_2_th_19 sorry
    thus "infXXREAL-2K2 ([.XXREAL-1K2 x,y .[) =HIDDENR1 x"
      using A2 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_27:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 (].XXREAL-1K3 x,y .]) =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 (].XXREAL-1K3 x,y .]) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .] holds z <=XXREAL-0R1 x"
    proof(rule ballI)
      fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .]"
      have " for r be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 r & r <XXREAL-0R3 y implies z <=XXREAL-0R1 r"
      proof(rule ballI,rule impMI ,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume A3: "x <XXREAL-0R3 r"
          and A4: "r <XXREAL-0R3 y"
        have "r inHIDDENR3 ].XXREAL-1K3 x,y .]"
          using A3 A4 xxreal_1_th_2 sorry
        thus "z <=XXREAL-0R1 r"
          using xxreal_2_def_2 sorry
      qed "sorry"
      thus "z <=XXREAL-0R1 x"
        using A1 xreal_1_th_228 sorry
    qed "sorry"
    have "x be LowerBoundXXREAL-2M2-of ].XXREAL-1K3 x,y .]"
      using xxreal_2_th_18 sorry
    thus "infXXREAL-2K2 (].XXREAL-1K3 x,y .]) =HIDDENR1 x"
      using A2 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_28:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 (].XXREAL-1K4 x,y .[) =HIDDENR1 x"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies infXXREAL-2K2 (].XXREAL-1K4 x,y .[) =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .[ holds z <=XXREAL-0R1 x"
    proof(rule ballI)
      fix z assume [ty]: "z be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .["
      have " for r be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 r & r <XXREAL-0R3 y implies z <=XXREAL-0R1 r"
        using xxreal_1_th_4 xxreal_2_def_2 sorry
      thus "z <=XXREAL-0R1 x"
        using A1 xreal_1_th_228 sorry
    qed "sorry"
    have "x be LowerBoundXXREAL-2M2-of ].XXREAL-1K4 x,y .["
      using xxreal_2_th_20 sorry
    thus "infXXREAL-2K2 (].XXREAL-1K4 x,y .[) =HIDDENR1 x"
      using A2 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_29:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies supXXREAL-2K1 ([.XXREAL-1K1 x,y .]) =HIDDENR1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies supXXREAL-2K1 ([.XXREAL-1K1 x,y .]) =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-0R1 y"
    have A2: " for z be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .] holds y <=XXREAL-0R1 z"
    proof(rule ballI)
      fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .]"
      have "y inHIDDENR3 [.XXREAL-1K1 x,y .]"
        using A1 xxreal_1_th_1 sorry
      thus "y <=XXREAL-0R1 z"
        using xxreal_2_def_1 sorry
    qed "sorry"
    have "y be UpperBoundXXREAL-2M1-of [.XXREAL-1K1 x,y .]"
      using xxreal_2_th_21 sorry
    thus "supXXREAL-2K1 ([.XXREAL-1K1 x,y .]) =HIDDENR1 y"
      using A2 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_30:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 (].XXREAL-1K3 x,y .]) =HIDDENR1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 (].XXREAL-1K3 x,y .]) =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .] holds y <=XXREAL-0R1 z"
    proof(rule ballI)
      fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .]"
      have "y inHIDDENR3 ].XXREAL-1K3 x,y .]"
        using A1 xxreal_1_th_2 sorry
      thus "y <=XXREAL-0R1 z"
        using xxreal_2_def_1 sorry
    qed "sorry"
    have "y be UpperBoundXXREAL-2M1-of ].XXREAL-1K3 x,y .]"
      using xxreal_2_th_22 sorry
    thus "supXXREAL-2K1 (].XXREAL-1K3 x,y .]) =HIDDENR1 y"
      using A2 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_31:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 ([.XXREAL-1K2 x,y .[) =HIDDENR1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 ([.XXREAL-1K2 x,y .[) =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .[ holds y <=XXREAL-0R1 z"
    proof(rule ballI)
      fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .["
      have " for r be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 r & r <XXREAL-0R3 y implies r <=XXREAL-0R1 z"
      proof(rule ballI,rule impMI ,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume A3: "x <XXREAL-0R3 r"
          and A4: "r <XXREAL-0R3 y"
        have "r inHIDDENR3 [.XXREAL-1K2 x,y .["
          using A3 A4 xxreal_1_th_3 sorry
        thus "r <=XXREAL-0R1 z"
          using xxreal_2_def_1 sorry
      qed "sorry"
      thus "y <=XXREAL-0R1 z"
        using A1 xreal_1_th_229 sorry
    qed "sorry"
    have "y be UpperBoundXXREAL-2M1-of [.XXREAL-1K2 x,y .["
      using xxreal_2_th_23 sorry
    thus "supXXREAL-2K1 ([.XXREAL-1K2 x,y .[) =HIDDENR1 y"
      using A2 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_32:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 (].XXREAL-1K4 x,y .[) =HIDDENR1 y"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies supXXREAL-2K1 (].XXREAL-1K4 x,y .[) =HIDDENR1 y"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    have A2: " for z be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .[ holds y <=XXREAL-0R1 z"
    proof(rule ballI)
      fix z assume [ty]: "z be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .["
      have " for r be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 r & r <XXREAL-0R3 y implies r <=XXREAL-0R1 z"
        using xxreal_1_th_4 xxreal_2_def_1 sorry
      thus "y <=XXREAL-0R1 z"
        using A1 xreal_1_th_229 sorry
    qed "sorry"
    have "y be UpperBoundXXREAL-2M1-of ].XXREAL-1K4 x,y .["
      using xxreal_2_th_24 sorry
    thus "supXXREAL-2K1 (].XXREAL-1K4 x,y .[) =HIDDENR1 y"
      using A2 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_33:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies [.XXREAL-1K1 x,y .] be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <=XXREAL-0R1 y implies [.XXREAL-1K1 x,y .] be left-endXXREAL-2V1 & [.XXREAL-1K1 x,y .] be right-endXXREAL-2V2"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <=XXREAL-0R1 y"
    then have "x inHIDDENR3 [.XXREAL-1K1 x,y .]"
      using xxreal_1_th_1 sorry
    then have "infXXREAL-2K2 ([.XXREAL-1K1 x,y .]) inHIDDENR3 [.XXREAL-1K1 x,y .]"
      using A1 xxreal_2_th_25 sorry
    thus "[.XXREAL-1K1 x,y .] be left-endXXREAL-2V1"
       sorry
    have Cut1105: "y inHIDDENR3 [.XXREAL-1K1 x,y .]"
      using A1 xxreal_1_th_1 sorry
    have "supXXREAL-2K1 ([.XXREAL-1K1 x,y .]) inHIDDENR3 [.XXREAL-1K1 x,y .]"
    proof-
      show "supXXREAL-2K1 ([.XXREAL-1K1 x,y .]) inHIDDENR3 [.XXREAL-1K1 x,y .]"
        using A1 xxreal_2_th_29 Cut1105 sorry
    qed
    thus "[.XXREAL-1K1 x,y .] be right-endXXREAL-2V2"
      using xxreal_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_34:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies [.XXREAL-1K2 x,y .[ be left-endXXREAL-2V1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies [.XXREAL-1K2 x,y .[ be left-endXXREAL-2V1"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    then have Cut1114: "x inHIDDENR3 [.XXREAL-1K2 x,y .["
      using xxreal_1_th_3 sorry
    have "infXXREAL-2K2 ([.XXREAL-1K2 x,y .[) inHIDDENR3 [.XXREAL-1K2 x,y .["
    proof-
      show "infXXREAL-2K2 ([.XXREAL-1K2 x,y .[) inHIDDENR3 [.XXREAL-1K2 x,y .["
        using A1 xxreal_2_th_26 Cut1114 sorry
    qed
    thus "[.XXREAL-1K2 x,y .[ be left-endXXREAL-2V1"
      using xxreal_2_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_35:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies ].XXREAL-1K3 x,y .] be right-endXXREAL-2V2"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x <XXREAL-0R3 y implies ].XXREAL-1K3 x,y .] be right-endXXREAL-2V2"
  proof(rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    assume A1: "x <XXREAL-0R3 y"
    then have Cut1123: "y inHIDDENR3 ].XXREAL-1K3 x,y .]"
      using xxreal_1_th_2 sorry
    have "supXXREAL-2K1 (].XXREAL-1K3 x,y .]) inHIDDENR3 ].XXREAL-1K3 x,y .]"
    proof-
      show "supXXREAL-2K1 (].XXREAL-1K3 x,y .]) inHIDDENR3 ].XXREAL-1K3 x,y .]"
        using A1 xxreal_2_th_30 Cut1123 sorry
    qed
    thus "].XXREAL-1K3 x,y .] be right-endXXREAL-2V2"
      using xxreal_2_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_36:
" for x be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of {}XBOOLE-0K1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x be LowerBoundXXREAL-2M2-of {}XBOOLE-0K1"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have " for y be ExtRealXXREAL-0M1 holds  not (y inHIDDENR3 {}XBOOLE-0K1 &  not x <=XXREAL-0R1 y)"
    proof(rule ballI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      show " not (y inHIDDENR3 {}XBOOLE-0K1 &  not x <=XXREAL-0R1 y)"
         sorry
    qed "sorry"
    thus "x be LowerBoundXXREAL-2M2-of {}XBOOLE-0K1"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_37:
" for x be ExtRealXXREAL-0M1 holds x be UpperBoundXXREAL-2M1-of {}XBOOLE-0K1"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x be UpperBoundXXREAL-2M1-of {}XBOOLE-0K1"
  proof(rule ballI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have " for y be ExtRealXXREAL-0M1 holds  not (y inHIDDENR3 {}XBOOLE-0K1 &  not y <=XXREAL-0R1 x)"
    proof(rule ballI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      show " not (y inHIDDENR3 {}XBOOLE-0K1 &  not y <=XXREAL-0R1 x)"
         sorry
    qed "sorry"
    thus "x be UpperBoundXXREAL-2M1-of {}XBOOLE-0K1"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_38:
"infXXREAL-2K2 ({}XBOOLE-0K1) =HIDDENR1 +inftyXXREAL-0K1"
proof-
  have A1: " for x be LowerBoundXXREAL-2M2-of {}XBOOLE-0K1 holds x <=XXREAL-0R1 +inftyXXREAL-0K1"
    using xxreal_0_th_3 sorry
  have "+inftyXXREAL-0K1 be LowerBoundXXREAL-2M2-of {}XBOOLE-0K1"
    using xxreal_2_th_36 sorry
  thus "infXXREAL-2K2 ({}XBOOLE-0K1) =HIDDENR1 +inftyXXREAL-0K1"
    using A1 xxreal_2_def_4 sorry
qed

mtheorem xxreal_2_th_39:
"supXXREAL-2K1 ({}XBOOLE-0K1) =HIDDENR1 -inftyXXREAL-0K2"
proof-
  have A1: " for x be UpperBoundXXREAL-2M1-of {}XBOOLE-0K1 holds -inftyXXREAL-0K2 <=XXREAL-0R1 x"
    using xxreal_0_th_5 sorry
  have "-inftyXXREAL-0K2 be UpperBoundXXREAL-2M1-of {}XBOOLE-0K1"
    using xxreal_2_th_37 sorry
  thus "supXXREAL-2K1 ({}XBOOLE-0K1) =HIDDENR1 -inftyXXREAL-0K2"
    using A1 xxreal_2_def_3 sorry
qed

mtheorem xxreal_2_th_40:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be  non emptyXBOOLE-0V1 iff infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X"
proof-
  have " for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (X be  non emptyXBOOLE-0V1 implies infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X) & (infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X implies  not X be emptyXBOOLE-0V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    show "X be  non emptyXBOOLE-0V1 implies infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X"
    proof(rule impI)
      assume "X be  non emptyXBOOLE-0V1"
      then obtain x where
        [ty]:"x be ExtRealXXREAL-0M1" and 
        A1: "x inHIDDENR3 X"
        using membered_th_8 sorry
      have A2: "x <=XXREAL-0R1 supXXREAL-2K1 X"
        using A1 xxreal_2_th_4 sorry
      have "infXXREAL-2K2 X <=XXREAL-0R1 x"
        using A1 xxreal_2_th_3 sorry
      thus "infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X"
        using A2 xxreal_0_th_2 sorry
    qed
    assume "infXXREAL-2K2 X <=XXREAL-0R1 supXXREAL-2K1 X"
    thus " not X be emptyXBOOLE-0V1"
      using xxreal_2_th_38 xxreal_2_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_25:
"cluster real-boundedXXREAL-2V5 also-is finiteFINSET-1V1 for integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds it be real-boundedXXREAL-2V5 implies it be finiteFINSET-1V1"
  proof-
    have " for X be integer-memberedMEMBEREDV5\<bar>setHIDDENM2 holds  not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
    proof(rule ballI)
      fix X assume [ty]: "X be integer-memberedMEMBEREDV5\<bar>setHIDDENM2"
      show " not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
      proof-
        have cases: "X be emptyXBOOLE-0V1 or X be  non emptyXBOOLE-0V1"
           sorry
        have case1: "X be emptyXBOOLE-0V1 implies  not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
        proof(rule impI)
          assume "X be emptyXBOOLE-0V1"
          thus " not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
             sorry
        qed
        have case2: "X be  non emptyXBOOLE-0V1 implies  not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
        proof(rule impI)
          assume A1: "X be  non emptyXBOOLE-0V1"
          have "X be bounded-belowXXREAL-2V3\<bar>bounded-aboveXXREAL-2V4 implies X be finiteFINSET-1V1"
          proof(rule impI)
            assume "X be bounded-belowXXREAL-2V3\<bar>bounded-aboveXXREAL-2V4"
            then obtain Z where 
              [ty]:"Z be bounded-belowXXREAL-2V3\<bar>bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>integer-memberedMEMBEREDV5\<bar>setHIDDENM2" and ZDef:"Z = X"
              using A1 sorry
            let ?m = "infXXREAL-2K2 Z"
            let ?n = "supXXREAL-2K1 Z"
            let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 X"
            let ?F = "\<lambda>Lamb1. Lamb1"
            let ?Y = "{?F(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (?m <=XXREAL-0R1 i & i <=XXREAL-0R1 ?n) & ?P(i) }"
            have A2: "X c=MEMBEREDR5 ?Y"
            proof-
              have "X c=MEMBEREDR5 {i where i be ElementSUBSET-1M1-of INTINT-1K1 : (infXXREAL-2K2 Z <=XXREAL-0R1 i & i <=XXREAL-0R1 supXXREAL-2K1 Z) & i inHIDDENR3 X }"
              proof-
                have " for i be IntegerINT-1M1 holds i inHIDDENR3 X implies i inHIDDENR3 {i where i be ElementSUBSET-1M1-of INTINT-1K1 : (infXXREAL-2K2 Z <=XXREAL-0R1 i & i <=XXREAL-0R1 supXXREAL-2K1 Z) & i inHIDDENR3 X }"
                proof(rule ballI,rule impI)
                  fix i assume [ty]: "i be IntegerINT-1M1"
                  have A3: "i inHIDDENR3 INTINT-1K1"
                    using int_1_def_2 sorry
                  assume A4: "?P(i)"
                  then have A5: "i <=XXREAL-0R1 ?n"
                    using xxreal_2_th_4 sorry
                  have "?m <=XXREAL-0R1 i"
                    using A4 xxreal_2_th_3 sorry
                  thus "i inHIDDENR3 {i where i be ElementSUBSET-1M1-of INTINT-1K1 : (infXXREAL-2K2 Z <=XXREAL-0R1 i & i <=XXREAL-0R1 supXXREAL-2K1 Z) & i inHIDDENR3 X }"
                    using A3 A4 A5 sorry
                qed "sorry"
                thus "X c=MEMBEREDR5 {?F(i) where i be ElementSUBSET-1M1-of INTINT-1K1 : (infXXREAL-2K2 Z <=XXREAL-0R1 i & i <=XXREAL-0R1 supXXREAL-2K1 Z) & ?P(i) }"
                  using membered_def_11 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have "?Y be finiteFINSET-1V1"
              using xxreal_2_sch_1 sorry
            thus "X be finiteFINSET-1V1"
              using A2 sorry
          qed
          thus " not (X be real-boundedXXREAL-2V5 &  not X be finiteFINSET-1V1)"
            using xxreal_2_def_11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_26:
"cluster note-that finiteFINSET-1V1 for bounded-aboveXXREAL-2V4\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be bounded-aboveXXREAL-2V4\<bar>natural-memberedMEMBEREDV6\<bar>setHIDDENM2 holds it be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem xxreal_2_th_41:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds +inftyXXREAL-0K1 be UpperBoundXXREAL-2M1-of X"
proof(rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 +inftyXXREAL-0K1"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 X"
    show "x <=XXREAL-0R1 +inftyXXREAL-0K1"
      using xxreal_0_th_3 sorry
  qed "sorry"
  thus "+inftyXXREAL-0K1 be UpperBoundXXREAL-2M1-of X"
    using xxreal_2_def_1 sorry
qed "sorry"

mtheorem xxreal_2_th_42:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds -inftyXXREAL-0K2 be LowerBoundXXREAL-2M2-of X"
proof(rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies -inftyXXREAL-0K2 <=XXREAL-0R1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 X"
    show "-inftyXXREAL-0K2 <=XXREAL-0R1 x"
      using xxreal_0_th_5 sorry
  qed "sorry"
  thus "-inftyXXREAL-0K2 be LowerBoundXXREAL-2M2-of X"
    using xxreal_2_def_2 sorry
qed "sorry"

mtheorem xxreal_2_th_43:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y & Y be bounded-aboveXXREAL-2V4 implies X be bounded-aboveXXREAL-2V4"
proof-
  have " for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies  not (Y be bounded-aboveXXREAL-2V4 &  not X be bounded-aboveXXREAL-2V4)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "X c=MEMBEREDR2 Y"
    have "( ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of Y) implies X be bounded-aboveXXREAL-2V4"
    proof(rule impI)
      assume Given: " ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of Y"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A2: "r be UpperBoundXXREAL-2M1-of Y"
         sorry
      have "r be UpperBoundXXREAL-2M1-of X"
      proof-
        show "r be UpperBoundXXREAL-2M1-of X"
          using A1 A2 xxreal_2_th_6 sorry
      qed
      thus "X be bounded-aboveXXREAL-2V4"
        using bexI[of _ "r"] xxreal_2_def_10 sorry
    qed
    thus " not (Y be bounded-aboveXXREAL-2V4 &  not X be bounded-aboveXXREAL-2V4)"
      using xxreal_2_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_44:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y & Y be bounded-belowXXREAL-2V3 implies X be bounded-belowXXREAL-2V3"
proof-
  have " for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies  not (Y be bounded-belowXXREAL-2V3 &  not X be bounded-belowXXREAL-2V3)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "X c=MEMBEREDR2 Y"
    have "( ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of Y) implies X be bounded-belowXXREAL-2V3"
    proof(rule impI)
      assume Given: " ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of Y"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A2: "r be LowerBoundXXREAL-2M2-of Y"
         sorry
      have "r be LowerBoundXXREAL-2M2-of X"
      proof-
        show "r be LowerBoundXXREAL-2M2-of X"
          using A1 A2 xxreal_2_th_5 sorry
      qed
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "r"] xxreal_2_def_9 sorry
    qed
    thus " not (Y be bounded-belowXXREAL-2V3 &  not X be bounded-belowXXREAL-2V3)"
      using xxreal_2_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_45:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y & Y be real-boundedXXREAL-2V5 implies X be real-boundedXXREAL-2V5"
  using xxreal_2_th_43 xxreal_2_th_44 sorry

mtheorem xxreal_2_th_46:
"REALNUMBERSK2 be  non bounded-belowXXREAL-2V3\<bar> non bounded-aboveXXREAL-2V4"
proof-
  have "REALNUMBERSK2 be  non bounded-belowXXREAL-2V3 &  not REALNUMBERSK2 be bounded-aboveXXREAL-2V4"
  proof(rule conjMI)
    show "REALNUMBERSK2 be  non bounded-belowXXREAL-2V3"
    proof-
      have " not REALNUMBERSK2 be bounded-belowXXREAL-2V3"
      proof-
        have "( ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of REALNUMBERSK2) implies  False "
        proof(rule impI)
          assume Given: " ex r be RealXREAL-0M1 st r be LowerBoundXXREAL-2M2-of REALNUMBERSK2"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A1: "r be LowerBoundXXREAL-2M2-of REALNUMBERSK2"
             sorry
          obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A2: "s <XXREAL-0R3 r"
            using xreal_1_th_2 sorry
          have "s inHIDDENR3 REALNUMBERSK2"
            using xreal_0_def_1 sorry
          thus " False "
            using A1 A2 xxreal_2_def_2 sorry
        qed
        thus " not REALNUMBERSK2 be bounded-belowXXREAL-2V3"
          using xxreal_2_def_9 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have "( ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of REALNUMBERSK2) implies  False "
    proof(rule impI)
      assume Given: " ex r be RealXREAL-0M1 st r be UpperBoundXXREAL-2M1-of REALNUMBERSK2"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A3: "r be UpperBoundXXREAL-2M1-of REALNUMBERSK2"
         sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A4: "r <XXREAL-0R3 s"
        using xreal_1_th_1 sorry
      have "s inHIDDENR3 REALNUMBERSK2"
        using xreal_0_def_1 sorry
      thus " False "
        using A3 A4 xxreal_2_def_1 sorry
    qed
    thus " not REALNUMBERSK2 be bounded-aboveXXREAL-2V4"
      using xxreal_2_def_10 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_27:
"cluster REALNUMBERSK2 as-term-is  non bounded-belowXXREAL-2V3\<bar> non bounded-aboveXXREAL-2V4"
proof
(*coherence*)
  show "REALNUMBERSK2 be  non bounded-belowXXREAL-2V3\<bar> non bounded-aboveXXREAL-2V4"
    using xxreal_2_th_46 sorry
qed "sorry"

mtheorem xxreal_2_th_47:
"{TARSKIK1 +inftyXXREAL-0K1 } be bounded-belowXXREAL-2V3"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 {TARSKIK1 +inftyXXREAL-0K1 } implies 0NUMBERSK6 <=XXREAL-0R1 x"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 {TARSKIK1 +inftyXXREAL-0K1 }"
    thus "0NUMBERSK6 <=XXREAL-0R1 x"
      using tarski_def_1 sorry
  qed "sorry"
  then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of {TARSKIK1 +inftyXXREAL-0K1 }"
    using xxreal_2_def_2 sorry
  thus "{TARSKIK1 +inftyXXREAL-0K1 } be bounded-belowXXREAL-2V3"
    using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
qed

mtheorem xxreal_2_th_48:
"{TARSKIK1 -inftyXXREAL-0K2 } be bounded-aboveXXREAL-2V4"
proof-
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 {TARSKIK1 -inftyXXREAL-0K2 } implies x <=XXREAL-0R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 {TARSKIK1 -inftyXXREAL-0K2 }"
    thus "x <=XXREAL-0R1 0NUMBERSK6"
      using tarski_def_1 sorry
  qed "sorry"
  then have "0NUMBERSK6 be UpperBoundXXREAL-2M1-of {TARSKIK1 -inftyXXREAL-0K2 }"
    using xxreal_2_def_1 sorry
  thus "{TARSKIK1 -inftyXXREAL-0K2 } be bounded-aboveXXREAL-2V4"
    using bexI[of _ "0NUMBERSK6"] xxreal_2_def_10 sorry
qed

mtheorem xxreal_2_th_49:
" for X be bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 } implies ( ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st x inTARSKIR2 X)"
proof-
  have " for X be bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 } implies  not ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not x inTARSKIR2 X)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be bounded-aboveXXREAL-2V4\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume "X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 }"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "x <>HIDDENR2 -inftyXXREAL-0K2"
      using zfmisc_1_th_35 sorry
    have 
      [ty]:"x be ExtRealXXREAL-0M1"
      using A1 sorry
    obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "r be UpperBoundXXREAL-2M1-of X"
      using xxreal_2_def_10 sorry
    have A4: "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "x <=XXREAL-0R1 r"
      using A3 A1 xxreal_2_def_1 sorry
    then have "x inHIDDENR3 REALNUMBERSK2"
      using A4 A2 xxreal_0_th_13 sorry
    thus " not ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not x inTARSKIR2 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_50:
" for X be bounded-belowXXREAL-2V3\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 } implies ( ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st x inTARSKIR2 X)"
proof-
  have " for X be bounded-belowXXREAL-2V3\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 } implies  not ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not x inTARSKIR2 X)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be bounded-belowXXREAL-2V3\<bar> non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume "X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 }"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "x inHIDDENR3 X"and A2: "x <>HIDDENR2 +inftyXXREAL-0K1"
      using zfmisc_1_th_35 sorry
    have 
      [ty]:"x be ExtRealXXREAL-0M1"
      using A1 sorry
    obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A3: "r be LowerBoundXXREAL-2M2-of X"
      using xxreal_2_def_9 sorry
    have A4: "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "r <=XXREAL-0R1 x"
      using A3 A1 xxreal_2_def_2 sorry
    then have "x inHIDDENR3 REALNUMBERSK2"
      using A4 A2 xxreal_0_th_10 sorry
    thus " not ( for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not x inTARSKIR2 X)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_51:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds -inftyXXREAL-0K2 be UpperBoundXXREAL-2M1-of X implies X c=MEMBEREDR2 {TARSKIK1 -inftyXXREAL-0K2 }"
proof(rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "-inftyXXREAL-0K2 be UpperBoundXXREAL-2M1-of X"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x inHIDDENR3 {TARSKIK1 -inftyXXREAL-0K2 }"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 X"
    then have "x =HIDDENR1 -inftyXXREAL-0K2"
      using A1 xxreal_2_def_1 xxreal_0_th_6 sorry
    thus "x inHIDDENR3 {TARSKIK1 -inftyXXREAL-0K2 }"
      using tarski_def_1 sorry
  qed "sorry"
  thus "X c=MEMBEREDR2 {TARSKIK1 -inftyXXREAL-0K2 }"
    using membered_def_8 sorry
qed "sorry"

mtheorem xxreal_2_th_52:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds +inftyXXREAL-0K1 be LowerBoundXXREAL-2M2-of X implies X c=MEMBEREDR2 {TARSKIK1 +inftyXXREAL-0K1 }"
proof(rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "+inftyXXREAL-0K1 be LowerBoundXXREAL-2M2-of X"
  have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x inHIDDENR3 {TARSKIK1 +inftyXXREAL-0K1 }"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    assume "x inHIDDENR3 X"
    then have "x =HIDDENR1 +inftyXXREAL-0K1"
      using A1 xxreal_2_def_2 xxreal_0_th_4 sorry
    thus "x inHIDDENR3 {TARSKIK1 +inftyXXREAL-0K1 }"
      using tarski_def_1 sorry
  qed "sorry"
  thus "X c=MEMBEREDR2 {TARSKIK1 +inftyXXREAL-0K1 }"
    using membered_def_8 sorry
qed "sorry"

mtheorem xxreal_2_th_53:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( ex y be UpperBoundXXREAL-2M1-of X st y <>HIDDENR2 +inftyXXREAL-0K1) implies X be bounded-aboveXXREAL-2V4"
proof(rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume Given: " ex y be UpperBoundXXREAL-2M1-of X st y <>HIDDENR2 +inftyXXREAL-0K1"
  then obtain y where
    [ty]:"y be UpperBoundXXREAL-2M1-of X" and 
    A1: "y <>HIDDENR2 +inftyXXREAL-0K1"
     sorry
  show "X be bounded-aboveXXREAL-2V4"
  proof-
    have cases: "y =HIDDENR1 -inftyXXREAL-0K2 or y <>HIDDENR2 -inftyXXREAL-0K2"
       sorry
    have case1: "y =HIDDENR1 -inftyXXREAL-0K2 implies X be bounded-aboveXXREAL-2V4"
    proof(rule impI)
      assume A2: "y =HIDDENR1 -inftyXXREAL-0K2"
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume A3: "x inHIDDENR3 X"
        have "X c=MEMBEREDR2 {TARSKIK1 -inftyXXREAL-0K2 }"
          using A2 xxreal_2_th_51 sorry
        thus "x <=XXREAL-0R1 0NUMBERSK6"
          using A3 tarski_def_1 sorry
      qed "sorry"
      then have "0NUMBERSK6 be UpperBoundXXREAL-2M1-of X"
        using xxreal_2_def_1 sorry
      thus "X be bounded-aboveXXREAL-2V4"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_10 sorry
    qed
    have case2: "y <>HIDDENR2 -inftyXXREAL-0K2 implies X be bounded-aboveXXREAL-2V4"
    proof(rule impI)
      assume "y <>HIDDENR2 -inftyXXREAL-0K2"
      then have "y inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_14 sorry
      then have 
        [ty]:"y be RealXREAL-0M1"
         sorry
      have "y be UpperBoundXXREAL-2M1-of X"
      proof-
        show "y be UpperBoundXXREAL-2M1-of X"
           sorry
      qed
      thus "X be bounded-aboveXXREAL-2V4"
        using bexI[of _ "y"] xxreal_2_def_10 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_54:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( ex y be LowerBoundXXREAL-2M2-of X st y <>HIDDENR2 -inftyXXREAL-0K2) implies X be bounded-belowXXREAL-2V3"
proof(rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume Given: " ex y be LowerBoundXXREAL-2M2-of X st y <>HIDDENR2 -inftyXXREAL-0K2"
  then obtain y where
    [ty]:"y be LowerBoundXXREAL-2M2-of X" and 
    A1: "y <>HIDDENR2 -inftyXXREAL-0K2"
     sorry
  show "X be bounded-belowXXREAL-2V3"
  proof-
    have cases: "y =HIDDENR1 +inftyXXREAL-0K1 or y <>HIDDENR2 +inftyXXREAL-0K1"
       sorry
    have case1: "y =HIDDENR1 +inftyXXREAL-0K1 implies X be bounded-belowXXREAL-2V3"
    proof(rule impI)
      assume A2: "y =HIDDENR1 +inftyXXREAL-0K1"
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies 0NUMBERSK6 <=XXREAL-0R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume A3: "x inHIDDENR3 X"
        have "X c=MEMBEREDR2 {TARSKIK1 +inftyXXREAL-0K1 }"
          using A2 xxreal_2_th_52 sorry
        thus "0NUMBERSK6 <=XXREAL-0R1 x"
          using A3 tarski_def_1 sorry
      qed "sorry"
      then have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of X"
        using xxreal_2_def_2 sorry
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
    qed
    have case2: "y <>HIDDENR2 +inftyXXREAL-0K1 implies X be bounded-belowXXREAL-2V3"
    proof(rule impI)
      assume "y <>HIDDENR2 +inftyXXREAL-0K1"
      then have "y inHIDDENR3 REALNUMBERSK2"
        using A1 xxreal_0_th_14 sorry
      then have 
        [ty]:"y be RealXREAL-0M1"
         sorry
      have "y be LowerBoundXXREAL-2M2-of X"
      proof-
        show "y be LowerBoundXXREAL-2M2-of X"
           sorry
      qed
      thus "X be bounded-belowXXREAL-2V3"
        using bexI[of _ "y"] xxreal_2_def_9 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_55:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be UpperBoundXXREAL-2M1-of X holds x inHIDDENR3 X implies x =HIDDENR1 supXXREAL-2K1 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be UpperBoundXXREAL-2M1-of X"
  assume "x inHIDDENR3 X"
  then have " for y be UpperBoundXXREAL-2M1-of X holds x <=XXREAL-0R1 y"
    using xxreal_2_def_1 sorry
  thus "x =HIDDENR1 supXXREAL-2K1 X"
    using xxreal_2_def_3 sorry
qed "sorry"

mtheorem xxreal_2_th_56:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be LowerBoundXXREAL-2M2-of X holds x inHIDDENR3 X implies x =HIDDENR1 infXXREAL-2K2 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be LowerBoundXXREAL-2M2-of X"
  assume "x inHIDDENR3 X"
  then have " for y be LowerBoundXXREAL-2M2-of X holds y <=XXREAL-0R1 x"
    using xxreal_2_def_2 sorry
  thus "x =HIDDENR1 infXXREAL-2K2 X"
    using xxreal_2_def_4 sorry
qed "sorry"

mtheorem xxreal_2_th_57:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be bounded-aboveXXREAL-2V4 & X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 } implies supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be bounded-aboveXXREAL-2V4 implies (X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 } implies supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "X be bounded-aboveXXREAL-2V4"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A2: "r be UpperBoundXXREAL-2M1-of X"
       sorry
    assume "X <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 }"
    then have A3: " ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st x inTARSKIR2 X"
      using A1 xxreal_2_th_49 sorry
    have "supXXREAL-2K1 X be UpperBoundXXREAL-2M1-of X"
      using xxreal_2_def_3 sorry
    then have A4: " not supXXREAL-2K1 X =HIDDENR1 -inftyXXREAL-0K2"
      using A3 xxreal_2_def_1 xxreal_0_th_12 sorry
    have A5: "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "supXXREAL-2K1 X <=XXREAL-0R1 r"
      using A2 xxreal_2_def_3 sorry
    thus "supXXREAL-2K1 X inHIDDENR3 REALNUMBERSK2"
      using A5 A4 xxreal_0_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_58:
" for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be bounded-belowXXREAL-2V3 & X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 } implies infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be bounded-belowXXREAL-2V3 implies (X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 } implies infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2)"
  proof(rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "X be bounded-belowXXREAL-2V3"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A2: "r be LowerBoundXXREAL-2M2-of X"
       sorry
    assume "X <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 }"
    then have A3: " ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st x inTARSKIR2 X"
      using A1 xxreal_2_th_50 sorry
    have "infXXREAL-2K2 X be LowerBoundXXREAL-2M2-of X"
      using xxreal_2_def_4 sorry
    then have A4: "infXXREAL-2K2 X <>HIDDENR2 +inftyXXREAL-0K1"
      using A3 xxreal_2_def_2 xxreal_0_th_9 sorry
    have A5: "r inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    have "r <=XXREAL-0R1 infXXREAL-2K2 X"
      using A2 xxreal_2_def_4 sorry
    thus "infXXREAL-2K2 X inHIDDENR3 REALNUMBERSK2"
      using A5 A4 xxreal_0_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_59:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies supXXREAL-2K1 X <=XXREAL-0R1 supXXREAL-2K1 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "X c=MEMBEREDR2 Y"
  have "supXXREAL-2K1 Y be UpperBoundXXREAL-2M1-of Y"
    using xxreal_2_def_3 sorry
  then have "supXXREAL-2K1 Y be UpperBoundXXREAL-2M1-of X"
    using A1 xxreal_2_th_6 sorry
  thus "supXXREAL-2K1 X <=XXREAL-0R1 supXXREAL-2K1 Y"
    using xxreal_2_def_3 sorry
qed "sorry"

mtheorem xxreal_2_th_60:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X c=MEMBEREDR2 Y implies infXXREAL-2K2 Y <=XXREAL-0R1 infXXREAL-2K2 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: "X c=MEMBEREDR2 Y"
  have "infXXREAL-2K2 Y be LowerBoundXXREAL-2M2-of Y"
    using xxreal_2_def_4 sorry
  then have "infXXREAL-2K2 Y be LowerBoundXXREAL-2M2-of X"
    using A1 xxreal_2_th_5 sorry
  thus "infXXREAL-2K2 Y <=XXREAL-0R1 infXXREAL-2K2 X"
    using xxreal_2_def_4 sorry
qed "sorry"

mtheorem xxreal_2_th_61:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be ExtRealXXREAL-0M1 holds ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 X & x <=XXREAL-0R1 y) implies x <=XXREAL-0R1 supXXREAL-2K1 X"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be ExtRealXXREAL-0M1"
  assume Given: " ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 X & x <=XXREAL-0R1 y"
  then obtain y where
    [ty]:"y be ExtRealXXREAL-0M1" and 
    A1: "y inHIDDENR3 X"and A2: "x <=XXREAL-0R1 y"
     sorry
  have "y <=XXREAL-0R1 supXXREAL-2K1 X"
    using A1 xxreal_2_th_4 sorry
  thus "x <=XXREAL-0R1 supXXREAL-2K1 X"
    using A2 xxreal_0_th_2 sorry
qed "sorry"

mtheorem xxreal_2_th_62:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be ExtRealXXREAL-0M1 holds ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 X & y <=XXREAL-0R1 x) implies infXXREAL-2K2 X <=XXREAL-0R1 x"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be ExtRealXXREAL-0M1"
  assume Given: " ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 X & y <=XXREAL-0R1 x"
  then obtain y where
    [ty]:"y be ExtRealXXREAL-0M1" and 
    A1: "y inHIDDENR3 X"and A2: "y <=XXREAL-0R1 x"
     sorry
  have "infXXREAL-2K2 X <=XXREAL-0R1 y"
    using A1 xxreal_2_th_3 sorry
  thus "infXXREAL-2K2 X <=XXREAL-0R1 x"
    using A2 xxreal_0_th_2 sorry
qed "sorry"

mtheorem xxreal_2_th_63:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 Y & x <=XXREAL-0R1 y)) implies supXXREAL-2K1 X <=XXREAL-0R1 supXXREAL-2K1 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 Y & x <=XXREAL-0R1 y)"
  have "supXXREAL-2K1 Y be UpperBoundXXREAL-2M1-of X"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 X implies x <=XXREAL-0R1 supXXREAL-2K1 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 X"
      then obtain y where
        [ty]:"y be ExtRealXXREAL-0M1" and 
        A2: "y inHIDDENR3 Y"and A3: "x <=XXREAL-0R1 y"
        using A1 sorry
      have "y <=XXREAL-0R1 supXXREAL-2K1 Y"
        using A2 xxreal_2_th_4 sorry
      thus "x <=XXREAL-0R1 supXXREAL-2K1 Y"
        using A3 xxreal_0_th_2 sorry
    qed "sorry"
    thus "supXXREAL-2K1 Y be UpperBoundXXREAL-2M1-of X"
      using xxreal_2_def_1 sorry
  qed
  thus "supXXREAL-2K1 X <=XXREAL-0R1 supXXREAL-2K1 Y"
    using xxreal_2_def_3 sorry
qed "sorry"

mtheorem xxreal_2_th_64:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 Y implies ( ex x be ExtRealXXREAL-0M1 st x inHIDDENR3 X & x <=XXREAL-0R1 y)) implies infXXREAL-2K2 X <=XXREAL-0R1 infXXREAL-2K2 Y"
proof(rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  assume A1: " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 Y implies ( ex x be ExtRealXXREAL-0M1 st x inHIDDENR3 X & x <=XXREAL-0R1 y)"
  have "infXXREAL-2K2 X be LowerBoundXXREAL-2M2-of Y"
  proof-
    have " for y be ExtRealXXREAL-0M1 holds y inHIDDENR3 Y implies infXXREAL-2K2 X <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "y inHIDDENR3 Y"
      then obtain x where
        [ty]:"x be ExtRealXXREAL-0M1" and 
        A2: "x inHIDDENR3 X"and A3: "x <=XXREAL-0R1 y"
        using A1 sorry
      have "infXXREAL-2K2 X <=XXREAL-0R1 x"
        using A2 xxreal_2_th_3 sorry
      thus "infXXREAL-2K2 X <=XXREAL-0R1 y"
        using A3 xxreal_0_th_2 sorry
    qed "sorry"
    thus "infXXREAL-2K2 X be LowerBoundXXREAL-2M2-of Y"
      using xxreal_2_def_2 sorry
  qed
  thus "infXXREAL-2K2 X <=XXREAL-0R1 infXXREAL-2K2 Y"
    using xxreal_2_def_4 sorry
qed "sorry"

mtheorem xxreal_2_th_65:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be UpperBoundXXREAL-2M1-of X holds  for y be UpperBoundXXREAL-2M1-of Y holds minXXREAL-0K4(x,y) be UpperBoundXXREAL-2M1-of X /\\XBOOLE-0K3 Y"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be UpperBoundXXREAL-2M1-of X"
  fix y assume [ty]: "y be UpperBoundXXREAL-2M1-of Y"
  have " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 X /\\XBOOLE-0K3 Y implies a <=XXREAL-0R1 minXXREAL-0K4(x,y)"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 X /\\XBOOLE-0K3 Y"
    then have "a inHIDDENR3 Y"
      using xboole_0_def_4 sorry
    then have A2: "a <=XXREAL-0R1 y"
      using xxreal_2_def_1 sorry
    have "a inHIDDENR3 X"
      using A1 xboole_0_def_4 sorry
    then have "a <=XXREAL-0R1 x"
      using xxreal_2_def_1 sorry
    thus "a <=XXREAL-0R1 minXXREAL-0K4(x,y)"
      using A2 xxreal_0_th_20 sorry
  qed "sorry"
  thus "minXXREAL-0K4(x,y) be UpperBoundXXREAL-2M1-of X /\\XBOOLE-0K3 Y"
    using xxreal_2_def_1 sorry
qed "sorry"

mtheorem xxreal_2_th_66:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for x be LowerBoundXXREAL-2M2-of X holds  for y be LowerBoundXXREAL-2M2-of Y holds maxXXREAL-0K5(x,y) be LowerBoundXXREAL-2M2-of X /\\XBOOLE-0K3 Y"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix x assume [ty]: "x be LowerBoundXXREAL-2M2-of X"
  fix y assume [ty]: "y be LowerBoundXXREAL-2M2-of Y"
  have " for a be ExtRealXXREAL-0M1 holds a inHIDDENR3 X /\\XBOOLE-0K3 Y implies maxXXREAL-0K5(x,y) <=XXREAL-0R1 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be ExtRealXXREAL-0M1"
    assume A1: "a inHIDDENR3 X /\\XBOOLE-0K3 Y"
    then have "a inHIDDENR3 Y"
      using xboole_0_def_4 sorry
    then have A2: "y <=XXREAL-0R1 a"
      using xxreal_2_def_2 sorry
    have "a inHIDDENR3 X"
      using A1 xboole_0_def_4 sorry
    then have "x <=XXREAL-0R1 a"
      using xxreal_2_def_2 sorry
    thus "maxXXREAL-0K5(x,y) <=XXREAL-0R1 a"
      using A2 xxreal_0_th_28 sorry
  qed "sorry"
  thus "maxXXREAL-0K5(x,y) be LowerBoundXXREAL-2M2-of X /\\XBOOLE-0K3 Y"
    using xxreal_2_def_2 sorry
qed "sorry"

mtheorem xxreal_2_th_67:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 (X /\\XBOOLE-0K3 Y) <=XXREAL-0R1 minXXREAL-0K4(supXXREAL-2K1 X,supXXREAL-2K1 Y)"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have A1: "supXXREAL-2K1 Y be UpperBoundXXREAL-2M1-of Y"
    using xxreal_2_def_3 sorry
  have "supXXREAL-2K1 X be UpperBoundXXREAL-2M1-of X"
    using xxreal_2_def_3 sorry
  then have "minXXREAL-0K4(supXXREAL-2K1 X,supXXREAL-2K1 Y) be UpperBoundXXREAL-2M1-of X /\\XBOOLE-0K3 Y"
    using A1 xxreal_2_th_65 sorry
  thus "supXXREAL-2K1 (X /\\XBOOLE-0K3 Y) <=XXREAL-0R1 minXXREAL-0K4(supXXREAL-2K1 X,supXXREAL-2K1 Y)"
    using xxreal_2_def_3 sorry
qed "sorry"

mtheorem xxreal_2_th_68:
" for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds maxXXREAL-0K5(infXXREAL-2K2 X,infXXREAL-2K2 Y) <=XXREAL-0R1 infXXREAL-2K2 (X /\\XBOOLE-0K3 Y)"
proof(rule ballI,rule ballI)
  fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  fix Y assume [ty]: "Y be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have A1: "infXXREAL-2K2 Y be LowerBoundXXREAL-2M2-of Y"
    using xxreal_2_def_4 sorry
  have "infXXREAL-2K2 X be LowerBoundXXREAL-2M2-of X"
    using xxreal_2_def_4 sorry
  then have "maxXXREAL-0K5(infXXREAL-2K2 X,infXXREAL-2K2 Y) be LowerBoundXXREAL-2M2-of X /\\XBOOLE-0K3 Y"
    using A1 xxreal_2_th_66 sorry
  thus "maxXXREAL-0K5(infXXREAL-2K2 X,infXXREAL-2K2 Y) <=XXREAL-0R1 infXXREAL-2K2 (X /\\XBOOLE-0K3 Y)"
    using xxreal_2_def_4 sorry
qed "sorry"

mtheorem xxreal_2_cl_28:
"cluster real-boundedXXREAL-2V5 also-is real-memberedMEMBEREDV3 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be real-boundedXXREAL-2V5 implies it be real-memberedMEMBEREDV3"
  proof-
    have " for X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds X be real-boundedXXREAL-2V5 implies X be real-memberedMEMBEREDV3"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
      assume A1: "X be real-boundedXXREAL-2V5"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be realXREAL-0V1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 X"
        then have 
          [ty]:"X be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
           sorry
        obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A3: "s be UpperBoundXXREAL-2M1-of X"
          using A1 xxreal_2_def_10 sorry
        have 
          [ty]:"x be ExtRealXXREAL-0M1"
          using A2 sorry
        have A4: "s inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have A5: "x <=XXREAL-0R1 s"
          using A2 A3 xxreal_2_def_1 sorry
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A6: "r be LowerBoundXXREAL-2M2-of X"
          using A1 xxreal_2_def_9 sorry
        have A7: "r inHIDDENR3 REALNUMBERSK2"
          using xreal_0_def_1 sorry
        have "r <=XXREAL-0R1 x"
          using A2 A6 xxreal_2_def_2 sorry
        then have "x inHIDDENR3 REALNUMBERSK2"
          using A5 A7 A4 xxreal_0_th_45 sorry
        thus "x be realXREAL-0V1"
           sorry
      qed "sorry"
      thus "X be real-memberedMEMBEREDV3"
        using membered_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_69:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A c=MEMBEREDR2 [.XXREAL-1K1 infXXREAL-2K2 A,supXXREAL-2K1 A .]"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A c=MEMBEREDR2 [.XXREAL-1K1 infXXREAL-2K2 A,supXXREAL-2K1 A .]"
  proof(rule ballI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 A implies x inHIDDENR3 [.XXREAL-1K1 infXXREAL-2K2 A,supXXREAL-2K1 A .]"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      assume A1: "x inHIDDENR3 A"
      then have A2: "x <=XXREAL-0R1 supXXREAL-2K1 A"
        using xxreal_2_th_4 sorry
      have "infXXREAL-2K2 A <=XXREAL-0R1 x"
        using A1 xxreal_2_th_3 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 infXXREAL-2K2 A,supXXREAL-2K1 A .]"
        using A2 xxreal_1_th_1 sorry
    qed "sorry"
    thus "A c=MEMBEREDR2 [.XXREAL-1K1 infXXREAL-2K2 A,supXXREAL-2K1 A .]"
      using membered_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_70:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 A implies A =MEMBEREDR8 {TARSKIK1 infXXREAL-2K2 A }"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 A implies A =MEMBEREDR8 {TARSKIK1 infXXREAL-2K2 A }"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 A"
    then have "A c=MEMBEREDR2 [.XXREAL-1K1 infXXREAL-2K2 A,infXXREAL-2K2 A .]"
      using xxreal_2_th_69 sorry
    then have A2: "A c=MEMBEREDR2 {TARSKIK1 infXXREAL-2K2 A }"
      using xxreal_1_th_17 sorry
    have "A <>HIDDENR2 {}XBOOLE-0K1"
      using A1 xxreal_2_th_38 xxreal_2_th_39 sorry
    thus "A =MEMBEREDR8 {TARSKIK1 infXXREAL-2K2 A }"
      using A2 zfmisc_1_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_71:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds x <=XXREAL-0R1 y & x be UpperBoundXXREAL-2M1-of A implies y be UpperBoundXXREAL-2M1-of A"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds x <=XXREAL-0R1 y & x be UpperBoundXXREAL-2M1-of A implies y be UpperBoundXXREAL-2M1-of A"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "x <=XXREAL-0R1 y"
      and A2: "x be UpperBoundXXREAL-2M1-of A"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 A implies z <=XXREAL-0R1 y"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 A"
      then have "z <=XXREAL-0R1 x"
        using A2 xxreal_2_def_1 sorry
      thus "z <=XXREAL-0R1 y"
        using A1 xxreal_0_th_2 sorry
    qed "sorry"
    thus "y be UpperBoundXXREAL-2M1-of A"
      using xxreal_2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_72:
" for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds y <=XXREAL-0R1 x & x be LowerBoundXXREAL-2M2-of A implies y be LowerBoundXXREAL-2M2-of A"
proof-
  have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds y <=XXREAL-0R1 x & x be LowerBoundXXREAL-2M2-of A implies y be LowerBoundXXREAL-2M2-of A"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "y <=XXREAL-0R1 x"
      and A2: "x be LowerBoundXXREAL-2M2-of A"
    have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 A implies y <=XXREAL-0R1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be ExtRealXXREAL-0M1"
      assume "z inHIDDENR3 A"
      then have "x <=XXREAL-0R1 z"
        using A2 xxreal_2_def_2 sorry
      thus "y <=XXREAL-0R1 z"
        using A1 xxreal_0_th_2 sorry
    qed "sorry"
    thus "y be LowerBoundXXREAL-2M2-of A"
      using xxreal_2_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_73:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be bounded-aboveXXREAL-2V4 iff supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (A be bounded-aboveXXREAL-2V4 implies supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1) & (supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1 implies A be bounded-aboveXXREAL-2V4)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    show "A be bounded-aboveXXREAL-2V4 implies supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
    proof(rule impI)
      assume A1: "A be bounded-aboveXXREAL-2V4"
      show "supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
      proof-
        have cases: "(A =MEMBEREDR8 {}XBOOLE-0K1 or A =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }) or supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2"
          using A1 xxreal_2_th_57 sorry
        have case1: "A =MEMBEREDR8 {}XBOOLE-0K1 implies supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
        proof(rule impI)
          assume "A =MEMBEREDR8 {}XBOOLE-0K1"
          thus "supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
            using xxreal_2_th_39 sorry
        qed
        have case2: "A =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 } implies supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
        proof(rule impI)
          assume "A =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
          thus "supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
            using xxreal_2_lm_1 sorry
        qed
        have case3: "supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2 implies supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
        proof(rule impI)
          assume "supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2"
          thus "supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    assume A2: "supXXREAL-2K1 A <>HIDDENR2 +inftyXXREAL-0K1"
    show "A be bounded-aboveXXREAL-2V4"
    proof-
      have cases: "supXXREAL-2K1 A =HIDDENR1 -inftyXXREAL-0K2 or supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2"
        using A2 xxreal_0_th_14 sorry
      have case1: "supXXREAL-2K1 A =HIDDENR1 -inftyXXREAL-0K2 implies A be bounded-aboveXXREAL-2V4"
      proof(rule impI)
        assume A3: "supXXREAL-2K1 A =HIDDENR1 -inftyXXREAL-0K2"
        have Cut1719: "-inftyXXREAL-0K2 be UpperBoundXXREAL-2M1-of A"
          using A3 xxreal_2_def_3 sorry
        have "0NUMBERSK6 be UpperBoundXXREAL-2M1-of A"
        proof-
          show "0NUMBERSK6 be UpperBoundXXREAL-2M1-of A"
            using xxreal_2_th_71 Cut1719 sorry
        qed
        thus "A be bounded-aboveXXREAL-2V4"
          using bexI[of _ "0NUMBERSK6"] xxreal_2_def_10 sorry
      qed
      have case2: "supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2 implies A be bounded-aboveXXREAL-2V4"
      proof(rule impI)
        assume "supXXREAL-2K1 A inHIDDENR3 REALNUMBERSK2"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = supXXREAL-2K1 A"
           sorry
        have "r be UpperBoundXXREAL-2M1-of A"
        proof-
          show "r be UpperBoundXXREAL-2M1-of A"
            using xxreal_2_def_3 sorry
        qed
        thus "A be bounded-aboveXXREAL-2V4"
          using bexI[of _ "r"] xxreal_2_def_10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_74:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be bounded-belowXXREAL-2V3 iff infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (A be bounded-belowXXREAL-2V3 implies infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2) & (infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2 implies A be bounded-belowXXREAL-2V3)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    show "A be bounded-belowXXREAL-2V3 implies infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
    proof(rule impI)
      assume A1: "A be bounded-belowXXREAL-2V3"
      show "infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
      proof-
        have cases: "(A =MEMBEREDR8 {}XBOOLE-0K1 or A =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }) or infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2"
          using A1 xxreal_2_th_58 sorry
        have case1: "A =MEMBEREDR8 {}XBOOLE-0K1 implies infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
        proof(rule impI)
          assume "A =MEMBEREDR8 {}XBOOLE-0K1"
          thus "infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
            using xxreal_2_th_38 sorry
        qed
        have case2: "A =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 } implies infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
        proof(rule impI)
          assume "A =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
          thus "infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
            using xxreal_2_lm_2 sorry
        qed
        have case3: "infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2 implies infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
        proof(rule impI)
          assume "infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2"
          thus "infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    assume A2: "infXXREAL-2K2 A <>HIDDENR2 -inftyXXREAL-0K2"
    show "A be bounded-belowXXREAL-2V3"
    proof-
      have cases: "infXXREAL-2K2 A =HIDDENR1 +inftyXXREAL-0K1 or infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2"
        using A2 xxreal_0_th_14 sorry
      have case1: "infXXREAL-2K2 A =HIDDENR1 +inftyXXREAL-0K1 implies A be bounded-belowXXREAL-2V3"
      proof(rule impI)
        assume A3: "infXXREAL-2K2 A =HIDDENR1 +inftyXXREAL-0K1"
        have Cut1756: "+inftyXXREAL-0K1 be LowerBoundXXREAL-2M2-of A"
          using A3 xxreal_2_def_4 sorry
        have "0NUMBERSK6 be LowerBoundXXREAL-2M2-of A"
        proof-
          show "0NUMBERSK6 be LowerBoundXXREAL-2M2-of A"
            using xxreal_2_th_72 Cut1756 sorry
        qed
        thus "A be bounded-belowXXREAL-2V3"
          using bexI[of _ "0NUMBERSK6"] xxreal_2_def_9 sorry
      qed
      have case2: "infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2 implies A be bounded-belowXXREAL-2V3"
      proof(rule impI)
        assume "infXXREAL-2K2 A inHIDDENR3 REALNUMBERSK2"
        then obtain r where 
          [ty]:"r be RealXREAL-0M1" and rDef:"r = infXXREAL-2K2 A"
           sorry
        have "r be LowerBoundXXREAL-2M2-of A"
        proof-
          show "r be LowerBoundXXREAL-2M2-of A"
            using xxreal_2_def_4 sorry
        qed
        thus "A be bounded-belowXXREAL-2V3"
          using bexI[of _ "r"] xxreal_2_def_9 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef xxreal_2_def_12 ("intervalXXREAL-2V6" 70 ) where
"attr intervalXXREAL-2V6 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 means
  (\<lambda>A.  for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r inHIDDENR3 A & s inHIDDENR3 A implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 A)"..

mtheorem xxreal_2_cl_29:
"cluster ExtREALXXREAL-0K3 as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "ExtREALXXREAL-0K3 be intervalXXREAL-2V6"
    using membered_th_2 sorry
qed "sorry"

mtheorem xxreal_2_cl_30:
"cluster emptyXBOOLE-0V1 also-is intervalXXREAL-2V6 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem xxreal_2_cl_31:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K1 r,s .] as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "[.XXREAL-1K1 r,s .] be intervalXXREAL-2V6"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K1 r,s .] implies (y inHIDDENR3 [.XXREAL-1K1 r,s .] implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 [.XXREAL-1K1 r,s .])"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A1: "r <=XXREAL-0R1 x"
        using xxreal_1_th_1 sorry
      assume "y inHIDDENR3 [.XXREAL-1K1 r,s .]"
      then have A2: "y <=XXREAL-0R1 s"
        using xxreal_1_th_1 sorry
      have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies z inHIDDENR3 [.XXREAL-1K1 r,s .]"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A3: "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "x <=XXREAL-0R1 z"
          using xxreal_1_th_1 sorry
        then have A4: "r <=XXREAL-0R1 z"
          using A1 xxreal_0_th_2 sorry
        have "z <=XXREAL-0R1 y"
          using A3 xxreal_1_th_1 sorry
        then have "z <=XXREAL-0R1 s"
          using A2 xxreal_0_th_2 sorry
        thus "z inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A4 xxreal_1_th_1 sorry
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 [.XXREAL-1K1 r,s .]"
        using membered_def_8 sorry
    qed "sorry"
    thus "[.XXREAL-1K1 r,s .] be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_32:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K3 r,s .] as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "].XXREAL-1K3 r,s .] be intervalXXREAL-2V6"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K3 r,s .] implies (y inHIDDENR3 ].XXREAL-1K3 r,s .] implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 ].XXREAL-1K3 r,s .])"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A5: "r <XXREAL-0R3 x"
        using xxreal_1_th_2 sorry
      assume "y inHIDDENR3 ].XXREAL-1K3 r,s .]"
      then have A6: "y <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies z inHIDDENR3 ].XXREAL-1K3 r,s .]"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A7: "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "x <=XXREAL-0R1 z"
          using xxreal_1_th_1 sorry
        then have A8: "r <XXREAL-0R3 z"
          using A5 xxreal_0_th_2 sorry
        have "z <=XXREAL-0R1 y"
          using A7 xxreal_1_th_1 sorry
        then have "z <=XXREAL-0R1 s"
          using A6 xxreal_0_th_2 sorry
        thus "z inHIDDENR3 ].XXREAL-1K3 r,s .]"
          using A8 xxreal_1_th_2 sorry
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 ].XXREAL-1K3 r,s .]"
        using membered_def_8 sorry
    qed "sorry"
    thus "].XXREAL-1K3 r,s .] be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_33:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 r,s .[ as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "[.XXREAL-1K2 r,s .[ be intervalXXREAL-2V6"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 [.XXREAL-1K2 r,s .[ implies (y inHIDDENR3 [.XXREAL-1K2 r,s .[ implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 [.XXREAL-1K2 r,s .[)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A9: "r <=XXREAL-0R1 x"
        using xxreal_1_th_3 sorry
      assume "y inHIDDENR3 [.XXREAL-1K2 r,s .["
      then have A10: "y <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies z inHIDDENR3 [.XXREAL-1K2 r,s .["
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A11: "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "x <=XXREAL-0R1 z"
          using xxreal_1_th_1 sorry
        then have A12: "r <=XXREAL-0R1 z"
          using A9 xxreal_0_th_2 sorry
        have "z <=XXREAL-0R1 y"
          using A11 xxreal_1_th_1 sorry
        then have "z <XXREAL-0R3 s"
          using A10 xxreal_0_th_2 sorry
        thus "z inHIDDENR3 [.XXREAL-1K2 r,s .["
          using A12 xxreal_1_th_3 sorry
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 [.XXREAL-1K2 r,s .["
        using membered_def_8 sorry
    qed "sorry"
    thus "[.XXREAL-1K2 r,s .[ be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_34:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 r,s .[ as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "].XXREAL-1K4 r,s .[ be intervalXXREAL-2V6"
  proof-
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 ].XXREAL-1K4 r,s .[ implies (y inHIDDENR3 ].XXREAL-1K4 r,s .[ implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 ].XXREAL-1K4 r,s .[)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume "x inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A13: "r <XXREAL-0R3 x"
        using xxreal_1_th_4 sorry
      assume "y inHIDDENR3 ].XXREAL-1K4 r,s .["
      then have A14: "y <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have " for z be ExtRealXXREAL-0M1 holds z inHIDDENR3 [.XXREAL-1K1 x,y .] implies z inHIDDENR3 ].XXREAL-1K4 r,s .["
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be ExtRealXXREAL-0M1"
        assume A15: "z inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "x <=XXREAL-0R1 z"
          using xxreal_1_th_1 sorry
        then have A16: "r <XXREAL-0R3 z"
          using A13 xxreal_0_th_2 sorry
        have "z <=XXREAL-0R1 y"
          using A15 xxreal_1_th_1 sorry
        then have "z <XXREAL-0R3 s"
          using A14 xxreal_0_th_2 sorry
        thus "z inHIDDENR3 ].XXREAL-1K4 r,s .["
          using A16 xxreal_1_th_4 sorry
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 ].XXREAL-1K4 r,s .["
        using membered_def_8 sorry
    qed "sorry"
    thus "].XXREAL-1K4 r,s .[ be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_35:
"cluster REALNUMBERSK2 as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "REALNUMBERSK2 be intervalXXREAL-2V6"
    using xxreal_1_th_224 sorry
qed "sorry"

mtheorem xxreal_2_cl_36:
"cluster intervalXXREAL-2V6 for  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be  non emptyXBOOLE-0V1\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st it be intervalXXREAL-2V6"
  proof-
    have " ex tVar29 be ext-real-memberedMEMBEREDV2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar29 be intervalXXREAL-2V6"
    proof-
      show " ex tVar29 be ext-real-memberedMEMBEREDV2\<bar> non emptyXBOOLE-0V1\<bar>setHIDDENM2 st tVar29 be intervalXXREAL-2V6"
      proof(rule bexI[of _ "REALNUMBERSK2"])
        show "REALNUMBERSK2 be intervalXXREAL-2V6"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_37:
  mlet "A be intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2", "B be intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"cluster A /\\XBOOLE-0K3 B as-term-is intervalXXREAL-2V6"
proof
(*coherence*)
  show "A /\\XBOOLE-0K3 B be intervalXXREAL-2V6"
  proof-
    have " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r inHIDDENR3 A /\\XBOOLE-0K3 B & s inHIDDENR3 A /\\XBOOLE-0K3 B implies [.XXREAL-1K1 r,s .] c=MEMBEREDR2 A /\\XBOOLE-0K3 B"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix r assume [ty]: "r be ExtRealXXREAL-0M1"
      fix s assume [ty]: "s be ExtRealXXREAL-0M1"
      assume A1: "r inHIDDENR3 A /\\XBOOLE-0K3 B"
        and A2: "s inHIDDENR3 A /\\XBOOLE-0K3 B"
      have A3: "s inHIDDENR3 B"
        using A2 xboole_0_def_4 sorry
      have "r inHIDDENR3 B"
        using A1 xboole_0_def_4 sorry
      then have A4: "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 B"
        using A3 xxreal_2_def_12 sorry
      have A5: "s inHIDDENR3 A"
        using A2 xboole_0_def_4 sorry
      have "r inHIDDENR3 A"
        using A1 xboole_0_def_4 sorry
      then have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 A"
        using A5 xxreal_2_def_12 sorry
      thus "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 A /\\XBOOLE-0K3 B"
        using A4 xboole_1_th_19 sorry
    qed "sorry"
    thus "A /\\XBOOLE-0K3 B be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed
qed "sorry"

reserve A, B for "ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
mtheorem xxreal_2_cl_38:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K3 r,s .] as-term-is  non left-endXXREAL-2V1"
proof
(*coherence*)
  show "].XXREAL-1K3 r,s .] be  non left-endXXREAL-2V1"
  proof-
    have "].XXREAL-1K3 r,s .] be left-endXXREAL-2V1 implies  False "
    proof(rule impI)
      assume "].XXREAL-1K3 r,s .] be left-endXXREAL-2V1"
      then have A1: "infXXREAL-2K2 (].XXREAL-1K3 r,s .]) inHIDDENR3 ].XXREAL-1K3 r,s .]"
         sorry
      then have A2: "infXXREAL-2K2 (].XXREAL-1K3 r,s .]) <=XXREAL-0R1 s"
        using xxreal_1_th_2 sorry
      have "r <XXREAL-0R3 infXXREAL-2K2 (].XXREAL-1K3 r,s .])"
        using A1 xxreal_1_th_2 sorry
      then have "r <XXREAL-0R3 s"
        using A2 xxreal_0_th_2 sorry
      then have "r =HIDDENR1 infXXREAL-2K2 (].XXREAL-1K3 r,s .])"
        using xxreal_2_th_27 sorry
      thus " False "
        using A1 xxreal_1_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_39:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster [.XXREAL-1K2 r,s .[ as-term-is  non right-endXXREAL-2V2"
proof
(*coherence*)
  show "[.XXREAL-1K2 r,s .[ be  non right-endXXREAL-2V2"
  proof-
    have "[.XXREAL-1K2 r,s .[ be right-endXXREAL-2V2 implies  False "
    proof(rule impI)
      assume "[.XXREAL-1K2 r,s .[ be right-endXXREAL-2V2"
      then have A3: "supXXREAL-2K1 ([.XXREAL-1K2 r,s .[) inHIDDENR3 [.XXREAL-1K2 r,s .["
         sorry
      then have A4: "supXXREAL-2K1 ([.XXREAL-1K2 r,s .[) <XXREAL-0R3 s"
        using xxreal_1_th_3 sorry
      have "r <=XXREAL-0R1 supXXREAL-2K1 ([.XXREAL-1K2 r,s .[)"
        using A3 xxreal_1_th_3 sorry
      then have "r <XXREAL-0R3 s"
        using A4 xxreal_0_th_2 sorry
      then have "s =HIDDENR1 supXXREAL-2K1 ([.XXREAL-1K2 r,s .[)"
        using xxreal_2_th_31 sorry
      thus " False "
        using A3 xxreal_1_th_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_40:
  mlet "r be ExtRealXXREAL-0M1", "s be ExtRealXXREAL-0M1"
"cluster ].XXREAL-1K4 r,s .[ as-term-is  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2"
proof
(*coherence*)
  show "].XXREAL-1K4 r,s .[ be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2"
  proof-
    have "].XXREAL-1K4 r,s .[ be  non left-endXXREAL-2V1 & (].XXREAL-1K4 r,s .[ be right-endXXREAL-2V2 implies  False )"
    proof(rule conjMI,rule impI)
      show "].XXREAL-1K4 r,s .[ be  non left-endXXREAL-2V1"
      proof-
        have "].XXREAL-1K4 r,s .[ be left-endXXREAL-2V1 implies  False "
        proof(rule impI)
          assume "].XXREAL-1K4 r,s .[ be left-endXXREAL-2V1"
          then have A5: "infXXREAL-2K2 (].XXREAL-1K4 r,s .[) inHIDDENR3 ].XXREAL-1K4 r,s .["
             sorry
          then have A6: "infXXREAL-2K2 (].XXREAL-1K4 r,s .[) <XXREAL-0R3 s"
            using xxreal_1_th_4 sorry
          have "r <XXREAL-0R3 infXXREAL-2K2 (].XXREAL-1K4 r,s .[)"
            using A5 xxreal_1_th_4 sorry
          then have "r <XXREAL-0R3 s"
            using A6 xxreal_0_th_2 sorry
          then have "r =HIDDENR1 infXXREAL-2K2 (].XXREAL-1K4 r,s .[)"
            using xxreal_2_th_28 sorry
          thus " False "
            using A5 xxreal_1_th_4 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      assume "].XXREAL-1K4 r,s .[ be right-endXXREAL-2V2"
      then have A7: "supXXREAL-2K1 (].XXREAL-1K4 r,s .[) inHIDDENR3 ].XXREAL-1K4 r,s .["
         sorry
      then have A8: "supXXREAL-2K1 (].XXREAL-1K4 r,s .[) <XXREAL-0R3 s"
        using xxreal_1_th_4 sorry
      have "r <XXREAL-0R3 supXXREAL-2K1 (].XXREAL-1K4 r,s .[)"
        using A7 xxreal_1_th_4 sorry
      then have "r <XXREAL-0R3 s"
        using A8 xxreal_0_th_2 sorry
      then have "s =HIDDENR1 supXXREAL-2K1 (].XXREAL-1K4 r,s .[)"
        using xxreal_2_th_32 sorry
      thus " False "
        using A7 xxreal_1_th_4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_41:
"cluster left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st it be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6"
  proof-
    have " ex tVar30 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (tVar30 be left-endXXREAL-2V1 & tVar30 be right-endXXREAL-2V2) & tVar30 be intervalXXREAL-2V6"
    proof-
      show " ex tVar30 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (tVar30 be left-endXXREAL-2V1 & tVar30 be right-endXXREAL-2V2) & tVar30 be intervalXXREAL-2V6"
      proof(rule bexI[of _ "[.XXREAL-1K1 0NUMBERSK6,\<one>\<^sub>M .]"])
        show "([.XXREAL-1K1 0NUMBERSK6,\<one>\<^sub>M .] be left-endXXREAL-2V1 & [.XXREAL-1K1 0NUMBERSK6,\<one>\<^sub>M .] be right-endXXREAL-2V2) & [.XXREAL-1K1 0NUMBERSK6,\<one>\<^sub>M .] be intervalXXREAL-2V6"
          using xxreal_2_th_33 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_42:
"cluster  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st it be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6"
  proof-
    have " ex tVar31 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st ( not tVar31 be left-endXXREAL-2V1 & tVar31 be right-endXXREAL-2V2) & tVar31 be intervalXXREAL-2V6"
    proof-
      show " ex tVar31 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st ( not tVar31 be left-endXXREAL-2V1 & tVar31 be right-endXXREAL-2V2) & tVar31 be intervalXXREAL-2V6"
      proof(rule bexI[of _ "].XXREAL-1K3 0NUMBERSK6,\<one>\<^sub>M .]"])
        show "( not ].XXREAL-1K3 0NUMBERSK6,\<one>\<^sub>M .] be left-endXXREAL-2V1 & ].XXREAL-1K3 0NUMBERSK6,\<one>\<^sub>M .] be right-endXXREAL-2V2) & ].XXREAL-1K3 0NUMBERSK6,\<one>\<^sub>M .] be intervalXXREAL-2V6"
          using xxreal_2_th_35 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_43:
"cluster left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st it be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6"
  proof-
    have " ex tVar32 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (tVar32 be left-endXXREAL-2V1 &  not tVar32 be right-endXXREAL-2V2) & tVar32 be intervalXXREAL-2V6"
    proof-
      show " ex tVar32 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (tVar32 be left-endXXREAL-2V1 &  not tVar32 be right-endXXREAL-2V2) & tVar32 be intervalXXREAL-2V6"
      proof(rule bexI[of _ "[.XXREAL-1K2 0NUMBERSK6,\<one>\<^sub>M .["])
        show "([.XXREAL-1K2 0NUMBERSK6,\<one>\<^sub>M .[ be left-endXXREAL-2V1 &  not [.XXREAL-1K2 0NUMBERSK6,\<one>\<^sub>M .[ be right-endXXREAL-2V2) & [.XXREAL-1K2 0NUMBERSK6,\<one>\<^sub>M .[ be intervalXXREAL-2V6"
          using xxreal_2_th_34 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_cl_44:
"cluster  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar> non emptyXBOOLE-0V1 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*existence*)
  show " ex it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st it be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar33 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (( not tVar33 be left-endXXREAL-2V1 &  not tVar33 be right-endXXREAL-2V2) & tVar33 be intervalXXREAL-2V6) &  not tVar33 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar33 be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 st (( not tVar33 be left-endXXREAL-2V1 &  not tVar33 be right-endXXREAL-2V2) & tVar33 be intervalXXREAL-2V6) &  not tVar33 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .["])
        have "\<one>\<^sub>M inTARSKIR2 ].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .["
          using xxreal_1_th_4 sorry
        thus "(( not ].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .[ be left-endXXREAL-2V1 &  not ].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .[ be right-endXXREAL-2V2) & ].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .[ be intervalXXREAL-2V6) &  not ].XXREAL-1K4 0NUMBERSK6,\<two>\<^sub>M .[ be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xxreal_2_th_75:
" for A be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A =MEMBEREDR8 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .]"
proof(rule ballI)
  fix A assume [ty]: "A be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A implies x inHIDDENR3 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .]) &  not (x inHIDDENR3 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .] &  not x inHIDDENR3 A)"
  proof(rule ballI,rule conjMI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    have A1: "maxXXREAL-2K6 A inHIDDENR3 A"
      using xxreal_2_def_6 sorry
    show "x inHIDDENR3 A implies x inHIDDENR3 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .]"
    proof(rule impI)
      assume A2: "x inHIDDENR3 A"
      then have A3: "x <=XXREAL-0R1 maxXXREAL-2K6 A"
        using xxreal_2_th_4 sorry
      have "minXXREAL-2K5 A <=XXREAL-0R1 x"
        using A2 xxreal_2_th_3 sorry
      thus "x inHIDDENR3 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .]"
        using A3 xxreal_1_th_1 sorry
    qed
    have "minXXREAL-2K5 A inHIDDENR3 A"
      using xxreal_2_def_5 sorry
    then have "[.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .] c=MEMBEREDR2 A"
      using A1 xxreal_2_def_12 sorry
    thus " not (x inHIDDENR3 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .] &  not x inHIDDENR3 A)"
       sorry
  qed "sorry"
  thus "A =MEMBEREDR8 [.XXREAL-1K1 minXXREAL-2K5 A,maxXXREAL-2K6 A .]"
    using membered_def_14 sorry
qed "sorry"

mtheorem xxreal_2_th_76:
" for A be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A =MEMBEREDR8 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]"
proof(rule ballI)
  fix A assume [ty]: "A be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A implies x inHIDDENR3 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]) & (x inHIDDENR3 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .] implies x inHIDDENR3 A)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 A & Lamb1 <XXREAL-0R3 x"
    show "x inHIDDENR3 A implies x inHIDDENR3 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]"
    proof(rule impI)
      have A1: " not infXXREAL-2K2 A inHIDDENR3 A"
        using xxreal_2_def_5 sorry
      assume A2: "x inHIDDENR3 A"
      then have A3: "x <=XXREAL-0R1 maxXXREAL-2K6 A"
        using xxreal_2_th_4 sorry
      have "infXXREAL-2K2 A <=XXREAL-0R1 x"
        using A2 xxreal_2_th_3 sorry
      then have "infXXREAL-2K2 A <XXREAL-0R3 x"
        using A2 A1 xxreal_0_th_1 sorry
      thus "x inHIDDENR3 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]"
        using A3 xxreal_1_th_2 sorry
    qed
    assume A4: "x inHIDDENR3 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]"
    show "x inHIDDENR3 A"
    proof-
      have cases: " not ( ex r be ExtRealXXREAL-0M1 st ?P(r)) or ( ex r be ExtRealXXREAL-0M1 st ?P(r))"
         sorry
      have case1: " not ( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r <XXREAL-0R3 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex r be ExtRealXXREAL-0M1 st ?P(r))"
        then have "x be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_def_2 sorry
        then have "x <=XXREAL-0R1 infXXREAL-2K2 A"
          using xxreal_2_def_4 sorry
        thus "x inHIDDENR3 A"
          using A4 xxreal_1_th_2 sorry
      qed
      have case2: "( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r <XXREAL-0R3 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " ex r be ExtRealXXREAL-0M1 st ?P(r)"
        then obtain r where
          [ty]:"r be ExtRealXXREAL-0M1" and 
          A5: "r inHIDDENR3 A"and A6: "r <XXREAL-0R3 x"
           sorry
        have "x <=XXREAL-0R1 maxXXREAL-2K6 A"
          using A4 xxreal_1_th_2 sorry
        then have A7: "x inHIDDENR3 [.XXREAL-1K1 r,maxXXREAL-2K6 A .]"
          using A6 xxreal_1_th_1 sorry
        have "maxXXREAL-2K6 A inHIDDENR3 A"
          using xxreal_2_def_6 sorry
        then have "[.XXREAL-1K1 r,maxXXREAL-2K6 A .] c=MEMBEREDR2 A"
          using A5 xxreal_2_def_12 sorry
        thus "x inHIDDENR3 A"
          using A7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "A =MEMBEREDR8 ].XXREAL-1K3 infXXREAL-2K2 A,maxXXREAL-2K6 A .]"
    using membered_def_14 sorry
qed "sorry"

mtheorem xxreal_2_th_77:
" for A be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A =MEMBEREDR8 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .["
proof(rule ballI)
  fix A assume [ty]: "A be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A implies x inHIDDENR3 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .[) & (x inHIDDENR3 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .[ implies x inHIDDENR3 A)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 A & Lamb1 >XXREAL-0R4 x"
    show "x inHIDDENR3 A implies x inHIDDENR3 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .["
    proof(rule impI)
      have A1: " not supXXREAL-2K1 A inHIDDENR3 A"
        using xxreal_2_def_6 sorry
      assume A2: "x inHIDDENR3 A"
      then have A3: "minXXREAL-2K5 A <=XXREAL-0R1 x"
        using xxreal_2_th_3 sorry
      have "x <=XXREAL-0R1 supXXREAL-2K1 A"
        using A2 xxreal_2_th_4 sorry
      then have "x <XXREAL-0R3 supXXREAL-2K1 A"
        using A2 A1 xxreal_0_th_1 sorry
      thus "x inHIDDENR3 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .["
        using A3 xxreal_1_th_3 sorry
    qed
    assume A4: "x inHIDDENR3 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .["
    show "x inHIDDENR3 A"
    proof-
      have cases: " not ( ex r be ExtRealXXREAL-0M1 st ?P(r)) or ( ex r be ExtRealXXREAL-0M1 st ?P(r))"
         sorry
      have case1: " not ( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r >XXREAL-0R4 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex r be ExtRealXXREAL-0M1 st ?P(r))"
        then have "x be UpperBoundXXREAL-2M1-of A"
          using xxreal_2_def_1 sorry
        then have "supXXREAL-2K1 A <=XXREAL-0R1 x"
          using xxreal_2_def_3 sorry
        thus "x inHIDDENR3 A"
          using A4 xxreal_1_th_3 sorry
      qed
      have case2: "( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r >XXREAL-0R4 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " ex r be ExtRealXXREAL-0M1 st ?P(r)"
        then obtain r where
          [ty]:"r be ExtRealXXREAL-0M1" and 
          A5: "r inHIDDENR3 A"and A6: "r >XXREAL-0R4 x"
           sorry
        have "infXXREAL-2K2 A <=XXREAL-0R1 x"
          using A4 xxreal_1_th_3 sorry
        then have A7: "x inHIDDENR3 [.XXREAL-1K1 infXXREAL-2K2 A,r .]"
          using A6 xxreal_1_th_1 sorry
        have "minXXREAL-2K5 A inHIDDENR3 A"
          using xxreal_2_def_5 sorry
        then have "[.XXREAL-1K1 infXXREAL-2K2 A,r .] c=MEMBEREDR2 A"
          using A5 xxreal_2_def_12 sorry
        thus "x inHIDDENR3 A"
          using A7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "A =MEMBEREDR8 [.XXREAL-1K2 minXXREAL-2K5 A,supXXREAL-2K1 A .["
    using membered_def_14 sorry
qed "sorry"

mtheorem xxreal_2_th_78:
" for A be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar> non emptyXBOOLE-0V1\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A =MEMBEREDR8 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
proof(rule ballI)
  fix A assume [ty]: "A be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar> non emptyXBOOLE-0V1\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
  have " for x be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A implies x inHIDDENR3 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .[) & (x inHIDDENR3 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .[ implies x inHIDDENR3 A)"
  proof(rule ballI,rule conjMI,rule impI)
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 A & Lamb1 <XXREAL-0R3 x"
    let ?Q = "\<lambda>Lamb1. Lamb1 inHIDDENR3 A & Lamb1 >XXREAL-0R4 x"
    show "x inHIDDENR3 A implies x inHIDDENR3 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
    proof(rule impI)
      assume A1: "x inHIDDENR3 A"
      then have A2: "x <>HIDDENR2 supXXREAL-2K1 A"
        using xxreal_2_def_6 sorry
      have "x <=XXREAL-0R1 supXXREAL-2K1 A"
        using A1 xxreal_2_th_4 sorry
      then have A3: "x <XXREAL-0R3 supXXREAL-2K1 A"
        using A2 xxreal_0_th_1 sorry
      have A4: "x <>HIDDENR2 infXXREAL-2K2 A"
        using A1 xxreal_2_def_5 sorry
      have "infXXREAL-2K2 A <=XXREAL-0R1 x"
        using A1 xxreal_2_th_3 sorry
      then have "infXXREAL-2K2 A <XXREAL-0R3 x"
        using A4 xxreal_0_th_1 sorry
      thus "x inHIDDENR3 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
        using A3 xxreal_1_th_4 sorry
    qed
    assume A5: "x inHIDDENR3 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
    show "x inHIDDENR3 A"
    proof-
      have cases: "( not ( ex r be ExtRealXXREAL-0M1 st ?P(r)) or  not ( ex r be ExtRealXXREAL-0M1 st ?Q(r))) or ( ex r be ExtRealXXREAL-0M1 st ?P(r)) & ( ex r be ExtRealXXREAL-0M1 st ?Q(r))"
         sorry
      have case1: " not ( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r <XXREAL-0R3 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex r be ExtRealXXREAL-0M1 st ?P(r))"
        then have "x be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_def_2 sorry
        then have "x <=XXREAL-0R1 infXXREAL-2K2 A"
          using xxreal_2_def_4 sorry
        thus "x inHIDDENR3 A"
          using A5 xxreal_1_th_4 sorry
      qed
      have case2: " not ( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r >XXREAL-0R4 x) implies x inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex r be ExtRealXXREAL-0M1 st ?Q(r))"
        then have "x be UpperBoundXXREAL-2M1-of A"
          using xxreal_2_def_1 sorry
        then have "supXXREAL-2K1 A <=XXREAL-0R1 x"
          using xxreal_2_def_3 sorry
        thus "x inHIDDENR3 A"
          using A5 xxreal_1_th_4 sorry
      qed
      have case3: "( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r <XXREAL-0R3 x) & ( ex r be ExtRealXXREAL-0M1 st r inHIDDENR3 A & r >XXREAL-0R4 x) implies x inHIDDENR3 A"
      proof(rule impMI ,rule impI)
        assume A6: " ex r be ExtRealXXREAL-0M1 st ?P(r)"
          and A7: " ex r be ExtRealXXREAL-0M1 st ?Q(r)"
        obtain r where
          [ty]:"r be ExtRealXXREAL-0M1" and 
          A8: "r inHIDDENR3 A"and A9: "r <XXREAL-0R3 x"
          using A6 sorry
        obtain s where
          [ty]:"s be ExtRealXXREAL-0M1" and 
          A10: "s inHIDDENR3 A"and A11: "s >XXREAL-0R4 x"
          using A7 sorry
        have A12: "x inHIDDENR3 [.XXREAL-1K1 r,s .]"
          using A9 A11 xxreal_1_th_1 sorry
        have "[.XXREAL-1K1 r,s .] c=MEMBEREDR2 A"
          using A8 A10 xxreal_2_def_12 sorry
        thus "x inHIDDENR3 A"
          using A12 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus "A =MEMBEREDR8 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
    using membered_def_14 sorry
qed "sorry"

mtheorem xxreal_2_th_79:
" for A be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  ex r be ExtRealXXREAL-0M1 st  ex s be ExtRealXXREAL-0M1 st r <=XXREAL-0R1 s & A =MEMBEREDR8 ].XXREAL-1K4 r,s .["
proof-
  have " for A be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  ex tVar34 be ExtRealXXREAL-0M1 st  ex tVar35 be ExtRealXXREAL-0M1 st tVar35 <=XXREAL-0R1 tVar35 & A =MEMBEREDR8 ].XXREAL-1K4 tVar35,tVar35 .["
  proof(rule ballI)
    fix A assume [ty]: "A be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2\<bar>intervalXXREAL-2V6\<bar>ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    show " ex tVar34 be ExtRealXXREAL-0M1 st  ex tVar35 be ExtRealXXREAL-0M1 st tVar35 <=XXREAL-0R1 tVar35 & A =MEMBEREDR8 ].XXREAL-1K4 tVar35,tVar35 .["
    proof-
      have cases: "A be emptyXBOOLE-0V1 or  not A be emptyXBOOLE-0V1"
         sorry
      have case1: "A be emptyXBOOLE-0V1 implies ( ex tVar34 be ExtRealXXREAL-0M1 st  ex tVar35 be ExtRealXXREAL-0M1 st tVar35 <=XXREAL-0R1 tVar35 & A =MEMBEREDR8 ].XXREAL-1K4 tVar35,tVar35 .[)"
      proof(rule impI)
        assume A1: "A be emptyXBOOLE-0V1"
        show " ex tVar34 be ExtRealXXREAL-0M1 st  ex tVar35 be ExtRealXXREAL-0M1 st tVar35 <=XXREAL-0R1 tVar35 & A =MEMBEREDR8 ].XXREAL-1K4 tVar35,tVar35 .["
        proof(rule bexI[of _ "-inftyXXREAL-0K2"])
          show " ex tVar35 be ExtRealXXREAL-0M1 st tVar35 <=XXREAL-0R1 tVar35 & A =MEMBEREDR8 ].XXREAL-1K4 tVar35,tVar35 .["
          proof(rule bexI[of _ "-inftyXXREAL-0K2"])
            show "-inftyXXREAL-0K2 <=XXREAL-0R1 -inftyXXREAL-0K2 & A =MEMBEREDR8 ].XXREAL-1K4 -inftyXXREAL-0K2,-inftyXXREAL-0K2 .["
              using A1 sorry
          qed "sorry"
        qed "sorry"
      qed
      have case2: " not A be emptyXBOOLE-0V1 implies ( ex tVar36 be ExtRealXXREAL-0M1 st  ex tVar37 be ExtRealXXREAL-0M1 st tVar36 <=XXREAL-0R1 tVar37 & A =MEMBEREDR8 ].XXREAL-1K4 tVar36,tVar37 .[)"
      proof(rule impI)
        assume A2: " not A be emptyXBOOLE-0V1"
        show " ex tVar36 be ExtRealXXREAL-0M1 st  ex tVar37 be ExtRealXXREAL-0M1 st tVar36 <=XXREAL-0R1 tVar37 & A =MEMBEREDR8 ].XXREAL-1K4 tVar36,tVar37 .["
        proof(rule bexI[of _ "infXXREAL-2K2 A"])
          show " ex tVar37 be ExtRealXXREAL-0M1 st infXXREAL-2K2 A <=XXREAL-0R1 tVar37 & A =MEMBEREDR8 ].XXREAL-1K4 infXXREAL-2K2 A,tVar37 .["
          proof(rule bexI[of _ "supXXREAL-2K1 A"],rule conjMI)
            show "infXXREAL-2K2 A <=XXREAL-0R1 supXXREAL-2K1 A"
              using A2 xxreal_2_th_40 sorry
            show "A =MEMBEREDR8 ].XXREAL-1K4 infXXREAL-2K2 A,supXXREAL-2K1 A .["
              using A2 xxreal_2_th_78 sorry
          qed "sorry"
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_80:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 y implies r inHIDDENR3 A)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & (y inHIDDENR3 A & (x <=XXREAL-0R1 r & r <=XXREAL-0R1 y)) implies r inHIDDENR3 A)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix y assume [ty]: "y be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    assume A2: "x inHIDDENR3 A"
      and A3: "y inHIDDENR3 A"
      and A4: "x <=XXREAL-0R1 r"
      and A5: "r <=XXREAL-0R1 y"
    have A6: "r inHIDDENR3 [.XXREAL-1K1 x,y .]"
      using A4 A5 xxreal_1_th_1 sorry
    have "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
      using A1 A2 A3 sorry
    thus "r inHIDDENR3 A"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_81:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A & x <=XXREAL-0R1 r) & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & (x <=XXREAL-0R1 r & r <XXREAL-0R3 supXXREAL-2K1 A) implies r inHIDDENR3 A)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    assume A2: "x inHIDDENR3 A"
      and A3: "x <=XXREAL-0R1 r"
      and A4: "r <XXREAL-0R3 supXXREAL-2K1 A"
    show "r inHIDDENR3 A"
    proof-
      have cases: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y) or  not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y)"
         sorry
      have case1: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y"
        thus "r inHIDDENR3 A"
          using A1 A2 A3 xxreal_2_th_80 sorry
      qed
      have case2: " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r <XXREAL-0R3 y)"
        then have "r be UpperBoundXXREAL-2M1-of A"
          using xxreal_2_def_1 sorry
        thus "r inHIDDENR3 A"
          using A4 xxreal_2_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_82:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A & infXXREAL-2K2 A <XXREAL-0R3 r) & r <=XXREAL-0R1 x implies r inHIDDENR3 A)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & (infXXREAL-2K2 A <XXREAL-0R3 r & r <=XXREAL-0R1 x) implies r inHIDDENR3 A)"
  proof(rule ballI,rule impI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
    fix x assume [ty]: "x be ExtRealXXREAL-0M1"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    assume A2: "x inHIDDENR3 A"
      and A3: "infXXREAL-2K2 A <XXREAL-0R3 r"
      and A4: "r <=XXREAL-0R1 x"
    show "r inHIDDENR3 A"
    proof-
      have cases: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) or  not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y)"
         sorry
      have case1: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y"
        thus "r inHIDDENR3 A"
          using A1 A2 A4 xxreal_2_th_80 sorry
      qed
      have case2: " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y)"
        then have "r be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_def_2 sorry
        thus "r inHIDDENR3 A"
          using A3 xxreal_2_def_4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_83:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for r be ExtRealXXREAL-0M1 holds infXXREAL-2K2 A <XXREAL-0R3 r & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A)"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 implies ( for r be ExtRealXXREAL-0M1 holds infXXREAL-2K2 A <XXREAL-0R3 r & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A)"
  proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    assume A2: "infXXREAL-2K2 A <XXREAL-0R3 r"
      and A3: "r <XXREAL-0R3 supXXREAL-2K1 A"
    show "r inHIDDENR3 A"
    proof-
      have cases: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) or  not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y)"
         sorry
      have case1: "( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y"
        thus "r inHIDDENR3 A"
          using A1 A3 xxreal_2_th_81 sorry
      qed
      have case2: " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y) implies r inHIDDENR3 A"
      proof(rule impI)
        assume " not ( ex y be ExtRealXXREAL-0M1 st y inHIDDENR3 A & r >XXREAL-0R4 y)"
        then have "r be LowerBoundXXREAL-2M2-of A"
          using xxreal_2_def_2 sorry
        thus "r inHIDDENR3 A"
          using A2 xxreal_2_def_4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_84:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A"
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & y inHIDDENR3 A implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 A"
        and A3: "y inHIDDENR3 A"
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 [.XXREAL-1K1 x,y .] implies r inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "r inHIDDENR3 ].XXREAL-1K4 x,y .[ \\/XBOOLE-0K2 {TARSKIK2 x,y }"
          using xxreal_1_th_29 xxreal_1_th_128 sorry
        then have A4: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ or r inHIDDENR3 {TARSKIK2 x,y }"
          using xboole_0_def_3 sorry
        show "r inHIDDENR3 A"
        proof-
          have cases: "(r =HIDDENR1 x or r =HIDDENR1 y) or r inHIDDENR3 ].XXREAL-1K4 x,y .["
            using A4 tarski_def_2 sorry
          have case1: "r =HIDDENR1 x implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 x"
            thus "r inHIDDENR3 A"
              using A2 sorry
          qed
          have case2: "r =HIDDENR1 y implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 y"
            thus "r inHIDDENR3 A"
              using A3 sorry
          qed
          have case3: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ implies r inHIDDENR3 A"
          proof(rule impI)
            assume A5: "r inHIDDENR3 ].XXREAL-1K4 x,y .["
            then have A6: "r <XXREAL-0R3 y"
              using xxreal_1_th_4 sorry
            have "x <XXREAL-0R3 r"
              using A5 xxreal_1_th_4 sorry
            thus "r inHIDDENR3 A"
              using A1 A2 A3 A6 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
        using membered_def_8 sorry
    qed "sorry"
    thus "A be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_85:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A & x <XXREAL-0R3 r) & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A & x <XXREAL-0R3 r) & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: " for x be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (x inHIDDENR3 A & x <XXREAL-0R3 r) & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A"
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & y inHIDDENR3 A implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 A"
        and A3: "y inHIDDENR3 A"
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 [.XXREAL-1K1 x,y .] implies r inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "r inHIDDENR3 ].XXREAL-1K4 x,y .[ \\/XBOOLE-0K2 {TARSKIK2 x,y }"
          using xxreal_1_th_29 xxreal_1_th_128 sorry
        then have A4: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ or r inHIDDENR3 {TARSKIK2 x,y }"
          using xboole_0_def_3 sorry
        show "r inHIDDENR3 A"
        proof-
          have cases: "(r =HIDDENR1 x or r =HIDDENR1 y) or r inHIDDENR3 ].XXREAL-1K4 x,y .["
            using A4 tarski_def_2 sorry
          have case1: "r =HIDDENR1 x implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 x"
            thus "r inHIDDENR3 A"
              using A2 sorry
          qed
          have case2: "r =HIDDENR1 y implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 y"
            thus "r inHIDDENR3 A"
              using A3 sorry
          qed
          have case3: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ implies r inHIDDENR3 A"
          proof(rule impI)
            assume A5: "r inHIDDENR3 ].XXREAL-1K4 x,y .["
            then have A6: "r <XXREAL-0R3 y"
              using xxreal_1_th_4 sorry
            have "y <=XXREAL-0R1 supXXREAL-2K1 A"
              using A3 xxreal_2_th_4 sorry
            then have A7: "r <XXREAL-0R3 supXXREAL-2K1 A"
              using A6 xxreal_0_th_2 sorry
            have "x <XXREAL-0R3 r"
              using A5 xxreal_1_th_4 sorry
            thus "r inHIDDENR3 A"
              using A1 A2 A7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
        using membered_def_8 sorry
    qed "sorry"
    thus "A be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_86:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (y inHIDDENR3 A & infXXREAL-2K2 A <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (y inHIDDENR3 A & infXXREAL-2K2 A <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: " for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds (y inHIDDENR3 A & infXXREAL-2K2 A <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A"
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & y inHIDDENR3 A implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 A"
        and A3: "y inHIDDENR3 A"
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 [.XXREAL-1K1 x,y .] implies r inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "r inHIDDENR3 ].XXREAL-1K4 x,y .[ \\/XBOOLE-0K2 {TARSKIK2 x,y }"
          using xxreal_1_th_29 xxreal_1_th_128 sorry
        then have A4: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ or r inHIDDENR3 {TARSKIK2 x,y }"
          using xboole_0_def_3 sorry
        show "r inHIDDENR3 A"
        proof-
          have cases: "(r =HIDDENR1 x or r =HIDDENR1 y) or r inHIDDENR3 ].XXREAL-1K4 x,y .["
            using A4 tarski_def_2 sorry
          have case1: "r =HIDDENR1 x implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 x"
            thus "r inHIDDENR3 A"
              using A2 sorry
          qed
          have case2: "r =HIDDENR1 y implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 y"
            thus "r inHIDDENR3 A"
              using A3 sorry
          qed
          have case3: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ implies r inHIDDENR3 A"
          proof(rule impI)
            assume A5: "r inHIDDENR3 ].XXREAL-1K4 x,y .["
            then have A6: "x <XXREAL-0R3 r"
              using xxreal_1_th_4 sorry
            have "infXXREAL-2K2 A <=XXREAL-0R1 x"
              using A2 xxreal_2_th_3 sorry
            then have A7: "infXXREAL-2K2 A <XXREAL-0R3 r"
              using A6 xxreal_0_th_2 sorry
            have "r <XXREAL-0R3 y"
              using A5 xxreal_1_th_4 sorry
            thus "r inHIDDENR3 A"
              using A1 A3 A7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
        using membered_def_8 sorry
    qed "sorry"
    thus "A be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_87:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for r be ExtRealXXREAL-0M1 holds infXXREAL-2K2 A <XXREAL-0R3 r & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for r be ExtRealXXREAL-0M1 holds infXXREAL-2K2 A <XXREAL-0R3 r & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: " for r be ExtRealXXREAL-0M1 holds infXXREAL-2K2 A <XXREAL-0R3 r & r <XXREAL-0R3 supXXREAL-2K1 A implies r inHIDDENR3 A"
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds x inHIDDENR3 A & y inHIDDENR3 A implies [.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x assume [ty]: "x be ExtRealXXREAL-0M1"
      fix y assume [ty]: "y be ExtRealXXREAL-0M1"
      assume A2: "x inHIDDENR3 A"
        and A3: "y inHIDDENR3 A"
      have " for r be ExtRealXXREAL-0M1 holds r inHIDDENR3 [.XXREAL-1K1 x,y .] implies r inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume "r inHIDDENR3 [.XXREAL-1K1 x,y .]"
        then have "r inHIDDENR3 ].XXREAL-1K4 x,y .[ \\/XBOOLE-0K2 {TARSKIK2 x,y }"
          using xxreal_1_th_29 xxreal_1_th_128 sorry
        then have A4: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ or r inHIDDENR3 {TARSKIK2 x,y }"
          using xboole_0_def_3 sorry
        show "r inHIDDENR3 A"
        proof-
          have cases: "(r =HIDDENR1 x or r =HIDDENR1 y) or r inHIDDENR3 ].XXREAL-1K4 x,y .["
            using A4 tarski_def_2 sorry
          have case1: "r =HIDDENR1 x implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 x"
            thus "r inHIDDENR3 A"
              using A2 sorry
          qed
          have case2: "r =HIDDENR1 y implies r inHIDDENR3 A"
          proof(rule impI)
            assume "r =HIDDENR1 y"
            thus "r inHIDDENR3 A"
              using A3 sorry
          qed
          have case3: "r inHIDDENR3 ].XXREAL-1K4 x,y .[ implies r inHIDDENR3 A"
          proof(rule impI)
            assume A5: "r inHIDDENR3 ].XXREAL-1K4 x,y .["
            then have A6: "r <XXREAL-0R3 y"
              using xxreal_1_th_4 sorry
            have "y <=XXREAL-0R1 supXXREAL-2K1 A"
              using A3 xxreal_2_th_4 sorry
            then have A7: "r <XXREAL-0R3 supXXREAL-2K1 A"
              using A6 xxreal_0_th_2 sorry
            have A8: "x <XXREAL-0R3 r"
              using A5 xxreal_1_th_4 sorry
            have "infXXREAL-2K2 A <=XXREAL-0R1 x"
              using A2 xxreal_2_th_3 sorry
            then have "infXXREAL-2K2 A <XXREAL-0R3 r"
              using A8 xxreal_0_th_2 sorry
            thus "r inHIDDENR3 A"
              using A1 A7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 sorry
        qed
      qed "sorry"
      thus "[.XXREAL-1K1 x,y .] c=MEMBEREDR2 A"
        using membered_def_8 sorry
    qed "sorry"
    thus "A be intervalXXREAL-2V6"
      using xxreal_2_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_88:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds ( for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 y implies r inHIDDENR3 A) implies A be intervalXXREAL-2V6"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 y implies r inHIDDENR3 A"
    then have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A & y inHIDDENR3 A) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A"
       sorry
    thus "A be intervalXXREAL-2V6"
      using xxreal_2_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_89:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (A be intervalXXREAL-2V6 & B be intervalXXREAL-2V6) & A meetsXBOOLE-0R5 B implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 & B be intervalXXREAL-2V6 implies  not ( not A meetsXBOOLE-0R5 B &  not A \\/XBOOLE-0K2 B be intervalXXREAL-2V6)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
      and A2: "B be intervalXXREAL-2V6"
    have "( ex z be ExtRealXXREAL-0M1 st z inHIDDENR3 A & z inHIDDENR3 B) implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
    proof(rule impI)
      assume Given: " ex z be ExtRealXXREAL-0M1 st z inHIDDENR3 A & z inHIDDENR3 B"
      then obtain z where
        [ty]:"z be ExtRealXXREAL-0M1" and 
        A3: "z inHIDDENR3 A"and A4: "z inHIDDENR3 B"
         sorry
      have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A \\/XBOOLE-0K2 B & y inHIDDENR3 A \\/XBOOLE-0K2 B) & x <=XXREAL-0R1 r) & r <=XXREAL-0R1 y implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
      proof-
        have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A \\/XBOOLE-0K2 B & (y inHIDDENR3 A \\/XBOOLE-0K2 B & (x <=XXREAL-0R1 r & r <=XXREAL-0R1 y)) implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
          fix x assume [ty]: "x be ExtRealXXREAL-0M1"
          fix y assume [ty]: "y be ExtRealXXREAL-0M1"
          fix r assume [ty]: "r be ExtRealXXREAL-0M1"
          assume A5: "x inHIDDENR3 A \\/XBOOLE-0K2 B"
            and A6: "y inHIDDENR3 A \\/XBOOLE-0K2 B"
            and A7: "x <=XXREAL-0R1 r"
            and A8: "r <=XXREAL-0R1 y"
          show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof-
            have cases: "((x inHIDDENR3 A & y inHIDDENR3 A or x inHIDDENR3 A & y inHIDDENR3 B) or x inHIDDENR3 B & y inHIDDENR3 A) or x inHIDDENR3 B & y inHIDDENR3 B"
              using A5 A6 xboole_0_def_3 sorry
            have case1: "x inHIDDENR3 A & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof(rule impI)
              assume "x inHIDDENR3 A & y inHIDDENR3 A"
              then have "r inHIDDENR3 A"
                using A1 A7 A8 xxreal_2_th_80 sorry
              thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                using xboole_0_def_3 sorry
            qed
            have case2: "x inHIDDENR3 A & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof(rule impMI ,rule impI)
              assume A9: "x inHIDDENR3 A"
                and A10: "y inHIDDENR3 B"
              show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof-
                have cases: "r <=XXREAL-0R1 z or z <=XXREAL-0R1 r"
                   sorry
                have case1: "r <=XXREAL-0R1 z implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
                proof(rule impI)
                  assume "r <=XXREAL-0R1 z"
                  then have "r inHIDDENR3 A"
                    using A1 A3 A7 A9 xxreal_2_th_80 sorry
                  thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                    using xboole_0_def_3 sorry
                qed
                have case2: "z <=XXREAL-0R1 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
                proof(rule impI)
                  assume "z <=XXREAL-0R1 r"
                  then have "r inHIDDENR3 B"
                    using A2 A4 A8 A10 xxreal_2_th_80 sorry
                  thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                    using xboole_0_def_3 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            have case3: "x inHIDDENR3 B & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof(rule impMI ,rule impI)
              assume A11: "x inHIDDENR3 B"
                and A12: "y inHIDDENR3 A"
              show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof-
                have cases: "z <=XXREAL-0R1 r or r <=XXREAL-0R1 z"
                   sorry
                have case1: "z <=XXREAL-0R1 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
                proof(rule impI)
                  assume "z <=XXREAL-0R1 r"
                  then have "r inHIDDENR3 A"
                    using A1 A3 A8 A12 xxreal_2_th_80 sorry
                  thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                    using xboole_0_def_3 sorry
                qed
                have case2: "r <=XXREAL-0R1 z implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
                proof(rule impI)
                  assume "r <=XXREAL-0R1 z"
                  then have "r inHIDDENR3 B"
                    using A2 A4 A7 A11 xxreal_2_th_80 sorry
                  thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                    using xboole_0_def_3 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            have case4: "x inHIDDENR3 B & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof(rule impI)
              assume "x inHIDDENR3 B & y inHIDDENR3 B"
              then have "r inHIDDENR3 B"
                using A2 A7 A8 xxreal_2_th_80 sorry
              thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                using xboole_0_def_3 sorry
            qed
            show " ?thesis "
              using cases case1 case2 case3 case4 sorry
          qed
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
        using xxreal_2_th_88 sorry
    qed
    thus " not ( not A meetsXBOOLE-0R5 B &  not A \\/XBOOLE-0K2 B be intervalXXREAL-2V6)"
      using membered_def_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_90:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (A be intervalXXREAL-2V6 & B be left-endXXREAL-2V1\<bar>intervalXXREAL-2V6) & supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be intervalXXREAL-2V6 & (B be left-endXXREAL-2V1\<bar>intervalXXREAL-2V6 & supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B) implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be intervalXXREAL-2V6"
      and A2: "B be left-endXXREAL-2V1\<bar>intervalXXREAL-2V6"
      and A3: "supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B"
    let ?z = "infXXREAL-2K2 B"
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A \\/XBOOLE-0K2 B & y inHIDDENR3 A \\/XBOOLE-0K2 B) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
    proof-
      have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A \\/XBOOLE-0K2 B & (y inHIDDENR3 A \\/XBOOLE-0K2 B & (x <XXREAL-0R3 r & r <XXREAL-0R3 y)) implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        fix y assume [ty]: "y be ExtRealXXREAL-0M1"
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume A4: "x inHIDDENR3 A \\/XBOOLE-0K2 B"
          and A5: "y inHIDDENR3 A \\/XBOOLE-0K2 B"
          and A6: "x <XXREAL-0R3 r"
          and A7: "r <XXREAL-0R3 y"
        show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
        proof-
          have cases: "((x inHIDDENR3 A & y inHIDDENR3 A or x inHIDDENR3 A & y inHIDDENR3 B) or x inHIDDENR3 B & y inHIDDENR3 A) or x inHIDDENR3 B & y inHIDDENR3 B"
            using A4 A5 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 A & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impI)
            assume "x inHIDDENR3 A & y inHIDDENR3 A"
            then have "r inHIDDENR3 A"
              using A1 A6 A7 xxreal_2_th_80 sorry
            thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              using xboole_0_def_3 sorry
          qed
          have case2: "x inHIDDENR3 A & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impMI ,rule impI)
            assume A8: "x inHIDDENR3 A"
              and A9: "y inHIDDENR3 B"
            show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof-
              have cases: "r <XXREAL-0R3 ?z or ?z <=XXREAL-0R1 r"
                 sorry
              have case1: "r <XXREAL-0R3 infXXREAL-2K2 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "r <XXREAL-0R3 ?z"
                then have "r inHIDDENR3 A"
                  using A1 A3 A6 A8 xxreal_2_th_81 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              have case2: "infXXREAL-2K2 B <=XXREAL-0R1 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "?z <=XXREAL-0R1 r"
                then have "r inHIDDENR3 B"
                  using A2 A7 A9 xxreal_2_th_80 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          have case3: "x inHIDDENR3 B & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impMI ,rule impI)
            assume A10: "x inHIDDENR3 B"
              and A11: "y inHIDDENR3 A"
            show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof-
              have cases: "?z <XXREAL-0R3 r or r <=XXREAL-0R1 ?z"
                 sorry
              have case1: "infXXREAL-2K2 B <XXREAL-0R3 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume A12: "?z <XXREAL-0R3 r"
                have "y <=XXREAL-0R1 ?z"
                  using A3 A11 xxreal_2_th_4 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using A7 A12 xxreal_0_th_2 sorry
              qed
              have case2: "r <=XXREAL-0R1 infXXREAL-2K2 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "r <=XXREAL-0R1 ?z"
                then have "r inHIDDENR3 B"
                  using A2 A6 A10 xxreal_2_th_80 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          have case4: "x inHIDDENR3 B & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impI)
            assume "x inHIDDENR3 B & y inHIDDENR3 B"
            then have "r inHIDDENR3 B"
              using A2 A6 A7 xxreal_2_th_80 sorry
            thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              using xboole_0_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
      using xxreal_2_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_91:
" for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds (A be right-endXXREAL-2V2\<bar>intervalXXREAL-2V6 & B be intervalXXREAL-2V6) & supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
proof-
  have " for A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds  for B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds A be right-endXXREAL-2V2\<bar>intervalXXREAL-2V6 & (B be intervalXXREAL-2V6 & supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B) implies A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix A assume [ty]: "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
    assume A1: "A be right-endXXREAL-2V2\<bar>intervalXXREAL-2V6"
      and A2: "B be intervalXXREAL-2V6"
      and A3: "supXXREAL-2K1 A =HIDDENR1 infXXREAL-2K2 B"
    let ?z = "infXXREAL-2K2 B"
    have A4: "?z inHIDDENR3 A"
      using A1 A3 sorry
    have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds ((x inHIDDENR3 A \\/XBOOLE-0K2 B & y inHIDDENR3 A \\/XBOOLE-0K2 B) & x <XXREAL-0R3 r) & r <XXREAL-0R3 y implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
    proof-
      have " for x be ExtRealXXREAL-0M1 holds  for y be ExtRealXXREAL-0M1 holds  for r be ExtRealXXREAL-0M1 holds x inHIDDENR3 A \\/XBOOLE-0K2 B & (y inHIDDENR3 A \\/XBOOLE-0K2 B & (x <XXREAL-0R3 r & r <XXREAL-0R3 y)) implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
      proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        fix y assume [ty]: "y be ExtRealXXREAL-0M1"
        fix r assume [ty]: "r be ExtRealXXREAL-0M1"
        assume A5: "x inHIDDENR3 A \\/XBOOLE-0K2 B"
          and A6: "y inHIDDENR3 A \\/XBOOLE-0K2 B"
          and A7: "x <XXREAL-0R3 r"
          and A8: "r <XXREAL-0R3 y"
        show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
        proof-
          have cases: "((x inHIDDENR3 A & y inHIDDENR3 A or x inHIDDENR3 A & y inHIDDENR3 B) or x inHIDDENR3 B & y inHIDDENR3 A) or x inHIDDENR3 B & y inHIDDENR3 B"
            using A5 A6 xboole_0_def_3 sorry
          have case1: "x inHIDDENR3 A & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impI)
            assume "x inHIDDENR3 A & y inHIDDENR3 A"
            then have "r inHIDDENR3 A"
              using A1 A7 A8 xxreal_2_th_80 sorry
            thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              using xboole_0_def_3 sorry
          qed
          have case2: "x inHIDDENR3 A & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impMI ,rule impI)
            assume A9: "x inHIDDENR3 A"
              and A10: "y inHIDDENR3 B"
            show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof-
              have cases: "r <=XXREAL-0R1 ?z or ?z <XXREAL-0R3 r"
                 sorry
              have case1: "r <=XXREAL-0R1 infXXREAL-2K2 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "r <=XXREAL-0R1 ?z"
                then have "r inHIDDENR3 A"
                  using A1 A4 A7 A9 xxreal_2_th_80 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              have case2: "infXXREAL-2K2 B <XXREAL-0R3 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "?z <XXREAL-0R3 r"
                then have "r inHIDDENR3 B"
                  using A2 A8 A10 xxreal_2_th_82 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          have case3: "x inHIDDENR3 B & y inHIDDENR3 A implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impMI ,rule impI)
            assume A11: "x inHIDDENR3 B"
              and A12: "y inHIDDENR3 A"
            show "r inHIDDENR3 A \\/XBOOLE-0K2 B"
            proof-
              have cases: "?z <=XXREAL-0R1 r or r <XXREAL-0R3 ?z"
                 sorry
              have case1: "infXXREAL-2K2 B <=XXREAL-0R1 r implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume "?z <=XXREAL-0R1 r"
                then have "r inHIDDENR3 A"
                  using A1 A4 A8 A12 xxreal_2_th_80 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using xboole_0_def_3 sorry
              qed
              have case2: "r <XXREAL-0R3 infXXREAL-2K2 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
              proof(rule impI)
                assume A13: "r <XXREAL-0R3 ?z"
                have "?z <=XXREAL-0R1 x"
                  using A11 xxreal_2_th_3 sorry
                thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
                  using A7 A13 xxreal_0_th_2 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          have case4: "x inHIDDENR3 B & y inHIDDENR3 B implies r inHIDDENR3 A \\/XBOOLE-0K2 B"
          proof(rule impI)
            assume "x inHIDDENR3 B & y inHIDDENR3 B"
            then have "r inHIDDENR3 B"
              using A2 A7 A8 xxreal_2_th_80 sorry
            thus "r inHIDDENR3 A \\/XBOOLE-0K2 B"
              using xboole_0_def_3 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "A \\/XBOOLE-0K2 B be intervalXXREAL-2V6"
      using xxreal_2_th_84 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_cl_45:
"cluster left-endXXREAL-2V1 also-is  non emptyXBOOLE-0V1 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be left-endXXREAL-2V1 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xxreal_2_cl_46:
"cluster right-endXXREAL-2V2 also-is  non emptyXBOOLE-0V1 for ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
proof
(*coherence*)
  show " for it be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2 holds it be right-endXXREAL-2V2 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem xxreal_2_th_92:
" for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies r <=XXREAL-0R1 -inftyXXREAL-0K2) implies A =MEMBEREDR8 {TARSKIK1 -inftyXXREAL-0K2 }"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies r <=XXREAL-0R1 -inftyXXREAL-0K2) implies (A <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 } implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    assume A1: " for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies r <=XXREAL-0R1 -inftyXXREAL-0K2"
    assume "A <>HIDDENR2 {TARSKIK1 -inftyXXREAL-0K2 }"
    then have " ex a be ElementSUBSET-1M3\<^bsub>(ExtREALXXREAL-0K3)\<^esub>-of A st a <>HIDDENR2 -inftyXXREAL-0K2"
      using setfam_1_th_49 sorry
    thus " False "
      using A1 xxreal_0_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_93:
" for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies +inftyXXREAL-0K1 <=XXREAL-0R1 r) implies A =MEMBEREDR8 {TARSKIK1 +inftyXXREAL-0K1 }"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies +inftyXXREAL-0K1 <=XXREAL-0R1 r) implies (A <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 } implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    assume A1: " for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds r inTARSKIR2 A implies +inftyXXREAL-0K1 <=XXREAL-0R1 r"
    assume "A <>HIDDENR2 {TARSKIK1 +inftyXXREAL-0K1 }"
    then have " ex a be ElementSUBSET-1M3\<^bsub>(ExtREALXXREAL-0K3)\<^esub>-of A st a <>HIDDENR2 +inftyXXREAL-0K1"
      using setfam_1_th_49 sorry
    thus " False "
      using A1 xxreal_0_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_94:
" for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 supXXREAL-2K1 A implies ( ex s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st s inTARSKIR2 A & r <XXREAL-0R3 s)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for r be ExtRealXXREAL-0M1 holds r <XXREAL-0R3 supXXREAL-2K1 A implies (( for s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds s inTARSKIR2 A implies  not r <XXREAL-0R3 s) implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix r assume [ty]: "r be ExtRealXXREAL-0M1"
    assume A1: "r <XXREAL-0R3 supXXREAL-2K1 A"
    assume A2: " for s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds s inTARSKIR2 A implies  not r <XXREAL-0R3 s"
    have "r be UpperBoundXXREAL-2M1-of A"
    proof-
      have " for x be ExtRealXXREAL-0M1 holds x inHIDDENR3 A implies x <=XXREAL-0R1 r"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        assume "x inHIDDENR3 A"
        thus "x <=XXREAL-0R1 r"
          using A2 sorry
      qed "sorry"
      thus "r be UpperBoundXXREAL-2M1-of A"
        using xxreal_2_def_1 sorry
    qed
    thus " False "
      using A1 xxreal_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_95:
" for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds infXXREAL-2K2 A <XXREAL-0R3 r implies ( ex s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st s inTARSKIR2 A & s <XXREAL-0R3 r)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds infXXREAL-2K2 A <XXREAL-0R3 r implies (( for s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds s inTARSKIR2 A implies  not s <XXREAL-0R3 r) implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix r assume [ty]: "r be ElementSUBSET-1M1-of ExtREALXXREAL-0K3"
    assume A1: "infXXREAL-2K2 A <XXREAL-0R3 r"
    assume A2: " for s be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 holds s inTARSKIR2 A implies  not s <XXREAL-0R3 r"
    have "r be LowerBoundXXREAL-2M2-of A"
    proof-
      have " for x be ExtRealXXREAL-0M1 holds  not (x inHIDDENR3 A &  not r <=XXREAL-0R1 x)"
      proof(rule ballI)
        fix x assume [ty]: "x be ExtRealXXREAL-0M1"
        show " not (x inHIDDENR3 A &  not r <=XXREAL-0R1 x)"
          using A2 sorry
      qed "sorry"
      thus "r be LowerBoundXXREAL-2M2-of A"
        using xxreal_2_def_2 sorry
    qed
    thus " False "
      using A1 xxreal_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem xxreal_2_th_96:
" for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r inHIDDENR3 A & s inHIDDENR3 B implies r <=XXREAL-0R1 s) implies supXXREAL-2K1 A <=XXREAL-0R1 infXXREAL-2K2 B"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds  for B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3 holds ( for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r inHIDDENR3 A & s inHIDDENR3 B implies r <=XXREAL-0R1 s) implies ( not supXXREAL-2K1 A <=XXREAL-0R1 infXXREAL-2K2 B implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    fix B assume [ty]: "B be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of ExtREALXXREAL-0K3"
    assume A1: " for r be ExtRealXXREAL-0M1 holds  for s be ExtRealXXREAL-0M1 holds r inHIDDENR3 A & s inHIDDENR3 B implies r <=XXREAL-0R1 s"
    assume " not supXXREAL-2K1 A <=XXREAL-0R1 infXXREAL-2K2 B"
    then obtain s1 where
      [ty]:"s1 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3" and 
      A2: "s1 inTARSKIR2 A"and A3: "infXXREAL-2K2 B <XXREAL-0R3 s1"
      using xxreal_2_th_94 sorry
    have " ex s2 be ElementSUBSET-1M1-of ExtREALXXREAL-0K3 st s2 inTARSKIR2 B & s2 <XXREAL-0R3 s1"
      using A3 xxreal_2_th_95 sorry
    thus " False "
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
