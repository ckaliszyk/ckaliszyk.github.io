theory series_5
  imports series_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d for "positiveXXREAL-0V2\<bar>RealXREAL-0M1"
reserve m, u, w, x, y, z for "RealXREAL-0M1"
reserve n, k for "NatNAT-1M1"
reserve s, s1 for "Real-SequenceSEQ-1M1"
mlemma series_5_lm_1:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "(x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1) =HIDDENR1 ((x *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 y ^2SQUARE-1K1)-XCMPLX-0K6 ((y *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (y *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 y *XCMPLX-0K3 y ^2SQUARE-1K1)"
       sorry
    also have "... = ((x *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 y ^2SQUARE-1K1)-XCMPLX-0K6 ((y *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (y *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 y *XCMPLX-0K3 y ^2SQUARE-1K1)"
      using newton_th_81 sorry
    also have "... = ((x  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 y ^2SQUARE-1K1)-XCMPLX-0K6 ((y *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (y *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 y *XCMPLX-0K3 y ^2SQUARE-1K1)"
      using newton_th_6 sorry
    also have "... = ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 (y *XCMPLX-0K3 y))-XCMPLX-0K6 (y *XCMPLX-0K3 x)*XCMPLX-0K3 y)-XCMPLX-0K6 y *XCMPLX-0K3 y ^2SQUARE-1K1"
       sorry
    also have "... = x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 y"
      using newton_th_81 sorry
    also have "... = x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_6 sorry
    finally have "(x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1) =HIDDENR1 x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
       sorry
    thus "x  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 y  |^NEWTONK1 \<three>\<^sub>M =COMPLEX1R1 (x -XCMPLX-0K6 y)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 y ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_2:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_116 sorry
    also have "... = ((a *XCMPLX-0K3 b)*XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (b +XCMPLX-0K2 a)"
      using xcmplx_1_th_77 sorry
    also have "... = (a *XCMPLX-0K3 b)/XCMPLX-0K7 (b +XCMPLX-0K2 a)"
       sorry
    finally have "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =HIDDENR1 (a *XCMPLX-0K3 b)/XCMPLX-0K7 (b +XCMPLX-0K2 a)"
       sorry
    then have "(\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (b +XCMPLX-0K2 a))"
      using xcmplx_1_th_74 sorry
    thus "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =COMPLEX1R1 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b)"
      using xcmplx_1_th_74 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_3:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    have "((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z)"
      using xcmplx_1_th_102 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
      using xcmplx_1_th_102 sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
       sorry
    thus "((\<one>\<^sub>M /XCMPLX-0K7 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 y))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 z) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 z)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_4:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =COMPLEX1R1 (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =COMPLEX1R1 (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (a /XCMPLX-0K7 c))to-powerPOWERK2 b"
      using power_th_32 sorry
    also have "... = ((c /XCMPLX-0K7 a)*XCMPLX-0K3 \<one>\<^sub>M)to-powerPOWERK2 b"
      using xcmplx_1_th_80 sorry
    also have "... = (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
       sorry
    finally have "(a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =HIDDENR1 (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
       sorry
    thus "(a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 b) =COMPLEX1R1 (c /XCMPLX-0K7 a)to-powerPOWERK2 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_5:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) >=XXREAL-0R2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 (a +XCMPLX-0K2 d)^2SQUARE-1K1"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) >=XXREAL-0R2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 (a +XCMPLX-0K2 d)^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d +XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (((a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d)*XCMPLX-0K3 ((c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a))"
      using sin_cos2_th_1 sorry
    then have "((a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d +XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a)+XCMPLX-0K2 ((a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 d ^2SQUARE-1K1) +XCMPLX-0K2 ((a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1)"
      using xreal_1_th_7 sorry
    then have "(((a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d +XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a)+XCMPLX-0K2 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1 +XCMPLX-0K2 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1"
       sorry
    then have A1: "(((a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d +XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a)+XCMPLX-0K2 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 d) +XCMPLX-0K2 (a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1"
      using square_1_th_22 sorry
    have "((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) =HIDDENR1 (a *XCMPLX-0K3 b +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1)"
      using square_1_def_2 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1)"
      using square_1_def_2 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1)"
      using square_1_def_2 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d)"
      using square_1_def_2 sorry
    also have "... = (((a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d)+XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1"
       sorry
    finally have "((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) =HIDDENR1 (((a ^2SQUARE-1K1 *XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 (a *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 d)+XCMPLX-0K2 (c ^2SQUARE-1K1 *XCMPLX-0K3 d)*XCMPLX-0K3 a)+XCMPLX-0K2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 d ^2SQUARE-1K1"
       sorry
    thus "((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1) >=XXREAL-0R2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 (a +XCMPLX-0K2 d)^2SQUARE-1K1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_6:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((x +XCMPLX-0K2 y)+XCMPLX-0K2 z)^2SQUARE-1K1 =COMPLEX1R1 ((((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 z)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 x"
   sorry

mlemma series_5_lm_7:
" for x be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M implies x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M implies  not x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume " |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
    then have "( |.COMPLEX1K10 x.|)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M ^2SQUARE-1K1"
      using square_1_th_16 sorry
    thus " not x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
      using complex1_th_75 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_8:
" for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M implies  not  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
    then have "sqrtSQUARE-1K3 x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
      using square_1_th_18 square_1_th_27 xreal_1_th_63 sorry
    thus " not  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
      using complex1_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_9:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =COMPLEX1R1 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =COMPLEX1R1 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 ((((((\<two>\<^sub>M ^2SQUARE-1K1 *XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
       sorry
    also have "... = ((((((\<two>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)*XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using newton_th_81 sorry
    also have "... = (((((\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using newton_th_6 sorry
    also have "... = ((((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c)))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
       sorry
    also have "... = ((((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 ((b *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 c)))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using square_1_th_29 sorry
    also have "... = (((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 (sqrtSQUARE-1K3 (((b *XCMPLX-0K3 c)*XCMPLX-0K3 a)*XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))"
       sorry
    also have "... = (((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 ((((b *XCMPLX-0K3 c)*XCMPLX-0K3 a)*XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 b))"
      using square_1_th_29 sorry
    also have "... = (((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)^2SQUARE-1K1"
       sorry
    also have "... = (((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using square_1_th_22 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 a))*XCMPLX-0K3 (b ^2SQUARE-1K1 *XCMPLX-0K3 b))*XCMPLX-0K3 (c ^2SQUARE-1K1 *XCMPLX-0K3 c)"
       sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (b ^2SQUARE-1K1 *XCMPLX-0K3 b))*XCMPLX-0K3 (c ^2SQUARE-1K1 *XCMPLX-0K3 c)"
      using newton_th_81 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (c ^2SQUARE-1K1 *XCMPLX-0K3 c)"
      using newton_th_81 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a))*XCMPLX-0K3 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)"
      using newton_th_81 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 (c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)"
      using newton_th_6 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 (c  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)"
      using newton_th_6 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 c  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a) |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 c  |^NEWTONK1 \<three>\<^sub>M"
      using newton_th_7 sorry
    also have "... = ((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 c  |^NEWTONK1 \<three>\<^sub>M"
      using newton_th_7 sorry
    also have "... = (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
      using newton_th_7 sorry
    finally have "(((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =HIDDENR1 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
       sorry
    thus "(((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) =COMPLEX1R1 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_10:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 (sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b))^2SQUARE-1K1"
       sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1"
      using square_1_def_2 sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1"
       sorry
    have A2: "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "sqrtSQUARE-1K3 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1))^2SQUARE-1K1 =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using A1 square_1_th_22 sorry
    thus "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using A2 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_11:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b"
      using series_3_th_6 sorry
    then have "(a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using xreal_1_th_6 sorry
    then have "sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) >=XXREAL-0R2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using square_1_th_26 sorry
    then have A1: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<four>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) >=XXREAL-0R2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using xreal_1_th_64 sorry
    have "sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) =COMPLEX1R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)^2SQUARE-1K1)"
       sorry
    then have "sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 \<three>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a +XCMPLX-0K2 b)^2SQUARE-1K1"
      using square_1_th_29 sorry
    also have "... = sqrtSQUARE-1K3 \<three>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using square_1_th_22 sorry
    finally have "sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 (\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b) =HIDDENR1 sqrtSQUARE-1K3 \<three>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
       sorry
    thus "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using A1 series_5_lm_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_12:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 a *XCMPLX-0K3 b"
      using series_3_th_7 sorry
    then have "(a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 a *XCMPLX-0K3 b +XCMPLX-0K2 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    then have "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M >=XXREAL-0R2 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M"
      using xreal_1_th_72 sorry
    thus "sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using square_1_th_26 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_13:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)"
      using series_3_th_6 sorry
    then have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))"
       sorry
    then have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 c)*XCMPLX-0K3 (c *XCMPLX-0K3 a))/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_76 sorry
    then have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 a)*XCMPLX-0K3 (c *XCMPLX-0K3 c))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 \<one>\<^sub>M))"
       sorry
    then have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 c)/XCMPLX-0K7 \<one>\<^sub>M)"
      using xcmplx_1_th_91 sorry
    thus "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_14:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =COMPLEX1R1 c ^2SQUARE-1K1"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =COMPLEX1R1 c ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =HIDDENR1 ((b *XCMPLX-0K3 c)*XCMPLX-0K3 (c *XCMPLX-0K3 a))/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_76 sorry
    also have "... = ((c *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    also have "... = (c *XCMPLX-0K3 c)*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_74 sorry
    also have "... = (c *XCMPLX-0K3 c)*XCMPLX-0K3 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    finally have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =HIDDENR1 (c *XCMPLX-0K3 c)*XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) =COMPLEX1R1 c ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_15:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =HIDDENR1 (\<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)"
       sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)"
      using series_5_lm_14 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))"
      using series_5_lm_14 sorry
    also have "... = (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1"
      using series_5_lm_14 sorry
    also have "... = \<two>\<^sub>M *XCMPLX-0K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 a ^2SQUARE-1K1)"
       sorry
    finally have "((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 a ^2SQUARE-1K1)"
       sorry
    thus "((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c) =COMPLEX1R1 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_16:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =COMPLEX1R1 ((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =COMPLEX1R1 ((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =HIDDENR1 ((((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1)+XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c))"
       sorry
    also have "... = ((((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1)+XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using series_5_lm_15 sorry
    finally have "(((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =HIDDENR1 ((((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1)+XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
       sorry
    thus "(((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 =COMPLEX1R1 ((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_17:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M"
    then have "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 (b +XCMPLX-0K2 c))/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    also have "... = (a /XCMPLX-0K7 a +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)-XCMPLX-0K6 \<one>\<^sub>M"
      using xcmplx_1_th_62 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)-XCMPLX-0K6 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    finally have "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    thus "\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_18:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =COMPLEX1R1 \<eight>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =COMPLEX1R1 \<eight>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =HIDDENR1 (((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c)))/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c)"
      using xcmplx_1_th_76 sorry
    also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c)))/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c)"
       sorry
    also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((b *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 c)))/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c)"
      using square_1_th_29 sorry
    also have "... = ((\<four>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((b *XCMPLX-0K3 a)*XCMPLX-0K3 c ^2SQUARE-1K1))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using xcmplx_1_th_76 sorry
    also have "... = (\<eight>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 ((b *XCMPLX-0K3 a)*XCMPLX-0K3 c ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
       sorry
    also have "... = (\<eight>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (((b *XCMPLX-0K3 a)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 (a *XCMPLX-0K3 b)))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using square_1_th_29 sorry
    also have "... = (\<eight>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)^2SQUARE-1K1)/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
       sorry
    also have "... = (\<eight>\<^sub>M *XCMPLX-0K3 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using square_1_th_22 sorry
    also have "... = \<eight>\<^sub>M *XCMPLX-0K3 (((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c))"
      using xcmplx_1_th_74 sorry
    also have "... = \<eight>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    finally have "(((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =HIDDENR1 \<eight>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
       sorry
    thus "(((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c) =COMPLEX1R1 \<eight>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_19:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M"
    then have "\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 (b +XCMPLX-0K2 c))/XCMPLX-0K7 a"
       sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 (a /XCMPLX-0K7 a +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)"
      using xcmplx_1_th_62 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 a /XCMPLX-0K7 a)+XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
       sorry
    also have "... = (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
      using xcmplx_1_th_60 sorry
    finally have "\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =HIDDENR1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
       sorry
    thus "\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_20:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) +XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (b *XCMPLX-0K3 c)"
      using xcmplx_1_th_76 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 b)) /XCMPLX-0K7 (b *XCMPLX-0K3 c)"
      using square_1_th_29 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 *XCMPLX-0K3 (c *XCMPLX-0K3 b)) /XCMPLX-0K7 (b *XCMPLX-0K3 c)"
       sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (c *XCMPLX-0K3 b))/XCMPLX-0K7 (b *XCMPLX-0K3 c)"
      using square_1_th_29 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (c *XCMPLX-0K3 b))/XCMPLX-0K7 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))^2SQUARE-1K1"
      using square_1_def_2 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 b) /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))"
      using xcmplx_1_th_76 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 (sqrtSQUARE-1K3 a ^2SQUARE-1K1 /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<one>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    also have "... = sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
      using square_1_th_22 sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
       sorry
    thus "(\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_21:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A2: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using xcmplx_1_th_76 sorry
    also have "... = sqrtSQUARE-1K3 ((b *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 b)) /XCMPLX-0K7 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_29 sorry
    also have "... = sqrtSQUARE-1K3 ((a *XCMPLX-0K3 c)*XCMPLX-0K3 b ^2SQUARE-1K1) /XCMPLX-0K7 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 b ^2SQUARE-1K1)/XCMPLX-0K7 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_29 sorry
    also have "... = (sqrtSQUARE-1K3 b ^2SQUARE-1K1 *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_def_2 sorry
    also have "... = (sqrtSQUARE-1K3 b ^2SQUARE-1K1 /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c)) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using xcmplx_1_th_76 sorry
    also have "... = (sqrtSQUARE-1K3 b ^2SQUARE-1K1 /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using A1 xcmplx_1_th_60 sorry
    also have "... = b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_22 sorry
    also have "... = b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 (c /XCMPLX-0K7 c)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))"
      using xcmplx_1_th_85 sorry
    also have "... = b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))"
      using xcmplx_1_th_60 sorry
    also have "... = b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
      using A2 xcmplx_1_th_60 sorry
    finally have "(sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    thus "(sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_22:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 (((\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using xcmplx_1_th_76 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b *XCMPLX-0K3 c)*XCMPLX-0K3 (a *XCMPLX-0K3 c)) /XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_29 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b *XCMPLX-0K3 a)*XCMPLX-0K3 c ^2SQUARE-1K1) /XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) *XCMPLX-0K3 sqrtSQUARE-1K3 c ^2SQUARE-1K1)/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_29 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) *XCMPLX-0K3 c)/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_th_22 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) *XCMPLX-0K3 c)/XCMPLX-0K7 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using square_1_def_2 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a)))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using xcmplx_1_th_76 sorry
    also have "... = (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 (c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a)))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using A1 xcmplx_1_th_60 sorry
    also have "... = ((((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
       sorry
    also have "... = ((((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using series_5_lm_20 sorry
    also have "... = (((((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 (b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 \<one>\<^sub>M)"
      using series_5_lm_21 sorry
    also have "... = (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
       sorry
    finally have "((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =HIDDENR1 (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
       sorry
    thus "((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c) =COMPLEX1R1 (((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma series_5_lm_23:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<six>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<six>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have A1: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >=XXREAL-0R2 \<two>\<^sub>M"
      using series_3_th_3 sorry
    have "sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have A2: "a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M"
      using series_3_th_3 sorry
    have "sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a) >=XXREAL-0R2 \<two>\<^sub>M"
      using series_3_th_3 sorry
    then have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a)) >=XXREAL-0R2 \<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using A1 xreal_1_th_7 sorry
    then have "(((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 (a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a) >=XXREAL-0R2 \<four>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using A2 xreal_1_th_7 sorry
    thus "((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<six>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_1:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<four>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<four>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a /XCMPLX-0K7 b)*XCMPLX-0K3 (b /XCMPLX-0K7 a))"
      using sin_cos2_th_1 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (b *XCMPLX-0K3 a))"
      using xcmplx_1_th_76 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (((a /XCMPLX-0K7 b)*XCMPLX-0K3 b)/XCMPLX-0K7 a)"
      using xcmplx_1_th_83 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 a)"
      using xcmplx_1_th_87 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using square_1_th_18 xcmplx_1_th_60 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 \<two>\<^sub>M >=XXREAL-0R2 \<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using xreal_1_th_7 sorry
    then have "((a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M"
       sorry
    then have "((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b) +XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M"
      using xcmplx_1_th_99 sorry
    then have "((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b) +XCMPLX-0K2 b *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))+XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M"
      using xcmplx_1_th_99 sorry
    then have "((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b) +XCMPLX-0K2 b *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))+XCMPLX-0K2 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))+XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M"
      using xcmplx_1_th_106 sorry
    then have "((a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b) +XCMPLX-0K2 b *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))+XCMPLX-0K2 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a))+XCMPLX-0K2 b *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<four>\<^sub>M"
      using xcmplx_1_th_106 sorry
    thus "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 \<four>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_2:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M >=XXREAL-0R2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M >=XXREAL-0R2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(a -XCMPLX-0K6 b)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "((a -XCMPLX-0K6 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b))*XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    then have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 ((a -XCMPLX-0K6 b)*XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    then have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a  |^NEWTONK1 \<three>\<^sub>M -XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M) >=XXREAL-0R2 0NUMBERSK6"
      using series_5_lm_1 sorry
    then have "(a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    then have "(a  |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 (a -XCMPLX-0K6 b) >=XXREAL-0R2 0NUMBERSK6"
      using newton_th_6 sorry
    then have "(a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b) >=XXREAL-0R2 0NUMBERSK6"
       sorry
    then have "(a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 (b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b  |^NEWTONK1 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) >=XXREAL-0R2 0NUMBERSK6"
      using newton_th_6 sorry
    then have "(((a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)-XCMPLX-0K6 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a) >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a)"
      using xreal_1_th_7 sorry
    thus "a  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M >=XXREAL-0R2 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_3:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies \<one>\<^sub>M <XXREAL-0R3 (b +XCMPLX-0K2 c)/XCMPLX-0K7 (a +XCMPLX-0K2 c)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not \<one>\<^sub>M <XXREAL-0R3 (b +XCMPLX-0K2 c)/XCMPLX-0K7 (a +XCMPLX-0K2 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume "a <XXREAL-0R3 b"
    then have "a +XCMPLX-0K2 c <XXREAL-0R3 b +XCMPLX-0K2 c"
      using xreal_1_th_8 sorry
    thus " not \<one>\<^sub>M <XXREAL-0R3 (b +XCMPLX-0K2 c)/XCMPLX-0K7 (a +XCMPLX-0K2 c)"
      using xreal_1_th_187 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_4:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not a /XCMPLX-0K7 b <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "b ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have "b  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using newton_th_81 sorry
    then have "b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A1: "b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using newton_th_6 sorry
    assume "a <XXREAL-0R3 b"
    then have "a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
      using xreal_1_th_49 sorry
    then have "(a *XCMPLX-0K3 b)*XCMPLX-0K3 (a -XCMPLX-0K6 b) <XXREAL-0R3 0NUMBERSK6"
       sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b -XCMPLX-0K6 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1 <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1"
      using xreal_1_th_8 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b)/XCMPLX-0K7 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A1 xreal_1_th_74 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b)/XCMPLX-0K7 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b) <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_6 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b)/XCMPLX-0K7 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b) <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)"
      using newton_th_6 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b)/XCMPLX-0K7 (b ^2SQUARE-1K1 *XCMPLX-0K3 b) <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)"
      using newton_th_81 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 b)/XCMPLX-0K7 (b ^2SQUARE-1K1 *XCMPLX-0K3 b) <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 (b ^2SQUARE-1K1 *XCMPLX-0K3 b)"
      using newton_th_81 sorry
    then have "a ^2SQUARE-1K1 /XCMPLX-0K7 b ^2SQUARE-1K1 <XXREAL-0R3 (a *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 (b *XCMPLX-0K3 b ^2SQUARE-1K1)"
      using xcmplx_1_th_91 sorry
    then have "a ^2SQUARE-1K1 /XCMPLX-0K7 b ^2SQUARE-1K1 <XXREAL-0R3 a /XCMPLX-0K7 b"
      using xcmplx_1_th_91 sorry
    then have "(a /XCMPLX-0K7 b)^2SQUARE-1K1 <XXREAL-0R3 a /XCMPLX-0K7 b"
      using xcmplx_1_th_76 sorry
    then have "sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)^2SQUARE-1K1 <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
      using square_1_th_27 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
      using square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_5:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
    then have "a /XCMPLX-0K7 b <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_189 sorry
    then have A2: "sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 \<one>\<^sub>M"
      using square_1_th_18 square_1_th_27 sorry
    have "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "\<one>\<^sub>M <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
      using A1 series_5_th_3 sorry
    thus " not sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_6:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies a /XCMPLX-0K7 b <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a <XXREAL-0R3 b implies  not a /XCMPLX-0K7 b <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a <XXREAL-0R3 b"
    then have A2: "sqrtSQUARE-1K3 (a /XCMPLX-0K7 b) <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
      using series_5_th_5 sorry
    have "a /XCMPLX-0K7 b <XXREAL-0R3 sqrtSQUARE-1K3 (a /XCMPLX-0K7 b)"
      using A1 series_5_th_4 sorry
    thus " not a /XCMPLX-0K7 b <XXREAL-0R3 (b +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))/XCMPLX-0K7 (a +XCMPLX-0K2 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_7:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b) <=XXREAL-0R1 \<one>\<^sub>M"
      using sin_cos2_th_1 xreal_1_th_183 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using A1 xreal_1_th_64 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_82 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_77 sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1)/XCMPLX-0K7 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
       sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a +XCMPLX-0K2 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using square_1_def_2 sorry
    thus "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using series_5_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_8:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b"
      using series_3_th_6 sorry
    then have "(a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b +XCMPLX-0K2 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)"
      using xreal_1_th_7 sorry
    then have "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)) >=XXREAL-0R2 sqrtSQUARE-1K3 (a +XCMPLX-0K2 b)^2SQUARE-1K1"
      using square_1_th_26 sorry
    then have "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)) >=XXREAL-0R2 a +XCMPLX-0K2 b"
      using square_1_th_22 sorry
    then have "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)) /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M) >=XXREAL-0R2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_th_20 xreal_1_th_72 sorry
    then have "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)) /XCMPLX-0K7 (sqrtSQUARE-1K3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 \<two>\<^sub>M) >=XXREAL-0R2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_th_29 sorry
    then have "(sqrtSQUARE-1K3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 (sqrtSQUARE-1K3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 \<two>\<^sub>M) >=XXREAL-0R2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_th_29 sorry
    then have A1: "((sqrtSQUARE-1K3 \<two>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<two>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using xcmplx_1_th_83 sorry
    have "sqrtSQUARE-1K3 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "(\<one>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<two>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    thus "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using square_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_9:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    have "x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y"
      using series_3_th_6 sorry
    then have A1: "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y +XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    then have A2: "\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1) >=XXREAL-0R2 (x +XCMPLX-0K2 y)^2SQUARE-1K1"
       sorry
    have A3: "(x +XCMPLX-0K2 y)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A4: "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)) >=XXREAL-0R2 sqrtSQUARE-1K3 (x +XCMPLX-0K2 y)^2SQUARE-1K1"
      using A1 square_1_th_26 sorry
    show "x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
    proof-
      have cases: "(x +XCMPLX-0K2 y >XXREAL-0R4 0NUMBERSK6 or x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6) or x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "x +XCMPLX-0K2 y >XXREAL-0R4 0NUMBERSK6 implies x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
      proof(rule impI)
        assume "x +XCMPLX-0K2 y >XXREAL-0R4 0NUMBERSK6"
        thus "x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
          using A4 square_1_th_22 sorry
      qed
      have case2: "x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6 implies x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
      proof(rule impI)
        assume "x +XCMPLX-0K2 y =COMPLEX1R1 0NUMBERSK6"
        thus "x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
          using A2 square_1_th_17 square_1_th_26 sorry
      qed
      have case3: "x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6 implies x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
      proof(rule impI)
        assume "x +XCMPLX-0K2 y <XXREAL-0R3 0NUMBERSK6"
        thus "x +XCMPLX-0K2 y <=XXREAL-0R1 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))"
          using A1 A3 square_1_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_10:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using series_3_th_2 sorry
    have "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using series_5_th_7 sorry
    thus "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_11:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using series_3_th_2 sorry
    have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using series_5_th_8 sorry
    thus "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_12:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds \<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 (a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M"
      using series_5_th_10 sorry
    have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using series_5_th_8 sorry
    thus "\<two>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_13:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M &  |.COMPLEX1K10 y.| <XXREAL-0R3 \<one>\<^sub>M implies  |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M &  |.COMPLEX1K10 y.| <XXREAL-0R3 \<one>\<^sub>M implies  |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume A1: " |.COMPLEX1K10 x.| <XXREAL-0R3 \<one>\<^sub>M"
      and A2: " |.COMPLEX1K10 y.| <XXREAL-0R3 \<one>\<^sub>M"
    show " |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
    proof-
      have cases: "\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y <>HIDDENR2 0NUMBERSK6 or \<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y <>HIDDENR2 0NUMBERSK6 implies  |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume A3: "\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y <>HIDDENR2 0NUMBERSK6"
        have "y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
          using A2 series_5_lm_7 sorry
        then have A4: "y ^2SQUARE-1K1 -XCMPLX-0K6 y ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 y ^2SQUARE-1K1"
          using xreal_1_th_14 sorry
        have "x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
          using A1 series_5_lm_7 sorry
        then have "x ^2SQUARE-1K1 -XCMPLX-0K6 x ^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1"
          using xreal_1_th_14 sorry
        then have "0NUMBERSK6 <XXREAL-0R3 (\<one>\<^sub>M -XCMPLX-0K6 x ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 y ^2SQUARE-1K1)"
          using A4 sorry
        then have "0NUMBERSK6 +XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1) <XXREAL-0R3 (((\<one>\<^sub>M -XCMPLX-0K6 y ^2SQUARE-1K1)-XCMPLX-0K6 x ^2SQUARE-1K1)+XCMPLX-0K2 x ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
          using xreal_1_th_8 sorry
        then have A5: "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y"
          using xreal_1_th_8 sorry
        have "(\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y)^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
          using A3 square_1_th_12 sorry
        then have "(x +XCMPLX-0K2 y)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y)^2SQUARE-1K1 <XXREAL-0R3 (x *XCMPLX-0K3 y +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y)^2SQUARE-1K1"
          using A5 xreal_1_th_74 sorry
        then have "(x +XCMPLX-0K2 y)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
          using A3 xcmplx_1_th_60 sorry
        then have "((x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y))^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M"
          using xcmplx_1_th_76 sorry
        thus " |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
          using series_5_lm_8 sorry
      qed
      have case2: "\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6 implies  |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6"
        then have " |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| =HIDDENR1  |.COMPLEX1K10 0NUMBERSK6 .|"
          using xcmplx_1_th_49 sorry
        also have "... = 0NUMBERSK6"
          using absvalue_th_2 sorry
        finally have " |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| =HIDDENR1 0NUMBERSK6"
           sorry
        thus " |.COMPLEX1K10 (x +XCMPLX-0K2 y)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 x *XCMPLX-0K3 y) .| <=XXREAL-0R1 \<one>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_14:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    show "( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
    proof-
      have cases: " |.COMPLEX1K10 x +XCMPLX-0K2 y .| =COMPLEX1R1 0NUMBERSK6 or  |.COMPLEX1K10 x +XCMPLX-0K2 y .| >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: " |.COMPLEX1K10 x +XCMPLX-0K2 y .| =COMPLEX1R1 0NUMBERSK6 implies ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
      proof(rule impI)
        assume " |.COMPLEX1K10 x +XCMPLX-0K2 y .| =COMPLEX1R1 0NUMBERSK6"
        thus "( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
           sorry
      qed
      have case2: " |.COMPLEX1K10 x +XCMPLX-0K2 y .| >XXREAL-0R4 0NUMBERSK6 implies ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
      proof(rule impI)
        assume A1: " |.COMPLEX1K10 x +XCMPLX-0K2 y .| >XXREAL-0R4 0NUMBERSK6"
        have "\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.| >=XXREAL-0R2 \<one>\<^sub>M"
          using xreal_1_th_31 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)+XCMPLX-0K2  |.COMPLEX1K10 x.| >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|"
          using xreal_1_th_6 sorry
        then have A2: "( |.COMPLEX1K10 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)"
          using xreal_1_th_118 sorry
        have "\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.| >=XXREAL-0R2 \<one>\<^sub>M"
          using xreal_1_th_31 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.| >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|"
          using xreal_1_th_6 sorry
        then have "( |.COMPLEX1K10 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) <=XXREAL-0R1 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
          using xreal_1_th_118 sorry
        then have A3: "( |.COMPLEX1K10 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
          using A2 xreal_1_th_7 sorry
        have "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)"
          using A1 complex1_th_56 xreal_1_th_118 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|) +XCMPLX-0K2 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        then have A4: "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|) +XCMPLX-0K2 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 \<one>\<^sub>M)"
          using xreal_1_th_118 sorry
        have A5: "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|"
          using A1 complex1_th_56 sorry
        then have A6: "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|))/XCMPLX-0K7 ((\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|))"
          using xcmplx_1_th_91 sorry
        also have "... = ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|))*XCMPLX-0K3 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|))"
           sorry
        also have "... = ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|))"
          using A5 xcmplx_1_th_87 sorry
        also have "... = ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|)"
          using xcmplx_1_th_62 sorry
        finally have "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x.| +XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|)+XCMPLX-0K2  |.COMPLEX1K10 y.|)"
           sorry
        have "( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) =HIDDENR1 (( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|))/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|))"
          using A1 xcmplx_1_th_55 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|))"
          using A1 xcmplx_1_th_60 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|) +XCMPLX-0K2 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|))"
          using xcmplx_1_th_62 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|) +XCMPLX-0K2 \<one>\<^sub>M)"
          using A1 xcmplx_1_th_60 sorry
        finally have "( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ( |.COMPLEX1K10 x +XCMPLX-0K2 y .|) +XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        thus "( |.COMPLEX1K10 x +XCMPLX-0K2 y .|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x +XCMPLX-0K2 y .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 x.|) +XCMPLX-0K2 ( |.COMPLEX1K10 y.|)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2  |.COMPLEX1K10 y.|)"
          using A4 A6 A3 xxreal_0_th_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_15:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  not ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "d +XCMPLX-0K2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xreal_1_th_8 sorry
    then have A1: "b /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xreal_1_th_76 sorry
    have "((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)+XCMPLX-0K2 a >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_8 sorry
    then have A2: "c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 c /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_76 sorry
    have "c +XCMPLX-0K2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d)"
      using xreal_1_th_8 sorry
    then have "a /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d)"
      using xreal_1_th_76 sorry
    then have "a /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using A1 xreal_1_th_8 sorry
    then have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xcmplx_1_th_62 sorry
    then have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) +XCMPLX-0K2 c /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 (a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using A2 xreal_1_th_8 sorry
    then have A3: "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 (a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xcmplx_1_th_62 sorry
    have "b +XCMPLX-0K2 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_8 sorry
    then have "d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 d /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_76 sorry
    then have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) +XCMPLX-0K2 d /XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using A3 xreal_1_th_8 sorry
    then have "(((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d)/XCMPLX-0K7 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xcmplx_1_th_62 sorry
    thus " not ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_16:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 \<two>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  not ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "b /XCMPLX-0K7 (a +XCMPLX-0K2 b) >XXREAL-0R4 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xreal_1_th_29 xreal_1_th_76 sorry
    have "a /XCMPLX-0K7 (a +XCMPLX-0K2 b) >XXREAL-0R4 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d)"
      using xreal_1_th_29 xreal_1_th_76 sorry
    then have "a /XCMPLX-0K7 (a +XCMPLX-0K2 b) +XCMPLX-0K2 b /XCMPLX-0K7 (a +XCMPLX-0K2 b) >XXREAL-0R4 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using A1 xreal_1_th_8 sorry
    then have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 (a +XCMPLX-0K2 b) >XXREAL-0R4 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xcmplx_1_th_62 sorry
    then have A2: "\<one>\<^sub>M >XXREAL-0R4 a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xcmplx_1_th_60 sorry
    have "a +XCMPLX-0K2 (c +XCMPLX-0K2 d) >XXREAL-0R4 c +XCMPLX-0K2 d"
      using xreal_1_th_29 sorry
    then have A3: "d /XCMPLX-0K7 (c +XCMPLX-0K2 d) >XXREAL-0R4 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_76 sorry
    have "b +XCMPLX-0K2 (c +XCMPLX-0K2 d) >XXREAL-0R4 c +XCMPLX-0K2 d"
      using xreal_1_th_29 sorry
    then have "c /XCMPLX-0K7 (c +XCMPLX-0K2 d) >XXREAL-0R4 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xreal_1_th_76 sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 c /XCMPLX-0K7 (c +XCMPLX-0K2 d) >XXREAL-0R4 (a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using A2 xreal_1_th_8 sorry
    then have "(\<one>\<^sub>M +XCMPLX-0K2 c /XCMPLX-0K7 (c +XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 (c +XCMPLX-0K2 d) >XXREAL-0R4 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using A3 xreal_1_th_8 sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 (c /XCMPLX-0K7 (c +XCMPLX-0K2 d) +XCMPLX-0K2 d /XCMPLX-0K7 (c +XCMPLX-0K2 d)) >XXREAL-0R4 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
       sorry
    then have "\<one>\<^sub>M +XCMPLX-0K2 (c +XCMPLX-0K2 d)/XCMPLX-0K7 (c +XCMPLX-0K2 d) >XXREAL-0R4 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xcmplx_1_th_62 sorry
    then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d)"
      using xcmplx_1_th_60 sorry
    thus " not ((a /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 d) +XCMPLX-0K2 b /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))+XCMPLX-0K2 c /XCMPLX-0K7 ((b +XCMPLX-0K2 c)+XCMPLX-0K2 d))+XCMPLX-0K2 d /XCMPLX-0K7 ((a +XCMPLX-0K2 c)+XCMPLX-0K2 d) <XXREAL-0R3 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_17:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b >XXREAL-0R4 c & b +XCMPLX-0K2 c >XXREAL-0R4 a) & a +XCMPLX-0K2 c >XXREAL-0R4 b implies (\<one>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((b +XCMPLX-0K2 c)-XCMPLX-0K6 a))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b) >=XXREAL-0R2 \<nine>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b >XXREAL-0R4 c & (b +XCMPLX-0K2 c >XXREAL-0R4 a & a +XCMPLX-0K2 c >XXREAL-0R4 b) implies (\<one>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((b +XCMPLX-0K2 c)-XCMPLX-0K6 a))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b) >=XXREAL-0R2 \<nine>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a +XCMPLX-0K2 b >XXREAL-0R4 c"
      and A2: "b +XCMPLX-0K2 c >XXREAL-0R4 a"
      and A3: "a +XCMPLX-0K2 c >XXREAL-0R4 b"
    have A4: "(a +XCMPLX-0K2 c)-XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
      using A3 xreal_1_th_50 sorry
    let ?f = "(c +XCMPLX-0K2 a)-XCMPLX-0K6 b"
    let ?e = "(b +XCMPLX-0K2 c)-XCMPLX-0K6 a"
    let ?d = "(a +XCMPLX-0K2 b)-XCMPLX-0K6 c"
    have A5: "(b +XCMPLX-0K2 c)-XCMPLX-0K6 a >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_th_50 sorry
    have A6: "(a +XCMPLX-0K2 b)-XCMPLX-0K6 c >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have A7: "(?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)"
      using A5 A4 series_3_th_15 sorry
    have "(\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((\<one>\<^sub>M /XCMPLX-0K7 ?d)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ?e))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ?f))"
      using A6 A5 A4 series_3_th_15 sorry
    then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f))"
      using series_5_lm_3 sorry
    have A9: "\<three>\<^sub>M -rootPOWERK1 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f) >=XXREAL-0R2 0NUMBERSK6"
      using A6 A5 A4 power_th_7 sorry
    have "\<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)) >=XXREAL-0R2 0NUMBERSK6"
      using A6 A5 A4 power_th_7 sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 (\<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f))*XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)))"
      using A7 A9 A8 xreal_1_th_66 sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f) *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)))"
       sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)))"
      using A6 A5 A4 power_th_11 sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)/XCMPLX-0K7 (((?d *XCMPLX-0K3 ?e)*XCMPLX-0K3 ?f)/XCMPLX-0K7 \<one>\<^sub>M))"
      using xcmplx_1_th_79 sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 \<one>\<^sub>M"
      using A6 A5 A4 xcmplx_1_th_60 sorry
    then have "((?d +XCMPLX-0K2 ?e)+XCMPLX-0K2 ?f)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 ?d +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?e)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ?f) >=XXREAL-0R2 \<nine>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using power_th_6 sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((b +XCMPLX-0K2 c)-XCMPLX-0K6 a))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b) >=XXREAL-0R2 \<nine>\<^sub>M /XCMPLX-0K7 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)"
      using xreal_1_th_79 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_18:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)) >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)) >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A2: "sqrtSQUARE-1K3 (b *XCMPLX-0K3 d) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "a *XCMPLX-0K3 d +XCMPLX-0K2 b *XCMPLX-0K3 c >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c))"
      using sin_cos2_th_1 sorry
    then have "(a *XCMPLX-0K3 d +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c)) +XCMPLX-0K2 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d)"
      using xreal_1_th_7 sorry
    then have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c)) +XCMPLX-0K2 a *XCMPLX-0K3 c)+XCMPLX-0K2 b *XCMPLX-0K3 d"
       sorry
    then have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c)) +XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 d"
      using square_1_def_2 sorry
    then have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c)) +XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1"
      using square_1_def_2 sorry
    then have "(sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)))^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 c)*XCMPLX-0K3 (b *XCMPLX-0K3 d)) +XCMPLX-0K2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1)+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1"
      using square_1_def_2 sorry
    then have A3: "(sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)))^2SQUARE-1K1 >=XXREAL-0R2 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)))+XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1"
      using square_1_th_29 sorry
    have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A4: "sqrtSQUARE-1K3 (sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)))^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1"
      using A3 square_1_th_26 sorry
    have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "sqrtSQUARE-1K3 (sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)))^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)"
      using A4 A2 square_1_th_22 sorry
    thus "sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)*XCMPLX-0K3 (c +XCMPLX-0K2 d)) >=XXREAL-0R2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 d)"
      using A1 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_19:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 d"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 d) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "(a +XCMPLX-0K2 d)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 d))^2SQUARE-1K1"
      using sin_cos2_th_1 square_1_th_15 sorry
    then have "(a +XCMPLX-0K2 d)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M ^2SQUARE-1K1 *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 d))^2SQUARE-1K1"
       sorry
    then have "(a +XCMPLX-0K2 d)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)*XCMPLX-0K3 (a *XCMPLX-0K3 d)"
      using square_1_def_2 sorry
    then have A1: "(a +XCMPLX-0K2 d)^2SQUARE-1K1 *XCMPLX-0K3 (b *XCMPLX-0K3 c) >=XXREAL-0R2 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 d)*XCMPLX-0K3 (b *XCMPLX-0K3 c)"
      using xreal_1_th_64 sorry
    have "(a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) =HIDDENR1 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d)"
      using square_1_def_2 sorry
    also have "... = ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d)"
      using square_1_def_2 sorry
    also have "... = ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 d)"
      using square_1_def_2 sorry
    also have "... = ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1)"
      using square_1_def_2 sorry
    finally have "(a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) =HIDDENR1 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (c *XCMPLX-0K3 d))^2SQUARE-1K1)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 d))^2SQUARE-1K1)"
       sorry
    then have "(a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 (b *XCMPLX-0K3 c)*XCMPLX-0K3 (a +XCMPLX-0K2 d)^2SQUARE-1K1"
      using series_5_lm_5 sorry
    thus "(a *XCMPLX-0K3 b +XCMPLX-0K2 c *XCMPLX-0K3 d)*XCMPLX-0K3 (a *XCMPLX-0K3 c +XCMPLX-0K2 b *XCMPLX-0K3 d) >=XXREAL-0R2 (((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 d"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_20:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((a /XCMPLX-0K7 b)*XCMPLX-0K3 (b /XCMPLX-0K7 c))*XCMPLX-0K3 (c /XCMPLX-0K7 a))"
      using series_3_th_15 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((a *XCMPLX-0K3 b)/XCMPLX-0K7 (b *XCMPLX-0K3 c))*XCMPLX-0K3 (c /XCMPLX-0K7 a))"
      using xcmplx_1_th_76 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((a /XCMPLX-0K7 c)*XCMPLX-0K3 (c /XCMPLX-0K7 a))"
      using xcmplx_1_th_91 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 c)/XCMPLX-0K7 (c *XCMPLX-0K3 a))"
      using xcmplx_1_th_76 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    then have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using power_th_6 sorry
    thus "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_21:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 a =COMPLEX1R1 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 sqrtSQUARE-1K3 \<three>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 a =COMPLEX1R1 \<one>\<^sub>M implies (a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 sqrtSQUARE-1K3 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "(a *XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c *XCMPLX-0K3 a =COMPLEX1R1 \<one>\<^sub>M"
    then have "(a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M"
      using series_3_th_10 sorry
    then have "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    then have "sqrtSQUARE-1K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 \<three>\<^sub>M"
      using A1 square_1_th_26 sorry
    thus "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 sqrtSQUARE-1K3 \<three>\<^sub>M"
      using square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_22:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M"
      using series_5_th_20 sorry
    have "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a >=XXREAL-0R2 \<three>\<^sub>M"
      using series_5_th_20 sorry
    then have "((a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 ((b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c) >=XXREAL-0R2 \<three>\<^sub>M +NAT-1K1 \<three>\<^sub>M"
      using A1 xreal_1_th_7 sorry
    then have A2: "(((((a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M >=XXREAL-0R2 \<six>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M"
      using xreal_1_th_9 sorry
    have "(((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c =HIDDENR1 (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 a /XCMPLX-0K7 a)+XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c"
      using xcmplx_1_th_120 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c"
      using xcmplx_1_th_60 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((c +XCMPLX-0K2 a)/XCMPLX-0K7 b -XCMPLX-0K6 b /XCMPLX-0K7 b))+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c"
      using xcmplx_1_th_120 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((c +XCMPLX-0K2 a)/XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c"
      using xcmplx_1_th_60 sorry
    also have "... = ((((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (c +XCMPLX-0K2 a)/XCMPLX-0K7 b)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 c -XCMPLX-0K6 c /XCMPLX-0K7 c)"
      using xcmplx_1_th_120 sorry
    also have "... = ((((b +XCMPLX-0K2 c)/XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 (c +XCMPLX-0K2 a)/XCMPLX-0K7 b)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M)"
      using xcmplx_1_th_60 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c +XCMPLX-0K2 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M"
       sorry
    also have "... = (((b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 (c +XCMPLX-0K2 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M"
      using xcmplx_1_th_62 sorry
    also have "... = (((b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 (c /XCMPLX-0K7 b +XCMPLX-0K2 a /XCMPLX-0K7 b))+XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M"
      using xcmplx_1_th_62 sorry
    also have "... = (((b /XCMPLX-0K7 a +XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 (c /XCMPLX-0K7 b +XCMPLX-0K2 a /XCMPLX-0K7 b))+XCMPLX-0K2 (a /XCMPLX-0K7 c +XCMPLX-0K2 b /XCMPLX-0K7 c))-XCMPLX-0K6 \<three>\<^sub>M"
      using xcmplx_1_th_62 sorry
    also have "... = (((((a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M"
       sorry
    finally have "(((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c =HIDDENR1 (((((a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 a)+XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 c /XCMPLX-0K7 b)+XCMPLX-0K2 a /XCMPLX-0K7 c)-XCMPLX-0K6 \<three>\<^sub>M"
       sorry
    thus "(((b +XCMPLX-0K2 c)-XCMPLX-0K6 a)/XCMPLX-0K7 a +XCMPLX-0K2 ((c +XCMPLX-0K2 a)-XCMPLX-0K6 b)/XCMPLX-0K7 b)+XCMPLX-0K2 ((a +XCMPLX-0K2 b)-XCMPLX-0K6 c)/XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_23:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A2: "(a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =HIDDENR1 ((a *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b))+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b)"
       sorry
    also have "... = ((a *XCMPLX-0K3 b +XCMPLX-0K2 (a *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 b)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b)"
      using xcmplx_1_th_74 sorry
    also have "... = ((a *XCMPLX-0K3 b +XCMPLX-0K2 (a *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 b)+XCMPLX-0K2 (b *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 a)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b)"
      using xcmplx_1_th_74 sorry
    also have "... = ((a *XCMPLX-0K3 b +XCMPLX-0K2 (a *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 b)+XCMPLX-0K2 (b *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 a)+XCMPLX-0K2 (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_76 sorry
    also have "... = ((a *XCMPLX-0K3 b +XCMPLX-0K2 a /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    finally have "(a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) =HIDDENR1 ((a *XCMPLX-0K3 b +XCMPLX-0K2 a /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a /XCMPLX-0K7 b)*XCMPLX-0K3 (b /XCMPLX-0K7 a))"
      using sin_cos2_th_1 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (b *XCMPLX-0K3 a))"
      using xcmplx_1_th_76 sorry
    then have "a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using square_1_th_18 xcmplx_1_th_60 sorry
    then have A3: "(a /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 a)+XCMPLX-0K2 (a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)) >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 (a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xreal_1_th_6 sorry
    have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
       sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
      using square_1_def_2 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 \<one>\<^sub>M ^2SQUARE-1K1 /XCMPLX-0K7 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
      using xcmplx_1_th_76 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using square_1_def_2 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_74 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using A1 xcmplx_1_th_60 sorry
    also have "... = (a *XCMPLX-0K3 b +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    finally have "(sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1 =HIDDENR1 (a *XCMPLX-0K3 b +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    thus "(a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b) >=XXREAL-0R2 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
      using A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_24:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(a *XCMPLX-0K3 c)/XCMPLX-0K7 b +XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c =HIDDENR1 a *XCMPLX-0K3 (c /XCMPLX-0K7 b) +XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c"
      using xcmplx_1_th_74 sorry
    also have "... = a *XCMPLX-0K3 (c /XCMPLX-0K7 b) +XCMPLX-0K2 a *XCMPLX-0K3 (b /XCMPLX-0K7 c)"
      using xcmplx_1_th_74 sorry
    also have "... = a *XCMPLX-0K3 (c /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)"
       sorry
    finally have "(a *XCMPLX-0K3 c)/XCMPLX-0K7 b +XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c =HIDDENR1 a *XCMPLX-0K3 (c /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c)"
       sorry
    have A2: "(a *XCMPLX-0K3 b)/XCMPLX-0K7 c +XCMPLX-0K2 (b *XCMPLX-0K3 c)/XCMPLX-0K7 a =HIDDENR1 b *XCMPLX-0K3 (a /XCMPLX-0K7 c) +XCMPLX-0K2 (b *XCMPLX-0K3 c)/XCMPLX-0K7 a"
      using xcmplx_1_th_74 sorry
    also have "... = b *XCMPLX-0K3 (a /XCMPLX-0K7 c) +XCMPLX-0K2 b *XCMPLX-0K3 (c /XCMPLX-0K7 a)"
      using xcmplx_1_th_74 sorry
    also have "... = b *XCMPLX-0K3 (a /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 a)"
       sorry
    finally have "(a *XCMPLX-0K3 b)/XCMPLX-0K7 c +XCMPLX-0K2 (b *XCMPLX-0K3 c)/XCMPLX-0K7 a =HIDDENR1 b *XCMPLX-0K3 (a /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 a)"
       sorry
    have A3: "b *XCMPLX-0K3 (a /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 a) >=XXREAL-0R2 b *XCMPLX-0K3 \<two>\<^sub>M"
      using series_3_th_3 xreal_1_th_64 sorry
    have A4: "c *XCMPLX-0K3 (b /XCMPLX-0K7 a +XCMPLX-0K2 a /XCMPLX-0K7 b) >=XXREAL-0R2 c *XCMPLX-0K3 \<two>\<^sub>M"
      using series_3_th_3 xreal_1_th_64 sorry
    have "a *XCMPLX-0K3 (c /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c) >=XXREAL-0R2 a *XCMPLX-0K3 \<two>\<^sub>M"
      using series_3_th_3 xreal_1_th_64 sorry
    then have "a *XCMPLX-0K3 (c /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c) +XCMPLX-0K2 b *XCMPLX-0K3 (a /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 a) >=XXREAL-0R2 a *XCMPLX-0K3 \<two>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 \<two>\<^sub>M"
      using A3 xreal_1_th_7 sorry
    then have A5: "(a *XCMPLX-0K3 (c /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 c) +XCMPLX-0K2 b *XCMPLX-0K3 (a /XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 a))+XCMPLX-0K2 c *XCMPLX-0K3 (b /XCMPLX-0K7 a +XCMPLX-0K2 a /XCMPLX-0K7 b) >=XXREAL-0R2 (a *XCMPLX-0K3 \<two>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 \<two>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 \<two>\<^sub>M"
      using A4 xreal_1_th_7 sorry
    have "(b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b =HIDDENR1 c *XCMPLX-0K3 (b /XCMPLX-0K7 a) +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b"
      using xcmplx_1_th_74 sorry
    also have "... = c *XCMPLX-0K3 (b /XCMPLX-0K7 a) +XCMPLX-0K2 c *XCMPLX-0K3 (a /XCMPLX-0K7 b)"
      using xcmplx_1_th_74 sorry
    also have "... = c *XCMPLX-0K3 (b /XCMPLX-0K7 a +XCMPLX-0K2 a /XCMPLX-0K7 b)"
       sorry
    finally have "(b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b =HIDDENR1 c *XCMPLX-0K3 (b /XCMPLX-0K7 a +XCMPLX-0K2 a /XCMPLX-0K7 b)"
       sorry
    then have "(\<two>\<^sub>M *XCMPLX-0K3 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c))/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c))/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 A2 A5 xreal_1_th_72 sorry
    thus "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (a *XCMPLX-0K3 c)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_25:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x >XXREAL-0R4 y & y >XXREAL-0R4 z implies (x ^2SQUARE-1K1 *XCMPLX-0K3 y +XCMPLX-0K2 y ^2SQUARE-1K1 *XCMPLX-0K3 z)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 x >XXREAL-0R4 (x *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 y *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 z *XCMPLX-0K3 x ^2SQUARE-1K1"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds x >XXREAL-0R4 y & y >XXREAL-0R4 z implies  not (x ^2SQUARE-1K1 *XCMPLX-0K3 y +XCMPLX-0K2 y ^2SQUARE-1K1 *XCMPLX-0K3 z)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 x >XXREAL-0R4 (x *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 y *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 z *XCMPLX-0K3 x ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    assume A1: "x >XXREAL-0R4 y"
      and A2: "y >XXREAL-0R4 z"
    have A3: "y -XCMPLX-0K6 z >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_th_50 sorry
    have "x >XXREAL-0R4 z"
      using A1 A2 xxreal_0_th_2 sorry
    then have A4: "x -XCMPLX-0K6 z >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_50 sorry
    have "x -XCMPLX-0K6 y >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have "((x -XCMPLX-0K6 y)*XCMPLX-0K3 (y -XCMPLX-0K6 z))*XCMPLX-0K3 (x -XCMPLX-0K6 z) >XXREAL-0R4 0NUMBERSK6"
      using A3 A4 sorry
    then have "((x ^2SQUARE-1K1 *XCMPLX-0K3 y +XCMPLX-0K2 y ^2SQUARE-1K1 *XCMPLX-0K3 z)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 x)-XCMPLX-0K6 ((x *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 y *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 z *XCMPLX-0K3 x ^2SQUARE-1K1) >XXREAL-0R4 0NUMBERSK6"
       sorry
    thus " not (x ^2SQUARE-1K1 *XCMPLX-0K3 y +XCMPLX-0K2 y ^2SQUARE-1K1 *XCMPLX-0K3 z)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 x >XXREAL-0R4 (x *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 y *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 z *XCMPLX-0K3 x ^2SQUARE-1K1"
      using xreal_1_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_26:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies b /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 c)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies  not b /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 b"
      and A2: "b >XXREAL-0R4 c"
    have A3: "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    have "b *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) <XXREAL-0R3 c *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using A2 xreal_1_th_69 sorry
    then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 a <XXREAL-0R3 (-XCMPLX-0K4 c)+XCMPLX-0K2 a"
      using xreal_1_th_8 sorry
    then have A4: "c /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 c)"
      using A3 xreal_1_th_76 sorry
    have "b /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 b)"
      using A2 A3 xreal_1_th_74 sorry
    thus " not b /XCMPLX-0K7 (a -XCMPLX-0K6 b) >XXREAL-0R4 c /XCMPLX-0K7 (a -XCMPLX-0K6 c)"
      using A4 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_27:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds b >XXREAL-0R4 a & c >XXREAL-0R4 d implies c /XCMPLX-0K7 (c +XCMPLX-0K2 a) >XXREAL-0R4 d /XCMPLX-0K7 (d +XCMPLX-0K2 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for d be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds b >XXREAL-0R4 a & c >XXREAL-0R4 d implies  not c /XCMPLX-0K7 (c +XCMPLX-0K2 a) >XXREAL-0R4 d /XCMPLX-0K7 (d +XCMPLX-0K2 b)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix d assume [ty]: "d be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "b >XXREAL-0R4 a"
      and A2: "c >XXREAL-0R4 d"
    have "b *XCMPLX-0K3 c >XXREAL-0R4 a *XCMPLX-0K3 d"
      using A1 A2 xreal_1_th_96 sorry
    then have "b *XCMPLX-0K3 c +XCMPLX-0K2 c *XCMPLX-0K3 d >XXREAL-0R4 a *XCMPLX-0K3 d +XCMPLX-0K2 c *XCMPLX-0K3 d"
      using xreal_1_th_8 sorry
    then have "c *XCMPLX-0K3 (b +XCMPLX-0K2 d) >XXREAL-0R4 d *XCMPLX-0K3 (a +XCMPLX-0K2 c)"
       sorry
    thus " not c /XCMPLX-0K7 (c +XCMPLX-0K2 a) >XXREAL-0R4 d /XCMPLX-0K7 (d +XCMPLX-0K2 b)"
      using xreal_1_th_106 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_28:
" for m be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
proof-
  have " for m be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    have A1: "z ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A2: "m ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A3: "sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
      using A1 square_1_def_2 sorry
    have A4: "(m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have "(m *XCMPLX-0K3 y)^2SQUARE-1K1 +XCMPLX-0K2 (z *XCMPLX-0K3 x)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (m *XCMPLX-0K3 y))*XCMPLX-0K3 (z *XCMPLX-0K3 x)"
      using series_3_th_6 sorry
    then have A5: "((m *XCMPLX-0K3 y)^2SQUARE-1K1 +XCMPLX-0K2 (z *XCMPLX-0K3 x)^2SQUARE-1K1)+XCMPLX-0K2 (m ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1) >=XXREAL-0R2 (((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 x)*XCMPLX-0K3 y)*XCMPLX-0K3 z +XCMPLX-0K2 (m ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    have A6: "y ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A7: "x ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have A8: "sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1) >=XXREAL-0R2 0NUMBERSK6"
      using A6 square_1_def_2 sorry
    have "(sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))^2SQUARE-1K1 =HIDDENR1 (sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1))^2SQUARE-1K1 *XCMPLX-0K3 (sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))^2SQUARE-1K1"
       sorry
    also have "... = (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)*XCMPLX-0K3 (sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))^2SQUARE-1K1"
      using A2 A1 square_1_def_2 sorry
    also have "... = (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)*XCMPLX-0K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
      using A7 A6 square_1_def_2 sorry
    also have "... = ((m ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (m *XCMPLX-0K3 y)^2SQUARE-1K1)+XCMPLX-0K2 (z *XCMPLX-0K3 x)^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1"
       sorry
    finally have "(sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))^2SQUARE-1K1 =HIDDENR1 ((m ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (m *XCMPLX-0K3 y)^2SQUARE-1K1)+XCMPLX-0K2 (z *XCMPLX-0K3 x)^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1"
       sorry
    then have "sqrtSQUARE-1K3 (sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1))^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 (m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y)^2SQUARE-1K1"
      using A5 A4 square_1_th_26 sorry
    then have A9: "sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1) >=XXREAL-0R2 sqrtSQUARE-1K3 (m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y)^2SQUARE-1K1"
      using A3 A8 square_1_th_22 sorry
    show "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
    proof-
      have cases: "(m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y >XXREAL-0R4 0NUMBERSK6 or m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6) or m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y >XXREAL-0R4 0NUMBERSK6 implies m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
      proof(rule impI)
        assume "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y >XXREAL-0R4 0NUMBERSK6"
        thus "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
          using A9 square_1_th_22 sorry
      qed
      have case2: "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6 implies m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
      proof(rule impI)
        assume "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y =COMPLEX1R1 0NUMBERSK6"
        thus "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
          using A3 A8 sorry
      qed
      have case3: "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6 implies m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
      proof(rule impI)
        assume "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <XXREAL-0R3 0NUMBERSK6"
        thus "m *XCMPLX-0K3 x +XCMPLX-0K2 z *XCMPLX-0K3 y <=XXREAL-0R1 sqrtSQUARE-1K3 (m ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1) *XCMPLX-0K3 sqrtSQUARE-1K3 (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)"
          using A3 A8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_29:
" for m be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((m *XCMPLX-0K3 x +XCMPLX-0K2 u *XCMPLX-0K3 y)+XCMPLX-0K2 w *XCMPLX-0K3 z)^2SQUARE-1K1 <=XXREAL-0R1 ((m ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)"
proof-
  have " for m be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds  for w be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds ((m *XCMPLX-0K3 x +XCMPLX-0K2 u *XCMPLX-0K3 y)+XCMPLX-0K2 w *XCMPLX-0K3 z)^2SQUARE-1K1 <=XXREAL-0R1 ((m ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix m assume [ty]: "m be RealXREAL-0M1"
    fix u assume [ty]: "u be RealXREAL-0M1"
    fix w assume [ty]: "w be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    have "m ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 =COMPLEX1R1 (m *XCMPLX-0K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (w *XCMPLX-0K3 x)^2SQUARE-1K1"
       sorry
    then have A1: "m ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (m *XCMPLX-0K3 z))*XCMPLX-0K3 (w *XCMPLX-0K3 x)"
      using series_3_th_6 sorry
    have "u ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1 =COMPLEX1R1 (u *XCMPLX-0K3 z)^2SQUARE-1K1 +XCMPLX-0K2 (w *XCMPLX-0K3 y)^2SQUARE-1K1"
       sorry
    then have A2: "u ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (u *XCMPLX-0K3 z))*XCMPLX-0K3 (w *XCMPLX-0K3 y)"
      using series_3_th_6 sorry
    have "(m *XCMPLX-0K3 y)^2SQUARE-1K1 +XCMPLX-0K2 (u *XCMPLX-0K3 x)^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (m *XCMPLX-0K3 y))*XCMPLX-0K3 (u *XCMPLX-0K3 x)"
      using series_3_th_6 sorry
    then have "(m ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (m ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1) >=XXREAL-0R2 (((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 y)*XCMPLX-0K3 u)*XCMPLX-0K3 x +XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 z)*XCMPLX-0K3 w)*XCMPLX-0K3 x"
      using A1 xreal_1_th_7 sorry
    then have "(((m ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 m ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (u ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1 +XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1) >=XXREAL-0R2 ((((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 y)*XCMPLX-0K3 u)*XCMPLX-0K3 x +XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 z)*XCMPLX-0K3 w)*XCMPLX-0K3 x)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 z)*XCMPLX-0K3 w)*XCMPLX-0K3 y"
      using A2 xreal_1_th_7 sorry
    then have "(((((m ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 m ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 u ^2SQUARE-1K1 *XCMPLX-0K3 z ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1 *XCMPLX-0K3 y ^2SQUARE-1K1)+XCMPLX-0K2 (((m *XCMPLX-0K3 x)^2SQUARE-1K1 +XCMPLX-0K2 (u *XCMPLX-0K3 y)^2SQUARE-1K1)+XCMPLX-0K2 (w *XCMPLX-0K3 z)^2SQUARE-1K1) >=XXREAL-0R2 (((((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 y)*XCMPLX-0K3 u)*XCMPLX-0K3 x +XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 z)*XCMPLX-0K3 w)*XCMPLX-0K3 x)+XCMPLX-0K2 (((\<two>\<^sub>M *XCMPLX-0K3 u)*XCMPLX-0K3 z)*XCMPLX-0K3 w)*XCMPLX-0K3 y)+XCMPLX-0K2 (((m *XCMPLX-0K3 x)^2SQUARE-1K1 +XCMPLX-0K2 (u *XCMPLX-0K3 y)^2SQUARE-1K1)+XCMPLX-0K2 (w *XCMPLX-0K3 z)^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    thus "((m *XCMPLX-0K3 x +XCMPLX-0K2 u *XCMPLX-0K3 y)+XCMPLX-0K2 w *XCMPLX-0K3 z)^2SQUARE-1K1 <=XXREAL-0R1 ((m ^2SQUARE-1K1 +XCMPLX-0K2 u ^2SQUARE-1K1)+XCMPLX-0K2 w ^2SQUARE-1K1)*XCMPLX-0K3 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_30:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) <=XXREAL-0R1 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) <=XXREAL-0R1 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "b ^2SQUARE-1K1 *XCMPLX-0K3 (a +XCMPLX-0K2 c) >=XXREAL-0R2 b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))"
      using sin_cos2_th_1 xreal_1_th_64 sorry
    have A2: "c ^2SQUARE-1K1 *XCMPLX-0K3 (a +XCMPLX-0K2 b) >=XXREAL-0R2 c ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))"
      using sin_cos2_th_1 xreal_1_th_64 sorry
    have A3: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A4: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c)))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)))"
      using A4 A3 series_3_th_15 sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((((((((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))*XCMPLX-0K3 \<two>\<^sub>M)*XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))"
       sorry
    then have "((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c) |^NEWTONK1 \<three>\<^sub>M)"
      using series_5_lm_9 sorry
    then have A5: "((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 (((\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using power_th_4 sorry
    have A6: "(a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M >=XXREAL-0R2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
      using series_3_th_12 sorry
    have "a ^2SQUARE-1K1 *XCMPLX-0K3 (b +XCMPLX-0K2 c) >=XXREAL-0R2 a ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))"
      using sin_cos2_th_1 xreal_1_th_64 sorry
    then have "a ^2SQUARE-1K1 *XCMPLX-0K3 (b +XCMPLX-0K2 c) +XCMPLX-0K2 b ^2SQUARE-1K1 *XCMPLX-0K3 (a +XCMPLX-0K2 c) >=XXREAL-0R2 a ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c)) +XCMPLX-0K2 b ^2SQUARE-1K1 *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))"
      using A1 xreal_1_th_7 sorry
    then have "(a ^2SQUARE-1K1 *XCMPLX-0K3 (b +XCMPLX-0K2 c) +XCMPLX-0K2 b ^2SQUARE-1K1 *XCMPLX-0K3 (a +XCMPLX-0K2 c))+XCMPLX-0K2 c ^2SQUARE-1K1 *XCMPLX-0K3 (a +XCMPLX-0K2 b) >=XXREAL-0R2 ((\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1)*XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b)"
      using A2 xreal_1_th_7 sorry
    then have "((((a *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1 >=XXREAL-0R2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
      using A5 xxreal_0_th_2 sorry
    then have A7: "((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 (((((a *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<three>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c +XCMPLX-0K2 ((\<six>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c"
      using A6 xreal_1_th_7 sorry
    have "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)*XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) =HIDDENR1 (((((((a *XCMPLX-0K3 a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c ^2SQUARE-1K1"
       sorry
    also have "... = (((((((a *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c ^2SQUARE-1K1"
      using newton_th_81 sorry
    also have "... = (((((((a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c ^2SQUARE-1K1"
      using newton_th_6 sorry
    also have "... = (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c ^2SQUARE-1K1"
      using newton_th_81 sorry
    also have "... = (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c ^2SQUARE-1K1"
      using newton_th_6 sorry
    also have "... = (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M"
      using newton_th_81 sorry
    also have "... = (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 c  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1"
       sorry
    finally have "((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)*XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c) =HIDDENR1 (((((((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 c  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 a *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 c ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 a ^2SQUARE-1K1)+XCMPLX-0K2 c *XCMPLX-0K3 b ^2SQUARE-1K1"
       sorry
    then have "(((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) >=XXREAL-0R2 (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using A7 xreal_1_th_72 sorry
    then have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 (((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)) >=XXREAL-0R2 (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using xcmplx_1_th_77 sorry
    then have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)/XCMPLX-0K7 \<one>\<^sub>M >=XXREAL-0R2 (((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using xcmplx_1_th_60 sorry
    thus "(((\<nine>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) <=XXREAL-0R1 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_31:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c <=XXREAL-0R1 (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c <=XXREAL-0R1 (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 \<three>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A2: "sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (c +XCMPLX-0K2 a)"
      using series_5_lm_11 sorry
    have A3: "sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (b +XCMPLX-0K2 c)"
      using series_5_lm_11 sorry
    have "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using series_5_lm_11 sorry
    then have "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1) >=XXREAL-0R2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (b +XCMPLX-0K2 c)"
      using A3 xreal_1_th_7 sorry
    then have "(sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) >=XXREAL-0R2 (((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (b +XCMPLX-0K2 c))+XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)*XCMPLX-0K3 (c +XCMPLX-0K2 a)"
      using A2 xreal_1_th_7 sorry
    then have "((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 (((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 sqrtSQUARE-1K3 \<three>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M"
      using A1 xreal_1_th_72 sorry
    then have "((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 (sqrtSQUARE-1K3 \<three>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M)"
      using xcmplx_1_th_74 sorry
    then have "((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 \<one>\<^sub>M"
      using A1 xcmplx_1_th_60 sorry
    then have "(sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1))/XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
      using xcmplx_1_th_62 sorry
    then have "(sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
      using xcmplx_1_th_62 sorry
    then have "(sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M)+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
      using square_1_th_30 sorry
    then have "(sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1) /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M >=XXREAL-0R2 (a +XCMPLX-0K2 b)+XCMPLX-0K2 c"
      using square_1_th_30 sorry
    thus "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c <=XXREAL-0R1 (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M)"
      using square_1_th_30 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_32:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using series_5_lm_12 sorry
    have A2: "sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using series_5_lm_12 sorry
    have "sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using series_5_lm_12 sorry
    then have "sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A1 xreal_1_th_7 sorry
    thus "(sqrtSQUARE-1K3 (((a ^2SQUARE-1K1 +XCMPLX-0K2 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 c)+XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (((c ^2SQUARE-1K1 +XCMPLX-0K2 c *XCMPLX-0K3 a)+XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<three>\<^sub>M) <=XXREAL-0R1 (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)"
      using A2 xreal_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_33:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =COMPLEX1R1 (a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_def_2 sorry
    have A2: "(sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =COMPLEX1R1 (b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_def_2 sorry
    have A3: "sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A4: "sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A5: "((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    have A6: "sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A7: "(sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 =COMPLEX1R1 (c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_def_2 sorry
    have "((\<one>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 <=XXREAL-0R1 ((\<one>\<^sub>M ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M ^2SQUARE-1K1)+XCMPLX-0K2 \<one>\<^sub>M ^2SQUARE-1K1)*XCMPLX-0K3 (((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 (sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)+XCMPLX-0K2 (sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1)"
      using series_5_th_29 sorry
    then have "sqrtSQUARE-1K3 ((sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))^2SQUARE-1K1 <=XXREAL-0R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
      using A1 A2 A7 A5 square_1_th_26 sorry
    thus "(sqrtSQUARE-1K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 +XCMPLX-0K2 c ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 ((c ^2SQUARE-1K1 +XCMPLX-0K2 a ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) <=XXREAL-0R1 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
      using A6 A4 A3 square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_34:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)) <=XXREAL-0R1 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)) <=XXREAL-0R1 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
      using series_5_lm_13 sorry
    have A2: "((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1"
      using series_5_lm_13 sorry
    have "((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1"
      using series_5_lm_13 sorry
    then have "(((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1"
      using A2 xreal_1_th_7 sorry
    then have "(((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1 +XCMPLX-0K2 ((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 c ^2SQUARE-1K1"
      using A1 xreal_1_th_7 sorry
    then have "(((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)*XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 (((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)*XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M"
      using xreal_1_th_72 sorry
    then have "((((c *XCMPLX-0K3 a)/XCMPLX-0K7 b)^2SQUARE-1K1 +XCMPLX-0K2 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1)+XCMPLX-0K2 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1) >=XXREAL-0R2 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using xreal_1_th_6 sorry
    then have "(((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)"
      using series_5_lm_16 sorry
    then have "sqrtSQUARE-1K3 (((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c)^2SQUARE-1K1 >=XXREAL-0R2 sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1))"
      using square_1_th_26 sorry
    thus "sqrtSQUARE-1K3 (\<three>\<^sub>M *XCMPLX-0K3 ((a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1)+XCMPLX-0K2 c ^2SQUARE-1K1)) <=XXREAL-0R1 ((b *XCMPLX-0K3 c)/XCMPLX-0K7 a +XCMPLX-0K2 (c *XCMPLX-0K3 a)/XCMPLX-0K7 b)+XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 c"
      using square_1_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_35:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<nine>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<nine>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M"
    have "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    then have "\<one>\<^sub>M ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
      using A1 sin_cos2_th_1 square_1_th_15 sorry
    then have "\<one>\<^sub>M >=XXREAL-0R2 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
       sorry
    then have "\<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b)"
      using square_1_def_2 sorry
    then have "\<eight>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M <=XXREAL-0R1 \<eight>\<^sub>M /XCMPLX-0K7 ((\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)"
      using xreal_1_th_118 sorry
    then have "\<eight>\<^sub>M <=XXREAL-0R1 \<eight>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))"
       sorry
    then have "\<eight>\<^sub>M <=XXREAL-0R1 (\<eight>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_78 sorry
    then have A2: "\<eight>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<two>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    have "(\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 ((\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)/XCMPLX-0K7 a ^2SQUARE-1K1)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)"
      using xcmplx_1_th_126 sorry
    also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)/XCMPLX-0K7 a ^2SQUARE-1K1)*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 b ^2SQUARE-1K1)/XCMPLX-0K7 b ^2SQUARE-1K1)"
      using xcmplx_1_th_126 sorry
    also have "... = (((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a))*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 b)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b)))/XCMPLX-0K7 (a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1)"
      using xcmplx_1_th_76 sorry
    finally have "(\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 (((\<one>\<^sub>M -XCMPLX-0K6 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a))*XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 b)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b)))/XCMPLX-0K7 (a ^2SQUARE-1K1 *XCMPLX-0K3 b ^2SQUARE-1K1)"
       sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b)))/XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 (a *XCMPLX-0K3 b))"
      using A1 sorry
    also have "... = ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (a *XCMPLX-0K3 b))*XCMPLX-0K3 (((\<one>\<^sub>M +XCMPLX-0K2 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_76 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M +XCMPLX-0K2 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_60 sorry
    also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b))+XCMPLX-0K2 a *XCMPLX-0K3 b)/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    also have "... = \<two>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 (a *XCMPLX-0K3 b)/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using A1 xcmplx_1_th_62 sorry
    also have "... = \<two>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    finally have "(\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 a ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b ^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<nine>\<^sub>M"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_36:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<one>\<seven>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M implies a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<one>\<seven>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    assume "a +XCMPLX-0K2 b =COMPLEX1R1 \<one>\<^sub>M"
    then have "\<one>\<^sub>M ^2SQUARE-1K1 >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
      using A1 sin_cos2_th_1 square_1_th_15 sorry
    then have "\<one>\<^sub>M >=XXREAL-0R2 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))^2SQUARE-1K1"
       sorry
    then have "\<one>\<^sub>M >=XXREAL-0R2 \<four>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b)"
      using square_1_def_2 sorry
    then have A2: "\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M >=XXREAL-0R2 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 \<four>\<^sub>M)/XCMPLX-0K7 \<four>\<^sub>M"
      using xreal_1_th_72 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M) <=XXREAL-0R1 (a *XCMPLX-0K3 b)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M)"
      using xreal_1_th_65 sorry
    then have "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (-XCMPLX-0K4 a *XCMPLX-0K3 b)+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    then have "(\<three>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)^2SQUARE-1K1 <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1"
      using square_1_th_15 sorry
    then have "(\<nine>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)"
      using xreal_1_th_72 sorry
    then have A3: "\<nine>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M +XCMPLX-0K2 \<eight>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 *XCMPLX-0K3 \<four>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M"
      using xreal_1_th_7 sorry
    have "(\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      using xreal_1_th_63 sorry
    then have "(\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M) <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using A2 xreal_1_th_118 sorry
    then have A4: "(\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 *XCMPLX-0K3 \<four>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M <=XXREAL-0R1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<two>\<^sub>M"
      using xreal_1_th_7 sorry
    have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 a *XCMPLX-0K3 b =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (a *XCMPLX-0K3 b)*XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_113 sorry
    also have "... = (((\<one>\<^sub>M ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)*XCMPLX-0K3 (a *XCMPLX-0K3 b))+XCMPLX-0K2 (a *XCMPLX-0K3 b)^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
       sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 (a *XCMPLX-0K3 b)"
      using xcmplx_1_th_62 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((a *XCMPLX-0K3 b)/XCMPLX-0K7 (a *XCMPLX-0K3 b))"
      using xcmplx_1_th_74 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    also have "... = (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    finally have "\<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 a *XCMPLX-0K3 b =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 b)^2SQUARE-1K1 /XCMPLX-0K7 (a *XCMPLX-0K3 b) +XCMPLX-0K2 \<two>\<^sub>M"
       sorry
    thus "a *XCMPLX-0K3 b +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (a *XCMPLX-0K3 b) >=XXREAL-0R2 \<one>\<seven>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M"
      using A4 A3 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_37:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies (\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M"
    have A2: "\<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c) >=XXREAL-0R2 0NUMBERSK6"
      using power_th_7 sorry
    have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c))"
      using series_3_th_15 sorry
    then have A3: "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c))"
      using series_5_lm_3 sorry
    have A4: "\<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)) >=XXREAL-0R2 0NUMBERSK6"
      using power_th_7 sorry
    have "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c >=XXREAL-0R2 \<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)"
      using series_3_th_15 sorry
    then have "((a +XCMPLX-0K2 b)+XCMPLX-0K2 c)*XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 (\<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c))*XCMPLX-0K3 (\<three>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)))"
      using A2 A3 A4 xreal_1_th_66 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 (\<three>\<^sub>M -rootPOWERK1 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c) *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (\<one>\<^sub>M /XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)))"
      using A1 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)))"
      using power_th_11 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 (((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 (((a *XCMPLX-0K3 b)*XCMPLX-0K3 c)/XCMPLX-0K7 \<one>\<^sub>M))"
      using xcmplx_1_th_79 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M *XCMPLX-0K3 \<three>\<^sub>M -rootPOWERK1 \<one>\<^sub>M"
      using xcmplx_1_th_60 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
      using power_th_6 sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b)+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c >=XXREAL-0R2 \<nine>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_38:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<eight>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<eight>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "(a +XCMPLX-0K2 c)/XCMPLX-0K7 b >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    have A2: "(a +XCMPLX-0K2 b)/XCMPLX-0K7 c >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    have A3: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have A4: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    assume A5: "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M"
    then have A6: "((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M)"
      using series_5_lm_17 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M)"
      using A5 series_5_lm_17 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (((a +XCMPLX-0K2 b)/XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 c)-XCMPLX-0K6 \<one>\<^sub>M)"
      using A5 xcmplx_1_th_62 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (((a +XCMPLX-0K2 b)/XCMPLX-0K7 c +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
      using xcmplx_1_th_60 sorry
    also have "... = (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 c)"
       sorry
    finally have "((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 (((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 c)"
       sorry
    have A7: "sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(b +XCMPLX-0K2 c)/XCMPLX-0K7 a >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    then have "((b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)/XCMPLX-0K7 b) >=XXREAL-0R2 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b)"
      using A1 A7 A4 xreal_1_th_66 sorry
    then have "((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 (((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c)"
      using A6 A2 A7 A4 A3 xreal_1_th_66 sorry
    thus "((\<one>\<^sub>M /XCMPLX-0K7 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 c -XCMPLX-0K6 \<one>\<^sub>M) >=XXREAL-0R2 \<eight>\<^sub>M"
      using series_5_lm_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_39:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<six>\<four>\<^sub>M"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds (a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M implies ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<six>\<four>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    have A1: "sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 c >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    then have "\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b))/XCMPLX-0K7 c"
      using xreal_1_th_6 sorry
    then have A2: "\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)"
      using xcmplx_1_th_74 sorry
    have A3: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(a +XCMPLX-0K2 c)/XCMPLX-0K7 b >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    then have "\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))/XCMPLX-0K7 b"
      using xreal_1_th_6 sorry
    then have A4: "\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)"
      using xcmplx_1_th_74 sorry
    have A5: "sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
      using square_1_th_25 sorry
    have "(b +XCMPLX-0K2 c)/XCMPLX-0K7 a >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a"
      using sin_cos2_th_1 xreal_1_th_72 sorry
    then have "\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))/XCMPLX-0K7 a"
      using xreal_1_th_6 sorry
    then have "\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a >=XXREAL-0R2 \<two>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)"
      using xcmplx_1_th_74 sorry
    then have "(\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))"
      using A4 A1 A5 xreal_1_th_66 sorry
    then have A6: "((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c) >=XXREAL-0R2 ((\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)))*XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c))"
      using A2 A1 A5 A3 xreal_1_th_66 sorry
    have "((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a >=XXREAL-0R2 \<six>\<^sub>M"
      using series_5_lm_23 sorry
    then have "\<two>\<^sub>M +XCMPLX-0K2 (((((sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b +XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a) >=XXREAL-0R2 \<six>\<^sub>M +NAT-1K1 \<two>\<^sub>M"
      using xreal_1_th_6 sorry
    then have A7: "\<eight>\<^sub>M *XCMPLX-0K3 ((((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a) >=XXREAL-0R2 \<eight>\<^sub>M *NAT-1K2 \<eight>\<^sub>M"
      using xreal_1_th_64 sorry
    assume A8: "(a +XCMPLX-0K2 b)+XCMPLX-0K2 c =COMPLEX1R1 \<one>\<^sub>M"
    then have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) =HIDDENR1 ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c)"
      using series_5_lm_19 sorry
    also have "... = ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c)"
      using A8 series_5_lm_19 sorry
    also have "... = ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 c +XCMPLX-0K2 c /XCMPLX-0K7 c))"
      using A8 xcmplx_1_th_62 sorry
    also have "... = ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 ((\<one>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)+XCMPLX-0K2 \<one>\<^sub>M)"
      using xcmplx_1_th_60 sorry
    also have "... = ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)"
       sorry
    finally have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) =HIDDENR1 ((\<two>\<^sub>M +XCMPLX-0K2 (b +XCMPLX-0K2 c)/XCMPLX-0K7 a)*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 c)/XCMPLX-0K7 b))*XCMPLX-0K3 (\<two>\<^sub>M +XCMPLX-0K2 (a +XCMPLX-0K2 b)/XCMPLX-0K7 c)"
       sorry
    then have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<eight>\<^sub>M *XCMPLX-0K3 (((\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c))"
      using A6 sorry
    then have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<eight>\<^sub>M *XCMPLX-0K3 ((((((\<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c) /XCMPLX-0K7 b)+XCMPLX-0K2 b /XCMPLX-0K7 sqrtSQUARE-1K3 (a *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (a *XCMPLX-0K3 b) /XCMPLX-0K7 c)+XCMPLX-0K2 c /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 a))+XCMPLX-0K2 a /XCMPLX-0K7 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c))+XCMPLX-0K2 sqrtSQUARE-1K3 (b *XCMPLX-0K3 c) /XCMPLX-0K7 a)"
      using series_5_lm_22 sorry
    thus "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 b))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 c) >=XXREAL-0R2 \<six>\<four>\<^sub>M"
      using A7 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_40:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    have A1: "(y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 y *XCMPLX-0K3 z"
      using series_3_th_7 sorry
    have A2: "(x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 x *XCMPLX-0K3 z"
      using series_3_th_7 sorry
    have "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 x *XCMPLX-0K3 y"
      using series_3_th_7 sorry
    then have "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y"
      using A1 xreal_1_th_7 sorry
    then have "((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M >=XXREAL-0R2 (y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 z"
      using A2 xreal_1_th_7 sorry
    then have "-XCMPLX-0K4 (((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M) <=XXREAL-0R1 -XCMPLX-0K4 ((y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 z)"
      using xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 (((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M))*XCMPLX-0K3 \<two>\<^sub>M <=XXREAL-0R1 (-XCMPLX-0K4 ((y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 z))*XCMPLX-0K3 \<two>\<^sub>M"
      using xreal_1_th_64 sorry
    then have "(-XCMPLX-0K4 (((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (y ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 (x ^2SQUARE-1K1 +XCMPLX-0K2 z ^2SQUARE-1K1)/XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 (-XCMPLX-0K4 ((y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 z)*XCMPLX-0K3 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    then have A3: "\<one>\<^sub>M -XCMPLX-0K6 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)*XCMPLX-0K3 \<two>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M -XCMPLX-0K6 ((y *XCMPLX-0K3 z +XCMPLX-0K2 x *XCMPLX-0K3 y)+XCMPLX-0K2 x *XCMPLX-0K3 z)*XCMPLX-0K3 \<two>\<^sub>M"
       sorry
    assume "(x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M"
    then have "((((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 z)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 x =COMPLEX1R1 \<one>\<^sub>M ^2SQUARE-1K1"
      using series_5_lm_6 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 ((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)*XCMPLX-0K3 \<two>\<^sub>M"
      using A3 xreal_1_th_20 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M <=XXREAL-0R1 (((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)*XCMPLX-0K3 \<three>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M"
      using xreal_1_th_72 sorry
    thus "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_41:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for z be RealXREAL-0M1 holds (x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M implies (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix z assume [ty]: "z be RealXREAL-0M1"
    have "(x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1 >=XXREAL-0R2 (x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 x *XCMPLX-0K3 z"
      using series_3_th_10 sorry
    then have A1: "((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x) >=XXREAL-0R2 ((x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 x *XCMPLX-0K3 z)+XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 ((x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x)"
      using xreal_1_th_7 sorry
    assume "(x +XCMPLX-0K2 y)+XCMPLX-0K2 z =COMPLEX1R1 \<one>\<^sub>M"
    then have "\<one>\<^sub>M ^2SQUARE-1K1 =COMPLEX1R1 ((((x ^2SQUARE-1K1 +XCMPLX-0K2 y ^2SQUARE-1K1)+XCMPLX-0K2 z ^2SQUARE-1K1)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 y)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 y)*XCMPLX-0K3 z)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 z)*XCMPLX-0K3 x"
      using series_5_lm_6 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M >=XXREAL-0R2 (\<three>\<^sub>M *XCMPLX-0K3 ((x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x))/XCMPLX-0K7 \<three>\<^sub>M"
      using A1 xreal_1_th_72 sorry
    thus "(x *XCMPLX-0K3 y +XCMPLX-0K2 y *XCMPLX-0K3 z)+XCMPLX-0K2 z *XCMPLX-0K3 x <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_42:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies (a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c) >XXREAL-0R4 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds a >XXREAL-0R4 b & b >XXREAL-0R4 c implies  not (a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c) >XXREAL-0R4 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 b"
      and A2: "b >XXREAL-0R4 c"
    have A3: "b /XCMPLX-0K7 c >XXREAL-0R4 \<one>\<^sub>M"
      using A2 xreal_1_th_187 sorry
    let ?e = "(a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)"
    have A4: "b to-powerPOWERK2 (c +XCMPLX-0K2 a) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    have "b -XCMPLX-0K6 c >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_th_50 sorry
    then have A5: "(b /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using A3 power_th_35 sorry
    have A6: "a /XCMPLX-0K7 b >XXREAL-0R4 \<one>\<^sub>M"
      using A1 xreal_1_th_187 sorry
    have "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
      using A1 xreal_1_th_50 sorry
    then have "(a /XCMPLX-0K7 b)to-powerPOWERK2 (a -XCMPLX-0K6 b) >XXREAL-0R4 \<one>\<^sub>M"
      using A6 power_th_35 sorry
    then have A7: "(a /XCMPLX-0K7 b)to-powerPOWERK2 (a -XCMPLX-0K6 b) *XCMPLX-0K3 (b /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using A5 xreal_1_th_161 sorry
    have A8: "c to-powerPOWERK2 (a +XCMPLX-0K2 b) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    have A9: "a >XXREAL-0R4 c"
      using A1 A2 xxreal_0_th_2 sorry
    then have A10: "a /XCMPLX-0K7 c >XXREAL-0R4 \<one>\<^sub>M"
      using xreal_1_th_187 sorry
    let ?d = "(a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c)"
    have A11: "a to-powerPOWERK2 (b +XCMPLX-0K2 c) >XXREAL-0R4 0NUMBERSK6"
      using power_th_34 sorry
    have "a -XCMPLX-0K6 c >XXREAL-0R4 0NUMBERSK6"
      using A9 xreal_1_th_50 sorry
    then have "(a /XCMPLX-0K7 c)to-powerPOWERK2 (a -XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using A10 power_th_35 sorry
    then have "((a /XCMPLX-0K7 b)to-powerPOWERK2 (a -XCMPLX-0K6 b) *XCMPLX-0K3 (b /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 (a /XCMPLX-0K7 c)to-powerPOWERK2 (-XCMPLX-0K4 (c -XCMPLX-0K6 a)) >XXREAL-0R4 \<one>\<^sub>M"
      using A7 xreal_1_th_161 sorry
    then have "((a /XCMPLX-0K7 b)to-powerPOWERK2 (a -XCMPLX-0K6 b) *XCMPLX-0K3 (b /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 (c /XCMPLX-0K7 a)to-powerPOWERK2 (c -XCMPLX-0K6 a) >XXREAL-0R4 \<one>\<^sub>M"
      using series_5_lm_4 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 b to-powerPOWERK2 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (b /XCMPLX-0K7 c)to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 (c /XCMPLX-0K7 a)to-powerPOWERK2 (c -XCMPLX-0K6 a) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_31 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 b to-powerPOWERK2 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (b to-powerPOWERK2 (b -XCMPLX-0K6 c) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c)))*XCMPLX-0K3 (c /XCMPLX-0K7 a)to-powerPOWERK2 (c -XCMPLX-0K6 a) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_31 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 b to-powerPOWERK2 (a -XCMPLX-0K6 b))*XCMPLX-0K3 (b to-powerPOWERK2 (b -XCMPLX-0K6 c) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c)))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a)) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_31 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) *XCMPLX-0K3 b to-powerPOWERK2 (b -XCMPLX-0K6 c))/XCMPLX-0K7 (c to-powerPOWERK2 (b -XCMPLX-0K6 c) *XCMPLX-0K3 b to-powerPOWERK2 (a -XCMPLX-0K6 b)))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a)) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_76 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 (b to-powerPOWERK2 (b -XCMPLX-0K6 c) /XCMPLX-0K7 b to-powerPOWERK2 (a -XCMPLX-0K6 b)))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a)) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_76 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 b to-powerPOWERK2 ((b -XCMPLX-0K6 c)-XCMPLX-0K6 (a -XCMPLX-0K6 b)))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a)) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a)))*XCMPLX-0K3 b to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 a)-XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
       sorry
    then have "((a to-powerPOWERK2 (a -XCMPLX-0K6 b) /XCMPLX-0K7 a to-powerPOWERK2 (c -XCMPLX-0K6 a))*XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c)))*XCMPLX-0K3 b to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 a)-XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_85 sorry
    then have "(a to-powerPOWERK2 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 (c -XCMPLX-0K6 a)) *XCMPLX-0K3 (c to-powerPOWERK2 (c -XCMPLX-0K6 a) /XCMPLX-0K7 c to-powerPOWERK2 (b -XCMPLX-0K6 c)))*XCMPLX-0K3 b to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 a)-XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "(a to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 b)-XCMPLX-0K6 c) *XCMPLX-0K3 c to-powerPOWERK2 ((c -XCMPLX-0K6 a)-XCMPLX-0K6 (b -XCMPLX-0K6 c)))*XCMPLX-0K3 b to-powerPOWERK2 ((\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 a)-XCMPLX-0K6 c) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "(a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a -XCMPLX-0K6 (b +XCMPLX-0K2 c)) *XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c -XCMPLX-0K6 (a +XCMPLX-0K2 b)))*XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
       sorry
    then have "((a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) /XCMPLX-0K7 a to-powerPOWERK2 (b +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c -XCMPLX-0K6 (a +XCMPLX-0K2 b)))*XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "((a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) /XCMPLX-0K7 a to-powerPOWERK2 (b +XCMPLX-0K2 c))*XCMPLX-0K3 (c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c) /XCMPLX-0K7 c to-powerPOWERK2 (a +XCMPLX-0K2 b)))*XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "((a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c))/XCMPLX-0K7 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)))*XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_76 sorry
    then have "((a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c))/XCMPLX-0K7 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)))*XCMPLX-0K3 (b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b) /XCMPLX-0K7 b to-powerPOWERK2 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
      using power_th_29 sorry
    then have "((a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c))*XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))/XCMPLX-0K7 ((a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b))*XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c)) >XXREAL-0R4 \<one>\<^sub>M"
      using xcmplx_1_th_76 sorry
    then have "(?d /XCMPLX-0K7 ?e)*XCMPLX-0K3 ?e >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 ?e"
      using A11 A4 A8 xreal_1_th_68 sorry
    thus " not (a to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 a) *XCMPLX-0K3 b to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 b))*XCMPLX-0K3 c to-powerPOWERK2 (\<two>\<^sub>M *XCMPLX-0K3 c) >XXREAL-0R4 (a to-powerPOWERK2 (b +XCMPLX-0K2 c) *XCMPLX-0K3 b to-powerPOWERK2 (a +XCMPLX-0K2 c))*XCMPLX-0K3 c to-powerPOWERK2 (a +XCMPLX-0K2 b)"
      using A11 A4 A8 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_43:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    show "a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
    proof-
      have cases: "(a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 or a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6) or a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
      proof(rule impI)
        assume A2: "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
        then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 b"
          using xreal_1_th_8 sorry
        then have "a  |^NEWTONK1 n >XXREAL-0R4 b  |^NEWTONK1 n"
          using A1 prepower_th_10 sorry
        then have "a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_50 sorry
        then have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n) >XXREAL-0R4 0NUMBERSK6"
          using A2 sorry
        then have "((a *XCMPLX-0K3 a  |^NEWTONK1 n -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
           sorry
        then have "((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using newton_th_6 sorry
        then have "((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using newton_th_6 sorry
        then have "(((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 n) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 n)"
          using xreal_1_th_8 sorry
        thus "a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
           sorry
      qed
      have case2: "a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
      proof(rule impI)
        assume A3: "a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6"
        then have "a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 n *XCMPLX-0K3 a"
          using newton_th_6 sorry
        also have "... = a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        finally have "a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
          using A3 sorry
      qed
      have case3: "a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6 implies a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
      proof(rule impI)
        assume A4: "a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
        then have "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
          using xreal_1_th_8 sorry
        then have "a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
          using A1 prepower_th_10 sorry
        then have "a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        then have "(a -XCMPLX-0K6 b)*XCMPLX-0K3 (a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n) >XXREAL-0R4 0NUMBERSK6"
          using A4 sorry
        then have "((a *XCMPLX-0K3 a  |^NEWTONK1 n -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
           sorry
        then have "((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using newton_th_6 sorry
        then have "((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using newton_th_6 sorry
        then have "(((a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 b *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 n) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 n)"
          using xreal_1_th_8 sorry
        thus "a  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 a  |^NEWTONK1 n *XCMPLX-0K3 b +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 n"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_44:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =COMPLEX1R1 c ^2SQUARE-1K1 & n >=XXREAL-0R2 \<three>\<^sub>M implies a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 c  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for c be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =COMPLEX1R1 c ^2SQUARE-1K1 & n >=XXREAL-0R2 \<three>\<^sub>M implies  not a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 c  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix c assume [ty]: "c be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a ^2SQUARE-1K1 +XCMPLX-0K2 b ^2SQUARE-1K1 =COMPLEX1R1 c ^2SQUARE-1K1"
      and A2: "n >=XXREAL-0R2 \<three>\<^sub>M"
    have A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 xxreal_0_th_2 sorry
    have "b ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A4: "b  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using newton_th_81 sorry
    have "(c ^2SQUARE-1K1 -XCMPLX-0K6 b ^2SQUARE-1K1)+XCMPLX-0K2 b ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 b ^2SQUARE-1K1"
      using A1 xreal_1_th_8 sorry
    then have "sqrtSQUARE-1K3 c ^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
      using square_1_th_27 sorry
    then have "c >XXREAL-0R4 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
      using square_1_th_22 sorry
    then have "c >XXREAL-0R4 b"
      using square_1_th_22 sorry
    then have "c  |^NEWTONK1 n >XXREAL-0R4 b  |^NEWTONK1 n"
      using A3 prepower_th_10 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 b  |^NEWTONK1 n *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M"
      using A4 xreal_1_th_68 sorry
    then have A5: "c  |^NEWTONK1 n *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using newton_th_8 sorry
    have "a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
       sorry
    then have A6: "a  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using newton_th_81 sorry
    have "(c ^2SQUARE-1K1 -XCMPLX-0K6 a ^2SQUARE-1K1)+XCMPLX-0K2 a ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 a ^2SQUARE-1K1"
      using A1 xreal_1_th_8 sorry
    then have "sqrtSQUARE-1K3 c ^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 a ^2SQUARE-1K1"
      using square_1_th_27 sorry
    then have "c >XXREAL-0R4 sqrtSQUARE-1K3 a ^2SQUARE-1K1"
      using square_1_th_22 sorry
    then have "c >XXREAL-0R4 a"
      using square_1_th_22 sorry
    then have "c  |^NEWTONK1 n >XXREAL-0R4 a  |^NEWTONK1 n"
      using A3 prepower_th_10 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 a  |^NEWTONK1 n *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M"
      using A6 xreal_1_th_68 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using newton_th_8 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 c  |^NEWTONK1 n *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using A5 xreal_1_th_8 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M) >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
       sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 (a ^2SQUARE-1K1 +XCMPLX-0K2 b  |^NEWTONK1 \<two>\<^sub>M) >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using newton_th_81 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 c ^2SQUARE-1K1 >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using A1 newton_th_81 sorry
    then have "c  |^NEWTONK1 n *XCMPLX-0K3 c  |^NEWTONK1 \<two>\<^sub>M >XXREAL-0R4 a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using newton_th_81 sorry
    thus " not a  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 b  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 c  |^NEWTONK1 (n +NAT-1K1 \<two>\<^sub>M)"
      using newton_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_45:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 n <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies  not (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 n <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 n +NAT-1K1 0NUMBERSK6"
      using xreal_1_th_8 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n"
      using A1 xreal_1_th_76 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_8 sorry
    then have A2: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 n <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n"
      using A1 prepower_th_10 sorry
    have A3: "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_6 sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n"
      using newton_th_6 sorry
    also have "... = (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 n)"
       sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 n)"
       sorry
    then have "((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n)+XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 n"
      using A1 A3 xreal_1_th_8 sorry
    thus " not (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) |^NEWTONK1 n <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
      using A2 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_46:
" for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & k >=XXREAL-0R2 \<one>\<^sub>M implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
proof-
  have " for a be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for b be positiveXXREAL-0V2\<bar>RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & k >=XXREAL-0R2 \<one>\<^sub>M implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix b assume [ty]: "b be positiveXXREAL-0V2\<bar>RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "k >=XXREAL-0R2 \<one>\<^sub>M"
    have A3: "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n)) =HIDDENR1 ((((a  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n +XCMPLX-0K2 a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (k +XCMPLX-0K2 n))-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (k +XCMPLX-0K2 n)"
       sorry
    also have "... = ((((a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n)-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (k +XCMPLX-0K2 n))-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (k +XCMPLX-0K2 n)"
      using newton_th_8 sorry
    also have "... = ((((a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)+XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 (k +XCMPLX-0K2 n))-XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 (k +XCMPLX-0K2 n)"
      using newton_th_8 sorry
    also have "... = ((a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 a  |^NEWTONK1 (k +XCMPLX-0K2 n))-XCMPLX-0K6 b  |^NEWTONK1 (k +XCMPLX-0K2 n)"
       sorry
    also have "... = ((a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 a  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 b  |^NEWTONK1 (k +XCMPLX-0K2 n)"
      using newton_th_8 sorry
    also have "... = ((a  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 a  |^NEWTONK1 k *XCMPLX-0K3 a  |^NEWTONK1 n)-XCMPLX-0K6 b  |^NEWTONK1 k *XCMPLX-0K3 b  |^NEWTONK1 n"
      using newton_th_8 sorry
    also have "... = (a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n)*XCMPLX-0K3 (b  |^NEWTONK1 k -XCMPLX-0K6 a  |^NEWTONK1 k)"
       sorry
    finally have "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) -XCMPLX-0K6 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n)) =HIDDENR1 (a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n)*XCMPLX-0K3 (b  |^NEWTONK1 k -XCMPLX-0K6 a  |^NEWTONK1 k)"
       sorry
    show "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
    proof-
      have cases: "(a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 or a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6) or a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
      proof(rule impI)
        assume "a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
        then have A4: "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 b"
          using xreal_1_th_8 sorry
        then have "a  |^NEWTONK1 k >XXREAL-0R4 b  |^NEWTONK1 k"
          using A2 prepower_th_10 sorry
        then have A5: "b  |^NEWTONK1 k -XCMPLX-0K6 a  |^NEWTONK1 k <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        have "a  |^NEWTONK1 n >XXREAL-0R4 b  |^NEWTONK1 n"
          using A1 A4 prepower_th_10 sorry
        then have "a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_50 sorry
        thus "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
          using A3 A5 xreal_1_th_48 sorry
      qed
      have case2: "a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6 implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
      proof(rule impI)
        assume "a -XCMPLX-0K6 b =COMPLEX1R1 0NUMBERSK6"
        then have "a  |^NEWTONK1 n =COMPLEX1R1 b  |^NEWTONK1 n"
           sorry
        thus "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
          using A3 sorry
      qed
      have case3: "a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6 implies (a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
      proof(rule impI)
        assume "a -XCMPLX-0K6 b <XXREAL-0R3 0NUMBERSK6"
        then have A6: "(a -XCMPLX-0K6 b)+XCMPLX-0K2 b <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 b"
          using xreal_1_th_8 sorry
        then have "a  |^NEWTONK1 k <XXREAL-0R3 b  |^NEWTONK1 k"
          using A2 prepower_th_10 sorry
        then have A7: "b  |^NEWTONK1 k -XCMPLX-0K6 a  |^NEWTONK1 k >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_50 sorry
        have "a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
          using A1 A6 prepower_th_10 sorry
        then have "a  |^NEWTONK1 n -XCMPLX-0K6 b  |^NEWTONK1 n <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        thus "(a  |^NEWTONK1 k +XCMPLX-0K2 b  |^NEWTONK1 k)*XCMPLX-0K3 (a  |^NEWTONK1 n +XCMPLX-0K2 b  |^NEWTONK1 n) <=XXREAL-0R1 \<two>\<^sub>M *XCMPLX-0K3 (a  |^NEWTONK1 (k +XCMPLX-0K2 n) +XCMPLX-0K2 b  |^NEWTONK1 (k +XCMPLX-0K2 n))"
          using A3 A7 xreal_1_th_48 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_47:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) implies ( for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using square_1_th_25 sorry
        have "(\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<eight>\<^sub>M <XXREAL-0R3 (\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<nine>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "sqrtSQUARE-1K3 (\<four>\<^sub>M *NAT-1K2 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))) <XXREAL-0R3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)^2SQUARE-1K1"
          using square_1_th_27 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)^2SQUARE-1K1"
          using square_1_th_20 square_1_th_29 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M"
          using square_1_th_22 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)"
          using square_1_th_29 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1"
          using square_1_th_22 sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using A3 xreal_1_th_74 sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)))/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using square_1_th_29 sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 ((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
           sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M)/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using A3 xcmplx_1_th_89 sorry
        then have "((\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using xcmplx_1_th_62 sorry
        then have A4: "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using A3 xcmplx_1_th_89 sorry
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using xreal_1_th_8 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using A4 xxreal_0_th_2 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<two>\<^sub>M)"
          using A1 sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using A1 sorry
    also have "... = \<one>\<^sub>M"
      using square_1_th_18 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A5: "?X(0NUMBERSK6)"
      using square_1_th_18 sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_48:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
        then have A3: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1 <=XXREAL-0R1 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1"
          using xreal_1_th_7 sorry
        have "(n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M >XXREAL-0R4 (n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1) >XXREAL-0R4 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1 *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))"
          using xreal_1_th_74 sorry
        then have "((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1) >XXREAL-0R4 (n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))"
          using xcmplx_1_th_91 sorry
        then have "((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1) >XXREAL-0R4 ((n +NAT-1K1 \<two>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
          using xcmplx_1_th_78 sorry
        then have "((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1) >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)"
          using xcmplx_1_th_60 sorry
        then have "(-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1)) <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))"
          using xreal_1_th_69 sorry
        then have A4: "(-XCMPLX-0K4 ((n ^2SQUARE-1K1 +XCMPLX-0K2 \<three>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<three>\<^sub>M)/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1))+XCMPLX-0K2 \<two>\<^sub>M <XXREAL-0R3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
          using A1 sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
           sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1)"
          using A3 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<two>\<^sub>M)^2SQUARE-1K1)"
          using xcmplx_1_th_130 sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A4 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
      using A1 sorry
    also have "... = \<one>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A5: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A5 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_49:
" for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) implies  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    assume " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
    then have A1: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <=XXREAL-0R1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
      using series_5_th_48 sorry
    have "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<two>\<^sub>M <XXREAL-0R3 0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M"
      using xreal_1_th_8 sorry
    thus " not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<two>\<^sub>M"
      using A1 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_50:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <XXREAL-0R3 Lamb1 +NAT-1K1 \<one>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        assume "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using A1 A3 xreal_1_th_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    then have A4: "?X(0NUMBERSK6)"
      using A1 sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A4 A2 sorry
    thus " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_51:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 -XCMPLX-0K6 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 \<one>\<^sub>M"
    have A2: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n"
        have A4: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
          using A1 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 0NUMBERSK6"
          using A1 series_5_th_50 xreal_1_th_49 sorry
        then have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ((Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)-XCMPLX-0K6 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 ((Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)-XCMPLX-0K6 \<one>\<^sub>M)"
          using A4 xreal_1_th_69 sorry
        then have A5: "((s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 n)-XCMPLX-0K6 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_8 sorry
        have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using A1 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n)*XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 xreal_1_th_64 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
          using A5 xxreal_0_th_2 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))-XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
          using series_3_def_1 sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) -XCMPLX-0K6 0NUMBERSK6 =COMPLEX1R1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    then have A6: "?X(0NUMBERSK6)"
      using series_3_def_1 sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A6 A2 sorry
    thus " for n be NatNAT-1M1 holds Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n -XCMPLX-0K6 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_52:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6)"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >XXREAL-0R4 0NUMBERSK6"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A2: "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 implies Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
        have A5: "Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        have A6: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using A1 sorry
        have "s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        thus "Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using A4 A5 A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) >XXREAL-0R4 0NUMBERSK6"
      using A1 sorry
    then have A7: "?X(0NUMBERSK6)"
      using A2 series_1_def_1 sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A7 A3 sorry
    thus " for n be NatNAT-1M1 holds  not Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_53:
" for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n) implies ( for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1)"
  proof(rule ballI,rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >=XXREAL-0R2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
    assume A1: " for n be NatNAT-1M1 holds s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 0NUMBERSK6 & s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
    then have A2: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) >XXREAL-0R4 0NUMBERSK6"
       sorry
    have A3: " for n be NatNAT-1M1 holds ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        let ?x = "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        let ?y = "Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n"
        assume A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
        then have A5: "?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ((?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M) >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 +XCMPLX-0K2 ((?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)"
          using xreal_1_th_7 sorry
        have "sqrtSQUARE-1K3 (?x *XCMPLX-0K3 ?y) >=XXREAL-0R2 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
          using A4 square_1_th_26 sorry
        then have "sqrtSQUARE-1K3 (?x *XCMPLX-0K3 ?y) >=XXREAL-0R2 n +NAT-1K1 \<one>\<^sub>M"
          using square_1_th_22 sorry
        then have A6: "\<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?x *XCMPLX-0K3 ?y) >=XXREAL-0R2 \<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_64 sorry
        have A7: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using A1 sorry
        have A8: "?x >XXREAL-0R4 0NUMBERSK6"
          using A1 series_3_th_33 sorry
        have "?y >XXREAL-0R4 0NUMBERSK6"
          using A1 series_5_th_52 sorry
        then have "?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 ((?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
          using A7 A8 sin_cos2_th_1 sorry
        then have "?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?x /XCMPLX-0K7 ((\<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 (?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))))"
          using xcmplx_1_th_81 sorry
        then have "?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?x /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 ?y))"
          using A7 xcmplx_1_th_91 sorry
        then have "?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 sqrtSQUARE-1K3 (?y *XCMPLX-0K3 (?x /XCMPLX-0K7 \<one>\<^sub>M))"
          using xcmplx_1_th_81 sorry
        then have "?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M"
          using A6 xxreal_0_th_2 sorry
        then have A9: "(?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ?y *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 ((n ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<two>\<^sub>M) >=XXREAL-0R2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M)+XCMPLX-0K2 ((n ^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<two>\<^sub>M)"
          using xreal_1_th_7 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (?x +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
        also have "... = (?x +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (?y +XCMPLX-0K2 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using series_1_def_1 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using xcmplx_1_th_74 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 \<one>\<^sub>M"
          using A7 xcmplx_1_th_60 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x /XCMPLX-0K7 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 \<one>\<^sub>M))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 \<one>\<^sub>M"
          using xcmplx_1_th_79 sorry
        also have "... = ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ((?x *XCMPLX-0K3 ?y +XCMPLX-0K2 ?x /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 ?y)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
          using A9 A5 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6))"
      using A1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 (s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) /XCMPLX-0K7 \<one>\<^sub>M)"
      using xcmplx_1_th_79 sorry
    also have "... = \<one>\<^sub>M"
      using A2 xcmplx_1_th_60 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A10: "?X(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?X(n)"
      using nat_1_sch_2 A10 A3 sorry
    thus " for n be NatNAT-1M1 holds Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 Partial-SumsSERIES-1K3 s1 .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_54:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n"
        have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A3 xreal_1_th_7 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have A5: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 sorry
        have "0NUMBERSK6 +XCMPLX-0K2 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 +XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 n) <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 +XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 n)"
          using xreal_1_th_8 sorry
        then have "(\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M)*XCMPLX-0K3 n <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 ((\<one>\<six>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 +XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
        then have "(\<four>\<^sub>M *NAT-1K2 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<four>\<^sub>M)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n"
          using A3 xreal_1_th_106 sorry
        then have "(\<four>\<^sub>M *NAT-1K2 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 ((\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n"
          using xcmplx_1_th_62 sorry
        then have "\<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n"
          using xcmplx_1_th_91 sorry
        then have "\<one>\<^sub>M +XCMPLX-0K2 (\<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1) <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
          using xreal_1_th_8 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<four>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
           sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 (\<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
          using xcmplx_1_th_76 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)))+XCMPLX-0K2 (\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))^2SQUARE-1K1 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 n"
          using xcmplx_1_th_74 sorry
        then have "(\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 (\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 n"
          using A3 xcmplx_1_th_113 sorry
        then have "sqrtSQUARE-1K3 (\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M)^2SQUARE-1K1 <XXREAL-0R3 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 n)/XCMPLX-0K7 n)"
          using square_1_th_27 sorry
        then have "\<two>\<^sub>M /XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 n)/XCMPLX-0K7 n)"
          using square_1_th_22 sorry
        then have "(\<two>\<^sub>M +NAT-1K1 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 sqrtSQUARE-1K3 ((\<one>\<^sub>M +XCMPLX-0K2 n)/XCMPLX-0K7 n)"
          using xcmplx_1_th_113 sorry
        then have A6: "(\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)/XCMPLX-0K7 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n) /XCMPLX-0K7 sqrtSQUARE-1K3 n"
          using square_1_th_30 sorry
        have "sqrtSQUARE-1K3 n >XXREAL-0R4 0NUMBERSK6"
          using A3 square_1_th_25 sorry
        then have "(\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 ((\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 n) <XXREAL-0R3 (\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n) *XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M))"
          using A6 xreal_1_th_68 xreal_1_th_102 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n))*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<seven>\<^sub>M) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n)"
          using A4 xxreal_0_th_2 sorry
        then have A7: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n) <XXREAL-0R3 (((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n))*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<seven>\<^sub>M) -XCMPLX-0K6 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n))+XCMPLX-0K2 sqrtSQUARE-1K3 (\<one>\<^sub>M +XCMPLX-0K2 n)"
          using xreal_1_th_8 sorry
        show "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using A5 A7 series_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = \<one>\<^sub>M"
      using A1 square_1_th_18 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A8: "?X(\<one>\<^sub>M)"
      using square_1_th_18 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A8 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n <XXREAL-0R3 ((\<one>\<^sub>M /XCMPLX-0K7 \<six>\<^sub>M)*XCMPLX-0K3 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_55:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 Lamb1)*XCMPLX-0K3 sqrtSQUARE-1K3 Lamb1"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 n & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n"
        have "\<two>\<^sub>M *XCMPLX-0K3 n >=XXREAL-0R2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
          using A3 xreal_1_th_64 sorry
        then have "\<two>\<^sub>M *XCMPLX-0K3 n >XXREAL-0R4 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have A5: "\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
          using xreal_1_th_50 sorry
        have "\<three>\<^sub>M *XCMPLX-0K3 n >=XXREAL-0R2 \<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
          using A3 xreal_1_th_64 sorry
        then have "\<three>\<^sub>M *XCMPLX-0K3 n >XXREAL-0R4 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have "\<one>\<^sub>M -XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 n <XXREAL-0R3 0NUMBERSK6"
          using xreal_1_th_49 sorry
        then have "((\<one>\<^sub>M +XCMPLX-0K2 (n -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n))+XCMPLX-0K2 (\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1))+XCMPLX-0K2 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1)+XCMPLX-0K2 n)+XCMPLX-0K2 ((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M"
           sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 (n  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 n) -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 (n *XCMPLX-0K3 n))+XCMPLX-0K2 n)+XCMPLX-0K2 ((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M) <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M"
          using newton_th_6 sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<two>\<^sub>M -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 ((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M"
           sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 n +XCMPLX-0K2 ((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<three>\<^sub>M"
          using newton_th_81 sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 (n  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 n)"
          using newton_th_6 sorry
        then have "((\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 n)+XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (\<four>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 n"
           sorry
        then have "(\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)^2SQUARE-1K1 *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (\<four>\<^sub>M *XCMPLX-0K3 n ^2SQUARE-1K1)*XCMPLX-0K3 n"
          using newton_th_81 sorry
        then have "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 n)^2SQUARE-1K1 /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)^2SQUARE-1K1"
          using A3 A5 xreal_1_th_106 sorry
        then have "(n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n <XXREAL-0R3 ((\<two>\<^sub>M *XCMPLX-0K3 n)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M))^2SQUARE-1K1"
          using xcmplx_1_th_76 sorry
        then have "sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n) <XXREAL-0R3 sqrtSQUARE-1K3 ((\<two>\<^sub>M *XCMPLX-0K3 n)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M))^2SQUARE-1K1"
          using square_1_th_27 sorry
        then have "sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 n) <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 n)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)"
          using A5 square_1_th_22 sorry
        then have A6: "sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) /XCMPLX-0K7 sqrtSQUARE-1K3 n <XXREAL-0R3 (\<two>\<^sub>M *XCMPLX-0K3 n)/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)"
          using square_1_th_30 sorry
        have "sqrtSQUARE-1K3 n >XXREAL-0R4 0NUMBERSK6"
          using A3 square_1_th_25 sorry
        then have "(\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 n -XCMPLX-0K6 \<one>\<^sub>M)) <XXREAL-0R3 (\<one>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 ((\<two>\<^sub>M *XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
          using A5 A6 xreal_1_th_68 xreal_1_th_102 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using A4 xxreal_0_th_2 sorry
        then have A7: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_8 sorry
        have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A3 xreal_1_th_7 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using A1 A7 sorry
        thus "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)"
          using series_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = \<one>\<^sub>M"
      using A1 square_1_th_18 sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A8: "?X(\<one>\<^sub>M)"
      using square_1_th_18 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A8 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 ((\<two>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M)*XCMPLX-0K3 n)*XCMPLX-0K3 sqrtSQUARE-1K3 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_56:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<three>\<^sub>M)"
    have A1: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<three>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 \<five>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
       sorry
    assume A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<one>\<^sub>M) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
    have A3: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) implies Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<three>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A5: "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)"
        have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A4 xreal_1_th_7 sorry
        then have A6: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        have A7: "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using square_1_th_25 sorry
        have "\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M) >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using xreal_1_th_8 sorry
        then have "(\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M"
           sorry
        then have "(\<one>\<^sub>M ^2SQUARE-1K1 /XCMPLX-0K7 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M"
          using square_1_def_2 sorry
        then have "((\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M)+XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M"
          using xcmplx_1_th_76 sorry
        then have "((\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M)+XCMPLX-0K2 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M"
          using square_1_def_2 sorry
        then have "((\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))))+XCMPLX-0K2 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 >XXREAL-0R4 \<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M"
          using A7 xcmplx_1_th_106 sorry
        then have "sqrtSQUARE-1K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using square_1_th_27 sorry
        then have "sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) >XXREAL-0R4 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using A7 square_1_th_22 sorry
        then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using xreal_1_th_68 sorry
        have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
          using A5 xreal_1_th_68 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
           sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 ((\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)"
          using xcmplx_1_th_74 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
          using xcmplx_1_th_74 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)^2SQUARE-1K1)"
          using square_1_th_22 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) *XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)))"
          using square_1_th_29 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 ((sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)))"
          using xcmplx_1_th_76 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M) +XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M)))"
          using A7 xcmplx_1_th_60 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using A8 xxreal_0_th_2 sorry
        then have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<five>\<^sub>M)"
          using A2 A6 sorry
        thus "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<three>\<^sub>M)"
          using series_3_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "sqrtSQUARE-1K3 (\<one>\<six>\<^sub>M /XCMPLX-0K7 \<nine>\<^sub>M) >XXREAL-0R4 sqrtSQUARE-1K3 (\<five>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)"
      using square_1_th_27 sorry
    then have "sqrtSQUARE-1K3 \<four>\<^sub>M ^2SQUARE-1K1 /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M ^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 (\<five>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)"
      using square_1_th_30 sorry
    then have "\<four>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 \<three>\<^sub>M ^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 (\<five>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)"
      using square_1_th_22 sorry
    then have "\<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M >XXREAL-0R4 sqrtSQUARE-1K3 (\<five>\<^sub>M /XCMPLX-0K7 \<four>\<^sub>M)"
      using square_1_th_22 sorry
    then have A9: "\<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M >XXREAL-0R4 sqrtSQUARE-1K3 \<five>\<^sub>M /XCMPLX-0K7 sqrtSQUARE-1K3 \<two>\<^sub>M ^2SQUARE-1K1"
      using square_1_th_30 sorry
    have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6)"
      using series_3_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_3_def_1 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A2 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using A2 sorry
    also have "... = \<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
       sorry
    finally have "Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (\<one>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 \<four>\<^sub>M /XCMPLX-0K7 \<three>\<^sub>M"
       sorry
    then have A10: "?X(\<one>\<^sub>M)"
      using A1 A9 square_1_th_22 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A10 A3 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-ProductSERIES-3K1 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M)*XCMPLX-0K3 sqrtSQUARE-1K3 (\<two>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<three>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem series_5_th_57:
" for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6) implies ( for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule impI)
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    let ?X = "\<lambda>Lamb1. Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> Lamb1 >XXREAL-0R4 (Lamb1 *XCMPLX-0K3 (Lamb1 +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
    assume A1: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n =COMPLEX1R1 sqrtSQUARE-1K3 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)) & s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & ?X(n) implies ?X(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M implies Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
      proof(rule ballI,rule impMI ,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
          and A4: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
        have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
          using A3 xreal_1_th_7 sorry
        then have "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have A5: "s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using A1 sorry
        have "n +NAT-1K1 \<two>\<^sub>M >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_8 sorry
        then have "(n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
          using xreal_1_th_68 sorry
        then have "sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 sqrtSQUARE-1K3 (n +NAT-1K1 \<one>\<^sub>M)^2SQUARE-1K1"
          using square_1_th_27 sorry
        then have A6: "sqrtSQUARE-1K3 ((n +NAT-1K1 \<two>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 n +NAT-1K1 \<one>\<^sub>M"
          using square_1_th_22 sorry
        have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 (sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M) >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 (sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) -XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)"
          using A4 xreal_1_th_8 sorry
        then have "(Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))-XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)) -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
           sorry
        then have "(Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))-XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
          using A6 xreal_1_th_50 sorry
        then have A7: "((Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n +XCMPLX-0K2 sqrtSQUARE-1K3 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M)))-XCMPLX-0K6 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 ((n +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (n +NAT-1K1 \<two>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
          using xreal_1_th_8 sorry
        show "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
          using A5 A7 series_1_def_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> (0NUMBERSK6) +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using series_1_def_1 sorry
    also have "... = 0NUMBERSK6 +XCMPLX-0K2 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M"
      using A1 sorry
    also have "... = sqrtSQUARE-1K3 (\<one>\<^sub>M *NAT-1K2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))"
      using A1 sorry
    also have "... = sqrtSQUARE-1K3 \<two>\<^sub>M"
       sorry
    finally have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M =HIDDENR1 sqrtSQUARE-1K3 \<two>\<^sub>M"
       sorry
    then have "(Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)^2SQUARE-1K1 =COMPLEX1R1 \<two>\<^sub>M"
      using square_1_def_2 sorry
    then have "sqrtSQUARE-1K3 (Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)^2SQUARE-1K1 >XXREAL-0R4 sqrtSQUARE-1K3 ((\<one>\<^sub>M *NAT-1K2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)^2SQUARE-1K1"
      using square_1_th_27 sorry
    then have A9: "sqrtSQUARE-1K3 (Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M)^2SQUARE-1K1 >XXREAL-0R4 (\<one>\<^sub>M *NAT-1K2 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M"
      using square_1_th_22 sorry
    have "Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using A8 square_1_th_25 sorry
    then have A10: "?X(\<one>\<^sub>M)"
      using A9 square_1_th_22 sorry
    have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies ?X(n)"
      using nat_1_sch_8 A10 A2 sorry
    thus " for n be NatNAT-1M1 holds  not (n >=XXREAL-0R2 \<one>\<^sub>M & Partial-SumsSERIES-1K3 s .NAT-1K8\<^bsub>(REALNUMBERSK2)\<^esub> n >XXREAL-0R4 (n *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
