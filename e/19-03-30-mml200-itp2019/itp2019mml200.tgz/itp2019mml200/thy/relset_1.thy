theory relset_1
  imports relat_1
begin
(*begin*)
reserve A, B, X, X1, Y, Y1, Y2, Z for "setHIDDENM2"
reserve a, x, y, z for "objectHIDDENM1"
syntax RELSET_1M1 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("RelationRELSET-1M1-of'( _ , _ ')" [0,0]70)
translations "RelationRELSET-1M1-of(X,Y)" \<rightharpoonup> "SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :]"

mtheorem relset_1_cl_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster note-that Relation-likeRELAT-1V1 for SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :]"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of [:ZFMISC-1K2 X,Y :] holds it be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem relset_1_cl_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster note-that X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5 for RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(X,Y) holds it be X -definedRELAT-1V4\<bar>Y -valuedRELAT-1V5"
  proof-
    have " for R be RelationRELSET-1M1-of(X,Y) holds R be X -definedRELAT-1V4 & R be Y -valuedRELAT-1V5"
    proof(rule ballI)
      fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
      have "domRELAT-1K1 R c=TARSKIR1 X & R be Y -valuedRELAT-1V5"
      proof(rule conjMI)
        show "domRELAT-1K1 R c=TARSKIR1 X"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 R implies x inHIDDENR3 X"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELAT-1K1 R"
            then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
              using xtuple_0_def_12 sorry
            thus "x inHIDDENR3 X"
              using zfmisc_1_th_87 sorry
          qed "sorry"
          thus "domRELAT-1K1 R c=TARSKIR1 X"
            using tarski_def_3 sorry
        qed
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELAT-1K2 R implies y inHIDDENR3 Y"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngRELAT-1K2 R"
          then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
            using xtuple_0_def_13 sorry
          thus "y inHIDDENR3 Y"
            using zfmisc_1_th_87 sorry
        qed "sorry"
        thus "R be Y -valuedRELAT-1V5"
          using tarski_def_3 relat_1_def_19 sorry
      qed
      thus "R be X -definedRELAT-1V4 & R be Y -valuedRELAT-1V5"
        using relat_1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

reserve P, R for "RelationRELSET-1M1-of(X,Y)"
syntax RELSET_1R1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ c=RELSET-1R1\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50)
translations "R c=RELSET-1R1\<^bsub>(X,Y)\<^esub> Z" \<rightharpoonup> "R c=TARSKIR1 Z"

mtheorem relset_1_def_1:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "Z be setHIDDENM2"
"redefine pred R c=RELSET-1R1\<^bsub>(X,Y)\<^esub> Z means
   for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z"
proof
(*compatibility*)
  show "R c=RELSET-1R1\<^bsub>(X,Y)\<^esub> Z iff ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z)"
  proof-
    have "(R c=RELAT-1R2 Z implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z)) & (( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z) implies R c=TARSKIR1 Z)"
    proof(rule conjMI,rule impI)
      show "R c=RELAT-1R2 Z implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z)"
         sorry
      assume A1: " for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Z"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 a,b ] inHIDDENR3 Z"
      proof(rule ballI,rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        assume A2: "[TARSKIK4 a,b ] inHIDDENR3 R"
        then obtain a9 where 
          [ty]:"a9 be ElementSUBSET-1M1-of X" and a9Def:"a9 = a"
          using zfmisc_1_th_87 sorry
        obtain b9 where 
          [ty]:"b9 be ElementSUBSET-1M1-of Y" and b9Def:"b9 = b"
          using A2 zfmisc_1_th_87 sorry
        have "[TARSKIK4 a9,b9 ] inHIDDENR3 Z"
          using A1 A2 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 Z"
           sorry
      qed "sorry"
      thus "R c=TARSKIR1 Z"
        using relat_1_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax RELSET_1R2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =RELSET-1R2\<^bsub>'( _ , _ ')\<^esub>  _ " [50,0,0,50]50)
translations "P =RELSET-1R2\<^bsub>(X,Y)\<^esub> R" \<rightharpoonup> "P =HIDDENR1 R"

mtheorem relset_1_def_2:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "P be RelationRELSET-1M1-of(X,Y)", "R be RelationRELSET-1M1-of(X,Y)"
"redefine pred P =RELSET-1R2\<^bsub>(X,Y)\<^esub> R means
   for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R"
proof
(*compatibility*)
  show "P =RELSET-1R2\<^bsub>(X,Y)\<^esub> R iff ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R)"
  proof-
    have "(P =RELAT-1R1 R implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R)) & (( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R) implies P =HIDDENR1 R)"
    proof(rule conjMI,rule impI)
      show "P =RELAT-1R1 R implies ( for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R)"
         sorry
      assume A1: " for x be ElementSUBSET-1M1-of X holds  for y be ElementSUBSET-1M1-of Y holds [TARSKIK4 x,y ] inHIDDENR3 P iff [TARSKIK4 x,y ] inHIDDENR3 R"
      have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 R) & ([TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 a,b ] inHIDDENR3 P)"
      proof(rule ballI,rule ballI,rule conjMI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        fix b assume [ty]: "b be objectHIDDENM1"
        show "[TARSKIK4 a,b ] inHIDDENR3 P implies [TARSKIK4 a,b ] inHIDDENR3 R"
        proof(rule impI)
          assume A2: "[TARSKIK4 a,b ] inHIDDENR3 P"
          then obtain a9 where 
            [ty]:"a9 be ElementSUBSET-1M1-of X" and a9Def:"a9 = a"
            using zfmisc_1_th_87 sorry
          obtain b9 where 
            [ty]:"b9 be ElementSUBSET-1M1-of Y" and b9Def:"b9 = b"
            using A2 zfmisc_1_th_87 sorry
          have "[TARSKIK4 a9,b9 ] inHIDDENR3 R"
            using A1 A2 sorry
          thus "[TARSKIK4 a,b ] inHIDDENR3 R"
             sorry
        qed
        assume A3: "[TARSKIK4 a,b ] inHIDDENR3 R"
        then obtain a9 where 
          [ty]:"a9 be ElementSUBSET-1M1-of X" and a9Def:"a9 = a"
          using zfmisc_1_th_87 sorry
        obtain b9 where 
          [ty]:"b9 be ElementSUBSET-1M1-of Y" and b9Def:"b9 = b"
          using A3 zfmisc_1_th_87 sorry
        have "[TARSKIK4 a9,b9 ] inHIDDENR3 P"
          using A1 A3 sorry
        thus "[TARSKIK4 a,b ] inHIDDENR3 P"
           sorry
      qed "sorry"
      thus "P =HIDDENR1 R"
        using relat_1_def_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relset_1_th_1:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds A c=TARSKIR1 R implies A be RelationRELSET-1M1-of(X,Y)"
  using xboole_1_th_1 sorry

mtheorem relset_1_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for a be objectHIDDENM1 holds  for R be RelationRELSET-1M1-of(X,Y) holds a inHIDDENR3 R implies ( ex x be objectHIDDENM1 st  ex y be objectHIDDENM1 st (a =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X) & y inHIDDENR3 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for a be objectHIDDENM1 holds  for R be RelationRELSET-1M1-of(X,Y) holds a inHIDDENR3 R implies  not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((a =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X) & y inHIDDENR3 Y))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix a assume [ty]: "a be objectHIDDENM1"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume A1: "a inHIDDENR3 R"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A2: "a =HIDDENR1 [TARSKIK4 x,y ]"
      using relat_1_def_1 sorry
    have "x inHIDDENR3 X & y inHIDDENR3 Y"
      using A1 A2 zfmisc_1_th_87 sorry
    thus " not ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((a =HIDDENR1 [TARSKIK4 x,y ] & x inHIDDENR3 X) & y inHIDDENR3 Y))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_3:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 Y implies {TARSKIK1 [TARSKIK4 x,y ] } be RelationRELSET-1M1-of(X,Y)"
  using zfmisc_1_th_31 zfmisc_1_th_87 sorry

mtheorem relset_1_th_4:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y implies R be RelationRELSET-1M1-of(X,Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELAT-1M1 holds domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y implies R be RelationRELSET-1M1-of(X,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "domRELAT-1K1 R c=TARSKIR1 X & rngRELAT-1K2 R c=TARSKIR1 Y"
    then have "R c=RELAT-1R2 [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] & [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 X,Y :]"
      using relat_1_th_7 zfmisc_1_th_96 sorry
    thus "R be RelationRELSET-1M1-of(X,Y)"
      using xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_5:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds domRELAT-1K1 R c=TARSKIR1 X1 implies R be RelationRELSET-1M1-of(X1,Y)"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds domRELAT-1K1 R c=TARSKIR1 X1 implies R be RelationRELSET-1M1-of(X1,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have A1: "rngRELAT-1K2 R c=TARSKIR1 Y"
      using relat_1_def_19 sorry
    assume "domRELAT-1K1 R c=TARSKIR1 X1"
    then have "R c=RELSET-1R1\<^bsub>(X,Y)\<^esub> [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] & [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 X1,Y :]"
      using A1 relat_1_th_7 zfmisc_1_th_96 sorry
    thus "R be RelationRELSET-1M1-of(X1,Y)"
      using xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_6:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds rngRELAT-1K2 R c=TARSKIR1 Y1 implies R be RelationRELSET-1M1-of(X,Y1)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds rngRELAT-1K2 R c=TARSKIR1 Y1 implies R be RelationRELSET-1M1-of(X,Y1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have A1: "domRELAT-1K1 R c=TARSKIR1 X"
      using relat_1_def_18 sorry
    assume "rngRELAT-1K2 R c=TARSKIR1 Y1"
    then have "R c=RELSET-1R1\<^bsub>(X,Y)\<^esub> [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] & [:ZFMISC-1K2 domRELAT-1K1 R,rngRELAT-1K2 R :] c=RELAT-1R2 [:ZFMISC-1K2 X,Y1 :]"
      using A1 relat_1_th_7 zfmisc_1_th_96 sorry
    thus "R be RelationRELSET-1M1-of(X,Y1)"
      using xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_7:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds X c=TARSKIR1 X1 & Y c=TARSKIR1 Y1 implies R be RelationRELSET-1M1-of(X1,Y1)"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds X c=TARSKIR1 X1 & Y c=TARSKIR1 Y1 implies R be RelationRELSET-1M1-of(X1,Y1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume "X c=TARSKIR1 X1 & Y c=TARSKIR1 Y1"
    then have "[:ZFMISC-1K2 X,Y :] c=RELAT-1R2 [:ZFMISC-1K2 X1,Y1 :]"
      using zfmisc_1_th_96 sorry
    thus "R be RelationRELSET-1M1-of(X1,Y1)"
      using xboole_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_cl_3:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1", "S be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster R \\/XBOOLE-0K2 S as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "R \\/XBOOLE-0K2 S be X -definedRELAT-1V4"
  proof-
    have A1: "domRELAT-1K1 (R \\/XBOOLE-0K2 S) =XBOOLE-0R4 domRELAT-1K1 R \\/XBOOLE-0K2 domRELAT-1K1 S"
      using xtuple_0_th_23 sorry
    have Cut183: "domRELAT-1K1 R c=TARSKIR1 X & domRELAT-1K1 S c=TARSKIR1 X"
      using relat_1_def_18 sorry
    have "domRELAT-1K1 (R \\/XBOOLE-0K2 S) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (R \\/XBOOLE-0K2 S) c=TARSKIR1 X"
        using A1 xboole_1_th_8 Cut183 sorry
    qed
    thus "R \\/XBOOLE-0K2 S be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem relset_1_cl_4:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R /\\XBOOLE-0K3 S as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "R /\\XBOOLE-0K3 S be X -definedRELAT-1V4"
  proof-
    have "R /\\XBOOLE-0K3 S c=RELAT-1R2 R"
      using xboole_1_th_17 sorry
    then have Cut195: "domRELAT-1K1 R c=TARSKIR1 X & domRELAT-1K1 (R /\\XBOOLE-0K3 S) c=TARSKIR1 domRELAT-1K1 R"
      using relat_1_th_11 relat_1_def_18 sorry
    have "domRELAT-1K1 (R /\\XBOOLE-0K3 S) c=TARSKIR1 X"
    proof-
      show "domRELAT-1K1 (R /\\XBOOLE-0K3 S) c=TARSKIR1 X"
        using Cut195 sorry
    qed
    thus "R /\\XBOOLE-0K3 S be X -definedRELAT-1V4"
      using relat_1_def_18 sorry
  qed
qed "sorry"

mtheorem relset_1_cl_5:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R \\SUBSET-1K6 S as-term-is X -definedRELAT-1V4"
proof
(*coherence*)
  show "R \\SUBSET-1K6 S be X -definedRELAT-1V4"
     sorry
qed "sorry"

mtheorem relset_1_cl_6:
  mlet "X be setHIDDENM2", "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1", "S be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"cluster R \\/XBOOLE-0K2 S as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "R \\/XBOOLE-0K2 S be X -valuedRELAT-1V5"
  proof-
    have A1: "rngRELAT-1K2 (R \\/XBOOLE-0K2 S) =XBOOLE-0R4 rngRELAT-1K2 R \\/XBOOLE-0K2 rngRELAT-1K2 S"
      using relat_1_th_12 sorry
    have Cut209: "rngRELAT-1K2 R c=TARSKIR1 X & rngRELAT-1K2 S c=TARSKIR1 X"
      using relat_1_def_19 sorry
    have "rngRELAT-1K2 (R \\/XBOOLE-0K2 S) c=TARSKIR1 X"
    proof-
      show "rngRELAT-1K2 (R \\/XBOOLE-0K2 S) c=TARSKIR1 X"
        using A1 xboole_1_th_8 Cut209 sorry
    qed
    thus "R \\/XBOOLE-0K2 S be X -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem relset_1_cl_7:
  mlet "X be setHIDDENM2", "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R /\\XBOOLE-0K3 S as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "R /\\XBOOLE-0K3 S be X -valuedRELAT-1V5"
  proof-
    have "R /\\XBOOLE-0K3 S c=RELAT-1R2 R"
      using xboole_1_th_17 sorry
    then have Cut221: "rngRELAT-1K2 R c=TARSKIR1 X & rngRELAT-1K2 (R /\\XBOOLE-0K3 S) c=TARSKIR1 rngRELAT-1K2 R"
      using relat_1_th_11 relat_1_def_19 sorry
    have "rngRELAT-1K2 (R /\\XBOOLE-0K3 S) c=TARSKIR1 X"
    proof-
      show "rngRELAT-1K2 (R /\\XBOOLE-0K3 S) c=TARSKIR1 X"
        using Cut221 sorry
    qed
    thus "R /\\XBOOLE-0K3 S be X -valuedRELAT-1V5"
      using relat_1_def_19 sorry
  qed
qed "sorry"

mtheorem relset_1_cl_8:
  mlet "X be setHIDDENM2", "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1", "S be RelationRELAT-1M1"
"cluster R \\SUBSET-1K6 S as-term-is X -valuedRELAT-1V5"
proof
(*coherence*)
  show "R \\SUBSET-1K6 S be X -valuedRELAT-1V5"
     sorry
qed "sorry"

syntax RELSET_1K1 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("domRELSET-1K1\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "domRELSET-1K1\<^bsub>(X)\<^esub> R" \<rightharpoonup> "domRELAT-1K1 R"

mtheorem relset_1_add_1:
  mlet "X be setHIDDENM2", "R be X -definedRELAT-1V4\<bar>RelationRELAT-1M1"
"cluster domRELAT-1K1 R as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "domRELAT-1K1 R be SubsetSUBSET-1M2-of X"
    using relat_1_def_18 sorry
qed "sorry"

syntax RELSET_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("rngRELSET-1K2\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "rngRELSET-1K2\<^bsub>(X)\<^esub> R" \<rightharpoonup> "rngRELAT-1K2 R"

mtheorem relset_1_add_2:
  mlet "X be setHIDDENM2", "R be X -valuedRELAT-1V5\<bar>RelationRELAT-1M1"
"cluster rngRELAT-1K2 R as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "rngRELAT-1K2 R be SubsetSUBSET-1M2-of X"
    using relat_1_def_19 sorry
qed "sorry"

mtheorem relset_1_th_8:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds fieldRELAT-1K3 R c=TARSKIR1 X \\/XBOOLE-0K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds fieldRELAT-1K3 R c=TARSKIR1 X \\/XBOOLE-0K2 Y"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have "domRELSET-1K1\<^bsub>(X)\<^esub> R \\/XBOOLE-0K2 rngRELSET-1K2\<^bsub>(Y)\<^esub> R c=TARSKIR1 X \\/XBOOLE-0K2 Y"
      using xboole_1_th_13 sorry
    thus "fieldRELAT-1K3 R c=TARSKIR1 X \\/XBOOLE-0K2 Y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) iff domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds (( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) implies domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X) &  not (domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R))))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    show "( for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) implies domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X"
    proof(rule impI)
      assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies ( ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R iff x inHIDDENR3 X"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have "x inHIDDENR3 X implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        proof(rule impI)
          assume "x inHIDDENR3 X"
          then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
            using A1 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
            using xtuple_0_def_12 sorry
        qed
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R iff x inHIDDENR3 X"
           sorry
      qed "sorry"
      thus "domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X"
        using tarski_th_2 sorry
    qed
    show " not (domRELSET-1K1\<^bsub>(X)\<^esub> R =XBOOLE-0R4 X &  not ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 X & ( for y be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R))))"
      using xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) iff rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds (( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y) &  not (rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y &  not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Y & ( for x be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R))))"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    show "( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)) implies rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y"
    proof(rule impI)
      assume A1: " for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ( ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R)"
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R iff y inHIDDENR3 Y"
      proof(rule ballI)
        fix y assume [ty]: "y be objectHIDDENM1"
        have "y inHIDDENR3 Y implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        proof(rule impI)
          assume "y inHIDDENR3 Y"
          then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R"
            using A1 sorry
          thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
            using xtuple_0_def_13 sorry
        qed
        thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R iff y inHIDDENR3 Y"
           sorry
      qed "sorry"
      thus "rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y"
        using tarski_th_2 sorry
    qed
    show " not (rngRELSET-1K2\<^bsub>(Y)\<^esub> R =XBOOLE-0R4 Y &  not ( for y be objectHIDDENM1 holds  not (y inHIDDENR3 Y & ( for x be objectHIDDENM1 holds  not [TARSKIK4 x,y ] inHIDDENR3 R))))"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax RELSET_1K3 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ~RELSET-1K3\<^bsub>'( _ , _ ')\<^esub>" [228,0,0]228)
translations "R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>" \<rightharpoonup> "R ~RELAT-1K4"

mtheorem relset_1_add_3:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)"
"cluster R ~RELAT-1K4 as-term-is RelationRELSET-1M1-of(Y,X)"
proof
(*coherence*)
  show "R ~RELAT-1K4 be RelationRELSET-1M1-of(Y,X)"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4 implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 R ~RELAT-1K4"
      then have "[TARSKIK4 y,x ] inHIDDENR3 R"
        using relat_1_def_7 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Y,X :]"
        using zfmisc_1_th_88 sorry
    qed "sorry"
    thus "R ~RELAT-1K4 be RelationRELSET-1M1-of(Y,X)"
      using relat_1_def_3 sorry
  qed
qed "sorry"

syntax RELSET_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ *RELSET-1K4\<^bsub>'( _ , _ , _ , _ ')\<^esub>  _ " [164,0,0,0,0,164]164)
translations "P *RELSET-1K4\<^bsub>(X,Y1,Y2,Z)\<^esub> R" \<rightharpoonup> "P *RELAT-1K6 R"

mtheorem relset_1_add_4:
  mlet "X be setHIDDENM2", "Y1 be setHIDDENM2", "Y2 be setHIDDENM2", "Z be setHIDDENM2", "P be RelationRELSET-1M1-of(X,Y1)", "R be RelationRELSET-1M1-of(Y2,Z)"
"cluster P *RELAT-1K6 R as-term-is RelationRELSET-1M1-of(X,Z)"
proof
(*coherence*)
  show "P *RELAT-1K6 R be RelationRELSET-1M1-of(X,Z)"
  proof-
    have " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,z ] inHIDDENR3 P *RELAT-1K6 R implies [TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "[TARSKIK4 x,z ] inHIDDENR3 P *RELAT-1K6 R"
      then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R"
        using relat_1_def_8 sorry
      then have "x inHIDDENR3 X & z inHIDDENR3 Z"
        using zfmisc_1_th_87 sorry
      thus "[TARSKIK4 x,z ] inHIDDENR3 [:ZFMISC-1K2 X,Z :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "P *RELAT-1K6 R be RelationRELSET-1M1-of(X,Z)"
      using relat_1_def_3 sorry
  qed
qed "sorry"

mtheorem relset_1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) iff x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R implies x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
      proof(rule impI)
        assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A2: "[TARSKIK4 y,x ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>"
          using A2 relat_1_def_7 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
          using xtuple_0_def_12 sorry
      qed
      have "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      proof(rule impI)
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "[TARSKIK4 x,y ] inHIDDENR3 R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>"
          using xtuple_0_def_12 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 R"
          using A3 relat_1_def_7 sorry
        thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
          using xtuple_0_def_13 sorry
      qed
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) iff x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        using A1 sorry
    qed "sorry"
    thus "domRELSET-1K1\<^bsub>(Y)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) iff x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A4: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
      proof(rule impI)
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A5: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        have "[TARSKIK4 y,x ] inHIDDENR3 R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>"
          using A5 relat_1_def_7 sorry
        thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
          using xtuple_0_def_13 sorry
      qed
      have "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      proof(rule impI)
        assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>)"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A6: "[TARSKIK4 y,x ] inHIDDENR3 R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>"
          using xtuple_0_def_13 sorry
        have "[TARSKIK4 x,y ] inHIDDENR3 R"
          using A6 relat_1_def_7 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
          using xtuple_0_def_12 sorry
      qed
      thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) iff x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        using A4 sorry
    qed "sorry"
    thus "rngRELSET-1K2\<^bsub>(X)\<^esub> (R ~RELSET-1K3\<^bsub>(X,Y)\<^esub>) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds {}XBOOLE-0K1 be RelationRELSET-1M1-of(X,Y)"
  using xboole_1_th_2 sorry

mtheorem relset_1_cl_9:
  mlet "A be emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for RelationRELSET-1M1-of(A,B)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(A,B) holds it be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem relset_1_cl_10:
  mlet "A be emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be setHIDDENM2"
"cluster note-that emptyXBOOLE-0V1 for RelationRELSET-1M1-of(B,A)"
proof
(*coherence*)
  show " for it be RelationRELSET-1M1-of(B,A) holds it be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem relset_1_th_13:
" for X be setHIDDENM2 holds idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
proof-
  have " for X be setHIDDENM2 holds idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "[:ZFMISC-1K2 X,X :] c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
       sorry
    then obtain R where 
      [ty]:"R be RelationRELSET-1M1-of(X,X)" and RDef:"R = [:ZFMISC-1K2 X,X :]"
       sorry
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X implies [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 idRELAT-1K7 X"
      then have "x inHIDDENR3 X & x =HIDDENR1 y"
        using relat_1_def_10 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 R"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "idRELAT-1K7 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_14:
" for X be setHIDDENM2 holds idRELAT-1K7 X be RelationRELSET-1M1-of(X,X)"
  using relset_1_th_13 sorry

mtheorem relset_1_th_15:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 A c=RELAT-1R2 R implies A c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R & A c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 A c=RELAT-1R2 R implies A c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R & A c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume A1: "idRELAT-1K7 A c=RELAT-1R2 R"
    show "A c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 A"
        then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 A"
          using relat_1_def_10 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
          using A1 xtuple_0_def_12 sorry
      qed "sorry"
      thus "A c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        using tarski_def_3 sorry
    qed
    show "A c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 A"
        then have "[TARSKIK4 x,x ] inHIDDENR3 idRELAT-1K7 A"
          using relat_1_def_10 sorry
        thus "x inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
          using A1 xtuple_0_def_13 sorry
      qed "sorry"
      thus "A c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        using tarski_def_3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 X c=RELAT-1R2 R implies X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R & X c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
  using relset_1_th_15 sorry

mtheorem relset_1_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds idRELAT-1K7 Y c=RELAT-1R2 R implies Y c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R & Y =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
  using relset_1_th_15 sorry

syntax RELSET_1K5 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |RELSET-1K5\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> A" \<rightharpoonup> "R  |RELAT-1K8 A"

mtheorem relset_1_add_5:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "A be setHIDDENM2"
"cluster R  |RELAT-1K8 A as-term-is RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show "R  |RELAT-1K8 A be RelationRELSET-1M1-of(X,Y)"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 A implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 R  |RELAT-1K8 A"
      then have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_11 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
         sorry
    qed "sorry"
    thus "R  |RELAT-1K8 A be RelationRELSET-1M1-of(X,Y)"
      using relat_1_def_3 sorry
  qed
qed "sorry"

syntax RELSET_1K6 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _  |`RELSET-1K6\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "B  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R" \<rightharpoonup> "B  |`RELAT-1K9 R"

mtheorem relset_1_add_6:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "B be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)"
"cluster B  |`RELAT-1K9 R as-term-is RelationRELSET-1M1-of(X,Y)"
proof
(*coherence*)
  show "B  |`RELAT-1K9 R be RelationRELSET-1M1-of(X,Y)"
  proof-
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 B  |`RELAT-1K9 R implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 B  |`RELAT-1K9 R"
      then have "[TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
         sorry
    qed "sorry"
    thus "B  |`RELAT-1K9 R be RelationRELSET-1M1-of(X,Y)"
      using relat_1_def_3 sorry
  qed
qed "sorry"

mtheorem relset_1_th_18:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 be RelationRELSET-1M1-of(X1,Y)"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 be RelationRELSET-1M1-of(X1,Y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X1,Y :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1"
      then have "x inHIDDENR3 X1 & y inHIDDENR3 Y"
        using relat_1_def_11 zfmisc_1_th_87 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X1,Y :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 be RelationRELSET-1M1-of(X1,Y)"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_19:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds X c=TARSKIR1 X1 implies R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds X c=TARSKIR1 X1 implies R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume A1: "X c=TARSKIR1 X1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 iff [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1"
      proof(rule impI)
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        then have "x inHIDDENR3 X"
          using zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1"
          using A1 A2 relat_1_def_11 sorry
      qed
      thus "[TARSKIK4 x,y ] inHIDDENR3 R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 iff [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_11 sorry
    qed "sorry"
    thus "R  |RELSET-1K5\<^bsub>(X,Y)\<^esub> X1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R be RelationRELSET-1M1-of(X,Y1)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R be RelationRELSET-1M1-of(X,Y1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R implies [TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y1 :]"
    proof(rule ballI,rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "[TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R"
      then have "y inHIDDENR3 Y1 & x inHIDDENR3 X"
        using relat_1_def_12 zfmisc_1_th_87 sorry
      thus "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y1 :]"
        using zfmisc_1_th_87 sorry
    qed "sorry"
    thus "Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R be RelationRELSET-1M1-of(X,Y1)"
      using relat_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_21:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds Y c=TARSKIR1 Y1 implies Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds Y c=TARSKIR1 Y1 implies Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    assume A1: "Y c=TARSKIR1 Y1"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R iff [TARSKIK4 x,y ] inHIDDENR3 R"
    proof(rule ballI,rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      have "[TARSKIK4 x,y ] inHIDDENR3 R implies [TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R"
      proof(rule impI)
        assume A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
        then have "y inHIDDENR3 Y"
          using zfmisc_1_th_87 sorry
        thus "[TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R"
          using A1 A2 relat_1_def_12 sorry
      qed
      thus "[TARSKIK4 x,y ] inHIDDENR3 Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R iff [TARSKIK4 x,y ] inHIDDENR3 R"
        using relat_1_def_12 sorry
    qed "sorry"
    thus "Y1  |`RELSET-1K6\<^bsub>(X,Y)\<^esub> R =RELSET-1R2\<^bsub>(X,Y)\<^esub> R"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax RELSET_1K7 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .:RELSET-1K7\<^bsub>'( _ , _ ')\<^esub>  _ " [200,0,0,200]200)
translations "R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> A" \<rightharpoonup> "R .:RELAT-1K10 A"

mtheorem relset_1_add_7:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "A be setHIDDENM2"
"cluster R .:RELAT-1K10 A as-term-is SubsetSUBSET-1M2-of Y"
proof
(*coherence*)
  show "R .:RELAT-1K10 A be SubsetSUBSET-1M2-of Y"
  proof-
    have "R .:RELAT-1K10 A c=TARSKIR1 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      using relat_1_th_111 sorry
    thus "R .:RELAT-1K10 A be SubsetSUBSET-1M2-of Y"
      using xboole_1_th_1 sorry
  qed
qed "sorry"

syntax RELSET_1K8 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ \<inverse>RELSET-1K8\<^bsub>'( _ , _ ')\<^esub>  _ " [228,0,0,228]228)
translations "R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> A" \<rightharpoonup> "R \<inverse>RELAT-1K11 A"

mtheorem relset_1_add_8:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "R be RelationRELSET-1M1-of(X,Y)", "A be setHIDDENM2"
"cluster R \<inverse>RELAT-1K11 A as-term-is SubsetSUBSET-1M2-of X"
proof
(*coherence*)
  show "R \<inverse>RELAT-1K11 A be SubsetSUBSET-1M2-of X"
  proof-
    have "R \<inverse>RELAT-1K11 A c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      using relat_1_th_132 sorry
    thus "R \<inverse>RELAT-1K11 A be SubsetSUBSET-1M2-of X"
      using xboole_1_th_1 sorry
  qed
qed "sorry"

mtheorem relset_1_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have " for y be objectHIDDENM1 holds y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X iff y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
    proof(rule ballI)
      fix y assume [ty]: "y be objectHIDDENM1"
      have A1: "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R implies y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X"
      proof(rule impI)
        assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        have "x inHIDDENR3 X"
          using A2 zfmisc_1_th_87 sorry
        thus "y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X"
          using A2 relat_1_def_13 sorry
      qed
      have "y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X implies y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      proof(rule impI)
        assume "y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X"
        then have " ex x be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & x inHIDDENR3 X"
          using relat_1_def_13 sorry
        thus "y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
          using xtuple_0_def_13 sorry
      qed
      thus "y inHIDDENR3 R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X iff y inHIDDENR3 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
        using A1 sorry
    qed "sorry"
    thus "R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      using tarski_th_2 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y iff x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A3: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R implies x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y"
      proof(rule impI)
        assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        have "y inHIDDENR3 Y"
          using A4 zfmisc_1_th_87 sorry
        thus "x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y"
          using A4 relat_1_def_14 sorry
      qed
      have "x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y implies x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      proof(rule impI)
        assume "x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y"
        then have " ex y be objectHIDDENM1 st [TARSKIK4 x,y ] inHIDDENR3 R & y inHIDDENR3 Y"
          using relat_1_def_14 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
          using xtuple_0_def_12 sorry
      qed
      thus "x inHIDDENR3 R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y iff x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> R"
        using A3 sorry
    qed "sorry"
    thus "R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_23:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for R be RelationRELSET-1M1-of(X,Y) holds R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(X,Y)"
    have "R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R & R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R"
      using relset_1_th_22 sorry
    thus "R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> Y =XBOOLE-0R4 rngRELSET-1K2\<^bsub>(Y)\<^esub> R & R \<inverse>RELSET-1K8\<^bsub>(X,Y)\<^esub> (R .:RELSET-1K7\<^bsub>(X,Y)\<^esub> X) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> R"
      using relat_1_th_113 relat_1_th_134 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem relset_1_sch_1:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2"
  shows " ex R be RelationRELSET-1M1-of(Af0,Bf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
  proof-
    have " ex tVar1 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar1 &  not ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar1)"
    proof-
      obtain R where
        [ty]:"R be RelationRELAT-1M1" and 
        A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
        using relat_1_sch_1 sorry
      have "R c=RELAT-1R2 [:ZFMISC-1K2 Af0,Bf0 :]"
      proof-
        have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds [TARSKIK4 x1,x2 ] inHIDDENR3 R implies [TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :]"
        proof(rule ballI,rule ballI,rule impI)
          fix x1 assume [ty]: "x1 be objectHIDDENM1"
          fix x2 assume [ty]: "x2 be objectHIDDENM1"
          assume "[TARSKIK4 x1,x2 ] inHIDDENR3 R"
          then have "x1 inHIDDENR3 Af0 & x2 inHIDDENR3 Bf0"
            using A1 sorry
          thus "[TARSKIK4 x1,x2 ] inHIDDENR3 [:ZFMISC-1K2 Af0,Bf0 :]"
            using zfmisc_1_th_87 sorry
        qed "sorry"
        thus "R c=RELAT-1R2 [:ZFMISC-1K2 Af0,Bf0 :]"
          using relat_1_def_3 sorry
      qed
      then have 
        [ty]:"R be RelationRELSET-1M1-of(Af0,Bf0)"
         sorry
      show " ex tVar1 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar1 &  not ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar1)"
      proof(rule bexI[of _ "R"])
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 R &  not ((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 R)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

syntax RELSET_1M2 :: " Set \<Rightarrow> Ty" ("RelationRELSET-1M2-of  _ " [70]70)
translations "RelationRELSET-1M2-of X" \<rightharpoonup> "RelationRELSET-1M1-of(X,X)"

reserve D, D1, D2, E, F for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve R for "RelationRELSET-1M1-of(D,E)"
reserve x for "ElementSUBSET-1M1-of D"
reserve y for "ElementSUBSET-1M1-of E"
mtheorem relset_1_cl_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster idRELAT-1K7 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "idRELAT-1K7 D be  non emptyXBOOLE-0V1"
  proof-
    have " not idRELAT-1K7 D be emptyXBOOLE-0V1"
    proof-
      have "idRELAT-1K7 D =RELAT-1R1 {}XBOOLE-0K1 implies  False "
      proof(rule impI)
        let ?y = "the ElementSUBSET-1M1-of D"
        have A1: "[TARSKIK4 ?y,?y ] inHIDDENR3 idRELAT-1K7 D"
          using relat_1_def_10 sorry
        assume "idRELAT-1K7 D =RELAT-1R1 {}XBOOLE-0K1"
        thus " False "
          using A1 sorry
      qed
      thus " not idRELAT-1K7 D be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relset_1_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R iff ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for x be ElementSUBSET-1M1-of D holds (x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R)) & (( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R) implies x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    show "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R)"
    proof-
      have "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R implies ( ex tVar2 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar2 ] inHIDDENR3 R)"
      proof(rule impI)
        assume "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_12 sorry
        obtain b where 
          [ty]:"b be ElementSUBSET-1M1-of E" and bDef:"b = y"
          using A1 zfmisc_1_th_87 sorry
        show " ex tVar2 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar2 ] inHIDDENR3 R"
        proof(rule bexI[of _ "b"])
          show "[TARSKIK4 x,b ] inHIDDENR3 R"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R"
    then obtain y where
      [ty]:"y be ElementSUBSET-1M1-of E" and 
      A2: "[TARSKIK4 x,y ] inHIDDENR3 R"
       sorry
    show "x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R"
      using A2 xtuple_0_def_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for y be objectHIDDENM1 holds y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R iff ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for y be objectHIDDENM1 holds (y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R implies ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R)) &  not ( not ( for x be ElementSUBSET-1M1-of D holds  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    fix y assume [ty]: "y be objectHIDDENM1"
    show "y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R implies ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R)"
    proof-
      have "y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R implies ( ex tVar3 be ElementSUBSET-1M1-of D st [TARSKIK4 tVar3,y ] inHIDDENR3 R)"
      proof(rule impI)
        assume "y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"
          using xtuple_0_def_13 sorry
        obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of D" and aDef:"a = x"
          using A1 zfmisc_1_th_87 sorry
        show " ex tVar3 be ElementSUBSET-1M1-of D st [TARSKIK4 tVar3,y ] inHIDDENR3 R"
        proof(rule bexI[of _ "a"])
          show "[TARSKIK4 a,y ] inHIDDENR3 R"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    show " not ( not ( for x be ElementSUBSET-1M1-of D holds  not [TARSKIK4 x,y ] inHIDDENR3 R) &  not y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R)"
      using xtuple_0_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds domRELSET-1K1\<^bsub>(D)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1 implies ( ex y be ElementSUBSET-1M1-of E st y inTARSKIR2 rngRELSET-1K2\<^bsub>(E)\<^esub> R)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds domRELSET-1K1\<^bsub>(D)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for y be ElementSUBSET-1M1-of E holds  not y inTARSKIR2 rngRELSET-1K2\<^bsub>(E)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    assume "domRELSET-1K1\<^bsub>(D)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1"
    then have "rngRELSET-1K2\<^bsub>(E)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1"
      using relat_1_th_42 sorry
    then have " ex y be objectHIDDENM1 st y inHIDDENR3 rngRELSET-1K2\<^bsub>(E)\<^esub> R"
      using xboole_0_def_1 sorry
    thus " not ( for y be ElementSUBSET-1M1-of E holds  not y inTARSKIR2 rngRELSET-1K2\<^bsub>(E)\<^esub> R)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds rngRELSET-1K2\<^bsub>(E)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1 implies ( ex x be ElementSUBSET-1M1-of D st x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds rngRELSET-1K2\<^bsub>(E)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1 implies  not ( for x be ElementSUBSET-1M1-of D holds  not x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    assume "rngRELSET-1K2\<^bsub>(E)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1"
    then have "domRELSET-1K1\<^bsub>(D)\<^esub> R <>HIDDENR2 {}XBOOLE-0K1"
      using relat_1_th_42 sorry
    then have " ex x be objectHIDDENM1 st x inHIDDENR3 domRELSET-1K1\<^bsub>(D)\<^esub> R"
      using xboole_0_def_1 sorry
    thus " not ( for x be ElementSUBSET-1M1-of D holds  not x inTARSKIR2 domRELSET-1K1\<^bsub>(D)\<^esub> R)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for P be RelationRELSET-1M1-of(D,E) holds  for R be RelationRELSET-1M1-of(E,F) holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds [TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R iff ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for P be RelationRELSET-1M1-of(D,E) holds  for R be RelationRELSET-1M1-of(E,F) holds  for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ([TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R)) & (( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R) implies [TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix P assume [ty]: "P be RelationRELSET-1M1-of(D,E)"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(E,F)"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix z assume [ty]: "z be objectHIDDENM1"
    show "[TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R)"
    proof-
      have "[TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R implies ( ex tVar4 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar4 ] inHIDDENR3 P & [TARSKIK4 tVar4,z ] inHIDDENR3 R)"
      proof(rule impI)
        assume "[TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 P"and A2: "[TARSKIK4 y,z ] inHIDDENR3 R"
          using relat_1_def_8 sorry
        obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of E" and aDef:"a = y"
          using A1 zfmisc_1_th_87 sorry
        show " ex tVar4 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar4 ] inHIDDENR3 P & [TARSKIK4 tVar4,z ] inHIDDENR3 R"
        proof(rule bexI[of _ "a"])
          show "[TARSKIK4 x,a ] inHIDDENR3 P & [TARSKIK4 a,z ] inHIDDENR3 R"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R"
    then obtain y where
      [ty]:"y be ElementSUBSET-1M1-of E" and 
      A3: "[TARSKIK4 x,y ] inHIDDENR3 P & [TARSKIK4 y,z ] inHIDDENR3 R"
       sorry
    show "[TARSKIK4 x,z ] inHIDDENR3 P *RELSET-1K4\<^bsub>(D,E,E,F)\<^esub> R"
      using A3 relat_1_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for y be ElementSUBSET-1M1-of E holds y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1 iff ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for y be ElementSUBSET-1M1-of E holds (y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1 implies ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1)) & (( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1) implies y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of E"
    show "y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1 implies ( ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1)"
    proof-
      have "y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1 implies ( ex tVar5 be ElementSUBSET-1M1-of D st [TARSKIK4 tVar5,y ] inHIDDENR3 R & tVar5 inTARSKIR2 D1)"
      proof(rule impI)
        assume "y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "x inHIDDENR3 D1"
          using relat_1_def_13 sorry
        obtain a where 
          [ty]:"a be ElementSUBSET-1M1-of D" and aDef:"a = x"
          using A1 zfmisc_1_th_87 sorry
        show " ex tVar5 be ElementSUBSET-1M1-of D st [TARSKIK4 tVar5,y ] inHIDDENR3 R & tVar5 inTARSKIR2 D1"
        proof(rule bexI[of _ "a"])
          show "[TARSKIK4 a,y ] inHIDDENR3 R & a inTARSKIR2 D1"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex x be ElementSUBSET-1M1-of D st [TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1"
    then obtain x where
      [ty]:"x be ElementSUBSET-1M1-of D" and 
      A3: "[TARSKIK4 x,y ] inHIDDENR3 R & x inTARSKIR2 D1"
       sorry
    show "y inTARSKIR2 R .:RELSET-1K7\<^bsub>(D,E)\<^esub> D1"
      using A3 relat_1_def_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for x be ElementSUBSET-1M1-of D holds x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2 iff ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for R be RelationRELSET-1M1-of(D,E) holds  for x be ElementSUBSET-1M1-of D holds (x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2 implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2)) & (( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2) implies x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D2 assume [ty]: "D2 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix R assume [ty]: "R be RelationRELSET-1M1-of(D,E)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    show "x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2 implies ( ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2)"
    proof-
      have "x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2 implies ( ex tVar6 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar6 ] inHIDDENR3 R & tVar6 inTARSKIR2 D2)"
      proof(rule impI)
        assume "x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A1: "[TARSKIK4 x,y ] inHIDDENR3 R"and A2: "y inHIDDENR3 D2"
          using relat_1_def_14 sorry
        obtain b where 
          [ty]:"b be ElementSUBSET-1M1-of E" and bDef:"b = y"
          using A1 zfmisc_1_th_87 sorry
        show " ex tVar6 be ElementSUBSET-1M1-of E st [TARSKIK4 x,tVar6 ] inHIDDENR3 R & tVar6 inTARSKIR2 D2"
        proof(rule bexI[of _ "b"])
          show "[TARSKIK4 x,b ] inHIDDENR3 R & b inTARSKIR2 D2"
            using A1 A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex y be ElementSUBSET-1M1-of E st [TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2"
    then obtain y where
      [ty]:"y be ElementSUBSET-1M1-of E" and 
      A3: "[TARSKIK4 x,y ] inHIDDENR3 R & y inTARSKIR2 D2"
       sorry
    show "x inTARSKIR2 R \<inverse>RELSET-1K8\<^bsub>(D,E)\<^esub> D2"
      using A3 relat_1_def_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem relset_1_sch_2:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  shows " ex R be RelationRELSET-1M1-of(Af0,Bf0) st  for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds [TARSKIK4 x,y ] inHIDDENR3 R iff Pp2(x,y)"
  proof-
    have " ex tVar7 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar7 &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar7)"
    proof-
      obtain R where
        [ty]:"R be RelationRELSET-1M1-of(Af0,Bf0)" and 
        A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
        using relset_1_sch_1 sorry
      show " ex tVar7 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar7 &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar7)"
      proof(rule bexI[of _ "R"])
        show " for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 R &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 R)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

(*begin*)
theorem relset_1_sch_3:
  fixes Nf0 Mf0 Ff1 
  assumes
[ty]: "Nf0 be setHIDDENM2" and
  [ty]: "Mf0 be SubsetSUBSET-1M2-of Nf0" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for i be ElementSUBSET-1M1-of Nf0 holds i inTARSKIR2 Mf0 implies Ff1(i) c=TARSKIR1 Mf0"
  shows " ex R be RelationRELSET-1M2-of Mf0 st  for i be ElementSUBSET-1M1-of Nf0 holds i inTARSKIR2 Mf0 implies ImRELAT-1K12(R,i) =XBOOLE-0R4 Ff1(i)"
  proof-
    have " ex tVar8 be RelationRELSET-1M2-of Mf0 st  for i be ElementSUBSET-1M1-of Nf0 holds i inTARSKIR2 Mf0 implies ImRELAT-1K12(tVar8,i) =XBOOLE-0R4 Ff1(i)"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inHIDDENR3 Ff1(Lamb1)"
      obtain R where
        [ty]:"R be RelationRELSET-1M2-of Mf0" and 
        A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Mf0 & y inHIDDENR3 Mf0) & ?P(x,y)"
        using relset_1_sch_1 sorry
      show " ex tVar8 be RelationRELSET-1M2-of Mf0 st  for i be ElementSUBSET-1M1-of Nf0 holds i inTARSKIR2 Mf0 implies ImRELAT-1K12(tVar8,i) =XBOOLE-0R4 Ff1(i)"
      proof(rule bexI[of _ "R"],rule ballI,rule impI)
        fix i assume [ty]: "i be ElementSUBSET-1M1-of Nf0"
        assume A3: "i inTARSKIR2 Mf0"
        have "ImRELAT-1K12(R,i) c=TARSKIR1 Ff1(i) & Ff1(i) c=TARSKIR1 ImRELAT-1K12(R,i)"
        proof(rule conjMI)
          show "ImRELAT-1K12(R,i) c=TARSKIR1 Ff1(i)"
          proof-
            have " for e be objectHIDDENM1 holds e inHIDDENR3 ImRELAT-1K12(R,i) implies e inHIDDENR3 Ff1(i)"
            proof(rule ballI,rule impI)
              fix e assume [ty]: "e be objectHIDDENM1"
              assume "e inHIDDENR3 ImRELAT-1K12(R,i)"
              then obtain u where
                [ty]:"u be objectHIDDENM1" and 
                A4: "[TARSKIK4 u,e ] inHIDDENR3 R"and A5: "u inHIDDENR3 {TARSKIK1 i}"
                using relat_1_def_13 sorry
              have "u =HIDDENR1 i"
                using A5 tarski_def_1 sorry
              thus "e inHIDDENR3 Ff1(i)"
                using A2 A4 sorry
            qed "sorry"
            thus "ImRELAT-1K12(R,i) c=TARSKIR1 Ff1(i)"
              using tarski_def_3 sorry
          qed
          have " for e be objectHIDDENM1 holds e inHIDDENR3 Ff1(i) implies e inHIDDENR3 ImRELAT-1K12(R,i)"
          proof(rule ballI,rule impI)
            fix e assume [ty]: "e be objectHIDDENM1"
            assume A6: "e inHIDDENR3 Ff1(i)"
            have "Ff1(i) c=TARSKIR1 Mf0"
              using A1 A3 sorry
            then have "i inTARSKIR2 {TARSKIK1 i} & [TARSKIK4 i,e ] inHIDDENR3 R"
              using A2 A3 A6 tarski_def_1 sorry
            thus "e inHIDDENR3 ImRELAT-1K12(R,i)"
              using relat_1_def_13 sorry
          qed "sorry"
          thus "Ff1(i) c=TARSKIR1 ImRELAT-1K12(R,i)"
            using tarski_def_3 sorry
        qed
        thus "ImRELAT-1K12(R,i) =XBOOLE-0R4 Ff1(i)"
          using xboole_0_def_10 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mtheorem relset_1_th_31:
" for N be setHIDDENM2 holds  for R be RelationRELSET-1M2-of N holds  for S be RelationRELSET-1M2-of N holds ( for i be setHIDDENM2 holds i inTARSKIR2 N implies ImRELAT-1K12(R,i) =XBOOLE-0R4 ImRELAT-1K12(S,i)) implies R =RELSET-1R2\<^bsub>(N,N)\<^esub> S"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix N assume [ty]: "N be setHIDDENM2"
  fix R assume [ty]: "R be RelationRELSET-1M2-of N"
  fix S assume [ty]: "S be RelationRELSET-1M2-of N"
  assume A1: " for i be setHIDDENM2 holds i inTARSKIR2 N implies ImRELAT-1K12(R,i) =XBOOLE-0R4 ImRELAT-1K12(S,i)"
  have " for a be ElementSUBSET-1M1-of N holds  for b be ElementSUBSET-1M1-of N holds ([TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 a,b ] inHIDDENR3 S) & ([TARSKIK4 a,b ] inHIDDENR3 S implies [TARSKIK4 a,b ] inHIDDENR3 R)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix a assume [ty]: "a be ElementSUBSET-1M1-of N"
    fix b assume [ty]: "b be ElementSUBSET-1M1-of N"
    show "[TARSKIK4 a,b ] inHIDDENR3 R implies [TARSKIK4 a,b ] inHIDDENR3 S"
    proof(rule impI)
      assume A2: "[TARSKIK4 a,b ] inHIDDENR3 R"
      then have A3: "a inTARSKIR2 domRELSET-1K1\<^bsub>(N)\<^esub> R"
        using xtuple_0_def_12 sorry
      have "a inTARSKIR2 {TARSKIK1 a}"
        using tarski_def_1 sorry
      then have "b inTARSKIR2 ImRELAT-1K12(R,a)"
        using A2 relat_1_def_13 sorry
      then have "b inTARSKIR2 ImRELAT-1K12(S,a)"
        using A1 A3 sorry
      then have " ex e be objectHIDDENM1 st [TARSKIK4 e,b ] inHIDDENR3 S & e inHIDDENR3 {TARSKIK1 a}"
        using relat_1_def_13 sorry
      thus "[TARSKIK4 a,b ] inHIDDENR3 S"
        using tarski_def_1 sorry
    qed
    assume A4: "[TARSKIK4 a,b ] inHIDDENR3 S"
    then have A5: "a inTARSKIR2 domRELSET-1K1\<^bsub>(N)\<^esub> S"
      using xtuple_0_def_12 sorry
    have "a inTARSKIR2 {TARSKIK1 a}"
      using tarski_def_1 sorry
    then have "b inTARSKIR2 ImRELAT-1K12(S,a)"
      using A4 relat_1_def_13 sorry
    then have "b inTARSKIR2 ImRELAT-1K12(R,a)"
      using A1 A5 sorry
    then have " ex e be objectHIDDENM1 st [TARSKIK4 e,b ] inHIDDENR3 R & e inHIDDENR3 {TARSKIK1 a}"
      using relat_1_def_13 sorry
    thus "[TARSKIK4 a,b ] inHIDDENR3 R"
      using tarski_def_1 sorry
  qed "sorry"
  thus "R =RELSET-1R2\<^bsub>(N,N)\<^esub> S"
    using relset_1_def_2 sorry
qed "sorry"

theorem relset_1_sch_4:
  fixes Af0 Bf0 Pf0 Rf0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Pf0 be RelationRELSET-1M1-of(Af0,Bf0)" and
  [ty]: "Rf0 be RelationRELSET-1M1-of(Af0,Bf0)" and
   A1: " for p be ElementSUBSET-1M1-of Af0 holds  for q be ElementSUBSET-1M1-of Bf0 holds [TARSKIK4 p,q ] inHIDDENR3 Pf0 iff Pp2(p,q)" and
   A2: " for p be ElementSUBSET-1M1-of Af0 holds  for q be ElementSUBSET-1M1-of Bf0 holds [TARSKIK4 p,q ] inHIDDENR3 Rf0 iff Pp2(p,q)"
  shows "Pf0 =RELSET-1R2\<^bsub>(Af0,Bf0)\<^esub> Rf0"
  proof-
    have " for y be ElementSUBSET-1M1-of Af0 holds  for z be ElementSUBSET-1M1-of Bf0 holds  not ([TARSKIK4 y,z ] inHIDDENR3 Pf0 &  not [TARSKIK4 y,z ] inHIDDENR3 Rf0) &  not ([TARSKIK4 y,z ] inHIDDENR3 Rf0 &  not [TARSKIK4 y,z ] inHIDDENR3 Pf0)"
    proof(rule ballI,rule ballI)
      fix y assume [ty]: "y be ElementSUBSET-1M1-of Af0"
      fix z assume [ty]: "z be ElementSUBSET-1M1-of Bf0"
      have "[TARSKIK4 y,z ] inHIDDENR3 Pf0 iff Pp2(y,z)"
        using A1 sorry
      thus " not ([TARSKIK4 y,z ] inHIDDENR3 Pf0 &  not [TARSKIK4 y,z ] inHIDDENR3 Rf0) &  not ([TARSKIK4 y,z ] inHIDDENR3 Rf0 &  not [TARSKIK4 y,z ] inHIDDENR3 Pf0)"
        using A2 sorry
    qed "sorry"
    thus "Pf0 =RELSET-1R2\<^bsub>(Af0,Bf0)\<^esub> Rf0"
      using relset_1_def_2 sorry
  qed

mtheorem relset_1_cl_12:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "Z be setHIDDENM2", "f be RelationRELSET-1M1-of([:ZFMISC-1K2 X,Y :],Z)"
"cluster domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem relset_1_cl_13:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "Z be setHIDDENM2", "f be RelationRELSET-1M1-of(X,[:ZFMISC-1K2 Y,Z :])"
"cluster rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> f as-term-is Relation-likeRELAT-1V1"
proof
(*coherence*)
  show "rngRELSET-1K2\<^bsub>([:ZFMISC-1K2 Y,Z :])\<^esub> f be Relation-likeRELAT-1V1"
     sorry
qed "sorry"

mtheorem relset_1_th_32:
" for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELSET-1M1-of(X,Y) holds A missesXBOOLE-0R1 X implies P  |RELSET-1K5\<^bsub>(X,Y)\<^esub> A =RELAT-1R1 {}XBOOLE-0K1"
proof-
  have " for A be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for P be RelationRELSET-1M1-of(X,Y) holds A missesXBOOLE-0R1 X implies P  |RELSET-1K5\<^bsub>(X,Y)\<^esub> A =RELAT-1R1 {}XBOOLE-0K1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix P assume [ty]: "P be RelationRELSET-1M1-of(X,Y)"
    assume "A missesXBOOLE-0R1 X"
    then have "A missesXBOOLE-0R1 domRELSET-1K1\<^bsub>(X)\<^esub> P"
      using xboole_1_th_63 sorry
    thus "P  |RELSET-1K5\<^bsub>(X,Y)\<^esub> A =RELAT-1R1 {}XBOOLE-0K1"
      using relat_1_th_152 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem relset_1_cl_14:
  mlet "R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of domRELAT-1K1 R"
"cluster R  |RELAT-1K8 Y as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R  |RELAT-1K8 Y be  non emptyXBOOLE-0V1"
  proof-
    have " not R  |RELAT-1K8 Y be emptyXBOOLE-0V1"
    proof-
      have "domRELAT-1K1 (R  |RELAT-1K8 Y) =XBOOLE-0R4 Y"
        using relat_1_th_62 sorry
      thus " not R  |RELAT-1K8 Y be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relset_1_cl_15:
  mlet "R be  non emptyXBOOLE-0V1\<bar>RelationRELAT-1M1", "Y be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of domRELAT-1K1 R"
"cluster R .:RELAT-1K10 Y as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "R .:RELAT-1K10 Y be  non emptyXBOOLE-0V1"
  proof-
    have " not R .:RELAT-1K10 Y be emptyXBOOLE-0V1"
    proof-
      have "R .:RELAT-1K10 Y =XBOOLE-0R4 rngRELAT-1K2 (R  |RELAT-1K8 Y)"
        using relat_1_th_115 sorry
      thus " not R .:RELAT-1K10 Y be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem relset_1_cl_16:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2"
"cluster emptyXBOOLE-0V1 for RelationRELSET-1M1-of(X,Y)"
proof
(*existence*)
  show " ex it be RelationRELSET-1M1-of(X,Y) st it be emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be RelationRELSET-1M1-of(X,Y) holds  not VarFor1 be emptyXBOOLE-0V1)"
    proof-
      have "{}XBOOLE-0K1 be RelationRELSET-1M1-of(X,Y)"
        using xboole_1_th_2 sorry
      thus " not ( for VarFor1 be RelationRELSET-1M1-of(X,Y) holds  not VarFor1 be emptyXBOOLE-0V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

theorem relset_1_sch_5:
  fixes Af0 Bf0 Pp2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2"
  shows " ex R be RelationRELSET-1M1-of(Af0,Bf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y)"
  proof-
    have " ex tVar9 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar9 &  not ((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y))) &  not (((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar9)"
    proof-
      obtain R where
        [ty]:"R be RelationRELSET-1M1-of(Af0,Bf0)" and 
        A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 R iff (x inHIDDENR3 Af0 & y inHIDDENR3 Bf0) & Pp2(x,y)"
        using relset_1_sch_1 sorry
      show " ex tVar9 be RelationRELSET-1M1-of(Af0,Bf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ([TARSKIK4 x,y ] inHIDDENR3 tVar9 &  not ((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y))) &  not (((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar9)"
      proof(rule bexI[of _ "R"])
        show " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ([TARSKIK4 x,y ] inHIDDENR3 R &  not ((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y))) &  not (((x inTARSKIR2 Af0 & y inTARSKIR2 Bf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 R)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
