theory ordinal2
  imports ordinal1 funcop_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve A, A1, A2, B, C, D for "OrdinalORDINAL1M3"
reserve X, Y for "setHIDDENM2"
reserve x, y, a, b, c for "objectHIDDENM1"
reserve L, L1, L2, L3 for "SequenceORDINAL1M4"
reserve f for "FunctionFUNCT-1M1"
theorem ordinal2_sch_1:
  fixes Pp1 
  assumes
    A1: "Pp1(0ORDINAL1K5)" and
   A2: " for A be OrdinalORDINAL1M3 holds Pp1(A) implies Pp1(succORDINAL1K1 A)" and
   A3: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies Pp1(B)) implies Pp1(A)"
  shows " for A be OrdinalORDINAL1M3 holds Pp1(A)"
  proof-
    have A4: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies Pp1(B)) implies Pp1(A)"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies Pp1(B)"
      have A6: "A <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies Pp1(A)"
        using A3 A5 ordinal1_th_29 sorry
      have "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies Pp1(A)"
      proof(rule impI)
        assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A7: "A =XBOOLE-0R4 succORDINAL1K1 B"
           sorry
        have "B inTARSKIR2 A"
          using A7 ordinal1_th_6 sorry
        thus "Pp1(A)"
          using A2 A5 A7 sorry
      qed
      thus "Pp1(A)"
        using A1 A6 sorry
    qed "sorry"
    show " for A be OrdinalORDINAL1M3 holds Pp1(A)"
      using ordinal1_sch_2 A4 sorry
  qed

mtheorem ordinal2_th_1:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B iff succORDINAL1K1 A c=ORDINAL1R1 succORDINAL1K1 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not (A c=ORDINAL1R1 B &  not succORDINAL1K1 A c=ORDINAL1R1 succORDINAL1K1 B) &  not (succORDINAL1K1 A c=ORDINAL1R1 succORDINAL1K1 B &  not A c=ORDINAL1R1 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have "A c=ORDINAL1R1 B iff A inTARSKIR2 succORDINAL1K1 B"
      using ordinal1_th_22 sorry
    thus " not (A c=ORDINAL1R1 B &  not succORDINAL1K1 A c=ORDINAL1R1 succORDINAL1K1 B) &  not (succORDINAL1K1 A c=ORDINAL1R1 succORDINAL1K1 B &  not A c=ORDINAL1R1 B)"
      using ordinal1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_2:
" for A be OrdinalORDINAL1M3 holds unionTARSKIK3 (succORDINAL1K1 A) =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds unionTARSKIK3 (succORDINAL1K1 A) =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "unionTARSKIK3 (succORDINAL1K1 A) c=ORDINAL1R1 A & A c=TARSKIR1 unionTARSKIK3 (succORDINAL1K1 A)"
    proof(rule conjMI)
      show "unionTARSKIK3 (succORDINAL1K1 A) c=ORDINAL1R1 A"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 (succORDINAL1K1 A) implies x inHIDDENR3 A"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 unionTARSKIK3 (succORDINAL1K1 A)"
          then obtain X where
            [ty]:"X be setHIDDENM2" and 
            A1: "x inHIDDENR3 X"and A2: "X inTARSKIR2 succORDINAL1K1 A"
            using tarski_def_4 sorry
          have 
            [ty]:"X be OrdinalORDINAL1M3"
            using A2 sorry
          have "X c=ORDINAL1R1 A"
            using A2 ordinal1_th_22 sorry
          thus "x inHIDDENR3 A"
            using A1 sorry
        qed "sorry"
        thus "unionTARSKIK3 (succORDINAL1K1 A) c=ORDINAL1R1 A"
          using tarski_def_3 sorry
      qed
      show "A c=TARSKIR1 unionTARSKIK3 (succORDINAL1K1 A)"
        using ordinal1_th_6 zfmisc_1_th_74 sorry
    qed
    thus "unionTARSKIK3 (succORDINAL1K1 A) =XBOOLE-0R4 A"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_3:
" for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A c=TARSKIR1 boolSETFAM-1K9 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A c=TARSKIR1 boolSETFAM-1K9 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 A implies x inHIDDENR3 boolSETFAM-1K9 A"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A1: "x inHIDDENR3 succORDINAL1K1 A"
      then obtain B where 
        [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
         sorry
      have "x inHIDDENR3 A or x =HIDDENR1 A"
        using A1 ordinal1_th_8 sorry
      then have "B c=ORDINAL1R1 A"
        using ordinal1_def_2 sorry
      thus "x inHIDDENR3 boolSETFAM-1K9 A"
         sorry
    qed "sorry"
    thus "succORDINAL1K1 A c=TARSKIR1 boolSETFAM-1K9 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_4:
"0ORDINAL1K5 be limit-ordinalORDINAL1V4"
  using zfmisc_1_th_2 sorry

mtheorem ordinal2_th_5:
" for A be OrdinalORDINAL1M3 holds unionTARSKIK3 A c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds unionTARSKIK3 A c=ORDINAL1R1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 A implies x inHIDDENR3 A"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 unionTARSKIK3 A"
      then obtain Y where
        [ty]:"Y be setHIDDENM2" and 
        A1: "x inHIDDENR3 Y"and A2: "Y inTARSKIR2 A"
        using tarski_def_4 sorry
      have "Y c=TARSKIR1 A"
        using A2 ordinal1_def_2 sorry
      thus "x inHIDDENR3 A"
        using A1 sorry
    qed "sorry"
    thus "unionTARSKIK3 A c=ORDINAL1R1 A"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef ordinal2_def_1 ("lastORDINAL2K1  _ " [228]228 ) where
  mlet "L be SequenceORDINAL1M4"
"func lastORDINAL2K1 L \<rightarrow> setHIDDENM2 equals
  L .FUNCT-1K1 unionTARSKIK3 (domRELAT-1K1 L)"
proof-
  (*coherence*)
    show "L .FUNCT-1K1 unionTARSKIK3 (domRELAT-1K1 L) be setHIDDENM2"
       sorry
qed "sorry"

mtheorem ordinal2_th_6:
" for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A implies lastORDINAL2K1 L =XBOOLE-0R4 L .FUNCT-1K1 A"
  using ordinal2_th_2 sorry

mtheorem ordinal2_th_7:
" for X be setHIDDENM2 holds OnORDINAL1K2 X c=TARSKIR1 X"
  using ordinal1_def_9 sorry

mtheorem ordinal2_th_8:
" for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 A =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 A =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 A & x be OrdinalORDINAL1M3"
       sorry
    thus "OnORDINAL1K2 A =XBOOLE-0R4 A"
      using ordinal1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_9:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies OnORDINAL1K2 X c=TARSKIR1 OnORDINAL1K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies OnORDINAL1K2 X c=TARSKIR1 OnORDINAL1K2 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x inHIDDENR3 OnORDINAL1K2 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 OnORDINAL1K2 X"
      then have "x inHIDDENR3 X & x be OrdinalORDINAL1M3"
        using ordinal1_def_9 sorry
      thus "x inHIDDENR3 OnORDINAL1K2 Y"
        using A1 ordinal1_def_9 sorry
    qed "sorry"
    thus "OnORDINAL1K2 X c=TARSKIR1 OnORDINAL1K2 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_10:
" for X be setHIDDENM2 holds LimORDINAL1K3 X c=TARSKIR1 X"
  using ordinal1_def_10 sorry

mtheorem ordinal2_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies LimORDINAL1K3 X c=TARSKIR1 LimORDINAL1K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies LimORDINAL1K3 X c=TARSKIR1 LimORDINAL1K3 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 LimORDINAL1K3 X implies x inHIDDENR3 LimORDINAL1K3 Y"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 LimORDINAL1K3 X"
      then have "x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
        using ordinal1_def_10 sorry
      thus "x inHIDDENR3 LimORDINAL1K3 Y"
        using A1 ordinal1_def_10 sorry
    qed "sorry"
    thus "LimORDINAL1K3 X c=TARSKIR1 LimORDINAL1K3 Y"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_12:
" for X be setHIDDENM2 holds LimORDINAL1K3 X c=TARSKIR1 OnORDINAL1K2 X"
proof-
  have " for X be setHIDDENM2 holds LimORDINAL1K3 X c=TARSKIR1 OnORDINAL1K2 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 LimORDINAL1K3 X implies x inHIDDENR3 OnORDINAL1K2 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 LimORDINAL1K3 X"
      then have "x inHIDDENR3 X & ( ex A be OrdinalORDINAL1M3 st x =HIDDENR1 A & A be limit-ordinalORDINAL1V4)"
        using ordinal1_def_10 sorry
      thus "x inHIDDENR3 OnORDINAL1K2 X"
        using ordinal1_def_9 sorry
    qed "sorry"
    thus "LimORDINAL1K3 X c=TARSKIR1 OnORDINAL1K2 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_13:
" for X be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be OrdinalORDINAL1M3) implies meetSETFAM-1K1 X be OrdinalORDINAL1M3"
proof-
  have " for X be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be OrdinalORDINAL1M3) implies meetSETFAM-1K1 X be OrdinalORDINAL1M3"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be OrdinalORDINAL1M3"
    have "X <>HIDDENR2 0ORDINAL1K5 implies meetSETFAM-1K1 X be OrdinalORDINAL1M3"
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
      let ?x = "the ElementSUBSET-1M1-of X"
      assume A2: "X <>HIDDENR2 0ORDINAL1K5"
      then have "?x be OrdinalORDINAL1M3"
        using A1 sorry
      then have A3: " ex A be OrdinalORDINAL1M3 st ?P(A)"
        using A2 sorry
      obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A4: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
        using ordinal1_sch_1 A3 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 A iff ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)"
      proof-
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y) implies x inHIDDENR3 A)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y)"
          proof(rule impI,rule ballI,rule impI)
            assume A5: "x inHIDDENR3 A"
            fix Y assume [ty]: "Y be setHIDDENM2"
            assume A6: "Y inTARSKIR2 X"
            then obtain B where 
              [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = Y"
              using A1 sorry
            have "A c=ORDINAL1R1 B"
              using A4 A6 sorry
            thus "x inHIDDENR3 Y"
              using A5 sorry
          qed "sorry"
          assume " for Y be setHIDDENM2 holds Y inTARSKIR2 X implies x inHIDDENR3 Y"
          thus "x inHIDDENR3 A"
            using A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "meetSETFAM-1K1 X be OrdinalORDINAL1M3"
        using A2 setfam_1_def_1 sorry
    qed
    thus "meetSETFAM-1K1 X be OrdinalORDINAL1M3"
      using setfam_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_cl_1:
"cluster limit-ordinalORDINAL1V4 for OrdinalORDINAL1M3"
proof
(*existence*)
  show " ex it be OrdinalORDINAL1M3 st it be limit-ordinalORDINAL1V4"
  proof-
    have " ex tVar1 be OrdinalORDINAL1M3 st tVar1 be limit-ordinalORDINAL1V4"
    proof-
      show " ex tVar1 be OrdinalORDINAL1M3 st tVar1 be limit-ordinalORDINAL1V4"
      proof(rule bexI[of _ "omegaORDINAL1K4"])
        show "omegaORDINAL1K4 be limit-ordinalORDINAL1V4"
          using ordinal1_def_11 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef ordinal2_def_2 ("infORDINAL2K2  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func infORDINAL2K2 X \<rightarrow> OrdinalORDINAL1M3 equals
  meetSETFAM-1K1 (OnORDINAL1K2 X)"
proof-
  (*coherence*)
    show "meetSETFAM-1K1 (OnORDINAL1K2 X) be OrdinalORDINAL1M3"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x be OrdinalORDINAL1M3"
        using ordinal1_def_9 sorry
      thus "meetSETFAM-1K1 (OnORDINAL1K2 X) be OrdinalORDINAL1M3"
        using ordinal2_th_13 sorry
    qed
qed "sorry"

mdef ordinal2_def_3 ("supORDINAL2K3  _ " [300]300 ) where
  mlet "X be setHIDDENM2"
"func supORDINAL2K3 X \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. OnORDINAL1K2 X c=TARSKIR1 it & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies it c=ORDINAL1R1 A)"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st OnORDINAL1K2 X c=TARSKIR1 it & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies it c=ORDINAL1R1 A)"
    proof-
      have " ex F be OrdinalORDINAL1M3 st OnORDINAL1K2 X c=TARSKIR1 F & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies F c=ORDINAL1R1 A)"
      proof-
        let ?P = "\<lambda>Lamb1. OnORDINAL1K2 X c=TARSKIR1 Lamb1"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x be OrdinalORDINAL1M3"
          using ordinal1_def_9 sorry
        then obtain A where 
          [ty]:"A be epsilon-transitiveORDINAL1V1\<bar>epsilon-connectedORDINAL1V2\<bar>setHIDDENM2" and ADef:"A = unionTARSKIK3 (OnORDINAL1K2 X)"
          using ordinal1_th_23 sorry
        have "OnORDINAL1K2 X c=TARSKIR1 succORDINAL1K1 A"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x inHIDDENR3 succORDINAL1K1 A"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A1: "x inHIDDENR3 OnORDINAL1K2 X"
            then obtain B where 
              [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
              using ordinal1_def_9 sorry
            have "B c=ORDINAL1R1 A"
              using A1 zfmisc_1_th_74 sorry
            thus "x inHIDDENR3 succORDINAL1K1 A"
              using ordinal1_th_22 sorry
          qed "sorry"
          thus "OnORDINAL1K2 X c=TARSKIR1 succORDINAL1K1 A"
            using tarski_def_3 sorry
        qed
        then have A2: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        show " ex F be OrdinalORDINAL1M3 st OnORDINAL1K2 X c=TARSKIR1 F & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies F c=ORDINAL1R1 A)"
          using ordinal1_sch_1 A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds (OnORDINAL1K2 X c=TARSKIR1 it1 & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies it1 c=ORDINAL1R1 A)) & (OnORDINAL1K2 X c=TARSKIR1 it2 & ( for A be OrdinalORDINAL1M3 holds OnORDINAL1K2 X c=TARSKIR1 A implies it2 c=ORDINAL1R1 A)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem ordinal2_th_14:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies infORDINAL2K2 X c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies infORDINAL2K2 X c=ORDINAL1R1 A"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "A inTARSKIR2 X"
    then have "A inTARSKIR2 OnORDINAL1K2 X"
      using ordinal1_def_9 sorry
    thus "infORDINAL2K2 X c=ORDINAL1R1 A"
      using setfam_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_15:
" for D be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds OnORDINAL1K2 X <>HIDDENR2 0ORDINAL1K5 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies D c=ORDINAL1R1 A) implies D c=ORDINAL1R1 infORDINAL2K2 X"
proof-
  have " for D be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds OnORDINAL1K2 X <>HIDDENR2 0ORDINAL1K5 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies D c=ORDINAL1R1 A) implies D c=ORDINAL1R1 infORDINAL2K2 X"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "OnORDINAL1K2 X <>HIDDENR2 0ORDINAL1K5"
      and A2: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies D c=ORDINAL1R1 A"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 D implies x inHIDDENR3 infORDINAL2K2 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 D"
      have " for Y be setHIDDENM2 holds Y inTARSKIR2 OnORDINAL1K2 X implies x inHIDDENR3 Y"
      proof(rule ballI,rule impI)
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume A4: "Y inTARSKIR2 OnORDINAL1K2 X"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = Y"
          using ordinal1_def_9 sorry
        have "A inTARSKIR2 X"
          using A4 ordinal1_def_9 sorry
        then have "D c=ORDINAL1R1 A"
          using A2 sorry
        thus "x inHIDDENR3 Y"
          using A3 sorry
      qed "sorry"
      thus "x inHIDDENR3 infORDINAL2K2 X"
        using A1 setfam_1_def_1 sorry
    qed "sorry"
    thus "D c=ORDINAL1R1 infORDINAL2K2 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_16:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A inTARSKIR2 X & X c=TARSKIR1 Y implies infORDINAL2K2 Y c=ORDINAL1R1 infORDINAL2K2 X"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds A inTARSKIR2 X implies (X c=TARSKIR1 Y implies infORDINAL2K2 Y c=ORDINAL1R1 infORDINAL2K2 X)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "A inTARSKIR2 X"
    then have A1: "OnORDINAL1K2 X <>HIDDENR2 0ORDINAL1K5"
      using ordinal1_def_9 sorry
    assume "X c=TARSKIR1 Y"
    then have "OnORDINAL1K2 X c=TARSKIR1 OnORDINAL1K2 Y"
      using ordinal2_th_9 sorry
    thus "infORDINAL2K2 Y c=ORDINAL1R1 infORDINAL2K2 X"
      using A1 setfam_1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_17:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies infORDINAL2K2 X inTARSKIR2 X"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies infORDINAL2K2 X inTARSKIR2 X"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 X"
    assume "A inTARSKIR2 X"
    then have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
       sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A2: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
      using ordinal1_sch_1 A1 sorry
    have A3: "A inTARSKIR2 OnORDINAL1K2 X"
      using A2 ordinal1_def_9 sorry
    have A4: " for x be objectHIDDENM1 holds (x inHIDDENR3 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 OnORDINAL1K2 X implies x inHIDDENR3 Y)) & (( for Y be setHIDDENM2 holds Y inTARSKIR2 OnORDINAL1K2 X implies x inHIDDENR3 Y) implies x inHIDDENR3 A)"
    proof(rule ballI,rule conjMI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      show "x inHIDDENR3 A implies ( for Y be setHIDDENM2 holds Y inTARSKIR2 OnORDINAL1K2 X implies x inHIDDENR3 Y)"
      proof(rule impI,rule ballI,rule impI)
        assume A5: "x inHIDDENR3 A"
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume A6: "Y inTARSKIR2 OnORDINAL1K2 X"
        then obtain B where 
          [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = Y"
          using ordinal1_def_9 sorry
        have "Y inTARSKIR2 X"
          using A6 ordinal1_def_9 sorry
        then have "A c=ORDINAL1R1 B"
          using A2 sorry
        thus "x inHIDDENR3 Y"
          using A5 sorry
      qed "sorry"
      assume " for Y be setHIDDENM2 holds Y inTARSKIR2 OnORDINAL1K2 X implies x inHIDDENR3 Y"
      thus "x inHIDDENR3 A"
        using A3 sorry
    qed "sorry"
    have "OnORDINAL1K2 X <>HIDDENR2 0ORDINAL1K5"
      using A2 ordinal1_def_9 sorry
    thus "infORDINAL2K2 X inTARSKIR2 X"
      using A2 A4 setfam_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_18:
" for A be OrdinalORDINAL1M3 holds supORDINAL2K3 A =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds supORDINAL2K3 A =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "OnORDINAL1K2 A =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds OnORDINAL1K2 A c=TARSKIR1 B implies A c=ORDINAL1R1 B)"
      using ordinal2_th_8 sorry
    thus "supORDINAL2K3 A =XBOOLE-0R4 A"
      using ordinal2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_19:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies A inTARSKIR2 supORDINAL2K3 X"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 X implies A inTARSKIR2 supORDINAL2K3 X"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume "A inTARSKIR2 X"
    then have A1: "A inTARSKIR2 OnORDINAL1K2 X"
      using ordinal1_def_9 sorry
    have "OnORDINAL1K2 X c=TARSKIR1 supORDINAL2K3 X"
      using ordinal2_def_3 sorry
    thus "A inTARSKIR2 supORDINAL2K3 X"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_20:
" for D be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies A inTARSKIR2 D) implies supORDINAL2K3 X c=ORDINAL1R1 D"
proof-
  have " for D be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies A inTARSKIR2 D) implies supORDINAL2K3 X c=ORDINAL1R1 D"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 X implies A inTARSKIR2 D"
    have "OnORDINAL1K2 X c=TARSKIR1 D"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 X implies x inHIDDENR3 D"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A2: "x inHIDDENR3 OnORDINAL1K2 X"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
          using ordinal1_def_9 sorry
        have "A inTARSKIR2 X"
          using A2 ordinal1_def_9 sorry
        thus "x inHIDDENR3 D"
          using A1 sorry
      qed "sorry"
      thus "OnORDINAL1K2 X c=TARSKIR1 D"
        using tarski_def_3 sorry
    qed
    thus "supORDINAL2K3 X c=ORDINAL1R1 D"
      using ordinal2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_21:
" for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 supORDINAL2K3 X implies ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 X & A c=ORDINAL1R1 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for X be setHIDDENM2 holds A inTARSKIR2 supORDINAL2K3 X & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies  not A c=ORDINAL1R1 B) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix X assume [ty]: "X be setHIDDENM2"
    assume A1: "A inTARSKIR2 supORDINAL2K3 X"
      and A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies  not A c=ORDINAL1R1 B"
    have " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 X implies B inTARSKIR2 A"
      using A2 ordinal1_th_16 sorry
    then have "supORDINAL2K3 X c=ORDINAL1R1 A"
      using ordinal2_th_20 sorry
    thus " False "
      using A1 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_22:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies supORDINAL2K3 X c=ORDINAL1R1 supORDINAL2K3 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies supORDINAL2K3 X c=ORDINAL1R1 supORDINAL2K3 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "X c=TARSKIR1 Y"
    then have A1: "OnORDINAL1K2 X c=TARSKIR1 OnORDINAL1K2 Y"
      using ordinal2_th_9 sorry
    have "OnORDINAL1K2 Y c=TARSKIR1 supORDINAL2K3 Y"
      using ordinal2_def_3 sorry
    then have "OnORDINAL1K2 X c=TARSKIR1 supORDINAL2K3 Y"
      using A1 sorry
    thus "supORDINAL2K3 X c=ORDINAL1R1 supORDINAL2K3 Y"
      using ordinal2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_23:
" for A be OrdinalORDINAL1M3 holds supORDINAL2K3 {TARSKIK1 A} =XBOOLE-0R4 succORDINAL1K1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds supORDINAL2K3 {TARSKIK1 A} =XBOOLE-0R4 succORDINAL1K1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have A1: "OnORDINAL1K2 {TARSKIK1 A} c=TARSKIR1 succORDINAL1K1 A"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 OnORDINAL1K2 {TARSKIK1 A} implies x inHIDDENR3 succORDINAL1K1 A"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 OnORDINAL1K2 {TARSKIK1 A}"
        then have "x inHIDDENR3 {TARSKIK1 A}"
          using ordinal1_def_9 sorry
        then have "x =HIDDENR1 A"
          using tarski_def_1 sorry
        thus "x inHIDDENR3 succORDINAL1K1 A"
          using ordinal1_th_6 sorry
      qed "sorry"
      thus "OnORDINAL1K2 {TARSKIK1 A} c=TARSKIR1 succORDINAL1K1 A"
        using tarski_def_3 sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds OnORDINAL1K2 {TARSKIK1 A} c=TARSKIR1 B implies succORDINAL1K1 A c=ORDINAL1R1 B"
    proof(rule ballI,rule impI)
      have "A inTARSKIR2 {TARSKIK1 A}"
        using tarski_def_1 sorry
      then have A2: "A inTARSKIR2 OnORDINAL1K2 {TARSKIK1 A}"
        using ordinal1_def_9 sorry
      fix B assume [ty]: "B be OrdinalORDINAL1M3"
      assume "OnORDINAL1K2 {TARSKIK1 A} c=TARSKIR1 B"
      thus "succORDINAL1K1 A c=ORDINAL1R1 B"
        using A2 ordinal1_th_21 sorry
    qed "sorry"
    thus "supORDINAL2K3 {TARSKIK1 A} =XBOOLE-0R4 succORDINAL1K1 A"
      using A1 ordinal2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_24:
" for X be setHIDDENM2 holds infORDINAL2K2 X c=ORDINAL1R1 supORDINAL2K3 X"
proof-
  have " for X be setHIDDENM2 holds infORDINAL2K2 X c=ORDINAL1R1 supORDINAL2K3 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 infORDINAL2K2 X implies x inHIDDENR3 supORDINAL2K3 X"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      let ?y = "the ElementSUBSET-1M1-of OnORDINAL1K2 X"
      assume A1: "x inHIDDENR3 infORDINAL2K2 X"
      then obtain y where 
        [ty]:"y be OrdinalORDINAL1M3" and yDef:"y = ?y"
        using ordinal1_def_9 setfam_1_th_1 sorry
      have "OnORDINAL1K2 X c=TARSKIR1 supORDINAL2K3 X"
        using ordinal2_def_3 sorry
      then have "y inTARSKIR2 supORDINAL2K3 X"
        using A1 setfam_1_th_1 sorry
      then have A2: "y c=ORDINAL1R1 supORDINAL2K3 X"
        using ordinal1_def_2 sorry
      have "x inHIDDENR3 y"
        using A1 setfam_1_th_1 setfam_1_def_1 sorry
      thus "x inHIDDENR3 supORDINAL2K3 X"
        using A2 sorry
    qed "sorry"
    thus "infORDINAL2K2 X c=ORDINAL1R1 supORDINAL2K3 X"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem ordinal2_sch_2:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2"
  shows " ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies L .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A))"
  proof-
    have " ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies L .FUNCT-1K1 A =HIDDENR1 Ff1(A))"
    proof-
      let ?G = "\<lambda>Lamb1. Ff1(supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 Lamb1}))"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 Af0 & ( for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies f .FUNCT-1K1 x =XBOOLE-0R4 ?G(x))"
        using funct_1_sch_3 sorry
      have 
        [ty]:"f be SequenceORDINAL1M4"
        using A1 ordinal1_def_7 sorry
      obtain L where 
        [ty]:"L be SequenceORDINAL1M4" and LDef:"L = f"
         sorry
      show " ex L be SequenceORDINAL1M4 st domRELAT-1K1 L =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies L .FUNCT-1K1 A =HIDDENR1 Ff1(A))"
      proof(rule bexI[of _ "L"],rule conjMI,rule ballI,rule impI)
        show "domRELAT-1K1 L =XBOOLE-0R4 Af0"
          using A1 sorry
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "A inTARSKIR2 Af0"
        then have "L .FUNCT-1K1 A =HIDDENR1 Ff1(supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 A}))"
          using A1 sorry
        also have "... = Ff1(supORDINAL2K3 A)"
          using zfmisc_1_th_25 sorry
        also have "... = Ff1(A)"
          using ordinal2_th_18 sorry
        finally show "L .FUNCT-1K1 A =HIDDENR1 Ff1(A)"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

mdef ordinal2_def_4 ("Ordinal-yieldingORDINAL2V1" 70 ) where
"attr Ordinal-yieldingORDINAL2V1 for FunctionFUNCT-1M1 means
  (\<lambda>f.  ex A be OrdinalORDINAL1M3 st rngFUNCT-1K2 f c=TARSKIR1 A)"..

mtheorem ordinal2_cl_2:
"cluster Ordinal-yieldingORDINAL2V1 for SequenceORDINAL1M4"
proof
(*existence*)
  show " ex it be SequenceORDINAL1M4 st it be Ordinal-yieldingORDINAL2V1"
  proof-
    have " ex tVar3 be SequenceORDINAL1M4 st tVar3 be Ordinal-yieldingORDINAL2V1"
    proof-
      let ?A = "the OrdinalORDINAL1M3"
      let ?L = "the SequenceORDINAL1M5-of ?A"
      show " ex tVar3 be SequenceORDINAL1M4 st tVar3 be Ordinal-yieldingORDINAL2V1"
      proof(rule bexI[of _ "?L"])
        have "rngFUNCT-1K2 (the SequenceORDINAL1M5-of the OrdinalORDINAL1M3) c=TARSKIR1 the OrdinalORDINAL1M3"
        proof-
          show "rngFUNCT-1K2 (the SequenceORDINAL1M5-of the OrdinalORDINAL1M3) c=TARSKIR1 the OrdinalORDINAL1M3"
            using relat_1_def_19 sorry
        qed
        thus "the SequenceORDINAL1M5-of the OrdinalORDINAL1M3 be Ordinal-yieldingORDINAL2V1"
          using bexI[of _ "?A"] ordinal2_def_4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax ORDINAL2M1 :: "Ty" ("Ordinal-SequenceORDINAL2M1" 70)
translations "Ordinal-SequenceORDINAL2M1" \<rightharpoonup> "Ordinal-yieldingORDINAL2V1\<bar>SequenceORDINAL1M4"

mtheorem ordinal2_cl_3:
  mlet "A be OrdinalORDINAL1M3"
"cluster note-that Ordinal-yieldingORDINAL2V1 for SequenceORDINAL1M5-of A"
proof
(*coherence*)
  show " for it be SequenceORDINAL1M5-of A holds it be Ordinal-yieldingORDINAL2V1"
    using relat_1_def_19 sorry
qed "sorry"

mtheorem ordinal2_cl_4:
  mlet "L be Ordinal-SequenceORDINAL2M1", "A be OrdinalORDINAL1M3"
"cluster L  |RELAT-1K8 A as-term-is Ordinal-yieldingORDINAL2V1"
proof
(*coherence*)
  show "L  |RELAT-1K8 A be Ordinal-yieldingORDINAL2V1"
  proof-
    obtain B where
      [ty]:"B be OrdinalORDINAL1M3" and 
      A1: "rngFUNCT-1K2 L c=TARSKIR1 B"
      using ordinal2_def_4 sorry
    have "L  |RELAT-1K8 A be Ordinal-yieldingORDINAL2V1"
    proof-
      have Cut475: "rngFUNCT-1K2 (L  |RELAT-1K8 A) c=TARSKIR1 rngFUNCT-1K2 L"
        using relat_1_th_70 sorry
      have "rngFUNCT-1K2 (L  |RELAT-1K8 A) c=TARSKIR1 B"
      proof-
        show "rngFUNCT-1K2 (L  |RELAT-1K8 A) c=TARSKIR1 B"
          using A1 Cut475 sorry
      qed
      thus "L  |RELAT-1K8 A be Ordinal-yieldingORDINAL2V1"
        using bexI[of _ "B"] ordinal2_def_4 sorry
    qed
    thus "L  |RELAT-1K8 A be Ordinal-yieldingORDINAL2V1"
       sorry
  qed
qed "sorry"

reserve fi, psi for "Ordinal-SequenceORDINAL2M1"
mtheorem ordinal2_th_25:
" for A be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds A inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 A be OrdinalORDINAL1M3"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds A inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 A be OrdinalORDINAL1M3"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    assume "A inTARSKIR2 domRELAT-1K1 fi"
    then have A1: "fi .FUNCT-1K1 A inTARSKIR2 rngFUNCT-1K2 fi"
      using funct_1_def_3 sorry
    have " ex B be OrdinalORDINAL1M3 st rngFUNCT-1K2 fi c=TARSKIR1 B"
      using ordinal2_def_4 sorry
    thus "fi .FUNCT-1K1 A be OrdinalORDINAL1M3"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_cl_5:
  mlet "f be Ordinal-SequenceORDINAL2M1", "a be objectHIDDENM1"
"cluster f .FUNCT-1K1 a as-term-is ordinalORDINAL1V3"
proof
(*coherence*)
  show "f .FUNCT-1K1 a be ordinalORDINAL1V3"
  proof-
    have "a inHIDDENR3 domRELAT-1K1 f or  not a inHIDDENR3 domRELAT-1K1 f"
       sorry
    thus "f .FUNCT-1K1 a be ordinalORDINAL1V3"
      using ordinal2_th_25 funct_1_def_2 sorry
  qed
qed "sorry"

theorem ordinal2_sch_3:
  fixes Af0 Ff1 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be OrdinalORDINAL1M3"
  shows " ex fi be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 fi =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies fi .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A))"
  proof-
    have " ex fi be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 fi =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies fi .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A))"
    proof-
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A1: "domRELAT-1K1 L =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies L .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A))"
        using ordinal2_sch_2 sorry
      have "L be Ordinal-yieldingORDINAL2V1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 L implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 L)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A2: "x inHIDDENR3 rngFUNCT-1K2 L"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A3: "y inHIDDENR3 domRELAT-1K1 L"and A4: "x =HIDDENR1 L .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"y be OrdinalORDINAL1M3"
            using A3 sorry
          have "L .FUNCT-1K1 y =XBOOLE-0R4 Ff1(y)"
            using A1 A3 sorry
          then have A5: "x inHIDDENR3 OnORDINAL1K2 (rngFUNCT-1K2 L)"
            using A2 A4 ordinal1_def_9 sorry
          have "OnORDINAL1K2 (rngFUNCT-1K2 L) c=TARSKIR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
            using ordinal2_def_3 sorry
          thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 L)"
            using A5 sorry
        qed "sorry"
        then have "rngFUNCT-1K2 L c=TARSKIR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
          using tarski_def_3 sorry
        thus "L be Ordinal-yieldingORDINAL2V1"
          using bexI[of _ "supORDINAL2K3 (rngFUNCT-1K2 L)"] ordinal2_def_4 sorry
      qed
      then have 
        [ty]:"L be Ordinal-SequenceORDINAL2M1"
         sorry
      obtain fi where 
        [ty]:"fi be Ordinal-SequenceORDINAL2M1" and fiDef:"fi = L"
         sorry
      show " ex fi be Ordinal-SequenceORDINAL2M1 st domRELAT-1K1 fi =XBOOLE-0R4 Af0 & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies fi .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A))"
      proof(rule bexI[of _ "fi"],rule conjMI,rule ballI,rule impI)
        show "domRELAT-1K1 fi =XBOOLE-0R4 Af0"
          using A1 sorry
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "A inTARSKIR2 Af0"
        thus "fi .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
          using A1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_4:
  fixes Af0 Bf0 Cf2 Df2 L1f0 L2f0 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be objectHIDDENM1" and
  [ty]: "L1f0 be SequenceORDINAL1M4" and
  [ty]: "L2f0 be SequenceORDINAL1M4" and
   A1: "domRELAT-1K1 L1f0 =XBOOLE-0R4 Af0" and
   A2: "0ORDINAL1K5 inTARSKIR2 Af0 implies L1f0 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0" and
   A3: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies L1f0 .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L1f0 .FUNCT-1K1 A)" and
   A4: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L1f0 .FUNCT-1K1 A =HIDDENR1 Df2(A,L1f0  |RELAT-1K8 A)" and
   A5: "domRELAT-1K1 L2f0 =XBOOLE-0R4 Af0" and
   A6: "0ORDINAL1K5 inTARSKIR2 Af0 implies L2f0 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0" and
   A7: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies L2f0 .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L2f0 .FUNCT-1K1 A)" and
   A8: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L2f0 .FUNCT-1K1 A =HIDDENR1 Df2(A,L2f0  |RELAT-1K8 A)"
  shows "L1f0 =FUNCT-1R1 L2f0"
  proof-
    have "L1f0 <>HIDDENR2 L2f0 implies  False "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. L1f0 .FUNCT-1K1 Lamb1 <>HIDDENR2 L2f0 .FUNCT-1K1 Lamb1"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A9: " for Y be objectHIDDENM1 holds Y inHIDDENR3 X iff Y inHIDDENR3 Af0 & ?P(Y)"
        using xboole_0_sch_1 sorry
      have " for b be objectHIDDENM1 holds b inHIDDENR3 X implies b inHIDDENR3 Af0"
        using A9 sorry
      then have A10: "X c=TARSKIR1 Af0"
         sorry
      assume "L1f0 <>HIDDENR2 L2f0"
      then have " ex a be objectHIDDENM1 st a inHIDDENR3 Af0 & L1f0 .FUNCT-1K1 a <>HIDDENR2 L2f0 .FUNCT-1K1 a"
        using A1 A5 funct_1_th_2 sorry
      then have "X <>HIDDENR2 0ORDINAL1K5"
        using A9 sorry
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A11: "B inTARSKIR2 X"and A12: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 X implies B c=ORDINAL1R1 C"
        using A10 ordinal1_th_20 sorry
      have A13: "B inTARSKIR2 Af0"
        using A9 A11 sorry
      then have A14: "B c=ORDINAL1R1 Af0"
        using ordinal1_def_2 sorry
      then have A15: "domRELAT-1K1 (L1f0  |RELAT-1K8 B) =XBOOLE-0R4 B & domRELAT-1K1 (L2f0  |RELAT-1K8 B) =XBOOLE-0R4 B"
        using A1 A5 relat_1_th_62 sorry
      have A16: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies L1f0 .FUNCT-1K1 C =XBOOLE-0R4 L2f0 .FUNCT-1K1 C"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A17: "C inTARSKIR2 B"
        then have " not C inTARSKIR2 X"
          using A12 ordinal1_th_5 sorry
        thus "L1f0 .FUNCT-1K1 C =XBOOLE-0R4 L2f0 .FUNCT-1K1 C"
          using A9 A14 A17 sorry
      qed "sorry"
      have A18: " for a be objectHIDDENM1 holds a inHIDDENR3 B implies (L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 (L2f0  |RELAT-1K8 B).FUNCT-1K1 a"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume A19: "a inHIDDENR3 B"
        have "(L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 L1f0 .FUNCT-1K1 a & (L2f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 L2f0 .FUNCT-1K1 a"
          using A15 A19 funct_1_th_47 sorry
        thus "(L1f0  |RELAT-1K8 B).FUNCT-1K1 a =XBOOLE-0R4 (L2f0  |RELAT-1K8 B).FUNCT-1K1 a"
          using A16 A19 sorry
      qed "sorry"
      have A20: "( ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C) implies L1f0 .FUNCT-1K1 B =XBOOLE-0R4 L2f0 .FUNCT-1K1 B"
      proof(rule impI)
        assume Given: " ex C be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 C"
        then obtain C where
          [ty]:"C be OrdinalORDINAL1M3" and 
          A21: "B =XBOOLE-0R4 succORDINAL1K1 C"
           sorry
        have A22: "L1f0 .FUNCT-1K1 C =XBOOLE-0R4 (L1f0  |RELAT-1K8 B).FUNCT-1K1 C & L2f0 .FUNCT-1K1 C =XBOOLE-0R4 (L2f0  |RELAT-1K8 B).FUNCT-1K1 C"
          using A21 funct_1_th_49 ordinal1_th_6 sorry
        have "L1f0 .FUNCT-1K1 B =HIDDENR1 Cf2(C,L1f0 .FUNCT-1K1 C) & L2f0 .FUNCT-1K1 B =HIDDENR1 Cf2(C,L2f0 .FUNCT-1K1 C)"
          using A3 A7 A13 A21 sorry
        thus "L1f0 .FUNCT-1K1 B =XBOOLE-0R4 L2f0 .FUNCT-1K1 B"
          using A18 A21 A22 ordinal1_th_6 sorry
      qed
      have "B <>HIDDENR2 0ORDINAL1K5 & ( for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C) implies L1f0 .FUNCT-1K1 B =XBOOLE-0R4 L2f0 .FUNCT-1K1 B"
      proof(rule impMI ,rule impI)
        assume A23: "B <>HIDDENR2 0ORDINAL1K5"
          and A24: " for C be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 C"
        have "B be limit-ordinalORDINAL1V4"
          using A24 ordinal1_th_29 sorry
        then have "L1f0 .FUNCT-1K1 B =HIDDENR1 Df2(B,L1f0  |RELAT-1K8 B) & L2f0 .FUNCT-1K1 B =HIDDENR1 Df2(B,L2f0  |RELAT-1K8 B)"
          using A4 A8 A13 A23 sorry
        thus "L1f0 .FUNCT-1K1 B =XBOOLE-0R4 L2f0 .FUNCT-1K1 B"
          using A15 A18 funct_1_th_2 sorry
      qed
      thus " False "
        using A2 A6 A9 A11 A20 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_5:
  fixes Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be objectHIDDENM1" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be objectHIDDENM1"
  shows " ex L be SequenceORDINAL1M4 st ((domRELAT-1K1 L =XBOOLE-0R4 Af0 & (0ORDINAL1K5 inTARSKIR2 Af0 implies L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A))) & ( for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A =HIDDENR1 Df2(A,L  |RELAT-1K8 A))"
  proof-
    have " not ( for L be SequenceORDINAL1M4 holds  not (((domRELAT-1K1 L =XBOOLE-0R4 Af0 &  not (0ORDINAL1K5 inTARSKIR2 Af0 &  not L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 A inTARSKIR2 Af0 &  not L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A)))) & ( for A be OrdinalORDINAL1M3 holds  not (((A inTARSKIR2 Af0 &  not A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 A =HIDDENR1 Df2(A,L  |RELAT-1K8 A)))))"
    proof-
      let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. ((domRELAT-1K1 Lamb2 =XBOOLE-0R4 Lamb1 & (0ORDINAL1K5 inTARSKIR2 Lamb1 implies Lamb2 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A1 be OrdinalORDINAL1M3 holds succORDINAL1K1 A1 inTARSKIR2 Lamb1 implies Lamb2 .FUNCT-1K1 succORDINAL1K1 A1 =HIDDENR1 Cf2(A1,Lamb2 .FUNCT-1K1 A1))) & ( for A1 be OrdinalORDINAL1M3 holds (A1 inTARSKIR2 Lamb1 & A1 <>HIDDENR2 0ORDINAL1K5) & A1 be limit-ordinalORDINAL1V4 implies Lamb2 .FUNCT-1K1 A1 =HIDDENR1 Df2(A1,Lamb2  |RELAT-1K8 A1))"
      let ?R = "\<lambda>Lamb1.  ex L be SequenceORDINAL1M4 st ?P(Lamb1,L)"
      have A1: " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?R(C)) implies ?R(B)"
      proof-
        have " for B be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( ex L be SequenceORDINAL1M4 st ((domRELAT-1K1 L =XBOOLE-0R4 C & (0ORDINAL1K5 inTARSKIR2 C implies L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A1 be OrdinalORDINAL1M3 holds succORDINAL1K1 A1 inTARSKIR2 C implies L .FUNCT-1K1 succORDINAL1K1 A1 =HIDDENR1 Cf2(A1,L .FUNCT-1K1 A1))) & ( for A1 be OrdinalORDINAL1M3 holds (A1 inTARSKIR2 C & A1 <>HIDDENR2 0ORDINAL1K5) & A1 be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A1 =HIDDENR1 Df2(A1,L  |RELAT-1K8 A1)))) implies ( ex tVar15 be SequenceORDINAL1M4 st domRELAT-1K1 tVar15 =XBOOLE-0R4 B & ((0ORDINAL1K5 inTARSKIR2 B implies tVar15 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0) & (( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 B implies tVar15 .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,tVar15 .FUNCT-1K1 A)) & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B & (D <>HIDDENR2 0ORDINAL1K5 & D be limit-ordinalORDINAL1V4) implies tVar15 .FUNCT-1K1 D =HIDDENR1 Df2(D,tVar15  |RELAT-1K8 D)))))"
        proof(rule ballI,rule impI)
          let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 be OrdinalORDINAL1M3 & Lamb2 be SequenceORDINAL1M4) & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 Lamb1 & L =HIDDENR1 Lamb2 implies ?P(A,L))"
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          assume A2: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( ex L be SequenceORDINAL1M4 st ?P(C,L))"
          have A3: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds ?R(a,b) & ?R(a,c) implies b =HIDDENR1 c"
          proof-
            have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds a be OrdinalORDINAL1M3 & (b be SequenceORDINAL1M4 & (( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 b implies ((domRELAT-1K1 L =XBOOLE-0R4 A & (0ORDINAL1K5 inTARSKIR2 A implies L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A1 be OrdinalORDINAL1M3 holds succORDINAL1K1 A1 inTARSKIR2 A implies L .FUNCT-1K1 succORDINAL1K1 A1 =HIDDENR1 Cf2(A1,L .FUNCT-1K1 A1))) & ( for A1 be OrdinalORDINAL1M3 holds (A1 inTARSKIR2 A & A1 <>HIDDENR2 0ORDINAL1K5) & A1 be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A1 =HIDDENR1 Df2(A1,L  |RELAT-1K8 A1))) & (a be OrdinalORDINAL1M3 & (c be SequenceORDINAL1M4 & ( for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 c implies ((domRELAT-1K1 L =XBOOLE-0R4 A & (0ORDINAL1K5 inTARSKIR2 A implies L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A1 be OrdinalORDINAL1M3 holds succORDINAL1K1 A1 inTARSKIR2 A implies L .FUNCT-1K1 succORDINAL1K1 A1 =HIDDENR1 Cf2(A1,L .FUNCT-1K1 A1))) & ( for A1 be OrdinalORDINAL1M3 holds (A1 inTARSKIR2 A & A1 <>HIDDENR2 0ORDINAL1K5) & A1 be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A1 =HIDDENR1 Df2(A1,L  |RELAT-1K8 A1))))))) implies b =HIDDENR1 c"
            proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              fix b assume [ty]: "b be objectHIDDENM1"
              fix c assume [ty]: "c be objectHIDDENM1"
              assume A4: "a be OrdinalORDINAL1M3"
                and A5: "b be SequenceORDINAL1M4"
                and A6: " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 b implies ?P(A,L)"
                and "a be OrdinalORDINAL1M3"
                and A7: "c be SequenceORDINAL1M4"
                and A8: " for A be OrdinalORDINAL1M3 holds  for L be SequenceORDINAL1M4 holds A =HIDDENR1 a & L =HIDDENR1 c implies ?P(A,L)"
              have 
                [ty]:"a be OrdinalORDINAL1M3"
                using A4 sorry
              have 
                [ty]:"c be SequenceORDINAL1M4"
                using A7 sorry
              have A9: "domRELAT-1K1 c =XBOOLE-0R4 a"
                using A8 sorry
              have A10: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 a & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies c .FUNCT-1K1 A =HIDDENR1 Df2(A,c  |RELAT-1K8 A)"
                using A8 sorry
              have A11: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 a implies c .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,c .FUNCT-1K1 A)"
                using A8 sorry
              have A12: "0ORDINAL1K5 inTARSKIR2 a implies c .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0"
                using A8 sorry
              have 
                [ty]:"b be SequenceORDINAL1M4"
                using A5 sorry
              have A13: "0ORDINAL1K5 inTARSKIR2 a implies b .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0"
                using A6 sorry
              have A14: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 a implies b .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,b .FUNCT-1K1 A)"
                using A6 sorry
              have A15: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 a & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies b .FUNCT-1K1 A =HIDDENR1 Df2(A,b  |RELAT-1K8 A)"
                using A6 sorry
              have A16: "domRELAT-1K1 b =XBOOLE-0R4 a"
                using A6 sorry
              have "b =FUNCT-1R1 c"
                using ordinal2_sch_4 A16 A13 A14 A15 A9 A12 A11 A10 sorry
              thus "b =HIDDENR1 c"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain G where
            [ty]:"G be FunctionFUNCT-1M1" and 
            A17: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds [TARSKIK4 a,b ] inHIDDENR3 G iff a inHIDDENR3 B & ?R(a,b)"
            using funct_1_sch_1 A3 sorry
          let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 Lamb1 & L =XBOOLE-0R4 G .FUNCT-1K1 Lamb1) & ((A =XBOOLE-0R4 0ORDINAL1K5 & Lamb2 =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & Lamb2 =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Lamb2 =HIDDENR1 Df2(A,L))"
          have A18: "domRELAT-1K1 G =XBOOLE-0R4 B"
          proof-
            have "( for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 G implies a inHIDDENR3 B) & B c=TARSKIR1 domRELAT-1K1 G"
            proof(rule conjMI)
              show " for a be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 G implies a inHIDDENR3 B"
              proof(rule ballI,rule impI)
                fix a assume [ty]: "a be objectHIDDENM1"
                assume "a inHIDDENR3 domRELAT-1K1 G"
                then have " ex b be objectHIDDENM1 st [TARSKIK4 a,b ] inHIDDENR3 G"
                  using xtuple_0_def_12 sorry
                thus "a inHIDDENR3 B"
                  using A17 sorry
              qed "sorry"
              have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies a inHIDDENR3 domRELAT-1K1 G"
              proof(rule ballI,rule impI)
                fix a assume [ty]: "a be objectHIDDENM1"
                assume A19: "a inHIDDENR3 B"
                then obtain a9 where 
                  [ty]:"a9 be OrdinalORDINAL1M3" and a9Def:"a9 = a"
                   sorry
                obtain L where
                  [ty]:"L be SequenceORDINAL1M4" and 
                  A20: "?P(a9,L)"
                  using A2 A19 sorry
                have " for A be OrdinalORDINAL1M3 holds  for K be SequenceORDINAL1M4 holds A =XBOOLE-0R4 a9 & K =FUNCT-1R1 L implies ?P(A,K)"
                  using A20 sorry
                then have "[TARSKIK4 a9,L ] inHIDDENR3 G"
                  using A17 A19 sorry
                thus "a inHIDDENR3 domRELAT-1K1 G"
                  using xtuple_0_def_12 sorry
              qed "sorry"
              thus "B c=TARSKIR1 domRELAT-1K1 G"
                using tarski_def_3 sorry
            qed
            thus "domRELAT-1K1 G =XBOOLE-0R4 B"
              using tarski_def_3 xboole_0_def_10 sorry
          qed
          have A21: " for a be objectHIDDENM1 holds a inHIDDENR3 B implies ( ex b be objectHIDDENM1 st ?Q(a,b))"
          proof-
            have " for a be objectHIDDENM1 holds a inHIDDENR3 B implies  not ( for b be objectHIDDENM1 holds  not ( ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(A,L))))"
            proof(rule ballI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              assume A22: "a inHIDDENR3 B"
              then obtain A where 
                [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = a"
                 sorry
              obtain c where
                [ty]:"c be objectHIDDENM1" and 
                A23: "[TARSKIK4 a,c ] inHIDDENR3 G"
                using A18 A22 xtuple_0_def_12 sorry
              obtain L where 
                [ty]:"L be SequenceORDINAL1M4" and LDef:"L = c"
                using A17 A23 sorry
              have A24: "( ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 C) implies ( ex b be objectHIDDENM1 st  ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(A,L)))"
              proof(rule impI)
                assume Given: " ex C be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 C"
                then obtain C where
                  [ty]:"C be OrdinalORDINAL1M3" and 
                  A25: "A =XBOOLE-0R4 succORDINAL1K1 C"
                   sorry
                show " ex b be objectHIDDENM1 st  ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(A,L))"
                proof-
                  have " ex tVar8 be objectHIDDENM1 st  ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be SequenceORDINAL1M4 st (tVar9 =HIDDENR1 a & tVar10 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar9 =XBOOLE-0R4 0ORDINAL1K5 & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar9 =XBOOLE-0R4 succORDINAL1K1 B & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Cf2(B,tVar10 .FUNCT-1K1 B)))) &  not (( not tVar9 <>HIDDENR2 0ORDINAL1K5 & tVar9 be limit-ordinalORDINAL1V4) & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Df2(tVar9,tVar10)))"
                  proof-
                    show " ex tVar8 be objectHIDDENM1 st  ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be SequenceORDINAL1M4 st (tVar9 =HIDDENR1 a & tVar10 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar9 =XBOOLE-0R4 0ORDINAL1K5 & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar9 =XBOOLE-0R4 succORDINAL1K1 B & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Cf2(B,tVar10 .FUNCT-1K1 B)))) &  not (( not tVar9 <>HIDDENR2 0ORDINAL1K5 & tVar9 be limit-ordinalORDINAL1V4) & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Df2(tVar9,tVar10)))"
                    proof(rule bexI[of _ "Cf2(C,L .FUNCT-1K1 C)"])
                      show " ex tVar9 be OrdinalORDINAL1M3 st  ex tVar10 be SequenceORDINAL1M4 st (tVar9 =HIDDENR1 a & tVar10 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar9 =XBOOLE-0R4 0ORDINAL1K5 & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar9 =XBOOLE-0R4 succORDINAL1K1 B & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Cf2(B,tVar10 .FUNCT-1K1 B)))) &  not (( not tVar9 <>HIDDENR2 0ORDINAL1K5 & tVar9 be limit-ordinalORDINAL1V4) & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Df2(tVar9,tVar10)))"
                      proof(rule bexI[of _ "A"])
                        show " ex tVar10 be SequenceORDINAL1M4 st (A =HIDDENR1 a & tVar10 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Cf2(B,tVar10 .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Cf2(C,tVar10 .FUNCT-1K1 C) =HIDDENR1 Df2(A,tVar10)))"
                        proof(rule bexI[of _ "L"],rule conjMI)
                          show "A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a"
                            using A23 funct_1_th_1 sorry
                          show " not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Cf2(C,L .FUNCT-1K1 C) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Cf2(C,L .FUNCT-1K1 C) =HIDDENR1 Cf2(B,L .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Cf2(C,L .FUNCT-1K1 C) =HIDDENR1 Df2(A,L)))"
                            using A25 sorry
                        qed "sorry"
                      qed "sorry"
                    qed "sorry"
                  qed
                  thus " ?thesis "
                     sorry
                qed
              qed
              have A26: "A <>HIDDENR2 0ORDINAL1K5 & ( for C be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 C) implies ( ex Ac be OrdinalORDINAL1M3 st  ex Lc be SequenceORDINAL1M4 st (Ac =HIDDENR1 a & Lc =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ac =XBOOLE-0R4 0ORDINAL1K5 & Df2(A,L) =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ac =XBOOLE-0R4 succORDINAL1K1 B & Df2(A,L) =HIDDENR1 Cf2(B,Lc .FUNCT-1K1 B))) or (Ac <>HIDDENR2 0ORDINAL1K5 & Ac be limit-ordinalORDINAL1V4) & Df2(A,L) =HIDDENR1 Df2(Ac,Lc)))"
              proof(rule impI)
                assume A27: "A <>HIDDENR2 0ORDINAL1K5 & ( for C be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 C)"
                show " ex Ac be OrdinalORDINAL1M3 st  ex Lc be SequenceORDINAL1M4 st (Ac =HIDDENR1 a & Lc =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ac =XBOOLE-0R4 0ORDINAL1K5 & Df2(A,L) =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ac =XBOOLE-0R4 succORDINAL1K1 B & Df2(A,L) =HIDDENR1 Cf2(B,Lc .FUNCT-1K1 B))) or (Ac <>HIDDENR2 0ORDINAL1K5 & Ac be limit-ordinalORDINAL1V4) & Df2(A,L) =HIDDENR1 Df2(Ac,Lc))"
                proof-
                  have " ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be SequenceORDINAL1M4 st (tVar11 =HIDDENR1 a & tVar12 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar11 =XBOOLE-0R4 0ORDINAL1K5 & Df2(tVar11,tVar12) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar11 =XBOOLE-0R4 succORDINAL1K1 B & Df2(tVar11,tVar12) =HIDDENR1 Cf2(B,tVar12 .FUNCT-1K1 B)))) &  not (( not tVar11 <>HIDDENR2 0ORDINAL1K5 & tVar11 be limit-ordinalORDINAL1V4) & Df2(tVar11,tVar12) =HIDDENR1 Df2(tVar11,tVar12)))"
                  proof-
                    show " ex tVar11 be OrdinalORDINAL1M3 st  ex tVar12 be SequenceORDINAL1M4 st (tVar11 =HIDDENR1 a & tVar12 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar11 =XBOOLE-0R4 0ORDINAL1K5 & Df2(tVar11,tVar12) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar11 =XBOOLE-0R4 succORDINAL1K1 B & Df2(tVar11,tVar12) =HIDDENR1 Cf2(B,tVar12 .FUNCT-1K1 B)))) &  not (( not tVar11 <>HIDDENR2 0ORDINAL1K5 & tVar11 be limit-ordinalORDINAL1V4) & Df2(tVar11,tVar12) =HIDDENR1 Df2(tVar11,tVar12)))"
                    proof(rule bexI[of _ "A"])
                      show " ex tVar12 be SequenceORDINAL1M4 st (A =HIDDENR1 a & tVar12 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Df2(A,tVar12) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Df2(A,tVar12) =HIDDENR1 Cf2(B,tVar12 .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Df2(A,tVar12) =HIDDENR1 Df2(A,tVar12)))"
                      proof(rule bexI[of _ "L"],rule conjMI)
                        show "A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a"
                          using A23 funct_1_th_1 sorry
                        show " not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Df2(A,L) =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Df2(A,L) =HIDDENR1 Cf2(B,L .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Df2(A,L) =HIDDENR1 Df2(A,L)))"
                          using A27 ordinal1_th_29 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  thus " ?thesis "
                     sorry
                qed
              qed
              have "A =XBOOLE-0R4 0ORDINAL1K5 implies ( ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(A,L)))"
              proof(rule impI)
                assume A28: "A =XBOOLE-0R4 0ORDINAL1K5"
                show " ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(A,L))"
                proof-
                  have " ex tVar13 be OrdinalORDINAL1M3 st  ex tVar14 be SequenceORDINAL1M4 st (tVar13 =HIDDENR1 a & tVar14 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar13 =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar13 =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,tVar14 .FUNCT-1K1 B)))) &  not (( not tVar13 <>HIDDENR2 0ORDINAL1K5 & tVar13 be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(tVar13,tVar14)))"
                  proof-
                    show " ex tVar13 be OrdinalORDINAL1M3 st  ex tVar14 be SequenceORDINAL1M4 st (tVar13 =HIDDENR1 a & tVar14 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (tVar13 =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (tVar13 =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,tVar14 .FUNCT-1K1 B)))) &  not (( not tVar13 <>HIDDENR2 0ORDINAL1K5 & tVar13 be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(tVar13,tVar14)))"
                    proof(rule bexI[of _ "A"])
                      show " ex tVar14 be SequenceORDINAL1M4 st (A =HIDDENR1 a & tVar14 =XBOOLE-0R4 G .FUNCT-1K1 a) &  not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,tVar14 .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(A,tVar14)))"
                      proof(rule bexI[of _ "L"],rule conjMI)
                        show "A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a"
                          using A23 funct_1_th_1 sorry
                        show " not (( not (A =XBOOLE-0R4 0ORDINAL1K5 & Bf0 =HIDDENR1 Bf0) & ( for B be OrdinalORDINAL1M3 holds  not (A =XBOOLE-0R4 succORDINAL1K1 B & Bf0 =HIDDENR1 Cf2(B,L .FUNCT-1K1 B)))) &  not (( not A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & Bf0 =HIDDENR1 Df2(A,L)))"
                          using A28 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  thus " ?thesis "
                     sorry
                qed
              qed
              thus " not ( for b be objectHIDDENM1 holds  not ( ex A be OrdinalORDINAL1M3 st  ex L be SequenceORDINAL1M4 st (A =HIDDENR1 a & L =XBOOLE-0R4 G .FUNCT-1K1 a) & ((A =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,L .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(A,L))))"
                using A24 A26 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A29: " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds (a inHIDDENR3 B & ?Q(a,b)) & ?Q(a,c) implies b =HIDDENR1 c"
          proof-
            have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds  for c be objectHIDDENM1 holds a inHIDDENR3 B implies (( ex Ab be OrdinalORDINAL1M3 st  ex Lb be SequenceORDINAL1M4 st (Ab =HIDDENR1 a & Lb =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ab =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ab =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,Lb .FUNCT-1K1 B))) or (Ab <>HIDDENR2 0ORDINAL1K5 & Ab be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(Ab,Lb))) implies (( ex Ac be OrdinalORDINAL1M3 st  ex Lc be SequenceORDINAL1M4 st (Ac =HIDDENR1 a & Lc =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ac =XBOOLE-0R4 0ORDINAL1K5 & c =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ac =XBOOLE-0R4 succORDINAL1K1 B & c =HIDDENR1 Cf2(B,Lc .FUNCT-1K1 B))) or (Ac <>HIDDENR2 0ORDINAL1K5 & Ac be limit-ordinalORDINAL1V4) & c =HIDDENR1 Df2(Ac,Lc))) implies b =HIDDENR1 c))"
            proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule impI)
              fix a assume [ty]: "a be objectHIDDENM1"
              fix b assume [ty]: "b be objectHIDDENM1"
              fix c assume [ty]: "c be objectHIDDENM1"
              assume "a inHIDDENR3 B"
              assume Given: " ex Ab be OrdinalORDINAL1M3 st  ex Lb be SequenceORDINAL1M4 st (Ab =HIDDENR1 a & Lb =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ab =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ab =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,Lb .FUNCT-1K1 B))) or (Ab <>HIDDENR2 0ORDINAL1K5 & Ab be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(Ab,Lb))"
              then obtain Ab Lb where
                [ty]:"Ab be OrdinalORDINAL1M3" "Lb be SequenceORDINAL1M4" and 
                A30: "Ab =HIDDENR1 a"and A31: "Lb =XBOOLE-0R4 G .FUNCT-1K1 a"and A32: "(Ab =XBOOLE-0R4 0ORDINAL1K5 & b =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ab =XBOOLE-0R4 succORDINAL1K1 B & b =HIDDENR1 Cf2(B,Lb .FUNCT-1K1 B))) or (Ab <>HIDDENR2 0ORDINAL1K5 & Ab be limit-ordinalORDINAL1V4) & b =HIDDENR1 Df2(Ab,Lb)"
                 sorry
              assume Given: " ex Ac be OrdinalORDINAL1M3 st  ex Lc be SequenceORDINAL1M4 st (Ac =HIDDENR1 a & Lc =XBOOLE-0R4 G .FUNCT-1K1 a) & ((Ac =XBOOLE-0R4 0ORDINAL1K5 & c =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ac =XBOOLE-0R4 succORDINAL1K1 B & c =HIDDENR1 Cf2(B,Lc .FUNCT-1K1 B))) or (Ac <>HIDDENR2 0ORDINAL1K5 & Ac be limit-ordinalORDINAL1V4) & c =HIDDENR1 Df2(Ac,Lc))"
              then obtain Ac Lc where
                [ty]:"Ac be OrdinalORDINAL1M3" "Lc be SequenceORDINAL1M4" and 
                A33: "Ac =HIDDENR1 a"and A34: "Lc =XBOOLE-0R4 G .FUNCT-1K1 a"and A35: "(Ac =XBOOLE-0R4 0ORDINAL1K5 & c =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st Ac =XBOOLE-0R4 succORDINAL1K1 B & c =HIDDENR1 Cf2(B,Lc .FUNCT-1K1 B))) or (Ac <>HIDDENR2 0ORDINAL1K5 & Ac be limit-ordinalORDINAL1V4) & c =HIDDENR1 Df2(Ac,Lc)"
                 sorry
              have "( ex C be OrdinalORDINAL1M3 st Ab =XBOOLE-0R4 succORDINAL1K1 C) implies b =HIDDENR1 c"
              proof(rule impI)
                assume Given: " ex C be OrdinalORDINAL1M3 st Ab =XBOOLE-0R4 succORDINAL1K1 C"
                then obtain C where
                  [ty]:"C be OrdinalORDINAL1M3" and 
                  A36: "Ab =XBOOLE-0R4 succORDINAL1K1 C"
                   sorry
                obtain A where
                  [ty]:"A be OrdinalORDINAL1M3" and 
                  A37: "Ab =XBOOLE-0R4 succORDINAL1K1 A"and A38: "b =HIDDENR1 Cf2(A,Lb .FUNCT-1K1 A)"
                  using A32 A36 ordinal1_th_29 sorry
                obtain D where
                  [ty]:"D be OrdinalORDINAL1M3" and 
                  A39: "Ac =XBOOLE-0R4 succORDINAL1K1 D"and A40: "c =HIDDENR1 Cf2(D,Lc .FUNCT-1K1 D)"
                  using A30 A33 A35 A36 ordinal1_th_29 sorry
                have "A =XBOOLE-0R4 D"
                  using A30 A33 A37 A39 ordinal1_th_7 sorry
                thus "b =HIDDENR1 c"
                  using A31 A34 A38 A40 sorry
              qed
              thus "b =HIDDENR1 c"
                using A30 A31 A32 A33 A34 A35 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          obtain F where
            [ty]:"F be FunctionFUNCT-1M1" and 
            A41: "domRELAT-1K1 F =XBOOLE-0R4 B & ( for a be objectHIDDENM1 holds a inHIDDENR3 B implies ?Q(a,F .FUNCT-1K1 a))"
            using funct_1_sch_2 A29 A21 sorry
          obtain L where 
            [ty]:"L be SequenceORDINAL1M4" and LDef:"L = F"
            using A41 ordinal1_def_7 sorry
          show " ex tVar15 be SequenceORDINAL1M4 st domRELAT-1K1 tVar15 =XBOOLE-0R4 B & ((0ORDINAL1K5 inTARSKIR2 B implies tVar15 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0) & (( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 B implies tVar15 .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,tVar15 .FUNCT-1K1 A)) & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B & (D <>HIDDENR2 0ORDINAL1K5 & D be limit-ordinalORDINAL1V4) implies tVar15 .FUNCT-1K1 D =HIDDENR1 Df2(D,tVar15  |RELAT-1K8 D))))"
          proof(rule bexI[of _ "L"],rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
            show "domRELAT-1K1 L =XBOOLE-0R4 B"
              using A41 sorry
            show "0ORDINAL1K5 inTARSKIR2 B implies L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0"
            proof(rule impI)
              assume "0ORDINAL1K5 inTARSKIR2 B"
              then have " ex A be OrdinalORDINAL1M3 st  ex K be SequenceORDINAL1M4 st (A =XBOOLE-0R4 0ORDINAL1K5 & K =XBOOLE-0R4 G .FUNCT-1K1 (0ORDINAL1K5)) & ((A =XBOOLE-0R4 0ORDINAL1K5 & F .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & F .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Cf2(B,K .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & F .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Df2(A,K))"
                using A41 sorry
              thus "L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0"
                 sorry
            qed
            have A42: " for A be OrdinalORDINAL1M3 holds  for L1 be SequenceORDINAL1M4 holds A inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 A implies L  |RELAT-1K8 A =FUNCT-1R1 L1"
            proof-
              let ?Q = "\<lambda>Lamb1.  for L1 be SequenceORDINAL1M4 holds Lamb1 inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 Lamb1 implies L  |RELAT-1K8 Lamb1 =FUNCT-1R1 L1"
              have A43: " for A be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies ?Q(C)) implies ?Q(A)"
              proof-
                have " for A be OrdinalORDINAL1M3 holds ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies ( for L1 be SequenceORDINAL1M4 holds C inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 C implies L  |RELAT-1K8 C =FUNCT-1R1 L1)) implies ( for L1 be SequenceORDINAL1M4 holds A inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 A implies L  |RELAT-1K8 A =FUNCT-1R1 L1)"
                proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
                  fix A assume [ty]: "A be OrdinalORDINAL1M3"
                  assume " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 A implies ( for L1 be SequenceORDINAL1M4 holds C inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 C implies L  |RELAT-1K8 C =FUNCT-1R1 L1)"
                  fix L1 assume [ty]: "L1 be SequenceORDINAL1M4"
                  assume A44: "A inTARSKIR2 B"
                    and A45: "L1 =XBOOLE-0R4 G .FUNCT-1K1 A"
                  have A46: "[TARSKIK4 A,L1 ] inHIDDENR3 G"
                    using A18 A44 A45 funct_1_th_1 sorry
                  then have A47: "?P(A,L1)"
                    using A17 sorry
                  have A48: " for x be objectHIDDENM1 holds x inHIDDENR3 A implies L1 .FUNCT-1K1 x =XBOOLE-0R4 (L  |RELAT-1K8 A).FUNCT-1K1 x"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume A49: "x inHIDDENR3 A"
                    then obtain x9 where 
                      [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
                       sorry
                    have A50: "x9 inTARSKIR2 B"
                      using A44 A49 ordinal1_th_10 sorry
                    then obtain A1 L2 where
                      [ty]:"A1 be OrdinalORDINAL1M3" "L2 be SequenceORDINAL1M4" and 
                      A51: "A1 =XBOOLE-0R4 x9"and A52: "L2 =XBOOLE-0R4 G .FUNCT-1K1 x9"and A53: "(A1 =XBOOLE-0R4 0ORDINAL1K5 & L .FUNCT-1K1 x9 =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A1 =XBOOLE-0R4 succORDINAL1K1 B & L .FUNCT-1K1 x9 =HIDDENR1 Cf2(B,L2 .FUNCT-1K1 B))) or (A1 <>HIDDENR2 0ORDINAL1K5 & A1 be limit-ordinalORDINAL1V4) & L .FUNCT-1K1 x9 =HIDDENR1 Df2(A1,L2)"
                      using A41 sorry
                    have " for D be OrdinalORDINAL1M3 holds  for L3 be SequenceORDINAL1M4 holds D =XBOOLE-0R4 x9 & L3 =FUNCT-1R1 L1  |RELAT-1K8 x9 implies ?P(D,L3)"
                    proof-
                      have " for D be OrdinalORDINAL1M3 holds  for L3 be SequenceORDINAL1M4 holds D =XBOOLE-0R4 x9 & L3 =FUNCT-1R1 L1  |RELAT-1K8 x9 implies domRELAT-1K1 L3 =XBOOLE-0R4 D & ((0ORDINAL1K5 inTARSKIR2 D implies L3 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0) & (( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 D implies L3 .FUNCT-1K1 succORDINAL1K1 C =HIDDENR1 Cf2(C,L3 .FUNCT-1K1 C)) & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 D & (C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4) implies L3 .FUNCT-1K1 C =HIDDENR1 Df2(C,L3  |RELAT-1K8 C))))"
                      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule conjMI,rule conjMI,rule ballI,rule impMI ,rule impI)
                        fix D assume [ty]: "D be OrdinalORDINAL1M3"
                        fix L3 assume [ty]: "L3 be SequenceORDINAL1M4"
                        assume A54: "D =XBOOLE-0R4 x9"
                          and A55: "L3 =FUNCT-1R1 L1  |RELAT-1K8 x9"
                        have "x9 c=ORDINAL1R1 A"
                          using A49 ordinal1_def_2 sorry
                        thus "domRELAT-1K1 L3 =XBOOLE-0R4 D"
                          using A47 A54 A55 relat_1_th_62 sorry
                        show "0ORDINAL1K5 inTARSKIR2 D implies L3 .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0"
                          using A47 A49 A54 A55 funct_1_th_49 ordinal1_th_10 sorry
                        show " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 D implies L3 .FUNCT-1K1 succORDINAL1K1 C =HIDDENR1 Cf2(C,L3 .FUNCT-1K1 C)"
                        proof-
                          have " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 D implies L3 .FUNCT-1K1 succORDINAL1K1 C =HIDDENR1 Cf2(C,L3 .FUNCT-1K1 C)"
                          proof(rule ballI,rule impI)
                            fix C assume [ty]: "C be OrdinalORDINAL1M3"
                            assume A56: "succORDINAL1K1 C inTARSKIR2 D"
                            have "C inTARSKIR2 succORDINAL1K1 C"
                              using ordinal1_th_6 sorry
                            then have A57: "(L1  |RELAT-1K8 x9).FUNCT-1K1 C =XBOOLE-0R4 L1 .FUNCT-1K1 C"
                              using A54 A56 funct_1_th_49 ordinal1_th_10 sorry
                            have "succORDINAL1K1 C inTARSKIR2 A & (L1  |RELAT-1K8 x9).FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 L1 .FUNCT-1K1 succORDINAL1K1 C"
                              using A49 A54 A56 funct_1_th_49 ordinal1_th_10 sorry
                            thus "L3 .FUNCT-1K1 succORDINAL1K1 C =HIDDENR1 Cf2(C,L3 .FUNCT-1K1 C)"
                              using A17 A46 A55 A57 sorry
                          qed "sorry"
                          thus " ?thesis "
                             sorry
                        qed
                        fix C assume [ty]: "C be OrdinalORDINAL1M3"
                        assume A58: "C inTARSKIR2 D"
                          and A59: "C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4"
                        have "C c=ORDINAL1R1 x9"
                          using A54 A58 ordinal1_def_2 sorry
                        then have A60: "L1  |RELAT-1K8 C =FUNCT-1R1 L3  |RELAT-1K8 C"
                          using A55 funct_1_th_51 sorry
                        have "C inTARSKIR2 A"
                          using A49 A54 A58 ordinal1_th_10 sorry
                        then have "L1 .FUNCT-1K1 C =HIDDENR1 Df2(C,L3  |RELAT-1K8 C)"
                          using A17 A46 A59 A60 sorry
                        thus "L3 .FUNCT-1K1 C =HIDDENR1 Df2(C,L3  |RELAT-1K8 C)"
                          using A54 A55 A58 funct_1_th_49 sorry
                      qed "sorry"
                      thus " ?thesis "
                         sorry
                    qed
                    then have "[TARSKIK4 x9,L1  |RELAT-1K8 x9 ] inHIDDENR3 G"
                      using A17 A50 sorry
                    then have A61: "L1  |RELAT-1K8 x9 =FUNCT-1R1 L2"
                      using A52 funct_1_th_1 sorry
                    have A62: "(L  |RELAT-1K8 A).FUNCT-1K1 x =XBOOLE-0R4 L .FUNCT-1K1 x"
                      using A49 funct_1_th_49 sorry
                    have "( ex D be OrdinalORDINAL1M3 st x9 =XBOOLE-0R4 succORDINAL1K1 D) implies L1 .FUNCT-1K1 x =XBOOLE-0R4 (L  |RELAT-1K8 A).FUNCT-1K1 x"
                    proof(rule impI)
                      assume Given: " ex D be OrdinalORDINAL1M3 st x9 =XBOOLE-0R4 succORDINAL1K1 D"
                      then obtain D where
                        [ty]:"D be OrdinalORDINAL1M3" and 
                        A63: "x9 =XBOOLE-0R4 succORDINAL1K1 D"
                         sorry
                      have A64: "L1 .FUNCT-1K1 x =HIDDENR1 Cf2(D,L1 .FUNCT-1K1 D)"
                        using A17 A46 A49 A63 sorry
                      obtain C where
                        [ty]:"C be OrdinalORDINAL1M3" and 
                        A65: "A1 =XBOOLE-0R4 succORDINAL1K1 C"and A66: "L .FUNCT-1K1 x9 =HIDDENR1 Cf2(C,L2 .FUNCT-1K1 C)"
                        using A51 A53 A63 ordinal1_th_29 sorry
                      have "C =XBOOLE-0R4 D"
                        using A51 A63 A65 ordinal1_th_7 sorry
                      thus "L1 .FUNCT-1K1 x =XBOOLE-0R4 (L  |RELAT-1K8 A).FUNCT-1K1 x"
                        using A62 A61 A63 A66 A64 funct_1_th_49 ordinal1_th_6 sorry
                    qed
                    thus "L1 .FUNCT-1K1 x =XBOOLE-0R4 (L  |RELAT-1K8 A).FUNCT-1K1 x"
                      using A17 A46 A49 A51 A53 A62 A61 sorry
                  qed "sorry"
                  have "A c=ORDINAL1R1 domRELAT-1K1 L"
                    using A41 A44 ordinal1_def_2 sorry
                  then have "domRELAT-1K1 (L  |RELAT-1K8 A) =XBOOLE-0R4 A"
                    using relat_1_th_62 sorry
                  thus "L  |RELAT-1K8 A =FUNCT-1R1 L1"
                    using A47 A48 funct_1_th_2 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              show " for A be OrdinalORDINAL1M3 holds  for L1 be SequenceORDINAL1M4 holds A inTARSKIR2 B & L1 =XBOOLE-0R4 G .FUNCT-1K1 A implies L  |RELAT-1K8 A =FUNCT-1R1 L1"
                using ordinal1_sch_2 A43 sorry
            qed
            show " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 B implies L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A)"
            proof-
              have " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 B implies L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A)"
              proof(rule ballI,rule impI)
                fix A assume [ty]: "A be OrdinalORDINAL1M3"
                assume A67: "succORDINAL1K1 A inTARSKIR2 B"
                then obtain C K where
                  [ty]:"C be OrdinalORDINAL1M3" "K be SequenceORDINAL1M4" and 
                  A68: "C =XBOOLE-0R4 succORDINAL1K1 A"and A69: "K =XBOOLE-0R4 G .FUNCT-1K1 succORDINAL1K1 A"and A70: "(C =XBOOLE-0R4 0ORDINAL1K5 & F .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st C =XBOOLE-0R4 succORDINAL1K1 B & F .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(B,K .FUNCT-1K1 B))) or (C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4) & F .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Df2(C,K)"
                  using A41 sorry
                have A71: "K =FUNCT-1R1 L  |RELAT-1K8 succORDINAL1K1 A"
                  using A42 A67 A69 sorry
                obtain D where
                  [ty]:"D be OrdinalORDINAL1M3" and 
                  A72: "C =XBOOLE-0R4 succORDINAL1K1 D"and A73: "F .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(D,K .FUNCT-1K1 D)"
                  using A68 A70 ordinal1_th_29 sorry
                have "A =XBOOLE-0R4 D"
                  using A68 A72 ordinal1_th_7 sorry
                thus "L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A)"
                  using A73 A71 funct_1_th_49 ordinal1_th_6 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            fix D assume [ty]: "D be OrdinalORDINAL1M3"
            assume A74: "D inTARSKIR2 B"
              and A75: "D <>HIDDENR2 0ORDINAL1K5 & D be limit-ordinalORDINAL1V4"
            have " ex A be OrdinalORDINAL1M3 st  ex K be SequenceORDINAL1M4 st (A =XBOOLE-0R4 D & K =XBOOLE-0R4 G .FUNCT-1K1 D) & ((A =XBOOLE-0R4 0ORDINAL1K5 & F .FUNCT-1K1 D =HIDDENR1 Bf0 or ( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B & F .FUNCT-1K1 D =HIDDENR1 Cf2(B,K .FUNCT-1K1 B))) or (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & F .FUNCT-1K1 D =HIDDENR1 Df2(A,K))"
              using A41 A74 sorry
            thus "L .FUNCT-1K1 D =HIDDENR1 Df2(D,L  |RELAT-1K8 D)"
              using A42 A74 A75 ordinal1_th_29 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for A be OrdinalORDINAL1M3 holds ?R(A)"
        using ordinal1_sch_2 A1 sorry
      thus " not ( for L be SequenceORDINAL1M4 holds  not (((domRELAT-1K1 L =XBOOLE-0R4 Af0 &  not (0ORDINAL1K5 inTARSKIR2 Af0 &  not L .FUNCT-1K1 (0ORDINAL1K5) =HIDDENR1 Bf0)) & ( for A be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 A inTARSKIR2 Af0 &  not L .FUNCT-1K1 succORDINAL1K1 A =HIDDENR1 Cf2(A,L .FUNCT-1K1 A)))) & ( for A be OrdinalORDINAL1M3 holds  not (((A inTARSKIR2 Af0 &  not A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 A =HIDDENR1 Df2(A,L  |RELAT-1K8 A)))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_6:
  fixes Lf0 Ff1 Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "Lf0 be SequenceORDINAL1M4" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be setHIDDENM2" and
   A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))" and
   A2: "domRELAT-1K1 Lf0 =XBOOLE-0R4 Af0" and
   A3: "0ORDINAL1K5 inTARSKIR2 Af0 implies Lf0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0" and
   A4: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies Lf0 .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,Lf0 .FUNCT-1K1 A)" and
   A5: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies Lf0 .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,Lf0  |RELAT-1K8 A)"
  shows " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 Lf0 implies Lf0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?L = "Lf0  |RELAT-1K8 succORDINAL1K1 A"
    assume "A inTARSKIR2 domRELAT-1K1 Lf0"
    then have A6: "succORDINAL1K1 A c=ORDINAL1R1 domRELAT-1K1 Lf0"
      using ordinal1_th_21 sorry
    have A7: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies ?L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,?L .FUNCT-1K1 C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies (Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,(Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C)"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A8: "succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A"
        have "C inTARSKIR2 succORDINAL1K1 C"
          using ordinal1_th_6 sorry
        then have A9: "?L .FUNCT-1K1 C =XBOOLE-0R4 Lf0 .FUNCT-1K1 C"
          using A8 funct_1_th_49 ordinal1_th_10 sorry
        have "?L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Lf0 .FUNCT-1K1 succORDINAL1K1 C"
          using A8 funct_1_th_49 sorry
        thus "(Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,(Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C)"
          using A2 A4 A6 A8 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies ?L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,?L  |RELAT-1K8 C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 succORDINAL1K1 A & (C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4) implies (Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C =XBOOLE-0R4 Df2(C,(Lf0  |RELAT-1K8 succORDINAL1K1 A) |RELAT-1K8 C)"
      proof(rule ballI,rule impMI ,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A11: "C inTARSKIR2 succORDINAL1K1 A"
          and A12: "C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4"
        have "C c=ORDINAL1R1 succORDINAL1K1 A"
          using A11 ordinal1_def_2 sorry
        then have A13: "?L  |RELAT-1K8 C =FUNCT-1R1 Lf0  |RELAT-1K8 C"
          using funct_1_th_51 sorry
        have "?L .FUNCT-1K1 C =XBOOLE-0R4 Lf0 .FUNCT-1K1 C"
          using A11 funct_1_th_49 sorry
        thus "(Lf0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C =XBOOLE-0R4 Df2(C,(Lf0  |RELAT-1K8 succORDINAL1K1 A) |RELAT-1K8 C)"
          using A2 A5 A6 A11 A12 A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "0ORDINAL1K5 c=ORDINAL1R1 succORDINAL1K1 A"
       sorry
    then have "0ORDINAL1K5 c<XBOOLE-0R2 succORDINAL1K1 A"
       sorry
    then have A14: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 A & ?L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Lf0 .FUNCT-1K1 (0ORDINAL1K5)"
      using funct_1_th_49 ordinal1_th_11 sorry
    have A15: "domRELAT-1K1 ?L =XBOOLE-0R4 succORDINAL1K1 A"
      using A6 relat_1_th_62 sorry
    then have "A inTARSKIR2 succORDINAL1K1 A & lastORDINAL2K1 ?L =XBOOLE-0R4 ?L .FUNCT-1K1 A"
      using ordinal2_th_2 ordinal1_th_21 sorry
    then have "lastORDINAL2K1 ?L =XBOOLE-0R4 Lf0 .FUNCT-1K1 A"
      using funct_1_th_49 sorry
    thus "Lf0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
      using A1 A2 A3 A6 A15 A14 A7 A10 sorry
  qed "sorry"

theorem ordinal2_sch_7:
  fixes Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be setHIDDENM2"
  shows "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))) & ( ex L be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
  proof-
    have "( ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex L1 be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L1 & domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0) & L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C))) implies (( ex L2 be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L2 & domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0) & L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A1: "((domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0 & (0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))"
        using ordinal2_sch_5 sorry
      show " ex x be objectHIDDENM1 st  ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C))"
      proof-
        have " ex x be setHIDDENM2 st  ex tVar17 be SequenceORDINAL1M4 st (x =XBOOLE-0R4 lastORDINAL2K1 tVar17 & domRELAT-1K1 tVar17 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar17 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar17 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar17 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar17 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar17  |RELAT-1K8 C))))"
        proof-
          obtain x where 
            [ty]:"x be setHIDDENM2" and xDef:"x = lastORDINAL2K1 L"
             sorry
          show " ex x be setHIDDENM2 st  ex tVar17 be SequenceORDINAL1M4 st (x =XBOOLE-0R4 lastORDINAL2K1 tVar17 & domRELAT-1K1 tVar17 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar17 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar17 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar17 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar17 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar17  |RELAT-1K8 C))))"
          proof(rule bexI[of _ "x"])
            show " ex tVar17 be SequenceORDINAL1M4 st (x =XBOOLE-0R4 lastORDINAL2K1 tVar17 & domRELAT-1K1 tVar17 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar17 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar17 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar17 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar17 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar17  |RELAT-1K8 C))))"
            proof(rule bexI[of _ "L"],rule conjMI)
              show "x =XBOOLE-0R4 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0"
                using A1 sorry
              have "0ORDINAL1K5 c=ORDINAL1R1 succORDINAL1K1 Af0"
                 sorry
              then have "0ORDINAL1K5 c<XBOOLE-0R2 succORDINAL1K1 Af0"
                 sorry
              thus "(L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))"
                using A1 ordinal1_th_11 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      fix x1 assume [ty]: "x1 be setHIDDENM2"
      fix x2 assume [ty]: "x2 be setHIDDENM2"
      assume Given: " ex L1 be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 L1 & domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0) & L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C))"
      then obtain L1 where
        [ty]:"L1 be SequenceORDINAL1M4" and 
        A2: "x1 =XBOOLE-0R4 lastORDINAL2K1 L1"and A3: "domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0"and A4: "L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A5: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C)"and A6: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C)"
         sorry
      have A7: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"
        using A4 sorry
      assume Given: " ex L2 be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 L2 & domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0) & L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C))"
      then obtain L2 where
        [ty]:"L2 be SequenceORDINAL1M4" and 
        A8: "x2 =XBOOLE-0R4 lastORDINAL2K1 L2"and A9: "domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0"and A10: "L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A11: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C)"and A12: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C)"
         sorry
      have A13: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"
        using A10 sorry
      have "L1 =FUNCT-1R1 L2"
        using ordinal2_sch_4 A3 A7 A5 A6 A9 A13 A11 A12 sorry
      thus "x1 =XBOOLE-0R4 x2"
        using A2 A8 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_8:
  fixes Ff1 Bf0 Cf2 Df2 
  assumes
[ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be setHIDDENM2" and
   A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))"
  shows "Ff1(0ORDINAL1K5) =XBOOLE-0R4 Bf0"
  proof-
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A2: "((domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5) & (0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & ( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) implies L .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,L .FUNCT-1K1 A))) & ( for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,L  |RELAT-1K8 A))"
      using ordinal2_sch_5 sorry
    have "Bf0 =XBOOLE-0R4 lastORDINAL2K1 L"
      using A2 ordinal2_th_2 ordinal1_th_6 sorry
    thus "Ff1(0ORDINAL1K5) =XBOOLE-0R4 Bf0"
      using A1 A2 ordinal1_th_6 sorry
  qed

theorem ordinal2_sch_9:
  fixes Bf0 Cf2 Df2 Ff1 
  assumes
[ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
   A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))"
  shows " for A be OrdinalORDINAL1M3 holds Ff1(succORDINAL1K1 A) =XBOOLE-0R4 Cf2(A,Ff1(A))"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A2: "domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 (succORDINAL1K1 A)"and A3: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A4: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C)"and A5: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)"
      using ordinal2_sch_5 sorry
    have A6: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))"
      using A1 sorry
    have A7: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 B =XBOOLE-0R4 Ff1(B)"
      using ordinal2_sch_6 A6 A2 A3 A4 A5 sorry
    then have A8: "L .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Ff1(succORDINAL1K1 A)"
      using A2 ordinal1_th_6 sorry
    have "A inTARSKIR2 succORDINAL1K1 A & succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A)"
      using ordinal1_th_6 sorry
    then have "L .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
      using A2 A7 ordinal1_th_10 sorry
    thus "Ff1(succORDINAL1K1 A) =XBOOLE-0R4 Cf2(A,Ff1(A))"
      using A4 A8 ordinal1_th_6 sorry
  qed "sorry"

theorem ordinal2_sch_10:
  fixes Lf0 Af0 Ff1 Bf0 Cf2 Df2 
  assumes
[ty]: "Lf0 be SequenceORDINAL1M4" and
  [ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Cf2(x1,x2) be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be setHIDDENM2" and
   A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))" and
   A2: "Af0 <>HIDDENR2 0ORDINAL1K5 & Af0 be limit-ordinalORDINAL1V4" and
   A3: "domRELAT-1K1 Lf0 =XBOOLE-0R4 Af0" and
   A4: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies Lf0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
  shows "Ff1(Af0) =XBOOLE-0R4 Df2(Af0,Lf0)"
  proof-
    have A5: "Af0 inTARSKIR2 succORDINAL1K1 Af0"
      using ordinal1_th_6 sorry
    obtain L where
      [ty]:"L be SequenceORDINAL1M4" and 
      A6: "domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 Af0"and A7: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A8: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C)"and A9: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)"
      using ordinal2_sch_5 sorry
    let ?L1 = "L  |RELAT-1K8 Af0"
    have A10: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 Ff1(A) iff ( ex L be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 L & domRELAT-1K1 L =XBOOLE-0R4 succORDINAL1K1 A) & L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies L .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L  |RELAT-1K8 C)))"
      using A1 sorry
    have A11: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 B =XBOOLE-0R4 Ff1(B)"
      using ordinal2_sch_6 A10 A6 A7 A8 A9 sorry
    have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (L  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 Lf0 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A13: "x inHIDDENR3 Af0"
      then obtain x9 where 
        [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
         sorry
      have "(L  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 L .FUNCT-1K1 x9"
        using A13 funct_1_th_49 sorry
      also have "... = Ff1(x9)"
        using A6 A11 A5 A13 ordinal1_th_10 sorry
      also have "... = Lf0 .FUNCT-1K1 x"
        using A4 A13 sorry
      finally show "(L  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 Lf0 .FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "Af0 c=ORDINAL1R1 domRELAT-1K1 L"
      using A6 A5 ordinal1_def_2 sorry
    then have "domRELAT-1K1 ?L1 =XBOOLE-0R4 Af0"
      using relat_1_th_62 sorry
    then have "?L1 =FUNCT-1R1 Lf0"
      using A3 A12 funct_1_th_2 sorry
    then have "L .FUNCT-1K1 Af0 =XBOOLE-0R4 Df2(Af0,Lf0)"
      using A2 A9 ordinal1_th_6 sorry
    thus "Ff1(Af0) =XBOOLE-0R4 Df2(Af0,Lf0)"
      using A6 A11 ordinal1_th_6 sorry
  qed

theorem ordinal2_sch_11:
  fixes Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3"
  shows " ex fi be Ordinal-SequenceORDINAL2M1 st ((domRELAT-1K1 fi =XBOOLE-0R4 Af0 & (0ORDINAL1K5 inTARSKIR2 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & ( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A))) & ( for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fi  |RELAT-1K8 A))"
  proof-
    have " ex fi be Ordinal-SequenceORDINAL2M1 st (domRELAT-1K1 fi =XBOOLE-0R4 Af0 & (0ORDINAL1K5 inTARSKIR2 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & (( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A)) & ( for A be OrdinalORDINAL1M3 holds  not (((A inTARSKIR2 Af0 &  not A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fi  |RELAT-1K8 A))))"
    proof-
      let ?CC = "\<lambda>Lamb1. \<lambda>Lamb2. Cf2(Lamb1,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 Lamb2}))"
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A1: "domRELAT-1K1 L =XBOOLE-0R4 Af0"and A2: "0ORDINAL1K5 inTARSKIR2 Af0 implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A3: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies L .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 ?CC(A,L .FUNCT-1K1 A)"and A4: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,L  |RELAT-1K8 A)"
        using ordinal2_sch_5 sorry
      have "L be Ordinal-yieldingORDINAL2V1"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 L implies x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 L)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A5: "x inHIDDENR3 rngFUNCT-1K2 L"
          then obtain y where
            [ty]:"y be objectHIDDENM1" and 
            A6: "y inHIDDENR3 domRELAT-1K1 L"and A7: "x =HIDDENR1 L .FUNCT-1K1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"y be OrdinalORDINAL1M3"
            using A6 sorry
          have A8: "y <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds y <>HIDDENR2 succORDINAL1K1 B) implies x be OrdinalORDINAL1M3"
          proof(rule impMI ,rule impI)
            assume A9: "y <>HIDDENR2 0ORDINAL1K5"
              and A10: " for B be OrdinalORDINAL1M3 holds y <>HIDDENR2 succORDINAL1K1 B"
            have "y be limit-ordinalORDINAL1V4"
              using A10 ordinal1_th_29 sorry
            then have "L .FUNCT-1K1 y =XBOOLE-0R4 Df2(y,L  |RELAT-1K8 y)"
              using A1 A4 A6 A9 sorry
            thus "x be OrdinalORDINAL1M3"
              using A7 sorry
          qed
          have A11: "OnORDINAL1K2 (rngFUNCT-1K2 L) c=TARSKIR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
            using ordinal2_def_3 sorry
          have "( ex B be OrdinalORDINAL1M3 st y =XBOOLE-0R4 succORDINAL1K1 B) implies x be OrdinalORDINAL1M3"
          proof(rule impI)
            assume Given: " ex B be OrdinalORDINAL1M3 st y =XBOOLE-0R4 succORDINAL1K1 B"
            then obtain B where
              [ty]:"B be OrdinalORDINAL1M3" and 
              A12: "y =XBOOLE-0R4 succORDINAL1K1 B"
               sorry
            have "L .FUNCT-1K1 y =XBOOLE-0R4 Cf2(B,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L .FUNCT-1K1 B }))"
              using A1 A3 A6 A12 sorry
            thus "x be OrdinalORDINAL1M3"
              using A7 sorry
          qed
          then have "x inHIDDENR3 OnORDINAL1K2 (rngFUNCT-1K2 L)"
            using A1 A2 A5 A6 A7 A8 ordinal1_def_9 sorry
          thus "x inHIDDENR3 supORDINAL2K3 (rngFUNCT-1K2 L)"
            using A11 sorry
        qed "sorry"
        then have "rngFUNCT-1K2 L c=TARSKIR1 supORDINAL2K3 (rngFUNCT-1K2 L)"
          using tarski_def_3 sorry
        thus "L be Ordinal-yieldingORDINAL2V1"
          using bexI[of _ "supORDINAL2K3 (rngFUNCT-1K2 L)"] ordinal2_def_4 sorry
      qed
      then have 
        [ty]:"L be Ordinal-SequenceORDINAL2M1"
         sorry
      obtain fi where 
        [ty]:"fi be Ordinal-SequenceORDINAL2M1" and fiDef:"fi = L"
         sorry
      show " ex fi be Ordinal-SequenceORDINAL2M1 st (domRELAT-1K1 fi =XBOOLE-0R4 Af0 & (0ORDINAL1K5 inTARSKIR2 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & (( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A)) & ( for A be OrdinalORDINAL1M3 holds  not (((A inTARSKIR2 Af0 &  not A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fi  |RELAT-1K8 A))))"
      proof(rule bexI[of _ "fi"],rule conjMI,rule conjMI)
        show "domRELAT-1K1 fi =XBOOLE-0R4 Af0 & (0ORDINAL1K5 inTARSKIR2 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)"
          using A1 A2 sorry
        show " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A)"
        proof-
          have " for A be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 A inTARSKIR2 Af0 &  not fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A))"
          proof(rule ballI)
            fix A assume [ty]: "A be OrdinalORDINAL1M3"
            obtain B where 
              [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = fi .FUNCT-1K1 A"
               sorry
            have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 B}) =HIDDENR1 supORDINAL2K3 B"
              using zfmisc_1_th_25 sorry
            also have "... = B"
              using ordinal2_th_18 sorry
            finally have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 B}) =HIDDENR1 B"
               sorry
            thus " not (succORDINAL1K1 A inTARSKIR2 Af0 &  not fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A))"
              using A3 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for A be OrdinalORDINAL1M3 holds  not (((A inTARSKIR2 Af0 &  not A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fi  |RELAT-1K8 A))"
          using A4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_12:
  fixes fif0 Ff1 Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "fif0 be Ordinal-SequenceORDINAL2M1" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be OrdinalORDINAL1M3" and
  [ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3" and
   A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))" and
   A2: "domRELAT-1K1 fif0 =XBOOLE-0R4 Af0" and
   A3: "0ORDINAL1K5 inTARSKIR2 Af0 implies fif0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0" and
   A4: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 Af0 implies fif0 .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fif0 .FUNCT-1K1 A)" and
   A5: " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 Af0 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies fif0 .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fif0  |RELAT-1K8 A)"
  shows " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 fif0 implies fif0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?fi = "fif0  |RELAT-1K8 succORDINAL1K1 A"
    assume "A inTARSKIR2 domRELAT-1K1 fif0"
    then have A6: "succORDINAL1K1 A c=ORDINAL1R1 domRELAT-1K1 fif0"
      using ordinal1_th_21 sorry
    have A7: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies ?fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,?fi .FUNCT-1K1 C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies (fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,(fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C)"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A8: "succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A"
        have "C inTARSKIR2 succORDINAL1K1 C"
          using ordinal1_th_6 sorry
        then have A9: "?fi .FUNCT-1K1 C =XBOOLE-0R4 fif0 .FUNCT-1K1 C"
          using A8 funct_1_th_49 ordinal1_th_10 sorry
        have "?fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fif0 .FUNCT-1K1 succORDINAL1K1 C"
          using A8 funct_1_th_49 sorry
        thus "(fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,(fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C)"
          using A2 A4 A6 A8 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies ?fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,?fi  |RELAT-1K8 C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 succORDINAL1K1 A & (C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4) implies (fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C =XBOOLE-0R4 Df2(C,(fif0  |RELAT-1K8 succORDINAL1K1 A) |RELAT-1K8 C)"
      proof(rule ballI,rule impMI ,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A11: "C inTARSKIR2 succORDINAL1K1 A"
          and A12: "C <>HIDDENR2 0ORDINAL1K5 & C be limit-ordinalORDINAL1V4"
        have "C c=ORDINAL1R1 succORDINAL1K1 A"
          using A11 ordinal1_def_2 sorry
        then have A13: "?fi  |RELAT-1K8 C =FUNCT-1R1 fif0  |RELAT-1K8 C"
          using funct_1_th_51 sorry
        have "?fi .FUNCT-1K1 C =XBOOLE-0R4 fif0 .FUNCT-1K1 C"
          using A11 funct_1_th_49 sorry
        thus "(fif0  |RELAT-1K8 succORDINAL1K1 A).FUNCT-1K1 C =XBOOLE-0R4 Df2(C,(fif0  |RELAT-1K8 succORDINAL1K1 A) |RELAT-1K8 C)"
          using A2 A5 A6 A11 A12 A13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "0ORDINAL1K5 c=ORDINAL1R1 succORDINAL1K1 A"
       sorry
    then have "0ORDINAL1K5 c<XBOOLE-0R2 succORDINAL1K1 A"
       sorry
    then have A14: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 A & ?fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 fif0 .FUNCT-1K1 (0ORDINAL1K5)"
      using funct_1_th_49 ordinal1_th_11 sorry
    have A15: "domRELAT-1K1 ?fi =XBOOLE-0R4 succORDINAL1K1 A"
      using A6 relat_1_th_62 sorry
    then have "A inTARSKIR2 succORDINAL1K1 A & lastORDINAL2K1 ?fi =XBOOLE-0R4 ?fi .FUNCT-1K1 A"
      using ordinal2_th_2 ordinal1_th_21 sorry
    then have "lastORDINAL2K1 ?fi =XBOOLE-0R4 fif0 .FUNCT-1K1 A"
      using funct_1_th_49 sorry
    thus "fif0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
      using A1 A2 A3 A6 A15 A14 A7 A10 sorry
  qed "sorry"

theorem ordinal2_sch_13:
  fixes Af0 Bf0 Cf2 Df2 
  assumes
[ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3"
  shows "( ex A be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((A =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
  proof-
    have "( ex A be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((A =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex L1 be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 L1 & domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0) & L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C))) implies (( ex L2 be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 L2 & domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0) & L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI,rule impI)
      obtain fi where
        [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
        A1: "((domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0 & (0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))"
        using ordinal2_sch_11 sorry
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = lastORDINAL2K1 fi"
         sorry
      show " ex A be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((A =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C))"
      proof-
        have " ex tVar20 be OrdinalORDINAL1M3 st  ex tVar21 be Ordinal-SequenceORDINAL2M1 st (tVar20 =XBOOLE-0R4 lastORDINAL2K1 tVar21 & domRELAT-1K1 tVar21 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar21 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar21 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar21 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar21 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar21  |RELAT-1K8 C))))"
        proof-
          show " ex tVar20 be OrdinalORDINAL1M3 st  ex tVar21 be Ordinal-SequenceORDINAL2M1 st (tVar20 =XBOOLE-0R4 lastORDINAL2K1 tVar21 & domRELAT-1K1 tVar21 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar21 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar21 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar21 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar21 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar21  |RELAT-1K8 C))))"
          proof(rule bexI[of _ "A"])
            show " ex tVar21 be Ordinal-SequenceORDINAL2M1 st (A =XBOOLE-0R4 lastORDINAL2K1 tVar21 & domRELAT-1K1 tVar21 =XBOOLE-0R4 succORDINAL1K1 Af0) & ((tVar21 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not tVar21 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,tVar21 .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not tVar21 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,tVar21  |RELAT-1K8 C))))"
            proof(rule bexI[of _ "fi"],rule conjMI)
              show "A =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0"
                using A1 sorry
              have "0ORDINAL1K5 c=ORDINAL1R1 succORDINAL1K1 Af0"
                 sorry
              then have "0ORDINAL1K5 c<XBOOLE-0R2 succORDINAL1K1 Af0"
                 sorry
              thus "(fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0 & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 Af0 &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))"
                using A1 ordinal1_th_11 sorry
            qed "sorry"
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      let ?CD = "\<lambda>Lamb1. \<lambda>Lamb2. Cf2(Lamb1,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 Lamb2}))"
      fix A1 assume [ty]: "A1 be OrdinalORDINAL1M3"
      fix A2 assume [ty]: "A2 be OrdinalORDINAL1M3"
      assume Given: " ex L1 be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 L1 & domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0) & L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C))"
      then obtain L1 where
        [ty]:"L1 be Ordinal-SequenceORDINAL2M1" and 
        A2: "A1 =XBOOLE-0R4 lastORDINAL2K1 L1"and A3: "domRELAT-1K1 L1 =XBOOLE-0R4 succORDINAL1K1 Af0"and A4: "L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A5: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L1 .FUNCT-1K1 C)"and A6: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C)"
         sorry
      have A7: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"
        using A4 sorry
      have A8: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?CD(C,L1 .FUNCT-1K1 C)"
      proof-
        have " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L1 .FUNCT-1K1 C }))"
        proof(rule ballI,rule impI)
          fix C assume [ty]: "C be OrdinalORDINAL1M3"
          assume A9: "succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0"
          obtain x9 where 
            [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = L1 .FUNCT-1K1 C"
             sorry
          have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L1 .FUNCT-1K1 C }) =HIDDENR1 supORDINAL2K3 x9"
            using zfmisc_1_th_25 sorry
          also have "... = x9"
            using ordinal2_th_18 sorry
          finally have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L1 .FUNCT-1K1 C }) =HIDDENR1 x9"
             sorry
          thus "L1 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L1 .FUNCT-1K1 C }))"
            using A5 A9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      assume Given: " ex L2 be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 L2 & domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0) & L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C))"
      then obtain L2 where
        [ty]:"L2 be Ordinal-SequenceORDINAL2M1" and 
        A10: "A2 =XBOOLE-0R4 lastORDINAL2K1 L2"and A11: "domRELAT-1K1 L2 =XBOOLE-0R4 succORDINAL1K1 Af0"and A12: "L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A13: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,L2 .FUNCT-1K1 C)"and A14: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C)"
         sorry
      have A15: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L2 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L2  |RELAT-1K8 C)"
        using A14 sorry
      have A16: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies L1 .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,L1  |RELAT-1K8 C)"
        using A6 sorry
      have A17: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?CD(C,L2 .FUNCT-1K1 C)"
      proof-
        have " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L2 .FUNCT-1K1 C }))"
        proof(rule ballI,rule impI)
          fix C assume [ty]: "C be OrdinalORDINAL1M3"
          assume A18: "succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0"
          obtain x9 where 
            [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = L2 .FUNCT-1K1 C"
             sorry
          have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L2 .FUNCT-1K1 C }) =HIDDENR1 supORDINAL2K3 x9"
            using zfmisc_1_th_25 sorry
          also have "... = x9"
            using ordinal2_th_18 sorry
          finally have "supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L2 .FUNCT-1K1 C }) =HIDDENR1 x9"
             sorry
          thus "L2 .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,supORDINAL2K3 (unionTARSKIK3 {TARSKIK1 L2 .FUNCT-1K1 C }))"
            using A13 A18 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A19: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies L2 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"
        using A12 sorry
      have "L1 =FUNCT-1R1 L2"
        using ordinal2_sch_4 A3 A7 A8 A16 A11 A19 A17 A15 sorry
      thus "A1 =XBOOLE-0R4 A2"
        using A2 A10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

theorem ordinal2_sch_14:
  fixes Ff1 Bf0 Cf2 Df2 
  assumes
[ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3" and
   A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))"
  shows "Ff1(0ORDINAL1K5) =XBOOLE-0R4 Bf0"
  proof-
    obtain fi where
      [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
      A2: "((domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5) & (0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0)) & ( for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) implies fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Cf2(A,fi .FUNCT-1K1 A))) & ( for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 succORDINAL1K1 (0ORDINAL1K5) & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 A =XBOOLE-0R4 Df2(A,fi  |RELAT-1K8 A))"
      using ordinal2_sch_11 sorry
    have "Bf0 =XBOOLE-0R4 lastORDINAL2K1 fi"
      using A2 ordinal2_th_2 ordinal1_th_6 sorry
    thus "Ff1(0ORDINAL1K5) =XBOOLE-0R4 Bf0"
      using A1 A2 ordinal1_th_6 sorry
  qed

theorem ordinal2_sch_15:
  fixes Bf0 Cf2 Df2 Ff1 
  assumes
[ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be OrdinalORDINAL1M3" and
   A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))"
  shows " for A be OrdinalORDINAL1M3 holds Ff1(succORDINAL1K1 A) =XBOOLE-0R4 Cf2(A,Ff1(A))"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    obtain fi where
      [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
      A2: "domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 (succORDINAL1K1 A)"and A3: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A4: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C)"and A5: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A) & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)"
      using ordinal2_sch_11 sorry
    have A6: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))"
      using A1 sorry
    have A7: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 B =XBOOLE-0R4 Ff1(B)"
      using ordinal2_sch_12 A6 A2 A3 A4 A5 sorry
    then have A8: "fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Ff1(succORDINAL1K1 A)"
      using A2 ordinal1_th_6 sorry
    have "A inTARSKIR2 succORDINAL1K1 A & succORDINAL1K1 A inTARSKIR2 succORDINAL1K1 (succORDINAL1K1 A)"
      using ordinal1_th_6 sorry
    then have "fi .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
      using A2 A7 ordinal1_th_10 sorry
    thus "Ff1(succORDINAL1K1 A) =XBOOLE-0R4 Cf2(A,Ff1(A))"
      using A4 A8 ordinal1_th_6 sorry
  qed "sorry"

theorem ordinal2_sch_16:
  fixes fif0 Af0 Ff1 Bf0 Cf2 Df2 
  assumes
[ty]: "fif0 be Ordinal-SequenceORDINAL2M1" and
  [ty]: "Af0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1. x1 be OrdinalORDINAL1M3 \<Longrightarrow> Ff1(x1) be OrdinalORDINAL1M3" and
  [ty]: "Bf0 be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be OrdinalORDINAL1M3 \<Longrightarrow> Cf2(x1,x2) be OrdinalORDINAL1M3" and
  [ty_func]: "\<And> x1 x2. x1 be OrdinalORDINAL1M3 \<Longrightarrow> x2 be SequenceORDINAL1M4 \<Longrightarrow> Df2(x1,x2) be OrdinalORDINAL1M3" and
   A1: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))" and
   A2: "Af0 <>HIDDENR2 0ORDINAL1K5 & Af0 be limit-ordinalORDINAL1V4" and
   A3: "domRELAT-1K1 fif0 =XBOOLE-0R4 Af0" and
   A4: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Af0 implies fif0 .FUNCT-1K1 A =XBOOLE-0R4 Ff1(A)"
  shows "Ff1(Af0) =XBOOLE-0R4 Df2(Af0,fif0)"
  proof-
    have A5: "Af0 inTARSKIR2 succORDINAL1K1 Af0"
      using ordinal1_th_6 sorry
    obtain fi where
      [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
      A6: "domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 Af0"and A7: "0ORDINAL1K5 inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0"and A8: " for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 Af0 implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C)"and A9: " for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 Af0 & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)"
      using ordinal2_sch_11 sorry
    let ?psi = "fi  |RELAT-1K8 Af0"
    have A10: " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B =XBOOLE-0R4 Ff1(A) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((B =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Bf0) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 Cf2(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 Df2(C,fi  |RELAT-1K8 C)))"
      using A1 sorry
    have A11: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 B =XBOOLE-0R4 Ff1(B)"
      using ordinal2_sch_12 A10 A6 A7 A8 A9 sorry
    have A12: " for x be objectHIDDENM1 holds x inHIDDENR3 Af0 implies (fi  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 fif0 .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A13: "x inHIDDENR3 Af0"
      then obtain x9 where 
        [ty]:"x9 be OrdinalORDINAL1M3" and x9Def:"x9 = x"
         sorry
      have "(fi  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 fi .FUNCT-1K1 x9"
        using A13 funct_1_th_49 sorry
      also have "... = Ff1(x9)"
        using A6 A11 A5 A13 ordinal1_th_10 sorry
      also have "... = fif0 .FUNCT-1K1 x"
        using A4 A13 sorry
      finally show "(fi  |RELAT-1K8 Af0).FUNCT-1K1 x =HIDDENR1 fif0 .FUNCT-1K1 x"
         sorry
    qed "sorry"
    have "Af0 c=ORDINAL1R1 domRELAT-1K1 fi"
      using A6 A5 ordinal1_def_2 sorry
    then have "domRELAT-1K1 ?psi =XBOOLE-0R4 Af0"
      using relat_1_th_62 sorry
    then have "?psi =FUNCT-1R1 fif0"
      using A3 A12 funct_1_th_2 sorry
    then have "fi .FUNCT-1K1 Af0 =XBOOLE-0R4 Df2(Af0,fif0)"
      using A2 A9 ordinal1_th_6 sorry
    thus "Ff1(Af0) =XBOOLE-0R4 Df2(Af0,fif0)"
      using A6 A11 ordinal1_th_6 sorry
  qed

mdef ordinal2_def_5 ("supORDINAL2K4  _ " [300]300 ) where
  mlet "L be SequenceORDINAL1M4"
"func supORDINAL2K4 L \<rightarrow> OrdinalORDINAL1M3 equals
  supORDINAL2K3 (rngFUNCT-1K2 L)"
proof-
  (*coherence*)
    show "supORDINAL2K3 (rngFUNCT-1K2 L) be OrdinalORDINAL1M3"
       sorry
qed "sorry"

mdef ordinal2_def_6 ("infORDINAL2K5  _ " [228]228 ) where
  mlet "L be SequenceORDINAL1M4"
"func infORDINAL2K5 L \<rightarrow> OrdinalORDINAL1M3 equals
  infORDINAL2K2 (rngFUNCT-1K2 L)"
proof-
  (*coherence*)
    show "infORDINAL2K2 (rngFUNCT-1K2 L) be OrdinalORDINAL1M3"
       sorry
qed "sorry"

mtheorem ordinal2_th_26:
" for L be SequenceORDINAL1M4 holds supORDINAL2K4 L =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 L) & infORDINAL2K5 L =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 L)"
   sorry

mdef ordinal2_def_7 ("lim-supORDINAL2K6  _ " [228]228 ) where
  mlet "L be SequenceORDINAL1M4"
"func lim-supORDINAL2K6 L \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex fi be Ordinal-SequenceORDINAL2M1 st (it =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (it =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
    proof-
      have " ex tVar22 be OrdinalORDINAL1M3 st  ex tVar23 be Ordinal-SequenceORDINAL2M1 st (infORDINAL2K5 tVar23 =XBOOLE-0R4 infORDINAL2K5 tVar23 & domRELAT-1K1 tVar23 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar23 .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
      proof-
        let ?F = "\<lambda>Lamb1. supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 Lamb1)))"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A1: "domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 ?F(A))"
          using ordinal2_sch_3 sorry
        show " ex tVar22 be OrdinalORDINAL1M3 st  ex tVar23 be Ordinal-SequenceORDINAL2M1 st (infORDINAL2K5 tVar23 =XBOOLE-0R4 infORDINAL2K5 tVar23 & domRELAT-1K1 tVar23 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar23 .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
        proof(rule bexI[of _ "infORDINAL2K5 fi"])
          show " ex tVar23 be Ordinal-SequenceORDINAL2M1 st (infORDINAL2K5 tVar23 =XBOOLE-0R4 infORDINAL2K5 tVar23 & domRELAT-1K1 tVar23 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar23 .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
          proof(rule bexI[of _ "fi"])
            show "(infORDINAL2K5 fi =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
              using A1 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (it1 =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (it2 =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (A1 =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies (( ex psi be Ordinal-SequenceORDINAL2M1 st (A2 =XBOOLE-0R4 infORDINAL2K5 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies A1 =HIDDENR1 A2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix A1 assume [ty]: "A1 be OrdinalORDINAL1M3"
        fix A2 assume [ty]: "A2 be OrdinalORDINAL1M3"
        assume Given: " ex fi be Ordinal-SequenceORDINAL2M1 st (A1 =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
        then obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A2: "A1 =XBOOLE-0R4 infORDINAL2K5 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L"and A3: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
           sorry
        assume Given: " ex psi be Ordinal-SequenceORDINAL2M1 st (A2 =XBOOLE-0R4 infORDINAL2K5 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
        then obtain psi where
          [ty]:"psi be Ordinal-SequenceORDINAL2M1" and 
          A4: "A2 =XBOOLE-0R4 infORDINAL2K5 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L"and A5: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
           sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 L implies fi .FUNCT-1K1 x =XBOOLE-0R4 psi .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A6: "x inHIDDENR3 domRELAT-1K1 L"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "fi .FUNCT-1K1 A =XBOOLE-0R4 supORDINAL2K3 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
            using A3 A6 sorry
          thus "fi .FUNCT-1K1 x =XBOOLE-0R4 psi .FUNCT-1K1 x"
            using A5 A6 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using A2 A4 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal2_def_8 ("lim-infORDINAL2K7  _ " [228]228 ) where
  mlet "L be SequenceORDINAL1M4"
"func lim-infORDINAL2K7 L \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex fi be Ordinal-SequenceORDINAL2M1 st (it =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (it =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
    proof-
      have " ex tVar24 be OrdinalORDINAL1M3 st  ex tVar25 be Ordinal-SequenceORDINAL2M1 st (supORDINAL2K4 tVar25 =XBOOLE-0R4 supORDINAL2K4 tVar25 & domRELAT-1K1 tVar25 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar25 .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
      proof-
        let ?F = "\<lambda>Lamb1. infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 Lamb1)))"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A7: "domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 ?F(A))"
          using ordinal2_sch_3 sorry
        show " ex tVar24 be OrdinalORDINAL1M3 st  ex tVar25 be Ordinal-SequenceORDINAL2M1 st (supORDINAL2K4 tVar25 =XBOOLE-0R4 supORDINAL2K4 tVar25 & domRELAT-1K1 tVar25 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar25 .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
        proof(rule bexI[of _ "supORDINAL2K4 fi"])
          show " ex tVar25 be Ordinal-SequenceORDINAL2M1 st (supORDINAL2K4 tVar25 =XBOOLE-0R4 supORDINAL2K4 tVar25 & domRELAT-1K1 tVar25 =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not tVar25 .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
          proof(rule bexI[of _ "fi"])
            show "(supORDINAL2K4 fi =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 domRELAT-1K1 L &  not fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))))"
              using A7 sorry
          qed "sorry"
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (it1 =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (it2 =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (A1 =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies (( ex psi be Ordinal-SequenceORDINAL2M1 st (A2 =XBOOLE-0R4 supORDINAL2K4 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))) implies A1 =HIDDENR1 A2)"
      proof(rule ballI,rule ballI,rule impI,rule impI)
        fix A1 assume [ty]: "A1 be OrdinalORDINAL1M3"
        fix A2 assume [ty]: "A2 be OrdinalORDINAL1M3"
        assume Given: " ex fi be Ordinal-SequenceORDINAL2M1 st (A1 =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
        then obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A8: "A1 =XBOOLE-0R4 supORDINAL2K4 fi & domRELAT-1K1 fi =XBOOLE-0R4 domRELAT-1K1 L"and A9: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
           sorry
        assume Given: " ex psi be Ordinal-SequenceORDINAL2M1 st (A2 =XBOOLE-0R4 supORDINAL2K4 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L) & ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A))))"
        then obtain psi where
          [ty]:"psi be Ordinal-SequenceORDINAL2M1" and 
          A10: "A2 =XBOOLE-0R4 supORDINAL2K4 psi & domRELAT-1K1 psi =XBOOLE-0R4 domRELAT-1K1 L"and A11: " for A be OrdinalORDINAL1M3 holds A inTARSKIR2 domRELAT-1K1 L implies psi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
           sorry
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 L implies fi .FUNCT-1K1 x =XBOOLE-0R4 psi .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A12: "x inHIDDENR3 domRELAT-1K1 L"
          then obtain A where 
            [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
             sorry
          have "fi .FUNCT-1K1 A =XBOOLE-0R4 infORDINAL2K2 (rngFUNCT-1K2 (L  |RELAT-1K8 (domRELAT-1K1 L \\SUBSET-1K6 A)))"
            using A9 A12 sorry
          thus "fi .FUNCT-1K1 x =XBOOLE-0R4 psi .FUNCT-1K1 x"
            using A11 A12 sorry
        qed "sorry"
        thus "A1 =HIDDENR1 A2"
          using A8 A10 funct_1_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal2_def_9 (" _ is-limes-ofORDINAL2R1  _ " [50,50]50 ) where
  mlet "A be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"pred A is-limes-ofORDINAL2R1 fi means
   ex B be OrdinalORDINAL1M3 st B inTARSKIR2 domRELAT-1K1 fi & ( for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5) if A =XBOOLE-0R4 0ORDINAL1K5 otherwise  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 A & A inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C))"
proof-
  (*consistency*)
    show " True "
       sorry
qed "sorry"

mdef ordinal2_def_10 ("limORDINAL2K8  _ " [164]164 ) where
  mlet "fi be Ordinal-SequenceORDINAL2M1"
"assume  ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi func limORDINAL2K8 fi \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it. it is-limes-ofORDINAL2R1 fi"
proof-
  (*existence*)
    show "( ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi) implies ( ex it be OrdinalORDINAL1M3 st it is-limes-ofORDINAL2R1 fi)"
    proof(rule impI)
      assume Assume: " ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi"
      have Given: " ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi"
        using Assume sorry
      then obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A1: "A is-limes-ofORDINAL2R1 fi"
         sorry
      show " ex it be OrdinalORDINAL1M3 st it is-limes-ofORDINAL2R1 fi"
        using A1 sorry
    qed
  (*uniqueness*)
    show "( ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi) implies ( for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds it1 is-limes-ofORDINAL2R1 fi & it2 is-limes-ofORDINAL2R1 fi implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: " ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi"
      have Given: " ex A be OrdinalORDINAL1M3 st A is-limes-ofORDINAL2R1 fi"
        using Assume sorry
      then obtain A where
        [ty]:"A be OrdinalORDINAL1M3" and 
        A1: "A is-limes-ofORDINAL2R1 fi"
         sorry
      show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds it1 is-limes-ofORDINAL2R1 fi & it2 is-limes-ofORDINAL2R1 fi implies it1 =HIDDENR1 it2"
      proof-
        have " for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds  not ((A1 is-limes-ofORDINAL2R1 fi & A2 is-limes-ofORDINAL2R1 fi) &  not A1 =HIDDENR1 A2)"
        proof(rule ballI,rule ballI)
          fix A1 assume [ty]: "A1 be OrdinalORDINAL1M3"
          fix A2 assume [ty]: "A2 be OrdinalORDINAL1M3"
          have "(A1 =XBOOLE-0R4 0ORDINAL1K5 & ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 domRELAT-1K1 fi & ( for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5)) or A1 <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 A1 & A1 inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)))) & (A2 =XBOOLE-0R4 0ORDINAL1K5 & ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 domRELAT-1K1 fi & ( for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5)) or A2 <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 A2 & A2 inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)))) implies (A1 <>HIDDENR2 A2 implies  False )"
          proof(rule impMI ,rule impI,rule impI)
            assume A2: "A1 =XBOOLE-0R4 0ORDINAL1K5 & ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 domRELAT-1K1 fi & ( for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5)) or A1 <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 A1 & A1 inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)))"
              and A3: "A2 =XBOOLE-0R4 0ORDINAL1K5 & ( ex B be OrdinalORDINAL1M3 st B inTARSKIR2 domRELAT-1K1 fi & ( for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5)) or A2 <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 A2 & A2 inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)))"
            have A4: "A1 inTARSKIR2 A2 implies  False "
            proof(rule impI)
              let ?x = "the ElementSUBSET-1M1-of A1"
              obtain x where 
                [ty]:"x be OrdinalORDINAL1M3" and xDef:"x = ?x"
                 sorry
              assume "A1 inTARSKIR2 A2"
              then obtain D where
                [ty]:"D be OrdinalORDINAL1M3" and 
                A5: "D inTARSKIR2 domRELAT-1K1 fi"and A6: " for A be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 A & A inTARSKIR2 domRELAT-1K1 fi implies A1 inTARSKIR2 fi .FUNCT-1K1 A & fi .FUNCT-1K1 A inTARSKIR2 succORDINAL1K1 A2"
                using A3 ordinal1_th_6 sorry
              have "A1 =XBOOLE-0R4 0ORDINAL1K5 implies  False "
              proof(rule impI)
                assume "A1 =XBOOLE-0R4 0ORDINAL1K5"
                then obtain B where
                  [ty]:"B be OrdinalORDINAL1M3" and 
                  A7: "B inTARSKIR2 domRELAT-1K1 fi"and A8: " for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5"
                  using A2 sorry
                have "B c=ORDINAL1R1 D or D c=ORDINAL1R1 B"
                   sorry
                then obtain E where
                  [ty]:"E be OrdinalORDINAL1M3" and 
                  A9: "E =XBOOLE-0R4 D & B c=ORDINAL1R1 D or E =XBOOLE-0R4 B & D c=ORDINAL1R1 B"
                   sorry
                have "fi .FUNCT-1K1 E =XBOOLE-0R4 0ORDINAL1K5"
                  using A5 A7 A8 A9 sorry
                thus " False "
                  using A5 A6 A7 A9 sorry
              qed
              then obtain C where
                [ty]:"C be OrdinalORDINAL1M3" and 
                A10: "C inTARSKIR2 domRELAT-1K1 fi"and A11: " for A be OrdinalORDINAL1M3 holds C c=ORDINAL1R1 A & A inTARSKIR2 domRELAT-1K1 fi implies x inTARSKIR2 fi .FUNCT-1K1 A & fi .FUNCT-1K1 A inTARSKIR2 succORDINAL1K1 A1"
                using A2 ordinal1_th_6 sorry
              have "C c=ORDINAL1R1 D or D c=ORDINAL1R1 C"
                 sorry
              then obtain E where
                [ty]:"E be OrdinalORDINAL1M3" and 
                A12: "E =XBOOLE-0R4 D & C c=ORDINAL1R1 D or E =XBOOLE-0R4 C & D c=ORDINAL1R1 C"
                 sorry
              have "fi .FUNCT-1K1 E inTARSKIR2 succORDINAL1K1 A1"
                using A5 A10 A11 A12 sorry
              then have A13: "fi .FUNCT-1K1 E inTARSKIR2 A1 or fi .FUNCT-1K1 E =XBOOLE-0R4 A1"
                using ordinal1_th_8 sorry
              have "A1 inTARSKIR2 fi .FUNCT-1K1 E"
                using A5 A6 A10 A12 sorry
              thus " False "
                using A13 sorry
            qed
            let ?x = "the ElementSUBSET-1M1-of A2"
            obtain x where 
              [ty]:"x be OrdinalORDINAL1M3" and xDef:"x = ?x"
               sorry
            assume "A1 <>HIDDENR2 A2"
            then have "A1 inTARSKIR2 A2 or A2 inTARSKIR2 A1"
              using ordinal1_th_14 sorry
            then obtain D where
              [ty]:"D be OrdinalORDINAL1M3" and 
              A14: "D inTARSKIR2 domRELAT-1K1 fi"and A15: " for A be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 A & A inTARSKIR2 domRELAT-1K1 fi implies A2 inTARSKIR2 fi .FUNCT-1K1 A & fi .FUNCT-1K1 A inTARSKIR2 succORDINAL1K1 A1"
              using A2 A4 ordinal1_th_6 sorry
            have "A2 =XBOOLE-0R4 0ORDINAL1K5 implies  False "
            proof(rule impI)
              assume "A2 =XBOOLE-0R4 0ORDINAL1K5"
              then obtain B where
                [ty]:"B be OrdinalORDINAL1M3" and 
                A16: "B inTARSKIR2 domRELAT-1K1 fi"and A17: " for C be OrdinalORDINAL1M3 holds B c=ORDINAL1R1 C & C inTARSKIR2 domRELAT-1K1 fi implies fi .FUNCT-1K1 C =XBOOLE-0R4 0ORDINAL1K5"
                using A3 sorry
              have "B c=ORDINAL1R1 D or D c=ORDINAL1R1 B"
                 sorry
              then obtain E where
                [ty]:"E be OrdinalORDINAL1M3" and 
                A18: "E =XBOOLE-0R4 D & B c=ORDINAL1R1 D or E =XBOOLE-0R4 B & D c=ORDINAL1R1 B"
                 sorry
              have "fi .FUNCT-1K1 E =XBOOLE-0R4 0ORDINAL1K5"
                using A14 A16 A17 A18 sorry
              thus " False "
                using A14 A15 A16 A18 sorry
            qed
            then obtain C where
              [ty]:"C be OrdinalORDINAL1M3" and 
              A19: "C inTARSKIR2 domRELAT-1K1 fi"and A20: " for A be OrdinalORDINAL1M3 holds C c=ORDINAL1R1 A & A inTARSKIR2 domRELAT-1K1 fi implies x inTARSKIR2 fi .FUNCT-1K1 A & fi .FUNCT-1K1 A inTARSKIR2 succORDINAL1K1 A2"
              using A3 ordinal1_th_6 sorry
            have "C c=ORDINAL1R1 D or D c=ORDINAL1R1 C"
               sorry
            then obtain E where
              [ty]:"E be OrdinalORDINAL1M3" and 
              A21: "E =XBOOLE-0R4 D & C c=ORDINAL1R1 D or E =XBOOLE-0R4 C & D c=ORDINAL1R1 C"
               sorry
            have "fi .FUNCT-1K1 E inTARSKIR2 succORDINAL1K1 A2"
              using A14 A19 A20 A21 sorry
            then have A22: "fi .FUNCT-1K1 E inTARSKIR2 A2 or fi .FUNCT-1K1 E =XBOOLE-0R4 A2"
              using ordinal1_th_8 sorry
            have "A2 inTARSKIR2 fi .FUNCT-1K1 E"
              using A14 A15 A19 A21 sorry
            thus " False "
              using A22 sorry
          qed
          thus " not ((A1 is-limes-ofORDINAL2R1 fi & A2 is-limes-ofORDINAL2R1 fi) &  not A1 =HIDDENR1 A2)"
            using ordinal2_def_9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef ordinal2_def_11 ("limORDINAL2K9'( _ , _ ')" [0,0]164 ) where
  mlet "A be OrdinalORDINAL1M3", "fi be Ordinal-SequenceORDINAL2M1"
"func limORDINAL2K9(A,fi) \<rightarrow> OrdinalORDINAL1M3 equals
  limORDINAL2K8 fi  |RELAT-1K8 A"
proof-
  (*coherence*)
    show "limORDINAL2K8 fi  |RELAT-1K8 A be OrdinalORDINAL1M3"
       sorry
qed "sorry"

mdef ordinal2_def_12 ("increasingORDINAL2V2" 70 ) where
"attr increasingORDINAL2V2 for Ordinal-SequenceORDINAL2M1 means
  (\<lambda>L.  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B & B inTARSKIR2 domRELAT-1K1 L implies L .FUNCT-1K1 A inTARSKIR2 L .FUNCT-1K1 B)"..

mdef ordinal2_def_13 ("continuousORDINAL2V3" 70 ) where
"attr continuousORDINAL2V3 for Ordinal-SequenceORDINAL2M1 means
  (\<lambda>L.  for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds ((A inTARSKIR2 domRELAT-1K1 L & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4) & B =XBOOLE-0R4 L .FUNCT-1K1 A implies B is-limes-ofORDINAL2R1 L  |RELAT-1K8 A)"..

mdef ordinal2_def_14 (" _ +^ORDINAL2K10  _ " [132,132]132 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func A +^ORDINAL2K10 B \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. succORDINAL1K1 Lamb2"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. succORDINAL1K1 Lamb2"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 succORDINAL1K1 (fi .FUNCT-1K1 C)))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef ordinal2_def_15 (" _ *^ORDINAL2K11  _ " [164,164]164 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func A *^ORDINAL2K11 B \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 +^ORDINAL2K10 B"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 +^ORDINAL2K10 B"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C))))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 A) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 fi .FUNCT-1K1 C +^ORDINAL2K10 B))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 A &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 (fi  |RELAT-1K8 C)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ordinal2_cl_6:
  mlet "O be OrdinalORDINAL1M3"
"cluster note-that ordinalORDINAL1V3 for ElementSUBSET-1M1-of O"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of O holds it be ordinalORDINAL1V3"
     sorry
qed "sorry"

mdef ordinal2_def_16 ("expORDINAL2K12'( _ , _ ')" [0,0]164 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"func expORDINAL2K12(A,B) \<rightarrow> OrdinalORDINAL1M3 means
  \<lambda>it.  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)"
proof-
  (*existence*)
    show " ex it be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((it =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. limORDINAL2K8 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. A *^ORDINAL2K11 Lamb2"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be OrdinalORDINAL1M3 holds  for it2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C)) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. limORDINAL2K8 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. A *^ORDINAL2K11 Lamb2"
        have "( ex F be OrdinalORDINAL1M3 st  ex fi be Ordinal-SequenceORDINAL2M1 st (((F =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( for A1 be OrdinalORDINAL1M3 holds  for A2 be OrdinalORDINAL1M3 holds ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) & ( ex fi be Ordinal-SequenceORDINAL2M1 st (((A2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C))) implies A1 =XBOOLE-0R4 A2)"
          using ordinal2_sch_13 sorry
        thus " not ( for VarFor1 be OrdinalORDINAL1M3 holds  for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) & ( for VarFor1 be OrdinalORDINAL1M3 holds  for VarFor2 be OrdinalORDINAL1M3 holds  not (( not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C)))) &  not ( for fi be Ordinal-SequenceORDINAL2M1 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B &  not fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 A *^ORDINAL2K11 fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds  not (((C inTARSKIR2 succORDINAL1K1 B &  not C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4) &  not fi .FUNCT-1K1 C =XBOOLE-0R4 limORDINAL2K8 fi  |RELAT-1K8 C))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem ordinal2_th_27:
" for A be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. succORDINAL1K1 Lamb2"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. supORDINAL2K4 Lamb2"
    let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_14 sorry
    show "A +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 A"
      using ordinal2_sch_14 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_28:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 succORDINAL1K1 B =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 B)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 succORDINAL1K1 B =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. succORDINAL1K1 Lamb2"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. supORDINAL2K4 Lamb2"
    let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_14 sorry
    have " for B be OrdinalORDINAL1M3 holds ?F(succORDINAL1K1 B) =XBOOLE-0R4 ?C(B,?F(B))"
      using ordinal2_sch_15 A1 sorry
    thus "A +^ORDINAL2K10 succORDINAL1K1 B =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_29:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 A +^ORDINAL2K10 C) implies A +^ORDINAL2K10 B =XBOOLE-0R4 supORDINAL2K4 fi)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 A +^ORDINAL2K10 C) implies A +^ORDINAL2K10 B =XBOOLE-0R4 supORDINAL2K4 fi)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. succORDINAL1K1 Lamb2"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. supORDINAL2K4 Lamb2"
    assume A1: "B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4"
    let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    assume A2: "domRELAT-1K1 fi =XBOOLE-0R4 B"
      and A3: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?F(C)"
    have A4: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 A) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_14 sorry
    show "A +^ORDINAL2K10 B =XBOOLE-0R4 supORDINAL2K4 fi"
      using ordinal2_sch_16 A4 A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_30:
" for A be OrdinalORDINAL1M3 holds 0ORDINAL1K5 +^ORDINAL2K10 A =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds 0ORDINAL1K5 +^ORDINAL2K10 A =XBOOLE-0R4 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. 0ORDINAL1K5 +^ORDINAL2K10 Lamb1 =XBOOLE-0R4 Lamb1"
    have A1: " for A be OrdinalORDINAL1M3 holds ?P(A) implies ?P(succORDINAL1K1 A)"
      using ordinal2_th_28 sorry
    have A2: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies 0ORDINAL1K5 +^ORDINAL2K10 B =XBOOLE-0R4 B) implies 0ORDINAL1K5 +^ORDINAL2K10 A =XBOOLE-0R4 A"
      proof(rule ballI,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. 0ORDINAL1K5 +^ORDINAL2K10 Lamb1"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: "A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4"
          and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies 0ORDINAL1K5 +^ORDINAL2K10 B =XBOOLE-0R4 B"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A5: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies fi .FUNCT-1K1 B =XBOOLE-0R4 ?F(B))"
          using ordinal2_sch_3 sorry
        have A6: "rngFUNCT-1K2 fi =XBOOLE-0R4 A"
        proof-
          have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 A) & A c=TARSKIR1 rngFUNCT-1K2 fi"
          proof(rule conjMI)
            show " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 A"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 fi"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A7: "y inHIDDENR3 domRELAT-1K1 fi"and A8: "x =HIDDENR1 fi .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be OrdinalORDINAL1M3"
                using A7 sorry
              have "x =HIDDENR1 0ORDINAL1K5 +^ORDINAL2K10 y"
                using A5 A7 A8 sorry
              also have "... = y"
                using A4 A5 A7 sorry
              finally have "x =HIDDENR1 y"
                 sorry
              thus "x inHIDDENR3 A"
                using A5 A7 sorry
            qed "sorry"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 rngFUNCT-1K2 fi"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume A9: "x inHIDDENR3 A"
              then obtain B where 
                [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
                 sorry
              have "0ORDINAL1K5 +^ORDINAL2K10 B =XBOOLE-0R4 B & fi .FUNCT-1K1 B =XBOOLE-0R4 0ORDINAL1K5 +^ORDINAL2K10 B"
                using A4 A5 A9 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 fi"
                using A5 A9 funct_1_def_3 sorry
            qed "sorry"
            thus "A c=TARSKIR1 rngFUNCT-1K2 fi"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 fi =XBOOLE-0R4 A"
            using tarski_def_3 xboole_0_def_10 sorry
        qed
        have "0ORDINAL1K5 +^ORDINAL2K10 A =HIDDENR1 supORDINAL2K4 fi"
          using A3 A5 ordinal2_th_29 sorry
        also have "... = supORDINAL2K3 (rngFUNCT-1K2 fi)"
           sorry
        finally have "0ORDINAL1K5 +^ORDINAL2K10 A =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 fi)"
           sorry
        thus "0ORDINAL1K5 +^ORDINAL2K10 A =XBOOLE-0R4 A"
          using A6 ordinal2_th_18 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "?P(0ORDINAL1K5)"
      using ordinal2_th_27 sorry
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A10 A1 A2 sorry
    thus "0ORDINAL1K5 +^ORDINAL2K10 A =XBOOLE-0R4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma ordinal2_lm_1:
"\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
   sorry

mtheorem ordinal2_th_31:
" for A be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 \<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds A +^ORDINAL2K10 \<one>\<^sub>M =HIDDENR1 succORDINAL1K1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "A +^ORDINAL2K10 \<one>\<^sub>M =HIDDENR1 succORDINAL1K1 (A +^ORDINAL2K10 0ORDINAL1K5)"
      using ordinal2_lm_1 ordinal2_th_28 sorry
    also have "... = succORDINAL1K1 A"
      using ordinal2_th_27 sorry
    finally show "A +^ORDINAL2K10 \<one>\<^sub>M =HIDDENR1 succORDINAL1K1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_32:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds  not (A inTARSKIR2 B &  not C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B)"
  proof(rule ballI,rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. A inTARSKIR2 Lamb1 implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 Lamb1"
    have A1: " for B be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies ?P(D)) implies ?P(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies (A inTARSKIR2 D implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 D)) & A inTARSKIR2 B implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
      proof(rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies (A inTARSKIR2 D implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 D)"
          and A3: "A inTARSKIR2 B"
        have A4: "( ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 D) implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
        proof(rule impI)
          assume Given: " ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 D"
          then obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A5: "B =XBOOLE-0R4 succORDINAL1K1 D"
             sorry
          have A6: "A inTARSKIR2 D implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
          proof(rule impI)
            assume "A inTARSKIR2 D"
            then have A7: "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 D"
              using A2 A5 ordinal1_th_6 sorry
            have "succORDINAL1K1 (C +^ORDINAL2K10 D) =XBOOLE-0R4 C +^ORDINAL2K10 succORDINAL1K1 D & C +^ORDINAL2K10 D inTARSKIR2 succORDINAL1K1 (C +^ORDINAL2K10 D)"
              using ordinal2_th_28 ordinal1_th_6 sorry
            thus "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
              using A5 A7 ordinal1_th_10 sorry
          qed
          have " not A inTARSKIR2 D implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
          proof(rule impI)
            assume A8: " not A inTARSKIR2 D"
            have "A c<XBOOLE-0R2 D iff A c=ORDINAL1R1 D & A <>HIDDENR2 D"
               sorry
            then have "C +^ORDINAL2K10 A inTARSKIR2 succORDINAL1K1 (C +^ORDINAL2K10 D)"
              using A3 A5 A8 ordinal1_th_11 ordinal1_th_22 sorry
            thus "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
              using A5 ordinal2_th_28 sorry
          qed
          thus "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
            using A6 sorry
        qed
        have "( for D be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 D) implies C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
        proof(rule impI)
          let ?F = "\<lambda>Lamb1. C +^ORDINAL2K10 Lamb1"
          obtain fi where
            [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
            A9: "domRELAT-1K1 fi =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
            using ordinal2_sch_3 sorry
          have "fi .FUNCT-1K1 A =XBOOLE-0R4 C +^ORDINAL2K10 A"
            using A3 A9 sorry
          then have A10: "C +^ORDINAL2K10 A inTARSKIR2 rngFUNCT-1K2 fi"
            using A3 A9 funct_1_def_3 sorry
          assume " for D be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 D"
          then have "B be limit-ordinalORDINAL1V4"
            using ordinal1_th_29 sorry
          then have "C +^ORDINAL2K10 B =HIDDENR1 supORDINAL2K4 fi"
            using A3 A9 ordinal2_th_29 sorry
          also have "... = supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          finally have "C +^ORDINAL2K10 B =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          thus "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
            using A10 ordinal2_th_19 sorry
        qed
        thus "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
          using A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal1_sch_2 A1 sorry
    thus " not (A inTARSKIR2 B &  not C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_33:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C +^ORDINAL2K10 A c=ORDINAL1R1 C +^ORDINAL2K10 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C +^ORDINAL2K10 A c=ORDINAL1R1 C +^ORDINAL2K10 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
    have "A <>HIDDENR2 B implies C +^ORDINAL2K10 A c=ORDINAL1R1 C +^ORDINAL2K10 B"
    proof(rule impI)
      assume "A <>HIDDENR2 B"
      then have "A c<XBOOLE-0R2 B"
        using A1 sorry
      then have "C +^ORDINAL2K10 A inTARSKIR2 C +^ORDINAL2K10 B"
        using ordinal2_th_32 ordinal1_th_11 sorry
      thus "C +^ORDINAL2K10 A c=ORDINAL1R1 C +^ORDINAL2K10 B"
        using ordinal1_def_2 sorry
    qed
    thus "C +^ORDINAL2K10 A c=ORDINAL1R1 C +^ORDINAL2K10 B"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_34:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1 c=ORDINAL1R1 B +^ORDINAL2K10 Lamb1"
    assume A1: "A c=ORDINAL1R1 B"
    have A2: " for C be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies ?P(D)) implies ?P(C)"
    proof-
      have " for C be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies A +^ORDINAL2K10 D c=ORDINAL1R1 B +^ORDINAL2K10 D) implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
      proof(rule ballI,rule impI)
        fix C assume [ty]: "C be OrdinalORDINAL1M3"
        assume A3: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies A +^ORDINAL2K10 D c=ORDINAL1R1 B +^ORDINAL2K10 D"
        have A4: "( ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 succORDINAL1K1 D) implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
        proof(rule impI)
          assume Given: " ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 succORDINAL1K1 D"
          then obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A5: "C =XBOOLE-0R4 succORDINAL1K1 D"
             sorry
          have A6: "B +^ORDINAL2K10 C =XBOOLE-0R4 succORDINAL1K1 (B +^ORDINAL2K10 D)"
            using A5 ordinal2_th_28 sorry
          have "A +^ORDINAL2K10 D c=ORDINAL1R1 B +^ORDINAL2K10 D & A +^ORDINAL2K10 C =XBOOLE-0R4 succORDINAL1K1 (A +^ORDINAL2K10 D)"
            using A3 A5 ordinal2_th_28 ordinal1_th_6 sorry
          thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
            using A6 ordinal2_th_1 sorry
        qed
        have A7: "C <>HIDDENR2 0ORDINAL1K5 & ( for D be OrdinalORDINAL1M3 holds C <>HIDDENR2 succORDINAL1K1 D) implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
        proof(rule impMI ,rule impI)
          let ?F = "\<lambda>Lamb1. A +^ORDINAL2K10 Lamb1"
          assume A8: "C <>HIDDENR2 0ORDINAL1K5"
            and A9: " for D be OrdinalORDINAL1M3 holds C <>HIDDENR2 succORDINAL1K1 D"
          obtain fi where
            [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
            A10: "domRELAT-1K1 fi =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
            using ordinal2_sch_3 sorry
          have A11: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 rngFUNCT-1K2 fi implies D inTARSKIR2 B +^ORDINAL2K10 C"
          proof(rule ballI,rule impI)
            fix D assume [ty]: "D be OrdinalORDINAL1M3"
            assume "D inTARSKIR2 rngFUNCT-1K2 fi"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A12: "x inHIDDENR3 domRELAT-1K1 fi"and A13: "D =XBOOLE-0R4 fi .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have 
              [ty]:"x be OrdinalORDINAL1M3"
              using A12 sorry
            have A14: "B +^ORDINAL2K10 x inTARSKIR2 B +^ORDINAL2K10 C"
              using A10 A12 ordinal2_th_32 sorry
            have "D =XBOOLE-0R4 A +^ORDINAL2K10 x & A +^ORDINAL2K10 x c=ORDINAL1R1 B +^ORDINAL2K10 x"
              using A3 A10 A12 A13 sorry
            thus "D inTARSKIR2 B +^ORDINAL2K10 C"
              using A14 ordinal1_th_12 sorry
          qed "sorry"
          have "C be limit-ordinalORDINAL1V4"
            using A9 ordinal1_th_29 sorry
          then have "A +^ORDINAL2K10 C =HIDDENR1 supORDINAL2K4 fi"
            using A8 A10 ordinal2_th_29 sorry
          also have "... = supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          finally have "A +^ORDINAL2K10 C =HIDDENR1 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
            using A11 ordinal2_th_20 sorry
        qed
        have "C =XBOOLE-0R4 0ORDINAL1K5 implies A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
        proof(rule impI)
          assume A15: "C =XBOOLE-0R4 0ORDINAL1K5"
          then have "A +^ORDINAL2K10 C =XBOOLE-0R4 A"
            using ordinal2_th_27 sorry
          thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
            using A1 A15 ordinal2_th_27 sorry
        qed
        thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
          using A4 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for C be OrdinalORDINAL1M3 holds ?P(C)"
      using ordinal1_sch_2 A2 sorry
    thus "A +^ORDINAL2K10 C c=ORDINAL1R1 B +^ORDINAL2K10 C"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_35:
" for A be OrdinalORDINAL1M3 holds (0ORDINAL1K5)*^ORDINAL2K11 A =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for A be OrdinalORDINAL1M3 holds (0ORDINAL1K5)*^ORDINAL2K11 A =XBOOLE-0R4 0ORDINAL1K5"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 supORDINAL2K4 Lamb2"
    let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 A"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 +^ORDINAL2K10 A"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_15 sorry
    show "(0ORDINAL1K5)*^ORDINAL2K11 A =XBOOLE-0R4 0ORDINAL1K5"
      using ordinal2_sch_14 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_36:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B *^ORDINAL2K11 A =XBOOLE-0R4 B *^ORDINAL2K11 A +^ORDINAL2K10 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B *^ORDINAL2K11 A =XBOOLE-0R4 B *^ORDINAL2K11 A +^ORDINAL2K10 A"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 supORDINAL2K4 Lamb2"
    let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 A"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 +^ORDINAL2K10 A"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_15 sorry
    have " for B be OrdinalORDINAL1M3 holds ?F(succORDINAL1K1 B) =XBOOLE-0R4 ?C(B,?F(B))"
      using ordinal2_sch_15 A1 sorry
    thus "succORDINAL1K1 B *^ORDINAL2K11 A =XBOOLE-0R4 B *^ORDINAL2K11 A +^ORDINAL2K10 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_37:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 C *^ORDINAL2K11 A) implies B *^ORDINAL2K11 A =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 fi)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 C *^ORDINAL2K11 A) implies B *^ORDINAL2K11 A =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 fi)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. unionTARSKIK3 supORDINAL2K4 Lamb2"
    assume A1: "B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 +^ORDINAL2K10 A"
    let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 A"
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    assume A2: "domRELAT-1K1 fi =XBOOLE-0R4 B"
      and A3: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?F(C)"
    have A4: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_15 sorry
    show "B *^ORDINAL2K11 A =XBOOLE-0R4 unionTARSKIK3 supORDINAL2K4 fi"
      using ordinal2_sch_16 A4 A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_38:
" for A be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for A be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
    have A1: " for A be OrdinalORDINAL1M3 holds ?P(A) implies ?P(succORDINAL1K1 A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5 implies succORDINAL1K1 A *^ORDINAL2K11 (0ORDINAL1K5) =HIDDENR1 0ORDINAL1K5"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
        then have "succORDINAL1K1 A *^ORDINAL2K11 (0ORDINAL1K5) =HIDDENR1 0ORDINAL1K5 +^ORDINAL2K10 0ORDINAL1K5"
          using ordinal2_th_36 sorry
        also have "... = 0ORDINAL1K5"
          using ordinal2_th_27 sorry
        finally show "succORDINAL1K1 A *^ORDINAL2K11 (0ORDINAL1K5) =HIDDENR1 0ORDINAL1K5"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A2: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5)) implies A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 (0ORDINAL1K5)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: "A <>HIDDENR2 0ORDINAL1K5"
          and A4: "A be limit-ordinalORDINAL1V4"
          and A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A6: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies fi .FUNCT-1K1 B =XBOOLE-0R4 ?F(B))"
          using ordinal2_sch_3 sorry
        have "rngFUNCT-1K2 fi =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
        proof-
          have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 succORDINAL1K1 (0ORDINAL1K5)) & succORDINAL1K1 (0ORDINAL1K5) c=TARSKIR1 rngFUNCT-1K2 fi"
          proof(rule conjMI)
            show " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 succORDINAL1K1 (0ORDINAL1K5)"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 rngFUNCT-1K2 fi"
              then obtain y where
                [ty]:"y be objectHIDDENM1" and 
                A7: "y inHIDDENR3 domRELAT-1K1 fi"and A8: "x =HIDDENR1 fi .FUNCT-1K1 y"
                using funct_1_def_3 sorry
              have 
                [ty]:"y be OrdinalORDINAL1M3"
                using A7 sorry
              have "x =HIDDENR1 y *^ORDINAL2K11 (0ORDINAL1K5)"
                using A6 A7 A8 sorry
              also have "... = 0ORDINAL1K5"
                using A5 A6 A7 sorry
              finally have "x =HIDDENR1 0ORDINAL1K5"
                 sorry
              thus "x inHIDDENR3 succORDINAL1K1 (0ORDINAL1K5)"
                using tarski_def_1 sorry
            qed "sorry"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 succORDINAL1K1 (0ORDINAL1K5) implies x inHIDDENR3 rngFUNCT-1K2 fi"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 succORDINAL1K1 (0ORDINAL1K5)"
              then have A9: "x =HIDDENR1 0ORDINAL1K5"
                using tarski_def_1 sorry
              have "0ORDINAL1K5 c=ORDINAL1R1 A"
                 sorry
              then have A10: "0ORDINAL1K5 c<XBOOLE-0R2 A"
                using A3 sorry
              then have A11: "0ORDINAL1K5 inTARSKIR2 A"
                using ordinal1_th_11 sorry
              have "(0ORDINAL1K5)*^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
                using ordinal2_th_35 sorry
              then have "fi .FUNCT-1K1 x =HIDDENR1 x"
                using A6 A10 A9 ordinal1_th_11 sorry
              thus "x inHIDDENR3 rngFUNCT-1K2 fi"
                using A6 A11 A9 funct_1_def_3 sorry
            qed "sorry"
            thus "succORDINAL1K1 (0ORDINAL1K5) c=TARSKIR1 rngFUNCT-1K2 fi"
              using tarski_def_3 sorry
          qed
          thus "rngFUNCT-1K2 fi =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
            using tarski_def_3 xboole_0_def_10 sorry
        qed
        then have A12: "supORDINAL2K3 (rngFUNCT-1K2 fi) =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
          using ordinal2_th_18 sorry
        have "A *^ORDINAL2K11 (0ORDINAL1K5) =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
          using A3 A4 A6 ordinal2_th_37 sorry
        also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
           sorry
        finally have "A *^ORDINAL2K11 (0ORDINAL1K5) =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
           sorry
        thus "A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
          using A12 ordinal2_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: "?P(0ORDINAL1K5)"
      using ordinal2_th_35 sorry
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A13 A1 A2 sorry
    thus "A *^ORDINAL2K11 (0ORDINAL1K5) =XBOOLE-0R4 0ORDINAL1K5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_39:
" for A be OrdinalORDINAL1M3 holds \<one>\<^sub>M *^ORDINAL2K11 A =XBOOLE-0R4 A & A *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds \<one>\<^sub>M *^ORDINAL2K11 A =HIDDENR1 A & A *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 A"
  proof(rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =XBOOLE-0R4 Lamb1"
    have "\<one>\<^sub>M *^ORDINAL2K11 A =HIDDENR1 (0ORDINAL1K5)*^ORDINAL2K11 A +^ORDINAL2K10 A"
      using ordinal2_lm_1 ordinal2_th_36 sorry
    also have "... = 0ORDINAL1K5 +^ORDINAL2K10 A"
      using ordinal2_th_35 sorry
    also have "... = A"
      using ordinal2_th_30 sorry
    finally show "\<one>\<^sub>M *^ORDINAL2K11 A =HIDDENR1 A"
       sorry
    have A1: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =XBOOLE-0R4 B) implies A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =XBOOLE-0R4 A"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies B *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =XBOOLE-0R4 B"
        have A3: "A <>HIDDENR2 0ORDINAL1K5 & ( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 A"
        proof(rule impMI ,rule impI)
          let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5)"
          assume A4: "A <>HIDDENR2 0ORDINAL1K5"
            and A5: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
          obtain fi where
            [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
            A6: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 A implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
            using ordinal2_sch_3 sorry
          have A7: "A =XBOOLE-0R4 rngFUNCT-1K2 fi"
          proof-
            have "A c=TARSKIR1 rngFUNCT-1K2 fi & rngFUNCT-1K2 fi c=TARSKIR1 A"
            proof(rule conjMI)
              show "A c=TARSKIR1 rngFUNCT-1K2 fi"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 A implies x inHIDDENR3 rngFUNCT-1K2 fi"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume A8: "x inHIDDENR3 A"
                  then obtain B where 
                    [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = x"
                     sorry
                  have "x =HIDDENR1 B *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5)"
                    using A2 A8 sorry
                  also have "... = fi .FUNCT-1K1 x"
                    using A6 A8 sorry
                  finally have "x =HIDDENR1 fi .FUNCT-1K1 x"
                     sorry
                  thus "x inHIDDENR3 rngFUNCT-1K2 fi"
                    using A6 A8 funct_1_def_3 sorry
                qed "sorry"
                thus "A c=TARSKIR1 rngFUNCT-1K2 fi"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 A"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 rngFUNCT-1K2 fi"
                then obtain y where
                  [ty]:"y be objectHIDDENM1" and 
                  A9: "y inHIDDENR3 domRELAT-1K1 fi"and A10: "x =HIDDENR1 fi .FUNCT-1K1 y"
                  using funct_1_def_3 sorry
                have 
                  [ty]:"y be OrdinalORDINAL1M3"
                  using A9 sorry
                have "fi .FUNCT-1K1 y =HIDDENR1 y *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5)"
                  using A6 A9 sorry
                also have "... = y"
                  using A2 A6 A9 sorry
                finally have "fi .FUNCT-1K1 y =HIDDENR1 y"
                   sorry
                thus "x inHIDDENR3 A"
                  using A6 A9 A10 sorry
              qed "sorry"
              thus "rngFUNCT-1K2 fi c=TARSKIR1 A"
                using tarski_def_3 sorry
            qed
            thus "A =XBOOLE-0R4 rngFUNCT-1K2 fi"
              using xboole_0_def_10 sorry
          qed
          have A11: "A be limit-ordinalORDINAL1V4"
            using A5 ordinal1_th_29 sorry
          then have "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
            using A4 A6 ordinal2_th_37 sorry
          also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          finally have "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          then have "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 unionTARSKIK3 A"
            using A7 ordinal2_th_18 sorry
          also have "... = A"
            using A11 sorry
          finally show "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 A"
             sorry
        qed
        have "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 A"
        proof(rule impI)
          assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
          then obtain B where
            [ty]:"B be OrdinalORDINAL1M3" and 
            A12: "A =XBOOLE-0R4 succORDINAL1K1 B"
             sorry
          have "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 B *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) +^ORDINAL2K10 succORDINAL1K1 (0ORDINAL1K5)"
            using A12 ordinal2_th_36 sorry
          also have "... = B +^ORDINAL2K10 succORDINAL1K1 (0ORDINAL1K5)"
            using A2 A12 ordinal1_th_6 sorry
          also have "... = succORDINAL1K1 (B +^ORDINAL2K10 0ORDINAL1K5)"
            using ordinal2_th_28 sorry
          also have "... = A"
            using A12 ordinal2_th_27 sorry
          finally show "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =HIDDENR1 A"
             sorry
        qed
        thus "A *^ORDINAL2K11 succORDINAL1K1 (0ORDINAL1K5) =XBOOLE-0R4 A"
          using A3 ordinal2_th_35 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal1_sch_2 A1 sorry
    thus "A *^ORDINAL2K11 \<one>\<^sub>M =XBOOLE-0R4 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_40:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C <>HIDDENR2 0ORDINAL1K5 & A inTARSKIR2 B implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C <>HIDDENR2 0ORDINAL1K5 implies  not (A inTARSKIR2 B &  not A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    have A1: "0ORDINAL1K5 c=ORDINAL1R1 C"
       sorry
    let ?P = "\<lambda>Lamb1. A inTARSKIR2 Lamb1 implies A *^ORDINAL2K11 C inTARSKIR2 Lamb1 *^ORDINAL2K11 C"
    assume "C <>HIDDENR2 0ORDINAL1K5"
    then have A2: "0ORDINAL1K5 c<XBOOLE-0R2 C"
      using A1 sorry
    then have A3: "0ORDINAL1K5 inTARSKIR2 C"
      using ordinal1_th_11 sorry
    have A4: " for B be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies ?P(D)) implies ?P(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies (A inTARSKIR2 D implies A *^ORDINAL2K11 C inTARSKIR2 D *^ORDINAL2K11 C)) & A inTARSKIR2 B implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
      proof(rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A5: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies (A inTARSKIR2 D implies A *^ORDINAL2K11 C inTARSKIR2 D *^ORDINAL2K11 C)"
          and A6: "A inTARSKIR2 B"
        have A7: "( ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 D) implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
        proof(rule impI)
          assume Given: " ex D be OrdinalORDINAL1M3 st B =XBOOLE-0R4 succORDINAL1K1 D"
          then obtain D where
            [ty]:"D be OrdinalORDINAL1M3" and 
            A8: "B =XBOOLE-0R4 succORDINAL1K1 D"
             sorry
          have A9: "A inTARSKIR2 D implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
          proof(rule impI)
            assume "A inTARSKIR2 D"
            then have A10: "A *^ORDINAL2K11 C inTARSKIR2 D *^ORDINAL2K11 C"
              using A5 A8 ordinal1_th_6 sorry
            have A11: "D *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 inTARSKIR2 D *^ORDINAL2K11 C +^ORDINAL2K10 C"
              using A2 ordinal2_th_32 ordinal1_th_11 sorry
            have "D *^ORDINAL2K11 C +^ORDINAL2K10 C =XBOOLE-0R4 succORDINAL1K1 D *^ORDINAL2K11 C & D *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 D *^ORDINAL2K11 C"
              using ordinal2_th_27 ordinal2_th_36 sorry
            thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
              using A8 A10 A11 ordinal1_th_10 sorry
          qed
          have " not A inTARSKIR2 D implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
          proof(rule impI)
            have A12: "A *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 A *^ORDINAL2K11 C"
              using ordinal2_th_27 sorry
            assume A13: " not A inTARSKIR2 D"
            have "A c<XBOOLE-0R2 D iff A c=ORDINAL1R1 D & A <>HIDDENR2 D"
               sorry
            then have "A *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 inTARSKIR2 D *^ORDINAL2K11 C +^ORDINAL2K10 C"
              using A3 A6 A8 A13 ordinal2_th_32 ordinal1_th_11 ordinal1_th_22 sorry
            thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
              using A8 A12 ordinal2_th_36 sorry
          qed
          thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
            using A9 sorry
        qed
        have "( for D be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 D) implies A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
        proof(rule impI)
          have A14: "A *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 =XBOOLE-0R4 A *^ORDINAL2K11 C & A *^ORDINAL2K11 C +^ORDINAL2K10 0ORDINAL1K5 inTARSKIR2 A *^ORDINAL2K11 C +^ORDINAL2K10 C"
            using A2 ordinal2_th_27 ordinal2_th_32 ordinal1_th_11 sorry
          have A15: "succORDINAL1K1 A *^ORDINAL2K11 C =XBOOLE-0R4 A *^ORDINAL2K11 C +^ORDINAL2K10 C"
            using ordinal2_th_36 sorry
          let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 C"
          obtain fi where
            [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
            A16: "domRELAT-1K1 fi =XBOOLE-0R4 B & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 B implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
            using ordinal2_sch_3 sorry
          assume " for D be OrdinalORDINAL1M3 holds B <>HIDDENR2 succORDINAL1K1 D"
          then have A17: "B be limit-ordinalORDINAL1V4"
            using ordinal1_th_29 sorry
          then have A18: "succORDINAL1K1 A inTARSKIR2 B"
            using A6 ordinal1_th_28 sorry
          then have "fi .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 succORDINAL1K1 A *^ORDINAL2K11 C"
            using A16 sorry
          then have "succORDINAL1K1 A *^ORDINAL2K11 C inTARSKIR2 rngFUNCT-1K2 fi"
            using A16 A18 funct_1_def_3 sorry
          then have A19: "succORDINAL1K1 A *^ORDINAL2K11 C c=ORDINAL1R1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
            using ordinal2_th_19 zfmisc_1_th_74 sorry
          have "B *^ORDINAL2K11 C =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
            using A6 A17 A16 ordinal2_th_37 sorry
          also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          finally have "B *^ORDINAL2K11 C =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
             sorry
          thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
            using A19 A14 A15 sorry
        qed
        thus "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
          using A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal1_sch_2 A4 sorry
    thus " not (A inTARSKIR2 B &  not A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_41:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
    have A2: "C <>HIDDENR2 0ORDINAL1K5 implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
    proof(rule impI)
      assume A3: "C <>HIDDENR2 0ORDINAL1K5"
      have "A <>HIDDENR2 B implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
      proof(rule impI)
        assume "A <>HIDDENR2 B"
        then have "A c<XBOOLE-0R2 B"
          using A1 sorry
        then have "A *^ORDINAL2K11 C inTARSKIR2 B *^ORDINAL2K11 C"
          using A3 ordinal2_th_40 ordinal1_th_11 sorry
        thus "A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
          using ordinal1_def_2 sorry
      qed
      thus "A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
         sorry
    qed
    have "C =XBOOLE-0R4 0ORDINAL1K5 implies A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
      using ordinal2_th_38 sorry
    thus "A *^ORDINAL2K11 C c=ORDINAL1R1 B *^ORDINAL2K11 C"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_42:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    fix C assume [ty]: "C be OrdinalORDINAL1M3"
    assume A1: "A c=ORDINAL1R1 B"
    have "B <>HIDDENR2 0ORDINAL1K5 implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
    proof(rule impI)
      let ?P = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 A c=ORDINAL1R1 Lamb1 *^ORDINAL2K11 B"
      assume A2: "B <>HIDDENR2 0ORDINAL1K5"
      have A3: " for C be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies ?P(D)) implies ?P(C)"
      proof-
        have " for C be OrdinalORDINAL1M3 holds ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies D *^ORDINAL2K11 A c=ORDINAL1R1 D *^ORDINAL2K11 B) implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
        proof(rule ballI,rule impI)
          fix C assume [ty]: "C be OrdinalORDINAL1M3"
          assume A4: " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies D *^ORDINAL2K11 A c=ORDINAL1R1 D *^ORDINAL2K11 B"
          have A5: "( ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 succORDINAL1K1 D) implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
          proof(rule impI)
            assume Given: " ex D be OrdinalORDINAL1M3 st C =XBOOLE-0R4 succORDINAL1K1 D"
            then obtain D where
              [ty]:"D be OrdinalORDINAL1M3" and 
              A6: "C =XBOOLE-0R4 succORDINAL1K1 D"
               sorry
            have "D *^ORDINAL2K11 A c=ORDINAL1R1 D *^ORDINAL2K11 B"
              using A4 A6 ordinal1_th_6 sorry
            then have A7: "D *^ORDINAL2K11 A +^ORDINAL2K10 A c=ORDINAL1R1 D *^ORDINAL2K11 B +^ORDINAL2K10 A"
              using ordinal2_th_34 sorry
            have A8: "C *^ORDINAL2K11 A =XBOOLE-0R4 D *^ORDINAL2K11 A +^ORDINAL2K10 A & C *^ORDINAL2K11 B =XBOOLE-0R4 D *^ORDINAL2K11 B +^ORDINAL2K10 B"
              using A6 ordinal2_th_36 sorry
            have "D *^ORDINAL2K11 B +^ORDINAL2K10 A c=ORDINAL1R1 D *^ORDINAL2K11 B +^ORDINAL2K10 B"
              using A1 ordinal2_th_33 sorry
            thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
              using A7 A8 xboole_1_th_1 sorry
          qed
          have A9: "C <>HIDDENR2 0ORDINAL1K5 & ( for D be OrdinalORDINAL1M3 holds C <>HIDDENR2 succORDINAL1K1 D) implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
          proof(rule impMI ,rule impI)
            let ?F = "\<lambda>Lamb1. Lamb1 *^ORDINAL2K11 A"
            assume A10: "C <>HIDDENR2 0ORDINAL1K5"
              and A11: " for D be OrdinalORDINAL1M3 holds C <>HIDDENR2 succORDINAL1K1 D"
            obtain fi where
              [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
              A12: "domRELAT-1K1 fi =XBOOLE-0R4 C & ( for D be OrdinalORDINAL1M3 holds D inTARSKIR2 C implies fi .FUNCT-1K1 D =XBOOLE-0R4 ?F(D))"
              using ordinal2_sch_3 sorry
            have " for D be OrdinalORDINAL1M3 holds D inTARSKIR2 rngFUNCT-1K2 fi implies D inTARSKIR2 C *^ORDINAL2K11 B"
            proof(rule ballI,rule impI)
              fix D assume [ty]: "D be OrdinalORDINAL1M3"
              assume "D inTARSKIR2 rngFUNCT-1K2 fi"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A13: "x inHIDDENR3 domRELAT-1K1 fi"and A14: "D =XBOOLE-0R4 fi .FUNCT-1K1 x"
                using funct_1_def_3 sorry
              have 
                [ty]:"x be OrdinalORDINAL1M3"
                using A13 sorry
              have A15: "x *^ORDINAL2K11 B inTARSKIR2 C *^ORDINAL2K11 B"
                using A2 A12 A13 ordinal2_th_40 sorry
              have "D =XBOOLE-0R4 x *^ORDINAL2K11 A & x *^ORDINAL2K11 A c=ORDINAL1R1 x *^ORDINAL2K11 B"
                using A4 A12 A13 A14 sorry
              thus "D inTARSKIR2 C *^ORDINAL2K11 B"
                using A15 ordinal1_th_12 sorry
            qed "sorry"
            then have A16: "supORDINAL2K3 (rngFUNCT-1K2 fi) c=ORDINAL1R1 C *^ORDINAL2K11 B"
              using ordinal2_th_20 sorry
            have "C be limit-ordinalORDINAL1V4"
              using A11 ordinal1_th_29 sorry
            then have A17: "C *^ORDINAL2K11 A =HIDDENR1 unionTARSKIK3 supORDINAL2K4 fi"
              using A10 A12 ordinal2_th_37 sorry
            also have "... = unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
               sorry
            finally have "C *^ORDINAL2K11 A =HIDDENR1 unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi)"
               sorry
            have "unionTARSKIK3 supORDINAL2K3 (rngFUNCT-1K2 fi) c=ORDINAL1R1 supORDINAL2K3 (rngFUNCT-1K2 fi)"
              using ordinal2_th_5 sorry
            thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
              using A17 A16 xboole_1_th_1 sorry
          qed
          have "C =XBOOLE-0R4 0ORDINAL1K5 implies C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
          proof(rule impI)
            assume "C =XBOOLE-0R4 0ORDINAL1K5"
            then have "C *^ORDINAL2K11 A =XBOOLE-0R4 0ORDINAL1K5"
              using ordinal2_th_35 sorry
            thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
               sorry
          qed
          thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
            using A5 A9 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have " for C be OrdinalORDINAL1M3 holds ?P(C)"
        using ordinal1_sch_2 A3 sorry
      thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
         sorry
    qed
    thus "C *^ORDINAL2K11 A c=ORDINAL1R1 C *^ORDINAL2K11 B"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_43:
" for A be OrdinalORDINAL1M3 holds expORDINAL2K12(A,0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for A be OrdinalORDINAL1M3 holds expORDINAL2K12(A,0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. limORDINAL2K8 Lamb2"
    let ?F = "\<lambda>Lamb1. expORDINAL2K12(A,Lamb1)"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. A *^ORDINAL2K11 Lamb2"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_16 sorry
    show "expORDINAL2K12(A,0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M"
      using ordinal2_sch_14 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_44:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds expORDINAL2K12(A,succORDINAL1K1 B) =XBOOLE-0R4 A *^ORDINAL2K11 (expORDINAL2K12(A,B))"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds expORDINAL2K12(A,succORDINAL1K1 B) =XBOOLE-0R4 A *^ORDINAL2K11 (expORDINAL2K12(A,B))"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. limORDINAL2K8 Lamb2"
    let ?F = "\<lambda>Lamb1. expORDINAL2K12(A,Lamb1)"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. A *^ORDINAL2K11 Lamb2"
    have A1: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_16 sorry
    have " for B be OrdinalORDINAL1M3 holds ?F(succORDINAL1K1 B) =XBOOLE-0R4 ?C(B,?F(B))"
      using ordinal2_sch_15 A1 sorry
    thus "expORDINAL2K12(A,succORDINAL1K1 B) =XBOOLE-0R4 A *^ORDINAL2K11 (expORDINAL2K12(A,B))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_45:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 expORDINAL2K12(A,C)) implies expORDINAL2K12(A,B) =XBOOLE-0R4 limORDINAL2K8 fi)"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4 implies ( for fi be Ordinal-SequenceORDINAL2M1 holds domRELAT-1K1 fi =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 expORDINAL2K12(A,C)) implies expORDINAL2K12(A,B) =XBOOLE-0R4 limORDINAL2K8 fi)"
  proof(rule ballI,rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. limORDINAL2K8 Lamb2"
    assume A1: "B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4"
    let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. A *^ORDINAL2K11 Lamb2"
    let ?F = "\<lambda>Lamb1. expORDINAL2K12(A,Lamb1)"
    fix fi assume [ty]: "fi be Ordinal-SequenceORDINAL2M1"
    assume A2: "domRELAT-1K1 fi =XBOOLE-0R4 B"
      and A3: " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?F(C)"
    have A4: " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds C =XBOOLE-0R4 ?F(B) iff ( ex fi be Ordinal-SequenceORDINAL2M1 st (((C =XBOOLE-0R4 lastORDINAL2K1 fi & domRELAT-1K1 fi =XBOOLE-0R4 succORDINAL1K1 B) & fi .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 \<one>\<^sub>M) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 B implies fi .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,fi .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 B & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies fi .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,fi  |RELAT-1K8 C)))"
      using ordinal2_def_16 sorry
    show "expORDINAL2K12(A,B) =XBOOLE-0R4 limORDINAL2K8 fi"
      using ordinal2_sch_16 A4 A1 A2 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_46:
" for A be OrdinalORDINAL1M3 holds expORDINAL2K12(A,\<one>\<^sub>M) =XBOOLE-0R4 A & expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for A be OrdinalORDINAL1M3 holds expORDINAL2K12(A,\<one>\<^sub>M) =HIDDENR1 A & expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule conjMI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1. expORDINAL2K12(\<one>\<^sub>M,Lamb1) =XBOOLE-0R4 \<one>\<^sub>M"
    have A1: " for A be OrdinalORDINAL1M3 holds ?P(A) implies ?P(succORDINAL1K1 A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M implies expORDINAL2K12(\<one>\<^sub>M,succORDINAL1K1 A) =HIDDENR1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
        then have "expORDINAL2K12(\<one>\<^sub>M,succORDINAL1K1 A) =HIDDENR1 \<one>\<^sub>M *^ORDINAL2K11 \<one>\<^sub>M"
          using ordinal2_th_44 sorry
        also have "... = \<one>\<^sub>M"
          using ordinal2_th_39 sorry
        finally show "expORDINAL2K12(\<one>\<^sub>M,succORDINAL1K1 A) =HIDDENR1 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "expORDINAL2K12(A,\<one>\<^sub>M) =HIDDENR1 A *^ORDINAL2K11 (expORDINAL2K12(A,0ORDINAL1K5))"
      using ordinal2_lm_1 ordinal2_th_44 sorry
    also have "... = A *^ORDINAL2K11 \<one>\<^sub>M"
      using ordinal2_th_43 sorry
    also have "... = A"
      using ordinal2_th_39 sorry
    finally show "expORDINAL2K12(A,\<one>\<^sub>M) =HIDDENR1 A"
       sorry
    have A2: " for A be OrdinalORDINAL1M3 holds (A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4) & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & (A be limit-ordinalORDINAL1V4 & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies expORDINAL2K12(\<one>\<^sub>M,B) =XBOOLE-0R4 \<one>\<^sub>M)) implies expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        let ?F = "\<lambda>Lamb1. expORDINAL2K12(\<one>\<^sub>M,Lamb1)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: "A <>HIDDENR2 0ORDINAL1K5"
          and A4: "A be limit-ordinalORDINAL1V4"
          and A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies expORDINAL2K12(\<one>\<^sub>M,B) =XBOOLE-0R4 \<one>\<^sub>M"
        obtain fi where
          [ty]:"fi be Ordinal-SequenceORDINAL2M1" and 
          A6: "domRELAT-1K1 fi =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies fi .FUNCT-1K1 B =XBOOLE-0R4 ?F(B))"
          using ordinal2_sch_3 sorry
        have A7: "rngFUNCT-1K2 fi c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M}"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 fi implies x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 fi"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A8: "y inHIDDENR3 domRELAT-1K1 fi"and A9: "x =HIDDENR1 fi .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have 
              [ty]:"y be OrdinalORDINAL1M3"
              using A8 sorry
            have "x =HIDDENR1 expORDINAL2K12(\<one>\<^sub>M,y)"
              using A6 A8 A9 sorry
            also have "... = \<one>\<^sub>M"
              using A5 A6 A8 sorry
            finally have "x =HIDDENR1 \<one>\<^sub>M"
               sorry
            thus "x inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
              using tarski_def_1 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 fi c=TARSKIR1 {TARSKIK1 \<one>\<^sub>M}"
            using tarski_def_3 sorry
        qed
        have "0ORDINAL1K5 <>HIDDENR2 \<one>\<^sub>M & ( for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 \<one>\<^sub>M & \<one>\<^sub>M inTARSKIR2 C implies ( ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)))"
        proof(rule conjMI,rule ballI,rule ballI,rule impI)
          let ?x = "the ElementSUBSET-1M1-of A"
          show "0ORDINAL1K5 <>HIDDENR2 \<one>\<^sub>M"
             sorry
          fix B assume [ty]: "B be OrdinalORDINAL1M3"
          fix C assume [ty]: "C be OrdinalORDINAL1M3"
          assume A10: "B inTARSKIR2 \<one>\<^sub>M & \<one>\<^sub>M inTARSKIR2 C"
          obtain x where 
            [ty]:"x be OrdinalORDINAL1M3" and xDef:"x = ?x"
             sorry
          obtain D where 
            [ty]:"D be OrdinalORDINAL1M3" and DDef:"D = x"
             sorry
          show " ex D be OrdinalORDINAL1M3 st D inTARSKIR2 domRELAT-1K1 fi & ( for E be OrdinalORDINAL1M3 holds D c=ORDINAL1R1 E & E inTARSKIR2 domRELAT-1K1 fi implies B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C)"
          proof(rule bexI[of _ "D"],rule conjMI,rule ballI,rule impMI ,rule impI)
            show "D inTARSKIR2 domRELAT-1K1 fi"
              using A3 A6 sorry
            fix E assume [ty]: "E be OrdinalORDINAL1M3"
            assume "D c=ORDINAL1R1 E"
              and A11: "E inTARSKIR2 domRELAT-1K1 fi"
            have "fi .FUNCT-1K1 E inTARSKIR2 rngFUNCT-1K2 fi"
              using A11 funct_1_def_3 sorry
            thus "B inTARSKIR2 fi .FUNCT-1K1 E & fi .FUNCT-1K1 E inTARSKIR2 C"
              using A7 A10 tarski_def_1 sorry
          qed "sorry"
        qed "sorry"
        then have A12: "\<one>\<^sub>M is-limes-ofORDINAL2R1 fi"
          using ordinal2_def_9 sorry
        have "expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 limORDINAL2K8 fi"
          using A3 A4 A6 ordinal2_th_45 sorry
        thus "expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
          using A12 ordinal2_def_10 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A13: "?P(0ORDINAL1K5)"
      using ordinal2_th_43 sorry
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A13 A1 A2 sorry
    thus "expORDINAL2K12(\<one>\<^sub>M,A) =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_47:
" for A be OrdinalORDINAL1M3 holds  ex B be OrdinalORDINAL1M3 st  ex C be OrdinalORDINAL1M3 st (B be limit-ordinalORDINAL1V4 & C be naturalORDINAL1V7) & A =XBOOLE-0R4 B +^ORDINAL2K10 C"
proof-
  have " for A be OrdinalORDINAL1M3 holds  ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & A =XBOOLE-0R4 A1 +^ORDINAL2K10 A2"
  proof-
    let ?Th = "\<lambda>Lamb1.  ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & Lamb1 =XBOOLE-0R4 A1 +^ORDINAL2K10 A2"
    have A1: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?Th(B)) implies ?Th(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ( ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & B =XBOOLE-0R4 A1 +^ORDINAL2K10 A2)) implies ( ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & A =XBOOLE-0R4 A1 +^ORDINAL2K10 A2)"
      proof(rule ballI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A2: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?Th(B)"
        have A3: "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies ?Th(A)"
        proof-
          have "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies ( ex tVar27 be OrdinalORDINAL1M3 st  ex E be setHIDDENM2 st tVar27 be limit-ordinalORDINAL1V4 & (E be naturalORDINAL1V7 & A =XBOOLE-0R4 tVar27 +^ORDINAL2K10 E))"
          proof(rule impI)
            assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
            then obtain B where
              [ty]:"B be OrdinalORDINAL1M3" and 
              A4: "A =XBOOLE-0R4 succORDINAL1K1 B"
               sorry
            obtain C D where
              [ty]:"C be OrdinalORDINAL1M3" "D be OrdinalORDINAL1M3" and 
              A5: "C be limit-ordinalORDINAL1V4"and A6: "D be naturalORDINAL1V7"and A7: "B =XBOOLE-0R4 C +^ORDINAL2K10 D"
              using A2 A4 ordinal1_th_6 sorry
            show " ex tVar27 be OrdinalORDINAL1M3 st  ex E be setHIDDENM2 st tVar27 be limit-ordinalORDINAL1V4 & (E be naturalORDINAL1V7 & A =XBOOLE-0R4 tVar27 +^ORDINAL2K10 E)"
            proof(rule bexI[of _ "C"])
              obtain E where 
                [ty]:"E be setHIDDENM2" and EDef:"E = succORDINAL1K1 D"
                 sorry
              show " ex E be setHIDDENM2 st C be limit-ordinalORDINAL1V4 & (E be naturalORDINAL1V7 & A =XBOOLE-0R4 C +^ORDINAL2K10 E)"
              proof(rule bexI[of _ "E"],rule conjMI)
                show "C be limit-ordinalORDINAL1V4"
                  using A5 sorry
                have "E inTARSKIR2 omegaORDINAL1K4 & A =XBOOLE-0R4 C +^ORDINAL2K10 E"
                proof(rule conjMI)
                  show "E inTARSKIR2 omegaORDINAL1K4"
                    using A6 ordinal1_def_12 sorry
                  show "A =XBOOLE-0R4 C +^ORDINAL2K10 E"
                    using A4 A7 ordinal2_th_28 sorry
                qed
                thus "E be naturalORDINAL1V7 & A =XBOOLE-0R4 C +^ORDINAL2K10 E"
                  using ordinal1_def_12 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have "( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies ?Th(A)"
        proof-
          have "( for D be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 D) implies ( ex B be OrdinalORDINAL1M3 st  ex C be setHIDDENM2 st B be limit-ordinalORDINAL1V4 & (C be naturalORDINAL1V7 & A =XBOOLE-0R4 B +^ORDINAL2K10 C))"
          proof(rule impI)
            assume A8: " for D be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 D"
            obtain B where 
              [ty]:"B be OrdinalORDINAL1M3" and BDef:"B = A"
               sorry
            show " ex B be OrdinalORDINAL1M3 st  ex C be setHIDDENM2 st B be limit-ordinalORDINAL1V4 & (C be naturalORDINAL1V7 & A =XBOOLE-0R4 B +^ORDINAL2K10 C)"
            proof(rule bexI[of _ "B"])
              obtain C where 
                [ty]:"C be setHIDDENM2" and CDef:"C = 0ORDINAL1K5"
                 sorry
              show " ex C be setHIDDENM2 st B be limit-ordinalORDINAL1V4 & (C be naturalORDINAL1V7 & A =XBOOLE-0R4 B +^ORDINAL2K10 C)"
              proof(rule bexI[of _ "C"],rule conjMI)
                show "B be limit-ordinalORDINAL1V4"
                  using A8 ordinal1_th_29 sorry
                have "C inTARSKIR2 omegaORDINAL1K4 & A =XBOOLE-0R4 B +^ORDINAL2K10 C"
                proof(rule conjMI)
                  show "C inTARSKIR2 omegaORDINAL1K4"
                    using ordinal1_def_11 sorry
                  show "A =XBOOLE-0R4 B +^ORDINAL2K10 C"
                    using ordinal2_th_27 sorry
                qed
                thus "C be naturalORDINAL1V7 & A =XBOOLE-0R4 B +^ORDINAL2K10 C"
                  using ordinal1_def_12 sorry
              qed "sorry"
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus " ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & A =XBOOLE-0R4 A1 +^ORDINAL2K10 A2"
          using A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for A be OrdinalORDINAL1M3 holds  ex A1 be OrdinalORDINAL1M3 st  ex A2 be OrdinalORDINAL1M3 st (A1 be limit-ordinalORDINAL1V4 & A2 be naturalORDINAL1V7) & A =XBOOLE-0R4 A1 +^ORDINAL2K10 A2"
      using ordinal1_sch_2 A1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_cl_7:
  mlet "X be setHIDDENM2", "o be OrdinalORDINAL1M3"
"cluster X -->FUNCOP-1K7 o as-term-is Ordinal-yieldingORDINAL2V1"
proof
(*coherence*)
  show "X -->FUNCOP-1K7 o be Ordinal-yieldingORDINAL2V1"
  proof-
    have "rngFUNCT-1K2 (X -->FUNCOP-1K7 o) c=TARSKIR1 {TARSKIK1 o} & {TARSKIK1 o} c=TARSKIR1 succORDINAL1K1 o"
      using funcop_1_th_13 xboole_1_th_7 sorry
    then have "rngFUNCT-1K2 (X -->FUNCOP-1K7 o) c=TARSKIR1 succORDINAL1K1 o"
       sorry
    thus "X -->FUNCOP-1K7 o be Ordinal-yieldingORDINAL2V1"
       sorry
  qed
qed "sorry"

mtheorem ordinal2_cl_8:
  mlet "O be OrdinalORDINAL1M3", "x be objectHIDDENM1"
"cluster O -->FUNCOP-1K7 x as-term-is Sequence-likeORDINAL1V5"
proof
(*coherence*)
  show "O -->FUNCOP-1K7 x be Sequence-likeORDINAL1V5"
    using funcop_1_th_13 sorry
qed "sorry"

mdef ordinal2_def_17 (" _ is-cofinal-withORDINAL2R2  _ " [50,50]50 ) where
  mlet "A be OrdinalORDINAL1M3", "B be OrdinalORDINAL1M3"
"pred A is-cofinal-withORDINAL2R2 B means
   ex xi be Ordinal-SequenceORDINAL2M1 st ((domRELAT-1K1 xi =XBOOLE-0R4 B & rngFUNCT-1K2 xi c=TARSKIR1 A) & xi be increasingORDINAL2V2) & A =XBOOLE-0R4 supORDINAL2K4 xi"..

mtheorem ORDINAL2R2_reflexivity:
" for B be OrdinalORDINAL1M3 holds B is-cofinal-withORDINAL2R2 B"
proof-
  have " for B be OrdinalORDINAL1M3 holds  ex xi be Ordinal-SequenceORDINAL2M1 st ((domRELAT-1K1 xi =XBOOLE-0R4 B & rngFUNCT-1K2 xi c=TARSKIR1 B) & xi be increasingORDINAL2V2) & B =XBOOLE-0R4 supORDINAL2K4 xi"
  proof-
    have " for A be OrdinalORDINAL1M3 holds  ex tVar31 be Ordinal-SequenceORDINAL2M1 st (domRELAT-1K1 tVar31 =XBOOLE-0R4 A & rngFUNCT-1K2 tVar31 c=TARSKIR1 A) & (tVar31 be increasingORDINAL2V2 & A =XBOOLE-0R4 supORDINAL2K4 tVar31)"
    proof(rule ballI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      have A1: "domRELAT-1K1 (idRELAT-1K7 A) =XBOOLE-0R4 A"
        using relat_1_th_45 sorry
      then obtain xi where 
        [ty]:"xi be SequenceORDINAL1M4" and xiDef:"xi = idRELAT-1K7 A"
        using ordinal1_def_7 sorry
      have A2: "rngFUNCT-1K2 (idRELAT-1K7 A) =XBOOLE-0R4 A"
        using relat_1_th_45 sorry
      then have 
        [ty]:"xi be Ordinal-SequenceORDINAL2M1"
        using ordinal2_def_4 sorry
      show " ex tVar31 be Ordinal-SequenceORDINAL2M1 st (domRELAT-1K1 tVar31 =XBOOLE-0R4 A & rngFUNCT-1K2 tVar31 c=TARSKIR1 A) & (tVar31 be increasingORDINAL2V2 & A =XBOOLE-0R4 supORDINAL2K4 tVar31)"
      proof(rule bexI[of _ "xi"],rule conjMI,rule conjMI)
        show "domRELAT-1K1 xi =XBOOLE-0R4 A & rngFUNCT-1K2 xi c=TARSKIR1 A"
          using relat_1_th_45 sorry
        show "xi be increasingORDINAL2V2"
        proof-
          have " for B be OrdinalORDINAL1M3 holds  for C be OrdinalORDINAL1M3 holds B inTARSKIR2 C & C inTARSKIR2 domRELAT-1K1 xi implies xi .FUNCT-1K1 B inTARSKIR2 xi .FUNCT-1K1 C"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix B assume [ty]: "B be OrdinalORDINAL1M3"
            fix C assume [ty]: "C be OrdinalORDINAL1M3"
            assume A3: "B inTARSKIR2 C"
              and A4: "C inTARSKIR2 domRELAT-1K1 xi"
            have "xi .FUNCT-1K1 C =XBOOLE-0R4 C"
              using A1 A4 funct_1_th_18 sorry
            thus "xi .FUNCT-1K1 B inTARSKIR2 xi .FUNCT-1K1 C"
              using A1 A3 A4 funct_1_th_18 ordinal1_th_10 sorry
          qed "sorry"
          thus "xi be increasingORDINAL2V2"
            using ordinal2_def_12 sorry
        qed
        show "A =XBOOLE-0R4 supORDINAL2K4 xi"
          using A2 ordinal2_th_18 sorry
      qed "sorry"
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus " ?thesis "
    using ordinal2_def_17 sorry
qed

reserve e, u for "setHIDDENM2"
mtheorem ordinal2_th_48:
" for psi be Ordinal-SequenceORDINAL2M1 holds  for e be setHIDDENM2 holds e inTARSKIR2 rngFUNCT-1K2 psi implies e be OrdinalORDINAL1M3"
proof-
  have " for psi be Ordinal-SequenceORDINAL2M1 holds  for e be setHIDDENM2 holds e inTARSKIR2 rngFUNCT-1K2 psi implies e be OrdinalORDINAL1M3"
  proof(rule ballI,rule ballI,rule impI)
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    fix e assume [ty]: "e be setHIDDENM2"
    assume "e inTARSKIR2 rngFUNCT-1K2 psi"
    then have " ex u be objectHIDDENM1 st u inHIDDENR3 domRELAT-1K1 psi & e =XBOOLE-0R4 psi .FUNCT-1K1 u"
      using funct_1_def_3 sorry
    thus "e be OrdinalORDINAL1M3"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_49:
" for psi be Ordinal-SequenceORDINAL2M1 holds rngFUNCT-1K2 psi c=TARSKIR1 supORDINAL2K4 psi"
proof-
  have " for psi be Ordinal-SequenceORDINAL2M1 holds rngFUNCT-1K2 psi c=TARSKIR1 supORDINAL2K4 psi"
  proof(rule ballI)
    fix psi assume [ty]: "psi be Ordinal-SequenceORDINAL2M1"
    have " for e be objectHIDDENM1 holds e inHIDDENR3 rngFUNCT-1K2 psi implies e inHIDDENR3 supORDINAL2K4 psi"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume A1: "e inHIDDENR3 rngFUNCT-1K2 psi"
      then have "e be OrdinalORDINAL1M3"
        using ordinal2_th_48 sorry
      thus "e inHIDDENR3 supORDINAL2K4 psi"
        using A1 ordinal2_th_19 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 psi c=TARSKIR1 supORDINAL2K4 psi"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem ordinal2_th_50:
" for A be OrdinalORDINAL1M3 holds A is-cofinal-withORDINAL2R2 0ORDINAL1K5 implies A =XBOOLE-0R4 0ORDINAL1K5"
proof-
  have " for A be OrdinalORDINAL1M3 holds  not (A is-cofinal-withORDINAL2R2 0ORDINAL1K5 &  not A =XBOOLE-0R4 0ORDINAL1K5)"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "( ex psi be Ordinal-SequenceORDINAL2M1 st ((domRELAT-1K1 psi =XBOOLE-0R4 0ORDINAL1K5 & rngFUNCT-1K2 psi c=TARSKIR1 A) & psi be increasingORDINAL2V2) & A =XBOOLE-0R4 supORDINAL2K4 psi) implies A =HIDDENR1 0ORDINAL1K5"
    proof(rule impI)
      assume Given: " ex psi be Ordinal-SequenceORDINAL2M1 st ((domRELAT-1K1 psi =XBOOLE-0R4 0ORDINAL1K5 & rngFUNCT-1K2 psi c=TARSKIR1 A) & psi be increasingORDINAL2V2) & A =XBOOLE-0R4 supORDINAL2K4 psi"
      then obtain psi where
        [ty]:"psi be Ordinal-SequenceORDINAL2M1" and 
        A1: "domRELAT-1K1 psi =XBOOLE-0R4 0ORDINAL1K5"and "rngFUNCT-1K2 psi c=TARSKIR1 A"and "psi be increasingORDINAL2V2"and A2: "A =XBOOLE-0R4 supORDINAL2K4 psi"
         sorry
      have "A =HIDDENR1 supORDINAL2K3 (0ORDINAL1K5)"
        using A1 A2 relat_1_th_42 sorry
      also have "... = 0ORDINAL1K5"
        using ordinal2_th_18 sorry
      finally show "A =HIDDENR1 0ORDINAL1K5"
         sorry
    qed
    thus " not (A is-cofinal-withORDINAL2R2 0ORDINAL1K5 &  not A =XBOOLE-0R4 0ORDINAL1K5)"
      using ordinal2_def_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem ordinal2_sch_17:
  fixes af0 Pp1 
  assumes
[ty]: "af0 be NatORDINAL1M6" and
   A1: "Pp1(0ORDINAL1K5)" and
   A2: " for a be NatORDINAL1M6 holds Pp1(a) implies Pp1(succORDINAL1K1 a)"
  shows "Pp1(af0)"
  proof-
    let ?P = "\<lambda>Lamb1. Lamb1 be naturalORDINAL1V7 implies Pp1(Lamb1)"
    have A3: " for A be OrdinalORDINAL1M3 holds (A be naturalORDINAL1V7 implies Pp1(A)) implies (succORDINAL1K1 A be naturalORDINAL1V7 implies Pp1(succORDINAL1K1 A))"
    proof(rule ballI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A4: "?P(A)"
      have "succORDINAL1K1 A be naturalORDINAL1V7 implies (succORDINAL1K1 A be naturalORDINAL1V7 implies Pp1(succORDINAL1K1 A))"
      proof(rule impI)
        assume "succORDINAL1K1 A be naturalORDINAL1V7"
        then have A5: "succORDINAL1K1 A inTARSKIR2 omegaORDINAL1K4"
           sorry
        have "A inTARSKIR2 succORDINAL1K1 A"
          using ordinal1_th_6 sorry
        then have "A be ElementSUBSET-1M1-of omegaORDINAL1K4"
          using A5 ordinal1_th_10 sorry
        thus "succORDINAL1K1 A be naturalORDINAL1V7 implies Pp1(succORDINAL1K1 A)"
          using A2 A4 sorry
      qed
      thus "succORDINAL1K1 A be naturalORDINAL1V7 implies Pp1(succORDINAL1K1 A)"
         sorry
    qed "sorry"
    have A6: " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 implies (A be limit-ordinalORDINAL1V4 implies (( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B be naturalORDINAL1V7 implies Pp1(B))) implies (A be naturalORDINAL1V7 implies Pp1(A))))"
    proof(rule ballI,rule impI,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A7: "A <>HIDDENR2 0ORDINAL1K5"
      have "0ORDINAL1K5 c=ORDINAL1R1 A"
         sorry
      then have "0ORDINAL1K5 c<XBOOLE-0R2 A"
        using A7 sorry
      then have A8: "0ORDINAL1K5 inTARSKIR2 A"
        using ordinal1_th_11 sorry
      have A9: " not A inTARSKIR2 A"
         sorry
      assume "A be limit-ordinalORDINAL1V4"
      then have "omegaORDINAL1K4 c=ORDINAL1R1 A"
        using A8 ordinal1_def_11 sorry
      then have " not A inTARSKIR2 omegaORDINAL1K4"
        using A9 sorry
      thus "( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B be naturalORDINAL1V7 implies Pp1(B))) implies (A be naturalORDINAL1V7 implies Pp1(A))"
        using ordinal1_def_12 sorry
    qed "sorry"
    have A10: "?P(0ORDINAL1K5)"
      using A1 sorry
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal2_sch_1 A10 A3 A6 sorry
    thus "Pp1(af0)"
       sorry
  qed

mtheorem ordinal2_cl_9:
  mlet "a be NatORDINAL1M6", "b be NatORDINAL1M6"
"cluster a +^ORDINAL2K10 b as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "a +^ORDINAL2K10 b be naturalORDINAL1V7"
  proof-
    let ?P = "\<lambda>Lamb1. a +^ORDINAL2K10 Lamb1 be naturalORDINAL1V7"
    have A1: " for b be NatORDINAL1M6 holds a +^ORDINAL2K10 b be naturalORDINAL1V7 implies a +^ORDINAL2K10 succORDINAL1K1 b be naturalORDINAL1V7"
    proof(rule ballI,rule impI)
      fix b assume [ty]: "b be NatORDINAL1M6"
      assume "?P(b)"
      then obtain c where 
        [ty]:"c be NatORDINAL1M6" and cDef:"c = a +^ORDINAL2K10 b"
         sorry
      have "a +^ORDINAL2K10 succORDINAL1K1 b =XBOOLE-0R4 succORDINAL1K1 c"
        using ordinal2_th_28 sorry
      thus "a +^ORDINAL2K10 succORDINAL1K1 b be naturalORDINAL1V7"
         sorry
    qed "sorry"
    have A2: "?P(0ORDINAL1K5)"
      using ordinal2_th_27 sorry
    show "a +^ORDINAL2K10 b be naturalORDINAL1V7"
      using ordinal2_sch_17 A2 A1 sorry
  qed
qed "sorry"

mtheorem ordinal2_cl_10:
  mlet "x be setHIDDENM2", "y be setHIDDENM2", "a be NatORDINAL1M6", "b be NatORDINAL1M6"
"cluster IFEQFUNCOP-1K15(x,y,a,b) as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
  proof-
    show "IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
    proof-
      have cases: "x =XBOOLE-0R4 y or x <>HIDDENR2 y"
         sorry
      have case1: "x =XBOOLE-0R4 y implies IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
      proof(rule impI)
        assume "x =XBOOLE-0R4 y"
        thus "IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
          using funcop_1_def_8 sorry
      qed
      have case2: "x <>HIDDENR2 y implies IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
      proof(rule impI)
        assume "x <>HIDDENR2 y"
        thus "IFEQFUNCOP-1K15(x,y,a,b) be naturalORDINAL1V7"
          using funcop_1_def_8 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

theorem ordinal2_sch_18:
  fixes Af0 Gf2 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Gf2(x1,x2) be setHIDDENM2"
  shows " ex f be FunctionFUNCT-1M1 st (domRELAT-1K1 f =XBOOLE-0R4 omegaORDINAL1K4 & f .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0) & ( for n be NatORDINAL1M6 holds f .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf2(n,f .FUNCT-1K1 n))"
  proof-
    have " ex tVar32 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar32 =XBOOLE-0R4 omegaORDINAL1K4 & (tVar32 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0 & ( for n be NatORDINAL1M6 holds tVar32 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf2(n,tVar32 .FUNCT-1K1 n)))"
    proof-
      let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. 0ORDINAL1K5"
      obtain L where
        [ty]:"L be SequenceORDINAL1M4" and 
        A1: "domRELAT-1K1 L =XBOOLE-0R4 omegaORDINAL1K4"and A2: "0ORDINAL1K5 inTARSKIR2 omegaORDINAL1K4 implies L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0"and A3: " for A be OrdinalORDINAL1M3 holds succORDINAL1K1 A inTARSKIR2 omegaORDINAL1K4 implies L .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 Gf2(A,L .FUNCT-1K1 A)"and " for A be OrdinalORDINAL1M3 holds (A inTARSKIR2 omegaORDINAL1K4 & A <>HIDDENR2 0ORDINAL1K5) & A be limit-ordinalORDINAL1V4 implies L .FUNCT-1K1 A =XBOOLE-0R4 ?D(A,L  |RELAT-1K8 A)"
        using ordinal2_sch_5 sorry
      show " ex tVar32 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar32 =XBOOLE-0R4 omegaORDINAL1K4 & (tVar32 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0 & ( for n be NatORDINAL1M6 holds tVar32 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf2(n,tVar32 .FUNCT-1K1 n)))"
      proof(rule bexI[of _ "L"],rule conjMI,rule conjMI,rule ballI)
        show "domRELAT-1K1 L =XBOOLE-0R4 omegaORDINAL1K4"
          using A1 sorry
        have "0ORDINAL1K5 inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        thus "L .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0"
          using A2 sorry
        fix n assume [ty]: "n be NatORDINAL1M6"
        have "succORDINAL1K1 n inTARSKIR2 omegaORDINAL1K4"
          using ordinal1_def_12 sorry
        thus "L .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf2(n,L .FUNCT-1K1 n)"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

reserve n for "NatORDINAL1M6"
theorem ordinal2_sch_19:
  fixes Af0 Ff0 Gf0 Pp3 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 omegaORDINAL1K4" and
   A2: "Ff0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0" and
   A3: " for n be NatORDINAL1M6 holds Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 succORDINAL1K1 n)" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 omegaORDINAL1K4" and
   A5: "Gf0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0" and
   A6: " for n be NatORDINAL1M6 holds Pp3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 succORDINAL1K1 n)" and
   A7: " for n be NatORDINAL1M6 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds Pp3(n,x,y1) & Pp3(n,x,y2) implies y1 =XBOOLE-0R4 y2"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    let ?P = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 =XBOOLE-0R4 Gf0 .FUNCT-1K1 Lamb1"
    have A8: " for n be NatORDINAL1M6 holds ?P(n) implies ?P(succORDINAL1K1 n)"
    proof-
      have " for n be NatORDINAL1M6 holds Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n implies Ff0 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 succORDINAL1K1 n"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        assume "Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n"
        then have A9: "Pp3(n,Ff0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 succORDINAL1K1 n)"
          using A6 sorry
        have "Pp3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 succORDINAL1K1 n)"
          using A3 sorry
        thus "Ff0 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 succORDINAL1K1 n"
          using A7 A9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A10: "?P(0ORDINAL1K5)"
      using A2 A5 sorry
    have " for n be NatORDINAL1M6 holds ?P(n)"
    proof-
      have " for n be NatORDINAL1M6 holds Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        show "Ff0 .FUNCT-1K1 n =XBOOLE-0R4 Gf0 .FUNCT-1K1 n"
          using ordinal2_sch_17 A10 A8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be objectHIDDENM1 holds x inHIDDENR3 omegaORDINAL1K4 implies Ff0 .FUNCT-1K1 x =XBOOLE-0R4 Gf0 .FUNCT-1K1 x"
       sorry
    thus "Ff0 =FUNCT-1R1 Gf0"
      using A1 A4 funct_1_th_2 sorry
  qed

theorem ordinal2_sch_20:
  fixes Af0 Ff2 Ff0 Gf0 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be setHIDDENM2 \<Longrightarrow> x2 be setHIDDENM2 \<Longrightarrow> Ff2(x1,x2) be setHIDDENM2" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 omegaORDINAL1K4" and
   A2: "Ff0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0" and
   A3: " for n be NatORDINAL1M6 holds Ff0 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Ff2(n,Ff0 .FUNCT-1K1 n)" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 omegaORDINAL1K4" and
   A5: "Gf0 .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 Af0" and
   A6: " for n be NatORDINAL1M6 holds Gf0 .FUNCT-1K1 succORDINAL1K1 n =XBOOLE-0R4 Ff2(n,Gf0 .FUNCT-1K1 n)"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =XBOOLE-0R4 Ff2(Lamb1,Lamb2)"
    have A7: " for n be NatORDINAL1M6 holds ?P(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 succORDINAL1K1 n)"
      using A6 sorry
    have A8: " for n be NatORDINAL1M6 holds  for x be setHIDDENM2 holds  for y1 be setHIDDENM2 holds  for y2 be setHIDDENM2 holds ?P(n,x,y1) & ?P(n,x,y2) implies y1 =XBOOLE-0R4 y2"
       sorry
    have A9: " for n be NatORDINAL1M6 holds ?P(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 succORDINAL1K1 n)"
      using A3 sorry
    show "Ff0 =FUNCT-1R1 Gf0"
      using ordinal2_sch_19 A1 A2 A9 A4 A5 A7 A8 sorry
  qed

end
