theory fcont_1
  imports square_1 rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve n, m, k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve x, X, X1, Z, Z1 for "setHIDDENM2"
reserve s, g, r, p, x0, x1, x2 for "RealXREAL-0M1"
reserve s1, s2, q1 for "Real-SequenceSEQ-1M1"
reserve Y for "SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mdef fcont_1_def_1 (" _ is-continuous-inFCONT-1R1  _ " [50,50]50 ) where
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "x0 be RealXREAL-0M1"
"pred f is-continuous-inFCONT-1R1 x0 means
   for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0 implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"..

mtheorem fcont_1_th_1:
" for X be setHIDDENM2 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 X & f is-continuous-inFCONT-1R1 x0 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
proof-
  have " for X be setHIDDENM2 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 X & f is-continuous-inFCONT-1R1 x0 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 X"
      and A2: "f is-continuous-inFCONT-1R1 x0"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        and A4: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using relat_1_th_61 sorry
      then have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 xboole_1_th_18 sorry
      have A6: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 funct_2_th_117 sorry
      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A4 A5 sorry
      have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =HIDDENR1 f .FUNCT-1K1 x0"
        using A1 funct_1_th_49 sorry
      also have "... = limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A4 A5 A6 sorry
      finally show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_2:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 iff ( for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-continuous-inFCONT-1R1 x0 implies ( for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)) & (( for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) implies f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-continuous-inFCONT-1R1 x0 implies ( for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
       sorry
    assume A1: " for s1 be Real-SequenceSEQ-1M1 holds ((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 x0) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    have " for s2 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
    proof(rule ballI,rule impMI ,rule impI)
      fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
      assume A2: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A3: "s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 x0"
      have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
      proof-
        show "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
        proof-
          have cases: "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 m implies s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =COMPLEX1R1 x0) or ( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0)"
             sorry
          have case1: "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 m implies s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
          proof(rule impI)
            assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <=XXREAL-0R1 m implies s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =COMPLEX1R1 x0"
            then obtain N where
              [ty]:"N be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A4: " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds N <=XXREAL-0R1 m implies s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m =COMPLEX1R1 x0"
               sorry
            have A5: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 N) =COMPLEX1R1 x0"
                using A4 nat_1_th_12 sorry
              thus "(s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
                using nat_1_def_3 sorry
            qed "sorry"
            have A6: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N"
              using A2 valued_0_th_27 sorry
            have A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2"
              using valued_0_th_21 sorry
            have A8: " for p be RealXREAL-0M1 holds p >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p)"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              assume A9: "p >XXREAL-0R4 0NUMBERSK6"
              obtain zz where 
                [ty]:"zz be NatNAT-1M1" and zzDef:"zz = 0NUMBERSK6"
                 sorry
              obtain n where 
                [ty]:"n be NatNAT-1M1" and nDef:"n = zz"
                 sorry
              show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
              proof(rule bexI[of _ "n"],rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume "n <=XXREAL-0R1 m"
                have A10: "m inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 ((s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N).FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                  using A2 A7 funct_2_th_108 xboole_1_th_1 sorry
                also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                  using A5 A10 sorry
                also have "... = 0NUMBERSK6"
                  using absvalue_th_2 sorry
                finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1 0NUMBERSK6"
                   sorry
                thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                  using A9 sorry
              qed "sorry"
            qed "sorry"
            then have A11: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N) be convergentSEQ-2V5"
              using seq_2_def_6 sorry
            then have "f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> N)"
              using A8 A6 seq_2_def_7 sorry
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
              using A11 A6 seq_4_th_20 seq_4_th_21 sorry
          qed
          have case2: "( for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
          proof(rule impI,rule conjMI)
            assume A12: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <=XXREAL-0R1 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0"
            let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3.  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds Lamb2 =XBOOLE-0R4 n & Lamb3 =XBOOLE-0R4 m implies (n <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds n <XXREAL-0R3 k & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k)"
            let ?P1 = "\<lambda>Lamb1. s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0"
            have " ex m1 be ElementSUBSET-1M1-of NATNUMBERSK1 st 0NUMBERSK6 <=XXREAL-0R1 m1 & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m1 <>HIDDENR2 x0"
              using A12 sorry
            then have A13: " ex m be NatNAT-1M1 st ?P1(m)"
               sorry
            obtain M where
              [ty]:"M be NatNAT-1M1" and 
              A14: "?P1(M) & ( for n be NatNAT-1M1 holds ?P1(n) implies M <=XXREAL-0R1 n)"
              using nat_1_sch_5 A13 sorry
            obtain M9 where 
              [ty]:"M9 be ElementSUBSET-1M1-of NATNUMBERSK1" and M9Def:"M9 = M"
              using ordinal1_def_12 sorry
            have A15: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              obtain m where
                [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                A16: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0"
                using A12 sorry
              show " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st n <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0"
              proof(rule bexI[of _ "m"])
                show "n <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0"
                  using A16 nat_1_th_13 sorry
              qed "sorry"
            qed "sorry"
            have A17: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex y be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P(n,x,y)"
            proof-
              have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & tVar3 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
              proof(rule ballI,rule ballI)
                fix n assume [ty]: "n be NatNAT-1M1"
                fix x assume [ty]: "x be ElementSUBSET-1M1-of NATNUMBERSK1"
                let ?P2 = "\<lambda>Lamb1. x <XXREAL-0R3 Lamb1 & s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0"
                have " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P2(m)"
                  using A15 sorry
                then have A18: " ex m be NatNAT-1M1 st ?P2(m)"
                   sorry
                obtain l where
                  [ty]:"l be NatNAT-1M1" and 
                  A19: "?P2(l) & ( for k be NatNAT-1M1 holds ?P2(k) implies l <=XXREAL-0R1 k)"
                  using nat_1_sch_5 A18 sorry
                show " ex tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & tVar3 =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
                proof(rule bexI[of _ "l"])
                  have "l inTARSKIR2 NATNUMBERSK1"
                    using ordinal1_def_12 sorry
                  thus "l be ElementSUBSET-1M1-of NATNUMBERSK1 & ( for nc be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds x =XBOOLE-0R4 nc & l =XBOOLE-0R4 m implies (nc <XXREAL-0R3 m & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> m <>HIDDENR2 x0) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds nc <XXREAL-0R3 k & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0 implies m <=XXREAL-0R1 k))"
                    using A19 sorry
                qed "sorry"
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain F where
              [ty]:"F be sequenceNAT-1M2-of NATNUMBERSK1" and 
              A20: "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M9 & ( for n be NatNAT-1M1 holds ?P(n,F .RECDEF-1K1 n,F .RECDEF-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
              using recdef_1_sch_2 A17 sorry
            have A21: "rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> F c=TARSKIR1 REALNUMBERSK2"
              using numbers_th_19 sorry
            have A22: "rngRELSET-1K2\<^bsub>(NATNUMBERSK1)\<^esub> F c=TARSKIR1 NATNUMBERSK1"
               sorry
            have A23: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> F =XBOOLE-0R4 NATNUMBERSK1"
              using funct_2_def_1 sorry
            then have 
              [ty]:"F be Real-SequenceSEQ-1M1"
              using A21 relset_1_th_4 sorry
            have A24: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> F"
                using A23 funct_1_def_3 sorry
              thus "F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A22 sorry
            qed "sorry"
            have " for n be NatNAT-1M1 holds F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
            proof(rule ballI)
              fix n assume [ty]: "n be NatNAT-1M1"
              have "n inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have "F .FUNCT-1K1 n be ElementSUBSET-1M1-of NATNUMBERSK1 & F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) be ElementSUBSET-1M1-of NATNUMBERSK1"
                using A24 sorry
              thus "F .FUNCT-1K1 n <XXREAL-0R3 F .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
                using A20 sorry
            qed "sorry"
            then have 
              [ty]:"F be increasingVALUED-0V9\<bar>sequenceNAT-1M2-of NATNUMBERSK1"
              using seqm_3_def_6 sorry
            have A25: "s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F be convergentSEQ-2V5 & limSEQ-2K1 (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) =COMPLEX1R1 x0"
              using A3 seq_4_th_16 seq_4_th_17 sorry
            have A26: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n <>HIDDENR2 x0 implies ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 n)"
            proof-
              have "( ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st s2 .FUNCT-1K1 n <>HIDDENR2 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 n)) implies  False "
              proof(rule impI)
                let ?P3 = "\<lambda>Lamb1. s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0 & ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 Lamb1)"
                assume " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st ?P3(n)"
                then have A27: " ex n be NatNAT-1M1 st ?P3(n)"
                   sorry
                obtain M1 where
                  [ty]:"M1 be NatNAT-1M1" and 
                  A28: "?P3(M1) & ( for n be NatNAT-1M1 holds ?P3(n) implies M1 <=XXREAL-0R1 n)"
                  using nat_1_sch_5 A27 sorry
                let ?P4 = "\<lambda>Lamb1. (Lamb1 <XXREAL-0R3 M1 & s2 .FUNCT-1K1 Lamb1 <>HIDDENR2 x0) & ( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 Lamb1)"
                have A29: " ex n be NatNAT-1M1 st ?P4(n)"
                proof-
                  have " ex tVar4 be NatNAT-1M1 st tVar4 <XXREAL-0R3 M1 & (s2 .FUNCT-1K1 tVar4 <>HIDDENR2 x0 & ( ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar5 =COMPLEX1R1 tVar4))"
                  proof-
                    show " ex tVar4 be NatNAT-1M1 st tVar4 <XXREAL-0R3 M1 & (s2 .FUNCT-1K1 tVar4 <>HIDDENR2 x0 & ( ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar5 =COMPLEX1R1 tVar4))"
                    proof(rule bexI[of _ "M"],rule conjMI,rule conjMI)
                      have "M <=XXREAL-0R1 M1 & M <>HIDDENR2 M1"
                        using A14 A20 A28 sorry
                      thus "M <XXREAL-0R3 M1"
                        using xxreal_0_th_1 sorry
                      show "s2 .FUNCT-1K1 M <>HIDDENR2 x0"
                        using A14 sorry
                      show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 tVar5 =COMPLEX1R1 M"
                      proof(rule bexI[of _ "0NUMBERSK6"])
                        show "F .RECDEF-1K1 (0NUMBERSK6) =COMPLEX1R1 M"
                          using A20 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  thus " ?thesis "
                     sorry
                qed
                have A30: " for n be NatNAT-1M1 holds ?P4(n) implies n <=XXREAL-0R1 M1"
                   sorry
                obtain MX where
                  [ty]:"MX be NatNAT-1M1" and 
                  A31: "?P4(MX) & ( for n be NatNAT-1M1 holds ?P4(n) implies n <=XXREAL-0R1 MX)"
                  using nat_1_sch_6 A30 A29 sorry
                have A32: " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds MX <XXREAL-0R3 k & k <XXREAL-0R3 M1 implies s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k =COMPLEX1R1 x0"
                proof-
                  have "( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0)) implies  False "
                  proof(rule impI)
                    assume Given: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st MX <XXREAL-0R3 k & (k <XXREAL-0R3 M1 & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0)"
                    then obtain k where
                      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                      A33: "MX <XXREAL-0R3 k"and A34: "k <XXREAL-0R3 M1 & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> k <>HIDDENR2 x0"
                       sorry
                    have " False "
                    proof-
                      show " False "
                      proof-
                        have cases: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) or ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k)"
                           sorry
                        have case1: "( ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k) implies  False "
                        proof(rule impI)
                          assume " ex m be ElementSUBSET-1M1-of NATNUMBERSK1 st F .RECDEF-1K1 m =COMPLEX1R1 k"
                          thus " False "
                            using A31 A33 A34 sorry
                        qed
                        have case2: "( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k) implies  False "
                        proof(rule impI)
                          assume " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds F .RECDEF-1K1 m <>HIDDENR2 k"
                          thus " False "
                            using A28 A34 sorry
                        qed
                        show " ?thesis "
                          using cases case1 case2 sorry
                      qed
                    qed
                    thus " False "
                       sorry
                  qed
                  thus " ?thesis "
                     sorry
                qed
                obtain m where
                  [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                  A35: "F .RECDEF-1K1 m =COMPLEX1R1 MX"
                  using A31 sorry
                have A36: "MX <XXREAL-0R3 F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) & s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M)) <>HIDDENR2 x0"
                  using A20 A35 sorry
                have "M1 inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                then have A37: "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 M1"
                  using A20 A28 A31 A35 sorry
                have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1 implies  False "
                proof(rule impI)
                  assume "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 M1"
                  then have "F .RECDEF-1K1 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 M1"
                    using A37 xxreal_0_th_1 sorry
                  thus " False "
                    using A32 A36 sorry
                qed
                thus " False "
                  using A28 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            have A38: " for n be NatNAT-1M1 holds (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 n <>HIDDENR2 x0"
            proof-
              let ?P4 = "\<lambda>Lamb1. (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 Lamb1 <>HIDDENR2 x0"
              have A39: " for k be NatNAT-1M1 holds ?P4(k) implies ?P4(k +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have " for k be NatNAT-1M1 holds (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <>HIDDENR2 x0 implies (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 x0"
                proof(rule ballI,rule impI)
                  fix k assume [ty]: "k be NatNAT-1M1"
                  assume "(s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 k <>HIDDENR2 x0"
                  have 
                    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1"
                    using ordinal1_def_12 sorry
                  have "?P(k,F .RECDEF-1K1 k,F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M))"
                    using A20 sorry
                  then have "s2 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (F .RECDEF-1K1 (k +NAT-1K1 \<one>\<^sub>M)) <>HIDDENR2 x0"
                     sorry
                  thus "(s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 x0"
                    using funct_2_th_15 sorry
                qed "sorry"
                thus " ?thesis "
                   sorry
              qed
              have A40: "?P4(0NUMBERSK6)"
                using A14 A20 funct_2_th_15 sorry
              show " for n be NatNAT-1M1 holds (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-1K1 n <>HIDDENR2 x0"
                using nat_1_sch_2 A40 A39 sorry
            qed
            have A41: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2"
              using valued_0_th_21 sorry
            then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A2 sorry
            then have A42: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F)"
              using A1 A38 A25 sorry
            have A43: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p)"
            proof(rule ballI,rule impI)
              fix p assume [ty]: "p be RealXREAL-0M1"
              assume A44: "0NUMBERSK6 <XXREAL-0R3 p"
              then obtain n where
                [ty]:"n be NatNAT-1M1" and 
                A45: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                using A42 seq_2_def_7 sorry
              obtain k where 
                [ty]:"k be NatNAT-1M1" and kDef:"k = F .RECDEF-1K1 n"
                 sorry
              show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
              proof(rule bexI[of _ "k"],rule ballI,rule impI)
                fix m assume [ty]: "m be NatNAT-1M1"
                assume A46: "k <=XXREAL-0R1 m"
                have A47: "m inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                proof-
                  show " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                  proof-
                    have cases: "s2 .FUNCT-1K1 m =COMPLEX1R1 x0 or s2 .FUNCT-1K1 m <>HIDDENR2 x0"
                       sorry
                    have case1: "s2 .FUNCT-1K1 m =COMPLEX1R1 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                    proof(rule impI)
                      assume "s2 .FUNCT-1K1 m =COMPLEX1R1 x0"
                      then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x0 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
                        using A2 funct_2_th_108 A47 sorry
                      also have "... = 0NUMBERSK6"
                        using absvalue_th_2 sorry
                      finally have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1 0NUMBERSK6"
                         sorry
                      thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                        using A44 sorry
                    qed
                    have case2: "s2 .FUNCT-1K1 m <>HIDDENR2 x0 implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                    proof(rule impI)
                      assume "s2 .FUNCT-1K1 m <>HIDDENR2 x0"
                      then obtain l where
                        [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1" and 
                        A48: "m =COMPLEX1R1 F .RECDEF-1K1 l"
                        using A26 A47 sorry
                      have "n <=XXREAL-0R1 l"
                        using A46 A48 seqm_3_th_1 sorry
                      then have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                        using A45 sorry
                      then have " |.COMPLEX1K10 f .FUNCT-1K1 ((s2 *VALUED-0K2\<^bsub>(REALNUMBERSK2)\<^esub> F).FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> l) -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                        using A2 A41 funct_2_th_108 xboole_1_th_1 sorry
                      then have " |.COMPLEX1K10 f .FUNCT-1K1 (s2 .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                        using A48 funct_2_th_15 sorry
                      thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                        using A2 funct_2_th_108 A47 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
                   sorry
              qed "sorry"
            qed "sorry"
            thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
              using seq_2_def_6 sorry
            thus "f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
              using A43 seq_2_def_7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
         sorry
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_3:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 iff ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f is-continuous-inFCONT-1R1 x0 implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))) & (( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))) implies f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f is-continuous-inFCONT-1R1 x0 implies ( for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
    proof-
      have "f is-continuous-inFCONT-1R1 x0 implies (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be RealXREAL-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))) implies  False )"
      proof(rule impI,rule impI)
        assume A1: "f is-continuous-inFCONT-1R1 x0"
        assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be RealXREAL-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
        then obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: " for s be RealXREAL-0M1 holds  not 0NUMBERSK6 <XXREAL-0R3 s or ( ex x1 be RealXREAL-0M1 st (x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
           sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 Lamb2 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 Lamb2 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
        have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar7 be setHIDDENM2 & tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2) & ((tVar7 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 tVar7 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 tVar7 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "0NUMBERSK6 <XXREAL-0R3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
               sorry
            then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
              using xcmplx_1_th_215 sorry
            then obtain p where
              [ty]:"p be RealXREAL-0M1" and 
              A5: "(p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 p -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 p -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
              using A3 sorry
            show " ex tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2 st (tVar7 be setHIDDENM2 & tVar7 be ElementSUBSET-1M1-of REALNUMBERSK2) & ((tVar7 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 tVar7 -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 tVar7 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
            proof(rule bexI[of _ "p"])
              show "(p be setHIDDENM2 & p be ElementSUBSET-1M1-of REALNUMBERSK2) & ((p inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 p -XCMPLX-0K6 x0 .| <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 p -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
                using A5 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using funct_2_sch_3 A4 sorry
        have A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
            then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using funct_2_th_113 sorry
            thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              using A6 sorry
          qed "sorry"
          thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using tarski_def_3 sorry
        qed
        have A8: " for n be NatNAT-1M1 holds  not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A9: "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have " not  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-1K1 n) -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A6 A9 sorry
          thus " not  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A7 funct_2_th_108 A9 sorry
        qed "sorry"
        have A10: " for s be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 s implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s)"
        proof(rule ballI,rule impI)
          fix s assume [ty]: "s be RealXREAL-0M1"
          assume A11: "0NUMBERSK6 <XXREAL-0R3 s"
          obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A12: "s \<inverse>XCMPLX-0K5 <XXREAL-0R3 n"
            using seq_4_th_3 sorry
          have "s \<inverse>XCMPLX-0K5 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
            using A12 xreal_1_th_8 sorry
          then have "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 s \<inverse>XCMPLX-0K5"
            using A11 xreal_1_th_76 sorry
          then have A13: "\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
            using xcmplx_1_th_216 sorry
          obtain k where 
            [ty]:"k be NatNAT-1M1" and kDef:"k = n"
             sorry
          show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          proof(rule bexI[of _ "k"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            have A14: "m inTARSKIR2 NATNUMBERSK1"
              using ordinal1_def_12 sorry
            assume "k <=XXREAL-0R1 m"
            then have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 (k +NAT-1K1 \<one>\<^sub>M)"
              using xreal_1_th_118 sorry
            then have "\<one>\<^sub>M /XCMPLX-0K7 (m +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 s"
              using A13 xxreal_0_th_2 sorry
            thus " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
              using A6 xxreal_0_th_2 A14 sorry
          qed "sorry"
        qed "sorry"
        then have A15: "s1 be convergentSEQ-2V5"
          using seq_2_def_6 sorry
        then have "limSEQ-2K1 s1 =COMPLEX1R1 x0"
          using A10 seq_2_def_7 sorry
        then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A1 A7 A15 sorry
        then obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A16: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          using A2 seq_2_def_7 sorry
        have " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          using A16 sorry
        thus " False "
          using A8 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A17: " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        and A19: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A20: " for p be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 p implies ( ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p)"
      proof(rule ballI,rule impI)
        fix p assume [ty]: "p be RealXREAL-0M1"
        assume "0NUMBERSK6 <XXREAL-0R3 p"
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A21: "0NUMBERSK6 <XXREAL-0R3 s"and A22: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
          using A17 sorry
        obtain n where
          [ty]:"n be NatNAT-1M1" and 
          A23: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          using A19 A21 seq_2_def_7 sorry
        obtain k where 
          [ty]:"k be NatNAT-1M1" and kDef:"k = n"
           sorry
        show " ex k be NatNAT-1M1 st  for m be NatNAT-1M1 holds k <=XXREAL-0R1 m implies  |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
        proof(rule bexI[of _ "k"],rule ballI,rule impI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have A24: "m inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          assume "k <=XXREAL-0R1 m"
          then have "s1 .FUNCT-1K1 m inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 &  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            using A23 valued_0_th_28 sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
            using A18 A22 sorry
          thus " |.COMPLEX1K10 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 p"
            using A18 funct_2_th_108 A24 sorry
        qed "sorry"
      qed "sorry"
      then have "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using seq_2_def_6 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A20 seq_2_def_7 sorry
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_4:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-continuous-inFCONT-1R1 x0 iff ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds (f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1)) & (( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1) implies f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    show "f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1)"
    proof-
      have "f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex tVar10 be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 tVar10 implies f .FUNCT-1K1 x1 inTARSKIR2 N1)"
      proof(rule impI,rule ballI)
        assume A1: "f is-continuous-inFCONT-1R1 x0"
        fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0"
        obtain r where
          [ty]:"r be RealXREAL-0M1" and 
          A2: "0NUMBERSK6 <XXREAL-0R3 r"and A3: "N1 =XBOOLE-0R4 ].RCOMP-1K2 f .FUNCT-1K1 x0 -XCMPLX-0K6 r,f .FUNCT-1K1 x0 +XCMPLX-0K2 r .["
          using rcomp_1_def_6 sorry
        obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A4: "0NUMBERSK6 <XXREAL-0R3 s"and A5: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          using A1 A2 fcont_1_th_3 sorry
        obtain N where 
          [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 s,x0 +XCMPLX-0K2 s .["
          using A4 rcomp_1_def_6 sorry
        show " ex tVar10 be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 tVar10 implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
        proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          assume A6: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            and A7: "x1 inHIDDENR3 N"
          have " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            using A7 rcomp_1_th_1 sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A5 A6 sorry
          thus "f .FUNCT-1K1 x1 inTARSKIR2 N1"
            using A3 rcomp_1_th_1 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A8: " for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
    have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "0NUMBERSK6 <XXREAL-0R3 r"
      then obtain N1 where 
        [ty]:"N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0" and N1Def:"N1 = ].RCOMP-1K2 f .FUNCT-1K1 x0 -XCMPLX-0K6 r,f .FUNCT-1K1 x0 +XCMPLX-0K2 r .["
        using rcomp_1_def_6 sorry
      obtain N2 where
        [ty]:"N2 be NeighbourhoodRCOMP-1M1-of x0" and 
        A9: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N2 implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
        using A8 sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A10: "0NUMBERSK6 <XXREAL-0R3 s"and A11: "N2 =XBOOLE-0R4 ].RCOMP-1K2 x0 -XCMPLX-0K6 s,x0 +XCMPLX-0K2 s .["
        using rcomp_1_def_6 sorry
      show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"])
        have " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
        proof-
          have " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          proof(rule ballI,rule impMI ,rule impI)
            fix x1 assume [ty]: "x1 be RealXREAL-0M1"
            assume A12: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
              and A13: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            have "x1 inHIDDENR3 N2"
              using A11 A13 rcomp_1_th_1 sorry
            then have "f .FUNCT-1K1 x1 inTARSKIR2 N1"
              using A9 A12 sorry
            thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
              using rcomp_1_th_1 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
          using A10 sorry
      qed "sorry"
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
      using fcont_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_5:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds f is-continuous-inFCONT-1R1 x0 iff ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1)"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for x0 be RealXREAL-0M1 holds (f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1)) & (( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1) implies f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    show "f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1)"
    proof-
      have "f is-continuous-inFCONT-1R1 x0 implies ( for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex tVar12 be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar12 c=TARSKIR1 N1)"
      proof(rule impI,rule ballI)
        assume A1: "f is-continuous-inFCONT-1R1 x0"
        fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0"
        obtain N where
          [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
          A2: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
          using A1 fcont_1_th_4 sorry
        show " ex tVar12 be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> tVar12 c=TARSKIR1 N1"
        proof(rule bexI[of _ "N"])
          have " for r be RealXREAL-0M1 holds r inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N implies r inHIDDENR3 N1"
          proof(rule ballI,rule impI)
            fix r assume [ty]: "r be RealXREAL-0M1"
            assume "r inHIDDENR3 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N"
            then have " ex x be ElementSUBSET-1M1-of REALNUMBERSK2 st (x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x inTARSKIR2 N) & r =COMPLEX1R1 f .FUNCT-1K1 x"
              using partfun2_th_59 sorry
            thus "r inHIDDENR3 N1"
              using A2 sorry
          qed "sorry"
          thus "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
             sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A3: " for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
    have " for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
    proof(rule ballI)
      fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0"
      obtain N where
        [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
        A4: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
        using A3 sorry
      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N implies f .FUNCT-1K1 x1 inTARSKIR2 N1"
      proof(rule bexI[of _ "N"],rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x1 inHIDDENR3 N"
        then have "f .FUNCT-1K1 x1 inTARSKIR2 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N"
          using funct_1_def_6 sorry
        thus "f .FUNCT-1K1 x1 inTARSKIR2 N1"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
      using fcont_1_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_6:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N =XBOOLE-0R4 {SEQ-4K1 x0}) implies f is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex N be NeighbourhoodRCOMP-1M1-of x0 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N =XBOOLE-0R4 {SEQ-4K1 x0}) implies f is-continuous-inFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume Given: " ex N be NeighbourhoodRCOMP-1M1-of x0 st domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N =XBOOLE-0R4 {SEQ-4K1 x0}"
    then obtain N where
      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
      A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N =XBOOLE-0R4 {SEQ-4K1 x0}"
       sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> N"
      using A1 tarski_def_1 sorry
    then have A2: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using xboole_0_def_4 sorry
    have " for N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
    proof(rule ballI)
      fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of f .FUNCT-1K1 x0"
      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
      proof(rule bexI[of _ "N"])
        have A3: "f .FUNCT-1K1 x0 inTARSKIR2 N1"
          using rcomp_1_th_16 sorry
        have "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N =HIDDENR1 ImRELAT-1K12(f,x0)"
          using A1 relat_1_th_112 sorry
        also have "... = {SEQ-4K1 f .FUNCT-1K1 x0 }"
          using A2 funct_1_th_59 sorry
        finally have "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N =HIDDENR1 {SEQ-4K1 f .FUNCT-1K1 x0 }"
           sorry
        thus "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> N c=TARSKIR1 N1"
          using A3 zfmisc_1_th_31 sorry
      qed "sorry"
    qed "sorry"
    thus "f is-continuous-inFCONT-1R1 x0"
      using fcont_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_7:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1 is-continuous-inFCONT-1R1 x0) & f2 is-continuous-inFCONT-1R1 x0 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0 & f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0) & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1 is-continuous-inFCONT-1R1 x0 & f2 is-continuous-inFCONT-1R1 x0 implies f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0 & f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    assume A2: "f1 is-continuous-inFCONT-1R1 x0"
      and A3: "f2 is-continuous-inFCONT-1R1 x0"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        and A5: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A4 valued_1_def_1 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A4 sorry
      then have A8: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A5 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_1 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A9: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A4 sorry
      then have A10: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A5 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A8 sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A6 rfunct_2_th_8 sorry
      have A11: "f1 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A5 A9 sorry
      have A12: "f2 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A5 A7 sorry
      have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 valued_1_def_1 sorry
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x0 +XCMPLX-0K2 f2 .FUNCT-1K1 x0"
        using valued_1_def_1 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A10 A11 A8 A12 seq_2_th_6 sorry
      also have "... = limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A6 rfunct_2_th_8 sorry
      finally show "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0"
       sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A13: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        and A14: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A15: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A13 valued_1_th_12 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_th_12 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A13 sorry
      then have A17: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A14 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_th_12 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A13 sorry
      then have A19: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A14 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A17 sorry
      thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A15 rfunct_2_th_8 sorry
      have A20: "f1 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A14 A18 sorry
      have A21: "f2 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A14 A16 sorry
      have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        using A1 valued_1_th_12 sorry
      then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x0 -XCMPLX-0K6 f2 .FUNCT-1K1 x0"
        using valued_1_th_13 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A19 A20 A17 A21 seq_2_th_12 sorry
      also have "... = limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A15 rfunct_2_th_8 sorry
      finally show "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0"
       sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A22: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        and A23: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_4 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_17 sorry
      then have A24: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A22 sorry
      then have A25: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A23 sorry
      have A26: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A22 valued_1_def_4 sorry
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_4 sorry
      then have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using xboole_1_th_17 sorry
      then have A27: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A22 sorry
      then have A28: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A23 sorry
      then have "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A25 sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A26 rfunct_2_th_8 sorry
      have A29: "f1 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A23 A27 sorry
      have A30: "f2 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A23 A24 sorry
      have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 f2 .FUNCT-1K1 x0"
        using valued_1_th_5 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A28 A29 A25 A30 seq_2_th_15 sorry
      also have "... = limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A26 rfunct_2_th_8 sorry
      finally show "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_8:
" for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-continuous-inFCONT-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
proof-
  have " for r be RealXREAL-0M1 holds  for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-continuous-inFCONT-1R1 x0 implies r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    then have A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    assume A2: "f is-continuous-inFCONT-1R1 x0"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        and A4: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 valued_1_def_5 sorry
      then have A6: "f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A4 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A4 A5 sorry
      then have "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
         sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A5 rfunct_2_th_9 sorry
      have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 r *XCMPLX-0K3 f .FUNCT-1K1 x0"
        using A1 valued_1_def_5 sorry
      also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A7 A6 seq_2_th_8 sorry
      also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A5 rfunct_2_th_9 sorry
      finally show "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_9:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f is-continuous-inFCONT-1R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0 & -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f is-continuous-inFCONT-1R1 x0 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0 & -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f is-continuous-inFCONT-1R1 x0"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
        and A4: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A3 valued_1_def_11 sorry
      then have A6: "f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A4 sorry
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A2 A4 A5 sorry
      then have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) be convergentSEQ-2V5"
        using seq_4_th_13 sorry
      thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A5 rfunct_2_th_10 sorry
      have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x0 =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x0.|"
        using valued_1_th_18 sorry
      also have "... = limSEQ-2K1 absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A7 A6 seq_4_th_14 sorry
      also have "... = limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A5 rfunct_2_th_10 sorry
      finally show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
       sorry
    show "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 x0"
      using A1 A2 fcont_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_10:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f is-continuous-inFCONT-1R1 x0 & f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 implies f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 x0"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f is-continuous-inFCONT-1R1 x0"
      and A2: "f .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
    have " not f .FUNCT-1K1 x0 inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
      using A2 tarski_def_1 sorry
    then have A3: " not x0 inHIDDENR3 f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
      using funct_1_def_7 sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI,rule conjMI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        and A5: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using A4 rfunct_1_def_2 xboole_1_th_36 sorry
      then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
         sorry
      then have A6: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A1 A5 sorry
      then have "(f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
        using A2 A4 rfunct_2_th_11 seq_2_th_21 sorry
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A4 rfunct_2_th_12 sorry
      have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A2 funct_1_def_2 sorry
      then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
        using A3 xboole_0_def_5 sorry
      then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using rfunct_1_def_2 sorry
      then have "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x0 =HIDDENR1 (f .FUNCT-1K1 x0)\<inverse>XCMPLX-0K5"
        using rfunct_1_def_2 sorry
      also have "... = limSEQ-2K1 (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
        using A2 A4 A6 rfunct_2_th_11 seq_2_th_22 sorry
      also have "... = limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A4 rfunct_2_th_12 sorry
      finally show "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x0 =HIDDENR1 limSEQ-2K1 (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
    qed "sorry"
    thus "f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_11:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1 is-continuous-inFCONT-1R1 x0) & f1 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6) & f2 is-continuous-inFCONT-1R1 x0 implies f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1 is-continuous-inFCONT-1R1 x0 & (f1 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6 & f2 is-continuous-inFCONT-1R1 x0) implies f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    assume A2: "f1 is-continuous-inFCONT-1R1 x0"
      and A3: "f1 .FUNCT-1K1 x0 <>HIDDENR2 0NUMBERSK6"
      and A4: "f2 is-continuous-inFCONT-1R1 x0"
    have " not f1 .FUNCT-1K1 x0 inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
      using A3 tarski_def_1 sorry
    then have A5: " not x0 inHIDDENR3 f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
      using funct_1_def_7 sorry
    have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      using A3 funct_1_def_2 sorry
    then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 }"
      using A5 xboole_0_def_5 sorry
    then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    then have A6: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A1 xboole_0_def_4 sorry
    have "f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-continuous-inFCONT-1R1 x0"
      using A2 A3 fcont_1_th_10 sorry
    then have "f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-continuous-inFCONT-1R1 x0"
      using A4 A6 fcont_1_th_7 sorry
    thus "f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
      using rfunct_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_12:
" for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & f1 is-continuous-inFCONT-1R1 x0) & f2 is-continuous-inFCONT-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
proof-
  have " for x0 be RealXREAL-0M1 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies (f1 is-continuous-inFCONT-1R1 x0 & f2 is-continuous-inFCONT-1R1 f1 .FUNCT-1K1 x0 implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix x0 assume [ty]: "x0 be RealXREAL-0M1"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
    assume A2: "f1 is-continuous-inFCONT-1R1 x0"
      and A3: "f2 is-continuous-inFCONT-1R1 f1 .FUNCT-1K1 x0"
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0) implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        and A5: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x0"
      have A6: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using relat_1_th_25 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A7: "x =HIDDENR1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using funct_2_th_113 sorry
        have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
          using valued_0_th_28 sorry
        then have "f1 .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A4 funct_1_th_11 sorry
        thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A4 A6 A7 funct_2_th_108 xboole_1_th_1 sorry
      qed "sorry"
      then have A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
         sorry
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
          using valued_0_th_28 sorry
        then have A9: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A4 funct_1_th_11 sorry
        have "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A4 funct_2_th_108 sorry
        also have "... = f2 .FUNCT-1K1 (f1 .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))"
          using A9 funct_1_th_13 sorry
        also have "... = f2 .FUNCT-1K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
          using A4 A6 funct_2_th_108 xboole_1_th_1 sorry
        also have "... = f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          using A8 funct_2_th_108 sorry
        finally show "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
           sorry
      qed "sorry"
      then have A10: "f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using funct_2_th_63 sorry
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
        using A4 A6 sorry
      then have A11: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f1 .FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A2 A5 sorry
      then have "f2 .FUNCT-1K1 (f1 .FUNCT-1K1 x0) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A3 A8 sorry
      thus "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1).FUNCT-1K1 x0 =COMPLEX1R1 limSEQ-2K1 (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A1 A3 A11 A8 A10 funct_1_th_12 sorry
    qed "sorry"
    thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
      using fcont_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fcont_1_def_2 ("continuousFCONT-1V1" 70 ) where
"attr continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-continuous-inFCONT-1R1 x0)"..

mtheorem fcont_1_th_13:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff ( for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1))"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)) & (( for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
    proof-
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for s1 be Real-SequenceSEQ-1M1 holds  not (((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X) &  not (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)))"
      proof(rule impI)
        assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X) implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        proof(rule ballI,rule impMI ,rule impMI ,rule impI)
          fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
          assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X"
            and A4: "s1 be convergentSEQ-2V5"
            and A5: "limSEQ-2K1 s1 inHIDDENR3 X"
          have A6: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
            using relat_1_th_61 sorry
          also have "... = X"
            using A1 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X"
             sorry
          then have A7: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 limSEQ-2K1 s1"
            using A2 A5 sorry
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have A8: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
              using valued_0_th_28 sorry
            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A3 A6 funct_2_th_108 sorry
            also have "... = f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
              using A3 A6 A8 funct_1_th_47 sorry
            also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
              using A1 A3 funct_2_th_108 xboole_1_th_1 sorry
            finally show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
               sorry
          qed "sorry"
          then have A9: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
            using funct_2_th_63 sorry
          have "f .FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (limSEQ-2K1 s1)"
            using A5 A6 funct_1_th_47 sorry
          also have "... = limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
            using A3 A4 A6 A7 A9 sorry
          finally have "f .FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
             sorry
          thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
            using A3 A4 A6 A7 A9 sorry
        qed "sorry"
        thus " for s1 be Real-SequenceSEQ-1M1 holds  not (((rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X) &  not (f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume A10: " for s1 be Real-SequenceSEQ-1M1 holds (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & s1 be convergentSEQ-2V5) & limSEQ-2K1 s1 inHIDDENR3 X implies f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    have " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x1"
    proof(rule ballI,rule impI)
      have A11: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
        using relat_1_th_61 sorry
      also have "... = X"
        using A1 xboole_1_th_28 sorry
      finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X"
         sorry
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      assume A12: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 x1) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A13: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          and A14: "s1 be convergentSEQ-2V5"
          and A15: "limSEQ-2K1 s1 =COMPLEX1R1 x1"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A16: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
            using valued_0_th_28 sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A13 funct_2_th_108 sorry
          also have "... = f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A13 A16 funct_1_th_47 sorry
          also have "... = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using A1 A11 A13 funct_2_th_108 xboole_1_th_1 sorry
          finally show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
             sorry
        qed "sorry"
        then have A17: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using funct_2_th_63 sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 f .FUNCT-1K1 (limSEQ-2K1 s1)"
          using A12 A15 funct_1_th_47 sorry
        also have "... = limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A10 A12 A11 A13 A14 A15 A17 sorry
        finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
           sorry
        thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A10 A12 A11 A13 A14 A15 A17 sorry
      qed "sorry"
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x1"
         sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_14:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff ( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))))"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))) & (( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
    proof-
      have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ( for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar15 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar15 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar15 implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
      proof(rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
        assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A3: "x0 inHIDDENR3 X"
          and A4: "0NUMBERSK6 <XXREAL-0R3 r"
        have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A1 A3 relat_1_th_62 sorry
        then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using A2 sorry
        then obtain s where
          [ty]:"s be RealXREAL-0M1" and 
          A5: "0NUMBERSK6 <XXREAL-0R3 s"and A6: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r"
          using A4 fcont_1_th_3 sorry
        show " ex tVar15 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar15 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar15 implies  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
            using A5 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          assume A7: "x1 inHIDDENR3 X"
            and A8: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          have A9: "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
            using relat_1_th_61 sorry
          also have "... = X"
            using A1 xboole_1_th_28 sorry
          finally have "domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =HIDDENR1 X"
             sorry
          then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
            using A7 funct_1_th_47 sorry
          also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .|"
            using A3 A9 funct_1_th_47 sorry
          finally have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .|"
             sorry
          thus " not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A6 A9 A7 A8 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A10: " for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 X & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A11: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      have A12: "x0 inHIDDENR3 X"
        using A11 sorry
      have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
      proof-
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex tVar16 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar16 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar16 implies  not  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
        proof(rule ballI,rule impI)
          fix r assume [ty]: "r be RealXREAL-0M1"
          assume "0NUMBERSK6 <XXREAL-0R3 r"
          then obtain s where
            [ty]:"s be RealXREAL-0M1" and 
            A13: "0NUMBERSK6 <XXREAL-0R3 s"and A14: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 X &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A10 A12 sorry
          show " ex tVar16 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar16 & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 tVar16 implies  not  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r)"
          proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 s"
              using A13 sorry
            fix x1 assume [ty]: "x1 be RealXREAL-0M1"
            assume A15: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and A16: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
            have " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
              using A11 funct_1_th_47 sorry
            also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
              using A15 funct_1_th_47 sorry
            finally have " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
               sorry
            thus " not  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 .| <XXREAL-0R3 r"
              using A14 A15 A16 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
        using fcont_1_th_3 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_1:
"cluster constantFUNCT-1V5 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be continuousFCONT-1V1"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be constantFUNCT-1V5 implies f be continuousFCONT-1V1"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      assume A1: "f be constantFUNCT-1V5"
      have " for x0 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r)))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        obtain s where 
          [ty]:"s be RealXREAL-0M1" and sDef:"s = \<one>\<^sub>M"
           sorry
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A2: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          and A3: "0NUMBERSK6 <XXREAL-0R3 r"
        show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impI,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
             sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          assume A4: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          assume " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s"
          have "f .FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x0"
            using A1 A2 A4 sorry
          thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
            using A3 absvalue_th_2 sorry
        qed "sorry"
      qed "sorry"
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
        using fcont_1_th_14 sorry
      thus "f be continuousFCONT-1V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_2:
"cluster continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be continuousFCONT-1V1"
  proof-
    have " ex tVar18 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar18 be continuousFCONT-1V1"
    proof-
      let ?f = "the constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      show " ex tVar18 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar18 be continuousFCONT-1V1"
      proof(rule bexI[of _ "?f"])
        show "the constantFUNCT-1V5\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) be continuousFCONT-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_3:
  mlet "f be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using relat_1_th_57 sorry
        then have A2: "f is-continuous-inFCONT-1R1 x0"
          using fcont_1_def_2 sorry
        have "x0 inHIDDENR3 X"
          using A1 sorry
        thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
          using A2 fcont_1_th_1 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_15:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 iff (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
   sorry

mtheorem fcont_1_th_16:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    assume "X1 c=TARSKIR1 X"
    then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1"
      using relat_1_th_74 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_4:
"cluster emptyXBOOLE-0V1 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be emptyXBOOLE-0V1 implies it be continuousFCONT-1V1"
     sorry
qed "sorry"

mtheorem fcont_1_cl_5:
  mlet "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be trivialZFMISC-1V1\<bar>setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      show " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1 or  not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1"
           sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1))"
        proof(rule impI)
          assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1"
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
             sorry
        qed
        have case2: " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1))"
        proof(rule impI)
          assume " not f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be emptyXBOOLE-0V1"
          then obtain x0 where
            [ty]:"x0 be RealXREAL-0M1" and 
            A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using membered_th_9 sorry
          have "x0 inHIDDENR3 X"
            using A1 relat_1_th_57 sorry
          then have A2: "X =XBOOLE-0R4 {SEQ-4K1 x0}"
            using zfmisc_1_th_132 sorry
          have " for p be RealXREAL-0M1 holds p inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 p"
          proof(rule ballI,rule impI)
            fix p assume [ty]: "p be RealXREAL-0M1"
            assume "p inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have A3: "p inHIDDENR3 {SEQ-4K1 x0}"
              using A2 sorry
            show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 p"
            proof-
              have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 p) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 p =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
              proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
                fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
                assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  and "s1 be convergentSEQ-2V5"
                  and "limSEQ-2K1 s1 =COMPLEX1R1 p"
                have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 x0} c=TARSKIR1 {SEQ-4K1 x0}"
                  using xboole_1_th_17 sorry
                have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}"
                  using A2 A4 relat_1_th_61 sorry
                then have A6: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 {SEQ-4K1 x0}"
                  using A5 sorry
                have A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
                proof(rule ballI)
                  fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
                  have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
                    using valued_0_th_28 sorry
                  thus "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 x0"
                    using A6 tarski_def_1 sorry
                qed "sorry"
                have A8: "p =COMPLEX1R1 x0"
                  using A3 tarski_def_1 sorry
                have A9: " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 p .| <XXREAL-0R3 g)"
                proof(rule ballI,rule impI)
                  fix g assume [ty]: "g be RealXREAL-0M1"
                  assume A10: "0NUMBERSK6 <XXREAL-0R3 g"
                  obtain n where 
                    [ty]:"n be NatNAT-1M1" and nDef:"n = 0NUMBERSK6"
                     sorry
                  show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 p .| <XXREAL-0R3 g"
                  proof(rule bexI[of _ "n"],rule ballI,rule impI)
                    fix m assume [ty]: "m be NatNAT-1M1"
                    assume "n <=XXREAL-0R1 m"
                    have A11: "m inTARSKIR2 NATNUMBERSK1"
                      using ordinal1_def_12 sorry
                    have " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 p .| =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 x0 .|"
                      using A2 A8 A4 funct_2_th_108 A11 sorry
                    also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 x0 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 x0 .|"
                      using A7 A11 sorry
                    also have "... = 0NUMBERSK6"
                      using absvalue_th_2 sorry
                    finally have " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 p .| =HIDDENR1 0NUMBERSK6"
                       sorry
                    thus " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0})/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 m -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0}).FUNCT-1K1 p .| <XXREAL-0R3 g"
                      using A10 sorry
                  qed "sorry"
                qed "sorry"
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
                  using A2 seq_2_def_6 sorry
                thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 p =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
                  using A2 A9 seq_2_def_7 sorry
              qed "sorry"
              thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 p"
                using fcont_1_def_1 sorry
            qed
          qed "sorry"
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be continuousFCONT-1V1)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_17:
" for x0 be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 x0} be continuousFCONT-1V1"
   sorry

mtheorem fcont_1_cl_6:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_1 sorry
      then have A1: "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_18 sorry
      have A2: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
         sorry
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 ?X"
          and A4: "s1 be convergentSEQ-2V5"
          and A5: "limSEQ-2K1 s1 inHIDDENR3 ?X"
        have A6: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A1 A2 A3 A4 A5 fcont_1_th_13 sorry
        then have A7: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
           sorry
        have A8: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A3 valued_1_def_1 sorry
        have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A1 A2 A3 A4 A5 fcont_1_th_13 sorry
        then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +XCMPLX-0K2 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A5 valued_1_def_1 sorry
        also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A6 seq_2_th_6 sorry
        also have "... = limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A8 rfunct_2_th_8 sorry
        finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
           sorry
        thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A8 A7 rfunct_2_th_8 sorry
      qed "sorry"
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
        using fcont_1_th_13 sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_7:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_th_12 sorry
      then have A9: "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_18 sorry
      have A10: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
         sorry
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A11: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 ?X"
          and A12: "s1 be convergentSEQ-2V5"
          and A13: "limSEQ-2K1 s1 inHIDDENR3 ?X"
        have A14: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A9 A10 A11 A12 A13 fcont_1_th_13 sorry
        then have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
           sorry
        have A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A11 valued_1_th_12 sorry
        have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A9 A10 A11 A12 A13 fcont_1_th_13 sorry
        then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -XCMPLX-0K6 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A13 valued_1_th_13 sorry
        also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A14 seq_2_th_12 sorry
        also have "... = limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A16 rfunct_2_th_8 sorry
        finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
           sorry
        thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A16 A15 rfunct_2_th_8 sorry
      qed "sorry"
      then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
        using fcont_1_th_13 sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_8:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      have "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using valued_1_def_4 sorry
      then have A17: "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & ?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using xboole_1_th_18 sorry
      have A18: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
         sorry
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A19: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 ?X"
          and A20: "s1 be convergentSEQ-2V5"
          and A21: "limSEQ-2K1 s1 inHIDDENR3 ?X"
        have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A17 A18 A19 A20 A21 fcont_1_th_13 sorry
        then have A23: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
           sorry
        have A24: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A19 valued_1_def_4 sorry
        have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A17 A18 A19 A20 A21 fcont_1_th_13 sorry
        then have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 (limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)*XCMPLX-0K3 (limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A21 valued_1_def_4 sorry
        also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A22 seq_2_th_15 sorry
        also have "... = limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A24 rfunct_2_th_8 sorry
        finally have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
           sorry
        thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A24 A23 rfunct_2_th_8 sorry
      qed "sorry"
      then have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
        using fcont_1_th_13 sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be continuousFCONT-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_18:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & ((f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1))"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI,rule conjMI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    assume A2: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    have A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using A1 xboole_1_th_18 sorry
    have A4: " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X) implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A5: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X"
        and A6: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X"
      have A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 A5 sorry
      have A8: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A2 A5 A6 fcont_1_th_13 sorry
      then have A9: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
         sorry
      have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A2 A5 A6 fcont_1_th_13 sorry
      then have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 (limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)*XCMPLX-0K3 (limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using valued_1_th_5 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 (#)VALUED-1K21\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A8 seq_2_th_15 sorry
      also have "... = limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A7 rfunct_2_th_8 sorry
      finally have "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
      thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A7 A9 rfunct_2_th_8 sorry
    qed "sorry"
    have A10: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_1 sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X) implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A11: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X"
        and A12: "s1 be convergentSEQ-2V5"
        and A13: "limSEQ-2K1 s1 inHIDDENR3 X"
      have A14: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A2 A11 A12 A13 fcont_1_th_13 sorry
      then have A15: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
         sorry
      have A16: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 A11 sorry
      have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A2 A11 A12 A13 fcont_1_th_13 sorry
      then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +XCMPLX-0K2 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A10 A13 valued_1_def_1 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 +VALUED-1K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A14 seq_2_th_6 sorry
      also have "... = limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A16 rfunct_2_th_8 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
      thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A16 A15 rfunct_2_th_8 sorry
    qed "sorry"
    thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A10 fcont_1_th_13 sorry
    have A17: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_th_12 sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X) implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A18: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X"
        and A19: "s1 be convergentSEQ-2V5"
        and A20: "limSEQ-2K1 s1 inHIDDENR3 X"
      have A21: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A3 A2 A18 A19 A20 fcont_1_th_13 sorry
      then have A22: "f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
         sorry
      have A23: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
        using A1 A18 sorry
      have "f1 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 & f2 .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A3 A2 A18 A19 A20 fcont_1_th_13 sorry
      then have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -XCMPLX-0K6 limSEQ-2K1 f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A17 A20 valued_1_th_13 sorry
      also have "... = limSEQ-2K1 (f1 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 -VALUED-1K49\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A21 seq_2_th_12 sorry
      also have "... = limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A23 rfunct_2_th_8 sorry
      finally have "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
      thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A23 A22 rfunct_2_th_8 sorry
    qed "sorry"
    thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A17 fcont_1_th_13 sorry
    have "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 valued_1_def_4 sorry
    thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A4 fcont_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_19:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1 implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1 implies ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    then have A1: "X /\\XBOOLE-0K3 X1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      using xboole_1_th_27 sorry
    assume "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1"
    then have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1"
      using fcont_1_th_16 xboole_1_th_17 sorry
    thus "((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1 & (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1) & (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be continuousFCONT-1V1"
      using A1 fcont_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_9:
  mlet "f be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "r be RealXREAL-0M1"
"cluster r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      have A1: "?X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
        using valued_1_def_5 sorry
      have A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X be continuousFCONT-1V1"
         sorry
      have A3: " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 ?X"
          and A5: "s1 be convergentSEQ-2V5"
          and A6: "limSEQ-2K1 s1 inHIDDENR3 ?X"
        have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A2 A4 A5 A6 fcont_1_th_13 sorry
        then have A8: "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
           sorry
        have "f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A2 A4 A5 A6 fcont_1_th_13 sorry
        then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 r *XCMPLX-0K3 (limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A1 A6 valued_1_def_5 sorry
        also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
          using A7 seq_2_th_8 sorry
        also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A4 rfunct_2_th_9 sorry
        finally have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
           sorry
        thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A4 A8 rfunct_2_th_9 sorry
      qed "sorry"
      have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) =XBOOLE-0R4 ?X"
        using valued_1_def_5 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?X =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
         sorry
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be continuousFCONT-1V1)"
        using A1 A3 fcont_1_th_13 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_20:
" for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for r be RealXREAL-0M1 holds  for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    have A3: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using A1 valued_1_def_5 sorry
    have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 inHIDDENR3 X) implies (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    proof(rule ballI,rule impMI ,rule impMI ,rule impI)
      fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
      assume A4: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 X"
        and A5: "s1 be convergentSEQ-2V5"
        and A6: "limSEQ-2K1 s1 inHIDDENR3 X"
      have A7: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
        using A1 A2 A4 A5 A6 fcont_1_th_13 sorry
      then have A8: "r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
         sorry
      have "f .FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A1 A2 A4 A5 A6 fcont_1_th_13 sorry
      then have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 r *XCMPLX-0K3 (limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A3 A6 valued_1_def_5 sorry
      also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)"
        using A7 seq_2_th_8 sorry
      also have "... = limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A1 A4 rfunct_2_th_9 xboole_1_th_1 sorry
      finally have "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =HIDDENR1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
         sorry
      thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 (limSEQ-2K1 s1) =COMPLEX1R1 limSEQ-2K1 (r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
        using A1 A4 A8 rfunct_2_th_9 xboole_1_th_1 sorry
    qed "sorry"
    thus "(r (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A3 fcont_1_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_21:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    assume A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      have " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
      proof(rule ballI,rule impI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume A3: "r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          using relat_1_th_57 sorry
        then have A4: "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using valued_1_def_11 sorry
        have "r inHIDDENR3 X"
          using A3 sorry
        then have A5: "r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A4 relat_1_th_57 sorry
        then have A6: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
          using A2 sorry
        show "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
        proof-
          have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 r) implies (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r =COMPLEX1R1 limSEQ-2K1 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          proof(rule ballI,rule impMI ,rule impI,rule conjMI)
            fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
            assume A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              and A8: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 r"
            have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using A7 relat_1_th_61 sorry
            then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
              using valued_1_def_11 sorry
            then have A9: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
              using relat_1_th_61 sorry
            have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            proof(rule ballI)
              fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
              have A10: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
                using valued_0_th_28 sorry
              then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                using A9 sorry
              then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
                using relat_1_th_61 sorry
              then have A11: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 X"
                using xboole_0_def_4 sorry
              have "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n.|"
                using seq_1_th_12 sorry
              also have "... =  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n).|"
                using A9 funct_2_th_108 sorry
              also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n).|"
                using A9 A10 funct_1_th_47 sorry
              also have "... = absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using valued_1_th_18 sorry
              also have "... = (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
                using A11 funct_1_th_49 sorry
              also have "... = (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                using A7 funct_2_th_108 sorry
              finally show "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
                 sorry
            qed "sorry"
            then have A12: "absVALUED-1K59\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
              using funct_2_th_63 sorry
            have A13: " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r.| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 r.|"
              using A5 funct_1_th_47 sorry
            also have "... = absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 r"
              using valued_1_th_18 sorry
            also have "... = (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r"
              using A3 funct_1_th_47 sorry
            finally have " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r.| =HIDDENR1 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r"
               sorry
            have A14: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
              using A6 A8 A9 sorry
            thus "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
              using A12 seq_4_th_13 sorry
            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
              using A6 A8 A9 sorry
            thus "(absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r =COMPLEX1R1 limSEQ-2K1 (absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
              using A14 A12 A13 seq_4_th_14 sorry
          qed "sorry"
          thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
            using fcont_1_def_1 sorry
        qed
      qed "sorry"
      thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        using fcont_1_def_2 sorry
    qed
    show "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A1 A2 fcont_1_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_22:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      and A2: "f \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {}XBOOLE-0K1"
      using A2 rfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    have " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
    proof(rule ballI,rule impI)
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume A4: "r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have A5: "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
        using relat_1_th_57 sorry
      have "r inHIDDENR3 X"
        using A4 sorry
      then have A6: "r inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        using A3 A5 relat_1_th_57 sorry
      then have A7: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
        using A1 sorry
      have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & (s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 r) implies ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5 & limSEQ-2K1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =HIDDENR1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r"
      proof(rule ballI,rule impMI ,rule impI,rule conjMI)
        have A8: "f .FUNCT-1K1 r =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "f .FUNCT-1K1 r =COMPLEX1R1 0NUMBERSK6"
          then have "f .FUNCT-1K1 r inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
            using tarski_def_1 sorry
          thus " False "
            using A2 A3 A5 funct_1_def_7 sorry
        qed
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        assume A9: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          and A10: "s1 be convergentSEQ-2V5 & limSEQ-2K1 s1 =COMPLEX1R1 r"
        have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
          using A9 relat_1_th_61 sorry
        then have A11: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
          using A3 relat_1_th_61 sorry
        then have A12: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A7 A10 sorry
        have " for n be NatNAT-1M1 holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A13: "s1 .FUNCT-1K1 n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
            using valued_0_th_28 sorry
          have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using A3 A9 relat_1_th_61 xboole_1_th_17 sorry
          then have A14: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
             sorry
          have A15: "f .FUNCT-1K1 (s1 .FUNCT-1K1 n) =COMPLEX1R1 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume "f .FUNCT-1K1 (s1 .FUNCT-1K1 n) =COMPLEX1R1 0NUMBERSK6"
            then have "f .FUNCT-1K1 (s1 .FUNCT-1K1 n) inTARSKIR2 {SEQ-4K1 0NUMBERSK6 }"
              using tarski_def_1 sorry
            thus " False "
              using A2 A14 A13 funct_1_def_7 sorry
          qed
          have "n inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-1K1 n)"
            using A11 funct_2_th_108 sorry
          also have "... = f .FUNCT-1K1 (s1 .FUNCT-1K1 n)"
            using A11 A13 funct_1_th_47 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n =HIDDENR1 f .FUNCT-1K1 (s1 .FUNCT-1K1 n)"
             sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
            using A15 sorry
        qed "sorry"
        then have A16: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be non-zeroORDINAL1V9"
          using seq_1_th_5 sorry
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have A17: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
            using valued_0_th_28 sorry
          then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            using A9 sorry
          then have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
            using relat_1_th_61 sorry
          then have A18: "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using xboole_0_def_4 sorry
          have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A9 funct_2_th_108 sorry
          also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
            using A9 A17 funct_1_th_47 sorry
          also have "... = (f .FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))\<inverse>XCMPLX-0K5"
            using A18 rfunct_1_def_2 sorry
          also have "... = ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 (s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n))\<inverse>XCMPLX-0K5"
            using A11 A17 funct_1_th_47 sorry
          also have "... = ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)\<inverse>REAL-1K2"
            using A11 funct_2_th_108 sorry
          also have "... = ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
            using valued_1_th_10 sorry
          finally show "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
             sorry
        qed "sorry"
        then have A19: "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1)\<inverse>VALUED-1K39\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub>"
          using funct_2_th_63 sorry
        have A20: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r =COMPLEX1R1 f .FUNCT-1K1 r"
          using A6 funct_1_th_47 sorry
        then have "limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 <>HIDDENR2 0NUMBERSK6"
          using A7 A10 A11 A8 sorry
        thus "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
          using A12 A16 A19 seq_2_th_21 sorry
        have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r =COMPLEX1R1 limSEQ-2K1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using A7 A10 A11 sorry
        then have "limSEQ-2K1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =HIDDENR1 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r)\<inverse>XCMPLX-0K5"
          using A12 A20 A8 A16 A19 seq_2_th_22 sorry
        also have "... = (f .FUNCT-1K1 r)\<inverse>XCMPLX-0K5"
          using A6 funct_1_th_47 sorry
        also have "... = (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 r"
          using A5 rfunct_1_def_2 sorry
        also have "... = ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r"
          using A4 funct_1_th_47 sorry
        finally show "limSEQ-2K1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)/*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 =HIDDENR1 ((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 r"
           sorry
      qed "sorry"
      thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 r"
         sorry
    qed "sorry"
    thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_23:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 implies (f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      and A2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)\<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A1 sorry
    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A2 fcont_1_th_22 sorry
    then have "((f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using rfunct_1_th_46 sorry
    thus "(f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_24:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) & f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 implies (f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & (f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1) implies (f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
    assume A2: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      and A3: "f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> {SEQ-4K1 0NUMBERSK6 } =XBOOLE-0R4 {}XBOOLE-0K1"
      and A4: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    have A5: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> {}XBOOLE-0K1"
      using A3 rfunct_1_def_2 sorry
    also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
       sorry
    finally have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
       sorry
    have "(f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A2 A3 fcont_1_th_22 sorry
    then have "(f2 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A1 A4 A5 fcont_1_th_18 sorry
    thus "(f2 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using rfunct_1_th_31 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_10:
  mlet "f1 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be continuousFCONT-1V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 as-term-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 implies it be continuousFCONT-1V1"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 &  not VarFor1 be continuousFCONT-1V1)"
    proof-
      have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) implies f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume A1: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1)"
        then have "f1 .FUNCT-1K1 x0 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using funct_1_th_11 sorry
        then have A2: "f2 is-continuous-inFCONT-1R1 f1 .FUNCT-1K1 x0"
          using fcont_1_def_2 sorry
        have "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using A1 funct_1_th_11 sorry
        then have "f1 is-continuous-inFCONT-1R1 x0"
          using fcont_1_def_2 sorry
        thus "f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 is-continuous-inFCONT-1R1 x0"
          using A1 A2 fcont_1_th_12 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 &  not VarFor1 be continuousFCONT-1V1)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_25:
" for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be continuousFCONT-1V1 implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be continuousFCONT-1V1) &  not (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have "(f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
      using funct_1_th_99 sorry
    thus " not ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) be continuousFCONT-1V1) &  not (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_26:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1 implies (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1) &  not (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1)"
      using funct_1_th_100 sorry
    thus " not ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be continuousFCONT-1V1) &  not (f2 *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> f1 \<inverse>RELSET-1K8\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) be continuousFCONT-1V1)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_27:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds f .FUNCT-1K1 (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 x2)) & ( ex x0 be RealXREAL-0M1 st f is-continuous-inFCONT-1R1 x0) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub> & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds f .FUNCT-1K1 (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 x2) implies (( ex x0 be RealXREAL-0M1 st f is-continuous-inFCONT-1R1 x0) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1)"
  proof(rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f be totalPARTFUN1V1\<^bsub>(REALNUMBERSK2)\<^esub>"
      and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds f .FUNCT-1K1 (x1 +XCMPLX-0K2 x2) =COMPLEX1R1 f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 x2"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 REALNUMBERSK2"
      using A1 partfun1_def_2 sorry
    assume Given: " ex x0 be RealXREAL-0M1 st f is-continuous-inFCONT-1R1 x0"
    then obtain x0 where
      [ty]:"x0 be RealXREAL-0M1" and 
      A4: "f is-continuous-inFCONT-1R1 x0"
       sorry
    have A5: "f .FUNCT-1K1 x0 +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 f .FUNCT-1K1 (x0 +XCMPLX-0K2 0NUMBERSK6)"
       sorry
    also have "... = f .FUNCT-1K1 x0 +XCMPLX-0K2 f .FUNCT-1K1 (0NUMBERSK6)"
      using A2 sorry
    finally have "f .FUNCT-1K1 x0 +XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 f .FUNCT-1K1 x0 +XCMPLX-0K2 f .FUNCT-1K1 (0NUMBERSK6)"
       sorry
    have A6: " for x1 be RealXREAL-0M1 holds -XCMPLX-0K4 f .FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 (-XCMPLX-0K4 x1)"
    proof(rule ballI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      have "0NUMBERSK6 =HIDDENR1 f .FUNCT-1K1 (x1 +XCMPLX-0K2 (-XCMPLX-0K4 x1))"
        using A5 sorry
      also have "... = f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 (-XCMPLX-0K4 x1)"
        using A2 sorry
      finally have "0NUMBERSK6 =HIDDENR1 f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 (-XCMPLX-0K4 x1)"
         sorry
      thus "-XCMPLX-0K4 f .FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 (-XCMPLX-0K4 x1)"
         sorry
    qed "sorry"
    have A7: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds f .FUNCT-1K1 (x1 -XCMPLX-0K6 x2) =HIDDENR1 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2"
    proof(rule ballI,rule ballI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      have "f .FUNCT-1K1 (x1 -XCMPLX-0K6 x2) =HIDDENR1 f .FUNCT-1K1 (x1 +XCMPLX-0K2 (-XCMPLX-0K4 x2))"
         sorry
      also have "... = f .FUNCT-1K1 x1 +XCMPLX-0K2 f .FUNCT-1K1 (-XCMPLX-0K4 x2)"
        using A2 sorry
      also have "... = f .FUNCT-1K1 x1 +XCMPLX-0K2 (-XCMPLX-0K4 f .FUNCT-1K1 x2)"
        using A6 sorry
      also have "... = f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2"
         sorry
      finally show "f .FUNCT-1K1 (x1 -XCMPLX-0K6 x2) =HIDDENR1 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2"
         sorry
    qed "sorry"
    have " for x1 be RealXREAL-0M1 holds  for r be RealXREAL-0M1 holds x1 inHIDDENR3 REALNUMBERSK2 & r >XXREAL-0R4 0NUMBERSK6 implies ( ex s be RealXREAL-0M1 st s >XXREAL-0R4 0NUMBERSK6 & ( for x2 be RealXREAL-0M1 holds x2 inHIDDENR3 REALNUMBERSK2 &  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 .| <XXREAL-0R3 r))"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix r assume [ty]: "r be RealXREAL-0M1"
      assume "x1 inHIDDENR3 REALNUMBERSK2"
        and A8: "r >XXREAL-0R4 0NUMBERSK6"
      let ?y = "x1 -XCMPLX-0K6 x0"
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A9: "0NUMBERSK6 <XXREAL-0R3 s"and A10: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r"
        using A4 A8 fcont_1_th_3 sorry
      show " ex s be RealXREAL-0M1 st s >XXREAL-0R4 0NUMBERSK6 & ( for x2 be RealXREAL-0M1 holds x2 inHIDDENR3 REALNUMBERSK2 &  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 .| <XXREAL-0R3 r)"
      proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule impMI ,rule impI)
        show "s >XXREAL-0R4 0NUMBERSK6"
          using A9 sorry
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume "x2 inHIDDENR3 REALNUMBERSK2"
          and A11: " |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .| <XXREAL-0R3 s"
        have A12: "x2 -XCMPLX-0K6 ?y inTARSKIR2 REALNUMBERSK2 &  |.COMPLEX1K10 (x2 -XCMPLX-0K6 ?y)-XCMPLX-0K6 x0 .| =COMPLEX1R1  |.COMPLEX1K10 x2 -XCMPLX-0K6 x1 .|"
          using xreal_0_def_1 sorry
        have "?y +XCMPLX-0K2 x0 =COMPLEX1R1 x1"
           sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 (f .FUNCT-1K1 ?y +XCMPLX-0K2 f .FUNCT-1K1 x0) .|"
          using A2 sorry
        also have "... =  |.COMPLEX1K10 (f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 ?y)-XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
           sorry
        also have "... =  |.COMPLEX1K10 f .FUNCT-1K1 (x2 -XCMPLX-0K6 ?y) -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
          using A7 sorry
        finally have " |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 .| =HIDDENR1  |.COMPLEX1K10 f .FUNCT-1K1 (x2 -XCMPLX-0K6 ?y) -XCMPLX-0K6 f .FUNCT-1K1 x0 .|"
           sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 x2 -XCMPLX-0K6 f .FUNCT-1K1 x1 .| <XXREAL-0R3 r"
          using A3 A10 A11 A12 sorry
      qed "sorry"
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using A3 fcont_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_28:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1 implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1"
proof(rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1"
    and A2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
  have " for s1 be Real-SequenceSEQ-1M1 holds rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f implies ( ex q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,REALNUMBERSK2 :]) st (q2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & q2 be convergentSEQ-2V5) & limSEQ-2K1 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
  proof(rule ballI,rule impI)
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    assume A3: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb2 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f .FUNCT-1K1 Lamb2 =COMPLEX1R1 s1 .FUNCT-1K1 Lamb1"
    have A4: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex p be ElementSUBSET-1M1-of REALNUMBERSK2 st ?P(n,p)"
    proof-
      have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar21 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f .FUNCT-1K1 tVar21 =COMPLEX1R1 s1 .FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
        have "s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s1"
          using valued_0_th_28 sorry
        then obtain p where
          [ty]:"p be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A5: "p inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 f .FUNCT-1K1 p"
          using A3 partfun1_th_3 sorry
        show " ex tVar21 be ElementSUBSET-1M1-of REALNUMBERSK2 st tVar21 inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f .FUNCT-1K1 tVar21 =COMPLEX1R1 s1 .FUNCT-1K1 n"
        proof(rule bexI[of _ "p"])
          show "p inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & f .FUNCT-1K1 p =COMPLEX1R1 s1 .FUNCT-1K1 n"
            using A5 sorry
        qed "sorry"
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain q1 where
      [ty]:"q1 be Real-SequenceSEQ-1M1" and 
      A6: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(n,q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n)"
      using funct_2_sch_3 A4 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 implies x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1"
      then have " ex n be ElementSUBSET-1M1-of NATNUMBERSK1 st x =HIDDENR1 q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using funct_2_th_113 sorry
      thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A6 sorry
    qed "sorry"
    then have A7: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    then obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A8: "s2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of q1"and A9: "s2 be convergentSEQ-2V5"and A10: "limSEQ-2K1 s2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 rcomp_1_def_3 sorry
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "f .FUNCT-1K1 (q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n) =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A6 sorry
      thus "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n =COMPLEX1R1 s1 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> n"
        using A7 funct_2_th_108 sorry
    qed "sorry"
    then have A11: "f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> q1 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,REALNUMBERSK2)\<^esub> s1"
      using funct_2_th_63 sorry
    obtain q2 where 
      [ty]:"q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,REALNUMBERSK2 :])" and q2Def:"q2 = f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
       sorry
    show " ex q2 be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 NATNUMBERSK1,REALNUMBERSK2 :]) st (q2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & q2 be convergentSEQ-2V5) & limSEQ-2K1 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
    proof(rule bexI[of _ "q2"])
      have "limSEQ-2K1 s2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
        using A10 sorry
      then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f is-continuous-inFCONT-1R1 limSEQ-2K1 s2"
        using A2 sorry
      then have A12: "f is-continuous-inFCONT-1R1 limSEQ-2K1 s2"
         sorry
      have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> q1"
        using A8 valued_0_th_21 sorry
      then have A13: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> s2 c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 sorry
      then have "f .FUNCT-1K1 (limSEQ-2K1 s2) =COMPLEX1R1 limSEQ-2K1 f /*FUNCT-2K8\<^bsub>(NATNUMBERSK1,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
        using A9 A12 sorry
      thus "(q2 be subsequenceVALUED-0M2\<^bsub>(REALNUMBERSK2)\<^esub>-of s1 & q2 be convergentSEQ-2V5) & limSEQ-2K1 q2 inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
        using A7 A11 A8 A9 A10 A12 A13 funct_1_def_3 valued_0_th_22 sorry
    qed "sorry"
  qed "sorry"
  thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1"
    using rcomp_1_def_3 sorry
qed "sorry"

mtheorem fcont_1_th_29:
" for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
proof-
  have " for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (Y be compactRCOMP-1V1 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1) implies f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: "Y be compactRCOMP-1V1"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1"
    have A4: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1"
      using A3 sorry
    have "domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Y"
      using relat_1_th_61 sorry
    also have "... = Y"
      using A1 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) =HIDDENR1 Y"
       sorry
    then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) be compactRCOMP-1V1"
      using A2 A4 fcont_1_th_28 sorry
    thus "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be compactRCOMP-1V1"
      using relat_1_th_115 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_30:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1 implies ( ex tVar23 be RealXREAL-0M1 st  ex tVar24 be RealXREAL-0M1 st ((tVar23 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & tVar24 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 tVar23 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 tVar24 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f))"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume "(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 & domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
    then have A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f <>HIDDENR2 {}XBOOLE-0K1 & rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f be compactRCOMP-1V1"
      using fcont_1_th_28 relat_1_th_42 sorry
    then obtain x where
      [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 f .FUNCT-1K1 x"
      using partfun1_th_3 rcomp_1_th_14 sorry
    show " ex tVar23 be RealXREAL-0M1 st  ex tVar24 be RealXREAL-0M1 st ((tVar23 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & tVar24 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 tVar23 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 tVar24 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
    proof(rule bexI[of _ "x"])
      obtain y where
        [ty]:"y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A3: "y inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f) =COMPLEX1R1 f .FUNCT-1K1 y"
        using A1 partfun1_th_3 rcomp_1_th_14 sorry
      show " ex tVar24 be RealXREAL-0M1 st ((x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & tVar24 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 x =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 tVar24 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
      proof(rule bexI[of _ "y"])
        show "((x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & y inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & f .FUNCT-1K1 x =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)) & f .FUNCT-1K1 y =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f)"
          using A2 A3 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Extreme value theorem*)
mtheorem fcont_1_th_31:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((Y <>HIDDENR2 {}XBOOLE-0K1 & Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & Y be compactRCOMP-1V1) & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1 implies ( ex x1 be RealXREAL-0M1 st  ex x2 be RealXREAL-0M1 st ((x1 inHIDDENR3 Y & x2 inHIDDENR3 Y) & f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for Y be SubsetSUBSET-1M2-of REALNUMBERSK2 holds Y <>HIDDENR2 {}XBOOLE-0K1 & (Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (Y be compactRCOMP-1V1 & f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1)) implies ( ex tVar25 be RealXREAL-0M1 st  ex tVar26 be RealXREAL-0M1 st (tVar25 inHIDDENR3 Y & tVar26 inHIDDENR3 Y) & (f .FUNCT-1K1 tVar25 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & f .FUNCT-1K1 tVar26 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix Y assume [ty]: "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Y <>HIDDENR2 {}XBOOLE-0K1"
      and A2: "Y c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "Y be compactRCOMP-1V1"
      and A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1"
    have A5: "domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> Y"
      using relat_1_th_61 sorry
    also have "... = Y"
      using A2 xboole_1_th_28 sorry
    finally have "domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) =HIDDENR1 Y"
       sorry
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y be continuousFCONT-1V1"
      using A4 sorry
    then obtain x1 x2 where
      [ty]:"x1 be RealXREAL-0M1" "x2 be RealXREAL-0M1" and 
      A6: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"and A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y).FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
      using A1 A3 A5 fcont_1_th_30 sorry
    show " ex tVar25 be RealXREAL-0M1 st  ex tVar26 be RealXREAL-0M1 st (tVar25 inHIDDENR3 Y & tVar26 inHIDDENR3 Y) & (f .FUNCT-1K1 tVar25 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & f .FUNCT-1K1 tVar26 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
    proof(rule bexI[of _ "x1"])
      show " ex tVar26 be RealXREAL-0M1 st (x1 inHIDDENR3 Y & tVar26 inHIDDENR3 Y) & (f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & f .FUNCT-1K1 tVar26 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
      proof(rule bexI[of _ "x2"],rule conjMI)
        show "x1 inHIDDENR3 Y & x2 inHIDDENR3 Y"
          using A6 sorry
        have "f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y))"
          using A6 A7 funct_1_th_47 sorry
        thus "f .FUNCT-1K1 x1 =COMPLEX1R1 upper-boundSEQ-4K2 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y) & f .FUNCT-1K1 x2 =COMPLEX1R1 lower-boundSEQ-4K3 (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Y)"
          using relat_1_th_115 sorry
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fcont_1_def_3 ("LipschitzianFCONT-1V2" 70 ) where
"attr LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  (\<lambda>f.  ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"..

mtheorem fcont_1_th_32:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 iff ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))) & (( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies ( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
    proof-
      have " not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & ( for r be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))))))"
      proof-
        have "( ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))) implies ( ex tVar27 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar27 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 tVar27 *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
        proof(rule impI)
          assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
          then obtain r where
            [ty]:"r be RealXREAL-0M1" and 
            A1: "0NUMBERSK6 <XXREAL-0R3 r"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
             sorry
          show " ex tVar27 be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 tVar27 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 tVar27 *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
          proof(rule bexI[of _ "r"],rule conjMI,rule ballI,rule ballI,rule impI)
            show "0NUMBERSK6 <XXREAL-0R3 r"
              using A1 sorry
            fix x1 assume [ty]: "x1 be RealXREAL-0M1"
            fix x2 assume [ty]: "x2 be RealXREAL-0M1"
            assume A3: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 =COMPLEX1R1 f .FUNCT-1K1 x2"
              using funct_1_th_47 sorry
            thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
              using A2 A3 sorry
          qed "sorry"
        qed
        thus " not (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & ( for r be RealXREAL-0M1 holds  not ( not 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))))))"
          using fcont_1_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex r be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
    then obtain r where
      [ty]:"r be RealXREAL-0M1" and 
      A4: "0NUMBERSK6 <XXREAL-0R3 r"and A5: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
       sorry
    have "0NUMBERSK6 <XXREAL-0R3 r & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
    proof(rule conjMI,rule ballI,rule ballI,rule impI)
      show "0NUMBERSK6 <XXREAL-0R3 r"
        using A4 sorry
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A6: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x1 & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 =COMPLEX1R1 f .FUNCT-1K1 x2"
        using funct_1_th_47 sorry
      thus " |.COMPLEX1K10 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 -XCMPLX-0K6 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using A5 A6 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
      using bexI[of _ "r"] fcont_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_11:
"cluster emptyXBOOLE-0V1 also-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be emptyXBOOLE-0V1 implies it be LipschitzianFCONT-1V2"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be emptyXBOOLE-0V1 implies f be LipschitzianFCONT-1V2"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      assume A1: "f be emptyXBOOLE-0V1"
      have " not 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
      proof-
        show " not 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)))"
          using A1 sorry
      qed
      thus "f be LipschitzianFCONT-1V2"
        using bexI[of _ "\<one>\<^sub>M"] fcont_1_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_12:
"cluster emptyXBOOLE-0V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be emptyXBOOLE-0V1"
  proof-
    have " ex tVar30 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar30 be emptyXBOOLE-0V1"
    proof-
      show " ex tVar30 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar30 be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "the emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"])
        show "the emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_13:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "X be setHIDDENM2"
"cluster f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: "0NUMBERSK6 <XXREAL-0R3 r"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_def_3 sorry
      have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
          using relat_1_th_57 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
          using A2 sorry
      qed "sorry"
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X &  not VarFor1 be LipschitzianFCONT-1V2)"
        using A1 fcont_1_th_32 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_33:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X1 c=TARSKIR1 X implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
      and A2: "X1 c=TARSKIR1 X"
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1"
      using A2 relat_1_th_74 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_14:
  mlet "f1 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      let ?X1 = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A1: "0NUMBERSK6 <XXREAL-0R3 s"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_th_32 sorry
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A3: "0NUMBERSK6 <XXREAL-0R3 g"and A4: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_th_32 sorry
      have " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = s +XCMPLX-0K2 g"
           sorry
        show " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 p"
            using A1 A3 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume A5: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            and A6: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          have " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 +XCMPLX-0K2 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .|"
            using A5 valued_1_def_1 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 +XCMPLX-0K2 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 .FUNCT-1K1 x2 +XCMPLX-0K2 f2 .FUNCT-1K1 x2) .|"
            using A6 valued_1_def_1 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)+XCMPLX-0K2 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
             sorry
          finally have " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)+XCMPLX-0K2 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
             sorry
          then have A7: " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .|"
            using complex1_th_56 sorry
          have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)"
            using relat_1_th_61 sorry
          also have "... = (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X"
            using xboole_1_th_16 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using valued_1_def_1 sorry
          finally have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
             sorry
          then have A8: " |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A4 A5 A6 sorry
          have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)"
            using relat_1_th_61 sorry
          also have "... = (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1"
            using xboole_1_th_16 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using valued_1_def_1 sorry
          finally have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
             sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A2 A5 A6 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|) +XCMPLX-0K2 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A8 xreal_1_th_7 sorry
          thus " |.COMPLEX1K10 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A7 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_15:
  mlet "f1 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      let ?X1 = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A9: "0NUMBERSK6 <XXREAL-0R3 s"and A10: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_th_32 sorry
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A11: "0NUMBERSK6 <XXREAL-0R3 g"and A12: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_th_32 sorry
      have " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = s +XCMPLX-0K2 g"
           sorry
        show " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 p"
            using A9 A11 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume A13: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            and A14: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .|"
            using A13 valued_1_th_13 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x1)-XCMPLX-0K6 (f1 .FUNCT-1K1 x2 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
            using A14 valued_1_th_13 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)-XCMPLX-0K6 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
             sorry
          finally have " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 (f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2)-XCMPLX-0K6 (f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2) .|"
             sorry
          then have A15: " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .|"
            using complex1_th_57 sorry
          have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)"
            using relat_1_th_61 sorry
          also have "... = (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X"
            using xboole_1_th_16 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using valued_1_th_12 sorry
          finally have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
             sorry
          then have A16: " |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A12 A13 A14 sorry
          have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)"
            using relat_1_th_61 sorry
          also have "... = (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X)/\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1"
            using xboole_1_th_16 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            using valued_1_th_12 sorry
          finally have "domRELSET-1K1\<^bsub>(domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1)) =HIDDENR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
             sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A10 A13 A14 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| +XCMPLX-0K2  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|) +XCMPLX-0K2 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A16 xreal_1_th_7 sorry
          thus " |.COMPLEX1K10 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x1 -XCMPLX-0K6 (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A15 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_34:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)"
      using relat_1_th_74 xboole_1_th_17 sorry
    have A2: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)"
      using rfunct_1_th_44 sorry
    assume "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
    thus "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_35:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2 implies (f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)"
      using relat_1_th_74 xboole_1_th_17 sorry
    have A2: "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1)"
      using rfunct_1_th_47 sorry
    assume "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2"
    thus "(f1 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (X /\\XBOOLE-0K3 X1) be LipschitzianFCONT-1V2"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_16:
  mlet "f1 be boundedSEQ-2V6\<bar>LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "f2 be boundedSEQ-2V6\<bar>LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
      let ?X1 = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
      obtain x1 where
        [ty]:"x1 be RealXREAL-0M1" and 
        A1: " for r be objectHIDDENM1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies  |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1 x1"
        using rfunct_1_th_72 sorry
      obtain x2 where
        [ty]:"x2 be RealXREAL-0M1" and 
        A2: " for r be objectHIDDENM1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1 x2"
        using rfunct_1_th_72 sorry
      obtain g where
        [ty]:"g be RealXREAL-0M1" and 
        A3: "0NUMBERSK6 <XXREAL-0R3 g"and A4: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 implies  |.COMPLEX1K10 f2 .FUNCT-1K1 x1 -XCMPLX-0K6 f2 .FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_def_3 sorry
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A5: "0NUMBERSK6 <XXREAL-0R3 s"and A6: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 implies  |.COMPLEX1K10 f1 .FUNCT-1K1 x1 -XCMPLX-0K6 f1 .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_def_3 sorry
      have A7: " for r be RealXREAL-0M1 holds r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1  |.COMPLEX1K10 x1.| &  |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1  |.COMPLEX1K10 x2.|"
      proof(rule ballI,rule impI,rule conjMI)
        fix r assume [ty]: "r be RealXREAL-0M1"
        assume "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
        then have A8: "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using valued_1_def_4 sorry
        then have "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1"
          using xboole_0_def_4 sorry
        then have A9: " |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1 x1"
          using A1 sorry
        have "r inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2"
          using A8 xboole_0_def_4 sorry
        then have A10: " |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1 x2"
          using A2 sorry
        have "x1 <=XXREAL-0R1  |.COMPLEX1K10 x1.|"
          using absvalue_th_4 sorry
        thus " |.COMPLEX1K10 f1 .FUNCT-1K1 r.| <=XXREAL-0R1  |.COMPLEX1K10 x1.|"
          using A9 xxreal_0_th_2 sorry
        have "x2 <=XXREAL-0R1  |.COMPLEX1K10 x2.|"
          using absvalue_th_4 sorry
        thus " |.COMPLEX1K10 f2 .FUNCT-1K1 r.| <=XXREAL-0R1  |.COMPLEX1K10 x2.|"
          using A10 xxreal_0_th_2 sorry
      qed "sorry"
      have " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|))"
      proof-
        obtain p where 
          [ty]:"p be setHIDDENM2" and pDef:"p = (( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g +XCMPLX-0K2 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 s)+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        show " ex p be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 p & ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies  |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|))"
        proof(rule bexI[of _ "p"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          have A11: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x1.|"
            using complex1_th_46 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x1.| & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x2.|"
            using complex1_th_46 sorry
          thus "0NUMBERSK6 <XXREAL-0R3 p"
            using A5 A3 sorry
          fix y1 assume [ty]: "y1 be RealXREAL-0M1"
          fix y2 assume [ty]: "y2 be RealXREAL-0M1"
          assume A12: "y1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
            and A13: "y2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
          have A14: "y2 inHIDDENR3 ?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1"
            using A13 valued_1_def_4 sorry
          then have A15: "y2 inHIDDENR3 ?X"
            using xboole_0_def_4 sorry
          have " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| =COMPLEX1R1 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|) & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|"
            using complex1_th_46 complex1_th_65 sorry
          then have A16: " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| <=XXREAL-0R1 ( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|)"
            using A7 A12 xreal_1_th_64 sorry
          have A17: "y2 inHIDDENR3 ?X1"
            using A14 xboole_0_def_4 sorry
          have A18: "y1 inHIDDENR3 ?X /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ?X1"
            using A12 valued_1_def_4 sorry
          then have "y1 inHIDDENR3 ?X1"
            using xboole_0_def_4 sorry
          then have "( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2 .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 (g *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|))"
            using A4 A17 A11 xreal_1_th_64 sorry
          then have A19: " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| <=XXREAL-0R1 (( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|)"
            using A16 xxreal_0_th_2 sorry
          have "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|"
            using complex1_th_46 sorry
          then have A20: "(( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g +XCMPLX-0K2 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 s)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|) +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g +XCMPLX-0K2 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 s)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|)"
            using xreal_1_th_7 sorry
          have " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| =HIDDENR1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .|"
            using valued_1_th_5 sorry
          also have "... =  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y1 +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y2 -XCMPLX-0K6 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 f2 .FUNCT-1K1 y2))-XCMPLX-0K6 f1 .FUNCT-1K1 y2 *XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
            using valued_1_th_5 sorry
          also have "... =  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
             sorry
          finally have " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| =HIDDENR1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) +XCMPLX-0K2 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
             sorry
          then have A21: " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| +XCMPLX-0K2  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .|"
            using complex1_th_56 sorry
          have " |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| =COMPLEX1R1 ( |.COMPLEX1K10 f2 .FUNCT-1K1 y2.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|) & 0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|"
            using complex1_th_46 complex1_th_65 sorry
          then have A22: " |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| <=XXREAL-0R1 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|)"
            using A7 A13 xreal_1_th_64 sorry
          have A23: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x2.|"
            using complex1_th_46 sorry
          have "y1 inHIDDENR3 ?X"
            using A18 xboole_0_def_4 sorry
          then have "( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2 .|) <=XXREAL-0R1 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 (s *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|))"
            using A6 A15 A23 xreal_1_th_64 sorry
          then have " |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| <=XXREAL-0R1 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 (s *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|))"
            using A22 xxreal_0_th_2 sorry
          then have " |.COMPLEX1K10 f1 .FUNCT-1K1 y1 *XCMPLX-0K3 (f2 .FUNCT-1K1 y1 -XCMPLX-0K6 f2 .FUNCT-1K1 y2) .| +XCMPLX-0K2  |.COMPLEX1K10 (f1 .FUNCT-1K1 y1 -XCMPLX-0K6 f1 .FUNCT-1K1 y2)*XCMPLX-0K3 f2 .FUNCT-1K1 y2 .| <=XXREAL-0R1 (( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|) +XCMPLX-0K2 (( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 s)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|)"
            using A19 xreal_1_th_7 sorry
          then have " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1 (( |.COMPLEX1K10 x1.|)*XCMPLX-0K3 g +XCMPLX-0K2 ( |.COMPLEX1K10 x2.|)*XCMPLX-0K3 s)*XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|)"
            using A21 xxreal_0_th_2 sorry
          thus " |.COMPLEX1K10 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y1 -XCMPLX-0K6 (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 y2 .| <=XXREAL-0R1 p *XCMPLX-0K3 ( |.COMPLEX1K10 y1 -XCMPLX-0K6 y2 .|)"
            using A20 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 &  not VarFor1 be LipschitzianFCONT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_36:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6 implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for Z1 be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6 implies (f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be LipschitzianFCONT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix Z1 assume [ty]: "Z1 be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have A1: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z))"
      using xboole_1_th_16 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 X)/\\XBOOLE-0K3 Z)"
      using xboole_1_th_16 sorry
    also have "... = (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 X)"
      using relat_1_th_71 sorry
    finally have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 X)"
       sorry
    have A2: "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 (X /\\XBOOLE-0K3 Z))"
      using xboole_1_th_16 sorry
    also have "... = f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X)"
      using xboole_1_th_16 sorry
    also have "... = (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 Z)"
      using relat_1_th_71 sorry
    finally have "f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 (f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X1 /\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 Z)"
       sorry
    have A3: "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 Z1)/\\XBOOLE-0K3 X1)"
      using xboole_1_th_16 sorry
    also have "... = (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((Z /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 Z1)"
      using relat_1_th_71 sorry
    finally have "f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =HIDDENR1 (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((Z /\\XBOOLE-0K3 X)/\\XBOOLE-0K3 Z1)"
       sorry
    have A4: "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)"
      using relat_1_th_71 rfunct_1_th_45 sorry
    assume "((f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X1 be LipschitzianFCONT-1V2) & f1  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z be boundedSEQ-2V6) & f2  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> Z1 be boundedSEQ-2V6"
    thus "(f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (((X /\\XBOOLE-0K3 Z)/\\XBOOLE-0K3 X1)/\\XBOOLE-0K3 Z1) be LipschitzianFCONT-1V2"
      using A1 A2 A4 A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_17:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)", "p be RealXREAL-0M1"
"cluster p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A1: "0NUMBERSK6 <XXREAL-0R3 s"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_def_3 sorry
      show " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
      proof-
        have cases: "p =COMPLEX1R1 0NUMBERSK6 or p <>HIDDENR2 0NUMBERSK6"
           sorry
        have case1: "p =COMPLEX1R1 0NUMBERSK6 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2))"
        proof(rule impI)
          assume A3: "p =COMPLEX1R1 0NUMBERSK6"
          have " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
          proof-
            show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
            proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
              show "0NUMBERSK6 <XXREAL-0R3 s"
                using A1 sorry
              fix x1 assume [ty]: "x1 be RealXREAL-0M1"
              fix x2 assume [ty]: "x2 be RealXREAL-0M1"
              assume A4: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                and A5: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              have A6: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|"
                using complex1_th_46 sorry
              have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .|"
                using A4 valued_1_def_5 sorry
              also have "... =  |.COMPLEX1K10 0NUMBERSK6 -XCMPLX-0K6 p *XCMPLX-0K3 f .FUNCT-1K1 x2 .|"
                using A3 A5 valued_1_def_5 sorry
              also have "... = 0NUMBERSK6"
                using A3 absvalue_th_2 sorry
              finally have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1 0NUMBERSK6"
                 sorry
              thus " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
                using A1 A6 sorry
            qed "sorry"
          qed
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
             sorry
        qed
        have case2: "p <>HIDDENR2 0NUMBERSK6 implies ( for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2))"
        proof(rule impI)
          assume "p <>HIDDENR2 0NUMBERSK6"
          then have "0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 p.|"
            using complex1_th_47 sorry
          then have A7: "(0NUMBERSK6)*XCMPLX-0K3 s <XXREAL-0R3 ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 s"
            using A1 xreal_1_th_68 sorry
          have " ex g be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 g & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
          proof-
            obtain g where 
              [ty]:"g be setHIDDENM2" and gDef:"g = ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 s"
               sorry
            show " ex g be setHIDDENM2 st 0NUMBERSK6 <XXREAL-0R3 g & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) implies  |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
            proof(rule bexI[of _ "g"],rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
              have A8: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 p.|"
                using complex1_th_46 sorry
              show "0NUMBERSK6 <XXREAL-0R3 g"
                using A7 sorry
              fix x1 assume [ty]: "x1 be RealXREAL-0M1"
              fix x2 assume [ty]: "x2 be RealXREAL-0M1"
              assume A9: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
                and A10: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
              have A11: " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .|"
                using A9 valued_1_def_5 sorry
              also have "... =  |.COMPLEX1K10 p *XCMPLX-0K3 f .FUNCT-1K1 x1 -XCMPLX-0K6 p *XCMPLX-0K3 f .FUNCT-1K1 x2 .|"
                using A10 valued_1_def_5 sorry
              also have "... =  |.COMPLEX1K10 p *XCMPLX-0K3 (f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2) .|"
                 sorry
              also have "... = ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|)"
                using complex1_th_65 sorry
              finally have " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| =HIDDENR1 ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|)"
                 sorry
              have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                using A9 A10 valued_1_def_5 sorry
              then have "( |.COMPLEX1K10 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|) <=XXREAL-0R1 ( |.COMPLEX1K10 p.|)*XCMPLX-0K3 (s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
                using A2 A8 xreal_1_th_64 sorry
              thus " |.COMPLEX1K10 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x1 -XCMPLX-0K6 (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f).FUNCT-1K1 x2 .| <=XXREAL-0R1 g *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
                using A11 sorry
            qed "sorry"
          qed
          thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_37:
" for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2)"
  proof(rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    have "(p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
      using rfunct_1_th_49 sorry
    thus " not ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) &  not (p (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_18:
  mlet "f be LipschitzianFCONT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
"cluster absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      obtain s where
        [ty]:"s be RealXREAL-0M1" and 
        A1: "0NUMBERSK6 <XXREAL-0R3 s"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using fcont_1_def_3 sorry
      have " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
      proof-
        show " ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
        proof(rule bexI[of _ "s"],rule conjMI,rule ballI,rule ballI,rule impI)
          show "0NUMBERSK6 <XXREAL-0R3 s"
            using A1 sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f"
          then have "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
            using valued_1_def_11 sorry
          then have A3: " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A2 sorry
          have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .|"
            using valued_1_th_18 sorry
          also have "... =  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6  |.COMPLEX1K10 f .FUNCT-1K1 x2.| .|"
            using valued_1_th_18 sorry
          finally have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10  |.COMPLEX1K10 f .FUNCT-1K1 x1.| -XCMPLX-0K6  |.COMPLEX1K10 f .FUNCT-1K1 x2.| .|"
             sorry
          then have " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <=XXREAL-0R1  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .|"
            using complex1_th_64 sorry
          thus " |.COMPLEX1K10 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x1 -XCMPLX-0K6 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f .FUNCT-1K1 x2 .| <=XXREAL-0R1 s *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A3 xxreal_0_th_2 sorry
        qed "sorry"
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f &  not VarFor1 be LipschitzianFCONT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_38:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 implies -VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2 & absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
    thus "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
       sorry
    have "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using rfunct_1_th_46 sorry
    thus "absVALUED-1K59\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_cl_19:
"cluster constantFUNCT-1V5 also-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be constantFUNCT-1V5 implies it be LipschitzianFCONT-1V2"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be constantFUNCT-1V5 implies f be LipschitzianFCONT-1V2"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      assume A1: "f be constantFUNCT-1V5"
      have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
      proof(rule ballI,rule ballI,rule impI)
        fix x1 assume [ty]: "x1 be RealXREAL-0M1"
        fix x2 assume [ty]: "x2 be RealXREAL-0M1"
        assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
        then have "f .FUNCT-1K1 x1 =COMPLEX1R1 f .FUNCT-1K1 x2"
          using A1 sorry
        then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| =COMPLEX1R1 0NUMBERSK6"
          using absvalue_th_2 sorry
        thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
          using complex1_th_46 sorry
      qed "sorry"
      thus "f be LipschitzianFCONT-1V2"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_20:
  mlet "Y be SubsetSUBSET-1M2-of REALNUMBERSK2"
"cluster idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y as-term-is LipschitzianFCONT-1V2 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it =HIDDENR1 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y implies it be LipschitzianFCONT-1V2"
  proof-
    have " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y &  not VarFor1 be LipschitzianFCONT-1V2)"
    proof-
      obtain r where 
        [ty]:"r be RealXREAL-0M1" and rDef:"r = \<one>\<^sub>M"
         sorry
      have "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y be LipschitzianFCONT-1V2"
      proof-
        have "r >XXREAL-0R4 0NUMBERSK6 & ( for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y) implies  |.COMPLEX1K10 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x1 -XCMPLX-0K6 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|))"
        proof(rule conjMI,rule ballI,rule ballI,rule impMI ,rule impI)
          show "r >XXREAL-0R4 0NUMBERSK6"
             sorry
          fix x1 assume [ty]: "x1 be RealXREAL-0M1"
          fix x2 assume [ty]: "x2 be RealXREAL-0M1"
          assume A1: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y)"
            and A2: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(Y)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y)"
          have A3: "x2 inHIDDENR3 Y"
            using A2 sorry
          have "x1 inHIDDENR3 Y"
            using A1 sorry
          then have " |.COMPLEX1K10 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x1 -XCMPLX-0K6 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 x1 -XCMPLX-0K6 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x2 .|"
            using funct_1_th_18 sorry
          also have "... = r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
            using A3 funct_1_th_18 sorry
          finally have " |.COMPLEX1K10 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x1 -XCMPLX-0K6 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x2 .| =HIDDENR1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
             sorry
          thus " |.COMPLEX1K10 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x1 -XCMPLX-0K6 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
             sorry
        qed "sorry"
        thus "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y be LipschitzianFCONT-1V2"
          using bexI[of _ "r"] fcont_1_def_3 sorry
      qed
      thus " for VarFor1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  not (VarFor1 =HIDDENR1 idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Y &  not VarFor1 be LipschitzianFCONT-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$N Lipschitz continuity*)
mtheorem fcont_1_cl_21:
"cluster LipschitzianFCONT-1V2 also-is continuousFCONT-1V1 for PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*coherence*)
  show " for it be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds it be LipschitzianFCONT-1V2 implies it be continuousFCONT-1V1"
  proof-
    have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f be LipschitzianFCONT-1V2 implies f be continuousFCONT-1V1"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
      let ?X = "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      assume "f be LipschitzianFCONT-1V2"
      then obtain r where
        [ty]:"r be RealXREAL-0M1" and 
        A1: "0NUMBERSK6 <XXREAL-0R3 r"and A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 ?X & x2 inHIDDENR3 ?X implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
         sorry
      have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f is-continuous-inFCONT-1R1 x0"
      proof(rule ballI,rule impI)
        fix x0 assume [ty]: "x0 be RealXREAL-0M1"
        assume A3: "x0 inHIDDENR3 ?X"
        have " for r be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 r implies ( ex s be RealXREAL-0M1 st 0NUMBERSK6 <XXREAL-0R3 s & ( for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 r))"
        proof-
          have " for g be RealXREAL-0M1 holds 0NUMBERSK6 <XXREAL-0R3 g implies ( ex s9 be setHIDDENM2 st  not 0NUMBERSK6 <XXREAL-0R3 s9 & ( for x1 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s9) &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 g)))"
          proof(rule ballI,rule impI)
            fix g assume [ty]: "g be RealXREAL-0M1"
            assume A4: "0NUMBERSK6 <XXREAL-0R3 g"
            let ?s = "g /XCMPLX-0K7 r"
            obtain s9 where 
              [ty]:"s9 be setHIDDENM2" and s9Def:"s9 = ?s"
               sorry
            show " ex s9 be setHIDDENM2 st  not 0NUMBERSK6 <XXREAL-0R3 s9 & ( for x1 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s9) &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 g))"
            proof(rule bexI[of _ "s9"])
              have A5: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 g /XCMPLX-0K7 r implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 g"
              proof(rule ballI,rule impMI ,rule impI)
                fix x1 assume [ty]: "x1 be RealXREAL-0M1"
                assume A6: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
                  and A7: " |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 ?s"
                have "r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .|) <XXREAL-0R3 (g /XCMPLX-0K7 r)*XCMPLX-0K3 r"
                  using A1 A7 xreal_1_th_68 sorry
                then have A8: "r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .|) <XXREAL-0R3 g"
                  using A1 xcmplx_1_th_87 sorry
                have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <=XXREAL-0R1 r *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .|)"
                  using A2 A3 A6 sorry
                thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 g"
                  using A8 xxreal_0_th_2 sorry
              qed "sorry"
              have "s9 =COMPLEX1R1 g *XCMPLX-0K3 r \<inverse>XCMPLX-0K5"
                using xcmplx_0_def_9 sorry
              thus " not 0NUMBERSK6 <XXREAL-0R3 s9 & ( for x1 be RealXREAL-0M1 holds  not ((x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f &  not  |.COMPLEX1K10 x1 -XCMPLX-0K6 x0 .| <XXREAL-0R3 s9) &  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x0 .| <XXREAL-0R3 g))"
                using A1 A4 A5 xreal_1_th_129 sorry
            qed "sorry"
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "f is-continuous-inFCONT-1R1 x0"
          using fcont_1_th_3 sorry
      qed "sorry"
      thus "f be continuousFCONT-1V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_39:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {SEQ-4K1 r}) implies f be continuousFCONT-1V1"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume Given: " ex r be RealXREAL-0M1 st rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {SEQ-4K1 r}"
  then obtain r where
    [ty]:"r be RealXREAL-0M1" and 
    A1: "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f =XBOOLE-0R4 {SEQ-4K1 r}"
     sorry
  have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be RealXREAL-0M1"
    fix x2 assume [ty]: "x2 be RealXREAL-0M1"
    assume A2: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "f .FUNCT-1K1 x2 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 funct_1_def_3 sorry
    then have A4: "f .FUNCT-1K1 x2 =COMPLEX1R1 r"
      using A1 tarski_def_1 sorry
    have "f .FUNCT-1K1 x1 inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A2 funct_1_def_3 sorry
    then have "f .FUNCT-1K1 x1 =COMPLEX1R1 r"
      using A1 tarski_def_1 sorry
    then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| =COMPLEX1R1 0NUMBERSK6"
      using A4 absvalue_th_2 sorry
    thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
      using complex1_th_46 sorry
  qed "sorry"
  then have "f be LipschitzianFCONT-1V2"
     sorry
  thus "f be continuousFCONT-1V1"
     sorry
qed "sorry"

mtheorem fcont_1_th_40:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1 x0) implies f be continuousFCONT-1V1"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
  assume A1: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1 x0"
  have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x1 assume [ty]: "x1 be RealXREAL-0M1"
    fix x2 assume [ty]: "x2 be RealXREAL-0M1"
    assume A2: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
    have "f .FUNCT-1K1 x1 =COMPLEX1R1 x1"
      using A1 A2 sorry
    thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
      using A1 A3 sorry
  qed "sorry"
  then have "f be LipschitzianFCONT-1V2"
     sorry
  thus "f be continuousFCONT-1V1"
     sorry
qed "sorry"

mtheorem fcont_1_th_41:
" for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1 r *XCMPLX-0K3 x0 +XCMPLX-0K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for r be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1 r *XCMPLX-0K3 x0 +XCMPLX-0K2 p) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1 r *XCMPLX-0K3 x0 +XCMPLX-0K2 p"
    have A2: " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 ( |.COMPLEX1K10 r.| +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume A3: "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
        and A4: "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      have "x2 inHIDDENR3 X"
        using A4 sorry
      then have A5: "f .FUNCT-1K1 x2 =COMPLEX1R1 r *XCMPLX-0K3 x2 +XCMPLX-0K2 p"
        using A1 sorry
      have A6: "0NUMBERSK6 <=XXREAL-0R1  |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|"
        using complex1_th_46 sorry
      have "x1 inHIDDENR3 X"
        using A3 sorry
      then have "f .FUNCT-1K1 x1 =COMPLEX1R1 r *XCMPLX-0K3 x1 +XCMPLX-0K2 p"
        using A1 sorry
      then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| =HIDDENR1  |.COMPLEX1K10 r *XCMPLX-0K3 (x1 -XCMPLX-0K6 x2) .|"
        using A5 sorry
      also have "... = ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using complex1_th_65 sorry
      finally have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| =HIDDENR1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
         sorry
      then have " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| +XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 ( |.COMPLEX1K10 r.|)*XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using A6 xreal_1_th_7 sorry
      thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 ( |.COMPLEX1K10 r.| +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
         sorry
    qed "sorry"
    have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3  |.COMPLEX1K10 r.| +XCMPLX-0K2 \<one>\<^sub>M"
      using complex1_th_46 xreal_1_th_8 sorry
    then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be LipschitzianFCONT-1V2"
      using A2 fcont_1_th_32 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_42:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    obtain f1 where 
      [ty]:"f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)" and f1Def:"f1 = idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f)"
       sorry
    assume A1: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1"
    have A2: " for x0 be objectHIDDENM1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 f1 .FUNCT-1K1 x0"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be objectHIDDENM1"
      assume A3: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      then obtain x1 where 
        [ty]:"x1 be RealXREAL-0M1" and x1Def:"x1 = x0"
         sorry
      have "f .FUNCT-1K1 x0 =HIDDENR1 x1 ^2SQUARE-1K1"
        using A1 A3 sorry
      also have "... = f1 .FUNCT-1K1 x1 *XCMPLX-0K3 x1"
        using A3 funct_1_th_18 sorry
      also have "... = f1 .FUNCT-1K1 x0 *XCMPLX-0K3 f1 .FUNCT-1K1 x0"
        using A3 funct_1_th_18 sorry
      finally show "f .FUNCT-1K1 x0 =HIDDENR1 f1 .FUNCT-1K1 x0 *XCMPLX-0K3 f1 .FUNCT-1K1 x0"
         sorry
    qed "sorry"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
       sorry
    then have "f =RELSET-1R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1 (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f1"
      using A2 valued_1_def_4 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_43:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "X c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A2: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1"
    have "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K8\<^bsub>(REALNUMBERSK2)\<^esub> X"
      using A1 xboole_1_th_28 sorry
    then have A3: "X =XBOOLE-0R4 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      using relat_1_th_61 sorry
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A4: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "f .FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1"
        using A2 sorry
      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =XBOOLE-0R4 x0 ^2SQUARE-1K1"
        using A4 funct_1_th_47 sorry
    qed "sorry"
    then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using A3 fcont_1_th_42 sorry
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_44:
" for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f be continuousFCONT-1V1"
proof-
  have " for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f be continuousFCONT-1V1"
  proof(rule ballI,rule impI)
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|"
    have " for x1 be RealXREAL-0M1 holds  for x2 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f implies  |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
    proof(rule ballI,rule ballI,rule impI)
      fix x1 assume [ty]: "x1 be RealXREAL-0M1"
      fix x2 assume [ty]: "x2 be RealXREAL-0M1"
      assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      then have "f .FUNCT-1K1 x1 =COMPLEX1R1  |.COMPLEX1K10 x1.| & f .FUNCT-1K1 x2 =COMPLEX1R1  |.COMPLEX1K10 x2.|"
        using A1 sorry
      thus " |.COMPLEX1K10 f .FUNCT-1K1 x1 -XCMPLX-0K6 f .FUNCT-1K1 x2 .| <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 x1 -XCMPLX-0K6 x2 .|)"
        using complex1_th_64 sorry
    qed "sorry"
    then have "f be LipschitzianFCONT-1V2"
       sorry
    thus "f be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_45:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 X implies f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|"
    proof(rule ballI,rule impI)
      fix x0 assume [ty]: "x0 be RealXREAL-0M1"
      assume A2: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
      then have "f .FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|"
        using A1 sorry
      thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1  |.COMPLEX1K10 x0.|"
        using A2 funct_1_th_47 sorry
    qed "sorry"
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      using fcont_1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_46:
" for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 & ( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st p <=XXREAL-0R1 g & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
proof-
  have " for X be setHIDDENM2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5 implies (( ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st p <=XXREAL-0R1 g & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be monotoneRFUNCT-2V5"
    assume Given: " ex p be RealXREAL-0M1 st  ex g be RealXREAL-0M1 st p <=XXREAL-0R1 g & f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
    then obtain p g where
      [ty]:"p be RealXREAL-0M1" "g be RealXREAL-0M1" and 
      A2: "p <=XXREAL-0R1 g"and A3: "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 [.RCOMP-1K1 p,g .]"
       sorry
    have 
      [ty]:"p be RealXREAL-0M1" and
      [ty]:"g be RealXREAL-0M1"
       sorry
    have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
    proof-
      show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
      proof-
        have cases: "p =COMPLEX1R1 g or p <XXREAL-0R3 g"
          using A2 xxreal_0_th_1 sorry
        have case1: "p =COMPLEX1R1 g implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume "p =COMPLEX1R1 g"
          then have "f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 {SEQ-4K1 p}"
            using A3 xxreal_1_th_17 sorry
          then have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) =XBOOLE-0R4 {SEQ-4K1 p}"
            using relat_1_th_115 sorry
          then have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be constantFUNCT-1V5"
             sorry
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
             sorry
        qed
        have case2: "p <XXREAL-0R3 g implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
        proof(rule impI)
          assume A4: "p <XXREAL-0R3 g"
          have "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
          proof-
            show "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
            proof-
              have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
                using A1 rfunct_2_def_5 sorry
              have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
              proof(rule impI)
                assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
                then have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-decreasingRFUNCT-2V3"
                   sorry
                have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
                proof(rule ballI,rule impI)
                  have A6: "[.RCOMP-1K1 p,g .] =XBOOLE-0R4 ].RCOMP-1K2 p,g .[ \\/XBOOLE-0K2 {TARSKIK2 p,g }"
                    using A2 xxreal_1_th_128 sorry
                  fix x0 assume [ty]: "x0 be RealXREAL-0M1"
                  have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
                    using relat_1_th_129 sorry
                  assume A8: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  have A9: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
                    using A8 funct_1_def_6 sorry
                  have 
                    [ty]:"x0 be RealXREAL-0M1"
                     sorry
                  have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 [.RCOMP-1K1 p,g .]"
                    using A3 A9 relat_1_th_129 sorry
                  then have A10: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK2 p,g }"
                    using A6 xboole_0_def_3 sorry
                  have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                  proof(rule ballI)
                    fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                    have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof-
                      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                      proof-
                        have cases: "((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p) or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g"
                          using A10 tarski_def_2 sorry
                        have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .["
                          then obtain N2 where
                            [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                            A11: "N2 c=TARSKIR1 ].RCOMP-1K2 p,g .["
                            using rcomp_1_th_18 sorry
                          have A12: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          obtain N3 where
                            [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                            A13: "N3 c=TARSKIR1 N1"and A14: "N3 c=TARSKIR1 N2"
                            using rcomp_1_th_17 sorry
                          obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A15: "r >XXREAL-0R4 0NUMBERSK6"and A16: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          have A17: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A15 xreal_1_th_29 xreal_1_th_215 sorry
                          let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                          have A18: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A15 xreal_1_th_29 xreal_1_th_215 sorry
                          have A19: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                            using A15 xreal_1_th_29 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                            using xreal_1_th_9 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A18 xxreal_0_th_2 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r }"
                            using A17 sorry
                          then have A20: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          then have "?M2 inTARSKIR2 N2"
                            using A14 A16 sorry
                          then have "?M2 inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using A11 sorry
                          then obtain x2 where
                            [ty]:"x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A21: "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inTARSKIR2 X"and A22: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2"
                            using A3 A7 A12 partfun2_th_59 sorry
                          have A23: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                          have A24: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A15 xreal_1_th_29 xreal_1_th_215 sorry
                          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using A18 xreal_1_th_19 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                            using A19 xxreal_0_th_2 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r }"
                            using A24 sorry
                          then have A25: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          then have "?M1 inTARSKIR2 N2"
                            using A14 A16 sorry
                          then have "?M1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using A11 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A26: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A27: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A7 A23 partfun2_th_59 sorry
                          have A28: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A15 xreal_1_th_29 xreal_1_th_215 sorry
                          then have A29: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using xreal_1_th_19 sorry
                          have A30: "x0 <XXREAL-0R3 x1 implies  False "
                          proof(rule impI)
                            assume A31: "x0 <XXREAL-0R3 x1"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A8 A26 xboole_0_def_4 sorry
                            thus " False "
                              using A5 A27 A29 A31 rfunct_2_th_22 sorry
                          qed
                          have A32: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using A15 xreal_1_th_29 xreal_1_th_215 sorry
                          have A33: "x2 <XXREAL-0R3 x0 implies  False "
                          proof(rule impI)
                            assume A34: "x2 <XXREAL-0R3 x0"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A8 A21 xboole_0_def_4 sorry
                            thus " False "
                              using A5 A22 A32 A34 rfunct_2_th_22 sorry
                          qed
                          have "x0 <>HIDDENR2 x2"
                            using A15 A22 xreal_1_th_29 xreal_1_th_215 sorry
                          then have "x0 <XXREAL-0R3 x2"
                            using A33 xxreal_0_th_1 sorry
                          then have A35: "x2 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                            using xreal_1_th_50 sorry
                          let ?R = "minXXREAL-0K4(x0 -XCMPLX-0K6 x1,x2 -XCMPLX-0K6 x0)"
                          have A36: "?R <=XXREAL-0R1 x2 -XCMPLX-0K6 x0"
                            using xxreal_0_th_17 sorry
                          have "x1 <>HIDDENR2 x0"
                            using A27 A28 xreal_1_th_19 sorry
                          then have "x1 <XXREAL-0R3 x0"
                            using A30 xxreal_0_th_1 sorry
                          then have "x0 -XCMPLX-0K6 x1 >XXREAL-0R4 0NUMBERSK6"
                            using xreal_1_th_50 sorry
                          then have "?R >XXREAL-0R4 0NUMBERSK6"
                            using A35 xxreal_0_th_15 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                            using rcomp_1_def_6 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A37: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A38: "x inHIDDENR3 N"
                            have A39: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A37 xboole_1_th_28 sorry
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R }"
                              using A38 rcomp_1_def_2 sorry
                            then have A40: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                               sorry
                            then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                              using xreal_1_th_19 sorry
                            then have A41: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                              using xreal_1_th_9 sorry
                            have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 x1"
                              using xxreal_0_th_17 sorry
                            then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 x1"
                              using A41 xxreal_0_th_2 sorry
                            then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 x1)"
                              using xreal_1_th_24 sorry
                            then have A42: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (x1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                              using xreal_1_th_6 sorry
                            have "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A26 xboole_0_def_4 sorry
                            then have A43: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A5 A42 A39 rfunct_2_th_22 sorry
                            have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                              using A40 xreal_1_th_19 sorry
                            then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 x2 -XCMPLX-0K6 x0"
                              using A36 xxreal_0_th_2 sorry
                            then have A44: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (x2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                              using xreal_1_th_6 sorry
                            have "x2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A21 xboole_0_def_4 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2"
                              using A5 A44 A39 rfunct_2_th_22 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : ?M1 <=XXREAL-0R1 s & s <=XXREAL-0R1 ?M2 }"
                              using A27 A22 A43 sorry
                            then have A45: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                              using rcomp_1_def_1 sorry
                            have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                              using A25 A20 xxreal_2_def_12 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                              using A16 A45 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A13 sorry
                          qed "sorry"
                        qed
                        have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume A46: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                          then obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A47: "r >XXREAL-0R4 0NUMBERSK6"and A48: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                            using rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          let ?R = "minXXREAL-0K4(r,g -XCMPLX-0K6 p) /XCMPLX-0K7 \<two>\<^sub>M"
                          have "g -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                            using A4 xreal_1_th_50 sorry
                          then have A49: "minXXREAL-0K4(r,g -XCMPLX-0K6 p) >XXREAL-0R4 0NUMBERSK6"
                            using A47 xxreal_0_th_15 sorry
                          then have A50: "?R <XXREAL-0R3 minXXREAL-0K4(r,g -XCMPLX-0K6 p)"
                            using xreal_1_th_216 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 r"
                            using xxreal_0_th_17 sorry
                          then have A51: "?R <XXREAL-0R3 r"
                            using A50 xxreal_0_th_2 sorry
                          then have A52: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using xreal_1_th_6 sorry
                          have A53: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                            using A49 xreal_1_th_44 xreal_1_th_215 sorry
                          have "-XCMPLX-0K4 r <XXREAL-0R3 -XCMPLX-0K4 ?R"
                            using A51 xreal_1_th_24 sorry
                          then have A54: "p +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 p +XCMPLX-0K2 (-XCMPLX-0K4 ?R)"
                            using xreal_1_th_6 sorry
                          have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using A47 xreal_1_th_29 sorry
                          then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using A53 xxreal_0_th_2 sorry
                          then have "p -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 p +XCMPLX-0K2 r }"
                            using A54 sorry
                          then have A55: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          have A56: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          have A57: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                            using A49 xreal_1_th_29 xreal_1_th_215 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                            using xxreal_0_th_17 sorry
                          then have "?R <XXREAL-0R3 g -XCMPLX-0K6 p"
                            using A50 xxreal_0_th_2 sorry
                          then have "p +XCMPLX-0K2 ?R <XXREAL-0R3 g"
                            using xreal_1_th_20 sorry
                          then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s & s <XXREAL-0R3 g }"
                            using A57 sorry
                          then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using rcomp_1_def_2 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A58: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A59: "p +XCMPLX-0K2 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A7 A56 partfun2_th_59 sorry
                          have A60: "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                            using A58 xboole_0_def_4 sorry
                          have "x1 <XXREAL-0R3 x0 implies  False "
                          proof(rule impI)
                            assume A61: "x1 <XXREAL-0R3 x0"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A8 A58 xboole_0_def_4 sorry
                            thus " False "
                              using A5 A46 A57 A59 A61 rfunct_2_th_22 sorry
                          qed
                          then have "x0 <XXREAL-0R3 x1"
                            using A46 A57 A59 xxreal_0_th_1 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0),x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0) .["
                            using rcomp_1_def_6 xreal_1_th_50 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A62: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A63: "x inHIDDENR3 N"
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0) <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0) }"
                              using A63 rcomp_1_def_2 sorry
                            then have A64: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0)"
                               sorry
                            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p,g .]"
                              using A3 A7 A62 funct_1_def_6 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s & s <=XXREAL-0R1 g }"
                              using rcomp_1_def_1 sorry
                            then have " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s) & s <=XXREAL-0R1 g"
                               sorry
                            then have A65: "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A53 xxreal_0_th_2 sorry
                            have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A62 xboole_0_def_4 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 p +XCMPLX-0K2 ?R"
                              using A5 A59 A60 A64 rfunct_2_th_22 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 ?R <=XXREAL-0R1 s & s <=XXREAL-0R1 p +XCMPLX-0K2 ?R }"
                              using A65 sorry
                            then have A66: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                              using rcomp_1_def_1 sorry
                            have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                              using A47 xreal_1_th_44 sorry
                            then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                              using A57 xxreal_0_th_2 sorry
                            then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 p +XCMPLX-0K2 r }"
                              using A52 sorry
                            then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                              using rcomp_1_def_2 sorry
                            then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                              using A48 A55 xxreal_2_def_12 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A66 sorry
                          qed "sorry"
                        qed
                        have case3: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume A67: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g"
                          have A68: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A69: "r >XXREAL-0R4 0NUMBERSK6"and A70: "N1 =XBOOLE-0R4 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                            using A67 rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          let ?R = "minXXREAL-0K4(r,g -XCMPLX-0K6 p) /XCMPLX-0K7 \<two>\<^sub>M"
                          have "g -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                            using A4 xreal_1_th_50 sorry
                          then have A71: "minXXREAL-0K4(r,g -XCMPLX-0K6 p) >XXREAL-0R4 0NUMBERSK6"
                            using A69 xxreal_0_th_15 sorry
                          then have A72: "?R <XXREAL-0R3 minXXREAL-0K4(r,g -XCMPLX-0K6 p)"
                            using xreal_1_th_216 sorry
                          have A73: "g -XCMPLX-0K6 ?R <XXREAL-0R3 g"
                            using A71 xreal_1_th_44 xreal_1_th_215 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                            using xxreal_0_th_17 sorry
                          then have "?R <XXREAL-0R3 g -XCMPLX-0K6 p"
                            using A72 xxreal_0_th_2 sorry
                          then have "?R +XCMPLX-0K2 p <XXREAL-0R3 g"
                            using xreal_1_th_20 sorry
                          then have "g -XCMPLX-0K6 ?R >XXREAL-0R4 p"
                            using xreal_1_th_20 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s & s <XXREAL-0R3 g }"
                            using A73 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using rcomp_1_def_2 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A74: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A75: "g -XCMPLX-0K6 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A7 A68 partfun2_th_59 sorry
                          have A76: "x0 <XXREAL-0R3 x1 implies  False "
                          proof(rule impI)
                            assume A77: "x0 <XXREAL-0R3 x1"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A8 A74 xboole_0_def_4 sorry
                            thus " False "
                              using A5 A67 A73 A75 A77 rfunct_2_th_22 sorry
                          qed
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 r"
                            using xxreal_0_th_17 sorry
                          then have A78: "?R <XXREAL-0R3 r"
                            using A72 xxreal_0_th_2 sorry
                          then have A79: "g +XCMPLX-0K2 ?R <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using xreal_1_th_6 sorry
                          have "-XCMPLX-0K4 r <XXREAL-0R3 -XCMPLX-0K4 ?R"
                            using A78 xreal_1_th_24 sorry
                          then have A80: "g +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 g +XCMPLX-0K2 (-XCMPLX-0K4 ?R)"
                            using xreal_1_th_6 sorry
                          have "g <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using A69 xreal_1_th_29 sorry
                          then have "g -XCMPLX-0K6 ?R <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using A73 xxreal_0_th_2 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 g +XCMPLX-0K2 r }"
                            using A80 sorry
                          then have A81: "g -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          have A82: "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                            using A74 xboole_0_def_4 sorry
                          have A83: "g <XXREAL-0R3 g +XCMPLX-0K2 ?R"
                            using A71 xreal_1_th_29 xreal_1_th_215 sorry
                          have "x1 <>HIDDENR2 x0"
                            using A67 A71 A75 xreal_1_th_44 xreal_1_th_215 sorry
                          then have "x1 <XXREAL-0R3 x0"
                            using A76 xxreal_0_th_1 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1),x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1) .["
                            using rcomp_1_def_6 xreal_1_th_50 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A84: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A85: "x inHIDDENR3 N"
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1) <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1) }"
                              using A85 rcomp_1_def_2 sorry
                            then have A86: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1)"
                               sorry
                            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p,g .]"
                              using A3 A7 A84 funct_1_def_6 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s & s <=XXREAL-0R1 g }"
                              using rcomp_1_def_1 sorry
                            then have " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s) & s <=XXREAL-0R1 g"
                               sorry
                            then have A87: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 g +XCMPLX-0K2 ?R"
                              using A83 xxreal_0_th_2 sorry
                            have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A84 xboole_0_def_4 sorry
                            then have "g -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A5 A75 A82 A86 rfunct_2_th_22 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 ?R <=XXREAL-0R1 s & s <=XXREAL-0R1 g +XCMPLX-0K2 ?R }"
                              using A87 sorry
                            then have A88: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 g -XCMPLX-0K6 ?R,g +XCMPLX-0K2 ?R .]"
                              using rcomp_1_def_1 sorry
                            have "g -XCMPLX-0K6 r <XXREAL-0R3 g"
                              using A69 xreal_1_th_44 sorry
                            then have "g -XCMPLX-0K6 r <XXREAL-0R3 g +XCMPLX-0K2 ?R"
                              using A83 xxreal_0_th_2 sorry
                            then have "g +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 g +XCMPLX-0K2 r }"
                              using A79 sorry
                            then have "g +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                              using rcomp_1_def_2 sorry
                            then have "[.RCOMP-1K1 g -XCMPLX-0K6 ?R,g +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                              using A70 A81 xxreal_2_def_12 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A88 sorry
                          qed "sorry"
                        qed
                        show " ?thesis "
                          using cases case1 case2 case3 sorry
                      qed
                    qed
                    then obtain N where
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
                      A89: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                       sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"])
                      show " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                        using A89 sorry
                    qed "sorry"
                  qed "sorry"
                  thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
                    using fcont_1_th_4 sorry
                qed "sorry"
                thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
                   sorry
              qed
              have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4 implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
              proof(rule impI)
                assume "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
                then have A90: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be non-increasingRFUNCT-2V4"
                   sorry
                have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) implies f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
                proof(rule ballI,rule impI)
                  have A91: "[.RCOMP-1K1 p,g .] =XBOOLE-0R4 ].RCOMP-1K2 p,g .[ \\/XBOOLE-0K2 {TARSKIK2 p,g }"
                    using A2 xxreal_1_th_128 sorry
                  fix x0 assume [ty]: "x0 be RealXREAL-0M1"
                  have A92: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X =XBOOLE-0R4 f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
                    using relat_1_th_129 sorry
                  assume A93: "x0 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                  have A94: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X"
                    using A93 funct_1_def_6 sorry
                  have 
                    [ty]:"x0 be RealXREAL-0M1"
                     sorry
                  have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 [.RCOMP-1K1 p,g .]"
                    using A3 A94 relat_1_th_129 sorry
                  then have A95: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 {TARSKIK2 p,g }"
                    using A91 xboole_0_def_3 sorry
                  have " for N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 holds  ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                  proof(rule ballI)
                    fix N1 assume [ty]: "N1 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                    have " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                    proof-
                      show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                      proof-
                        have cases: "((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p) or (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g"
                          using A95 tarski_def_2 sorry
                        have case1: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .[ implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 inTARSKIR2 ].RCOMP-1K2 p,g .["
                          then obtain N2 where
                            [ty]:"N2 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                            A96: "N2 c=TARSKIR1 ].RCOMP-1K2 p,g .["
                            using rcomp_1_th_18 sorry
                          have A97: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          obtain N3 where
                            [ty]:"N3 be NeighbourhoodRCOMP-1M1-of (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0" and 
                            A98: "N3 c=TARSKIR1 N1"and A99: "N3 c=TARSKIR1 N2"
                            using rcomp_1_th_17 sorry
                          obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A100: "r >XXREAL-0R4 0NUMBERSK6"and A101: "N3 =XBOOLE-0R4 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          have A102: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A100 xreal_1_th_29 xreal_1_th_215 sorry
                          let ?M2 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                          have A103: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A100 xreal_1_th_29 xreal_1_th_215 sorry
                          have A104: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                            using A100 xreal_1_th_29 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r)-XCMPLX-0K6 r"
                            using xreal_1_th_9 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A103 xxreal_0_th_2 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r }"
                            using A102 sorry
                          then have A105: "?M2 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          then have "?M2 inTARSKIR2 N2"
                            using A99 A101 sorry
                          then have "?M2 inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using A96 sorry
                          then obtain x2 where
                            [ty]:"x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A106: "x2 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inTARSKIR2 X"and A107: "?M2 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2"
                            using A3 A92 A97 partfun2_th_59 sorry
                          have A108: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          let ?M1 = "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M"
                          have A109: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r)+XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A100 xreal_1_th_29 xreal_1_th_215 sorry
                          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using A103 xreal_1_th_19 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r"
                            using A104 xxreal_0_th_2 sorry
                          then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r /XCMPLX-0K7 \<two>\<^sub>M inTARSKIR2 {s where s be RealXREAL-0M1 : (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r }"
                            using A109 sorry
                          then have A110: "?M1 inTARSKIR2 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          then have "?M1 inTARSKIR2 N2"
                            using A99 A101 sorry
                          then have "?M1 inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using A96 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A111: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A112: "?M1 =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A92 A108 partfun2_th_59 sorry
                          have A113: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r /XCMPLX-0K7 \<two>\<^sub>M"
                            using A100 xreal_1_th_29 xreal_1_th_215 sorry
                          then have A114: "?M1 <XXREAL-0R3 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using xreal_1_th_19 sorry
                          have A115: "x0 >XXREAL-0R4 x1 implies  False "
                          proof(rule impI)
                            assume A116: "x0 >XXREAL-0R4 x1"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A93 A111 xboole_0_def_4 sorry
                            thus " False "
                              using A90 A112 A114 A116 rfunct_2_th_23 sorry
                          qed
                          have A117: "?M2 >XXREAL-0R4 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0"
                            using A100 xreal_1_th_29 xreal_1_th_215 sorry
                          have A118: "x2 >XXREAL-0R4 x0 implies  False "
                          proof(rule impI)
                            assume A119: "x2 >XXREAL-0R4 x0"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A93 A106 xboole_0_def_4 sorry
                            thus " False "
                              using A90 A107 A117 A119 rfunct_2_th_23 sorry
                          qed
                          have "x0 <>HIDDENR2 x2"
                            using A100 A107 xreal_1_th_29 xreal_1_th_215 sorry
                          then have "x0 >XXREAL-0R4 x2"
                            using A118 xxreal_0_th_1 sorry
                          then have A120: "x0 -XCMPLX-0K6 x2 >XXREAL-0R4 0NUMBERSK6"
                            using xreal_1_th_50 sorry
                          let ?R = "minXXREAL-0K4(x1 -XCMPLX-0K6 x0,x0 -XCMPLX-0K6 x2)"
                          have A121: "?R <=XXREAL-0R1 x1 -XCMPLX-0K6 x0"
                            using xxreal_0_th_17 sorry
                          have "x1 <>HIDDENR2 x0"
                            using A112 A113 xreal_1_th_19 sorry
                          then have "x1 >XXREAL-0R4 x0"
                            using A115 xxreal_0_th_1 sorry
                          then have "x1 -XCMPLX-0K6 x0 >XXREAL-0R4 0NUMBERSK6"
                            using xreal_1_th_50 sorry
                          then have "?R >XXREAL-0R4 0NUMBERSK6"
                            using A120 xxreal_0_th_15 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 ?R,x0 +XCMPLX-0K2 ?R .["
                            using rcomp_1_def_6 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A122: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A123: "x inHIDDENR3 N"
                            have A124: "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A122 xboole_1_th_28 sorry
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R }"
                              using A123 rcomp_1_def_2 sorry
                            then have A125: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 ?R <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 ?R"
                               sorry
                            then have "x0 <XXREAL-0R3 ?R +XCMPLX-0K2 x"
                              using xreal_1_th_19 sorry
                            then have A126: "x0 -XCMPLX-0K6 x <XXREAL-0R3 (?R +XCMPLX-0K2 x)-XCMPLX-0K6 x"
                              using xreal_1_th_9 sorry
                            have "x -XCMPLX-0K6 x0 <XXREAL-0R3 ?R"
                              using A125 xreal_1_th_19 sorry
                            then have "x -XCMPLX-0K6 x0 <XXREAL-0R3 x1 -XCMPLX-0K6 x0"
                              using A121 xxreal_0_th_2 sorry
                            then have A127: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 <XXREAL-0R3 (x1 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                              using xreal_1_th_6 sorry
                            have "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A111 xboole_0_def_4 sorry
                            then have A128: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A90 A127 A124 rfunct_2_th_23 sorry
                            have "?R <=XXREAL-0R1 x0 -XCMPLX-0K6 x2"
                              using xxreal_0_th_17 sorry
                            then have "x0 -XCMPLX-0K6 x <XXREAL-0R3 x0 -XCMPLX-0K6 x2"
                              using A126 xxreal_0_th_2 sorry
                            then have "-XCMPLX-0K4 (x0 -XCMPLX-0K6 x) >XXREAL-0R4 -XCMPLX-0K4 (x0 -XCMPLX-0K6 x2)"
                              using xreal_1_th_24 sorry
                            then have A129: "(x -XCMPLX-0K6 x0)+XCMPLX-0K2 x0 >XXREAL-0R4 (x2 -XCMPLX-0K6 x0)+XCMPLX-0K2 x0"
                              using xreal_1_th_6 sorry
                            have "x2 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A106 xboole_0_def_4 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x2"
                              using A90 A129 A124 rfunct_2_th_23 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : ?M1 <=XXREAL-0R1 s & s <=XXREAL-0R1 ?M2 }"
                              using A112 A107 A128 sorry
                            then have A130: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 ?M1,?M2 .]"
                              using rcomp_1_def_1 sorry
                            have "[.RCOMP-1K1 ?M1,?M2 .] c=TARSKIR1 ].RCOMP-1K2 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 -XCMPLX-0K6 r,(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 +XCMPLX-0K2 r .["
                              using A110 A105 xxreal_2_def_12 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N3"
                              using A101 A130 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A98 sorry
                          qed "sorry"
                        qed
                        have case2: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume A131: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 p"
                          then obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A132: "r >XXREAL-0R4 0NUMBERSK6"and A133: "N1 =XBOOLE-0R4 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                            using rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          let ?R = "minXXREAL-0K4(r,g -XCMPLX-0K6 p) /XCMPLX-0K7 \<two>\<^sub>M"
                          have "g -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                            using A4 xreal_1_th_50 sorry
                          then have A134: "minXXREAL-0K4(r,g -XCMPLX-0K6 p) >XXREAL-0R4 0NUMBERSK6"
                            using A132 xxreal_0_th_15 sorry
                          then have A135: "?R <XXREAL-0R3 minXXREAL-0K4(r,g -XCMPLX-0K6 p)"
                            using xreal_1_th_216 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 r"
                            using xxreal_0_th_17 sorry
                          then have A136: "?R <XXREAL-0R3 r"
                            using A135 xxreal_0_th_2 sorry
                          then have A137: "p +XCMPLX-0K2 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using xreal_1_th_6 sorry
                          have A138: "p -XCMPLX-0K6 ?R <XXREAL-0R3 p"
                            using A134 xreal_1_th_44 xreal_1_th_215 sorry
                          have "-XCMPLX-0K4 r <XXREAL-0R3 -XCMPLX-0K4 ?R"
                            using A136 xreal_1_th_24 sorry
                          then have A139: "p +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 p +XCMPLX-0K2 (-XCMPLX-0K4 ?R)"
                            using xreal_1_th_6 sorry
                          have "p <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using A132 xreal_1_th_29 sorry
                          then have "p -XCMPLX-0K6 ?R <XXREAL-0R3 p +XCMPLX-0K2 r"
                            using A138 xxreal_0_th_2 sorry
                          then have "p -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 p +XCMPLX-0K2 r }"
                            using A139 sorry
                          then have A140: "p -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          have A141: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          have A142: "p <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                            using A134 xreal_1_th_29 xreal_1_th_215 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                            using xxreal_0_th_17 sorry
                          then have "?R <XXREAL-0R3 g -XCMPLX-0K6 p"
                            using A135 xxreal_0_th_2 sorry
                          then have "p +XCMPLX-0K2 ?R <XXREAL-0R3 g"
                            using xreal_1_th_20 sorry
                          then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s & s <XXREAL-0R3 g }"
                            using A142 sorry
                          then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using rcomp_1_def_2 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A143: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A144: "p +XCMPLX-0K2 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A92 A141 partfun2_th_59 sorry
                          have A145: "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                            using A143 xboole_0_def_4 sorry
                          have "x1 >XXREAL-0R4 x0 implies  False "
                          proof(rule impI)
                            assume A146: "x1 >XXREAL-0R4 x0"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A93 A143 xboole_0_def_4 sorry
                            thus " False "
                              using A90 A131 A142 A144 A146 rfunct_2_th_23 sorry
                          qed
                          then have "x0 >XXREAL-0R4 x1"
                            using A131 A142 A144 xxreal_0_th_1 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1),x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1) .["
                            using rcomp_1_def_6 xreal_1_th_50 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A147: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A148: "x inHIDDENR3 N"
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1) <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1) }"
                              using A148 rcomp_1_def_2 sorry
                            then have A149: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x0 -XCMPLX-0K6 x1) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x0 -XCMPLX-0K6 x1)"
                               sorry
                            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p,g .]"
                              using A3 A92 A147 funct_1_def_6 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s & s <=XXREAL-0R1 g }"
                              using rcomp_1_def_1 sorry
                            then have " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s) & s <=XXREAL-0R1 g"
                               sorry
                            then have A150: "p -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A138 xxreal_0_th_2 sorry
                            have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A147 xboole_0_def_4 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 p +XCMPLX-0K2 ?R"
                              using A90 A144 A145 A149 rfunct_2_th_23 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 ?R <=XXREAL-0R1 s & s <=XXREAL-0R1 p +XCMPLX-0K2 ?R }"
                              using A150 sorry
                            then have A151: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .]"
                              using rcomp_1_def_1 sorry
                            have "p -XCMPLX-0K6 r <XXREAL-0R3 p"
                              using A132 xreal_1_th_44 sorry
                            then have "p -XCMPLX-0K6 r <XXREAL-0R3 p +XCMPLX-0K2 ?R"
                              using A142 xxreal_0_th_2 sorry
                            then have "p +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 p +XCMPLX-0K2 r }"
                              using A137 sorry
                            then have "p +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 p -XCMPLX-0K6 r,p +XCMPLX-0K2 r .["
                              using rcomp_1_def_2 sorry
                            then have "[.RCOMP-1K1 p -XCMPLX-0K6 ?R,p +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                              using A133 A140 xxreal_2_def_12 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A151 sorry
                          qed "sorry"
                        qed
                        have case3: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g implies ( ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1)"
                        proof(rule impI)
                          assume A152: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x0 =COMPLEX1R1 g"
                          have A153: "].RCOMP-1K2 p,g .[ c=TARSKIR1 [.RCOMP-1K1 p,g .]"
                            using xxreal_1_th_25 sorry
                          obtain r where
                            [ty]:"r be RealXREAL-0M1" and 
                            A154: "r >XXREAL-0R4 0NUMBERSK6"and A155: "N1 =XBOOLE-0R4 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                            using A152 rcomp_1_def_6 sorry
                          have 
                            [ty]:"r be RealXREAL-0M1"
                             sorry
                          let ?R = "minXXREAL-0K4(r,g -XCMPLX-0K6 p) /XCMPLX-0K7 \<two>\<^sub>M"
                          have "g -XCMPLX-0K6 p >XXREAL-0R4 0NUMBERSK6"
                            using A4 xreal_1_th_50 sorry
                          then have A156: "minXXREAL-0K4(r,g -XCMPLX-0K6 p) >XXREAL-0R4 0NUMBERSK6"
                            using A154 xxreal_0_th_15 sorry
                          then have A157: "?R <XXREAL-0R3 minXXREAL-0K4(r,g -XCMPLX-0K6 p)"
                            using xreal_1_th_216 sorry
                          have A158: "g -XCMPLX-0K6 ?R <XXREAL-0R3 g"
                            using A156 xreal_1_th_44 xreal_1_th_215 sorry
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 g -XCMPLX-0K6 p"
                            using xxreal_0_th_17 sorry
                          then have "?R <XXREAL-0R3 g -XCMPLX-0K6 p"
                            using A157 xxreal_0_th_2 sorry
                          then have "?R +XCMPLX-0K2 p <XXREAL-0R3 g"
                            using xreal_1_th_20 sorry
                          then have "g -XCMPLX-0K6 ?R >XXREAL-0R4 p"
                            using xreal_1_th_20 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : p <XXREAL-0R3 s & s <XXREAL-0R3 g }"
                            using A158 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 p,g .["
                            using rcomp_1_def_2 sorry
                          then obtain x1 where
                            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                            A159: "x1 inTARSKIR2 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X"and A160: "g -XCMPLX-0K6 ?R =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1"
                            using A3 A92 A153 partfun2_th_59 sorry
                          have A161: "x0 >XXREAL-0R4 x1 implies  False "
                          proof(rule impI)
                            assume A162: "x0 >XXREAL-0R4 x1"
                            have "x0 inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A93 A159 xboole_0_def_4 sorry
                            thus " False "
                              using A90 A152 A158 A160 A162 rfunct_2_th_23 sorry
                          qed
                          have "minXXREAL-0K4(r,g -XCMPLX-0K6 p) <=XXREAL-0R1 r"
                            using xxreal_0_th_17 sorry
                          then have A163: "?R <XXREAL-0R3 r"
                            using A157 xxreal_0_th_2 sorry
                          then have A164: "g +XCMPLX-0K2 ?R <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using xreal_1_th_6 sorry
                          have "-XCMPLX-0K4 r <XXREAL-0R3 -XCMPLX-0K4 ?R"
                            using A163 xreal_1_th_24 sorry
                          then have A165: "g +XCMPLX-0K2 (-XCMPLX-0K4 r) <XXREAL-0R3 g +XCMPLX-0K2 (-XCMPLX-0K4 ?R)"
                            using xreal_1_th_6 sorry
                          have "g <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using A154 xreal_1_th_29 sorry
                          then have "g -XCMPLX-0K6 ?R <XXREAL-0R3 g +XCMPLX-0K2 r"
                            using A158 xxreal_0_th_2 sorry
                          then have "g -XCMPLX-0K6 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 g +XCMPLX-0K2 r }"
                            using A165 sorry
                          then have A166: "g -XCMPLX-0K6 ?R inTARSKIR2 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                            using rcomp_1_def_2 sorry
                          have A167: "x1 inTARSKIR2 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                            using A159 xboole_0_def_4 sorry
                          have A168: "g <XXREAL-0R3 g +XCMPLX-0K2 ?R"
                            using A156 xreal_1_th_29 xreal_1_th_215 sorry
                          have "x1 <>HIDDENR2 x0"
                            using A152 A156 A160 xreal_1_th_44 xreal_1_th_215 sorry
                          then have "x1 >XXREAL-0R4 x0"
                            using A161 xxreal_0_th_1 sorry
                          then obtain N where 
                            [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and NDef:"N = ].RCOMP-1K2 x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0),x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0) .["
                            using rcomp_1_def_6 xreal_1_th_50 sorry
                          show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                          proof(rule bexI[of _ "N"],rule ballI,rule impMI ,rule impI)
                            fix x assume [ty]: "x be RealXREAL-0M1"
                            assume A169: "x inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              and A170: "x inHIDDENR3 N"
                            have "x inHIDDENR3 {s where s be RealXREAL-0M1 : x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0) <XXREAL-0R3 s & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0) }"
                              using A170 rcomp_1_def_2 sorry
                            then have A171: " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 x & x0 -XCMPLX-0K6 (x1 -XCMPLX-0K6 x0) <XXREAL-0R3 s) & s <XXREAL-0R3 x0 +XCMPLX-0K2 (x1 -XCMPLX-0K6 x0)"
                               sorry
                            have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 p,g .]"
                              using A3 A92 A169 funct_1_def_6 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : p <=XXREAL-0R1 s & s <=XXREAL-0R1 g }"
                              using rcomp_1_def_1 sorry
                            then have " ex s be RealXREAL-0M1 st (s =COMPLEX1R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x & p <=XXREAL-0R1 s) & s <=XXREAL-0R1 g"
                               sorry
                            then have A172: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x <=XXREAL-0R1 g +XCMPLX-0K2 ?R"
                              using A168 xxreal_0_th_2 sorry
                            have "x inHIDDENR3 X /\\SUBSET-1K9\<^bsub>(X)\<^esub> domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X)"
                              using A169 xboole_0_def_4 sorry
                            then have "g -XCMPLX-0K6 ?R <=XXREAL-0R1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x"
                              using A90 A160 A167 A171 rfunct_2_th_23 sorry
                            then have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 ?R <=XXREAL-0R1 s & s <=XXREAL-0R1 g +XCMPLX-0K2 ?R }"
                              using A172 sorry
                            then have A173: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 [.RCOMP-1K1 g -XCMPLX-0K6 ?R,g +XCMPLX-0K2 ?R .]"
                              using rcomp_1_def_1 sorry
                            have "g -XCMPLX-0K6 r <XXREAL-0R3 g"
                              using A154 xreal_1_th_44 sorry
                            then have "g -XCMPLX-0K6 r <XXREAL-0R3 g +XCMPLX-0K2 ?R"
                              using A168 xxreal_0_th_2 sorry
                            then have "g +XCMPLX-0K2 ?R inTARSKIR2 {s where s be RealXREAL-0M1 : g -XCMPLX-0K6 r <XXREAL-0R3 s & s <XXREAL-0R3 g +XCMPLX-0K2 r }"
                              using A164 sorry
                            then have "g +XCMPLX-0K2 ?R inTARSKIR2 ].RCOMP-1K2 g -XCMPLX-0K6 r,g +XCMPLX-0K2 r .["
                              using rcomp_1_def_2 sorry
                            then have "[.RCOMP-1K1 g -XCMPLX-0K6 ?R,g +XCMPLX-0K2 ?R .] c=TARSKIR1 N1"
                              using A155 A166 xxreal_2_def_12 sorry
                            thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x inTARSKIR2 N1"
                              using A173 sorry
                          qed "sorry"
                        qed
                        show " ?thesis "
                          using cases case1 case2 case3 sorry
                      qed
                    qed
                    then obtain N where
                      [ty]:"N be NeighbourhoodRCOMP-1M1-of x0" and 
                      A174: " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                       sorry
                    show " ex N be NeighbourhoodRCOMP-1M1-of x0 st  for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                    proof(rule bexI[of _ "N"])
                      show " for x1 be RealXREAL-0M1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(X)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X) & x1 inHIDDENR3 N implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X).FUNCT-1K1 x1 inTARSKIR2 N1"
                        using A174 sorry
                    qed "sorry"
                  qed "sorry"
                  thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X is-continuous-inFCONT-1R1 x0"
                    using fcont_1_th_4 sorry
                qed "sorry"
                thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> X be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_47:
" for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (p <=XXREAL-0R1 g & [.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f) & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
proof-
  have " for g be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds p <=XXREAL-0R1 g & ([.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f & (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2)) implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix g assume [ty]: "g be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "p <=XXREAL-0R1 g"
      and A2: "[.RCOMP-1K1 p,g .] c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      and A3: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
    have 
      [ty]:"p be RealXREAL-0M1" and
      [ty]:"g be RealXREAL-0M1"
       sorry
    have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
    proof-
      show "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
      proof-
        have cases: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 or f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          using A3 sorry
        have case1: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
        proof(rule impI)
          assume A4: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be increasingRFUNCT-2V1"
          have A5: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using relat_1_th_61 sorry
          also have "... = [.RCOMP-1K1 p,g .]"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 [.RCOMP-1K1 p,g .]"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be increasingRFUNCT-2V1"
            using A4 rfunct_2_th_51 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
            using A1 A5 fcont_1_th_46 sorry
        qed
        have case2: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2 implies (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
        proof(rule impI)
          assume A6: "f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]) be decreasingRFUNCT-2V2"
          have A7: "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using relat_1_th_115 sorry
          also have "... = (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using funct_1_th_33 sorry
          also have "... = rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> ((f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
            using relat_1_th_113 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))"
            using funct_1_th_33 sorry
          also have "... = domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])"
            using relat_1_th_61 sorry
          also have "... = [.RCOMP-1K1 p,g .]"
            using A2 xboole_1_th_28 sorry
          finally have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) =HIDDENR1 [.RCOMP-1K1 p,g .]"
             sorry
          have "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be decreasingRFUNCT-2V2"
            using A6 rfunct_2_th_52 sorry
          thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
            using A1 A7 fcont_1_th_46 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "(f  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .]))\<inverse>PARTFUN2K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>  |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f .:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 p,g .])) be continuousFCONT-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef fcont_1_def_4 ("AffineMapFCONT-1K1'( _ , _ ')" [0,0]164 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"func AffineMapFCONT-1K1(a,b) \<rightarrow> FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) means
  \<lambda>it.  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
proof-
  (*existence*)
    show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds it .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    proof-
      have " ex tVar47 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar47 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
      proof-
        obtain a9 b9 where 
          [ty]:"a9 be ElementSUBSET-1M1-of REALNUMBERSK2" and a9Def:"a9 = a" and
          [ty]:"b9 be ElementSUBSET-1M1-of REALNUMBERSK2" and b9Def:"b9 = b"
          using xreal_0_def_1 sorry
        let ?F = "\<lambda>Lamb1. InSUBSET-1K10(a9 *XCMPLX-0K3 Lamb1 +XCMPLX-0K2 b9,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)" and 
          A1: " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 ?F(x)"
          using funct_2_sch_4 sorry
        show " ex tVar47 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st  for x be RealXREAL-0M1 holds tVar47 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
        proof(rule bexI[of _ "f"],rule ballI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain x9 where 
            [ty]:"x9 be ElementSUBSET-1M1-of REALNUMBERSK2" and x9Def:"x9 = x"
            using xreal_0_def_1 sorry
          have "f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x9 =COMPLEX1R1 ?F(x)"
            using A1 sorry
          thus "f .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for it2 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds it1 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) & ( for x be RealXREAL-0M1 holds it2 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies it1 =HIDDENR1 it2"
    proof-
      have " for f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f9 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) holds ( for x be RealXREAL-0M1 holds f .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) & ( for x be RealXREAL-0M1 holds f9 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f9"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix f assume [ty]: "f be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
        assume A2: " for x be RealXREAL-0M1 holds f .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
          and A3: " for x be RealXREAL-0M1 holds f9 .FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
        have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 f9 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
        proof(rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
          have "f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
            using A2 sorry
          also have "... = f9 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
            using A3 sorry
          finally show "f .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 f9 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
             sorry
        qed "sorry"
        thus "f =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f9"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem fcont_1_cl_22:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"cluster AffineMapFCONT-1K1(a,b) as-term-is continuousFCONT-1V1"
proof
(*coherence*)
  show "AffineMapFCONT-1K1(a,b) be continuousFCONT-1V1"
  proof-
    let ?f = "AffineMapFCONT-1K1(a,b)"
    have " for x0 be RealXREAL-0M1 holds x0 inHIDDENR3 REALNUMBERSK2 implies ?f .FUNCT-1K1 x0 =COMPLEX1R1 a *XCMPLX-0K3 x0 +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    then have "REALNUMBERSK2 =XBOOLE-0R4 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f & (AffineMapFCONT-1K1(a,b)) |PARTFUN1K2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> REALNUMBERSK2 be continuousFCONT-1V1"
      using fcont_1_th_41 funct_2_def_1 sorry
    thus "AffineMapFCONT-1K1(a,b) be continuousFCONT-1V1"
       sorry
  qed
qed "sorry"

mtheorem fcont_1_cl_23:
"cluster continuousFCONT-1V1 for FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st it be continuousFCONT-1V1"
  proof-
    have " ex tVar48 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar48 be continuousFCONT-1V1"
    proof-
      show " ex tVar48 be FunctionFUNCT-2M1-of(REALNUMBERSK2,REALNUMBERSK2) st tVar48 be continuousFCONT-1V1"
      proof(rule bexI[of _ "AffineMapFCONT-1K1(\<one>\<^sub>M,\<one>\<^sub>M)"])
        show "AffineMapFCONT-1K1(\<one>\<^sub>M,\<one>\<^sub>M) be continuousFCONT-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem fcont_1_th_48:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 b"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    also have "... = b"
       sorry
    finally show "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_49:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 a +XCMPLX-0K2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a +XCMPLX-0K2 b"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a *XCMPLX-0K3 \<one>\<^sub>M +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    also have "... = a +XCMPLX-0K2 b"
       sorry
    finally show "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 a +XCMPLX-0K2 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_50:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies AffineMapFCONT-1K1(a,b) be one-to-oneFUNCT-1V2"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a <>HIDDENR2 0NUMBERSK6"
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) implies (x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) implies ((AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x1 =COMPLEX1R1 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x2 implies x1 =HIDDENR1 x2))"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule impI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    let ?f = "AffineMapFCONT-1K1(a,b)"
    assume "x1 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
    then obtain r1 where 
      [ty]:"r1 be RealXREAL-0M1" and r1Def:"r1 = x1"
       sorry
    assume "x2 inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ?f"
    then obtain r2 where 
      [ty]:"r2 be RealXREAL-0M1" and r2Def:"r2 = x2"
       sorry
    assume "?f .FUNCT-1K1 x1 =COMPLEX1R1 ?f .FUNCT-1K1 x2"
    then have "a *XCMPLX-0K3 r1 +XCMPLX-0K2 b =HIDDENR1 ?f .FUNCT-1K1 x2"
      using fcont_1_def_4 sorry
    also have "... = a *XCMPLX-0K3 r2 +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    finally have "a *XCMPLX-0K3 r1 +XCMPLX-0K2 b =HIDDENR1 a *XCMPLX-0K3 r2 +XCMPLX-0K2 b"
       sorry
    thus "x1 =HIDDENR1 x2"
      using A1 xcmplx_1_th_5 sorry
  qed "sorry"
  thus "AffineMapFCONT-1K1(a,b) be one-to-oneFUNCT-1V2"
    using funct_1_def_4 sorry
qed "sorry"

mtheorem fcont_1_th_51:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & x <XXREAL-0R3 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <XXREAL-0R3 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & x <XXREAL-0R3 y implies  not (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <XXREAL-0R3 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "a >XXREAL-0R4 0NUMBERSK6 & x <XXREAL-0R3 y"
    then have A1: "a *XCMPLX-0K3 x <XXREAL-0R3 a *XCMPLX-0K3 y"
      using xreal_1_th_68 sorry
    have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y =COMPLEX1R1 a *XCMPLX-0K3 y +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    thus " not (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <XXREAL-0R3 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
      using A1 xreal_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_52:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & x <XXREAL-0R3 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >XXREAL-0R4 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <XXREAL-0R3 0NUMBERSK6 & x <XXREAL-0R3 y implies  not (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >XXREAL-0R4 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    assume "a <XXREAL-0R3 0NUMBERSK6 & x <XXREAL-0R3 y"
    then have A1: "a *XCMPLX-0K3 x >XXREAL-0R4 a *XCMPLX-0K3 y"
      using xreal_1_th_69 sorry
    have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y =COMPLEX1R1 a *XCMPLX-0K3 y +XCMPLX-0K2 b"
      using fcont_1_def_4 sorry
    thus " not (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >XXREAL-0R4 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
      using A1 xreal_1_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fcont_1_th_53:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & x <=XXREAL-0R1 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <=XXREAL-0R1 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  assume "a >=XXREAL-0R2 0NUMBERSK6 & x <=XXREAL-0R1 y"
  then have A1: "a *XCMPLX-0K3 x <=XXREAL-0R1 a *XCMPLX-0K3 y"
    using xreal_1_th_64 sorry
  have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y =COMPLEX1R1 a *XCMPLX-0K3 y +XCMPLX-0K2 b"
    using fcont_1_def_4 sorry
  thus "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x <=XXREAL-0R1 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
    using A1 xreal_1_th_7 sorry
qed "sorry"

mtheorem fcont_1_th_54:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds a <=XXREAL-0R1 0NUMBERSK6 & x <=XXREAL-0R1 y implies (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >=XXREAL-0R2 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  fix y assume [ty]: "y be RealXREAL-0M1"
  assume "a <=XXREAL-0R1 0NUMBERSK6 & x <=XXREAL-0R1 y"
  then have A1: "a *XCMPLX-0K3 x >=XXREAL-0R2 a *XCMPLX-0K3 y"
    using xreal_1_th_65 sorry
  have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x =COMPLEX1R1 a *XCMPLX-0K3 x +XCMPLX-0K2 b & (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y =COMPLEX1R1 a *XCMPLX-0K3 y +XCMPLX-0K2 b"
    using fcont_1_def_4 sorry
  thus "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 x >=XXREAL-0R2 (AffineMapFCONT-1K1(a,b)).FUNCT-1K1 y"
    using A1 xreal_1_th_7 sorry
qed "sorry"

mtheorem fcont_1_th_55:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) =XBOOLE-0R4 REALNUMBERSK2"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a <>HIDDENR2 0NUMBERSK6"
  have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) c=TARSKIR1 REALNUMBERSK2 & REALNUMBERSK2 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))"
  proof(rule conjMI)
    show "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) c=TARSKIR1 REALNUMBERSK2"
       sorry
    have " for e be objectHIDDENM1 holds e inHIDDENR3 REALNUMBERSK2 implies e inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))"
    proof(rule ballI,rule impI)
      fix e assume [ty]: "e be objectHIDDENM1"
      assume "e inHIDDENR3 REALNUMBERSK2"
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = e"
         sorry
      obtain s where 
        [ty]:"s be ElementSUBSET-1M1-of REALNUMBERSK2" and sDef:"s = (r -XCMPLX-0K6 b)/XCMPLX-0K7 a"
        using xreal_0_def_1 sorry
      have "(AffineMapFCONT-1K1(a,b)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 a *XCMPLX-0K3 s +XCMPLX-0K2 b"
        using fcont_1_def_4 sorry
      also have "... = (r -XCMPLX-0K6 b)+XCMPLX-0K2 b"
        using A1 xcmplx_1_th_87 sorry
      also have "... = r"
         sorry
      finally have "(AffineMapFCONT-1K1(a,b)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> s =HIDDENR1 r"
         sorry
      then have "r inTARSKIR2 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))"
        using funct_2_th_4 sorry
      thus "e inHIDDENR3 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))"
         sorry
    qed "sorry"
    thus "REALNUMBERSK2 c=TARSKIR1 rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))"
      using tarski_def_3 sorry
  qed
  thus "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) =XBOOLE-0R4 REALNUMBERSK2"
    using xboole_0_def_10 sorry
qed "sorry"

mtheorem fcont_1_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies (AffineMapFCONT-1K1(a,b))\<inverse>FUNCT-1K4 =FUNCT-1R1 AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a)"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a <>HIDDENR2 0NUMBERSK6"
  have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =COMPLEX1R1 idPARTFUN1K6 REALNUMBERSK2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
  proof-
    have " for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds ((AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 idPARTFUN1K6 REALNUMBERSK2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
    proof(rule ballI)
      fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "((AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 (AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((AffineMapFCONT-1K1(a,b)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x)"
        using funct_2_th_15 sorry
      also have "... = (AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a)).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)"
        using fcont_1_def_4 sorry
      also have "... = a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a *XCMPLX-0K3 x +XCMPLX-0K2 b) +XCMPLX-0K2 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
        using fcont_1_def_4 sorry
      also have "... = ((a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 a)*XCMPLX-0K3 x +XCMPLX-0K2 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 b)+XCMPLX-0K2 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
         sorry
      also have "... = (\<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 b)+XCMPLX-0K2 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
        using A1 xcmplx_0_def_7 sorry
      also have "... = (x +XCMPLX-0K2 a \<inverse>XCMPLX-0K5 *XCMPLX-0K3 b)-XCMPLX-0K6 b /XCMPLX-0K7 a"
         sorry
      also have "... = (x +XCMPLX-0K2 b /XCMPLX-0K7 a)-XCMPLX-0K6 b /XCMPLX-0K7 a"
        using xcmplx_0_def_9 sorry
      also have "... = idPARTFUN1K6 REALNUMBERSK2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
         sorry
      finally show "((AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b))).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x =HIDDENR1 idPARTFUN1K6 REALNUMBERSK2 .FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> x"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  then have A2: "(AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a))*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) =FUNCT-2R2\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN1K6 REALNUMBERSK2"
    using funct_2_th_63 sorry
  have "rngRELSET-1K2\<^bsub>(REALNUMBERSK2)\<^esub> (AffineMapFCONT-1K1(a,b)) =XBOOLE-0R4 REALNUMBERSK2"
    using A1 fcont_1_th_55 sorry
  thus "(AffineMapFCONT-1K1(a,b))\<inverse>FUNCT-1K4 =FUNCT-1R1 AffineMapFCONT-1K1(a \<inverse>XCMPLX-0K5,-XCMPLX-0K4 b /XCMPLX-0K7 a)"
    using A1 A2 fcont_1_th_50 funct_2_th_30 sorry
qed "sorry"

mtheorem fcont_1_th_57:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
proof(rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  assume A1: "a >XXREAL-0R4 0NUMBERSK6"
  have "(AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) c=TARSKIR1 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .] & [.RCOMP-1K1 b,a +XCMPLX-0K2 b .] c=TARSKIR1 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
  proof(rule conjMI)
    show "(AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) c=TARSKIR1 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
    proof-
      have A2: "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 \<one>\<^sub>M =COMPLEX1R1 a +XCMPLX-0K2 b"
        using fcont_1_th_49 sorry
      have " for u be objectHIDDENM1 holds u inHIDDENR3 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) implies u inHIDDENR3 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
      proof(rule ballI,rule impI)
        fix u assume [ty]: "u be objectHIDDENM1"
        assume "u inHIDDENR3 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
        then obtain r where
          [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A3: "r inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"and A4: "u =HIDDENR1 (AffineMapFCONT-1K1(a,b)).FUNCT-2K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> r"
          using funct_2_th_65 sorry
        obtain s where 
          [ty]:"s be RealXREAL-0M1" and sDef:"s = u"
          using A4 sorry
        have "r <=XXREAL-0R1 \<one>\<^sub>M"
          using A3 xxreal_1_th_1 sorry
        then have A5: "s <=XXREAL-0R1 a +XCMPLX-0K2 b"
          using A1 A4 A2 fcont_1_th_53 sorry
        have A6: "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 b"
          using fcont_1_th_48 sorry
        have "0NUMBERSK6 <=XXREAL-0R1 r"
          using A3 xxreal_1_th_1 sorry
        then have "b <=XXREAL-0R1 s"
          using A1 A4 A6 fcont_1_th_53 sorry
        thus "u inHIDDENR3 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
          using A5 xxreal_1_th_1 sorry
      qed "sorry"
      thus "(AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) c=TARSKIR1 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
        using tarski_def_3 sorry
    qed
    have " for u be objectHIDDENM1 holds u inHIDDENR3 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .] implies u inHIDDENR3 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
    proof(rule ballI,rule impI)
      fix u assume [ty]: "u be objectHIDDENM1"
      assume A7: "u inHIDDENR3 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of REALNUMBERSK2" and rDef:"r = u"
         sorry
      let ?s = "(r -XCMPLX-0K6 b)/XCMPLX-0K7 a"
      have A8: "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 ?s =HIDDENR1 a *XCMPLX-0K3 ?s +XCMPLX-0K2 b"
        using fcont_1_def_4 sorry
      also have "... = (r -XCMPLX-0K6 b)+XCMPLX-0K2 b"
        using A1 xcmplx_1_th_87 sorry
      also have "... = r"
         sorry
      finally have "(AffineMapFCONT-1K1(a,b)).FUNCT-1K1 ?s =HIDDENR1 r"
         sorry
      have "r <=XXREAL-0R1 a +XCMPLX-0K2 b"
        using A7 xxreal_1_th_1 sorry
      then have "r -XCMPLX-0K6 b <=XXREAL-0R1 a"
        using xreal_1_th_20 sorry
      then have "?s <=XXREAL-0R1 a /XCMPLX-0K7 a"
        using A1 xreal_1_th_72 sorry
      then have A9: "?s <=XXREAL-0R1 \<one>\<^sub>M"
        using A1 xcmplx_1_th_60 sorry
      have "b <=XXREAL-0R1 r"
        using A7 xxreal_1_th_1 sorry
      then have "0NUMBERSK6 <=XXREAL-0R1 r -XCMPLX-0K6 b"
        using xreal_1_th_48 sorry
      then have "?s inTARSKIR2 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
        using A1 A9 xxreal_1_th_1 sorry
      thus "u inHIDDENR3 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
        using A8 funct_2_th_35 sorry
    qed "sorry"
    thus "[.RCOMP-1K1 b,a +XCMPLX-0K2 b .] c=TARSKIR1 (AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .])"
      using tarski_def_3 sorry
  qed
  thus "(AffineMapFCONT-1K1(a,b)).:RELSET-1K7\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ([.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]) =XBOOLE-0R4 [.RCOMP-1K1 b,a +XCMPLX-0K2 b .]"
    using xboole_0_def_10 sorry
qed "sorry"

end
