theory recdef_2
  imports funct_7 binarith
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b, c, d, e, z for "objectHIDDENM1"
reserve A, B, C, D, E for "setHIDDENM2"
abbreviation(input) RECDEF_2K1(" _ `1-3RECDEF-2K1" [164]164) where
  "x `1-3RECDEF-2K1 \<equiv> x `1-3XTUPLE-0K4"

mtheorem recdef_2_def_1:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `1-3RECDEF-2K1 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y1"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-3RECDEF-2K1 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y1)"
  proof-
    obtain x1 x2 x3 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using xtuple_0_def_5 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-3RECDEF-2K1 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y1)"
      using A1 sorry
  qed
qed "sorry"

abbreviation(input) RECDEF_2K2(" _ `2-3RECDEF-2K2" [164]164) where
  "x `2-3RECDEF-2K2 \<equiv> x `2-3XTUPLE-0K5"

mtheorem recdef_2_def_2:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `2-3RECDEF-2K2 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y2"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-3RECDEF-2K2 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y2)"
  proof-
    obtain x1 x2 x3 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using xtuple_0_def_5 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-3RECDEF-2K2 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y2)"
      using A1 sorry
  qed
qed "sorry"

abbreviation(input) RECDEF_2K3(" _ `3-3RECDEF-2K3" [164]164) where
  "x `3-3RECDEF-2K3 \<equiv> x `2XTUPLE-0K2"

mtheorem recdef_2_def_3:
  mlet "x be tripleXTUPLE-0V2\<bar>objectHIDDENM1"
"redefine func x `3-3RECDEF-2K3 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y3"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-3RECDEF-2K3 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y3)"
  proof-
    obtain x1 x2 x3 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K3 x1,x2,x3 ]"
      using xtuple_0_def_5 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-3RECDEF-2K3 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K3 y1,y2,y3 ] implies it =HIDDENR1 y3)"
      using A1 sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem recdef_2_th_2:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies (z `1-3XTUPLE-0K4 inHIDDENR3 A & z `2-3XTUPLE-0K5 inHIDDENR3 B) & z `3-3XTUPLE-0K6 inHIDDENR3 C"
proof-
  have " for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies (z `1-3XTUPLE-0K4 inHIDDENR3 A & z `2-3XTUPLE-0K5 inHIDDENR3 B) & z `3-3XTUPLE-0K6 inHIDDENR3 C"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K3 A,B,C :]"
    then have A2: "C be  non emptyXBOOLE-0V1"
      using mcart_1_th_31 sorry
    have A3: "A be  non emptyXBOOLE-0V1 & B be  non emptyXBOOLE-0V1"
      using A1 mcart_1_th_31 sorry
    then obtain a b c where
      [ty]:"a be ElementSUBSET-1M1-of A" "b be ElementSUBSET-1M1-of B" "c be ElementSUBSET-1M1-of C" and 
      A4: "z =HIDDENR1 [XTUPLE-0K3 a,b,c ]"
      using A1 A2 domain_1_th_3 sorry
    have A5: "z `3-3XTUPLE-0K6 =HIDDENR1 c"
      using A4 sorry
    have "z `1-3XTUPLE-0K4 =HIDDENR1 a & z `2-3XTUPLE-0K5 =HIDDENR1 b"
      using A4 sorry
    thus "(z `1-3XTUPLE-0K4 inHIDDENR3 A & z `2-3XTUPLE-0K5 inHIDDENR3 B) & z `3-3XTUPLE-0K6 inHIDDENR3 C"
      using A3 A2 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem recdef_2_th_3:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies z =HIDDENR1 [XTUPLE-0K3 z `1-3XTUPLE-0K4,z `2-3XTUPLE-0K5,z `3-3XTUPLE-0K6 ]"
proof-
  have " for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K3 A,B,C :] implies z =HIDDENR1 [XTUPLE-0K3 z `1-3XTUPLE-0K4,z `2-3XTUPLE-0K5,z `3-3XTUPLE-0K6 ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K3 A,B,C :]"
    then have A2: "C be  non emptyXBOOLE-0V1"
      using mcart_1_th_31 sorry
    have "A be  non emptyXBOOLE-0V1 & B be  non emptyXBOOLE-0V1"
      using A1 mcart_1_th_31 sorry
    then have " ex a be ElementSUBSET-1M1-of A st  ex b be ElementSUBSET-1M1-of B st  ex c be ElementSUBSET-1M1-of C st z =HIDDENR1 [XTUPLE-0K3 a,b,c ]"
      using A1 A2 domain_1_th_3 sorry
    thus "z =HIDDENR1 [XTUPLE-0K3 z `1-3XTUPLE-0K4,z `2-3XTUPLE-0K5,z `3-3XTUPLE-0K6 ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) RECDEF_2K4(" _ `1-4RECDEF-2K4" [164]164) where
  "x `1-4RECDEF-2K4 \<equiv> x `1-4XTUPLE-0K8"

mtheorem recdef_2_def_4:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `1-4RECDEF-2K4 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y1"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-4RECDEF-2K4 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y1)"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using xtuple_0_def_9 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `1-4RECDEF-2K4 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y1)"
      using A1 sorry
  qed
qed "sorry"

abbreviation(input) RECDEF_2K5(" _ `2-4RECDEF-2K5" [164]164) where
  "x `2-4RECDEF-2K5 \<equiv> x `2-4XTUPLE-0K9"

mtheorem recdef_2_def_5:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `2-4RECDEF-2K5 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y2"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-4RECDEF-2K5 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y2)"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using xtuple_0_def_9 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `2-4RECDEF-2K5 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y2)"
      using A1 sorry
  qed
qed "sorry"

abbreviation(input) RECDEF_2K6(" _ `3-4RECDEF-2K6" [164]164) where
  "x `3-4RECDEF-2K6 \<equiv> x `2-3XTUPLE-0K5"

mtheorem recdef_2_def_6:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `3-4RECDEF-2K6 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y3"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-4RECDEF-2K6 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y3)"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using xtuple_0_def_9 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `3-4RECDEF-2K6 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y3)"
      using A1 sorry
  qed
qed "sorry"

abbreviation(input) RECDEF_2K7(" _ `4-4RECDEF-2K7" [164]164) where
  "x `4-4RECDEF-2K7 \<equiv> x `2XTUPLE-0K2"

mtheorem recdef_2_def_7:
  mlet "x be quadrupleXTUPLE-0V3\<bar>objectHIDDENM1"
"redefine func x `4-4RECDEF-2K7 \<rightarrow> objectHIDDENM1 means
  \<lambda>it.  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y4"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds it =HIDDENR1 x `4-4RECDEF-2K7 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y4)"
  proof-
    obtain x1 x2 x3 x4 where
      [ty]:"x1 be objectHIDDENM1" "x2 be objectHIDDENM1" "x3 be objectHIDDENM1" "x4 be objectHIDDENM1" and 
      A1: "x =HIDDENR1 [XTUPLE-0K7 x1,x2,x3,x4 ]"
      using xtuple_0_def_9 sorry
    show " for it be objectHIDDENM1 holds it =HIDDENR1 x `4-4RECDEF-2K7 iff ( for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds  for y3 be objectHIDDENM1 holds  for y4 be objectHIDDENM1 holds x =HIDDENR1 [XTUPLE-0K7 y1,y2,y3,y4 ] implies it =HIDDENR1 y4)"
      using A1 sorry
  qed
qed "sorry"

(*\$CT*)
mtheorem recdef_2_th_5:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies ((z `1-4XTUPLE-0K8 inHIDDENR3 A & z `2-4XTUPLE-0K9 inHIDDENR3 B) & z `3-4XTUPLE-0K10 inHIDDENR3 C) & z `4-4XTUPLE-0K11 inHIDDENR3 D"
proof-
  have " for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies ((z `1-4XTUPLE-0K8 inHIDDENR3 A & z `2-4XTUPLE-0K9 inHIDDENR3 B) & z `3-4XTUPLE-0K10 inHIDDENR3 C) & z `4-4XTUPLE-0K11 inHIDDENR3 D"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    fix D assume [ty]: "D be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :]"
    then have A2: "C be  non emptyXBOOLE-0V1 & D be  non emptyXBOOLE-0V1"
      using mcart_1_th_51 sorry
    have A3: "A be  non emptyXBOOLE-0V1 & B be  non emptyXBOOLE-0V1"
      using A1 mcart_1_th_51 sorry
    then obtain a b c d where
      [ty]:"a be ElementSUBSET-1M1-of A" "b be ElementSUBSET-1M1-of B" "c be ElementSUBSET-1M1-of C" "d be ElementSUBSET-1M1-of D" and 
      A4: "z =HIDDENR1 [XTUPLE-0K7 a,b,c,d ]"
      using A1 A2 domain_1_th_10 sorry
    have A5: "z `3-4XTUPLE-0K10 =HIDDENR1 c & z `4-4XTUPLE-0K11 =HIDDENR1 d"
      using A4 sorry
    have "z `1-4XTUPLE-0K8 =HIDDENR1 a & z `2-4XTUPLE-0K9 =HIDDENR1 b"
      using A4 sorry
    thus "((z `1-4XTUPLE-0K8 inHIDDENR3 A & z `2-4XTUPLE-0K9 inHIDDENR3 B) & z `3-4XTUPLE-0K10 inHIDDENR3 C) & z `4-4XTUPLE-0K11 inHIDDENR3 D"
      using A3 A2 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem recdef_2_th_6:
" for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies z =HIDDENR1 [XTUPLE-0K7 z `1-4XTUPLE-0K8,z `2-4XTUPLE-0K9,z `3-4XTUPLE-0K10,z `4-4XTUPLE-0K11 ]"
proof-
  have " for z be objectHIDDENM1 holds  for A be setHIDDENM2 holds  for B be setHIDDENM2 holds  for C be setHIDDENM2 holds  for D be setHIDDENM2 holds z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :] implies z =HIDDENR1 [XTUPLE-0K7 z `1-4XTUPLE-0K8,z `2-4XTUPLE-0K9,z `3-4XTUPLE-0K10,z `4-4XTUPLE-0K11 ]"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    fix A assume [ty]: "A be setHIDDENM2"
    fix B assume [ty]: "B be setHIDDENM2"
    fix C assume [ty]: "C be setHIDDENM2"
    fix D assume [ty]: "D be setHIDDENM2"
    assume A1: "z inHIDDENR3 [:ZFMISC-1K4 A,B,C,D :]"
    then have A2: "C be  non emptyXBOOLE-0V1 & D be  non emptyXBOOLE-0V1"
      using mcart_1_th_51 sorry
    have "A be  non emptyXBOOLE-0V1 & B be  non emptyXBOOLE-0V1"
      using A1 mcart_1_th_51 sorry
    then have " ex a be ElementSUBSET-1M1-of A st  ex b be ElementSUBSET-1M1-of B st  ex c be ElementSUBSET-1M1-of C st  ex d be ElementSUBSET-1M1-of D st z =HIDDENR1 [XTUPLE-0K7 a,b,c,d ]"
      using A1 A2 domain_1_th_10 sorry
    thus "z =HIDDENR1 [XTUPLE-0K7 z `1-4XTUPLE-0K8,z `2-4XTUPLE-0K9,z `3-4XTUPLE-0K10,z `4-4XTUPLE-0K11 ]"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CD 5*)
(*\$CT 3*)
theorem recdef_2_sch_1:
  fixes Cf0 Ff1 Gf1 Hf1 Pp1 Qp1 Rp1 
  assumes
[ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be objectHIDDENM1" and
   A1: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Rp1(c))" and
   A2: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) or Qp1(c)) or Rp1(c)"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)))"
  proof-
    obtain D1 where
      [ty]:"D1 be setHIDDENM2" and 
      A3: " for x be objectHIDDENM1 holds x inHIDDENR3 D1 iff x inHIDDENR3 Cf0 & Pp1(x)"
      using xboole_0_sch_1 sorry
    obtain D3 where
      [ty]:"D3 be setHIDDENM2" and 
      A4: " for x be objectHIDDENM1 holds x inHIDDENR3 D3 iff x inHIDDENR3 Cf0 & Rp1(x)"
      using xboole_0_sch_1 sorry
    obtain f1 where
      [ty]:"f1 be FunctionFUNCT-1M1" and 
      A5: "domRELAT-1K1 f1 =XBOOLE-0R4 D1"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 D1 implies f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      using funct_1_sch_3 sorry
    obtain D2 where
      [ty]:"D2 be setHIDDENM2" and 
      A7: " for x be objectHIDDENM1 holds x inHIDDENR3 D2 iff x inHIDDENR3 Cf0 & Qp1(x)"
      using xboole_0_sch_1 sorry
    obtain f3 where
      [ty]:"f3 be FunctionFUNCT-1M1" and 
      A8: "domRELAT-1K1 f3 =XBOOLE-0R4 D3"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 D3 implies f3 .FUNCT-1K1 x =HIDDENR1 Hf1(x)"
      using funct_1_sch_3 sorry
    obtain f2 where
      [ty]:"f2 be FunctionFUNCT-1M1" and 
      A10: "domRELAT-1K1 f2 =XBOOLE-0R4 D2"and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 D2 implies f2 .FUNCT-1K1 x =HIDDENR1 Gf1(x)"
      using funct_1_sch_3 sorry
    show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)))"
    proof-
      have " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & ((Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c))))"
      proof-
        obtain f where 
          [ty]:"f be setHIDDENM2" and fDef:"f = (f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3"
           sorry
        show " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & ((Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c))))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule conjMI,rule conjMI,rule impI)
          have A12: "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 (f1 +*FUNCT-4K1 f2) \\/XBOOLE-0K2 domRELAT-1K1 f3"
            using funct_4_def_1 sorry
          also have "... = (domRELAT-1K1 f1 \\/XBOOLE-0K2 domRELAT-1K1 f2)\\/XBOOLE-0K2 domRELAT-1K1 f3"
            using funct_4_def_1 sorry
          finally have "domRELAT-1K1 f =HIDDENR1 (domRELAT-1K1 f1 \\/XBOOLE-0K2 domRELAT-1K1 f2)\\/XBOOLE-0K2 domRELAT-1K1 f3"
             sorry
          show "domRELAT-1K1 f =XBOOLE-0R4 Cf0"
          proof-
            have A13: "D3 c=TARSKIR1 Cf0"
              using A4 sorry
            have A14: "D2 c=TARSKIR1 Cf0"
              using A7 sorry
            have "D1 c=TARSKIR1 Cf0"
              using A3 sorry
            then have Cut204: "D1 \\/XBOOLE-0K2 D2 c=TARSKIR1 Cf0"
              using A14 xboole_1_th_8 sorry
            have "domRELAT-1K1 f c=TARSKIR1 Cf0 & Cf0 c=TARSKIR1 domRELAT-1K1 f"
            proof(rule conjMI)
              show "domRELAT-1K1 f c=TARSKIR1 Cf0"
                using A5 A10 A8 A12 A13 xboole_1_th_8 Cut204 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Cf0 implies x inHIDDENR3 domRELAT-1K1 f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A15: "x inHIDDENR3 Cf0"
                then have "(Pp1(x) or Qp1(x)) or Rp1(x)"
                  using A2 sorry
                then have "(x inHIDDENR3 D1 or x inHIDDENR3 D2) or x inHIDDENR3 D3"
                  using A3 A7 A4 A15 sorry
                then have "x inHIDDENR3 D1 \\/XBOOLE-0K2 D2 or x inHIDDENR3 D3"
                  using xboole_0_def_3 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f"
                  using A5 A10 A8 A12 xboole_0_def_3 sorry
              qed "sorry"
              thus "Cf0 c=TARSKIR1 domRELAT-1K1 f"
                using tarski_def_3 sorry
            qed
            thus "domRELAT-1K1 f =XBOOLE-0R4 Cf0"
              using xboole_0_def_10 sorry
          qed
          fix c assume [ty]: "c be setHIDDENM2"
          assume A16: "c inTARSKIR2 Cf0"
          show "Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
          proof(rule impI)
            assume A17: "Pp1(c)"
            have " not Qp1(c)"
              using A1 A16 A17 sorry
            then have A18: " not c inTARSKIR2 D2"
              using A7 sorry
            have " not Rp1(c)"
              using A1 A16 A17 sorry
            then have " not c inTARSKIR2 D3"
              using A4 sorry
            then have "f .FUNCT-1K1 c =HIDDENR1 (f1 +*FUNCT-4K1 f2).FUNCT-1K1 c"
              using A8 funct_4_th_11 sorry
            also have "... = f1 .FUNCT-1K1 c"
              using A10 A18 funct_4_th_11 sorry
            also have "... = Ff1(c)"
              using A6 A17 A3 A16 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
               sorry
          qed
          show "Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)"
          proof(rule impI)
            assume A19: "Qp1(c)"
            have " not Rp1(c)"
              using A1 A16 A19 sorry
            then have " not c inTARSKIR2 D3"
              using A4 sorry
            then have "f .FUNCT-1K1 c =HIDDENR1 (f1 +*FUNCT-4K1 f2).FUNCT-1K1 c"
              using A8 funct_4_th_11 sorry
            also have "... = f2 .FUNCT-1K1 c"
              using A10 A19 A7 A16 funct_4_th_13 sorry
            also have "... = Gf1(c)"
              using A11 A19 A7 A16 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 Gf1(c)"
               sorry
          qed
          assume A20: "Rp1(c)"
          then have "f .FUNCT-1K1 c =HIDDENR1 f3 .FUNCT-1K1 c"
            using A8 A4 A16 funct_4_th_13 sorry
          also have "... = Hf1(c)"
            using A9 A20 A4 A16 sorry
          finally show "f .FUNCT-1K1 c =HIDDENR1 Hf1(c)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  qed

theorem recdef_2_sch_2:
  fixes Cf0 Ff1 Gf1 Hf1 If1 Pp1 Qp1 Rp1 Sp1 
  assumes
[ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Ff1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Gf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> Hf1(x1) be objectHIDDENM1" and
  [ty_func]: "\<And> x1. x1 be objectHIDDENM1 \<Longrightarrow> If1(x1) be objectHIDDENM1" and
   A1: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (((((Pp1(c) implies  not Qp1(c)) & (Pp1(c) implies  not Rp1(c))) & (Pp1(c) implies  not Sp1(c))) & (Qp1(c) implies  not Rp1(c))) & (Qp1(c) implies  not Sp1(c))) & (Rp1(c) implies  not Sp1(c))" and
   A2: " for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies ((Pp1(c) or Qp1(c)) or Rp1(c)) or Sp1(c)"
  shows " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c))) & (Sp1(c) implies f .FUNCT-1K1 c =HIDDENR1 If1(c)))"
  proof-
    obtain D1 where
      [ty]:"D1 be setHIDDENM2" and 
      A3: " for x be objectHIDDENM1 holds x inHIDDENR3 D1 iff x inHIDDENR3 Cf0 & Pp1(x)"
      using xboole_0_sch_1 sorry
    obtain D4 where
      [ty]:"D4 be setHIDDENM2" and 
      A4: " for x be objectHIDDENM1 holds x inHIDDENR3 D4 iff x inHIDDENR3 Cf0 & Sp1(x)"
      using xboole_0_sch_1 sorry
    obtain f1 where
      [ty]:"f1 be FunctionFUNCT-1M1" and 
      A5: "domRELAT-1K1 f1 =XBOOLE-0R4 D1"and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 D1 implies f1 .FUNCT-1K1 x =HIDDENR1 Ff1(x)"
      using funct_1_sch_3 sorry
    obtain D2 where
      [ty]:"D2 be setHIDDENM2" and 
      A7: " for x be objectHIDDENM1 holds x inHIDDENR3 D2 iff x inHIDDENR3 Cf0 & Qp1(x)"
      using xboole_0_sch_1 sorry
    obtain f2 where
      [ty]:"f2 be FunctionFUNCT-1M1" and 
      A8: "domRELAT-1K1 f2 =XBOOLE-0R4 D2"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 D2 implies f2 .FUNCT-1K1 x =HIDDENR1 Gf1(x)"
      using funct_1_sch_3 sorry
    obtain D3 where
      [ty]:"D3 be setHIDDENM2" and 
      A10: " for x be objectHIDDENM1 holds x inHIDDENR3 D3 iff x inHIDDENR3 Cf0 & Rp1(x)"
      using xboole_0_sch_1 sorry
    obtain f4 where
      [ty]:"f4 be FunctionFUNCT-1M1" and 
      A11: "domRELAT-1K1 f4 =XBOOLE-0R4 D4"and A12: " for x be objectHIDDENM1 holds x inHIDDENR3 D4 implies f4 .FUNCT-1K1 x =HIDDENR1 If1(x)"
      using funct_1_sch_3 sorry
    obtain f3 where
      [ty]:"f3 be FunctionFUNCT-1M1" and 
      A13: "domRELAT-1K1 f3 =XBOOLE-0R4 D3"and A14: " for x be objectHIDDENM1 holds x inHIDDENR3 D3 implies f3 .FUNCT-1K1 x =HIDDENR1 Hf1(x)"
      using funct_1_sch_3 sorry
    show " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (((Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & (Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c))) & (Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c))) & (Sp1(c) implies f .FUNCT-1K1 c =HIDDENR1 If1(c)))"
    proof-
      have " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & ((Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)) & ((Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)) & (Sp1(c) implies f .FUNCT-1K1 c =HIDDENR1 If1(c)))))"
      proof-
        obtain f where 
          [ty]:"f be setHIDDENM2" and fDef:"f = ((f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3)+*FUNCT-4K1 f4"
           sorry
        show " ex f be setHIDDENM2 st domRELAT-1K1 f =XBOOLE-0R4 Cf0 & ( for c be setHIDDENM2 holds c inTARSKIR2 Cf0 implies (Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)) & ((Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)) & ((Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)) & (Sp1(c) implies f .FUNCT-1K1 c =HIDDENR1 If1(c)))))"
        proof(rule bexI[of _ "f"],rule conjMI,rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule impI)
          have A15: "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 ((f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3) \\/XBOOLE-0K2 domRELAT-1K1 f4"
            using funct_4_def_1 sorry
          also have "... = (domRELAT-1K1 (f1 +*FUNCT-4K1 f2) \\/XBOOLE-0K2 domRELAT-1K1 f3)\\/XBOOLE-0K2 domRELAT-1K1 f4"
            using funct_4_def_1 sorry
          also have "... = ((domRELAT-1K1 f1 \\/XBOOLE-0K2 domRELAT-1K1 f2)\\/XBOOLE-0K2 domRELAT-1K1 f3)\\/XBOOLE-0K2 domRELAT-1K1 f4"
            using funct_4_def_1 sorry
          finally have "domRELAT-1K1 f =HIDDENR1 ((domRELAT-1K1 f1 \\/XBOOLE-0K2 domRELAT-1K1 f2)\\/XBOOLE-0K2 domRELAT-1K1 f3)\\/XBOOLE-0K2 domRELAT-1K1 f4"
             sorry
          show "domRELAT-1K1 f =XBOOLE-0R4 Cf0"
          proof-
            have A16: "D4 c=TARSKIR1 Cf0"
              using A4 sorry
            have A17: "D3 c=TARSKIR1 Cf0"
              using A10 sorry
            have A18: "D2 c=TARSKIR1 Cf0"
              using A7 sorry
            have "D1 c=TARSKIR1 Cf0"
              using A3 sorry
            then have "D1 \\/XBOOLE-0K2 D2 c=TARSKIR1 Cf0"
              using A18 xboole_1_th_8 sorry
            then have Cut301: "(D1 \\/XBOOLE-0K2 D2)\\/XBOOLE-0K2 D3 c=TARSKIR1 Cf0"
              using A17 xboole_1_th_8 sorry
            have "domRELAT-1K1 f c=TARSKIR1 Cf0 & Cf0 c=TARSKIR1 domRELAT-1K1 f"
            proof(rule conjMI)
              show "domRELAT-1K1 f c=TARSKIR1 Cf0"
                using A5 A8 A13 A11 A15 A16 xboole_1_th_8 Cut301 sorry
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Cf0 implies x inHIDDENR3 domRELAT-1K1 f"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A19: "x inHIDDENR3 Cf0"
                then have "((Pp1(x) or Qp1(x)) or Rp1(x)) or Sp1(x)"
                  using A2 sorry
                then have "((x inHIDDENR3 D1 or x inHIDDENR3 D2) or x inHIDDENR3 D3) or x inHIDDENR3 D4"
                  using A3 A7 A10 A4 A19 sorry
                then have "(x inHIDDENR3 D1 \\/XBOOLE-0K2 D2 or x inHIDDENR3 D3) or x inHIDDENR3 D4"
                  using xboole_0_def_3 sorry
                then have "x inHIDDENR3 (D1 \\/XBOOLE-0K2 D2)\\/XBOOLE-0K2 D3 or x inHIDDENR3 D4"
                  using xboole_0_def_3 sorry
                thus "x inHIDDENR3 domRELAT-1K1 f"
                  using A5 A8 A13 A11 A15 xboole_0_def_3 sorry
              qed "sorry"
              thus "Cf0 c=TARSKIR1 domRELAT-1K1 f"
                using tarski_def_3 sorry
            qed
            thus "domRELAT-1K1 f =XBOOLE-0R4 Cf0"
              using xboole_0_def_10 sorry
          qed
          fix c assume [ty]: "c be setHIDDENM2"
          assume A20: "c inTARSKIR2 Cf0"
          show "Pp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
          proof(rule impI)
            assume A21: "Pp1(c)"
            have " not Rp1(c)"
              using A1 A20 A21 sorry
            then have A22: " not c inTARSKIR2 D3"
              using A10 sorry
            have " not Qp1(c)"
              using A1 A20 A21 sorry
            then have A23: " not c inTARSKIR2 D2"
              using A7 sorry
            have " not Sp1(c)"
              using A1 A20 A21 sorry
            then have " not c inTARSKIR2 D4"
              using A4 sorry
            then have "f .FUNCT-1K1 c =HIDDENR1 ((f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3).FUNCT-1K1 c"
              using A11 funct_4_th_11 sorry
            also have "... = (f1 +*FUNCT-4K1 f2).FUNCT-1K1 c"
              using A13 A22 funct_4_th_11 sorry
            also have "... = f1 .FUNCT-1K1 c"
              using A8 A23 funct_4_th_11 sorry
            also have "... = Ff1(c)"
              using A6 A21 A3 A20 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 Ff1(c)"
               sorry
          qed
          show "Qp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Gf1(c)"
          proof(rule impI)
            assume A24: "Qp1(c)"
            have " not Rp1(c)"
              using A1 A20 A24 sorry
            then have A25: " not c inTARSKIR2 D3"
              using A10 sorry
            have " not Sp1(c)"
              using A1 A20 A24 sorry
            then have " not c inTARSKIR2 D4"
              using A4 sorry
            then have "f .FUNCT-1K1 c =HIDDENR1 ((f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3).FUNCT-1K1 c"
              using A11 funct_4_th_11 sorry
            also have "... = (f1 +*FUNCT-4K1 f2).FUNCT-1K1 c"
              using A13 A25 funct_4_th_11 sorry
            also have "... = f2 .FUNCT-1K1 c"
              using A8 A24 A7 A20 funct_4_th_13 sorry
            also have "... = Gf1(c)"
              using A9 A24 A7 A20 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 Gf1(c)"
               sorry
          qed
          show "Rp1(c) implies f .FUNCT-1K1 c =HIDDENR1 Hf1(c)"
          proof(rule impI)
            assume A26: "Rp1(c)"
            have " not Sp1(c)"
              using A1 A20 A26 sorry
            then have " not c inTARSKIR2 D4"
              using A4 sorry
            then have "f .FUNCT-1K1 c =HIDDENR1 ((f1 +*FUNCT-4K1 f2)+*FUNCT-4K1 f3).FUNCT-1K1 c"
              using A11 funct_4_th_11 sorry
            also have "... = f3 .FUNCT-1K1 c"
              using A13 A26 A10 A20 funct_4_th_13 sorry
            also have "... = Hf1(c)"
              using A14 A26 A10 A20 sorry
            finally show "f .FUNCT-1K1 c =HIDDENR1 Hf1(c)"
               sorry
          qed
          assume A27: "Sp1(c)"
          then have "f .FUNCT-1K1 c =HIDDENR1 f4 .FUNCT-1K1 c"
            using A11 A4 A20 funct_4_th_13 sorry
          also have "... = If1(c)"
            using A12 A27 A4 A20 sorry
          finally show "f .FUNCT-1K1 c =HIDDENR1 If1(c)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  qed

theorem recdef_2_sch_3:
  fixes Af0 Bf0 A0f0 B0f0 Pp5 
  assumes
[ty]: "Af0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Bf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "A0f0 be ElementSUBSET-1M1-of Af0" and
  [ty]: "B0f0 be ElementSUBSET-1M1-of Bf0" and
   A1: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of Af0 holds  for y be ElementSUBSET-1M1-of Bf0 holds  ex x1 be ElementSUBSET-1M1-of Af0 st  ex y1 be ElementSUBSET-1M1-of Bf0 st Pp5(n,x,y,x1,y1)"
  shows " ex f be sequenceNAT-1M2-of Af0 st  ex g be sequenceNAT-1M2-of Bf0 st (f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0) & ( for n be NatNAT-1M1 holds Pp5(n,f .FUNCT-1K1 n,g .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),g .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar4 be sequenceNAT-1M2-of Af0 st  ex tVar5 be sequenceNAT-1M2-of Bf0 st (tVar4 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0) & ( for i be NatNAT-1M1 holds Pp5(i,tVar4 .FUNCT-1K1 i,tVar5 .FUNCT-1K1 i,tVar4 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M),tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)))"
    proof-
      let ?P1 = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Pp5(Lamb1,Lamb2 `1XTUPLE-0K1,Lamb2 `2XTUPLE-0K2,Lamb3 `1XTUPLE-0K1,Lamb3 `2XTUPLE-0K2)"
      have A2: " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :] holds  ex y be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :] st ?P1(n,x,y)"
      proof-
        have " for n be NatNAT-1M1 holds  for x be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :] holds  ex tVar3 be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :] st Pp5(n,x `1XTUPLE-0K1,x `2XTUPLE-0K2,tVar3 `1XTUPLE-0K1,tVar3 `2XTUPLE-0K2)"
        proof(rule ballI,rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          fix x assume [ty]: "x be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :]"
          obtain ai bi where
            [ty]:"ai be ElementSUBSET-1M1-of Af0" "bi be ElementSUBSET-1M1-of Bf0" and 
            A3: "Pp5(n,x `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub>,x `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub>,ai,bi)"
            using A1 sorry
          show " ex tVar3 be ElementSUBSET-1M1-of [:ZFMISC-1K2 Af0,Bf0 :] st Pp5(n,x `1XTUPLE-0K1,x `2XTUPLE-0K2,tVar3 `1XTUPLE-0K1,tVar3 `2XTUPLE-0K2)"
          proof(rule bexI[of _ "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> ai,bi ]"])
            show "Pp5(n,x `1XTUPLE-0K1,x `2XTUPLE-0K2,[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> ai,bi ] `1XTUPLE-0K1,[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> ai,bi ] `2XTUPLE-0K2)"
              using A3 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be sequenceNAT-1M2-of [:ZFMISC-1K2 Af0,Bf0 :]" and 
        A4: "f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,[:ZFMISC-1K2 Af0,Bf0 :])\<^esub> (0NUMBERSK6) =XBOOLE-0R4 [DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> A0f0,B0f0 ]"and A5: " for e be NatNAT-1M1 holds ?P1(e,f .FUNCT-1K1 e,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,[:ZFMISC-1K2 Af0,Bf0 :])\<^esub> (e +NAT-1K1 \<one>\<^sub>M))"
        using recdef_1_sch_2 A2 sorry
      show " ex tVar4 be sequenceNAT-1M2-of Af0 st  ex tVar5 be sequenceNAT-1M2-of Bf0 st (tVar4 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0) & ( for i be NatNAT-1M1 holds Pp5(i,tVar4 .FUNCT-1K1 i,tVar5 .FUNCT-1K1 i,tVar4 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M),tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)))"
      proof(rule bexI[of _ "pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f"])
        show " ex tVar5 be sequenceNAT-1M2-of Bf0 st (pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0) & ( for i be NatNAT-1M1 holds Pp5(i,pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-1K1 i,tVar5 .FUNCT-1K1 i,pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M),tVar5 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)))"
        proof(rule bexI[of _ "pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f"],rule conjMI,rule ballI)
          have "[DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> A0f0,B0f0 ] `1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 A0f0 & [DOMAIN-1K1\<^bsub>(Af0,Bf0)\<^esub> A0f0,B0f0 ] `2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 B0f0"
             sorry
          thus "pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 A0f0 & pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 B0f0"
            using A4 funct_2_def_5 funct_2_def_6 sorry
          fix i assume [ty]: "i be NatNAT-1M1"
          have A6: "(f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,[:ZFMISC-1K2 Af0,Bf0 :])\<^esub> (i +NAT-1K1 \<one>\<^sub>M))`1DOMAIN-1K2\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) & (f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,[:ZFMISC-1K2 Af0,Bf0 :])\<^esub> (i +NAT-1K1 \<one>\<^sub>M))`2DOMAIN-1K3\<^bsub>(Af0,Bf0)\<^esub> =XBOOLE-0R4 pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)"
            using funct_2_def_5 funct_2_def_6 sorry
          have "i inTARSKIR2 NATNUMBERSK1"
            using ordinal1_def_12 sorry
          then have "(f .FUNCT-1K1 i)`1XTUPLE-0K1 =HIDDENR1 pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-1K1 i & (f .FUNCT-1K1 i)`2XTUPLE-0K2 =HIDDENR1 pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-1K1 i"
            using funct_2_def_5 funct_2_def_6 sorry
          thus "Pp5(i,pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-1K1 i,pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-1K1 i,pr1FUNCT-2K4\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Af0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M),pr2FUNCT-2K5\<^bsub>(NATNUMBERSK1,Af0,Bf0)\<^esub> f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Bf0)\<^esub> (i +NAT-1K1 \<one>\<^sub>M))"
            using A5 A6 sorry
        qed "sorry"
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_4:
  fixes Af0 Bf0 Ff3 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st ((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 NATNUMBERSK1 & (tVar6 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & (tVar6 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0 & ( for n be NatNAT-1M1 holds tVar6 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,tVar6 .FUNCT-1K1 n,tVar6 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))))"
    proof-
      let ?C = "\<lambda>Lamb1. Lamb1 =XBOOLE-0R4 0NUMBERSK6"
      let ?G = "\<lambda>Lamb1. \<lambda>Lamb2. [XTUPLE-0K3 Lamb2 `2-3XTUPLE-0K5,Lamb2 `3-3XTUPLE-0K6,Ff3(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2 `2-3XTUPLE-0K5,Lamb2 `3-3XTUPLE-0K6) ]"
      let ?r03 = "Ff3(0NUMBERSK6,Af0,Bf0)"
      let ?r13 = "Ff3(\<one>\<^sub>M,Bf0,?r03)"
      let ?H = "\<lambda>Lamb1. \<lambda>Lamb2. ?G(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2)"
      obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 h =XBOOLE-0R4 NATNUMBERSK1"and A1: "h .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 [XTUPLE-0K3 Bf0,?r03,?r13 ]"and A2: " for n be NatNAT-1M1 holds h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?H(n,h .FUNCT-1K1 n)"
        using nat_1_sch_11 sorry
      let ?Y = "\<lambda>Lamb1. h .FUNCT-1K1 (Lamb1 -'NAT-DK9 \<one>\<^sub>M)"
      let ?X = "\<lambda>Lamb1. [XTUPLE-0K3 Af0,Bf0,?r03 ]"
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1"and A3: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds (?C(x) implies g .FUNCT-1K1 x =HIDDENR1 ?X(x)) & ( not ?C(x) implies g .FUNCT-1K1 x =XBOOLE-0R4 ?Y(x))"
        using partfun1_sch_4 sorry
      let ?M = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1 `1-3XTUPLE-0K4"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A4: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A5: " for x be objectHIDDENM1 holds x inHIDDENR3 NATNUMBERSK1 implies f .FUNCT-1K1 x =HIDDENR1 ?M(x)"
        using funct_1_sch_3 sorry
      let ?P = "\<lambda>Lamb1. ((((f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5 & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 Lamb1 `2-3XTUPLE-0K5) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 Lamb1 `3-3XTUPLE-0K6) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) & f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(Lamb1,f .FUNCT-1K1 Lamb1,f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M))"
      have A6: "g .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 [XTUPLE-0K3 Af0,Bf0,?r03 ]"
        using A3 sorry
      have A7: " for n be NatNAT-1M1 holds g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 ?G(n +NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
      proof-
        have " for n be NatNAT-1M1 holds g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 [XTUPLE-0K3 g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ]"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have A8: "(n +NAT-1K1 \<two>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 n +XCMPLX-0K2 (\<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
             sorry
          have A9: "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?Y(n +NAT-1K1 \<one>\<^sub>M)"
            using A3 sorry
          also have "... = h .FUNCT-1K1 n"
            using nat_d_th_34 sorry
          finally have "g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 n"
             sorry
          have "g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 ((n +NAT-1K1 \<two>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
            using A3 sorry
          also have "... = h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A8 xreal_0_def_2 sorry
          also have "... = [XTUPLE-0K3 g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ]"
            using A2 A9 sorry
          finally show "g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 [XTUPLE-0K3 g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3((n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ]"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A10: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 ?G(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) `2-3RECDEF-2K2"
         sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
         sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
         sorry
      show " ex tVar6 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar6 =XBOOLE-0R4 NATNUMBERSK1 & (tVar6 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & (tVar6 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0 & ( for n be NatNAT-1M1 holds tVar6 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,tVar6 .FUNCT-1K1 n,tVar6 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)))))"
      proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
          using A4 sorry
        have A11: "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6) `1-3XTUPLE-0K4"
          using A5 sorry
        also have "... = Af0"
          using A6 sorry
        finally show "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"
           sorry
        have A12: "g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 ?Y(\<one>\<^sub>M)"
          using A3 sorry
        also have "... = [XTUPLE-0K3 Bf0,?r03,?r13 ]"
          using A1 xreal_1_th_232 sorry
        finally have "g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 [XTUPLE-0K3 Bf0,?r03,?r13 ]"
           sorry
        then have A13: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 Bf0"
           sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6) `2-3XTUPLE-0K5"
          using A6 sorry
        finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6) `2-3XTUPLE-0K5"
           sorry
        have A14: " for x be NatNAT-1M1 holds ?P(x) implies ?P(x +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for x be NatNAT-1M1 holds ?P(x) implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6 & f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))))))"
          proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
            fix x assume [ty]: "x be NatNAT-1M1"
            assume A15: "?P(x)"
            then have A16: "f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 x `2-3XTUPLE-0K5"
              using A5 sorry
            have A17: "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4"
              using A5 sorry
            also have "... = [XTUPLE-0K3 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3(((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ] `1-3RECDEF-2K1"
              using A7 sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
               sorry
            finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
               sorry
            show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
              using A15 sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 [XTUPLE-0K3 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3(((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ] `1-3RECDEF-2K1"
              using A7 sorry
            also have "... = g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
              using A15 sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
               sorry
            thus "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
              using A15 sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 [XTUPLE-0K3 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3(((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ] `2-3RECDEF-2K2"
              using A7 sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
               sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-3XTUPLE-0K5 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
               sorry
            show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
            proof-
              have cases: "x =XBOOLE-0R4 0NUMBERSK6 or x <>HIDDENR2 0NUMBERSK6"
                 sorry
              have case1: "x =XBOOLE-0R4 0NUMBERSK6 implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI)
                assume A18: "x =XBOOLE-0R4 0NUMBERSK6"
                then have "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4"
                  using A5 sorry
                also have "... = [XTUPLE-0K3 g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ] `1-3RECDEF-2K1"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6"
                  using A15 A18 sorry
                also have "... = Ff3(\<one>\<^sub>M,Bf0,Ff3(0NUMBERSK6,Af0,Bf0))"
                  using A12 sorry
                also have "... = Ff3(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,Bf0,g .FUNCT-1K1 (0NUMBERSK6) `3-3XTUPLE-0K6)"
                  using A6 sorry
                also have "... = Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
                  using A6 A15 A16 A18 sorry
                finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
                   sorry
              qed
              have case2: "x <>HIDDENR2 0NUMBERSK6 implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI)
                assume "x <>HIDDENR2 0NUMBERSK6"
                then have "0NUMBERSK6 <XXREAL-0R3 x"
                   sorry
                then have A19: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x"
                  using nat_1_th_13 sorry
                then have A20: "(x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 x"
                  using xreal_1_th_235 sorry
                have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 x -XCMPLX-0K6 \<one>\<^sub>M"
                  using A19 xreal_1_th_13 sorry
                then have A21: "x -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 x -'NAT-DK9 \<one>\<^sub>M"
                  using xreal_0_def_2 sorry
                have "x +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (x -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M"
                   sorry
                then have "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 [XTUPLE-0K3 g .FUNCT-1K1 ((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6,Ff3(((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5,g .FUNCT-1K1 ((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-3XTUPLE-0K6) ] `3-3RECDEF-2K3"
                  using A7 A15 A17 A21 sorry
                also have "... = Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
                  using A15 A16 A20 sorry
                finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A22: "f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4"
          using A5 sorry
        also have "... = ?G(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) `1-3RECDEF-2K1"
          using A7 sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
           sorry
        finally have "f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
           sorry
        have A23: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 g .FUNCT-1K1 \<one>\<^sub>M `1-3XTUPLE-0K4"
          using A5 sorry
        also have "... = Bf0"
          using A12 sorry
        finally show "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0"
           sorry
        have A24: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 ?G(0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) `1-3RECDEF-2K1"
          using A7 sorry
        also have "... = g .FUNCT-1K1 \<one>\<^sub>M `2-3XTUPLE-0K5"
           sorry
        also have "... = ?r03"
          using A12 sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6) `3-3XTUPLE-0K6"
          using A6 sorry
        finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6) `3-3XTUPLE-0K6"
           sorry
        then have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 ?r03"
          using A6 sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
          using A12 sorry
        finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-3XTUPLE-0K4 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-3XTUPLE-0K5"
           sorry
        then have A25: "?P(0NUMBERSK6)"
          using A12 A11 A23 A22 A13 A24 A10 sorry
        have " for x be NatNAT-1M1 holds ?P(x)"
          using nat_1_sch_2 A25 A14 sorry
        thus " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_5:
  fixes Xf0 Af0 Bf0 Ff3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be ElementSUBSET-1M1-of Xf0"
  shows " ex f be sequenceNAT-1M2-of Xf0 st (f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))"
  proof-
    have " not ( for f be sequenceNAT-1M2-of Xf0 holds  not ((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A2: "f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0"and A3: " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
        using recdef_2_sch_4 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 Xf0"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain n where
            [ty]:"n be objectHIDDENM1" and 
            A4: "n inHIDDENR3 domRELAT-1K1 f"and A5: "f .FUNCT-1K1 n =HIDDENR1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"n be NatNAT-1M1"
            using A1 A4 sorry
          show "y inHIDDENR3 Xf0"
          proof-
            have cases: "n <=XXREAL-0R1 \<one>\<^sub>M or n >XXREAL-0R4 \<one>\<^sub>M"
               sorry
            have case1: "n <=XXREAL-0R1 \<one>\<^sub>M implies y inHIDDENR3 Xf0"
            proof(rule impI)
              assume "n <=XXREAL-0R1 \<one>\<^sub>M"
              then have "n =XBOOLE-0R4 0NUMBERSK6 or n =XBOOLE-0R4 \<one>\<^sub>M"
                using nat_1_th_25 sorry
              thus "y inHIDDENR3 Xf0"
                using A2 A5 sorry
            qed
            have case2: "n >XXREAL-0R4 \<one>\<^sub>M implies y inHIDDENR3 Xf0"
            proof(rule impI)
              assume "n >XXREAL-0R4 \<one>\<^sub>M"
              then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              then have "n -XCMPLX-0K6 \<two>\<^sub>M inTARSKIR2 NATNUMBERSK1"
                using int_1_th_5 sorry
              then have "f .FUNCT-1K1 ((n -XCMPLX-0K6 \<two>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n -XCMPLX-0K6 \<two>\<^sub>M,f .FUNCT-1K1 (n -XCMPLX-0K6 \<two>\<^sub>M),f .FUNCT-1K1 ((n -XCMPLX-0K6 \<two>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M))"
                using A3 sorry
              thus "y inHIDDENR3 Xf0"
                using A5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
          using tarski_def_3 sorry
      qed
      then have "f be sequenceNAT-1M2-of Xf0"
        using A1 funct_2_def_1 relset_1_th_4 sorry
      thus " not ( for f be sequenceNAT-1M2-of Xf0 holds  not ((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)))))"
        using A2 A3 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_6:
  fixes Af0 Bf0 Ff0 Gf0 Ff3 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?Q = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      assume "Ff0 <>HIDDENR2 Gf0"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 NATNUMBERSK1 & Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A1 A4 funct_1_th_2 sorry
      then have A7: " ex k be NatNAT-1M1 st ?Q(k)"
         sorry
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A8: "?Q(m)"and A9: " for n be NatNAT-1M1 holds ?Q(n) implies m <=XXREAL-0R1 n"
        using nat_1_sch_5 A7 sorry
      have "m <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 \<one>\<^sub>M implies  False "
      proof(rule impI)
        let ?k = "m -'NAT-DK9 \<two>\<^sub>M"
        have A10: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(?k,Ff0 .FUNCT-1K1 ?k,Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M)) & Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 Ff3(?k,Gf0 .FUNCT-1K1 ?k,Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M))"
          using A3 A6 sorry
        assume "m <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 \<one>\<^sub>M"
        then have "\<one>\<^sub>M <XXREAL-0R3 m"
          using nat_1_th_25 sorry
        then have "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using nat_1_th_13 sorry
        then have A11: "m =XBOOLE-0R4 ?k +NAT-1K1 \<two>\<^sub>M"
          using xreal_1_th_235 sorry
        then have A12: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M)"
          using A9 xreal_1_th_6 sorry
        have "?k +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 m"
          using A11 xreal_1_th_6 sorry
        thus " False "
          using A8 A9 A11 A12 A10 sorry
      qed
      thus " False "
        using A2 A5 A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_7:
  fixes Xf0 Af0 Bf0 Ff0 Gf0 Ff3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> Ff3(x1,x2,x3) be ElementSUBSET-1M1-of Xf0" and
   A1: "Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))" and
   A3: "Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Ff3(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
  proof-
    have A5: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    have A6: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    show "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
      using recdef_2_sch_6 A6 A1 A2 A5 A3 A4 sorry
  qed

theorem recdef_2_sch_8:
  fixes Af0 Bf0 Cf0 Ff4 
  assumes
[ty]: "Af0 be setHIDDENM2" and
  [ty]: "Bf0 be setHIDDENM2" and
  [ty]: "Cf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be objectHIDDENM1"
  shows " ex f be FunctionFUNCT-1M1 st (((domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1 & f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0) & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M)))"
  proof-
    have " ex tVar7 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar7 =XBOOLE-0R4 NATNUMBERSK1 & (tVar7 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & (tVar7 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0 & (tVar7 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0 & ( for n be NatNAT-1M1 holds tVar7 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,tVar7 .FUNCT-1K1 n,tVar7 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),tVar7 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))))))"
    proof-
      let ?C3 = "\<lambda>Lamb1. InSUBSET-1K10(Lamb1,NATNUMBERSK1) >XXREAL-0R4 \<one>\<^sub>M"
      let ?C2 = "\<lambda>Lamb1. Lamb1 =HIDDENR1 \<one>\<^sub>M"
      let ?C1 = "\<lambda>Lamb1. Lamb1 =HIDDENR1 0NUMBERSK6"
      let ?G = "\<lambda>Lamb1. \<lambda>Lamb2. [XTUPLE-0K7 Lamb2 `2-4XTUPLE-0K9,Lamb2 `3-4XTUPLE-0K10,Lamb2 `4-4XTUPLE-0K11,Ff4(Lamb1 +NAT-1K1 \<one>\<^sub>M,Lamb2 `2-4XTUPLE-0K9,Lamb2 `3-4XTUPLE-0K10,Lamb2 `4-4XTUPLE-0K11) ]"
      let ?r04 = "Ff4(0NUMBERSK6,Af0,Bf0,Cf0)"
      let ?r14 = "Ff4(\<one>\<^sub>M,Bf0,Cf0,?r04)"
      let ?r24 = "Ff4(\<two>\<^sub>M,Cf0,?r04,?r14)"
      let ?H = "\<lambda>Lamb1. \<lambda>Lamb2. ?G(Lamb1 +NAT-1K1 \<two>\<^sub>M,Lamb2)"
      obtain h where
        [ty]:"h be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 h =XBOOLE-0R4 NATNUMBERSK1"and A1: "h .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 [XTUPLE-0K7 Cf0,?r04,?r14,?r24 ]"and A2: " for n be NatNAT-1M1 holds h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?H(n,h .FUNCT-1K1 n)"
        using nat_1_sch_11 sorry
      let ?X3 = "\<lambda>Lamb1. h .FUNCT-1K1 (InSUBSET-1K10(Lamb1,NATNUMBERSK1) -'NAT-DK9 \<two>\<^sub>M)"
      let ?X2 = "\<lambda>Lamb1. [XTUPLE-0K7 Bf0,Cf0,?r04,?r14 ]"
      let ?X1 = "\<lambda>Lamb1. [XTUPLE-0K7 Af0,Bf0,Cf0,?r04 ]"
      have A3: " for c be setHIDDENM2 holds c inTARSKIR2 NATNUMBERSK1 implies (?C1(c) or ?C2(c)) or ?C3(c)"
      proof-
        have " for c be setHIDDENM2 holds c inTARSKIR2 NATNUMBERSK1 implies  not (( not c =HIDDENR1 0NUMBERSK6 &  not c =HIDDENR1 \<one>\<^sub>M) &  not InSUBSET-1K10(c,NATNUMBERSK1) >XXREAL-0R4 \<one>\<^sub>M)"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be setHIDDENM2"
          assume "c inTARSKIR2 NATNUMBERSK1"
          then have "InSUBSET-1K10(c,NATNUMBERSK1) =XBOOLE-0R4 c"
            using subset_1_def_8 sorry
          thus " not (( not c =HIDDENR1 0NUMBERSK6 &  not c =HIDDENR1 \<one>\<^sub>M) &  not InSUBSET-1K10(c,NATNUMBERSK1) >XXREAL-0R4 \<one>\<^sub>M)"
            using nat_1_th_25 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A4: " for c be setHIDDENM2 holds c inTARSKIR2 NATNUMBERSK1 implies ((?C1(c) implies  not ?C2(c)) & (?C1(c) implies  not ?C3(c))) & (?C2(c) implies  not ?C3(c))"
         sorry
      obtain g where
        [ty]:"g be FunctionFUNCT-1M1" and 
        "domRELAT-1K1 g =XBOOLE-0R4 NATNUMBERSK1"and A5: " for x be setHIDDENM2 holds x inTARSKIR2 NATNUMBERSK1 implies ((?C1(x) implies g .FUNCT-1K1 x =HIDDENR1 ?X1(x)) & (?C2(x) implies g .FUNCT-1K1 x =HIDDENR1 ?X2(x))) & (?C3(x) implies g .FUNCT-1K1 x =XBOOLE-0R4 ?X3(x))"
        using recdef_2_sch_1 A4 A3 sorry
      have A6: "g .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 ?X3(\<two>\<^sub>M)"
        using A5 sorry
      also have "... = [XTUPLE-0K7 Cf0,?r04,?r14,?r24 ]"
        using A1 xreal_1_th_232 sorry
      finally have "g .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 [XTUPLE-0K7 Cf0,?r04,?r14,?r24 ]"
         sorry
      have A7: " for n be NatNAT-1M1 holds g .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 ?G(n +NAT-1K1 \<two>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))"
      proof-
        have " for n be NatNAT-1M1 holds g .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((n +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ]"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<two>\<^sub>M"
            using xreal_1_th_8 sorry
          then have A8: "g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 ?X3(n +NAT-1K1 \<two>\<^sub>M)"
            using A5 sorry
          also have "... = h .FUNCT-1K1 n"
            using nat_d_th_34 sorry
          finally have "g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 n"
             sorry
          have A9: "(n +NAT-1K1 \<three>\<^sub>M)-XCMPLX-0K6 \<two>\<^sub>M =XBOOLE-0R4 n +XCMPLX-0K2 (\<three>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M) & 0NUMBERSK6 <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
             sorry
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<three>\<^sub>M"
            using xreal_1_th_8 sorry
          then have "g .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 h .FUNCT-1K1 (InSUBSET-1K10(n +NAT-1K1 \<three>\<^sub>M,NATNUMBERSK1) -'NAT-DK9 \<two>\<^sub>M)"
            using A5 sorry
          also have "... = h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A9 xreal_0_def_2 sorry
          also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((n +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ]"
            using A2 A8 sorry
          finally show "g .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((n +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ]"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A10: "g .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 [XTUPLE-0K7 Bf0,Cf0,?r04,?r14 ]"
        using A5 sorry
      then have A11: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 ?r04"
         sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
        using A6 sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
         sorry
      have A12: "g .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 [XTUPLE-0K7 Af0,Bf0,Cf0,?r04 ]"
        using A5 sorry
      then have A13: "g .FUNCT-1K1 (0NUMBERSK6) `3-4XTUPLE-0K10 =HIDDENR1 Cf0"
         sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9"
        using A10 sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9"
         sorry
      have A14: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 ?r14"
        using A10 sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10"
        using A6 sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10"
         sorry
      have A15: "g .FUNCT-1K1 (0NUMBERSK6) `4-4XTUPLE-0K11 =HIDDENR1 ?r04"
        using A12 sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10"
        using A10 sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10"
         sorry
      have A16: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `1-4XTUPLE-0K8 =HIDDENR1 Bf0"
        using A10 sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6) `2-4XTUPLE-0K9"
        using A12 sorry
      finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `1-4XTUPLE-0K8 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6) `2-4XTUPLE-0K9"
         sorry
      let ?M = "\<lambda>Lamb1. g .FUNCT-1K1 Lamb1 `1-4XTUPLE-0K8"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A17: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A18: " for x be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 x =HIDDENR1 ?M(x)"
        using funct_1_sch_4 sorry
      have A19: "f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
        using A18 sorry
      also have "... = ?G(0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)) `1-4RECDEF-2K4"
        using A7 sorry
      also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
         sorry
      finally have "f .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
         sorry
      show " ex tVar7 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar7 =XBOOLE-0R4 NATNUMBERSK1 & (tVar7 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & (tVar7 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0 & (tVar7 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0 & ( for n be NatNAT-1M1 holds tVar7 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,tVar7 .FUNCT-1K1 n,tVar7 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),tVar7 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))))))"
      proof(rule bexI[of _ "f"],rule conjMI,rule conjMI,rule conjMI,rule conjMI)
        show "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"
          using A17 sorry
        let ?P = "\<lambda>Lamb1. (((((((f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 & g .FUNCT-1K1 Lamb1 `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `1-4XTUPLE-0K8) & g .FUNCT-1K1 Lamb1 `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9) & g .FUNCT-1K1 Lamb1 `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10) & g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 (Lamb1 +NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8) & f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(Lamb1,f .FUNCT-1K1 Lamb1,f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 (Lamb1 +NAT-1K1 \<two>\<^sub>M))"
        have A20: "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 ?G(0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)) `1-4RECDEF-2K4"
           sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
          using A7 sorry
        finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
           sorry
        have A21: "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6) `1-4XTUPLE-0K8"
          using A18 sorry
        also have "... = Af0"
          using A12 sorry
        finally show "f .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0"
           sorry
        have A22: "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 g .FUNCT-1K1 \<one>\<^sub>M `1-4XTUPLE-0K8"
          using A18 sorry
        also have "... = Bf0"
          using A10 sorry
        finally show "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0"
           sorry
        have A23: "f .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 g .FUNCT-1K1 \<two>\<^sub>M `1-4XTUPLE-0K8"
          using A18 sorry
        also have "... = Cf0"
          using A6 sorry
        finally show "f .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0"
           sorry
        have A24: " for x be NatNAT-1M1 holds ?P(x) implies ?P(x +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for x be NatNAT-1M1 holds ?P(x) implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `1-4XTUPLE-0K8 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 & (g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 & (g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10 & (g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8 & f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)))))))))"
          proof(rule ballI,rule impI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI,rule conjMI)
            fix x assume [ty]: "x be NatNAT-1M1"
            have A25: "(x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M)"
               sorry
            assume A26: "?P(x)"
            then have A27: "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 x `3-4XTUPLE-0K10"
              using A18 sorry
            have A28: "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
              using A18 sorry
            also have "... = [XTUPLE-0K7 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4(((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `1-4RECDEF-2K4"
              using A7 sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
               sorry
            finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
               sorry
            show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `1-4XTUPLE-0K8 =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9"
              using A26 sorry
            show "g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9"
              using A26 sorry
            show "g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10"
              using A26 sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((x +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `1-4RECDEF-2K4"
               sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8"
              using A7 A25 sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8"
               sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((x +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `2-4RECDEF-2K5"
               sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
              using A7 A25 sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9"
               sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((x +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `3-4RECDEF-2K6"
               sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10"
              using A7 A25 sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10"
               sorry
            have "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 [XTUPLE-0K7 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4(((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `1-4RECDEF-2K4"
               sorry
            also have "... = g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
              using A7 sorry
            finally show "g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
               sorry
            show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
            proof-
              have cases: "(x <=XXREAL-0R1 \<one>\<^sub>M & x <>HIDDENR2 \<one>\<^sub>M or x =XBOOLE-0R4 \<one>\<^sub>M) or \<one>\<^sub>M <XXREAL-0R3 x"
                 sorry
              have case1: "x <=XXREAL-0R1 \<one>\<^sub>M & x <>HIDDENR2 \<one>\<^sub>M implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
              proof(rule impI)
                assume "x <=XXREAL-0R1 \<one>\<^sub>M & x <>HIDDENR2 \<one>\<^sub>M"
                then have A29: "x =XBOOLE-0R4 0NUMBERSK6"
                  using nat_1_th_25 sorry
                then have "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
                  using A18 sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `1-4RECDEF-2K4"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) `2-4XTUPLE-0K9"
                   sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `2-4RECDEF-2K5"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10"
                   sorry
                also have "... = Ff4(\<one>\<^sub>M,Bf0,Cf0,Ff4(0NUMBERSK6,Af0,Bf0,Cf0))"
                  using A6 sorry
                also have "... = Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                  using A12 A22 A23 A26 A29 sorry
                finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                   sorry
              qed
              have case2: "x =XBOOLE-0R4 \<one>\<^sub>M implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
              proof(rule impI)
                assume A30: "x =XBOOLE-0R4 \<one>\<^sub>M"
                then have A31: "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =HIDDENR1 ?r04 & f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) =HIDDENR1 ?r14"
                  using A10 A26 A27 sorry
                have "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 ((\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `1-4XTUPLE-0K8"
                  using A18 A30 sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `1-4RECDEF-2K4"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<three>\<^sub>M) `2-4XTUPLE-0K9"
                   sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `2-4RECDEF-2K5"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<three>\<^sub>M) `3-4XTUPLE-0K10"
                   sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `3-4RECDEF-2K6"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11"
                   sorry
                also have "... = Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                  using A6 A23 A30 A31 sorry
                finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                   sorry
              qed
              have case3: "\<one>\<^sub>M <XXREAL-0R3 x implies f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
              proof(rule impI)
                assume A32: "\<one>\<^sub>M <XXREAL-0R3 x"
                then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 x -XCMPLX-0K6 \<one>\<^sub>M"
                  using xreal_1_th_13 sorry
                then have A33: "x -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 x -'NAT-DK9 \<one>\<^sub>M"
                  using xreal_0_def_2 sorry
                have A34: "\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 x"
                  using A32 nat_1_th_13 sorry
                then have A35: "(x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M =XBOOLE-0R4 x"
                  using xreal_1_th_235 sorry
                have "\<two>\<^sub>M -XCMPLX-0K6 \<two>\<^sub>M <=XXREAL-0R1 x -XCMPLX-0K6 \<two>\<^sub>M"
                  using A34 xreal_1_th_13 sorry
                then have A36: "x -XCMPLX-0K6 \<two>\<^sub>M =XBOOLE-0R4 x -'NAT-DK9 \<two>\<^sub>M"
                  using xreal_0_def_2 sorry
                have A37: "x +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (x -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M"
                   sorry
                have "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 g .FUNCT-1K1 (x +NAT-1K1 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M)) `2-4XTUPLE-0K9"
                  using A28 sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4((x +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `2-4RECDEF-2K5"
                  using A7 sorry
                also have "... = g .FUNCT-1K1 ((x -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `3-4XTUPLE-0K10"
                  using A33 sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11,Ff4((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M) `4-4XTUPLE-0K11) ] `3-4RECDEF-2K6"
                  using A7 A33 A37 sorry
                also have "... = g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) `4-4XTUPLE-0K11"
                  using A36 sorry
                also have "... = [XTUPLE-0K7 g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11,Ff4(((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `2-4XTUPLE-0K9,g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `3-4XTUPLE-0K10,g .FUNCT-1K1 ((x -'NAT-DK9 \<two>\<^sub>M)+NAT-1K1 \<two>\<^sub>M) `4-4XTUPLE-0K11) ] `4-4RECDEF-2K7"
                  using A7 sorry
                also have "... = Ff4(x +NAT-1K1 \<one>\<^sub>M,g .FUNCT-1K1 x `2-4XTUPLE-0K9,g .FUNCT-1K1 x `3-4XTUPLE-0K10,g .FUNCT-1K1 x `4-4XTUPLE-0K11)"
                  using A35 sorry
                also have "... = Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                  using A18 A26 A27 sorry
                finally show "f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(x +NAT-1K1 \<one>\<^sub>M,f .FUNCT-1K1 (x +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<two>\<^sub>M))"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 case3 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 Cf0"
          using A10 sorry
        also have "... = g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8"
          using A6 sorry
        finally have "g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) `2-4XTUPLE-0K9 =HIDDENR1 g .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<two>\<^sub>M) `1-4XTUPLE-0K8"
           sorry
        then have A38: "?P(0NUMBERSK6)"
          using A6 A21 A22 A23 A19 A16 A13 A15 A11 A14 A20 sorry
        have " for x be NatNAT-1M1 holds ?P(x)"
          using nat_1_sch_2 A38 A24 sorry
        thus " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_9:
  fixes Xf0 Af0 Bf0 Cf0 Ff4 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be ElementSUBSET-1M1-of Xf0"
  shows " ex f be sequenceNAT-1M2-of Xf0 st ((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M)))"
  proof-
    have " not ( for f be sequenceNAT-1M2-of Xf0 holds  not (((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M)))))"
    proof-
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "domRELAT-1K1 f =XBOOLE-0R4 NATNUMBERSK1"and A2: "(f .FUNCT-1K1 (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-1K1 \<two>\<^sub>M =XBOOLE-0R4 Cf0"and A3: " for n be NatNAT-1M1 holds f .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))"
        using recdef_2_sch_8 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
      proof-
        have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 Xf0"
        proof(rule ballI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          assume "y inHIDDENR3 rngFUNCT-1K2 f"
          then obtain n where
            [ty]:"n be objectHIDDENM1" and 
            A4: "n inHIDDENR3 domRELAT-1K1 f"and A5: "f .FUNCT-1K1 n =HIDDENR1 y"
            using funct_1_def_3 sorry
          have 
            [ty]:"n be NatNAT-1M1"
            using A1 A4 sorry
          show "y inHIDDENR3 Xf0"
          proof-
            have cases: "n <=XXREAL-0R1 \<two>\<^sub>M or n >XXREAL-0R4 \<two>\<^sub>M"
               sorry
            have case1: "n <=XXREAL-0R1 \<two>\<^sub>M implies y inHIDDENR3 Xf0"
            proof(rule impI)
              assume "n <=XXREAL-0R1 \<two>\<^sub>M"
              then have " ex VarFor1 be setHIDDENM2 st (0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M) & n =XBOOLE-0R4 VarFor1"
                 sorry
              thus "y inHIDDENR3 Xf0"
                using A2 A5 sorry
            qed
            have case2: "n >XXREAL-0R4 \<two>\<^sub>M implies y inHIDDENR3 Xf0"
            proof(rule impI)
              assume "n >XXREAL-0R4 \<two>\<^sub>M"
              then have "\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              then have "n -XCMPLX-0K6 \<three>\<^sub>M inTARSKIR2 NATNUMBERSK1"
                using int_1_th_5 sorry
              then have "f .FUNCT-1K1 ((n -XCMPLX-0K6 \<three>\<^sub>M)+XCMPLX-0K2 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n -XCMPLX-0K6 \<three>\<^sub>M,f .FUNCT-1K1 (n -XCMPLX-0K6 \<three>\<^sub>M),f .FUNCT-1K1 ((n -XCMPLX-0K6 \<three>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M),f .FUNCT-1K1 ((n -XCMPLX-0K6 \<three>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M))"
                using A3 sorry
              thus "y inHIDDENR3 Xf0"
                using A5 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed "sorry"
        thus "rngFUNCT-1K2 f c=TARSKIR1 Xf0"
          using tarski_def_3 sorry
      qed
      then have "f be sequenceNAT-1M2-of Xf0"
        using A1 funct_2_def_1 relset_1_th_4 sorry
      thus " not ( for f be sequenceNAT-1M2-of Xf0 holds  not (((f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & ( for n be NatNAT-1M1 holds f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,f .FUNCT-1K1 n,f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),f .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M)))))"
        using A2 A3 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_10:
  fixes Af0 Bf0 Cf0 Ff0 Gf0 Ff4 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Cf0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "(Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Ff0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "(Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Gf0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?Q = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      assume "Ff0 <>HIDDENR2 Gf0"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 NATNUMBERSK1 & Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A1 A4 funct_1_th_2 sorry
      then have A7: " ex k be NatNAT-1M1 st ?Q(k)"
         sorry
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A8: "?Q(m)"and A9: " for n be NatNAT-1M1 holds ?Q(n) implies m <=XXREAL-0R1 n"
        using nat_1_sch_5 A7 sorry
      have "( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M implies m <>HIDDENR2 VarFor1) implies  False "
      proof(rule impI)
        let ?k = "m -'NAT-DK9 \<three>\<^sub>M"
        have A10: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(?k,Ff0 .FUNCT-1K1 ?k,Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M)) & Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M) =HIDDENR1 Ff4(?k,Gf0 .FUNCT-1K1 ?k,Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M))"
          using A3 A6 sorry
        assume " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<two>\<^sub>M implies m <>HIDDENR2 VarFor1"
        then have "\<two>\<^sub>M <XXREAL-0R3 m"
           sorry
        then have "\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using nat_1_th_13 sorry
        then have A11: "m =XBOOLE-0R4 ?k +NAT-1K1 \<three>\<^sub>M"
          using xreal_1_th_235 sorry
        then have A12: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M)"
          using A9 xreal_1_th_6 sorry
        have A13: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M)"
          using A9 A11 xreal_1_th_6 sorry
        have "?k +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 m"
          using A11 xreal_1_th_6 sorry
        thus " False "
          using A8 A9 A11 A12 A13 A10 sorry
      qed
      thus " False "
        using A2 A5 A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_11:
  fixes Xf0 Af0 Bf0 Cf0 Ff0 Gf0 Ff4 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> Ff4(x1,x2,x3,x4) be ElementSUBSET-1M1-of Xf0" and
   A1: "(Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M))" and
   A3: "(Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Ff4(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
  proof-
    have A5: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    have A6: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    show "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
      using recdef_2_sch_10 A6 A1 A2 A5 A3 A4 sorry
  qed

theorem recdef_2_sch_12:
  fixes Af0 Bf0 Cf0 Df0 Ff0 Gf0 Ff5 
  assumes
[ty]: "Af0 be objectHIDDENM1" and
  [ty]: "Bf0 be objectHIDDENM1" and
  [ty]: "Cf0 be objectHIDDENM1" and
  [ty]: "Df0 be objectHIDDENM1" and
  [ty]: "Ff0 be FunctionFUNCT-1M1" and
  [ty]: "Gf0 be FunctionFUNCT-1M1" and
  [ty_func]: "\<And> x1 x2 x3 x4 x5. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> x5 be objectHIDDENM1 \<Longrightarrow> Ff5(x1,x2,x3,x4,x5) be objectHIDDENM1" and
   A1: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1" and
   A2: "((Ff0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Ff0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Ff0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0) & Ff0 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 Df0" and
   A3: " for n be NatNAT-1M1 holds Ff0 .FUNCT-1K1 (n +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M),Ff0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M))" and
   A4: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1" and
   A5: "((Gf0 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 Af0 & Gf0 .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 Bf0) & Gf0 .FUNCT-1K1 \<two>\<^sub>M =HIDDENR1 Cf0) & Gf0 .FUNCT-1K1 \<three>\<^sub>M =HIDDENR1 Df0" and
   A6: " for n be NatNAT-1M1 holds Gf0 .FUNCT-1K1 (n +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<two>\<^sub>M),Gf0 .FUNCT-1K1 (n +NAT-1K1 \<three>\<^sub>M))"
  shows "Ff0 =FUNCT-1R1 Gf0"
  proof-
    have "Ff0 <>HIDDENR2 Gf0 implies  False "
    proof(rule impI)
      let ?Q = "\<lambda>Lamb1. Ff0 .FUNCT-1K1 Lamb1 <>HIDDENR2 Gf0 .FUNCT-1K1 Lamb1"
      assume "Ff0 <>HIDDENR2 Gf0"
      then have " ex x be objectHIDDENM1 st x inHIDDENR3 NATNUMBERSK1 & Ff0 .FUNCT-1K1 x <>HIDDENR2 Gf0 .FUNCT-1K1 x"
        using A1 A4 funct_1_th_2 sorry
      then have A7: " ex k be NatNAT-1M1 st ?Q(k)"
         sorry
      obtain m where
        [ty]:"m be NatNAT-1M1" and 
        A8: "?Q(m)"and A9: " for n be NatNAT-1M1 holds ?Q(n) implies m <=XXREAL-0R1 n"
        using nat_1_sch_5 A7 sorry
      have "( for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<three>\<^sub>M implies m <>HIDDENR2 VarFor1) implies  False "
      proof(rule impI)
        let ?k = "m -'NAT-DK9 \<four>\<^sub>M"
        have A10: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(?k,Ff0 .FUNCT-1K1 ?k,Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M),Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M)) & Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<four>\<^sub>M) =HIDDENR1 Ff5(?k,Gf0 .FUNCT-1K1 ?k,Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M),Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M))"
          using A3 A6 sorry
        assume " for VarFor1 be setHIDDENM2 holds 0NUMBERSK6 <=XXREAL-0R1 VarFor1 & VarFor1 <=XXREAL-0R1 \<three>\<^sub>M implies m <>HIDDENR2 VarFor1"
        then have "\<three>\<^sub>M <XXREAL-0R3 m"
           sorry
        then have "\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 m"
          using nat_1_th_13 sorry
        then have A11: "m =XBOOLE-0R4 ?k +NAT-1K1 \<four>\<^sub>M"
          using xreal_1_th_235 sorry
        then have A12: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<one>\<^sub>M)"
          using A9 xreal_1_th_6 sorry
        have "?k +NAT-1K1 \<three>\<^sub>M <XXREAL-0R3 m"
          using A11 xreal_1_th_6 sorry
        then have A13: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<three>\<^sub>M)"
          using A9 sorry
        have "?k +NAT-1K1 \<two>\<^sub>M <XXREAL-0R3 m"
          using A11 xreal_1_th_6 sorry
        then have A14: "Ff0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M) =XBOOLE-0R4 Gf0 .FUNCT-1K1 (?k +NAT-1K1 \<two>\<^sub>M)"
          using A9 sorry
        have "?k +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 m"
          using A11 xreal_1_th_6 sorry
        thus " False "
          using A8 A9 A11 A12 A14 A13 A10 sorry
      qed
      thus " False "
        using A2 A5 A8 sorry
    qed
    thus " ?thesis "
       sorry
  qed

theorem recdef_2_sch_13:
  fixes Xf0 Af0 Bf0 Cf0 Df0 Ff0 Gf0 Ff5 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Af0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Bf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Cf0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Df0 be ElementSUBSET-1M1-of Xf0" and
  [ty]: "Ff0 be sequenceNAT-1M2-of Xf0" and
  [ty]: "Gf0 be sequenceNAT-1M2-of Xf0" and
  [ty_func]: "\<And> x1 x2 x3 x4 x5. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> x3 be objectHIDDENM1 \<Longrightarrow> x4 be objectHIDDENM1 \<Longrightarrow> x5 be objectHIDDENM1 \<Longrightarrow> Ff5(x1,x2,x3,x4,x5) be ElementSUBSET-1M1-of Xf0" and
   A1: "((Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 Df0" and
   A2: " for n be NatNAT-1M1 holds Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<four>\<^sub>M) =XBOOLE-0R4 Ff5(n,Ff0 .FUNCT-1K1 n,Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M),Ff0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M))" and
   A3: "((Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 Af0 & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 Bf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<two>\<^sub>M =XBOOLE-0R4 Cf0) & Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> \<three>\<^sub>M =XBOOLE-0R4 Df0" and
   A4: " for n be NatNAT-1M1 holds Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<four>\<^sub>M) =XBOOLE-0R4 Ff5(n,Gf0 .FUNCT-1K1 n,Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<one>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<two>\<^sub>M),Gf0 .FUNCT-2K3\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> (n +NAT-1K1 \<three>\<^sub>M))"
  shows "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
  proof-
    have A5: "domRELAT-1K1 Gf0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    have A6: "domRELAT-1K1 Ff0 =XBOOLE-0R4 NATNUMBERSK1"
      using funct_2_def_1 sorry
    show "Ff0 =FUNCT-2R2\<^bsub>(NATNUMBERSK1,Xf0)\<^esub> Gf0"
      using recdef_2_sch_12 A6 A1 A2 A5 A3 A4 sorry
  qed

(*begin*)
mtheorem recdef_2_th_10:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (((x `1-3XTUPLE-0K4 =HIDDENR1 y `1-3XTUPLE-0K4 & x `2-3XTUPLE-0K5 =HIDDENR1 y `2-3XTUPLE-0K5) & x `3-3XTUPLE-0K6 =HIDDENR1 y `3-3XTUPLE-0K6) & y inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :]) & x inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :] implies x =XBOOLE-0R4 y"
proof-
  have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds ((x `1-3XTUPLE-0K4 =HIDDENR1 y `1-3XTUPLE-0K4 & x `2-3XTUPLE-0K5 =HIDDENR1 y `2-3XTUPLE-0K5) & x `3-3XTUPLE-0K6 =HIDDENR1 y `3-3XTUPLE-0K6) & y inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :] implies (x inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :] implies x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix x assume [ty]: "x be setHIDDENM2"
    fix y assume [ty]: "y be setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "((x `1-3XTUPLE-0K4 =HIDDENR1 y `1-3XTUPLE-0K4 & x `2-3XTUPLE-0K5 =HIDDENR1 y `2-3XTUPLE-0K5) & x `3-3XTUPLE-0K6 =HIDDENR1 y `3-3XTUPLE-0K6) & y inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :]"
    assume "x inTARSKIR2 [:ZFMISC-1K3 X,Y,Z :]"
    then have "x =HIDDENR1 [XTUPLE-0K3 x `1-3XTUPLE-0K4,x `2-3XTUPLE-0K5,x `3-3XTUPLE-0K6 ]"
      using recdef_2_th_3 sorry
    also have "... = y"
      using A1 recdef_2_th_3 sorry
    finally show "x =HIDDENR1 y"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
