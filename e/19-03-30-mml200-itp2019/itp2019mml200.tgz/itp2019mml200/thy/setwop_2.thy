theory setwop_2
  imports finseqop finsop_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve C, C9, D, E for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve c, c9, c1, c2, c3 for "ElementSUBSET-1M1-of C"
reserve B, B9, B1, B2 for "ElementSUBSET-1M1-of FinFINSUB-1K5 C"
reserve A for "ElementSUBSET-1M1-of FinFINSUB-1K5 C9"
reserve d, d1, d2, d3, d4, e for "ElementSUBSET-1M1-of D"
reserve F, G for "BinOpBINOP-1M2-of D"
reserve u for "UnOpBINOP-1M1-of D"
reserve f, f9 for "FunctionFUNCT-2M1-of(C,D)"
reserve g for "FunctionFUNCT-2M1-of(C9,D)"
reserve H for "BinOpBINOP-1M2-of E"
reserve h for "FunctionFUNCT-2M1-of(D,E)"
reserve i, j for "NatNAT-1M1"
reserve s for "FunctionFUNCT-1M1"
reserve p, q for "FinSequenceFINSEQ-1M3-of D"
reserve T1, T2 for "ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
mlemma setwop_2_lm_1:
" for i be NatNAT-1M1 holds SegFINSEQ-1K2 i be ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
  using finsub_1_def_5 sorry

mlemma setwop_2_lm_2:
" for i be NatNAT-1M1 holds  not i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 i"
  using finseq_1_th_1 xreal_1_th_29 sorry

mtheorem setwop_2_th_1:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "c1 <>HIDDENR2 c2"
    obtain g where
      [ty]:"g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 C,D)" and 
      A3: "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =XBOOLE-0R4 g .FUNCT-1K1 {TARSKIK2 c1,c2 }"and " for e be ElementSUBSET-1M1-of D holds e is-a-unity-wrtBINOP-1R3\<^bsub>(D)\<^esub> F implies g .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A4: " for c be ElementSUBSET-1M1-of C holds g .FUNCT-1K1 {TARSKIK1 c} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"and A5: " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds B c=TARSKIR1 {TARSKIK2 c1,c2 } & B <>HIDDENR2 {}XBOOLE-0K1 implies ( for c be ElementSUBSET-1M1-of C holds c inTARSKIR2 {TARSKIK2 c1,c2 } \\SUBSET-1K6 B implies g .FUNCT-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 c}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
      using A1 setwiseo_def_3 sorry
    have "c1 inTARSKIR2 {TARSKIK1 c1} &  not c2 inTARSKIR2 {TARSKIK1 c1}"
      using A2 tarski_def_1 sorry
    then have "{TARSKIK2 c1,c2 } \\SUBSET-1K6 {TARSKIK1 c1} =XBOOLE-0R4 {TARSKIK1 c2}"
      using zfmisc_1_th_62 sorry
    then have A6: "c2 inTARSKIR2 {TARSKIK2 c1,c2 } \\SUBSET-1K6 {TARSKIK1 c1}"
      using tarski_def_1 sorry
    have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =HIDDENR1 g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> ({.SETWISEOK5\<^bsub>(C)\<^esub> c1.} \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c2.})"
      using A3 enumset1_th_1 sorry
    also have "... = F .BINOP-1K1(g .FUNCT-1K1 {TARSKIK1 c1},f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
      using A5 A6 zfmisc_1_th_7 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
      using A4 sorry
    finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_2:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) &  not c inTARSKIR2 B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c be ElementSUBSET-1M1-of C holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & ((B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not c inTARSKIR2 B) implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: " not c inTARSKIR2 B"
    show "F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
    proof-
      have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
      proof(rule impI)
        assume A4: "B =XBOOLE-0R4 {}XBOOLE-0K1"
        then have "B =XBOOLE-0R4 {}.SETWISEOK1 C"
           sorry
        then have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          using A1 A2 setwiseo_th_31 sorry
        then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
          using A2 A4 setwiseo_th_15 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
          using A1 A4 setwiseo_th_17 sorry
        finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
           sorry
      qed
      have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
      proof(rule impI)
        assume A5: "B <>HIDDENR2 {}XBOOLE-0K1"
        obtain g9 where
          [ty]:"g9 be FunctionFUNCT-2M1-of(FinFINSUB-1K5 C,D)" and 
          A6: "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 g9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B"and " for e be ElementSUBSET-1M1-of D holds e is-a-unity-wrtBINOP-1R3\<^bsub>(D)\<^esub> F implies g9 .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A7: " for c9 be ElementSUBSET-1M1-of C holds g9 .FUNCT-1K1 {TARSKIK1 c9} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9"and A8: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds B9 c=TARSKIR1 B & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for c9 be ElementSUBSET-1M1-of C holds c9 inTARSKIR2 B \\SETWISEOK9\<^bsub>(C)\<^esub> B9 implies g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(g9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9))"
          using A1 A2 setwiseo_def_3 sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-2M1-of(FinFINSUB-1K5 C,D)" and 
          A9: "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 g .FUNCT-1K1 (B \\/XBOOLE-0K2 {TARSKIK1 c})"and " for e be ElementSUBSET-1M1-of D holds e is-a-unity-wrtBINOP-1R3\<^bsub>(D)\<^esub> F implies g .FUNCT-1K1 {}XBOOLE-0K1 =XBOOLE-0R4 e"and A10: " for c9 be ElementSUBSET-1M1-of C holds g .FUNCT-1K1 {TARSKIK1 c9} =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9"and A11: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 c} & B9 <>HIDDENR2 {}XBOOLE-0K1 implies ( for c9 be ElementSUBSET-1M1-of C holds c9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 c})\\SUBSET-1K6 B9 implies g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9))"
          using A1 setwiseo_def_3 sorry
        let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 & Lamb1 c=TARSKIR1 B implies g .FUNCT-1K1 Lamb1 =XBOOLE-0R4 g9 .FUNCT-1K1 Lamb1"
        have A12: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/XBOOLE-0K2 {TARSKIK1 b})"
        proof-
          have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c9 be ElementSUBSET-1M1-of C holds (B9 <>HIDDENR2 {}XBOOLE-0K1 & B9 c=TARSKIR1 B implies g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9 =XBOOLE-0R4 g9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9) & ( not c9 inTARSKIR2 B9 & (B9 \\/XBOOLE-0K2 {TARSKIK1 c9} <>HIDDENR2 {}XBOOLE-0K1 & B9 \\/XBOOLE-0K2 {TARSKIK1 c9} c=TARSKIR1 B)) implies g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
            have A13: "B c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 c}"
              using xboole_1_th_7 sorry
            fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
            fix c9 assume [ty]: "c9 be ElementSUBSET-1M1-of C"
            assume A14: "B9 <>HIDDENR2 {}XBOOLE-0K1 & B9 c=TARSKIR1 B implies g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9 =XBOOLE-0R4 g9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9"
              and A15: " not c9 inTARSKIR2 B9"
              and "B9 \\/XBOOLE-0K2 {TARSKIK1 c9} <>HIDDENR2 {}XBOOLE-0K1"
              and A16: "B9 \\/XBOOLE-0K2 {TARSKIK1 c9} c=TARSKIR1 B"
            have A17: "c9 inTARSKIR2 B"
              using A16 zfmisc_1_th_137 sorry
            then have A18: "c9 inTARSKIR2 B \\SETWISEOK9\<^bsub>(C)\<^esub> B9"
              using A15 xboole_0_def_5 sorry
            have "c9 inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 c}"
              using A17 xboole_0_def_3 sorry
            then have A19: "c9 inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 c})\\SUBSET-1K6 B9"
              using A15 xboole_0_def_5 sorry
            have "B9 c=TARSKIR1 B"
              using A16 xboole_1_th_11 sorry
            then have A20: "B9 c=TARSKIR1 B \\/XBOOLE-0K2 {TARSKIK1 c}"
              using A13 xboole_1_th_1 sorry
            show "g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
            proof-
              have cases: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 or B9 <>HIDDENR2 {}XBOOLE-0K1"
                 sorry
              have case1: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 implies g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
              proof(rule impI)
                assume A21: "B9 =XBOOLE-0R4 {}XBOOLE-0K1"
                then have "g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9"
                  using A10 sorry
                thus "g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =XBOOLE-0R4 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
                  using A7 A21 sorry
              qed
              have case2: "B9 <>HIDDENR2 {}XBOOLE-0K1 implies g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =HIDDENR1 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
              proof(rule impI)
                assume A22: "B9 <>HIDDENR2 {}XBOOLE-0K1"
                then have "g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(g9 .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B9,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c9)"
                  using A11 A14 A16 A20 A19 xboole_1_th_11 sorry
                also have "... = g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
                  using A8 A16 A18 A22 xboole_1_th_11 sorry
                finally show "g .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9}) =HIDDENR1 g9 .FUNCT-1K1 (B9 \\/XBOOLE-0K2 {TARSKIK1 c9})"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A23: "?X({}.SETWISEOK1 C)"
           sorry
        have A24: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B9)"
          using setwiseo_sch_2 A23 A12 sorry
        have "c inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 c}"
          using zfmisc_1_th_136 sorry
        then have "c inTARSKIR2 (B \\/XBOOLE-0K2 {TARSKIK1 c})\\SUBSET-1K6 B"
          using A3 xboole_0_def_5 sorry
        then have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(g .FUNCT-2K3\<^bsub>(FinFINSUB-1K5 C,D)\<^esub> B,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using A5 A9 A11 xboole_1_th_7 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using A5 A6 A24 sorry
        finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_3:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for c3 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2) & c1 <>HIDDENR2 c3) & c2 <>HIDDENR2 c3 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK7\<^bsub>(C)\<^esub> c1,c2,c3 .},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for c1 be ElementSUBSET-1M1-of C holds  for c2 be ElementSUBSET-1M1-of C holds  for c3 be ElementSUBSET-1M1-of C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & c1 <>HIDDENR2 c2 implies (c1 <>HIDDENR2 c3 & c2 <>HIDDENR2 c3 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK7\<^bsub>(C)\<^esub> c1,c2,c3 .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix c1 assume [ty]: "c1 be ElementSUBSET-1M1-of C"
    fix c2 assume [ty]: "c2 be ElementSUBSET-1M1-of C"
    fix c3 assume [ty]: "c3 be ElementSUBSET-1M1-of C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "c1 <>HIDDENR2 c2"
    assume "c1 <>HIDDENR2 c3 & c2 <>HIDDENR2 c3"
    then have A3: " not c3 inTARSKIR2 {TARSKIK2 c1,c2 }"
      using tarski_def_2 sorry
    have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK7\<^bsub>(C)\<^esub> c1,c2,c3 .},f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .} \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c3.},f)"
      using enumset1_th_3 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK6\<^bsub>(C)\<^esub> c1,c2 .},f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3)"
      using A1 A3 setwop_2_th_2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3)"
      using A1 A2 setwop_2_th_1 sorry
    finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({.SETWISEOK7\<^bsub>(C)\<^esub> c1,c2,c3 .},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c1,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c2),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c3)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_4:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & B1 missesXBOOLE-0R1 B2 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  not ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) &  not ( not ( not B1 <>HIDDENR2 {}XBOOLE-0K1 &  not B2 <>HIDDENR2 {}XBOOLE-0K1) &  not F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & B1 missesXBOOLE-0R1 B2) &  not F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B1 assume [ty]: "B1 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix B2 assume [ty]: "B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    have "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & ((B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & B1 /\\FINSUB-1K3\<^bsub>(FinFINSUB-1K5 C)\<^esub> B2 =XBOOLE-0R4 {}XBOOLE-0K1) implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
        and A2: "B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
        and A3: "B1 /\\FINSUB-1K3\<^bsub>(FinFINSUB-1K5 C)\<^esub> B2 =XBOOLE-0R4 {}XBOOLE-0K1"
      have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
      proof-
        show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
        proof-
          have cases: "(B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1) or B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
          proof(rule impI)
            assume A4: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1"
            have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
            proof-
              show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
              proof-
                have cases: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 or B2 =XBOOLE-0R4 {}XBOOLE-0K1"
                  using A4 sorry
                have case1: "B1 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                proof(rule impI)
                  assume A5: "B1 =XBOOLE-0R4 {}XBOOLE-0K1"
                  then have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                    using A2 setwiseo_th_15 sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                    using A1 A2 A4 setwiseo_th_31 sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                    using A5 sorry
                  finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                     sorry
                qed
                have case2: "B2 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                proof(rule impI)
                  assume A6: "B2 =XBOOLE-0R4 {}XBOOLE-0K1"
                  then have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
                    using A2 setwiseo_th_15 sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f))"
                    using A1 A2 A4 setwiseo_th_31 sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                    using A6 sorry
                  finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
               sorry
          qed
          have case2: "B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
          proof(rule impI)
            assume A7: "B1 <>HIDDENR2 {}XBOOLE-0K1 & B2 <>HIDDENR2 {}XBOOLE-0K1"
            let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 & B1 /\\FINSUB-1K3\<^bsub>(FinFINSUB-1K5 C)\<^esub> Lamb1 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> Lamb1,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f))"
            have A8: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
            proof-
              have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds (B <>HIDDENR2 {}XBOOLE-0K1 & B1 /\\FINSUB-1K3\<^bsub>(FinFINSUB-1K5 C)\<^esub> B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))) & ( not c inTARSKIR2 B & B \\/XBOOLE-0K2 {TARSKIK1 c} <>HIDDENR2 {}XBOOLE-0K1) implies (B1 /\\XBOOLE-0K3 (B \\/XBOOLE-0K2 {TARSKIK1 c}) =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)))"
              proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
                fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
                fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
                assume A9: "B <>HIDDENR2 {}XBOOLE-0K1 & B1 /\\FINSUB-1K3\<^bsub>(FinFINSUB-1K5 C)\<^esub> B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
                  and A10: " not c inTARSKIR2 B"
                  and "B \\/XBOOLE-0K2 {TARSKIK1 c} <>HIDDENR2 {}XBOOLE-0K1"
                assume A11: "B1 /\\XBOOLE-0K3 (B \\/XBOOLE-0K2 {TARSKIK1 c}) =XBOOLE-0R4 {}XBOOLE-0K1"
                then have A12: "B1 missesXBOOLE-0R1 B \\/XBOOLE-0K2 {TARSKIK1 c}"
                   sorry
                have "c inTARSKIR2 B \\/XBOOLE-0K2 {TARSKIK1 c}"
                  using zfmisc_1_th_136 sorry
                then have A13: " not c inTARSKIR2 B1"
                  using A11 xboole_0_def_4 sorry
                have A14: "B <>HIDDENR2 {}XBOOLE-0K1 & B1 missesXBOOLE-0R1 B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
                  using A9 sorry
                have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                proof-
                  show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                  proof-
                    have cases: "B =XBOOLE-0R4 {}XBOOLE-0K1 or B <>HIDDENR2 {}XBOOLE-0K1"
                       sorry
                    have case1: "B =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                    proof(rule impI)
                      assume A15: "B =XBOOLE-0R4 {}XBOOLE-0K1"
                      then have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                        using A1 A7 A13 setwop_2_th_2 sorry
                      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                        using A1 A15 setwiseo_th_17 sorry
                      finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                         sorry
                    qed
                    have case2: "B <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                    proof(rule impI)
                      assume A16: "B <>HIDDENR2 {}XBOOLE-0K1"
                      have A17: " not c inTARSKIR2 B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B"
                        using A10 A13 xboole_0_def_3 sorry
                      have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>((B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B)\\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)"
                        using xboole_1_th_4 sorry
                      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                        using A1 A14 A12 A16 A17 setwop_2_th_2 xboole_1_th_7 xboole_1_th_63 sorry
                      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
                        using A1 sorry
                      also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                        using A1 A10 A16 setwop_2_th_2 sorry
                      finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> (B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}),f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f))"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            have A18: "?X({}.SETWISEOK1 C)"
               sorry
            have " for B2 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B2)"
              using setwiseo_sch_2 A18 A8 sorry
            thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
              using A3 A7 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f))"
         sorry
    qed
    thus " not ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) &  not ( not ( not B1 <>HIDDENR2 {}XBOOLE-0K1 &  not B2 <>HIDDENR2 {}XBOOLE-0K1) &  not F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & B1 missesXBOOLE-0R1 B2) &  not F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1 \\/SETWISEOK8\<^bsub>(C)\<^esub> B2,f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B2,f)))"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_5:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (A <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 A & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for A be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for g be FunctionFUNCT-2M1-of(C9,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> implies  not (( not (A <>HIDDENR2 {}XBOOLE-0K1 &  not F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not ( for s be FunctionFUNCT-1M1 holds  not (((domRELAT-1K1 s =XBOOLE-0R4 A & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A =FUNCT-1R1 f *FUNCT-1K3 s))) &  not F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix C9 assume [ty]: "C9 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix A assume [ty]: "A be ElementSUBSET-1M1-of FinFINSUB-1K5 C9"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix g assume [ty]: "g be FunctionFUNCT-2M1-of(C9,D)"
    let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 Lamb1 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> Lamb1 =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(Lamb1,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    have A2: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds  for b be ElementSUBSET-1M1-of C9 holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> b.})"
    proof-
      have " for A9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds  for a be ElementSUBSET-1M1-of C9 holds (A9 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 A9 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9 =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))) &  not a inTARSKIR2 A9 implies (A9 \\/XBOOLE-0K2 {TARSKIK1 a} <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.} & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> (A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.}) =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI,rule ballI,rule impI)
        fix A9 assume [ty]: "A9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C9"
        fix a assume [ty]: "a be ElementSUBSET-1M1-of C9"
        assume A3: "A9 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 A9 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9 =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
          and A4: " not a inTARSKIR2 A9"
        assume "A9 \\/XBOOLE-0K2 {TARSKIK1 a} <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        let ?A = "A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.}"
        assume Given: " ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 ?A & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> ?A =FUNCT-1R1 f *FUNCT-1K3 s"
        then obtain s where
          [ty]:"s be FunctionFUNCT-1M1" and 
          A5: "domRELAT-1K1 s =XBOOLE-0R4 ?A"and A6: "rngFUNCT-1K2 s =XBOOLE-0R4 B"and A7: "s be one-to-oneFUNCT-1V2"and A8: "g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> ?A =FUNCT-1R1 f *FUNCT-1K3 s"
           sorry
        have A9: "a inTARSKIR2 ?A"
          using zfmisc_1_th_136 sorry
        then have A10: "s .FUNCT-1K1 a inTARSKIR2 B"
          using A5 A6 funct_1_def_3 sorry
        have "B c=TARSKIR1 C"
          using finsub_1_def_5 sorry
        then obtain c where 
          [ty]:"c be ElementSUBSET-1M1-of C" and cDef:"c = s .FUNCT-1K1 a"
          using A10 sorry
        let ?B9 = "B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}"
        let ?s9 = "s  |RELAT-1K8 A9"
        have A11: "?s9 be one-to-oneFUNCT-1V2"
          using A7 funct_1_th_52 sorry
        have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 (s  |RELAT-1K8 A9) implies y inHIDDENR3 B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}) & (y inHIDDENR3 B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.} implies y inHIDDENR3 rngFUNCT-1K2 (s  |RELAT-1K8 A9))"
        proof(rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          show "y inHIDDENR3 rngFUNCT-1K2 (s  |RELAT-1K8 A9) implies y inHIDDENR3 B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}"
          proof(rule impI)
            assume "y inHIDDENR3 rngFUNCT-1K2 ?s9"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A12: "x inHIDDENR3 domRELAT-1K1 ?s9"and A13: "y =HIDDENR1 ?s9 .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have A14: "?s9 .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 x"
              using A12 funct_1_th_47 sorry
            have A15: "x inHIDDENR3 domRELAT-1K1 s /\\XBOOLE-0K3 A9"
              using A12 relat_1_th_61 sorry
            then have "x inHIDDENR3 domRELAT-1K1 s & x <>HIDDENR2 a"
              using A4 xboole_0_def_4 sorry
            then have "s .FUNCT-1K1 x <>HIDDENR2 c"
              using A5 A7 A9 funct_1_def_4 sorry
            then have A16: " not y inHIDDENR3 {TARSKIK1 c}"
              using A13 A14 tarski_def_1 sorry
            have "x inHIDDENR3 domRELAT-1K1 s"
              using A15 xboole_0_def_4 sorry
            then have "y inHIDDENR3 B"
              using A6 A13 A14 funct_1_def_3 sorry
            thus "y inHIDDENR3 B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}"
              using A16 xboole_0_def_5 sorry
          qed
          assume A17: "y inHIDDENR3 ?B9"
          then have "y inHIDDENR3 B"
            using xboole_0_def_5 sorry
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            A18: "x inHIDDENR3 domRELAT-1K1 s"and A19: "y =HIDDENR1 s .FUNCT-1K1 x"
            using A6 funct_1_def_3 sorry
          have A20: "x inHIDDENR3 A9 or x inHIDDENR3 {TARSKIK1 a}"
            using A5 A18 xboole_0_def_3 sorry
          have " not y inHIDDENR3 {TARSKIK1 c}"
            using A17 xboole_0_def_5 sorry
          then have "x <>HIDDENR2 a"
            using A19 tarski_def_1 sorry
          then have "x inHIDDENR3 domRELAT-1K1 s /\\XBOOLE-0K3 A9"
            using A18 A20 tarski_def_1 xboole_0_def_4 sorry
          then have "x inHIDDENR3 domRELAT-1K1 ?s9 & ?s9 .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 x"
            using funct_1_th_48 relat_1_th_61 sorry
          thus "y inHIDDENR3 rngFUNCT-1K2 (s  |RELAT-1K8 A9)"
            using A19 funct_1_def_3 sorry
        qed "sorry"
        then have A21: "rngFUNCT-1K2 ?s9 =XBOOLE-0R4 ?B9"
          using tarski_th_2 sorry
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9) implies x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s  |RELAT-1K8 A9)) & (x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s  |RELAT-1K8 A9) implies x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9))"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9) implies x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s  |RELAT-1K8 A9)"
          proof(rule impI)
            assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9)"
            then have A22: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> A9"
              using relat_1_th_61 sorry
            then have A23: "x inHIDDENR3 A9"
              using xboole_0_def_4 sorry
            have A24: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
              using A22 xboole_0_def_4 sorry
            have "x inHIDDENR3 ?A"
              using A23 zfmisc_1_th_136 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> ?A"
              using A24 xboole_0_def_4 sorry
            then have A25: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s)"
              using A8 relat_1_th_61 sorry
            then have A26: "s .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
              using funct_1_th_11 sorry
            have "x inHIDDENR3 domRELAT-1K1 s"
              using A25 funct_1_th_11 sorry
            then have "x inHIDDENR3 domRELAT-1K1 s /\\XBOOLE-0K3 A9"
              using A23 xboole_0_def_4 sorry
            then have A27: "x inHIDDENR3 domRELAT-1K1 ?s9"
              using relat_1_th_61 sorry
            then have "?s9 .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 x"
              using funct_1_th_47 sorry
            thus "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s  |RELAT-1K8 A9)"
              using A26 A27 funct_1_th_11 sorry
          qed
          assume A28: "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 ?s9)"
          then have A29: "x inHIDDENR3 domRELAT-1K1 ?s9"
            using funct_1_th_11 sorry
          then have A30: "x inHIDDENR3 domRELAT-1K1 s /\\XBOOLE-0K3 A9"
            using relat_1_th_61 sorry
          then have A31: "x inHIDDENR3 domRELAT-1K1 s"
            using xboole_0_def_4 sorry
          have "?s9 .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            using A28 funct_1_th_11 sorry
          then have "s .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
            using A29 funct_1_th_47 sorry
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> ?A)"
            using A8 A31 funct_1_th_11 sorry
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> ?A"
            using relat_1_th_61 sorry
          then have A32: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
            using xboole_0_def_4 sorry
          have "x inHIDDENR3 A9"
            using A30 xboole_0_def_4 sorry
          then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> A9"
            using A32 xboole_0_def_4 sorry
          thus "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9)"
            using relat_1_th_61 sorry
        qed "sorry"
        then have A33: "domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9) =XBOOLE-0R4 domRELAT-1K1 (f *FUNCT-1K3 ?s9)"
          using tarski_th_2 sorry
        have "a inTARSKIR2 C9"
           sorry
        then have "a inTARSKIR2 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
          using funct_2_def_1 sorry
        then have "a inTARSKIR2 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> ?A"
          using A9 xboole_0_def_4 sorry
        then have "a inTARSKIR2 domRELAT-1K1 (f *FUNCT-1K3 s) & g .FUNCT-2K3\<^bsub>(C9,D)\<^esub> a =XBOOLE-0R4 (f *FUNCT-1K3 s).FUNCT-1K1 a"
          using A8 funct_1_th_48 relat_1_th_61 sorry
        then have A34: "g .FUNCT-2K3\<^bsub>(C9,D)\<^esub> a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
          using funct_1_th_12 sorry
        have "?B9 \\/XBOOLE-0K2 {TARSKIK1 c} =XBOOLE-0R4 B \\/XBOOLE-0K2 {TARSKIK1 c}"
          using xboole_1_th_39 sorry
        then have A35: "B =XBOOLE-0R4 ?B9 \\/XBOOLE-0K2 {TARSKIK1 c}"
          using A10 zfmisc_1_th_40 sorry
        have A36: "domRELAT-1K1 ?s9 =XBOOLE-0R4 A9"
          using A5 relat_1_th_62 xboole_1_th_7 sorry
        have A37: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9) implies (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9).FUNCT-1K1 x =XBOOLE-0R4 (f *FUNCT-1K3 ?s9).FUNCT-1K1 x"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9) implies (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9).FUNCT-1K1 x =HIDDENR1 (f *FUNCT-1K3 s  |RELAT-1K8 A9).FUNCT-1K1 x"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9)"
            then have A38: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> A9"
              using relat_1_th_61 sorry
            then have A39: "x inHIDDENR3 A9"
              using xboole_0_def_4 sorry
            then have A40: "x inHIDDENR3 ?A"
              using zfmisc_1_th_136 sorry
            have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
              using A38 xboole_0_def_4 sorry
            then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> ?A"
              using A40 xboole_0_def_4 sorry
            then have "x inHIDDENR3 domRELAT-1K1 (f *FUNCT-1K3 s)"
              using A8 relat_1_th_61 sorry
            then have A41: "x inHIDDENR3 domRELAT-1K1 s"
              using funct_1_th_11 sorry
            then have "x inHIDDENR3 domRELAT-1K1 s /\\XBOOLE-0K3 A9"
              using A39 xboole_0_def_4 sorry
            then have A42: "x inHIDDENR3 domRELAT-1K1 ?s9"
              using relat_1_th_61 sorry
            then have A43: "?s9 .FUNCT-1K1 x =XBOOLE-0R4 s .FUNCT-1K1 x"
              using funct_1_th_47 sorry
            have "(g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9).FUNCT-1K1 x =HIDDENR1 g .FUNCT-1K1 x"
              using A39 funct_1_th_49 sorry
            also have "... = (f *FUNCT-1K3 s).FUNCT-1K1 x"
              using A8 A40 funct_1_th_49 sorry
            also have "... = f .FUNCT-1K1 (s .FUNCT-1K1 x)"
              using A41 funct_1_th_13 sorry
            also have "... = (f *FUNCT-1K3 s  |RELAT-1K8 A9).FUNCT-1K1 x"
              using A42 A43 funct_1_th_13 sorry
            finally show "(g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9).FUNCT-1K1 x =HIDDENR1 (f *FUNCT-1K3 s  |RELAT-1K8 A9).FUNCT-1K1 x"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then have A44: "g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9 =FUNCT-1R1 f *FUNCT-1K3 ?s9"
          using A33 funct_1_th_2 sorry
        have " for y be objectHIDDENM1 holds (y inHIDDENR3 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9 implies y inHIDDENR3 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> (B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.})) & (y inHIDDENR3 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> (B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.}) implies y inHIDDENR3 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9)"
        proof(rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          show "y inHIDDENR3 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9 implies y inHIDDENR3 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> (B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.})"
          proof(rule impI)
            assume "y inHIDDENR3 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A45: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g"and A46: "x inHIDDENR3 A9"and A47: "y =HIDDENR1 g .FUNCT-1K1 x"
              using funct_1_def_6 sorry
            have "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> g /\\SUBSET-1K8\<^bsub>(C9)\<^esub> A9"
              using A45 A46 xboole_0_def_4 sorry
            then have A48: "x inHIDDENR3 domRELSET-1K1\<^bsub>(C9)\<^esub> (g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A9)"
              using relat_1_th_61 sorry
            then have "x inHIDDENR3 domRELAT-1K1 ?s9"
              using A33 funct_1_th_11 sorry
            then have A49: "?s9 .FUNCT-1K1 x inTARSKIR2 ?B9"
              using A21 funct_1_def_3 sorry
            have "y =HIDDENR1 (f *FUNCT-1K3 ?s9).FUNCT-1K1 x"
              using A44 A46 A47 funct_1_th_49 sorry
            then have A50: "y =HIDDENR1 f .FUNCT-1K1 (?s9 .FUNCT-1K1 x)"
              using A33 A48 funct_1_th_12 sorry
            have "?s9 .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
              using A33 A48 funct_1_th_11 sorry
            thus "y inHIDDENR3 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> (B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.})"
              using A50 A49 funct_1_def_6 sorry
          qed
          assume "y inHIDDENR3 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> ?B9"
          then obtain x where
            [ty]:"x be objectHIDDENM1" and 
            "x inHIDDENR3 domRELSET-1K1\<^bsub>(C)\<^esub> f"and A51: "x inHIDDENR3 ?B9"and A52: "y =HIDDENR1 f .FUNCT-1K1 x"
            using funct_1_def_6 sorry
          let ?x9 = "?s9 \<inverse>FUNCT-1K4 .FUNCT-1K1 x"
          have A53: "?x9 inTARSKIR2 A9"
            using A11 A36 A21 A51 funct_1_th_32 sorry
          have "A9 c=TARSKIR1 C9"
            using finsub_1_def_5 sorry
          then have "?x9 inTARSKIR2 C9"
            using A53 sorry
          then have A54: "?x9 inTARSKIR2 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
            using funct_2_def_1 sorry
          have "?s9 .FUNCT-1K1 ?x9 =HIDDENR1 x"
            using A11 A21 A51 funct_1_th_35 sorry
          then have "y =HIDDENR1 (f *FUNCT-1K3 ?s9).FUNCT-1K1 ?x9"
            using A36 A52 A53 funct_1_th_13 sorry
          also have "... = g .FUNCT-1K1 ?x9"
            using A44 A53 funct_1_th_49 sorry
          finally have "y =HIDDENR1 g .FUNCT-1K1 ?x9"
             sorry
          thus "y inHIDDENR3 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9"
            using A53 A54 funct_1_def_6 sorry
        qed "sorry"
        then have A55: "f .:SETWISEOK11\<^bsub>(C,D)\<^esub> ?B9 =XBOOLE-0R4 g .:SETWISEOK11\<^bsub>(C9,D)\<^esub> A9"
          using tarski_th_2 sorry
        have A56: " not c inTARSKIR2 ?B9"
          using zfmisc_1_th_56 sorry
        have "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
        proof-
          show "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
          proof-
            have cases: "A9 =XBOOLE-0R4 {}XBOOLE-0K1 or A9 <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            have case1: "A9 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
            proof(rule impI)
              assume A57: "A9 =XBOOLE-0R4 {}XBOOLE-0K1"
              have "?B9 c=TARSKIR1 C"
                using finsub_1_def_5 sorry
              then have "?B9 c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
                using funct_2_def_1 sorry
              then have A58: "?B9 =XBOOLE-0R4 {}XBOOLE-0K1"
                using A55 A57 sorry
              have "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c"
                using A1 A34 A57 setwiseo_th_17 sorry
              also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
                using A1 A35 A58 setwiseo_th_17 sorry
              finally show "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
                 sorry
            qed
            have case2: "A9 <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
            proof(rule impI)
              assume A59: "A9 <>HIDDENR2 {}XBOOLE-0K1"
              have "A9 c=TARSKIR1 C9"
                using finsub_1_def_5 sorry
              then have "A9 c=TARSKIR1 domRELSET-1K1\<^bsub>(C9)\<^esub> g"
                using funct_2_def_1 sorry
              then have A60: "?B9 <>HIDDENR2 {}XBOOLE-0K1"
                using A55 A59 sorry
              have "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9,g),g .FUNCT-2K3\<^bsub>(C9,D)\<^esub> a)"
                using A1 A4 A59 setwop_2_th_2 sorry
              also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\SETWISEOK9\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                using A3 A34 A11 A36 A21 A33 A37 A59 funct_1_th_2 sorry
              also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
                using A1 A35 A56 A60 setwop_2_th_2 sorry
              finally show "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A9 \\/SETWISEOK8\<^bsub>(C9)\<^esub> {.SETWISEOK5\<^bsub>(C9)\<^esub> a.},g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A61: "?X({}.SETWISEOK1 C9)"
    proof-
      have "{}.SETWISEOK1 C9 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies ( for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ( ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 {}.SETWISEOK1 C9 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> {}.SETWISEOK1 C9 =FUNCT-1R1 f *FUNCT-1K3 s) implies F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>({}.SETWISEOK1 C9,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
      proof(rule impI,rule ballI,rule impI)
        assume A62: "{}.SETWISEOK1 C9 <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        assume Given: " ex s be FunctionFUNCT-1M1 st ((domRELAT-1K1 s =XBOOLE-0R4 {}.SETWISEOK1 C9 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> {}.SETWISEOK1 C9 =FUNCT-1R1 f *FUNCT-1K3 s"
        then obtain s where
          [ty]:"s be FunctionFUNCT-1M1" and 
          A63: "(domRELAT-1K1 s =XBOOLE-0R4 {}.SETWISEOK1 C9 & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2"and "g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> {}.SETWISEOK1 C9 =FUNCT-1R1 f *FUNCT-1K3 s"
           sorry
        have "(B,{}XBOOLE-0K1)are-equipotentTARSKIR3"
          using A63 wellord2_def_4 sorry
        then have A64: "B =XBOOLE-0R4 {}.SETWISEOK1 C"
          using card_1_th_26 sorry
        have "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>({}.SETWISEOK1 C9,g) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          using A1 A62 setwiseo_th_31 sorry
        thus "F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>({}.SETWISEOK1 C9,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
          using A1 A62 A64 setwiseo_th_31 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be ElementSUBSET-1M1-of FinFINSUB-1K5 C9 holds ?X(A)"
      using setwiseo_sch_2 A61 A2 sorry
    thus " not (( not (A <>HIDDENR2 {}XBOOLE-0K1 &  not F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not ( for s be FunctionFUNCT-1M1 holds  not (((domRELAT-1K1 s =XBOOLE-0R4 A & rngFUNCT-1K2 s =XBOOLE-0R4 B) & s be one-to-oneFUNCT-1V2) & g  |PARTFUN1K2\<^bsub>(C9,D)\<^esub> A =FUNCT-1R1 f *FUNCT-1K3 s))) &  not F $$SETWISEOK10\<^bsub>(C9,D)\<^esub>(A,g) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_6:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds (H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>)) & f be one-to-oneFUNCT-1V2 implies H $$SETWISEOK10\<^bsub>(D,E)\<^esub>(f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B,h) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds (H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>)) & f be one-to-oneFUNCT-1V2 implies H $$SETWISEOK10\<^bsub>(D,E)\<^esub>(f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B,h) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    assume A1: "H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>)"
      and A2: "f be one-to-oneFUNCT-1V2"
    let ?s = "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B"
    have A3: "rngFUNCT-1K2 ?s =XBOOLE-0R4 f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B & (h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f) |PARTFUN1K2\<^bsub>(C,E)\<^esub> B =FUNCT-1R1 h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> ?s"
      using relat_1_th_83 relat_1_th_115 sorry
    have "B c=TARSKIR1 C"
      using finsub_1_def_5 sorry
    then have "B c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
      using funct_2_def_1 sorry
    then have A4: "domRELSET-1K1\<^bsub>(C)\<^esub> ?s =XBOOLE-0R4 B"
      using relat_1_th_62 sorry
    have "?s be one-to-oneFUNCT-1V2"
      using A2 funct_1_th_52 sorry
    thus "H $$SETWISEOK10\<^bsub>(D,E)\<^esub>(f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B,h) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      using A1 A4 A3 setwop_2_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_7:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)) & f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B =FUNCT-1R1 f9  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies (f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B =FUNCT-1R1 f9  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (B <>HIDDENR2 {}XBOOLE-0K1 or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>)"
    let ?s = "idPARTFUN1K6 B"
    have A2: "domRELSET-1K1\<^bsub>(B)\<^esub> ?s =XBOOLE-0R4 B & rngFUNCT-1K2 ?s =XBOOLE-0R4 B"
       sorry
    assume "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B =FUNCT-1R1 f9  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B"
    then have "f  |PARTFUN1K2\<^bsub>(C,D)\<^esub> B =FUNCT-1R1 f9 *PARTFUN1K1\<^bsub>(B,B,C,D)\<^esub> ?s"
      using relat_1_th_65 sorry
    thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)"
      using A1 A2 setwop_2_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_8:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B =XBOOLE-0R4 {TARSKIK1 e} implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 e"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) implies  not (f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B =XBOOLE-0R4 {TARSKIK1 e} &  not F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 e)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?X = "\<lambda>Lamb1. f .:SETWISEOK11\<^bsub>(C,D)\<^esub> Lamb1 =XBOOLE-0R4 {TARSKIK1 e} implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f) =XBOOLE-0R4 e"
    have A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
    proof-
      have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds (f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B9 =XBOOLE-0R4 {TARSKIK1 e} implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f) =XBOOLE-0R4 e) & ( not c inTARSKIR2 B9 & f .:FUNCT-1K5 (B9 \\/XBOOLE-0K2 {TARSKIK1 c}) =XBOOLE-0R4 {TARSKIK1 e}) implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 e"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
        fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A5: "f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B9 =XBOOLE-0R4 {TARSKIK1 e} implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f) =XBOOLE-0R4 e"
          and A6: " not c inTARSKIR2 B9"
          and A7: "f .:FUNCT-1K5 (B9 \\/XBOOLE-0K2 {TARSKIK1 c}) =XBOOLE-0R4 {TARSKIK1 e}"
        have A8: "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
        proof-
          show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          proof-
            have cases: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 or B9 <>HIDDENR2 {}XBOOLE-0K1"
               sorry
            have case1: "B9 =XBOOLE-0R4 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
            proof(rule impI)
              assume "B9 =XBOOLE-0R4 {}XBOOLE-0K1"
              then have A9: "B9 =XBOOLE-0R4 {}.SETWISEOK1 C"
                 sorry
              have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                using A1 A2 A6 setwop_2_th_2 sorry
              also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                using A1 A2 A3 A9 setwiseo_th_31 sorry
              finally show "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                 sorry
            qed
            have case2: "B9 <>HIDDENR2 {}XBOOLE-0K1 implies F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
            proof(rule impI)
              assume A10: "B9 <>HIDDENR2 {}XBOOLE-0K1"
              have "B9 c=TARSKIR1 C"
                using finsub_1_def_5 sorry
              then have A11: "B9 c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
                using funct_2_def_1 sorry
              have "f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B9 c=TARSKIR1 {TARSKIK1 e}"
                using A7 relat_1_th_123 xboole_1_th_7 sorry
              thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
                using A1 A5 A6 A10 A11 setwop_2_th_2 zfmisc_1_th_33 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have "{.SETWISEOK5\<^bsub>(C)\<^esub> c.} c=TARSKIR1 C"
          using finsub_1_def_5 sorry
        then have A12: "{TARSKIK1 c} c=TARSKIR1 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using funct_2_def_1 sorry
        then have A13: "c inTARSKIR2 domRELSET-1K1\<^bsub>(C)\<^esub> f"
          using zfmisc_1_th_31 sorry
        have "ImRELAT-1K12(f,c) c=TARSKIR1 {TARSKIK1 e}"
          using A7 relat_1_th_123 xboole_1_th_7 sorry
        then have "ImRELAT-1K12(f,c) =XBOOLE-0R4 {TARSKIK1 e}"
          using A12 zfmisc_1_th_33 sorry
        then have "{TARSKIK1 e} =XBOOLE-0R4 {TARSKIK1 f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c }"
          using A13 funct_1_th_59 sorry
        then have "f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c =XBOOLE-0R4 e"
          using zfmisc_1_th_3 sorry
        thus "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 e"
          using A2 A3 A8 setwiseo_th_15 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A14: "?X({}.SETWISEOK1 C)"
       sorry
    have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B)"
      using setwiseo_sch_2 A14 A4 sorry
    thus " not (f .:SETWISEOK11\<^bsub>(C,D)\<^esub> B =XBOOLE-0R4 {TARSKIK1 e} &  not F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f) =XBOOLE-0R4 e)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_9:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & (G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))))) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A3: "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e"
      and A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
    let ?X = "\<lambda>Lamb1. G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
    have A5: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
    proof-
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)) &  not c inTARSKIR2 B implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f9)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A6: "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
          and A7: " not c inTARSKIR2 B"
        let ?s9 = "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)"
        let ?s = "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)"
        have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?s,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c) & F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f9) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?s9,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using A1 A7 setwop_2_th_2 sorry
        then have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f9)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)),G .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,f9 .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
          using A4 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)),(G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using funcop_1_th_37 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
          using A1 A6 A7 setwop_2_th_2 sorry
        finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f9)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f) =XBOOLE-0R4 e & F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f9) =XBOOLE-0R4 e"
      using A1 A2 setwiseo_th_31 sorry
    then have A8: "?X({}.SETWISEOK1 C)"
      using A1 A2 A3 setwiseo_th_31 sorry
    have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B)"
      using setwiseo_sch_2 A8 A5 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma setwop_2_lm_3:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> implies ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
      and A2: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix d3 assume [ty]: "d3 be ElementSUBSET-1M1-of D"
    fix d4 assume [ty]: "d4 be ElementSUBSET-1M1-of D"
    have "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d3),d4))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d2),d4))"
      using A1 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using A2 sorry
    also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
      using A2 sorry
    finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_10:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e) =XBOOLE-0R4 ?e & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using setwop_2_lm_3 setwiseo_th_15 sorry
    thus "F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,F .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
      using A1 setwop_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_11:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for f9 be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix f9 assume [ty]: "f9 be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e) =XBOOLE-0R4 ?e & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using A1 A2 finseqop_th_86 finseqop_th_89 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f9)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G .:FUNCOP-1K6\<^bsub>(D,C)\<^esub>(f,f9))"
      using A1 setwop_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_12:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies (G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?X = "\<lambda>Lamb1. G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
    have A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
    proof-
      have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f)) &  not c inTARSKIR2 B9 implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A5: "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
          and A6: " not c inTARSKIR2 B9"
        have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
          using A1 A6 setwop_2_th_2 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f)),G .BINOP-1K4\<^bsub>(D)\<^esub>(d,f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
          using A3 binop_1_th_11 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f)),(G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using A5 funcop_1_th_53 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
          using A1 A6 setwop_2_th_2 sorry
        finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e"
    then have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f)) =HIDDENR1 e"
      using A1 A2 setwiseo_th_31 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
      using A1 A2 setwiseo_th_31 sorry
    finally have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f)) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
       sorry
    then have A7: "?X({}.SETWISEOK1 C)"
       sorry
    have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B)"
      using setwiseo_sch_2 A7 A4 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_13:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies (G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?X = "\<lambda>Lamb1. G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
    have A4: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
    proof-
      have " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d)) &  not c inTARSKIR2 B9 implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),d) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B9 assume [ty]: "B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A5: "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
          and A6: " not c inTARSKIR2 B9"
        have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),d) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c),d)"
          using A1 A6 setwop_2_th_2 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,f),d),G .BINOP-1K4\<^bsub>(D)\<^esub>(f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c,d))"
          using A3 binop_1_th_11 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d)),(G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d)).FUNCT-2K3\<^bsub>(C,D)\<^esub> c)"
          using A5 funcop_1_th_48 sorry
        also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
          using A1 A6 setwop_2_th_2 sorry
        finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f),d) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e"
    then have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f),d) =HIDDENR1 e"
      using A1 A2 setwiseo_th_31 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
      using A1 A2 setwiseo_th_31 sorry
    finally have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f),d) =HIDDENR1 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
       sorry
    then have A7: "?X({}.SETWISEOK1 C)"
       sorry
    have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B)"
      using setwiseo_sch_2 A7 A4 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_14:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e) =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_66 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,C)\<^esub>(d,f))"
      using A1 A3 setwop_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_15:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d) =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_66 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),d) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [:]FUNCOP-1K9\<^bsub>(D,C)\<^esub>(f,d))"
      using A1 A3 setwop_2_th_13 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_16:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub>) & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>) & h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & ((H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>) & (h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)))) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "H be commutativeBINOP-1V1\<^bsub>(E)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(E)\<^esub> & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>"
      and A3: "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H"
      and A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    let ?X = "\<lambda>Lamb1. h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(Lamb1,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(Lamb1,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
    have A5: " for B9 be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for b be ElementSUBSET-1M1-of C holds ?X(B9) &  not b inTARSKIR2 B9 implies ?X(B9 \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> b.})"
    proof-
      have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for c be ElementSUBSET-1M1-of C holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f) &  not c inTARSKIR2 B implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of C"
        assume A6: "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
          and A7: " not c inTARSKIR2 B"
        have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f),f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
          using A1 A7 setwop_2_th_2 sorry
        also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>(H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f),h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (f .FUNCT-2K3\<^bsub>(C,D)\<^esub> c))"
          using A4 A6 sorry
        also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>(H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f),(h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f).FUNCT-2K3\<^bsub>(C,E)\<^esub> c)"
          using funct_2_th_15 sorry
        also have "... = H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
          using A2 A7 setwop_2_th_2 sorry
        finally show "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},f)) =HIDDENR1 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B \\/SETWISEOK8\<^bsub>(C)\<^esub> {.SETWISEOK5\<^bsub>(C)\<^esub> c.},h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f)) =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H"
      using A1 A3 setwiseo_th_31 sorry
    also have "... = H $$SETWISEOK10\<^bsub>(C,E)\<^esub>({}.SETWISEOK1 C,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
      using A2 setwiseo_th_31 sorry
    finally have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>({}.SETWISEOK1 C,f)) =HIDDENR1 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>({}.SETWISEOK1 C,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
       sorry
    then have A8: "?X({}.SETWISEOK1 C)"
       sorry
    have " for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds ?X(B)"
      using setwiseo_sch_2 A8 A5 sorry
    thus "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 H $$SETWISEOK10\<^bsub>(C,E)\<^esub>(B,h *PARTFUN1K1\<^bsub>(C,D,D,E)\<^esub> f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_17:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,u *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
  using setwop_2_th_16 sorry

mtheorem setwop_2_th_18:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)"
    have "?u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A3 finseqop_th_54 sorry
    then have A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds ?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
       sorry
    have "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_69 sorry
    thus "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
      using A1 A4 setwop_2_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_19:
" for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
proof-
  have " for C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for B be ElementSUBSET-1M1-of FinFINSUB-1K5 C holds  for F be BinOpBINOP-1M2-of D holds  for f be FunctionFUNCT-2M1-of(C,D) holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix C assume [ty]: "C be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix B assume [ty]: "B be ElementSUBSET-1M1-of FinFINSUB-1K5 C"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(C,D)"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have "?u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A1 A2 finseqop_th_63 sorry
    then have A3: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds ?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
       sorry
    have "?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e =XBOOLE-0R4 ?e"
      using A1 A2 finseqop_th_61 sorry
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,f)) =XBOOLE-0R4 F $$SETWISEOK10\<^bsub>(C,D)\<^esub>(B,(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*PARTFUN1K1\<^bsub>(C,D,D,D)\<^esub> f)"
      using A1 A3 setwop_2_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef setwop_2_def_1 ("[#]SETWOP-2K1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "d be ElementSUBSET-1M1-of D"
"func [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) \<rightarrow> sequenceNAT-1M2-of D equals
  (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> d)+*FINSOP-1K2\<^bsub>(D)\<^esub> p"
proof-
  (*coherence*)
    show "(NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> d)+*FINSOP-1K2\<^bsub>(D)\<^esub> p be sequenceNAT-1M2-of D"
       sorry
qed "sorry"

mtheorem setwop_2_th_20:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of D holds (i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i) & ( not i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for i be NatNAT-1M1 holds  for p be FinSequenceFINSEQ-1M3-of D holds (i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i) & ( not i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =HIDDENR1 d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    show "i inTARSKIR2 domFINSEQ-1K5 p implies [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =XBOOLE-0R4 p .FUNCT-1K1 i"
      using funct_4_th_13 sorry
    have A1: "i inTARSKIR2 NATNUMBERSK1"
      using ordinal1_def_12 sorry
    assume " not i inTARSKIR2 domFINSEQ-1K5 p"
    then have "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =HIDDENR1 (NATNUMBERSK1 -->FUNCOP-1K8\<^bsub>(D)\<^esub> d).FUNCT-1K1 i"
      using funct_4_th_11 sorry
    also have "... = d"
      using A1 funcop_1_th_7 sorry
    finally show "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i =HIDDENR1 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_21:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    let ?k = "lenFINSEQ-1K4 p"
    let ?f = "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)"
    have "SegFINSEQ-1K2 ?k c=TARSKIR1 NATNUMBERSK1"
       sorry
    then have "SegFINSEQ-1K2 ?k c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f"
      using funct_2_def_1 sorry
    then have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 ?k) =XBOOLE-0R4 SegFINSEQ-1K2 ?k"
      using relat_1_th_62 sorry
    have A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 ?k"
      using finseq_1_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 SegFINSEQ-1K2 ?k"
      then have "(?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 ?k).FUNCT-1K1 x =XBOOLE-0R4 ?f .FUNCT-1K1 x"
        using A1 funct_1_th_47 sorry
      thus "([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)).FUNCT-1K1 x =XBOOLE-0R4 p .FUNCT-1K1 x"
        using A2 A3 setwop_2_th_20 sorry
    qed "sorry"
    thus "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
      using A1 A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    let ?k = "lenFINSEQ-1K4 p"
    let ?f = "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)"
    have "SegFINSEQ-1K2 ?k c=TARSKIR1 NATNUMBERSK1"
       sorry
    then have "SegFINSEQ-1K2 ?k c=TARSKIR1 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ?f"
      using funct_2_def_1 sorry
    then have A1: "domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> (?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 ?k) =XBOOLE-0R4 SegFINSEQ-1K2 ?k"
      using relat_1_th_62 sorry
    have A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 ?k"
      using finseq_1_def_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 p) implies ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)).FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "?k <=XXREAL-0R1 ?k +NAT-1K1 lenFINSEQ-1K4 q"
        using nat_1_th_12 sorry
      then have "?k <=XXREAL-0R1 lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q)"
        using finseq_1_th_22 sorry
      then have A3: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q)) =XBOOLE-0R4 domFINSEQ-1K5 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q) & SegFINSEQ-1K2 ?k c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q))"
        using finseq_1_th_5 finseq_1_def_3 sorry
      assume A4: "x inHIDDENR3 SegFINSEQ-1K2 ?k"
      then have "(?f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 ?k).FUNCT-1K1 x =XBOOLE-0R4 ?f .FUNCT-1K1 x"
        using A1 funct_1_th_47 sorry
      then have "([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)).FUNCT-1K1 x =HIDDENR1 (p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q).FUNCT-1K1 x"
        using A4 A3 setwop_2_th_20 sorry
      also have "... = p .FUNCT-1K1 x"
        using A2 A4 finseq_1_def_7 sorry
      finally show "([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (lenFINSEQ-1K4 p)).FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x"
         sorry
    qed "sorry"
    thus "[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p ^FINSEQ-1K9\<^bsub>(D)\<^esub> q,d)  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> domFINSEQ-1K5 p =FUNCT-1R1 p"
      using A1 A2 funct_1_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_23:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) implies y inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}) & (y inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d} implies y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)))"
    proof(rule ballI,rule conjMI,rule impI)
      fix y assume [ty]: "y be objectHIDDENM1"
      show "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) implies y inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
      proof(rule impI)
        assume "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
        then obtain x where
          [ty]:"x be objectHIDDENM1" and 
          A1: "x inHIDDENR3 domRELSET-1K1\<^bsub>(NATNUMBERSK1)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"and A2: "y =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 x"
          using funct_1_def_3 sorry
        obtain i where 
          [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and iDef:"i = x"
          using A1 sorry
        have "i inTARSKIR2 domFINSEQ-1K5 p & y inHIDDENR3 rngFUNCT-1K2 p or  not i inTARSKIR2 domFINSEQ-1K5 p & ( not i inTARSKIR2 domFINSEQ-1K5 p implies y inHIDDENR3 {TARSKIK1 d})"
        proof-
          show "i inTARSKIR2 domFINSEQ-1K5 p & y inHIDDENR3 rngFUNCT-1K2 p or  not i inTARSKIR2 domFINSEQ-1K5 p & ( not i inTARSKIR2 domFINSEQ-1K5 p implies y inHIDDENR3 {TARSKIK1 d})"
          proof-
            have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
               sorry
            have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies y inHIDDENR3 rngFUNCT-1K2 p"
            proof(rule impI)
              assume A3: "i inTARSKIR2 domFINSEQ-1K5 p"
              then have "y =HIDDENR1 p .FUNCT-1K1 i"
                using A2 setwop_2_th_20 sorry
              thus "y inHIDDENR3 rngFUNCT-1K2 p"
                using A3 funct_1_def_3 sorry
            qed
            have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies y inHIDDENR3 {TARSKIK1 d}"
            proof(rule impI)
              assume " not i inTARSKIR2 domFINSEQ-1K5 p"
              then have "y =HIDDENR1 d"
                using A2 setwop_2_th_20 sorry
              thus "y inHIDDENR3 {TARSKIK1 d}"
                using tarski_def_1 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "y inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
          using xboole_0_def_3 sorry
      qed
      assume A4: "y inHIDDENR3 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
      have "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
      proof-
        show "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
        proof-
          have cases: "y inHIDDENR3 rngFUNCT-1K2 p or y inHIDDENR3 {TARSKIK1 d}"
            using A4 xboole_0_def_3 sorry
          have case1: "y inHIDDENR3 rngFUNCT-1K2 p implies y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
          proof(rule impI)
            assume "y inHIDDENR3 rngFUNCT-1K2 p"
            then obtain i where
              [ty]:"i be NatNAT-1M1" and 
              A5: "i inTARSKIR2 domFINSEQ-1K5 p"and A6: "y =HIDDENR1 p .FUNCT-1K1 i"
              using finseq_2_th_10 sorry
            have "y =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-1K1 i"
              using A5 A6 setwop_2_th_20 sorry
            thus "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
              using A5 funct_2_th_4 sorry
          qed
          have case2: "y inHIDDENR3 {TARSKIK1 d} implies y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
          proof(rule impI)
            assume A7: "y inHIDDENR3 {TARSKIK1 d}"
            have "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
              using finseq_1_def_3 sorry
            then have A8: " not lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
              using setwop_2_lm_2 sorry
            have "y =HIDDENR1 d"
              using A7 tarski_def_1 sorry
            then have "y =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> (lenFINSEQ-1K4 p +NAT-1K1 \<one>\<^sub>M)"
              using A8 setwop_2_th_20 sorry
            thus "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
              using funct_2_th_4 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "y inHIDDENR3 rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d))"
         sorry
    qed "sorry"
    thus "rngFUNCT-1K2 ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)) =XBOOLE-0R4 rngFUNCT-1K2 p \\/XBOOLE-0K2 {TARSKIK1 d}"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,E)\<^esub> [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,E)\<^esub> [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A1: "domFINSEQ-1K5 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p))"
        using finseq_1_def_3 sorry
      have A2: "lenFINSEQ-1K4 (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p) =XBOOLE-0R4 lenFINSEQ-1K4 p & SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
        using finseq_1_def_3 finseq_2_th_33 sorry
      have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
      proof-
        show "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
          proof(rule impI)
            assume A3: "i inTARSKIR2 domFINSEQ-1K5 p"
            then have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 h .FUNCT-1K1 (p .FUNCT-1K1 i)"
              using setwop_2_th_20 sorry
            also have "... = (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p).FUNCT-1K1 i"
              using A3 funct_1_th_13 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
              using A2 A1 A3 setwop_2_th_20 sorry
            finally show "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
               sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
          proof(rule impI)
            assume A4: " not i inTARSKIR2 domFINSEQ-1K5 p"
            then have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d"
              using setwop_2_th_20 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
              using A2 A1 A4 setwop_2_th_20 sorry
            finally show "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> ([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,E)\<^esub> i"
        using funct_2_th_15 sorry
    qed "sorry"
    thus "h *PARTFUN1K1\<^bsub>(NATNUMBERSK1,D,D,E)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,E)\<^esub> [#]SETWOP-2K1\<^bsub>(E)\<^esub>(h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma setwop_2_lm_4:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e implies F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q & F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e implies F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    assume A1: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
      and A2: "F .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e"
    let ?r = "F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
    have A3: "lenFINSEQ-1K4 ?r =XBOOLE-0R4 lenFINSEQ-1K4 p"
      using A1 finseq_2_th_72 sorry
    have A4: "domFINSEQ-1K5 ?r =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?r)"
      using finseq_1_def_3 sorry
    have A5: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have A6: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
      proof-
        show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A7: "i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 F .BINOP-1K1(p .FUNCT-1K1 i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i)"
              using setwop_2_th_20 sorry
            also have "... = F .BINOP-1K1(p .FUNCT-1K1 i,q .FUNCT-1K1 i)"
              using A1 A5 A6 A7 setwop_2_th_20 sorry
            also have "... = (F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)).FUNCT-1K1 i"
              using A3 A5 A4 A7 funcop_1_th_22 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A3 A5 A4 A7 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A8: " not i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i)"
              using setwop_2_th_20 sorry
            also have "... = e"
              using A1 A2 A5 A6 A8 setwop_2_th_20 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A3 A5 A4 A8 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        using funcop_1_th_37 sorry
    qed "sorry"
    thus "F .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma setwop_2_lm_5:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e"
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using finseq_1_def_3 sorry
      have A3: "lenFINSEQ-1K4 (F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)) =XBOOLE-0R4 lenFINSEQ-1K4 p & domFINSEQ-1K5 (F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)))"
        using finseq_1_def_3 finseq_2_th_84 sorry
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
      proof-
        show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A4: "i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 F .BINOP-1K1(p .FUNCT-1K1 i,d)"
              using setwop_2_th_20 sorry
            also have "... = (F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)).FUNCT-1K1 i"
              using A3 A2 A4 funcop_1_th_27 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A3 A2 A4 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A5: " not i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(e,d)"
              using setwop_2_th_20 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A1 A3 A2 A5 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i,d) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d)).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        using funcop_1_th_48 sorry
    qed "sorry"
    thus "F [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma setwop_2_lm_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e"
    have " for i be ElementSUBSET-1M1-of NATNUMBERSK1 holds (F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
    proof(rule ballI)
      fix i assume [ty]: "i be ElementSUBSET-1M1-of NATNUMBERSK1"
      have A2: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
        using finseq_1_def_3 sorry
      have A3: "lenFINSEQ-1K4 (F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)) =XBOOLE-0R4 lenFINSEQ-1K4 p & domFINSEQ-1K5 (F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)))"
        using finseq_1_def_3 finseq_2_th_78 sorry
      have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
      proof-
        show "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        proof-
          have cases: "i inTARSKIR2 domFINSEQ-1K5 p or  not i inTARSKIR2 domFINSEQ-1K5 p"
             sorry
          have case1: "i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A4: "i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 F .BINOP-1K1(d,p .FUNCT-1K1 i)"
              using setwop_2_th_20 sorry
            also have "... = (F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)).FUNCT-1K1 i"
              using A3 A2 A4 funcop_1_th_32 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A3 A2 A4 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          have case2: " not i inTARSKIR2 domFINSEQ-1K5 p implies F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
          proof(rule impI)
            assume A5: " not i inTARSKIR2 domFINSEQ-1K5 p"
            then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 F .BINOP-1K4\<^bsub>(D)\<^esub>(d,e)"
              using setwop_2_th_20 sorry
            also have "... = [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
              using A1 A3 A2 A5 setwop_2_th_20 sorry
            finally show "F .BINOP-1K4\<^bsub>(D)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i) =HIDDENR1 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "(F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e))).FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i =XBOOLE-0R4 [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e) .FUNCT-2K3\<^bsub>(NATNUMBERSK1,D)\<^esub> i"
        using funcop_1_th_53 sorry
    qed "sorry"
    thus "F [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)) =FUNCT-2R2\<^bsub>(NATNUMBERSK1,D)\<^esub> [#]SETWOP-2K1\<^bsub>(D)\<^esub>(F [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e)"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) SETWOP_2K2("finSegSETWOP-2K2  _ " [164]164) where
  "finSegSETWOP-2K2 i \<equiv> SegFINSEQ-1K1 i"

abbreviation(input) SETWOP_2K3("finSegSETWOP-2K3  _ " [164]164) where
  "finSegSETWOP-2K3 i \<equiv> SegFINSEQ-1K1 i"

mtheorem setwop_2_add_1:
  mlet "i be NatNAT-1M1"
"cluster SegFINSEQ-1K1 i as-term-is ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
proof
(*coherence*)
  show "SegFINSEQ-1K1 i be ElementSUBSET-1M1-of FinFINSUB-1K5 NATNUMBERSK1"
    using setwop_2_lm_1 sorry
qed "sorry"

abbreviation(input) SETWOP_2K4(" _ $$SETWOP-2K4\<^bsub>'( _ ')\<^esub>  _ " [180,0,180]180) where
  "F $$SETWOP-2K4\<^bsub>(D)\<^esub> p \<equiv> F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p"

abbreviation(input) SETWOP_2K5(" _ $$SETWOP-2K5\<^bsub>'( _ ')\<^esub>  _ " [180,0,180]180) where
  "F $$SETWOP-2K5\<^bsub>(D)\<^esub> p \<equiv> F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p"

mtheorem setwop_2_def_2:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FinSequenceFINSEQ-1M3-of D", "F be BinOpBINOP-1M2-of D"
"assume (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> redefine func F $$SETWOP-2K5\<^bsub>(D)\<^esub> p \<rightarrow> ElementSUBSET-1M1-of D equals
  F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F))"
proof
(*compatibility*)
  show "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub> implies ( for it be ElementSUBSET-1M1-of D holds it =HIDDENR1 F $$SETWOP-2K5\<^bsub>(D)\<^esub> p iff it =HIDDENR1 F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)))"
  proof(rule impI)
    assume Assume: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
    have A1: "(F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> or lenFINSEQ-1K4 p >=XXREAL-0R2 \<one>\<^sub>M) & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>(D)\<^esub>"
      using Assume sorry
    show " for it be ElementSUBSET-1M1-of D holds it =HIDDENR1 F $$SETWOP-2K5\<^bsub>(D)\<^esub> p iff it =HIDDENR1 F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F))"
      using A1 finsop_1_th_3 sorry
  qed
qed "sorry"

mtheorem setwop_2_th_25:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?X = "\<lambda>Lamb1. F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> Lamb1  |->FINSEQ-2K5\<^bsub>(D)\<^esub> ?e =XBOOLE-0R4 ?e"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    have A2: " for i be NatNAT-1M1 holds ?X(i) implies ?X(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be NatNAT-1M1 holds F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      proof(rule ballI,rule impI)
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A3: "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> ?e =XBOOLE-0R4 ?e"
        have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F*>)"
          using finseq_2_th_60 sorry
        also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F,the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F)"
          using A1 finsop_1_th_4 sorry
        also have "... = the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          using A1 A3 setwiseo_th_15 sorry
        finally show "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =HIDDENR1 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (0NUMBERSK6) |->FINSEQ-2K5\<^bsub>(D)\<^esub> ?e =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D"
       sorry
    also have "... = ?e"
      using A1 finsop_1_th_10 sorry
    finally have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (0NUMBERSK6) |->FINSEQ-2K5\<^bsub>(D)\<^esub> ?e =HIDDENR1 ?e"
       sorry
    then have A4: "?X(0NUMBERSK6)"
       sorry
    have " for i be NatNAT-1M1 holds ?X(i)"
      using nat_1_sch_2 A4 A2 sorry
    thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_26:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> implies (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
    let ?p1 = "i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d"
    let ?p2 = "j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d"
    assume "i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    then have "lenFINSEQ-1K4 ?p1 >=XXREAL-0R2 \<one>\<^sub>M & lenFINSEQ-1K4 ?p2 >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      using card_1_def_7 sorry
    then have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> ?p1 ^FINSEQ-1K9\<^bsub>(D)\<^esub> ?p2 =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> ?p1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> ?p2)"
      using A1 finsop_1_th_5 sorry
    thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i +XCMPLX-0K2 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
      using finseq_2_th_123 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_27:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "i >=XXREAL-0R2 \<one>\<^sub>M & j >=XXREAL-0R2 \<one>\<^sub>M or F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    show "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
    proof-
      have cases: "(i =XBOOLE-0R4 0NUMBERSK6 or j =XBOOLE-0R4 0NUMBERSK6) or i >XXREAL-0R4 0NUMBERSK6 & j >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "i =XBOOLE-0R4 0NUMBERSK6 or j =XBOOLE-0R4 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
      proof(rule impI)
        assume A3: "i =XBOOLE-0R4 0NUMBERSK6 or j =XBOOLE-0R4 0NUMBERSK6"
        let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
        have A4: "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
        proof-
          show "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
          proof-
            have cases: "i =XBOOLE-0R4 0NUMBERSK6 or j =XBOOLE-0R4 0NUMBERSK6"
              using A3 sorry
            have case1: "i =XBOOLE-0R4 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
            proof(rule impI)
              assume "i =XBOOLE-0R4 0NUMBERSK6"
              then have "i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =FINSEQ-1R1 <*>FINSEQ-1K7 D"
                 sorry
              then have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 ?e"
                using A2 A3 finsop_1_th_10 sorry
              thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
                using A2 A3 setwop_2_th_25 sorry
            qed
            have case2: "j =XBOOLE-0R4 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
            proof(rule impI)
              assume "j =XBOOLE-0R4 0NUMBERSK6"
              then have "j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =FINSEQ-1R1 <*>FINSEQ-1K7 D"
                 sorry
              thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
                using A2 A3 finsop_1_th_10 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have "(i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =FINSEQ-1R1 <*>FINSEQ-1K7 D"
          using A3 sorry
        thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
          using A2 A3 A4 finsop_1_th_10 sorry
      qed
      have case2: "i >XXREAL-0R4 0NUMBERSK6 & j >XXREAL-0R4 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
      proof(rule impI)
        assume A5: "i >XXREAL-0R4 0NUMBERSK6 & j >XXREAL-0R4 0NUMBERSK6"
        let ?X = "\<lambda>Lamb1. Lamb1 <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 Lamb1) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> Lamb1  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
        have A6: " for j be NatNAT-1M1 holds ?X(j) implies ?X(j +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have " for j be NatNAT-1M1 holds (j <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)) implies (j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d))"
          proof(rule ballI,rule impI)
            fix j assume [ty]: "j be NatNAT-1M1"
            assume A7: "j <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
            have "j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
            proof-
              show "j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
              proof-
                have cases: "j =XBOOLE-0R4 0NUMBERSK6 or j >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                  using nat_1_th_14 sorry
                have case1: "j =XBOOLE-0R4 0NUMBERSK6 implies (j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d))"
                proof(rule impI)
                  assume A8: "j =XBOOLE-0R4 0NUMBERSK6"
                  have "\<one>\<^sub>M  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d) =FINSEQ-1R1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d *>"
                    using finseq_2_th_59 sorry
                  thus "j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
                    using A8 finsop_1_th_11 sorry
                qed
                have case2: "j >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6 implies (j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d))"
                proof(rule impI)
                  assume A9: "j >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                  then have "j >XXREAL-0R4 0NUMBERSK6"
                     sorry
                  then have "i *XCMPLX-0K3 j >XXREAL-0R4 i *XCMPLX-0K3 (0NUMBERSK6)"
                    using A5 xreal_1_th_68 sorry
                  then have A10: "i *XCMPLX-0K3 j >=XXREAL-0R2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                    using nat_1_th_13 sorry
                  have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j +XCMPLX-0K2 i *XCMPLX-0K3 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d"
                     sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
                    using A1 A2 A10 setwop_2_th_26 sorry
                  also have "... = F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> \<one>\<^sub>M  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d))"
                    using finsop_1_th_16 sorry
                  also have "... = F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
                    using A1 A7 A9 setwop_2_th_26 sorry
                  finally have "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
                     sorry
                  thus "j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "j +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 (j +NAT-1K1 \<one>\<^sub>M)) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A11: "?X(0NUMBERSK6)"
           sorry
        have " for j be NatNAT-1M1 holds ?X(j)"
          using nat_1_sch_2 A11 A6 sorry
        thus "F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (i *XCMPLX-0K3 j) |->FINSEQ-2K5\<^bsub>(D)\<^esub> d =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> j  |->FINSEQ-2K5\<^bsub>(D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d)"
          using A5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_28:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>) & h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for H be BinOpBINOP-1M2-of E holds  for h be FunctionFUNCT-2M1-of(D,E) holds  for p be FinSequenceFINSEQ-1M3-of D holds F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub> & (h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)))) implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix H assume [ty]: "H be BinOpBINOP-1M2-of E"
    fix h assume [ty]: "h be FunctionFUNCT-2M1-of(D,E)"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "H be having-a-unitySETWISEOV1\<^bsub>(E)\<^esub>"
      and A3: "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(E)\<^esub> H"
      and A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 H .BINOP-1K4\<^bsub>(E)\<^esub>(h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d1,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d2)"
    let ?X = "\<lambda>Lamb1. h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> Lamb1) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> Lamb1"
    have A5: " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds ?X(q) implies ?X(q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
    proof-
      have " for q be FinSequenceFINSEQ-1M3-of D holds  for d be ElementSUBSET-1M1-of D holds h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q implies h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =HIDDENR1 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
      proof(rule ballI,rule ballI,rule impI)
        fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
        fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
        assume A6: "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q"
        have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q,d))"
          using A1 finsop_1_th_4 sorry
        also have "... = H .BINOP-1K4\<^bsub>(E)\<^esub>(H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q,h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d)"
          using A4 A6 sorry
        also have "... = H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> (h *FINSEQOPK4\<^bsub>(D,E)\<^esub> q)^FINSEQ-1K9\<^bsub>(E)\<^esub> (<*FINSEQ-1K13\<^bsub>(E)\<^esub> h .FUNCT-2K3\<^bsub>(D,E)\<^esub> d*>)"
          using A2 finsop_1_th_4 sorry
        also have "... = H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
          using finseqop_th_8 sorry
        finally show "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)) =HIDDENR1 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> (q ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D) =HIDDENR1 h .FUNCT-2K3\<^bsub>(D,E)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      using A1 finsop_1_th_10 sorry
    also have "... = H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> <*>FINSEQ-1K7 E"
      using A2 A3 finsop_1_th_10 sorry
    also have "... = H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> <*>FINSEQ-1K7 D"
       sorry
    finally have "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D) =HIDDENR1 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> <*>FINSEQ-1K7 D"
       sorry
    then have A7: "?X(<*>FINSEQ-1K7 D)"
       sorry
    have " for q be FinSequenceFINSEQ-1M3-of D holds ?X(q)"
      using finseq_2_sch_2 A7 A5 sorry
    thus "h .FUNCT-2K3\<^bsub>(D,E)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 H \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(E)\<^esub> h *FINSEQOPK4\<^bsub>(D,E)\<^esub> p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for u be UnOpBINOP-1M1-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & u .FUNCT-2K3\<^bsub>(D,D)\<^esub> the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F implies u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> u *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
  using setwop_2_th_28 sorry

mtheorem setwop_2_th_30:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F be associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F)) implies (G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F be associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A4: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)"
    have "?u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A4 finseqop_th_54 sorry
    then have A5: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds ?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
       sorry
    have "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e =XBOOLE-0R4 ?e"
      using A1 A2 A3 A4 finseqop_th_69 sorry
    thus "(G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D)).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FUNCOP-1K10\<^bsub>(D,D)\<^esub>(d,idPARTFUN1K6 D) *FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
      using A2 A5 setwop_2_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_31:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & (F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) implies (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub>"
      and A2: "F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A3: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    let ?u = "the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F"
    have "?u is-distributive-wrtBINOP-1R12\<^bsub>(D)\<^esub> F"
      using A1 A2 A3 finseqop_th_63 sorry
    then have A4: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds ?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> (F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d1,?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> d2)"
       sorry
    have "?u .FUNCT-2K3\<^bsub>(D,D)\<^esub> ?e =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_61 sorry
    thus "(the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F).FUNCT-2K3\<^bsub>(D,D)\<^esub> (F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> (the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)*FINSEQOPK4\<^bsub>(D,D)\<^esub> p"
      using A2 A4 setwop_2_th_28 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_32:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds ((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))) & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & (G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e & (( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))) & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q)) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    assume A1: "((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A2: "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e"
      and A3: " for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))"
      and A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q"
    have A5: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q))"
      using A4 finseq_2_th_72 sorry
    have A6: "domFINSEQ-1K5 (G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)) =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 (G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)))"
      using finseq_1_def_3 sorry
    have A7: "domFINSEQ-1K5 q =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 q)"
      using finseq_1_def_3 sorry
    have A8: "domFINSEQ-1K5 p =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 p)"
      using finseq_1_def_3 sorry
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)),F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q)"
      using A1 setwop_2_def_2 sorry
    also have "... = G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)),F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 q,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)))"
      using A1 setwop_2_def_2 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,G .:FUNCOP-1K6\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(q,e)))"
      using A1 A2 A3 A4 A8 A7 setwop_2_th_9 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),[#]SETWOP-2K1\<^bsub>(D)\<^esub>(G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q),e))"
      using A2 A4 A5 A8 A6 setwop_2_lm_4 sorry
    also have "... = F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
      using A1 setwop_2_def_2 sorry
    finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_33:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4))) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  not ((((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))) &  not G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix T1 assume [ty]: "T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    fix T2 assume [ty]: "T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    have "lenFINSEQ-1K4 T1 =XBOOLE-0R4 i & lenFINSEQ-1K4 T2 =XBOOLE-0R4 i"
      using card_1_def_7 sorry
    thus " not ((((((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,e) =XBOOLE-0R4 e) & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))) &  not G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2))"
      using setwop_2_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_34:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds  for q be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies  not (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q &  not F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    fix q assume [ty]: "q be FinSequenceFINSEQ-1M3-of D"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
    then have "F .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e) =XBOOLE-0R4 ?e & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),F .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using setwop_2_lm_3 setwiseo_th_15 sorry
    thus " not (lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 q &  not F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> q) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(p,q))"
      using A1 setwop_2_th_32 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  not (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix T1 assume [ty]: "T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    fix T2 assume [ty]: "T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    have "lenFINSEQ-1K4 T1 =XBOOLE-0R4 i & lenFINSEQ-1K4 T2 =XBOOLE-0R4 i"
      using card_1_def_7 sorry
    thus " not (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2))"
      using setwop_2_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_36:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub> implies F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  not (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d2))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of D"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    obtain T1 T2 where 
      [ty]:"T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D" and T1Def:"T1 = i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d1" and
      [ty]:"T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D" and T2Def:"T2 = i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d2"
       sorry
    have "i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =FINSEQ-1R1 F .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
      using finseqop_th_17 sorry
    thus " not (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) &  not F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2) =XBOOLE-0R4 F .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> i  |->FINSEQ-2K5\<^bsub>(D)\<^esub> d2))"
      using setwop_2_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_37:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for i be NatNAT-1M1 holds  for T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds  for T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    fix T1 assume [ty]: "T1 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    fix T2 assume [ty]: "T2 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of i -tuples-onFINSEQ-2K4 D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G =BINOP-1R13\<^bsub>(D,D,D)\<^esub> F *FINSEQOPK7\<^bsub>(D)\<^esub>(idPARTFUN1K6 D,the-inverseOp-wrtFINSEQOPK5\<^bsub>(D)\<^esub> F)"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,?e) =XBOOLE-0R4 ?e & ( for d1 be ElementSUBSET-1M1-of D holds  for d2 be ElementSUBSET-1M1-of D holds  for d3 be ElementSUBSET-1M1-of D holds  for d4 be ElementSUBSET-1M1-of D holds F .BINOP-1K4\<^bsub>(D)\<^esub>(G .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d2),G .BINOP-1K4\<^bsub>(D)\<^esub>(d3,d4)) =XBOOLE-0R4 G .BINOP-1K4\<^bsub>(D)\<^esub>(F .BINOP-1K4\<^bsub>(D)\<^esub>(d1,d3),F .BINOP-1K4\<^bsub>(D)\<^esub>(d2,d4)))"
      using A1 A2 finseqop_th_86 finseqop_th_89 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T1,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> T2) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G .:FINSEQOPK1\<^bsub>(D,D,D)\<^esub>(T1,T2)"
      using A1 setwop_2_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & (G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub> & F be associativeBINOP-1V2\<^bsub>(D)\<^esub>) & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A2: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A3: "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,e) =XBOOLE-0R4 e"
    have A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)) & SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using finseq_1_def_3 finseq_2_th_78 sorry
    have A5: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p))) =XBOOLE-0R4 domFINSEQ-1K5 (G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p))"
      using finseq_1_def_3 sorry
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)))"
      using A1 setwop_2_def_2 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,G [;]FUNCOP-1K10\<^bsub>(D,NATNUMBERSK1)\<^esub>(d,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)))"
      using A1 A2 A3 setwop_2_th_12 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p),e))"
      using A3 setwop_2_lm_6 sorry
    also have "... = F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
      using A1 A4 A5 setwop_2_def_2 sorry
    finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_39:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for e be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F) & (G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F & G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "(F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & e =XBOOLE-0R4 the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
      and A2: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
      and A3: "G .BINOP-1K4\<^bsub>(D)\<^esub>(e,d) =XBOOLE-0R4 e"
    have A4: "lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 (G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)) & SegFINSEQ-1K2 (lenFINSEQ-1K4 p) =XBOOLE-0R4 domFINSEQ-1K5 p"
      using finseq_1_def_3 finseq_2_th_84 sorry
    have A5: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d))) =XBOOLE-0R4 domFINSEQ-1K5 (G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d))"
      using finseq_1_def_3 sorry
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =HIDDENR1 G .BINOP-1K4\<^bsub>(D)\<^esub>(F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e)),d)"
      using A1 setwop_2_def_2 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,G [:]FUNCOP-1K9\<^bsub>(D,NATNUMBERSK1)\<^esub>([#]SETWOP-2K1\<^bsub>(D)\<^esub>(p,e),d))"
      using A1 A2 A3 setwop_2_th_13 sorry
    also have "... = F $$SETWISEOK10\<^bsub>(NATNUMBERSK1,D)\<^esub>(findomFINSOP-1K4 p,[#]SETWOP-2K1\<^bsub>(D)\<^esub>(G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d),e))"
      using A3 setwop_2_lm_5 sorry
    also have "... = F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
      using A1 A4 A5 setwop_2_def_2 sorry
    finally show "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =HIDDENR1 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_40:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,?e) =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_66 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(d,F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [;]FINSEQOPK3\<^bsub>(D,D,D)\<^esub>(d,p)"
      using A1 A3 setwop_2_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem setwop_2_th_41:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds ((F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>) & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for F be BinOpBINOP-1M2-of D holds  for G be BinOpBINOP-1M2-of D holds  for p be FinSequenceFINSEQ-1M3-of D holds (F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>) & (F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub> & G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F) implies G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix F assume [ty]: "F be BinOpBINOP-1M2-of D"
    fix G assume [ty]: "G be BinOpBINOP-1M2-of D"
    fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
    assume A1: "F be commutativeBINOP-1V1\<^bsub>(D)\<^esub>\<bar>associativeBINOP-1V2\<^bsub>(D)\<^esub> & F be having-a-unitySETWISEOV1\<^bsub>(D)\<^esub>"
      and A2: "F be having-an-inverseOpFINSEQOPV1\<^bsub>(D)\<^esub>"
      and A3: "G is-distributive-wrtBINOP-1R6\<^bsub>(D)\<^esub> F"
    let ?e = "the-unity-wrtBINOP-1K3\<^bsub>(D)\<^esub> F"
    have "G .BINOP-1K4\<^bsub>(D)\<^esub>(?e,d) =XBOOLE-0R4 ?e"
      using A1 A2 A3 finseqop_th_66 sorry
    thus "G .BINOP-1K4\<^bsub>(D)\<^esub>(F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> p,d) =XBOOLE-0R4 F \<inverse>**\<inverse>FINSOP-1K1\<^bsub>(D)\<^esub> G [:]FINSEQOPK2\<^bsub>(D,D,D)\<^esub>(p,d)"
      using A1 A3 setwop_2_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
