theory binarith
  imports margrel1 setwop_2 series_1 nat_d trees_3 rfinseq
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem binarith_th_1:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for z be TupleFINSEQ-2M3-of(n,D) holds i inHIDDENR3 SegFINSEQ-1K2 n implies (z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 z /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
  fix z assume [ty]: "z be TupleFINSEQ-2M3-of(n,D)"
  assume A1: "i inHIDDENR3 SegFINSEQ-1K2 n"
  have "lenFINSEQ-1K4 z =XBOOLE-0R4 n"
    using card_1_def_7 sorry
  then have "i inHIDDENR3 domFINSEQ-1K5 z"
    using A1 finseq_1_def_3 sorry
  thus "(z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 z /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
    using finseq_4_th_68 sorry
qed "sorry"

mtheorem binarith_th_2:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for z be TupleFINSEQ-2M3-of(n,D) holds (z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 d"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for d be ElementSUBSET-1M1-of D holds  for z be TupleFINSEQ-2M3-of(n,D) holds (z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of D"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(n,D)"
    have "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>) =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_39 sorry
    then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 (lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))"
       sorry
    then have A1: "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)"
      using finseq_1_def_3 sorry
    have "lenFINSEQ-1K4 z =XBOOLE-0R4 n"
      using card_1_def_7 sorry
    then have "(z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 finseq_4_th_69 sorry
    also have "... = d"
      using finseq_4_th_16 sorry
    finally show "(z ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(D)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 d"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) BINARITHK1(" _ ''or''BINARITHK1  _ " [170,170]170) where
  "x 'or'BINARITHK1 y \<equiv> x 'or'XBOOLEANK5 y"

mtheorem binarith_add_1:
  mlet "x be ElementSUBSET-1M1-of BOOLEANMARGREL1K5", "y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster x 'or'XBOOLEANK5 y as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "x 'or'XBOOLEANK5 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
  proof-
    have "x 'or'XBOOLEANK5 y =HIDDENR1 FALSEMARGREL1K6 or x 'or'XBOOLEANK5 y =HIDDENR1 TRUEMARGREL1K7"
      using xboolean_def_3 sorry
    thus "x 'or'XBOOLEANK5 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
  qed
qed "sorry"

abbreviation(input) BINARITHK2(" _ ''xor''BINARITHK2  _ " [164,164]164) where
  "x 'xor'BINARITHK2 y \<equiv> x 'xor'XBOOLEANK10 y"

mtheorem binarith_add_2:
  mlet "x be ElementSUBSET-1M1-of BOOLEANMARGREL1K5", "y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster x 'xor'XBOOLEANK10 y as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "x 'xor'XBOOLEANK10 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
  proof-
    have "x 'xor'XBOOLEANK10 y =HIDDENR1 FALSEMARGREL1K6 or x 'xor'XBOOLEANK10 y =HIDDENR1 TRUEMARGREL1K7"
      using xboolean_def_3 sorry
    thus "x 'xor'XBOOLEANK10 y be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
  qed
qed "sorry"

reserve x, y, z for "booleanMARGREL1V2\<bar>objectHIDDENM1"
mtheorem binarith_th_3:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 (FALSEMARGREL1K6) =HIDDENR1 x"
   sorry

mtheorem binarith_th_4:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds 'not'MARGREL1K8 (x '&'MARGREL1K9 y) =HIDDENR1 'not'MARGREL1K8 x 'or'XBOOLEANK5 'not'MARGREL1K8 y"
   sorry

mtheorem binarith_th_5:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds 'not'MARGREL1K8 (x 'or'XBOOLEANK5 y) =HIDDENR1 'not'MARGREL1K8 x '&'MARGREL1K9 'not'MARGREL1K8 y"
   sorry

mtheorem binarith_th_6:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x '&'MARGREL1K9 y =HIDDENR1 'not'MARGREL1K8 ('not'MARGREL1K8 x 'or'XBOOLEANK5 'not'MARGREL1K8 y)"
   sorry

mtheorem binarith_th_7:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (TRUEMARGREL1K7)'xor'XBOOLEANK10 x =HIDDENR1 'not'MARGREL1K8 x"
   sorry

mtheorem binarith_th_8:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (FALSEMARGREL1K6)'xor'XBOOLEANK10 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_9:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x '&'MARGREL1K9 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_10:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 (TRUEMARGREL1K7) =HIDDENR1 TRUEMARGREL1K7"
   sorry

mtheorem binarith_th_11:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for y be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for z be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (x 'or'XBOOLEANK5 y)'or'XBOOLEANK5 z =HIDDENR1 x 'or'XBOOLEANK5 (y 'or'XBOOLEANK5 z)"
   sorry

mtheorem binarith_th_12:
" for x be booleanMARGREL1V2\<bar>objectHIDDENM1 holds x 'or'XBOOLEANK5 x =HIDDENR1 x"
   sorry

mtheorem binarith_th_13:
"(TRUEMARGREL1K7)'xor'BINARITHK2 (FALSEMARGREL1K6) =XBOOLE-0R4 TRUEMARGREL1K7"
   sorry

reserve i, j, k for "NatNAT-1M1"
reserve n for " non zeroORDINAL1V8\<bar>NatNAT-1M1"
reserve x, y, z1, z2 for "TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
mdef binarith_def_1 ("''not''BINARITHK3\<^bsub>'( _ ')\<^esub>  _ " [0,182]182 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func 'not'BINARITHK3\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof-
      have " ex tVar1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies tVar1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof-
        let ?F = "\<lambda>Lamb1. 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5" and 
          A1: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A2: " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_2_sch_1 sorry
        have A3: "domFINSEQ-1K5 z =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A1 finseq_1_def_3 sorry
        have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
          using A1 card_1_def_7 sorry
        show " ex tVar1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies tVar1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule bexI[of _ "z"],rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A4: "i inHIDDENR3 SegFINSEQ-1K2 n"
          then have "i inHIDDENR3 domFINSEQ-1K5 z"
            using A1 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 z .FUNCT-1K1 i"
            using partfun1_def_6 sorry
          also have "... = 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 A3 A4 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
    proof-
      have " for y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies y =HIDDENR1 z"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix y assume [ty]: "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        fix z assume [ty]: "z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        assume A5: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          and A6: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        have A7: "lenFINSEQ-1K4 y =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A8: "domFINSEQ-1K5 y =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have A9: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 y implies y .FUNCT-1K1 j =HIDDENR1 z .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A10: "j inHIDDENR3 domFINSEQ-1K5 y"
          then have A11: "j inHIDDENR3 domFINSEQ-1K5 z"
            using A9 A8 finseq_1_def_3 sorry
          have "y .FUNCT-1K1 j =HIDDENR1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A10 partfun1_def_6 sorry
          also have "... = 'not'MARGREL1K10 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A5 A8 A10 sorry
          also have "... = z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A6 A8 A10 sorry
          also have "... = z .FUNCT-1K1 j"
            using A11 partfun1_def_6 sorry
          finally show "y .FUNCT-1K1 j =HIDDENR1 z .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "y =HIDDENR1 z"
          using A7 A9 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef binarith_def_2 ("carryBINARITHK4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func carryBINARITHK4\<^bsub>(n)\<^esub>(x,y) \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it. it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
    proof-
      have " ex tVar2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
      proof-
        let ?G = "\<lambda>Lamb1. \<lambda>Lamb2. (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 Lamb2)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (Lamb1 +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 Lamb2"
        obtain f where
          [ty]:"f be sequenceNAT-1M2-of BOOLEANMARGREL1K5" and 
          A1: "f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (0NUMBERSK6) =XBOOLE-0R4 FALSEMARGREL1K6"and A2: " for i be NatNAT-1M1 holds f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 ?G(i,f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
          using nat_1_sch_12 sorry
        let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 (Lamb1 -XCMPLX-0K6 \<one>\<^sub>M)"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M1" and 
          A3: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A4: " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_1_sch_2 sorry
        have "z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5"
        proof-
          have " for a be objectHIDDENM1 holds a inHIDDENR3 rngFUNCT-1K2 z implies a inHIDDENR3 BOOLEANMARGREL1K5"
          proof(rule ballI,rule impI)
            fix a assume [ty]: "a be objectHIDDENM1"
            assume "a inHIDDENR3 rngFUNCT-1K2 z"
            then obtain b where
              [ty]:"b be objectHIDDENM1" and 
              A5: "b inHIDDENR3 domFINSEQ-1K5 z"and A6: "a =HIDDENR1 z .FUNCT-1K1 b"
              using funct_1_def_3 sorry
            have A7: "b inHIDDENR3 SegFINSEQ-1K2 n"
              using A3 A5 finseq_1_def_3 sorry
            have 
              [ty]:"b be ElementSUBSET-1M1-of NATNUMBERSK1"
              using A5 sorry
            have "b >=XXREAL-0R2 \<one>\<^sub>M"
              using A7 finseq_1_th_1 sorry
            then obtain c where 
              [ty]:"c be ElementSUBSET-1M1-of NATNUMBERSK1" and cDef:"c = b -XCMPLX-0K6 \<one>\<^sub>M"
              using int_1_th_5 sorry
            have "z .FUNCT-1K1 b =XBOOLE-0R4 f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> c"
              using A4 A5 sorry
            thus "a inHIDDENR3 BOOLEANMARGREL1K5"
              using A6 sorry
          qed "sorry"
          thus "z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5"
            using finseq_1_def_4 tarski_def_3 sorry
        qed
        then have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
          using A3 card_1_def_7 sorry
        show " ex tVar2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 tVar2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)"
        proof(rule bexI[of _ "z"],rule conjMI,rule ballI,rule impMI ,rule impI)
          have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using nat_1_th_13 sorry
          then have "\<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n"
             sorry
          then have A8: "\<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 z"
            using A3 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 z .FUNCT-1K1 \<one>\<^sub>M"
            using partfun1_def_6 sorry
          also have "... = f .FUNCT-1K1 (\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M)"
            using A4 A8 sorry
          also have "... = FALSEMARGREL1K6"
            using A1 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 FALSEMARGREL1K6"
             sorry
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A9: "\<one>\<^sub>M <=XXREAL-0R1 i"
            and A10: "i <XXREAL-0R3 n"
          obtain j where
            [ty]:"j be NatNAT-1M1" and 
            A11: "j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i"
            using A9 nat_1_th_6 sorry
          have "j +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n"
            using A9 A10 A11 sorry
          then have A12: "j +NAT-1K1 \<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 z"
            using A3 finseq_1_def_3 sorry
          then have A13: "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z .FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)"
            using partfun1_def_6 sorry
          also have "... = f .FUNCT-1K1 ((j +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)"
            using A4 A12 sorry
          also have "... = f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
             sorry
          finally have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
             sorry
          have A14: "(i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 i"
             sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
            using A9 A10 nat_1_th_13 sorry
          then have A15: "i +NAT-1K1 \<one>\<^sub>M inHIDDENR3 domFINSEQ-1K5 z"
            using A3 finseq_3_th_25 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)"
            using partfun1_def_6 sorry
          also have "... = f .NAT-1K8\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (j +NAT-1K1 \<one>\<^sub>M)"
            using A4 A11 A14 A15 sorry
          also have "... = (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 A11 A13 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)) & (it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)) implies it1 =HIDDENR1 it2"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & (( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & (z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 & ( for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i))) implies z1 =HIDDENR1 z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        assume A16: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
          and A17: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          and A18: "z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
          and A19: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <XXREAL-0R3 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        have A20: "lenFINSEQ-1K4 z2 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        have A21: "lenFINSEQ-1K4 z1 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A22: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z1 implies z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1 =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1"
          have A23: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n & domFINSEQ-1K5 z2 =XBOOLE-0R4 SegFINSEQ-1K2 n"
            using A21 A20 finseq_1_def_3 sorry
          have A24: " for k be NatNAT-1M1 holds (k inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k) implies (k +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M))"
          proof(rule ballI,rule impI)
            fix k assume [ty]: "k be NatNAT-1M1"
            assume A25: "?P(k)"
            show "k +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
            proof(rule impI)
              assume A26: "k +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n"
              show "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
              proof-
                have cases: "k =XBOOLE-0R4 0NUMBERSK6 or k <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "k =XBOOLE-0R4 0NUMBERSK6 implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                proof(rule impI)
                  assume "k =XBOOLE-0R4 0NUMBERSK6"
                  thus "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                    using A16 A18 sorry
                qed
                have case2: "k <>HIDDENR2 0NUMBERSK6 implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                proof(rule impI)
                  assume A27: "k <>HIDDENR2 0NUMBERSK6"
                  have "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n & k <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
                    using A26 finseq_1_th_1 xreal_1_th_29 sorry
                  then have A28: "k <XXREAL-0R3 n"
                    using xxreal_0_th_2 sorry
                  have A29: "k >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                    using A27 nat_1_th_13 sorry
                  then have "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k '&'MARGREL1K11 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k 'or'BINARITHK1 x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k)'or'BINARITHK1 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k '&'MARGREL1K11 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> k"
                    using A17 A28 sorry
                  also have "... = z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                    using A19 A25 A29 A28 sorry
                  finally show "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
          qed "sorry"
          have A30: "?P(0NUMBERSK6)"
            using finseq_1_th_1 sorry
          have A31: " for k be NatNAT-1M1 holds ?P(k)"
            using nat_1_sch_2 A30 A24 sorry
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A32: "j inHIDDENR3 domFINSEQ-1K5 z1"
          have "z1 .FUNCT-1K1 j =HIDDENR1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A32 partfun1_def_6 sorry
          also have "... = z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A22 A32 A31 sorry
          also have "... = z2 .FUNCT-1K1 j"
            using A32 A23 partfun1_def_6 sorry
          finally show "z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "z1 =HIDDENR1 z2"
          using A21 A20 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef binarith_def_3 ("BinaryBINARITHK5\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func BinaryBINARITHK5\<^bsub>(n)\<^esub> x \<rightarrow> TupleFINSEQ-2M3-of(n,NATNUMBERSK1) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
    proof-
      have " ex tVar3 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) st  for j be NatNAT-1M1 holds j inHIDDENR3 SegFINSEQ-1K2 n implies tVar3 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (j -'NAT-DK9 \<one>\<^sub>M))"
      proof-
        let ?F = "\<lambda>Lamb1. IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (Lamb1 -'NAT-DK9 \<one>\<^sub>M))"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M3-of NATNUMBERSK1" and 
          A1: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A2: " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_2_sch_1 sorry
        have A3: "domFINSEQ-1K5 z =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A1 finseq_1_def_3 sorry
        have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,NATNUMBERSK1)"
          using A1 card_1_def_7 sorry
        show " ex tVar3 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) st  for j be NatNAT-1M1 holds j inHIDDENR3 SegFINSEQ-1K2 n implies tVar3 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (j -'NAT-DK9 \<one>\<^sub>M))"
        proof(rule bexI[of _ "z"],rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A4: "j inHIDDENR3 SegFINSEQ-1K2 n"
          then have "j inHIDDENR3 domFINSEQ-1K5 z"
            using A1 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j =HIDDENR1 z .FUNCT-1K1 j"
            using partfun1_def_6 sorry
          also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (j -'NAT-DK9 \<one>\<^sub>M))"
            using A2 A3 A4 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (j -'NAT-DK9 \<one>\<^sub>M))"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds  for it2 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds  for z2 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))) implies z1 =HIDDENR1 z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,NATNUMBERSK1)"
        assume A5: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
          and A6: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
        have A7: "lenFINSEQ-1K4 z1 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A8: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have A9: "lenFINSEQ-1K4 z2 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A10: "domFINSEQ-1K5 z2 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z1 implies z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A11: "j inHIDDENR3 domFINSEQ-1K5 z1"
          then have "z1 .FUNCT-1K1 j =HIDDENR1 z1 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j"
            using partfun1_def_6 sorry
          also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (j -'NAT-DK9 \<one>\<^sub>M))"
            using A5 A8 A11 sorry
          also have "... = z2 /.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> j"
            using A6 A8 A11 sorry
          also have "... = z2 .FUNCT-1K1 j"
            using A8 A10 A11 partfun1_def_6 sorry
          finally show "z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "z1 =HIDDENR1 z2"
          using A7 A9 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef binarith_def_4 ("AbsvalBINARITHK6\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "n be NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func AbsvalBINARITHK6\<^bsub>(n)\<^esub> x \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (BinaryBINARITHK5\<^bsub>(n)\<^esub> x)"
proof-
  (*coherence*)
    show "(addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (BinaryBINARITHK5\<^bsub>(n)\<^esub> x) be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mdef binarith_def_5 (" _ +BINARITHK7\<^bsub>'( _ ')\<^esub>  _ " [132,0,132]132 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "x be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "y be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func x +BINARITHK7\<^bsub>(n)\<^esub> y \<rightarrow> TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) means
  \<lambda>it.  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  (*existence*)
    show " ex it be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof-
      have " ex tVar4 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies tVar4 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof-
        let ?F = "\<lambda>Lamb1. (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1"
        obtain z where
          [ty]:"z be FinSequenceFINSEQ-1M3-of BOOLEANMARGREL1K5" and 
          A1: "lenFINSEQ-1K4 z =XBOOLE-0R4 n"and A2: " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z implies z .FUNCT-1K1 j =XBOOLE-0R4 ?F(j)"
          using finseq_2_sch_1 sorry
        have A3: "domFINSEQ-1K5 z =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using A1 finseq_1_def_3 sorry
        have 
          [ty]:"z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
          using A1 card_1_def_7 sorry
        show " ex tVar4 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) st  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies tVar4 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof(rule bexI[of _ "z"],rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A4: "i inHIDDENR3 SegFINSEQ-1K2 n"
          then have "i inHIDDENR3 domFINSEQ-1K5 z"
            using A1 finseq_1_def_3 sorry
          then have "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 z .FUNCT-1K1 i"
            using partfun1_def_6 sorry
          also have "... = (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            using A2 A3 A4 sorry
          finally show "z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for it2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies it2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies it1 =HIDDENR1 it2"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) & ( for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies z1 =HIDDENR1 z2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
        assume A5: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          and A6: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        have A7: "lenFINSEQ-1K4 z1 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A8: "domFINSEQ-1K5 z1 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have A9: "lenFINSEQ-1K4 z2 =XBOOLE-0R4 n"
          using card_1_def_7 sorry
        then have A10: "domFINSEQ-1K5 z2 =XBOOLE-0R4 SegFINSEQ-1K2 n"
          using finseq_1_def_3 sorry
        have " for j be NatNAT-1M1 holds j inHIDDENR3 domFINSEQ-1K5 z1 implies z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
        proof(rule ballI,rule impI)
          fix j assume [ty]: "j be NatNAT-1M1"
          assume A11: "j inHIDDENR3 domFINSEQ-1K5 z1"
          then have "z1 .FUNCT-1K1 j =HIDDENR1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using partfun1_def_6 sorry
          also have "... = (x /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j 'xor'BINARITHK2 y /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(x,y))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A5 A8 A11 sorry
          also have "... = z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> j"
            using A6 A8 A11 sorry
          also have "... = z2 .FUNCT-1K1 j"
            using A8 A10 A11 partfun1_def_6 sorry
          finally show "z1 .FUNCT-1K1 j =HIDDENR1 z2 .FUNCT-1K1 j"
             sorry
        qed "sorry"
        thus "z1 =HIDDENR1 z2"
          using A7 A9 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef binarith_def_6 ("add-ovflBINARITHK8\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"func add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) \<rightarrow> ElementSUBSET-1M1-of BOOLEANMARGREL1K5 equals
  (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n 'or'BINARITHK1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'or'BINARITHK1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
proof-
  (*coherence*)
    show "(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n 'or'BINARITHK1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n)'or'BINARITHK1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
       sorry
qed "sorry"

mdef binarith_def_7 ("'( _ , _ ')are-summableBINARITHR1\<^bsub>'( _ ')\<^esub>" [0,0,0]50 ) where
  mlet "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1", "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)", "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
"pred (z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub> means
  add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6"..

mtheorem binarith_th_14:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> or z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>"
proof-
  have " for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds  not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
  proof(rule ballI)
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
    have A1: " ex B be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 st z1 =FINSEQ-1R1 <*TREES-3K14 B*>"
      using finseq_2_th_97 sorry
    show " not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
    proof-
      have cases: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 or z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7"
        using xboolean_def_3 sorry
      have case1: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6 implies  not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
      proof(rule impI)
        assume "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
        thus " not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
          using A1 finseq_4_th_16 sorry
      qed
      have case2: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7 implies  not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
      proof(rule impI)
        assume "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 TRUEMARGREL1K7"
        thus " not ( not z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> &  not z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>)"
          using A1 finseq_4_th_16 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_15:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
    have A1: " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*TREES-3K14 k*>"
      using finseq_2_th_97 sorry
    assume "z1 =FINSEQ-1R1 <*TREES-3K14 FALSEMARGREL1K6 *>"
    then have A2: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 FALSEMARGREL1K6"
      using finseq_4_th_16 sorry
    have "\<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then have "(BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
      using binarith_def_3 sorry
    also have "... = 0NUMBERSK6"
      using A2 funcop_1_def_8 sorry
    finally have "(BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
       sorry
    then have "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 0NUMBERSK6 *>)"
      using A1 finseq_4_th_16 sorry
    also have "... = 0NUMBERSK6"
      using finsop_1_th_11 sorry
    finally show "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_16:
" for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
    have A1: "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
       sorry
    assume "z1 =FINSEQ-1R1 <*TREES-3K14 TRUEMARGREL1K7 *>"
    then have A2: "z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M <>HIDDENR2 FALSEMARGREL1K6"
      using finseq_4_th_16 sorry
    have "\<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
       sorry
    then have A3: "(BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M))"
      using binarith_def_3 sorry
    also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
      using A2 funcop_1_def_8 sorry
    finally have "(BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
       sorry
    have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st BinaryBINARITHK5\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =FINSEQ-1R1 <*TREES-3K14 k*>"
      using finseq_2_th_97 sorry
    then have "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (<*TREES-3K14 \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)*>)"
      using A3 finseq_4_th_16 sorry
    also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (\<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
      using finsop_1_th_11 sorry
    also have "... = \<two>\<^sub>M to-powerSERIES-1K5 (0NUMBERSK6)"
      using A1 xreal_0_def_2 sorry
    also have "... = \<one>\<^sub>M"
      using power_th_24 sorry
    finally show "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax BINARITHK9 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ^BINARITHK9\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [164,0,0,0,164]164)
translations "z1 ^BINARITHK9\<^bsub>(n1,n2,D)\<^esub> z2" \<rightharpoonup> "z1 ^FINSEQ-1K8 z2"

mtheorem binarith_add_3:
  mlet "n1 be NatNAT-1M1", "n2 be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "z1 be TupleFINSEQ-2M3-of(n1,D)", "z2 be TupleFINSEQ-2M3-of(n2,D)"
"cluster z1 ^FINSEQ-1K8 z2 as-term-is TupleFINSEQ-2M3-of(n1 +XCMPLX-0K2 n2,D)"
proof
(*coherence*)
  show "z1 ^FINSEQ-1K8 z2 be TupleFINSEQ-2M3-of(n1 +XCMPLX-0K2 n2,D)"
    using finseq_2_th_107 sorry
qed "sorry"

syntax BINARITHK10 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*BINARITHK10\<^bsub>'( _ ')\<^esub>  _ *>" [0,0]164)
translations "<*BINARITHK10\<^bsub>(D)\<^esub> d*>" \<rightharpoonup> "<*FINSEQ-1K6 d*>"

mtheorem binarith_add_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "d be ElementSUBSET-1M1-of D"
"cluster <*FINSEQ-1K6 d*> as-term-is TupleFINSEQ-2M3-of(\<one>\<^sub>M,D)"
proof
(*coherence*)
  show "<*FINSEQ-1K6 d*> be TupleFINSEQ-2M3-of(\<one>\<^sub>M,D)"
  proof-
    have "<*FINSEQ-1K13\<^bsub>(D)\<^esub> d*> inHIDDENR3 \<one>\<^sub>M -tuples-onFINSEQ-2K4 D"
      using finseq_2_th_98 sorry
    thus "<*FINSEQ-1K6 d*> be TupleFINSEQ-2M3-of(\<one>\<^sub>M,D)"
       sorry
  qed
qed "sorry"

mtheorem binarith_th_17:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    let ?P = "\<lambda>Lamb1. Lamb1 inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1 =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> Lamb1"
    fix i assume [ty]: "i be NatNAT-1M1"
    have A1: " for i be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P(i) implies ?P(i +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for i be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds (i inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i) implies (i +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule impI)
        fix i assume [ty]: "i be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
        assume A2: "?P(i)"
        assume "i +NAT-1K1 \<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n"
        then have "i +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 i & i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
          using finseq_1_th_1 xreal_1_th_29 sorry
        then have A3: "i <XXREAL-0R3 n"
          using xxreal_0_th_2 sorry
        have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_11 sorry
        then have A4: "i <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
          using A3 xxreal_0_th_2 sorry
        have A5: "\<one>\<^sub>M <=XXREAL-0R1 i"
          using nat_1_th_14 sorry
        then have "i inHIDDENR3 SegFINSEQ-1K2 n"
          using A3 sorry
        then have "(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i & (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          using binarith_th_1 sorry
        then have "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'or'BINARITHK1 z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'or'BINARITHK1 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          using A2 A5 A3 A4 binarith_def_2 sorry
        also have "... = (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)"
          using A5 A3 binarith_def_2 sorry
        finally show "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(\<one>\<^sub>M)"
    proof-
      have "\<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n implies (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
      proof(rule impI)
        assume "\<one>\<^sub>M inHIDDENR3 SegFINSEQ-1K2 n"
        have "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 FALSEMARGREL1K6"
          using binarith_def_2 sorry
        also have "... = (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
          using binarith_def_2 sorry
        finally show "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =HIDDENR1 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A7: " for i be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P(i)"
      using nat_1_sch_10 A6 A1 sorry
    assume A8: "i inHIDDENR3 SegFINSEQ-1K2 n"
    then have "i be  non zeroORDINAL1V8"
      using finseq_1_th_1 sorry
    thus "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      using A8 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_18:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have A1: "\<one>\<^sub>M <=XXREAL-0R1 n & n <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_14 xreal_1_th_29 sorry
    have A2: "n inHIDDENR3 SegFINSEQ-1K2 n"
      using finseq_1_th_3 sorry
    then have A3: "z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
      using binarith_th_1 sorry
    have "(carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n & z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n =XBOOLE-0R4 (z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> n"
      using A2 binarith_th_1 binarith_th_17 sorry
    thus "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
      using A3 A1 binarith_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_19:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>)"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds  for d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix d1 assume [ty]: "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    fix d2 assume [ty]: "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =XBOOLE-0R4 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
    proof-
      have " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
      proof(rule ballI,rule impI)
        have A1: "SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SegFINSEQ-1K2 n \\/XBOOLE-0K2 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
          using finseq_1_th_9 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A2: "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        show "((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
        proof-
          have cases: "i inHIDDENR3 SegFINSEQ-1K2 n or i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
            using A2 A1 xboole_0_def_3 sorry
          have case1: "i inHIDDENR3 SegFINSEQ-1K2 n implies ((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          proof(rule impI)
            assume A3: "i inHIDDENR3 SegFINSEQ-1K2 n"
            then have "((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using binarith_th_1 sorry
            also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A3 binarith_def_5 sorry
            also have "... = ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A3 binarith_th_1 sorry
            also have "... = ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A3 binarith_th_1 sorry
            also have "... = ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A3 binarith_th_17 sorry
            finally show "((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
               sorry
          qed
          have case2: "i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .} implies ((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
          proof(rule impI)
            assume "i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
            then have A4: "i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
              using tarski_def_1 sorry
            then have "((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2))"
              using binarith_th_2 sorry
            also have "... = (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A4 binarith_th_18 sorry
            also have "... = (d1 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A4 binarith_th_2 sorry
            also have "... = ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
              using A4 binarith_th_2 sorry
            finally show "((z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 (z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "z1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>) +BINARITHK7\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> z2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>) =FINSEQ-1R1 (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2)) *>)"
      using binarith_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_20:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
  proof(rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z assume [ty]: "z be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix d assume [ty]: "d be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    have " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =XBOOLE-0R4 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
    proof-
      have " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) implies ((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        have A1: "SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 SegFINSEQ-1K2 n \\/XBOOLE-0K2 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
          using finseq_1_th_9 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A2: "i inHIDDENR3 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
        show "((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
        proof-
          have cases: "i inHIDDENR3 SegFINSEQ-1K2 n or i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
            using A2 A1 xboole_0_def_3 sorry
          have case1: "i inHIDDENR3 SegFINSEQ-1K2 n implies ((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
          proof(rule impI)
            assume A3: "i inHIDDENR3 SegFINSEQ-1K2 n"
            then have "((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 (BinaryBINARITHK5\<^bsub>(n)\<^esub> z)/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i"
              using binarith_th_1 sorry
            also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(z /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
              using A3 binarith_def_3 sorry
            also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
              using A3 binarith_th_1 sorry
            finally show "((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
               sorry
          qed
          have case2: "i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .} implies ((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
          proof(rule impI)
            assume "i inHIDDENR3 {.SETWISEOK5\<^bsub>(NATNUMBERSK1)\<^esub> n +NAT-1K1 \<one>\<^sub>M .}"
            then have A4: "i =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
              using tarski_def_1 sorry
            then have "((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
              using binarith_th_2 sorry
            also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
              using A4 binarith_th_2 sorry
            also have "... = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
              using A4 nat_d_th_34 sorry
            finally show "((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))/.PARTFUN1K7\<^bsub>(NATNUMBERSK1)\<^esub> i =HIDDENR1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (i -'NAT-DK9 \<one>\<^sub>M))"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have "AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 (addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> ((BinaryBINARITHK5\<^bsub>(n)\<^esub> z)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,NATNUMBERSK1)\<^esub> (<*BINARITHK10\<^bsub>(NATNUMBERSK1)\<^esub> IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) *>))"
      using binarith_def_3 sorry
    also have "... = (addnatBINOP-2K23).NAT-1K10\<^bsub>(NATNUMBERSK1)\<^esub>((addnatBINOP-2K23)$$SETWOP-2K5\<^bsub>(NATNUMBERSK1)\<^esub> (BinaryBINARITHK5\<^bsub>(n)\<^esub> z),IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n))"
      using finsop_1_th_4 sorry
    also have "... = AbsvalBINARITHK6\<^bsub>(n)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
      using binop_2_def_23 sorry
    finally show "AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (z ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d*>)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_21:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
  proof-
    let ?P = "\<lambda>Lamb1.  for z1 be TupleFINSEQ-2M3-of(Lamb1,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(Lamb1,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(Lamb1)\<^esub> (z1 +BINARITHK7\<^bsub>(Lamb1)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(Lamb1)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 Lamb1) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(Lamb1)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(Lamb1)\<^esub> z2"
    let ?f = "FALSEMARGREL1K6"
    let ?t = "TRUEMARGREL1K7"
    have A1: " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds ( for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2) implies ( for z1 be TupleFINSEQ-2M3-of(n +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2)"
      proof(rule ballI,rule impI,rule ballI,rule ballI)
        fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
        assume A2: "?P(n)"
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n +NAT-1K1 \<one>\<^sub>M,BOOLEANMARGREL1K5)"
        obtain t1 d1 where
          [ty]:"t1 be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of n -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)" "d1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
          A3: "z1 =FINSEQ-1R1 t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>)"
          using finseq_2_th_117 sorry
        obtain t2 d2 where
          [ty]:"t2 be ElementFINSEQ-2M2\<^bsub>(BOOLEANMARGREL1K5)\<^esub>-of n -tuples-onFINSEQ-2K4 (BOOLEANMARGREL1K5)" "d2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5" and 
          A4: "z2 =FINSEQ-1R1 t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)"
          using finseq_2_th_117 sorry
        obtain C1 C2 C3 C4 C5 where 
          [ty]:"C1 be RealXREAL-0M1" and C1Def:"C1 = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M))" and
          [ty]:"C2 be RealXREAL-0M1" and C2Def:"C2 = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>((d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)" and
          [ty]:"C3 be RealXREAL-0M1" and C3Def:"C3 = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)" and
          [ty]:"C4 be RealXREAL-0M1" and C4Def:"C4 = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d2,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)" and
          [ty]:"C5 be RealXREAL-0M1" and C5Def:"C5 = IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
           sorry
        have A5: "add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2) =HIDDENR1 (d1 '&'MARGREL1K11 (t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) 'or'BINARITHK1 (t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 (t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using A3 A4 binarith_th_2 sorry
        also have "... = (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 (t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 (t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using binarith_th_2 sorry
        also have "... = (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 (t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M) '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using binarith_th_2 sorry
        also have "... = (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M))'or'BINARITHK1 d2 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using binarith_th_2 sorry
        also have "... = (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (carryBINARITHK4\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub>(t1 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d1*>),t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>)))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (n +NAT-1K1 \<one>\<^sub>M)"
          using binarith_th_18 sorry
        also have "... = (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
          using binarith_th_18 sorry
        finally have "add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2) =HIDDENR1 (d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
           sorry
        have A6: "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
        proof-
          have "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
          proof-
            show "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
            proof-
              have cases: "d1 =XBOOLE-0R4 ?f or d1 <>HIDDENR2 ?f"
                 sorry
              have case1: "d1 =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
              proof(rule impI)
                assume A7: "d1 =XBOOLE-0R4 ?f"
                then have A8: "C3 =HIDDENR1 0NUMBERSK6"
                  using funcop_1_def_8 sorry
                have "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                proof-
                  show "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                  proof-
                    have cases: "d2 =XBOOLE-0R4 ?f or d2 <>HIDDENR2 ?f"
                       sorry
                    have case1: "d2 =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                    proof(rule impI)
                      assume A9: "d2 =XBOOLE-0R4 ?f"
                      then have "C4 =HIDDENR1 0NUMBERSK6"
                        using funcop_1_def_8 sorry
                      thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                        using A5 A7 A9 funcop_1_def_8 sorry
                    qed
                    have case2: "d2 <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                    proof(rule impI)
                      assume A10: "d2 <>HIDDENR2 ?f"
                      then have A11: "C4 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                        using funcop_1_def_8 sorry
                      have "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                      proof-
                        show "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                        proof-
                          have cases: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                             sorry
                          have case1: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume A12: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f"
                            then have "C5 =HIDDENR1 0NUMBERSK6"
                              using funcop_1_def_8 sorry
                            thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A5 A7 A12 funcop_1_def_8 sorry
                          qed
                          have case2: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume A13: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                            have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A7 A10 xboolean_def_3 sorry
                            also have "... = ?f"
                              using A13 xboolean_def_3 sorry
                            finally have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?f"
                               sorry
                            then have A14: "C2 =HIDDENR1 0NUMBERSK6"
                              using funcop_1_def_8 sorry
                            have A15: "C5 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using A13 funcop_1_def_8 sorry
                            have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?f 'or'BINARITHK1 ?f)'or'BINARITHK1 ?t '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A7 A10 xboolean_def_3 sorry
                            also have "... = ?t"
                              using A13 xboolean_def_3 sorry
                            finally have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t"
                               sorry
                            then have "C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
                              using A5 funcop_1_def_8 sorry
                            then have "C2 +XCMPLX-0K2 C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
                              using A14 power_th_27 sorry
                            also have "... = \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using power_th_25 sorry
                            also have "... = (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A8 A11 A15 sorry
                            finally show "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                   sorry
              qed
              have case2: "d1 <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
              proof(rule impI)
                assume A16: "d1 <>HIDDENR2 ?f"
                then have A17: "C3 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                  using funcop_1_def_8 sorry
                have "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                proof-
                  show "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                  proof-
                    have cases: "d2 =XBOOLE-0R4 ?f or d2 <>HIDDENR2 ?f"
                       sorry
                    have case1: "d2 =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                    proof(rule impI)
                      assume A18: "d2 =XBOOLE-0R4 ?f"
                      then have A19: "C4 =HIDDENR1 0NUMBERSK6"
                        using funcop_1_def_8 sorry
                      have "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                      proof-
                        show "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                        proof-
                          have cases: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                             sorry
                          have case1: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f"
                            thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A5 A18 A19 funcop_1_def_8 sorry
                          qed
                          have case2: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume A20: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                            have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 A18 xboolean_def_3 sorry
                            also have "... = ?f"
                              using A20 xboolean_def_3 sorry
                            finally have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?f"
                               sorry
                            then have A21: "C2 =HIDDENR1 0NUMBERSK6"
                              using funcop_1_def_8 sorry
                            have A22: "C5 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using A20 funcop_1_def_8 sorry
                            have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?f 'or'BINARITHK1 ?t '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 A18 xboolean_def_3 sorry
                            also have "... = (?f 'or'BINARITHK1 ?t '&'MARGREL1K11 ?t)'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A20 xboolean_def_3 sorry
                            also have "... = ?t"
                               sorry
                            finally have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t"
                               sorry
                            then have "C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
                              using A5 funcop_1_def_8 sorry
                            then have "C2 +XCMPLX-0K2 C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
                              using A21 power_th_27 sorry
                            also have "... = \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using power_th_25 sorry
                            also have "... = (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A17 A19 A22 sorry
                            finally show "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                         sorry
                    qed
                    have case2: "d2 <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                    proof(rule impI)
                      assume A23: "d2 <>HIDDENR2 ?f"
                      then have A24: "C4 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                        using funcop_1_def_8 sorry
                      have "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                      proof-
                        show "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                        proof-
                          have cases: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f or add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                             sorry
                          have case1: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume A25: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) =XBOOLE-0R4 ?f"
                            have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?t 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 xboolean_def_3 sorry
                            also have "... = ?f"
                              using A23 A25 xboolean_def_3 sorry
                            finally have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?f"
                               sorry
                            then have A26: "C2 =HIDDENR1 0NUMBERSK6"
                              using funcop_1_def_8 sorry
                            have A27: "C5 =HIDDENR1 0NUMBERSK6"
                              using A25 funcop_1_def_8 sorry
                            have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?t '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 xboolean_def_3 sorry
                            also have "... = (?t '&'MARGREL1K11 ?t 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A23 xboolean_def_3 sorry
                            also have "... = ?t"
                               sorry
                            finally have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t"
                               sorry
                            then have "C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
                              using A5 funcop_1_def_8 sorry
                            then have "C2 +XCMPLX-0K2 C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
                              using A26 power_th_27 sorry
                            also have "... = \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using power_th_25 sorry
                            also have "... = (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A17 A24 A27 sorry
                            finally show "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                               sorry
                          qed
                          have case2: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 FALSEMARGREL1K6 implies C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                          proof(rule impI)
                            assume A28: "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2) <>HIDDENR2 ?f"
                            have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?t 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 xboolean_def_3 sorry
                            also have "... = ?f 'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A23 xboolean_def_3 sorry
                            also have "... = ?t"
                              using A28 xboolean_def_3 sorry
                            finally have "(d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t"
                               sorry
                            then have A29: "C2 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using funcop_1_def_8 sorry
                            have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 (?t '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A16 xboolean_def_3 sorry
                            also have "... = (?t '&'MARGREL1K11 ?t 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2))"
                              using A23 xboolean_def_3 sorry
                            also have "... = ?t"
                               sorry
                            finally have "(d1 '&'MARGREL1K11 d2 'or'BINARITHK1 d1 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)))'or'BINARITHK1 d2 '&'MARGREL1K11 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) =HIDDENR1 ?t"
                               sorry
                            then have "C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)"
                              using A5 funcop_1_def_8 sorry
                            then have "C2 +XCMPLX-0K2 C1 =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 n +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 n *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
                              using A29 power_th_27 sorry
                            also have "... = \<two>\<^sub>M to-powerSERIES-1K5 n +NAT-1K1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M to-powerSERIES-1K5 n"
                              using power_th_25 sorry
                            also have "... = (\<two>\<^sub>M to-powerSERIES-1K5 n +NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 n)+NAT-1K1 \<two>\<^sub>M to-powerSERIES-1K5 n"
                               sorry
                            also have "... = (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                              using A17 A24 A28 funcop_1_def_8 sorry
                            finally show "C2 +XCMPLX-0K2 C1 =HIDDENR1 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                               sorry
                          qed
                          show " ?thesis "
                            using cases case1 case2 sorry
                        qed
                      qed
                      thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                         sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "C2 +XCMPLX-0K2 C1 =XBOOLE-0R4 (C5 +XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
             sorry
        qed
        have "AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> ((t1 +BINARITHK7\<^bsub>(n)\<^esub> t2)^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> (d1 'xor'BINARITHK2 d2)'xor'BINARITHK2 (add-ovflBINARITHK8\<^bsub>(n)\<^esub>(t1,t2)) *>)) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M))"
          using A3 A4 binarith_th_19 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(n)\<^esub> (t1 +BINARITHK7\<^bsub>(n)\<^esub> t2) +XCMPLX-0K2 C2)+XCMPLX-0K2 C1"
          using binarith_th_20 sorry
        also have "... = ((AbsvalBINARITHK6\<^bsub>(n)\<^esub> (t1 +BINARITHK7\<^bsub>(n)\<^esub> t2) +XCMPLX-0K2 C5)+XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
          using A6 sorry
        also have "... = ((AbsvalBINARITHK6\<^bsub>(n)\<^esub> t1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> t2)+XCMPLX-0K2 C3)+XCMPLX-0K2 C4"
          using A2 sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(n)\<^esub> t1 +XCMPLX-0K2 C3)+XCMPLX-0K2 (AbsvalBINARITHK6\<^bsub>(n)\<^esub> t2 +XCMPLX-0K2 C4)"
           sorry
        also have "... = (AbsvalBINARITHK6\<^bsub>(n)\<^esub> t1 +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(d1,FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n))+NAT-1K1 AbsvalBINARITHK6\<^bsub>(n +XCMPLX-0K2 \<one>\<^sub>M)\<^esub> (t2 ^BINARITHK9\<^bsub>(n,\<one>\<^sub>M,BOOLEANMARGREL1K5)\<^esub> (<*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> d2*>))"
          using binarith_th_20 sorry
        also have "... = AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2"
          using A3 A4 binarith_th_20 sorry
        finally show "AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 (n +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n +NAT-1K1 \<one>\<^sub>M)\<^esub> z2"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A30: "?P(\<one>\<^sub>M)"
    proof-
      have " for z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
      proof(rule ballI,rule ballI)
        obtain T F where 
          [ty]:"T be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)" and TDef:"T = <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*>" and
          [ty]:"F be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)" and FDef:"F = <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*>"
           sorry
        fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
        fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(\<one>\<^sub>M,BOOLEANMARGREL1K5)"
        have A31: "(carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 ?f"
          using binarith_def_2 sorry
        have A32: "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> T =XBOOLE-0R4 \<one>\<^sub>M"
          using binarith_th_16 sorry
        have A33: "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> F =XBOOLE-0R4 0NUMBERSK6"
          using binarith_th_15 sorry
        show "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
        proof-
          have cases: "((z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*> or z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*>) or z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*>) or z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*>"
            using binarith_th_14 sorry
          have case1: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
          proof(rule impI)
            assume A34: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*>"
            have A35: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A36: "i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
              then have A37: "i =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_2 tarski_def_1 sorry
              have "F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A34 A36 finseq_1_th_2 tarski_def_1 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A34 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                using A37 binarith_def_2 sorry
              finally show "F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                 sorry
            qed "sorry"
            have "add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              using A31 A34 finseq_4_th_16 sorry
            then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
              using funcop_1_def_8 sorry
            thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
              using A33 A34 A35 binarith_def_5 sorry
          qed
          have case2: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
          proof(rule impI)
            assume A38: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*>"
            have A39: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume A40: "i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
              then have A41: "i =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_2 tarski_def_1 sorry
              have "T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (FALSEMARGREL1K6))'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A38 A40 finseq_1_th_2 tarski_def_1 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A38 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                using A41 binarith_def_2 sorry
              finally show "T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                 sorry
            qed "sorry"
            have "add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              using A31 A38 finseq_4_th_16 sorry
            then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
              using funcop_1_def_8 sorry
            thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
              using A33 A38 A39 binarith_def_5 sorry
          qed
          have case3: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> FALSEMARGREL1K6 *> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
          proof(rule impI)
            assume A42: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*>"
            have A43: " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume "i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
              then have A44: "i =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_2 tarski_def_1 sorry
              then have "T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ('not'MARGREL1K10 (TRUEMARGREL1K7) 'xor'BINARITHK2 (TRUEMARGREL1K7))'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (TRUEMARGREL1K7))'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A42 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A42 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                using A44 binarith_def_2 sorry
              finally show "T /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                 sorry
            qed "sorry"
            have "add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2) =XBOOLE-0R4 ?f"
              using A31 A42 finseq_4_th_16 sorry
            then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 0NUMBERSK6"
              using funcop_1_def_8 sorry
            thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
              using A33 A42 A43 binarith_def_5 sorry
          qed
          have case4: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> TRUEMARGREL1K7 *> implies AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
          proof(rule impI)
            assume A45: "z1 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*> & z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?t*>"
            have " for i be NatNAT-1M1 holds i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M implies F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
            proof(rule ballI,rule impI)
              fix i assume [ty]: "i be NatNAT-1M1"
              assume "i inHIDDENR3 SegFINSEQ-1K2 \<one>\<^sub>M"
              then have A46: "i =XBOOLE-0R4 \<one>\<^sub>M"
                using finseq_1_th_2 tarski_def_1 sorry
              then have "F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 ((TRUEMARGREL1K7)'xor'BINARITHK2 (TRUEMARGREL1K7))'xor'BINARITHK2 'not'MARGREL1K10 (TRUEMARGREL1K7)"
                using finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 (TRUEMARGREL1K7))'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A45 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> \<one>\<^sub>M)'xor'BINARITHK2 (FALSEMARGREL1K6)"
                using A45 finseq_4_th_16 sorry
              also have "... = (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                using A46 binarith_def_2 sorry
              finally show "F /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i =HIDDENR1 (z1 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i 'xor'BINARITHK2 z2 /.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i)'xor'BINARITHK2 (carryBINARITHK4\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2))/.PARTFUN1K7\<^bsub>(BOOLEANMARGREL1K5)\<^esub> i"
                 sorry
            qed "sorry"
            then have A47: "z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2 =FINSEQ-1R1 <*BINARITHK10\<^bsub>(BOOLEANMARGREL1K5)\<^esub> ?f*>"
              using binarith_def_5 sorry
            have "add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2) =XBOOLE-0R4 ?t"
              using A31 A45 finseq_4_th_16 sorry
            then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M"
              using funcop_1_def_8 sorry
            also have "... = \<two>\<^sub>M"
              using power_th_25 sorry
            finally have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M"
               sorry
            thus "AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> (z1 +BINARITHK7\<^bsub>(\<one>\<^sub>M)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(\<one>\<^sub>M)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 \<one>\<^sub>M) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(\<one>\<^sub>M)\<^esub> z2"
              using A32 A33 A45 A47 sorry
          qed
          show " ?thesis "
            using cases case1 case2 case3 case4 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
      using nat_1_sch_10 A30 A1 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem binarith_th_22:
" for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub> implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) =XBOOLE-0R4 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
proof-
  have " for n be  non zeroORDINAL1V8\<bar>NatNAT-1M1 holds  for z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds  for z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5) holds (z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub> implies AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be  non zeroORDINAL1V8\<bar>NatNAT-1M1"
    fix z1 assume [ty]: "z1 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    fix z2 assume [ty]: "z2 be TupleFINSEQ-2M3-of(n,BOOLEANMARGREL1K5)"
    assume "(z1,z2)are-summableBINARITHR1\<^bsub>(n)\<^esub>"
    then have "add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2) =XBOOLE-0R4 FALSEMARGREL1K6"
       sorry
    then have "IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n) =XBOOLE-0R4 0NUMBERSK6"
      using funcop_1_def_8 sorry
    then have "AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) +NAT-1K1 IFEQFUNCOP-1K16\<^bsub>(NATNUMBERSK1)\<^esub>(add-ovflBINARITHK8\<^bsub>(n)\<^esub>(z1,z2),FALSEMARGREL1K6,0NUMBERSK6,\<two>\<^sub>M to-powerSERIES-1K5 n)"
       sorry
    also have "... = AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
      using binarith_th_21 sorry
    finally show "AbsvalBINARITHK6\<^bsub>(n)\<^esub> (z1 +BINARITHK7\<^bsub>(n)\<^esub> z2) =HIDDENR1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z1 +NAT-1K1 AbsvalBINARITHK6\<^bsub>(n)\<^esub> z2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
