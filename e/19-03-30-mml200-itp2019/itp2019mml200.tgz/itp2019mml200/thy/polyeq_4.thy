theory polyeq_4
  imports polyeq_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, a, b, c, p, q for "RealXREAL-0M1"
reserve m, n for "ElementSUBSET-1M1-of NATNUMBERSK1"
mtheorem polyeq_4_th_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & (c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6"
      and A2: "c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      and A3: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
    have A4: "b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >=XXREAL-0R2 0NUMBERSK6"
      using A3 quin_1_def_1 sorry
    have "(b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6) or (b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) & (b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)"
    proof-
      show "(b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6) or (b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) & (b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)"
      proof-
        have cases: "b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 or b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
          using A1 xreal_1_th_143 sorry
        have case1: "b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A5: "b <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6"
          have A6: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A4 square_1_th_17 square_1_th_26 sorry
          have A7: "\<two>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
            using A5 xreal_1_th_129 sorry
          have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
            using A5 xreal_1_th_58 sorry
          then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
            using A6 sorry
          then have A8: "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A7 xreal_1_th_139 sorry
          have "c >XXREAL-0R4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
            using A2 A5 xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using A4 square_1_th_27 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 -XCMPLX-0K4 b"
            using A5 square_1_th_23 sorry
          then have "-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 -XCMPLX-0K4 (-XCMPLX-0K4 b)"
            using xreal_1_th_24 sorry
          then have "(-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))+XCMPLX-0K2 (-XCMPLX-0K4 b) >XXREAL-0R4 (-XCMPLX-0K4 (-XCMPLX-0K4 b))+XCMPLX-0K2 (-XCMPLX-0K4 b)"
            using xreal_1_th_8 sorry
          then have "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A7 xreal_1_th_139 sorry
          thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A8 quin_1_def_1 sorry
        qed
        have case2: "b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A9: "b >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
          then have A10: "a *XCMPLX-0K3 \<two>\<^sub>M <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 \<two>\<^sub>M"
            using xreal_1_th_68 sorry
          have "c <XXREAL-0R3 0NUMBERSK6"
            using A2 A9 sorry
          then have "a *XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
            using A9 xreal_1_th_130 sorry
          then have "\<four>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using A4 square_1_th_27 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b"
            using A9 square_1_th_22 sorry
          then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 (0NUMBERSK6 +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 b)"
            using xreal_1_th_8 sorry
          then have A11: "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A10 xreal_1_th_140 sorry
          have A12: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A4 square_1_th_17 square_1_th_26 sorry
          have "-XCMPLX-0K4 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6"
            using A9 sorry
          then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A12 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) +XCMPLX-0K2 b)) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_62 sorry
          then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A10 xreal_1_th_140 sorry
          thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
            using A11 quin_1_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_2:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (b /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & (c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "b /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      and A2: "c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      and A3: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
    have A4: "b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >=XXREAL-0R2 0NUMBERSK6"
      using A3 quin_1_def_1 sorry
    have "(b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) or (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) & (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6)"
    proof-
      show "(b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) or (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) & (b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6)"
      proof-
        have cases: "b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
          using A1 xreal_1_th_144 sorry
        have case1: "b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
        proof(rule impI)
          assume A5: "b >XXREAL-0R4 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6"
          then have "c >XXREAL-0R4 0NUMBERSK6 & \<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
            using A2 xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using A4 square_1_th_27 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b"
            using A5 square_1_th_22 sorry
          then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 (b +XCMPLX-0K2 (-XCMPLX-0K4 b))"
            using xreal_1_th_8 sorry
          then have A6: "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A5 xreal_1_th_129 xreal_1_th_141 sorry
          have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A4 square_1_th_17 square_1_th_26 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A5 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))) >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A5 xreal_1_th_129 xreal_1_th_141 sorry
          thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A6 quin_1_def_1 sorry
        qed
        have case2: "b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
        proof(rule impI)
          assume A7: "b <XXREAL-0R3 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
          have A8: "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A4 square_1_th_17 square_1_th_26 sorry
          have A9: "a *XCMPLX-0K3 \<two>\<^sub>M <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 \<two>\<^sub>M"
            using A7 xreal_1_th_68 sorry
          have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
            using A7 xreal_1_th_58 sorry
          then have "0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6 <XXREAL-0R3 (-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)"
            using A8 sorry
          then have A10: "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A9 xreal_1_th_142 sorry
          have "c <XXREAL-0R3 0NUMBERSK6"
            using A2 A7 sorry
          then have "a *XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
            using A7 xreal_1_th_130 sorry
          then have "\<four>\<^sub>M *XCMPLX-0K3 (a *XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_129 sorry
          then have "-XCMPLX-0K4 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 0NUMBERSK6"
             sorry
          then have "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 0NUMBERSK6"
             sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using A4 square_1_th_27 sorry
          then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 -XCMPLX-0K4 b"
            using A7 square_1_th_23 sorry
          then have "b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 (0NUMBERSK6 +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 b)"
            using xreal_1_th_8 sorry
          then have "-XCMPLX-0K4 (b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)) >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_58 sorry
          then have "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A9 xreal_1_th_142 sorry
          thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
            using A10 quin_1_def_1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_3:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 implies ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 or ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 & ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds c /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "c /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6"
    have "(c >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) &  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)) or (c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & (c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)))"
    proof-
      show "(c >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6) &  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)) or (c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6) & (c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6)))"
      proof-
        have cases: "c >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 or c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6"
          using A1 xreal_1_th_143 sorry
        have case1: "c >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
        proof(rule impI)
          assume A2: "c >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 0NUMBERSK6"
          then have "\<four>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 \<four>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
            using xreal_1_th_68 sorry
          then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 (0NUMBERSK6)*XCMPLX-0K3 c"
            using A2 xreal_1_th_68 sorry
          then have A3: "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_58 sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have A4: "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using square_1_th_27 xreal_1_th_63 sorry
          have A5: "\<two>\<^sub>M *XCMPLX-0K3 a <XXREAL-0R3 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
            using A2 xreal_1_th_68 sorry
          have "(-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 b ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
            using A3 xreal_1_th_8 xreal_1_th_63 sorry
          then have A6: "-XCMPLX-0K4 (-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)) >XXREAL-0R4 0NUMBERSK6"
            using square_1_th_17 square_1_th_27 sorry
          then have A7: "-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
             sorry
          have " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
          proof-
            show " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
            proof-
              have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
                 sorry
              have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
              proof(rule impI)
                assume A8: "b >=XXREAL-0R2 0NUMBERSK6"
                then have "-XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
                   sorry
                then have "(-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))+XCMPLX-0K2 (-XCMPLX-0K4 b) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
                  using A7 sorry
                then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
                   sorry
                then have A9: "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) <XXREAL-0R3 0NUMBERSK6"
                  using quin_1_def_1 sorry
                have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 b"
                  using A4 A8 square_1_th_22 sorry
                then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 (0NUMBERSK6 +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 b)"
                  using xreal_1_th_8 sorry
                then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
                  using A5 xreal_1_th_142 sorry
                thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
                  using A5 A9 quin_1_def_1 xreal_1_th_140 sorry
              qed
              have case2: "b <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
              proof(rule impI)
                assume A10: "b <XXREAL-0R3 0NUMBERSK6"
                then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 -XCMPLX-0K4 b"
                  using A4 square_1_th_23 sorry
                then have "-XCMPLX-0K4 (-XCMPLX-0K4 (b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))) >XXREAL-0R4 0NUMBERSK6"
                  using xreal_1_th_62 sorry
                then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
                   sorry
                then have A11: "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
                  using A5 xreal_1_th_140 sorry
                have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
                  using A10 xreal_1_th_58 sorry
                then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) +XCMPLX-0K2 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
                  using A6 sorry
                then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) +XCMPLX-0K2 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
                  using quin_1_def_1 sorry
                thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
                  using A5 A11 quin_1_def_1 xreal_1_th_142 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
             sorry
        qed
        have case2: "c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
        proof(rule impI)
          assume A12: "c <XXREAL-0R3 0NUMBERSK6 & a >XXREAL-0R4 0NUMBERSK6"
          then have "\<four>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_129 sorry
          then have "(\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c <XXREAL-0R3 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 (0NUMBERSK6)"
            using A12 xreal_1_th_68 sorry
          then have A13: "-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_58 sorry
          then have "b ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 b ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
            using xreal_1_th_8 sorry
          then have A14: "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 sqrtSQUARE-1K3 b ^2SQUARE-1K1"
            using square_1_th_27 xreal_1_th_63 sorry
          have A15: "\<two>\<^sub>M *XCMPLX-0K3 a >XXREAL-0R4 0NUMBERSK6"
            using A12 xreal_1_th_129 sorry
          have "(-XCMPLX-0K4 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)+XCMPLX-0K2 b ^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
            using A13 xreal_1_th_8 xreal_1_th_63 sorry
          then have A16: "-XCMPLX-0K4 (-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c)) >XXREAL-0R4 0NUMBERSK6"
            using square_1_th_17 square_1_th_27 sorry
          then have A17: "-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
             sorry
          have " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
          proof-
            show " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
            proof-
              have cases: "b >=XXREAL-0R2 0NUMBERSK6 or b <XXREAL-0R3 0NUMBERSK6"
                 sorry
              have case1: "b >=XXREAL-0R2 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
              proof(rule impI)
                assume A18: "b >=XXREAL-0R2 0NUMBERSK6"
                then have "-XCMPLX-0K4 b <=XXREAL-0R1 -XCMPLX-0K4 0NUMBERSK6"
                   sorry
                then have "(-XCMPLX-0K4 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))+XCMPLX-0K2 (-XCMPLX-0K4 b) <XXREAL-0R3 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
                  using A17 sorry
                then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
                   sorry
                then have A19: "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) <XXREAL-0R3 0NUMBERSK6"
                  using quin_1_def_1 sorry
                have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 b"
                  using A14 A18 square_1_th_22 sorry
                then have "(-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 (0NUMBERSK6 +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 b)"
                  using xreal_1_th_8 sorry
                then have "((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6"
                  using A15 xreal_1_th_139 sorry
                thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
                  using A12 A19 quin_1_def_1 xreal_1_th_129 xreal_1_th_141 sorry
              qed
              have case2: "b <XXREAL-0R3 0NUMBERSK6 implies  not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
              proof(rule impI)
                assume A20: "b <XXREAL-0R3 0NUMBERSK6"
                then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) >XXREAL-0R4 -XCMPLX-0K4 b"
                  using A14 square_1_th_23 sorry
                then have "-XCMPLX-0K4 (-XCMPLX-0K4 (b +XCMPLX-0K2 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))) >XXREAL-0R4 0NUMBERSK6"
                  using xreal_1_th_62 sorry
                then have "(-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) <XXREAL-0R3 0NUMBERSK6"
                   sorry
                then have A21: "((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6"
                  using A12 xreal_1_th_129 xreal_1_th_141 sorry
                have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
                  using A20 xreal_1_th_58 sorry
                then have "sqrtSQUARE-1K3 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c) +XCMPLX-0K2 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
                  using A16 sorry
                then have "sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)) +XCMPLX-0K2 (-XCMPLX-0K4 b) >XXREAL-0R4 0NUMBERSK6"
                  using quin_1_def_1 sorry
                thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
                  using A15 A21 quin_1_def_1 xreal_1_th_139 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6) &  not ( not ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) <XXREAL-0R3 0NUMBERSK6 &  not ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) >XXREAL-0R4 0NUMBERSK6))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_4:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a >XXREAL-0R4 0NUMBERSK6 & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & x  |^NEWTONK1 n =HIDDENR1 a implies x =HIDDENR1 n -rootPOWERK1 a or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a >XXREAL-0R4 0NUMBERSK6 & (n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M) implies (x  |^NEWTONK1 n =HIDDENR1 a implies  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "n be evenABIANV3"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
    assume A4: "x  |^NEWTONK1 n =HIDDENR1 a"
    then have A5: "x <>HIDDENR2 0NUMBERSK6"
      using A1 A3 newton_th_11 sorry
    have "x >XXREAL-0R4 0NUMBERSK6 &  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a) or x <XXREAL-0R3 0NUMBERSK6 & (x <XXREAL-0R3 0NUMBERSK6 implies  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a))"
    proof-
      show "x >XXREAL-0R4 0NUMBERSK6 &  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a) or x <XXREAL-0R3 0NUMBERSK6 & (x <XXREAL-0R3 0NUMBERSK6 implies  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a))"
      proof-
        have cases: "x >XXREAL-0R4 0NUMBERSK6 or x <XXREAL-0R3 0NUMBERSK6"
          using A5 sorry
        have case1: "x >XXREAL-0R4 0NUMBERSK6 implies  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a)"
        proof(rule impI)
          assume "x >XXREAL-0R4 0NUMBERSK6"
          thus " not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a)"
            using A4 A3 power_th_4 sorry
        qed
        have case2: "x <XXREAL-0R3 0NUMBERSK6 implies  not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a)"
        proof(rule impI)
          assume "x <XXREAL-0R3 0NUMBERSK6"
          then have A6: "-XCMPLX-0K4 x >XXREAL-0R4 0NUMBERSK6"
            using xreal_1_th_58 sorry
          have "n -rootPOWERK1 a =HIDDENR1 n -rootPOWERK1 ((-XCMPLX-0K4 x) |^NEWTONK1 n)"
            using A2 A4 power_th_1 sorry
          then have "(-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 n -rootPOWERK1 a =HIDDENR1 (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 x)"
            using A3 A6 power_th_4 sorry
          thus " not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a)"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not x =HIDDENR1 n -rootPOWERK1 a &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_5:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies  not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6"
    have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
      using A2 polyeq_1_def_2 sorry
    then have "((a *XCMPLX-0K3 x +XCMPLX-0K2 b)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x =HIDDENR1 0NUMBERSK6"
       sorry
    then have "(a *XCMPLX-0K3 x +XCMPLX-0K2 b)+XCMPLX-0K2 (-XCMPLX-0K4 b) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 b) or x =HIDDENR1 0NUMBERSK6"
      using xcmplx_1_th_6 sorry
    then have "x =HIDDENR1 (-XCMPLX-0K4 b)/XCMPLX-0K7 a or x =HIDDENR1 0NUMBERSK6"
      using A1 xcmplx_1_th_89 sorry
    thus " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a)"
      using xcmplx_1_th_187 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_6:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-1K2(a,0NUMBERSK6,0NUMBERSK6,x) =HIDDENR1 0NUMBERSK6"
    have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x)+XCMPLX-0K2 0NUMBERSK6 =HIDDENR1 0NUMBERSK6"
      using A2 polyeq_1_def_2 sorry
    then have "x ^2SQUARE-1K1 =HIDDENR1 0NUMBERSK6"
      using A1 sorry
    thus "x =HIDDENR1 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_7:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a <>HIDDENR2 0NUMBERSK6 & (n be oddABIANV2 & (deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6)) implies  not ( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "n be oddABIANV2"
      and A3: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6"
    have "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      using A1 A3 polyeq_1_th_5 sorry
    thus " not ( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      using A2 power_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_8:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((a <>HIDDENR2 0NUMBERSK6 & b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6) & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies ((x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a <>HIDDENR2 0NUMBERSK6 & ((((b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & (deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6 & PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6)) implies  not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "((b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & c /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "deltaQUIN-1K1(a,b,c) >=XXREAL-0R2 0NUMBERSK6"
      and A4: "PolynomPOLYEQ-1K2(a,b,c,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6"
    have " not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
    proof-
      show " not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      proof-
        have cases: "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          using A1 A3 A4 polyeq_1_th_5 sorry
        have case1: "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          then have "x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
            using A2 A3 polyeq_4_th_1 polyeq_4_th_4 sorry
          thus " not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
             sorry
        qed
        have case2: "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 ((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
          then have "x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
            using A2 A3 polyeq_4_th_1 polyeq_4_th_4 sorry
          thus " not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ((( not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (((-XCMPLX-0K4 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,b,c)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_9:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (a <>HIDDENR2 0NUMBERSK6 & n be oddABIANV2) & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a <>HIDDENR2 0NUMBERSK6 & (n be oddABIANV2 & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6) implies  not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "n be oddABIANV2"
      and A3: "PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6"
    have " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
    proof-
      show " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
      proof-
        have cases: "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6 or x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
          using A1 A3 polyeq_4_th_5 sorry
        have case1: "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6 implies  not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6"
          thus " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
            using prepower_th_5 sorry
        qed
        have case2: "x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a implies  not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
          thus " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
            using A2 power_th_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_10:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((a <>HIDDENR2 0NUMBERSK6 & b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 0NUMBERSK6 or x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a <>HIDDENR2 0NUMBERSK6 & (b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6 & ((n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M) & PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6)) implies  not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
      and A2: "b /XCMPLX-0K7 a <XXREAL-0R3 0NUMBERSK6"
      and A3: "n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "PolynomPOLYEQ-1K2(a,b,0NUMBERSK6,x  |^NEWTONK1 n) =HIDDENR1 0NUMBERSK6"
    have A5: "-XCMPLX-0K4 b /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_th_58 sorry
    have " not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
    proof-
      show " not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
      proof-
        have cases: "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6 or x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
          using A1 A4 polyeq_4_th_5 sorry
        have case1: "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6"
          thus " not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
            using prepower_th_5 sorry
        qed
        have case2: "x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a implies  not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 -XCMPLX-0K4 b /XCMPLX-0K7 a"
          thus " not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
            using A3 A5 polyeq_4_th_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (( not x =HIDDENR1 0NUMBERSK6 &  not x =HIDDENR1 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a)) &  not x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (-XCMPLX-0K4 b /XCMPLX-0K7 a))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) & a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) & a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    have A1: "(a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M) =HIDDENR1 (((((a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b))+XCMPLX-0K2 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))-XCMPLX-0K6 (a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
       sorry
    also have "... = (((((a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<one>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 (a +XCMPLX-0K2 b))+XCMPLX-0K2 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))-XCMPLX-0K6 (a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
       sorry
    also have "... = ((((a  |^NEWTONK1 (\<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 ((a +XCMPLX-0K2 b)+XCMPLX-0K2 0NUMBERSK6))+XCMPLX-0K2 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))-XCMPLX-0K6 (a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 (a +XCMPLX-0K2 b))+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 (a +XCMPLX-0K2 b)"
      using newton_th_8 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 ((a *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 b +XCMPLX-0K2 b *XCMPLX-0K3 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)))+XCMPLX-0K2 (a *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M) +XCMPLX-0K2 b *XCMPLX-0K3 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)))-XCMPLX-0K6 (a *XCMPLX-0K3 (a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M) +XCMPLX-0K2 b *XCMPLX-0K3 (a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M)"
       sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (b *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 (b *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)*XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M)"
      using polyeq_2_th_4 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 ((a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (b *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M)"
      using polyeq_2_th_4 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 (b  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b)"
      using newton_th_6 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 (\<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M))"
      using newton_th_6 sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 (\<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M))"
       sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 (b  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 b)*XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 (\<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M))"
       sorry
    also have "... = ((((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a  |^NEWTONK1 \<four>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 b +XCMPLX-0K2 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 a  |^NEWTONK1 \<three>\<^sub>M))+XCMPLX-0K2 (a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 a  |^NEWTONK1 \<two>\<^sub>M))-XCMPLX-0K6 ((a  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M *XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)-XCMPLX-0K6 (a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M))+XCMPLX-0K2 (a *XCMPLX-0K3 b  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M"
       sorry
    finally have "(a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M"
       sorry
    have "((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 ((a ^2SQUARE-1K1 *XCMPLX-0K3 a +XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (a *XCMPLX-0K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 b *XCMPLX-0K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 ((a *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 b ^2SQUARE-1K1)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 b ^2SQUARE-1K1)"
       sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (a *XCMPLX-0K3 (a *XCMPLX-0K3 b) +XCMPLX-0K2 b *XCMPLX-0K3 (a *XCMPLX-0K3 b)))+XCMPLX-0K2 (a *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 b *XCMPLX-0K3 b ^2SQUARE-1K1)"
      using polyeq_2_th_4 sorry
    also have "... = ((a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (a ^2SQUARE-1K1 *XCMPLX-0K3 b +XCMPLX-0K2 (b *XCMPLX-0K3 b)*XCMPLX-0K3 a))+XCMPLX-0K2 (a *XCMPLX-0K3 b ^2SQUARE-1K1 +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M)"
      using polyeq_2_th_4 sorry
    also have "... = a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    finally have "((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1)*XCMPLX-0K3 (a +XCMPLX-0K2 b) =HIDDENR1 a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M"
       sorry
    thus "a  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<three>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((a ^2SQUARE-1K1 -XCMPLX-0K6 a *XCMPLX-0K3 b)+XCMPLX-0K2 b ^2SQUARE-1K1) & a  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b  |^NEWTONK1 \<five>\<^sub>M =HIDDENR1 (a +XCMPLX-0K2 b)*XCMPLX-0K3 ((((a  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b)+XCMPLX-0K2 a  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 b  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 b  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 b  |^NEWTONK1 \<four>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_12:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K4(a,b,b,a,x) =HIDDENR1 0NUMBERSK6 implies (x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6) & PolynomPOLYEQ-1K4(a,b,b,a,x) =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1 >=XXREAL-0R2 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-1K4(a,b,b,a,x) =HIDDENR1 0NUMBERSK6"
    have "((a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
      using A2 polyeq_1_def_4 sorry
    then have "(x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 ((x ^2SQUARE-1K1 +XCMPLX-0K2 x)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 b =HIDDENR1 0NUMBERSK6"
       sorry
    then have "(x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M to-powerPOWERK2 \<three>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 ((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b =HIDDENR1 0NUMBERSK6"
       sorry
    then have "((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 x *XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M ^2SQUARE-1K1))*XCMPLX-0K3 a +XCMPLX-0K2 ((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b =HIDDENR1 0NUMBERSK6"
      using polyeq_4_th_11 sorry
    then have A3: "(((x ^2SQUARE-1K1 *XCMPLX-0K3 a -XCMPLX-0K6 x *XCMPLX-0K3 a)+XCMPLX-0K2 x *XCMPLX-0K3 b)+XCMPLX-0K2 a)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M) =HIDDENR1 0NUMBERSK6"
       sorry
    have "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or (a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 & ((a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
    proof-
      show "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) or (a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 & ((a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)))"
      proof-
        have cases: "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 or (a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
          using A3 sorry
        have case1: "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
        proof(rule impI)
          assume "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
          thus " not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
             sorry
        qed
        have case2: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
        proof(rule impI)
          assume A4: "(a *XCMPLX-0K3 x ^2SQUARE-1K1 -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
          have A5: "deltaQUIN-1K1(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a) =HIDDENR1 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a"
            using quin_1_def_1 sorry
          also have "... = (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 a ^2SQUARE-1K1"
             sorry
          finally have "deltaQUIN-1K1(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a) =HIDDENR1 (b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 (-XCMPLX-0K4 (\<four>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 a ^2SQUARE-1K1"
             sorry
          have "(a *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
            using A4 sorry
          then have "PolynomPOLYEQ-1K2(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a,x) =HIDDENR1 0NUMBERSK6"
            using polyeq_1_def_2 sorry
          then have "x =HIDDENR1 ((-XCMPLX-0K4 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b))+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) or x =HIDDENR1 ((-XCMPLX-0K4 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b))-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
            using A1 A5 polyeq_1_th_5 sorry
          thus " not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
            using A5 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)) &  not x =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 ((b ^2SQUARE-1K1 -XCMPLX-0K6 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)-XCMPLX-0K6 \<three>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef polyeq_4_def_1 ("PolynomPOLYEQ-4K1'( _ , _ , _ , _ , _ , _ , _ ')" [0,0,0,0,0,0,0]164 ) where
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "f be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"func PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) \<rightarrow> setHIDDENM2 equals
  ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 d *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 e *XCMPLX-0K3 x)+XCMPLX-0K2 f"
proof-
  (*coherence*)
    show "((((a *XCMPLX-0K3 x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 b *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 d *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 e *XCMPLX-0K3 x)+XCMPLX-0K2 f be setHIDDENM2"
       sorry
qed "sorry"

mtheorem polyeq_4_cl_1:
  mlet "a be ComplexXCMPLX-0M1", "b be ComplexXCMPLX-0M1", "c be ComplexXCMPLX-0M1", "d be ComplexXCMPLX-0M1", "e be ComplexXCMPLX-0M1", "f be ComplexXCMPLX-0M1", "x be ComplexXCMPLX-0M1"
"cluster PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem polyeq_4_cl_2:
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1", "c be RealXREAL-0M1", "d be RealXREAL-0M1", "e be RealXREAL-0M1", "f be RealXREAL-0M1", "x be RealXREAL-0M1"
"cluster PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "PolynomPOLYEQ-4K1(a,b,c,d,e,f,x) be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem polyeq_4_th_13:
" for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6) & PolynomPOLYEQ-4K1(a,b,c,c,b,a,x) =HIDDENR1 0NUMBERSK6 implies ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & y2 =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies (((x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M or x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a <>HIDDENR2 0NUMBERSK6 & ((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6) & PolynomPOLYEQ-4K1(a,b,c,c,b,a,x) =HIDDENR1 0NUMBERSK6 implies ( for y1 be RealXREAL-0M1 holds  for y2 be RealXREAL-0M1 holds y1 =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) & y2 =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a) implies  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6 & ((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c >XXREAL-0R4 0NUMBERSK6"
      and A2: "PolynomPOLYEQ-4K1(a,b,c,c,b,a,x) =HIDDENR1 0NUMBERSK6"
    fix y1 assume [ty]: "y1 be RealXREAL-0M1"
    fix y2 assume [ty]: "y2 be RealXREAL-0M1"
    assume A3: "y1 =HIDDENR1 ((a -XCMPLX-0K6 b)+XCMPLX-0K2 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
      and A4: "y2 =HIDDENR1 ((a -XCMPLX-0K6 b)-XCMPLX-0K6 sqrtSQUARE-1K3 (((b ^2SQUARE-1K1 +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 b)+XCMPLX-0K2 \<five>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1)-XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 c))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
    have A5: "0NUMBERSK6 =HIDDENR1 ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 x)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 b)+XCMPLX-0K2 ((c *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 c)"
      using A2 sorry
    also have "... = ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<five>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (x  |^NEWTONK1 (\<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) +XCMPLX-0K2 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<five>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (x  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) +XCMPLX-0K2 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
      using newton_th_6 sorry
    also have "... = ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<five>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 ((x *XCMPLX-0K3 x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
      using newton_th_6 sorry
    also have "... = ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<five>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 ((x *XCMPLX-0K3 (x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x) +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
      using newton_th_6 sorry
    also have "... = ((x  |^NEWTONK1 \<five>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<five>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 (((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 ((x *XCMPLX-0K3 x ^2SQUARE-1K1 +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 (0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M)-XCMPLX-0K6 x *XCMPLX-0K3 \<one>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (((x +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
      using polyeq_4_th_11 sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)-XCMPLX-0K6 x *XCMPLX-0K3 \<one>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (((x +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 x *XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (((x +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 x)+XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 (((x +XCMPLX-0K2 \<one>\<^sub>M)+XCMPLX-0K2 0NUMBERSK6)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 x)+XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M  |^NEWTONK11 \<three>\<^sub>M)*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 ((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
       sorry
    also have "... = (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((((x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 x)+XCMPLX-0K2 \<one>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 (((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 ((x ^2SQUARE-1K1 -XCMPLX-0K6 x *XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M ^2SQUARE-1K1))*XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 ((x +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 x ^2SQUARE-1K1)*XCMPLX-0K3 c"
      using polyeq_4_th_11 sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((((x *XCMPLX-0K3 x)*XCMPLX-0K3 x)*XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((((x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 x)*XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 (x *XCMPLX-0K3 x)*XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((((x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 x)*XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 (x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((((x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 x)*XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 (((x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 x)*XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((x  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 b -XCMPLX-0K6 (x *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 (x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x)*XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    also have "... = ((((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 a *XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 a *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 a *XCMPLX-0K3 x)+XCMPLX-0K2 a)+XCMPLX-0K2 ((x  |^NEWTONK1 \<three>\<^sub>M *XCMPLX-0K3 b -XCMPLX-0K6 x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M) *XCMPLX-0K3 b)+XCMPLX-0K2 b *XCMPLX-0K3 x))+XCMPLX-0K2 x  |^NEWTONK1 \<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    finally have "0NUMBERSK6 =HIDDENR1 ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a)*XCMPLX-0K3 (x +XCMPLX-0K2 \<one>\<^sub>M)"
       sorry
    have "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 & ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M))"
    proof-
      show "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 &  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) or (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 & ((((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M))"
      proof-
        have cases: "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 or (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
          using A5 sorry
        have case1: "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6 implies  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
        proof(rule impI)
          assume "x +XCMPLX-0K2 \<one>\<^sub>M =HIDDENR1 0NUMBERSK6"
          thus " not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
             sorry
        qed
        have case2: "(((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6 implies  not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
        proof(rule impI)
          assume A6: "(((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M -XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M)-XCMPLX-0K6 (a -XCMPLX-0K6 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a =HIDDENR1 0NUMBERSK6"
          let ?y = "x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 x"
          have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M))+XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a"
            using A6 sorry
          also have "... = (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 (x  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 x))+XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a"
            using newton_th_6 sorry
          also have "... = (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a"
             sorry
          finally have "0NUMBERSK6 =HIDDENR1 (((a *XCMPLX-0K3 x  |^NEWTONK1 \<four>\<^sub>M +XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x  |^NEWTONK1 \<three>\<^sub>M)+XCMPLX-0K2 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b)*XCMPLX-0K3 x ^2SQUARE-1K1)+XCMPLX-0K2 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b)*XCMPLX-0K3 x)+XCMPLX-0K2 a"
             sorry
          then have A7: "PolynomPOLYEQ-2K1(a,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,(a +XCMPLX-0K2 c)-XCMPLX-0K6 b,(-XCMPLX-0K4 a)+XCMPLX-0K2 b,a,x) =HIDDENR1 0NUMBERSK6"
            using polyeq_2_def_1 sorry
          have "?y =HIDDENR1 x +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 x & y1 =HIDDENR1 ((-XCMPLX-0K4 ((-XCMPLX-0K4 a)+XCMPLX-0K2 b))+XCMPLX-0K2 sqrtSQUARE-1K3 ((((-XCMPLX-0K4 a)+XCMPLX-0K2 b)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 ((a +XCMPLX-0K2 c)-XCMPLX-0K6 b))+XCMPLX-0K2 \<eight>\<^sub>M *XCMPLX-0K3 a ^2SQUARE-1K1))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 a)"
            using A3 sorry
          thus " not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
            using A1 A4 A7 polyeq_2_th_3 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not (((( not x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M &  not x =HIDDENR1 (y1 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y1 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y1,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M) &  not x =HIDDENR1 (y2 -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 y2,\<one>\<^sub>M)))/XCMPLX-0K7 \<two>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_14:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds (x +XCMPLX-0K2 y =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6 implies x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M or x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds x +XCMPLX-0K2 y =HIDDENR1 p & (x *XCMPLX-0K3 y =HIDDENR1 q & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) implies  not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    assume A1: "x +XCMPLX-0K2 y =HIDDENR1 p"
      and A2: "x *XCMPLX-0K3 y =HIDDENR1 q"
      and A3: "p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6"
    have A4: "deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q) =HIDDENR1 (-XCMPLX-0K4 p)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 q"
      using quin_1_def_1 sorry
    also have "... = p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q"
       sorry
    finally have "deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q) =HIDDENR1 p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q"
       sorry
    have "(\<one>\<^sub>M *XCMPLX-0K3 y ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 p)*XCMPLX-0K3 y)+XCMPLX-0K2 q =HIDDENR1 0NUMBERSK6"
      using A1 A2 sorry
    then have "PolynomPOLYEQ-1K2(\<one>\<^sub>M,-XCMPLX-0K4 p,q,y) =HIDDENR1 0NUMBERSK6"
      using polyeq_1_def_2 sorry
    then have A5: "y =HIDDENR1 ((-XCMPLX-0K4 (-XCMPLX-0K4 p))+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M) or y =HIDDENR1 ((-XCMPLX-0K4 (-XCMPLX-0K4 p))-XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 (\<two>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)"
      using A3 A4 polyeq_1_th_5 sorry
    have " not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
    proof-
      show " not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
      proof-
        have cases: "y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M or y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M"
          using A5 sorry
        have case1: "y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M implies  not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
        proof(rule impI)
          assume A6: "y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M"
          then have "x =HIDDENR1 (p *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)) /XCMPLX-0K7 \<two>\<^sub>M)"
            using A1 sorry
          also have "... = (p *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q) /XCMPLX-0K7 \<two>\<^sub>M)"
            using A4 sorry
          finally have "x =HIDDENR1 (p *XCMPLX-0K3 \<two>\<^sub>M)/XCMPLX-0K7 \<two>\<^sub>M -XCMPLX-0K6 (p /XCMPLX-0K7 \<two>\<^sub>M +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q) /XCMPLX-0K7 \<two>\<^sub>M)"
             sorry
          thus " not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
            using A4 A6 sorry
        qed
        have case2: "y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M implies  not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
        proof(rule impI)
          assume A7: "y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))/XCMPLX-0K7 \<two>\<^sub>M"
          then have "x =HIDDENR1 p -XCMPLX-0K6 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)))+XCMPLX-0K2 0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M"
            using A1 sorry
          also have "... = p -XCMPLX-0K6 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))+XCMPLX-0K2 0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M"
            using A4 sorry
          finally have "x =HIDDENR1 p -XCMPLX-0K6 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))+XCMPLX-0K2 0NUMBERSK6)/XCMPLX-0K7 \<two>\<^sub>M"
             sorry
          thus " not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
            using A4 A7 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not (x =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) &  not (x =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_15:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) & n be oddABIANV2 implies x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) & n be oddABIANV2 implies  not ( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "(x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n be oddABIANV2"
    have "x  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M or x  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
      using A1 polyeq_4_th_14 sorry
    thus " not ( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
      using A2 power_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_16:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q) & p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6) & p >XXREAL-0R4 0NUMBERSK6) & q >XXREAL-0R4 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M implies ((((((x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q implies (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6 & (p >XXREAL-0R4 0NUMBERSK6 & (q >XXREAL-0R4 0NUMBERSK6 & (n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M))) implies  not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 p & x  |^NEWTONK1 n *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 q"
    assume A2: "p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q >=XXREAL-0R2 0NUMBERSK6"
      and A3: "p >XXREAL-0R4 0NUMBERSK6"
      and A4: "q >XXREAL-0R4 0NUMBERSK6"
      and A5: "n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M"
    have "-XCMPLX-0K4 (-XCMPLX-0K4 \<four>\<^sub>M *XCMPLX-0K3 q) >XXREAL-0R4 0NUMBERSK6"
      using A4 xreal_1_th_129 sorry
    then have "-XCMPLX-0K4 \<four>\<^sub>M *XCMPLX-0K3 q <XXREAL-0R3 0NUMBERSK6"
       sorry
    then have "p ^2SQUARE-1K1 +XCMPLX-0K2 (-XCMPLX-0K4 \<four>\<^sub>M *XCMPLX-0K3 q) <XXREAL-0R3 p ^2SQUARE-1K1 +XCMPLX-0K2 0NUMBERSK6"
      using xreal_1_th_8 sorry
    then have "sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q) <XXREAL-0R3 sqrtSQUARE-1K3 p ^2SQUARE-1K1"
      using A2 square_1_th_27 sorry
    then have "sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q) <XXREAL-0R3 p"
      using A3 square_1_th_22 sorry
    then have "-XCMPLX-0K4 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q) >XXREAL-0R4 -XCMPLX-0K4 p"
      using xreal_1_th_24 sorry
    then have "(-XCMPLX-0K4 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))+XCMPLX-0K2 p >XXREAL-0R4 ((-XCMPLX-0K4 p)+XCMPLX-0K2 0NUMBERSK6)+XCMPLX-0K2 p"
      using xreal_1_th_8 sorry
    then have A6: "((0NUMBERSK6 +XCMPLX-0K2 p)-XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using xreal_1_th_139 sorry
    have A7: "deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q) =HIDDENR1 (-XCMPLX-0K4 p)^2SQUARE-1K1 -XCMPLX-0K6 (\<four>\<^sub>M *XCMPLX-0K3 \<one>\<^sub>M)*XCMPLX-0K3 q"
      using quin_1_def_1 sorry
    also have "... = p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q"
       sorry
    finally have "deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q) =HIDDENR1 p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q"
       sorry
    then have "0NUMBERSK6 <=XXREAL-0R1 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q))"
      using A2 square_1_th_17 square_1_th_26 sorry
    then have "(-XCMPLX-0K4 (-XCMPLX-0K4 p))+XCMPLX-0K2 sqrtSQUARE-1K3 (deltaQUIN-1K1(\<one>\<^sub>M,-XCMPLX-0K4 p,q)) >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 0NUMBERSK6"
      using A3 sorry
    then have A8: "((0NUMBERSK6 +XCMPLX-0K2 p)+XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using A7 xreal_1_th_139 sorry
    have " not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
    proof-
      show " not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
      proof-
        have cases: "x  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M or x  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
          using A1 A2 polyeq_4_th_14 sorry
        have case1: "x  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M implies  not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
          thus " not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
            using A5 A8 A6 polyeq_4_th_4 sorry
        qed
        have case2: "x  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M implies  not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
        proof(rule impI)
          assume "x  |^NEWTONK1 n =HIDDENR1 (p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M & y  |^NEWTONK1 n =HIDDENR1 (p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M"
          thus " not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
            using A5 A8 A6 polyeq_4_th_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ((((((( not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p -XCMPLX-0K6 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((p +XCMPLX-0K2 sqrtSQUARE-1K3 (p ^2SQUARE-1K1 -XCMPLX-0K6 \<four>\<^sub>M *XCMPLX-0K3 q))/XCMPLX-0K7 \<two>\<^sub>M)))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_17:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((((x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 a & x  |^NEWTONK1 n -XCMPLX-0K6 y  |^NEWTONK1 n =HIDDENR1 b) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & a +XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6) & a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6 implies ((x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M) or x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 a & x  |^NEWTONK1 n -XCMPLX-0K6 y  |^NEWTONK1 n =HIDDENR1 b implies ((n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M) & (a +XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6 & a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6) implies  not ((( not (x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M))))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "x  |^NEWTONK1 n +XCMPLX-0K2 y  |^NEWTONK1 n =HIDDENR1 a & x  |^NEWTONK1 n -XCMPLX-0K6 y  |^NEWTONK1 n =HIDDENR1 b"
    assume A2: "n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "a +XCMPLX-0K2 b >XXREAL-0R4 0NUMBERSK6 & a -XCMPLX-0K6 b >XXREAL-0R4 0NUMBERSK6"
    have "(a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & (a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using A3 xreal_1_th_139 sorry
    thus " not ((( not (x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)) &  not (x =HIDDENR1 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M))) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a +XCMPLX-0K2 b)/XCMPLX-0K7 \<two>\<^sub>M) & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 ((a -XCMPLX-0K6 b)/XCMPLX-0K7 \<two>\<^sub>M)))"
      using A1 A2 polyeq_4_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_18:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6) & n be oddABIANV2) & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b) or x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & (x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6 & (n be oddABIANV2 & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6)) implies  not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
      and A2: "x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6"
      and A3: "n be oddABIANV2"
      and A4: "a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
    obtain m where
      [ty]:"m be NatORDINAL1M6" and 
      A5: "n =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 m +XCMPLX-0K2 \<one>\<^sub>M"
      using A3 abian_th_9 sorry
    have A6: "n >XXREAL-0R4 0NUMBERSK6"
      using A5 sorry
    have " not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
    proof-
      show " not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
      proof-
        have cases: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6"
          using A2 sorry
        have case1: "x =HIDDENR1 0NUMBERSK6 implies  not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
        proof(rule impI)
          assume A7: "x =HIDDENR1 0NUMBERSK6"
          then have "a *XCMPLX-0K3 (0NUMBERSK6)to-powerPOWERK2 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
            using A1 sorry
          then have "a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
            using A6 power_def_2 sorry
          then have "y  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 b"
            using A4 xcmplx_1_th_89 sorry
          thus " not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
            using A3 A7 power_th_4 sorry
        qed
        have case2: "y =HIDDENR1 0NUMBERSK6 implies  not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
        proof(rule impI)
          assume A8: "y =HIDDENR1 0NUMBERSK6"
          then have "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 (0NUMBERSK6)to-powerPOWERK2 n =HIDDENR1 p"
            using A1 sorry
          then have "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 p"
            using A6 power_def_2 sorry
          then have "x  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 a"
            using A4 xcmplx_1_th_89 sorry
          thus " not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
            using A3 A8 power_th_4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " not ( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_19:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((((a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & p /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6) & p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6 implies ((x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b) or x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b)) or x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p & (x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6 & ((n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M) & (p /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6 & (p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6)))) implies  not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
      and A2: "x *XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6"
      and A3: "n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "p /XCMPLX-0K7 b >XXREAL-0R4 0NUMBERSK6"
      and A5: "p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      and A6: "a *XCMPLX-0K3 b <>HIDDENR2 0NUMBERSK6"
    have "n >=XXREAL-0R2 \<one>\<^sub>M"
      using A3 sorry
    then have A7: "n >XXREAL-0R4 0NUMBERSK6"
       sorry
    show " not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
    proof-
      have cases: "x =HIDDENR1 0NUMBERSK6 or y =HIDDENR1 0NUMBERSK6"
        using A2 sorry
      have case1: "x =HIDDENR1 0NUMBERSK6 implies  not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
      proof(rule impI)
        assume A8: "x =HIDDENR1 0NUMBERSK6"
        then have "a *XCMPLX-0K3 (0NUMBERSK6)to-powerPOWERK2 n +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
          using A1 sorry
        then have "a *XCMPLX-0K3 (0NUMBERSK6) +XCMPLX-0K2 b *XCMPLX-0K3 y  |^NEWTONK1 n =HIDDENR1 p"
          using A7 power_def_2 sorry
        then have "y  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 b"
          using A6 xcmplx_1_th_89 sorry
        thus " not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
          using A3 A4 A8 polyeq_4_th_4 sorry
      qed
      have case2: "y =HIDDENR1 0NUMBERSK6 implies  not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
      proof(rule impI)
        assume A9: "y =HIDDENR1 0NUMBERSK6"
        then have "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 (0NUMBERSK6)to-powerPOWERK2 n =HIDDENR1 p"
          using A1 sorry
        then have "a *XCMPLX-0K3 x  |^NEWTONK1 n +XCMPLX-0K2 b *XCMPLX-0K3 (0NUMBERSK6) =HIDDENR1 p"
          using A7 power_def_2 sorry
        then have "x  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 a"
          using A6 xcmplx_1_th_89 sorry
        thus " not ((( not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 b)) &  not (x =HIDDENR1 0NUMBERSK6 & y =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 b))) &  not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 0NUMBERSK6))"
          using A3 A5 A9 polyeq_4_th_4 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_20:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & n be oddABIANV2) & p *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & (x *XCMPLX-0K3 y =HIDDENR1 q & (n be oddABIANV2 & p *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6)) implies x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p"
      and A2: "x *XCMPLX-0K3 y =HIDDENR1 q"
      and A3: "n be oddABIANV2"
      and A4: "p *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
    obtain m where
      [ty]:"m be NatORDINAL1M6" and 
      A5: "n =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 m +XCMPLX-0K2 \<one>\<^sub>M"
      using A3 abian_th_9 sorry
    have A6: "a <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    then have A7: "x  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 a"
      using A1 xcmplx_1_th_89 sorry
    then have "x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a)"
      using A3 power_th_4 sorry
    then have "y *XCMPLX-0K3 (n -rootPOWERK1 (p /XCMPLX-0K7 a) *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A2 sorry
    then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a /XCMPLX-0K7 p)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A3 power_th_11 sorry
    then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a *XCMPLX-0K3 p \<inverse>XCMPLX-0K5)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using xcmplx_0_def_9 sorry
    then have "y *XCMPLX-0K3 n -rootPOWERK1 (((p /XCMPLX-0K7 a)*XCMPLX-0K3 a)*XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
       sorry
    then have "y *XCMPLX-0K3 n -rootPOWERK1 (p *XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A6 xcmplx_1_th_87 sorry
    then have A8: "y *XCMPLX-0K3 n -rootPOWERK1 (p /XCMPLX-0K7 p) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using xcmplx_0_def_9 sorry
    have A9: "\<two>\<^sub>M *XCMPLX-0K3 m +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_7 sorry
    have "p <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    then have "y *XCMPLX-0K3 n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A8 xcmplx_1_th_60 sorry
    then have "y *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A5 A9 power_th_6 sorry
    thus "x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
      using A3 A7 power_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_21:
" for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((((a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & x *XCMPLX-0K3 y =HIDDENR1 q) & n be evenABIANV3) & n >=XXREAL-0R2 \<one>\<^sub>M) & p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6) & a <>HIDDENR2 0NUMBERSK6 implies x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
proof-
  have " for x be RealXREAL-0M1 holds  for y be RealXREAL-0M1 holds  for a be RealXREAL-0M1 holds  for p be RealXREAL-0M1 holds  for q be RealXREAL-0M1 holds  for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p & (x *XCMPLX-0K3 y =HIDDENR1 q & ((n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M) & (p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 0NUMBERSK6))) implies  not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    fix y assume [ty]: "y be RealXREAL-0M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RealXREAL-0M1"
    fix q assume [ty]: "q be RealXREAL-0M1"
    fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A1: "a *XCMPLX-0K3 x  |^NEWTONK1 n =HIDDENR1 p"
      and A2: "x *XCMPLX-0K3 y =HIDDENR1 q"
      and A3: "n be evenABIANV3 & n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "p /XCMPLX-0K7 a >XXREAL-0R4 0NUMBERSK6"
      and A5: "a <>HIDDENR2 0NUMBERSK6"
    have A6: "x  |^NEWTONK1 n =HIDDENR1 p /XCMPLX-0K7 a"
      using A1 A5 xcmplx_1_th_89 sorry
    have "(p /XCMPLX-0K7 a)\<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6"
      using A4 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (p /XCMPLX-0K7 a) >XXREAL-0R4 0NUMBERSK6"
      using xcmplx_1_th_215 sorry
    then have A7: "(\<one>\<^sub>M *XCMPLX-0K3 a)/XCMPLX-0K7 p >XXREAL-0R4 0NUMBERSK6"
      using xcmplx_1_th_77 sorry
    have A8: "p <>HIDDENR2 0NUMBERSK6"
      using A4 sorry
    show " not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
    proof-
      have cases: "x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) or x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a)"
        using A3 A4 A6 polyeq_4_th_4 sorry
      have case1: "x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) implies  not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
      proof(rule impI)
        assume A9: "x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a)"
        then have "y *XCMPLX-0K3 (n -rootPOWERK1 (p /XCMPLX-0K7 a) *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A2 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a /XCMPLX-0K7 p)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A4 A3 A7 power_th_11 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a *XCMPLX-0K3 p \<inverse>XCMPLX-0K5)) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using xcmplx_0_def_9 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (((p /XCMPLX-0K7 a)*XCMPLX-0K3 a)*XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
           sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (p *XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A5 xcmplx_1_th_87 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (p /XCMPLX-0K7 p) =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using xcmplx_0_def_9 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A8 xcmplx_1_th_60 sorry
        then have "y *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A3 power_th_6 sorry
        thus " not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
          using A9 sorry
      qed
      have case2: "x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) implies  not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
      proof(rule impI)
        assume A10: "x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a)"
        then have "y *XCMPLX-0K3 (n -rootPOWERK1 (p /XCMPLX-0K7 a) *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A2 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a /XCMPLX-0K7 p)) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A4 A3 A7 power_th_11 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 ((p /XCMPLX-0K7 a)*XCMPLX-0K3 (a *XCMPLX-0K3 p \<inverse>XCMPLX-0K5)) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using xcmplx_0_def_9 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (((p /XCMPLX-0K7 a)*XCMPLX-0K3 a)*XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
           sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (p *XCMPLX-0K3 p \<inverse>XCMPLX-0K5) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A5 xcmplx_1_th_87 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 (p /XCMPLX-0K7 p) =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using xcmplx_0_def_9 sorry
        then have "y *XCMPLX-0K3 n -rootPOWERK1 \<one>\<^sub>M =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A8 xcmplx_1_th_60 sorry
        then have "y *XCMPLX-0K3 \<one>\<^sub>M =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)"
          using A3 power_th_6 sorry
        thus " not ( not (x =HIDDENR1 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)) &  not (x =HIDDENR1 -XCMPLX-0K4 n -rootPOWERK1 (p /XCMPLX-0K7 a) & y =HIDDENR1 -XCMPLX-0K4 q *XCMPLX-0K3 n -rootPOWERK1 (a /XCMPLX-0K7 p)))"
          using A10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem polyeq_4_th_22:
" for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a to-powerPOWERK2 x =HIDDENR1 \<one>\<^sub>M implies x =HIDDENR1 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume A1: "a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M"
    and A2: "a to-powerPOWERK2 x =HIDDENR1 \<one>\<^sub>M"
  have "x =HIDDENR1 logPOWERK3(a,\<one>\<^sub>M)"
    using A1 A2 power_def_3 sorry
  thus "x =HIDDENR1 0NUMBERSK6"
    using A1 power_th_51 sorry
qed "sorry"

mtheorem polyeq_4_th_23:
" for a be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & a to-powerPOWERK2 x =HIDDENR1 a implies x =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume A1: "a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M"
    and A2: "a to-powerPOWERK2 x =HIDDENR1 a"
  have "x =HIDDENR1 logPOWERK3(a,a)"
    using A1 A2 power_def_3 sorry
  thus "x =HIDDENR1 \<one>\<^sub>M"
    using A1 power_th_52 sorry
qed "sorry"

mtheorem polyeq_4_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 0NUMBERSK6 implies x =HIDDENR1 \<one>\<^sub>M"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume "((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 0NUMBERSK6"
  then have "a to-powerPOWERK2 (0NUMBERSK6) =HIDDENR1 x"
    using power_def_3 sorry
  thus "x =HIDDENR1 \<one>\<^sub>M"
    using power_th_24 sorry
qed "sorry"

mtheorem polyeq_4_th_25:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for x be RealXREAL-0M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 \<one>\<^sub>M implies x =HIDDENR1 a"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix a assume [ty]: "a be RealXREAL-0M1"
  fix b assume [ty]: "b be RealXREAL-0M1"
  fix x assume [ty]: "x be RealXREAL-0M1"
  assume "((a >XXREAL-0R4 0NUMBERSK6 & a <>HIDDENR2 \<one>\<^sub>M) & x >XXREAL-0R4 0NUMBERSK6) & logPOWERK3(a,x) =HIDDENR1 \<one>\<^sub>M"
  then have "a to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 x"
    using power_def_3 sorry
  thus "x =HIDDENR1 a"
     sorry
qed "sorry"

end
