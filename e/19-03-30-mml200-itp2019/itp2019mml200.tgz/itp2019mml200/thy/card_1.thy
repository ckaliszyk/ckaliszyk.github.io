theory card_1
  imports wellord2 finset_1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve A, B, C for "OrdinalORDINAL1M3"
reserve X, X1, Y, Y1, Z for "setHIDDENM2"
reserve a, b, b1, b2, x, y, z for "objectHIDDENM1"
reserve R for "RelationRELAT-1M1"
reserve f, g, h for "FunctionFUNCT-1M1"
reserve k, m, n for "NatORDINAL1M6"
mdef card_1_def_1 ("cardinalCARD-1V1" 70 ) where
"attr cardinalCARD-1V1 for objectHIDDENM1 means
  (\<lambda>IT.  ex B be OrdinalORDINAL1M3 st IT =HIDDENR1 B & ( for A be OrdinalORDINAL1M3 holds (A,B)are-equipotentWELLORD2R2 implies B c=ORDINAL1R1 A))"..

mtheorem card_1_cl_1:
"cluster cardinalCARD-1V1 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be cardinalCARD-1V1"
  proof-
    have " ex tVar1 be setHIDDENM2 st tVar1 be cardinalCARD-1V1"
    proof-
      let ?A = "the OrdinalORDINAL1M3"
      let ?P = "\<lambda>Lamb1. (Lamb1,?A)are-equipotentWELLORD2R2"
      have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
         sorry
      obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A2: "?P(B) & ( for C be OrdinalORDINAL1M3 holds ?P(C) implies B c=ORDINAL1R1 C)"
        using ordinal1_sch_1 A1 sorry
      obtain IT where 
        [ty]:"IT be setHIDDENM2" and ITDef:"IT = B"
         sorry
      show " ex tVar1 be setHIDDENM2 st tVar1 be cardinalCARD-1V1"
      proof(rule bexI[of _ "IT"])
        have "IT =HIDDENR1 B & ( for A be OrdinalORDINAL1M3 holds  not ((A,B)are-equipotentWELLORD2R2 &  not B c=ORDINAL1R1 A))"
        proof-
          show "IT =HIDDENR1 B & ( for A be OrdinalORDINAL1M3 holds  not ((A,B)are-equipotentWELLORD2R2 &  not B c=ORDINAL1R1 A))"
            using A2 wellord2_th_15 sorry
        qed
        thus "IT be cardinalCARD-1V1"
          using bexI[of _ "B"] card_1_def_1 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CARD_1M1 :: "Ty" ("CardinalCARD-1M1" 70)
translations "CardinalCARD-1M1" \<rightharpoonup> "cardinalCARD-1V1\<bar>setHIDDENM2"

mtheorem card_1_cl_2:
"cluster cardinalCARD-1V1 also-is ordinalORDINAL1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be cardinalCARD-1V1 implies it be ordinalORDINAL1V3"
     sorry
qed "sorry"

reserve M, N for "CardinalCARD-1M1"
(*\$CT*)
mtheorem card_1_th_2:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds (M,N)are-equipotentWELLORD2R2 implies M =XBOOLE-0R4 N"
proof-
  have " for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds  not ((M,N)are-equipotentWELLORD2R2 &  not M =XBOOLE-0R4 N)"
  proof(rule ballI,rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    fix N assume [ty]: "N be CardinalCARD-1M1"
    have A1: " ex A be OrdinalORDINAL1M3 st M =XBOOLE-0R4 A & ( for C be OrdinalORDINAL1M3 holds (C,A)are-equipotentWELLORD2R2 implies A c=ORDINAL1R1 C)"
      using card_1_def_1 sorry
    have " ex B be OrdinalORDINAL1M3 st N =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds (C,B)are-equipotentWELLORD2R2 implies B c=ORDINAL1R1 C)"
      using card_1_def_1 sorry
    thus " not ((M,N)are-equipotentWELLORD2R2 &  not M =XBOOLE-0R4 N)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_3:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M inTARSKIR2 N iff M c=ORDINAL1R1 N & M <>HIDDENR2 N"
  using ordinal1_th_11 xboole_0_def_8 sorry

mtheorem card_1_th_4:
" for M be CardinalCARD-1M1 holds  for N be CardinalCARD-1M1 holds M inTARSKIR2 N iff  not N c=ORDINAL1R1 M"
  using ordinal1_th_5 ordinal1_th_16 sorry

mdef card_1_def_2 ("cardCARD-1K1  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func cardCARD-1K1 X \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. (X,it)are-equipotentWELLORD2R2"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st (X,it)are-equipotentWELLORD2R2"
    proof-
      have " ex tVar5 be CardinalCARD-1M1 st (X,tVar5)are-equipotentWELLORD2R2"
      proof-
        let ?P = "\<lambda>Lamb1. (X,Lamb1)are-equipotentWELLORD2R2"
        obtain R where
          [ty]:"R be RelationRELAT-1M1" and 
          A1: "R well-ordersWELLORD1R2 X"
          using wellord2_th_17 sorry
        let ?Q = "R  |-2WELLORD1K2 X"
        let ?A = "order-type-ofWELLORD2K2 ?Q"
        have "?Q be well-orderingWELLORD1V2"
          using A1 wellord2_th_16 sorry
        then have "(?Q,RelInclWELLORD2K1 ?A)are-isomorphicWELLORD1R4"
          using wellord2_def_2 sorry
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A2: "f is-isomorphism-ofWELLORD1R3(?Q,RelInclWELLORD2K1 ?A)"
          using wellord1_def_8 sorry
        have "(X,?A)are-equipotentWELLORD2R2"
        proof-
          have "(X,order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X)are-equipotentWELLORD2R2"
          proof-
            have Cut111: "domRELAT-1K1 f =XBOOLE-0R4 fieldRELAT-1K3 ?Q & rngFUNCT-1K2 f =XBOOLE-0R4 fieldRELAT-1K3 (RelInclWELLORD2K1 ?A)"
              using A2 wellord1_def_7 sorry
            have "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =HIDDENR1 X) & rngRELAT-1K2 f =HIDDENR1 order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X"
            proof-
              show "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =HIDDENR1 X) & rngRELAT-1K2 f =HIDDENR1 order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X"
                using A1 A2 wellord1_def_7 wellord2_th_16 wellord2_def_1 Cut111 sorry
            qed
            thus "(X,order-type-ofWELLORD2K2 R  |-2WELLORD1K2 X)are-equipotentWELLORD2R2"
              using bexI[of _ "f"] wellord2_def_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A3: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A4: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
          using ordinal1_sch_1 A3 sorry
        have "A be cardinalCARD-1V1"
        proof-
          have "A =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds (B,A)are-equipotentWELLORD2R2 implies A c=ORDINAL1R1 B)"
          proof(rule conjMI,rule ballI,rule impI)
            show "A =XBOOLE-0R4 A"
               sorry
            fix B assume [ty]: "B be OrdinalORDINAL1M3"
            assume "(B,A)are-equipotentWELLORD2R2"
            thus "A c=ORDINAL1R1 B"
              using A4 wellord2_th_15 sorry
          qed "sorry"
          thus "A be cardinalCARD-1V1"
            using bexI[of _ "A"] card_1_def_1 sorry
        qed
        then obtain M where 
          [ty]:"M be CardinalCARD-1M1" and MDef:"M = A"
           sorry
        show " ex tVar5 be CardinalCARD-1M1 st (X,tVar5)are-equipotentWELLORD2R2"
        proof(rule bexI[of _ "M"])
          show "(X,M)are-equipotentWELLORD2R2"
            using A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds (X,it1)are-equipotentWELLORD2R2 & (X,it2)are-equipotentWELLORD2R2 implies it1 =HIDDENR1 it2"
      using card_1_th_2 wellord2_th_15 sorry
qed "sorry"

mtheorem CARD_1K1_projectivity:
" for X be setHIDDENM2 holds cardCARD-1K1 (cardCARD-1K1 X) =HIDDENR1 cardCARD-1K1 X"
proof-
  have " for it be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds it =HIDDENR1 cardCARD-1K1 X implies it =HIDDENR1 cardCARD-1K1 it"
  proof-
    have " for it be CardinalCARD-1M1 holds  for X be setHIDDENM2 holds (X,it)are-equipotentWELLORD2R2 implies (it,it)are-equipotentWELLORD2R2"
       sorry
    thus " ?thesis "
      using card_1_def_2 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_reduce_1:
  mlet "C be CardinalCARD-1M1"
"reduce cardCARD-1K1 C to C"
proof
(*reducibility*)
  show "cardCARD-1K1 C =HIDDENR1 C"
    using card_1_def_2 sorry
qed "sorry"

mtheorem card_1_cl_3:
"cluster emptyXBOOLE-0V1 also-is cardinalCARD-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be cardinalCARD-1V1"
  proof-
    have " for S be setHIDDENM2 holds S be emptyXBOOLE-0V1 implies S be cardinalCARD-1V1"
    proof(rule ballI,rule impI)
      fix S assume [ty]: "S be setHIDDENM2"
      assume A1: "S be emptyXBOOLE-0V1"
      have "S =XBOOLE-0R4 {}XBOOLE-0K1 & ( for A be OrdinalORDINAL1M3 holds (A,{}XBOOLE-0K1)are-equipotentWELLORD2R2 implies {}XBOOLE-0K1 c=ORDINAL1R1 A)"
      proof(rule conjMI,rule ballI,rule impI)
        show "S =XBOOLE-0R4 {}XBOOLE-0K1"
          using A1 sorry
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume "(A,{}XBOOLE-0K1)are-equipotentWELLORD2R2"
        show "{}XBOOLE-0K1 c=ORDINAL1R1 A"
           sorry
      qed "sorry"
      thus "S be cardinalCARD-1V1"
        using bexI[of _ "{}XBOOLE-0K1"] card_1_def_1 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_4:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "cardCARD-1K1 X be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem card_1_cl_5:
  mlet "X be emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is zeroORDINAL1V8"
proof
(*coherence*)
  show "cardCARD-1K1 X be zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem card_1_cl_6:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "cardCARD-1K1 X be  non emptyXBOOLE-0V1"
  proof-
    have "cardCARD-1K1 X be emptyXBOOLE-0V1 implies  False "
    proof(rule impI)
      assume "cardCARD-1K1 X be emptyXBOOLE-0V1"
      then have " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 {}XBOOLE-0K1"
        using card_1_def_2 wellord2_def_4 sorry
      thus " False "
        using relat_1_th_42 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_7:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "cardCARD-1K1 X be  non zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem card_1_th_5:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 iff cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ((X,Y)are-equipotentWELLORD2R2 implies cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y) & (cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y implies (X,Y)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "(Y,cardCARD-1K1 Y)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    have A2: "(X,cardCARD-1K1 X)are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    thus "(X,Y)are-equipotentWELLORD2R2 implies cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
      using card_1_def_2 wellord2_th_15 sorry
    assume "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
    thus "(X,Y)are-equipotentWELLORD2R2"
      using A2 A1 wellord2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_6:
" for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies (fieldRELAT-1K3 R,order-type-ofWELLORD2K2 R)are-equipotentWELLORD2R2"
proof-
  have " for R be RelationRELAT-1M1 holds R be well-orderingWELLORD1V2 implies (fieldRELAT-1K3 R,order-type-ofWELLORD2K2 R)are-equipotentWELLORD2R2"
  proof(rule ballI,rule impI)
    fix R assume [ty]: "R be RelationRELAT-1M1"
    assume "R be well-orderingWELLORD1V2"
    then have "(R,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R))are-isomorphicWELLORD1R4"
      using wellord2_def_2 sorry
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "f is-isomorphism-ofWELLORD1R3(R,RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R))"
      using wellord1_def_8 sorry
    have Cut203: "fieldRELAT-1K3 (RelInclWELLORD2K1 (order-type-ofWELLORD2K2 R)) =XBOOLE-0R4 order-type-ofWELLORD2K2 R"
      using wellord2_def_1 sorry
    have "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =HIDDENR1 fieldRELAT-1K3 R) & rngRELAT-1K2 f =HIDDENR1 order-type-ofWELLORD2K2 R"
    proof-
      show "(f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =HIDDENR1 fieldRELAT-1K3 R) & rngRELAT-1K2 f =HIDDENR1 order-type-ofWELLORD2K2 R"
        using A1 wellord1_def_7 Cut203 sorry
    qed
    thus "(fieldRELAT-1K3 R,order-type-ofWELLORD2K2 R)are-equipotentWELLORD2R2"
      using bexI[of _ "f"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_7:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X c=TARSKIR1 M implies cardCARD-1K1 X c=ORDINAL1R1 M"
proof-
  have " for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X c=TARSKIR1 M implies cardCARD-1K1 X c=ORDINAL1R1 M"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 c=ORDINAL1R1 M & (X,Lamb1)are-equipotentWELLORD2R2"
    obtain m where 
      [ty]:"m be OrdinalORDINAL1M3" and mDef:"m = M"
       sorry
    assume "X c=TARSKIR1 M"
    then have A1: "order-type-ofWELLORD2K2 RelInclWELLORD2K1 X c=ORDINAL1R1 m & RelInclWELLORD2K1 X be well-orderingWELLORD1V2"
      using wellord2_th_8 wellord2_th_14 sorry
    have "fieldRELAT-1K3 (RelInclWELLORD2K1 X) =XBOOLE-0R4 X"
      using wellord2_def_1 sorry
    then have A2: " ex A be OrdinalORDINAL1M3 st ?P(A)"
      using A1 card_1_th_6 sorry
    obtain A where
      [ty]:"A be OrdinalORDINAL1M3" and 
      A3: "?P(A) & ( for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B)"
      using ordinal1_sch_1 A2 sorry
    have "A be cardinalCARD-1V1"
    proof-
      have "A =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds (B,A)are-equipotentWELLORD2R2 implies ( not A c=ORDINAL1R1 B implies  False ))"
      proof(rule conjMI,rule ballI,rule impI,rule impI)
        show "A =XBOOLE-0R4 A"
           sorry
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A4: "(B,A)are-equipotentWELLORD2R2"
        assume A5: " not A c=ORDINAL1R1 B"
        then have "m c=ORDINAL1R1 B"
          using A3 A4 wellord2_th_15 sorry
        thus " False "
          using A3 A5 sorry
      qed "sorry"
      thus "A be cardinalCARD-1V1"
        using bexI[of _ "A"] card_1_def_1 sorry
    qed
    then have 
      [ty]:"A be CardinalCARD-1M1"
       sorry
    have "cardCARD-1K1 X =XBOOLE-0R4 A"
      using A3 card_1_def_2 sorry
    thus "cardCARD-1K1 X c=ORDINAL1R1 M"
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_8:
" for A be OrdinalORDINAL1M3 holds cardCARD-1K1 A c=ORDINAL1R1 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds cardCARD-1K1 A c=ORDINAL1R1 A"
  proof(rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    have "( ex B be OrdinalORDINAL1M3 st cardCARD-1K1 A =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds (C,B)are-equipotentWELLORD2R2 implies B c=ORDINAL1R1 C)) & (A,cardCARD-1K1 A)are-equipotentWELLORD2R2"
      using card_1_def_1 card_1_def_2 sorry
    thus "cardCARD-1K1 A c=ORDINAL1R1 A"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_9:
" for X be setHIDDENM2 holds  for M be CardinalCARD-1M1 holds X inTARSKIR2 M implies cardCARD-1K1 X inTARSKIR2 M"
  using card_1_th_8 ordinal1_th_12 sorry

(*\$N Cantor-Bernstein Theorem*)
mtheorem card_1_th_10:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y iff ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)) & (( ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)) implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y)"
    proof-
      have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex h be setHIDDENM2 st h be one-to-oneFUNCT-1V2 & (domRELAT-1K1 h =XBOOLE-0R4 X & rngFUNCT-1K2 h c=TARSKIR1 Y))"
      proof(rule impI)
        obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 cardCARD-1K1 X"
          using card_1_def_2 wellord2_def_4 sorry
        assume A3: "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A4: "g be one-to-oneFUNCT-1V2"and A5: "domRELAT-1K1 g =XBOOLE-0R4 Y & rngFUNCT-1K2 g =XBOOLE-0R4 cardCARD-1K1 Y"
          using card_1_def_2 wellord2_def_4 sorry
        obtain h where 
          [ty]:"h be setHIDDENM2" and hDef:"h = g \<inverse>FUNCT-1K4 *FUNCT-1K3 f"
           sorry
        show " ex h be setHIDDENM2 st h be one-to-oneFUNCT-1V2 & (domRELAT-1K1 h =XBOOLE-0R4 X & rngFUNCT-1K2 h c=TARSKIR1 Y)"
        proof(rule bexI[of _ "h"],rule conjMI)
          show "h be one-to-oneFUNCT-1V2"
            using A1 A4 sorry
          have "rngFUNCT-1K2 g =XBOOLE-0R4 domRELAT-1K1 (g \<inverse>FUNCT-1K4) & domRELAT-1K1 g =XBOOLE-0R4 rngFUNCT-1K2 (g \<inverse>FUNCT-1K4)"
            using A4 funct_1_th_33 sorry
          thus "domRELAT-1K1 h =XBOOLE-0R4 X & rngFUNCT-1K2 h c=TARSKIR1 Y"
            using A3 A2 A5 relat_1_th_26 relat_1_th_27 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y)"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A6: "f be one-to-oneFUNCT-1V2"and A7: "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f c=TARSKIR1 Y"
       sorry
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A8: "g be one-to-oneFUNCT-1V2"and A9: "domRELAT-1K1 g =XBOOLE-0R4 Y"and A10: "rngFUNCT-1K2 g =XBOOLE-0R4 cardCARD-1K1 Y"
      using card_1_def_2 wellord2_def_4 sorry
    have A11: "(X,rngFUNCT-1K2 (g *FUNCT-1K3 f))are-equipotentWELLORD2R2"
    proof-
      have "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 X & rngRELAT-1K2 (g *FUNCT-1K3 f) =HIDDENR1 rngFUNCT-1K2 (g *FUNCT-1K3 f))"
      proof(rule conjMI,rule conjMI)
        show "g *FUNCT-1K3 f be one-to-oneFUNCT-1V2"
          using A6 A8 sorry
        show "domRELAT-1K1 (g *FUNCT-1K3 f) =XBOOLE-0R4 X"
          using A7 A9 relat_1_th_27 sorry
        show "rngRELAT-1K2 (g *FUNCT-1K3 f) =HIDDENR1 rngFUNCT-1K2 (g *FUNCT-1K3 f)"
           sorry
      qed
      thus "(X,rngFUNCT-1K2 (g *FUNCT-1K3 f))are-equipotentWELLORD2R2"
        using bexI[of _ "g *FUNCT-1K3 f"] wellord2_def_4 sorry
    qed
    have A12: "(rngFUNCT-1K2 (g *FUNCT-1K3 f),cardCARD-1K1 (rngFUNCT-1K2 (g *FUNCT-1K3 f)))are-equipotentWELLORD2R2"
      using card_1_def_2 sorry
    have "cardCARD-1K1 (rngFUNCT-1K2 (g *FUNCT-1K3 f)) c=ORDINAL1R1 cardCARD-1K1 Y"
      using A10 card_1_th_7 relat_1_th_26 sorry
    thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      using A12 card_1_def_2 A11 wellord2_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_11:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds X c=TARSKIR1 Y implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y"
    have " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f c=TARSKIR1 Y"
    proof-
      have " ex tVar11 be FunctionFUNCT-1M1 st (tVar11 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar11 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar11 c=TARSKIR1 Y"
      proof-
        show " ex tVar11 be FunctionFUNCT-1M1 st (tVar11 be one-to-oneFUNCT-1V2 & domRELAT-1K1 tVar11 =XBOOLE-0R4 X) & rngFUNCT-1K2 tVar11 c=TARSKIR1 Y"
        proof(rule bexI[of _ "idRELAT-1K7 X"])
          show "(idRELAT-1K7 X be one-to-oneFUNCT-1V2 & domRELAT-1K1 (idRELAT-1K7 X) =XBOOLE-0R4 X) & rngFUNCT-1K2 (idRELAT-1K7 X) c=TARSKIR1 Y"
            using A1 relat_1_th_45 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      using card_1_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_12:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y iff ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f)) & (( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f) implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    show "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f)"
    proof-
      have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex tVar12 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar12 =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 tVar12)"
      proof(rule impI)
        assume "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f c=TARSKIR1 Y"
          using card_1_th_10 sorry
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inHIDDENR3 rngFUNCT-1K2 f & Lamb2 =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 Lamb1 or  not Lamb1 inHIDDENR3 rngFUNCT-1K2 f & Lamb2 =HIDDENR1 0ORDINAL1K5"
        have A4: " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies ( ex y be objectHIDDENM1 st ?P(x,y))"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 Y implies  not ( for y be objectHIDDENM1 holds  not (x inHIDDENR3 rngFUNCT-1K2 f & y =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 x or  not x inHIDDENR3 rngFUNCT-1K2 f & y =HIDDENR1 0ORDINAL1K5))"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 Y"
            have " not x inHIDDENR3 rngFUNCT-1K2 f implies  not ( for y be objectHIDDENM1 holds  not ?P(x,y))"
               sorry
            thus " not ( for y be objectHIDDENM1 holds  not (x inHIDDENR3 rngFUNCT-1K2 f & y =HIDDENR1 f \<inverse>FUNCT-1K4 .FUNCT-1K1 x or  not x inHIDDENR3 rngFUNCT-1K2 f & y =HIDDENR1 0ORDINAL1K5))"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        have A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 Y & ?P(x,y)) & ?P(x,z) implies y =HIDDENR1 z"
           sorry
        obtain g where
          [ty]:"g be FunctionFUNCT-1M1" and 
          A6: "domRELAT-1K1 g =XBOOLE-0R4 Y & ( for y be objectHIDDENM1 holds y inHIDDENR3 Y implies ?P(y,g .FUNCT-1K1 y))"
          using funct_1_sch_2 A5 A4 sorry
        show " ex tVar12 be FunctionFUNCT-1M1 st domRELAT-1K1 tVar12 =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 tVar12"
        proof(rule bexI[of _ "g"],rule conjMI)
          show "domRELAT-1K1 g =XBOOLE-0R4 Y"
            using A6 sorry
          have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 rngFUNCT-1K2 g"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume A7: "x inHIDDENR3 X"
            then have A8: "f .FUNCT-1K1 x inTARSKIR2 rngFUNCT-1K2 f"
              using A2 funct_1_def_3 sorry
            have "f \<inverse>FUNCT-1K4 .FUNCT-1K1 (f .FUNCT-1K1 x) =HIDDENR1 x"
              using A1 A2 A7 funct_1_th_34 sorry
            then have "x =HIDDENR1 g .FUNCT-1K1 (f .FUNCT-1K1 x)"
              using A3 A6 A8 sorry
            thus "x inHIDDENR3 rngFUNCT-1K2 g"
              using A3 A6 A8 funct_1_def_3 sorry
          qed "sorry"
          thus "X c=TARSKIR1 rngFUNCT-1K2 g"
            using tarski_def_3 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex f be FunctionFUNCT-1M1 st domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A9: "domRELAT-1K1 f =XBOOLE-0R4 Y"and A10: "X c=TARSKIR1 rngFUNCT-1K2 f"
       sorry
    let ?f = "\<lambda>Lamb1. f \<inverse>FUNCT-1K6 {TARSKIK1 Lamb1}"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A11: "domRELAT-1K1 g =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies g .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_3 sorry
    show "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
    proof-
      have cases: "X <>HIDDENR2 {}XBOOLE-0K1 or X =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have case1: "X <>HIDDENR2 {}XBOOLE-0K1 implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      proof(rule impI)
        assume "X <>HIDDENR2 {}XBOOLE-0K1"
        then obtain M where 
          [ty]:"M be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and MDef:"M = rngFUNCT-1K2 g"
          using A11 relat_1_th_42 sorry
        have " for Z be setHIDDENM2 holds Z inTARSKIR2 M implies Z <>HIDDENR2 {}XBOOLE-0K1"
        proof-
          have " for Z be setHIDDENM2 holds Z inTARSKIR2 M implies  not Z <>HIDDENR2 {}XBOOLE-0K1"
          proof(rule ballI,rule impI)
            fix Z assume [ty]: "Z be setHIDDENM2"
            assume "Z inTARSKIR2 M"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A12: "x inHIDDENR3 domRELAT-1K1 g & Z =XBOOLE-0R4 g .FUNCT-1K1 x"
              using funct_1_def_3 sorry
            have A13: "x inHIDDENR3 {TARSKIK1 x}"
              using tarski_def_1 sorry
            have "Z =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 x} & ( ex y be objectHIDDENM1 st y inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 y)"
              using A10 A11 A12 funct_1_def_3 sorry
            thus " not Z <>HIDDENR2 {}XBOOLE-0K1"
              using A13 funct_1_def_7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        then obtain F where
          [ty]:"F be FunctionFUNCT-1M1" and 
          A14: "domRELAT-1K1 F =XBOOLE-0R4 M"and A15: " for Z be setHIDDENM2 holds Z inTARSKIR2 M implies F .FUNCT-1K1 Z inTARSKIR2 Z"
          using funct_1_th_111 sorry
        have A16: "domRELAT-1K1 (F *FUNCT-1K3 g) =XBOOLE-0R4 X"
          using A11 A14 relat_1_th_27 sorry
        have A17: "F *FUNCT-1K3 g be one-to-oneFUNCT-1V2"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 g) & (y inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 g) & (F *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (F *FUNCT-1K3 g).FUNCT-1K1 y) implies x =HIDDENR1 y"
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            assume A18: "x inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 g)"
              and A19: "y inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 g)"
              and A20: "(F *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 (F *FUNCT-1K3 g).FUNCT-1K1 y"
            have A21: "g .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
              using A11 A16 A19 sorry
            then have "f \<inverse>FUNCT-1K6 {TARSKIK1 y} inTARSKIR2 M"
              using A11 A16 A19 funct_1_def_3 sorry
            then have "F .FUNCT-1K1 f \<inverse>FUNCT-1K6 {TARSKIK1 y} inTARSKIR2 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
              using A15 sorry
            then have A22: "f .FUNCT-1K1 (F .FUNCT-1K1 f \<inverse>FUNCT-1K6 {TARSKIK1 y}) inTARSKIR2 {TARSKIK1 y}"
              using funct_1_def_7 sorry
            have A23: "g .FUNCT-1K1 x =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using A11 A16 A18 sorry
            then have "f \<inverse>FUNCT-1K6 {TARSKIK1 x} inTARSKIR2 M"
              using A11 A16 A18 funct_1_def_3 sorry
            then have "F .FUNCT-1K1 f \<inverse>FUNCT-1K6 {TARSKIK1 x} inTARSKIR2 f \<inverse>FUNCT-1K6 {TARSKIK1 x}"
              using A15 sorry
            then have "f .FUNCT-1K1 (F .FUNCT-1K1 f \<inverse>FUNCT-1K6 {TARSKIK1 x}) inTARSKIR2 {TARSKIK1 x}"
              using funct_1_def_7 sorry
            then have A24: "f .FUNCT-1K1 (F .FUNCT-1K1 f \<inverse>FUNCT-1K6 {TARSKIK1 x}) =HIDDENR1 x"
              using tarski_def_1 sorry
            have "(F *FUNCT-1K3 g).FUNCT-1K1 x =XBOOLE-0R4 F .FUNCT-1K1 (g .FUNCT-1K1 x) & (F *FUNCT-1K3 g).FUNCT-1K1 y =XBOOLE-0R4 F .FUNCT-1K1 (g .FUNCT-1K1 y)"
              using A11 A16 A18 A19 funct_1_th_13 sorry
            thus "x =HIDDENR1 y"
              using A20 A23 A21 A22 A24 tarski_def_1 sorry
          qed "sorry"
          thus "F *FUNCT-1K3 g be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        have "rngFUNCT-1K2 (F *FUNCT-1K3 g) c=TARSKIR1 Y"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (F *FUNCT-1K3 g) implies x inHIDDENR3 Y"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngFUNCT-1K2 (F *FUNCT-1K3 g)"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A25: "y inHIDDENR3 domRELAT-1K1 (F *FUNCT-1K3 g)"and A26: "x =HIDDENR1 (F *FUNCT-1K3 g).FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have A27: "x =HIDDENR1 F .FUNCT-1K1 (g .FUNCT-1K1 y)"
              using A11 A16 A25 A26 funct_1_th_13 sorry
            have A28: "g .FUNCT-1K1 y =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
              using A11 A16 A25 sorry
            then have "f \<inverse>FUNCT-1K6 {TARSKIK1 y} inTARSKIR2 M"
              using A11 A16 A25 funct_1_def_3 sorry
            then have "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
              using A15 A28 A27 sorry
            thus "x inHIDDENR3 Y"
              using A9 funct_1_def_7 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 (F *FUNCT-1K3 g) c=TARSKIR1 Y"
            using tarski_def_3 sorry
        qed
        thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
          using A16 A17 card_1_th_10 sorry
      qed
      have case2: "X =XBOOLE-0R4 {}XBOOLE-0K1 implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      proof(rule impI)
        assume "X =XBOOLE-0R4 {}XBOOLE-0K1"
        thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_13:
" for X be setHIDDENM2 holds  not (X,boolZFMISC-1K1 X)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  not (X,boolZFMISC-1K1 X)are-equipotentWELLORD2R2"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "( ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 boolZFMISC-1K1 X)) implies  False "
    proof(rule impI)
      assume Given: " ex f be FunctionFUNCT-1M1 st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 boolZFMISC-1K1 X)"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        "f be one-to-oneFUNCT-1V2"and A1: "domRELAT-1K1 f =XBOOLE-0R4 X & rngFUNCT-1K2 f =XBOOLE-0R4 boolZFMISC-1K1 X"
         sorry
      let ?P = "\<lambda>Lamb1.  for Y be setHIDDENM2 holds Y =XBOOLE-0R4 f .FUNCT-1K1 Lamb1 implies  not Lamb1 inHIDDENR3 Y"
      obtain Z where
        [ty]:"Z be setHIDDENM2" and 
        A2: " for a be objectHIDDENM1 holds a inHIDDENR3 Z iff a inHIDDENR3 X & ?P(a)"
        using xboole_0_sch_1 sorry
      have "Z c=TARSKIR1 X"
        using A2 sorry
      then obtain a where
        [ty]:"a be objectHIDDENM1" and 
        A3: "a inHIDDENR3 X"and A4: "Z =XBOOLE-0R4 f .FUNCT-1K1 a"
        using A1 funct_1_def_3 sorry
      have " ex Y be setHIDDENM2 st Y =XBOOLE-0R4 f .FUNCT-1K1 a & a inHIDDENR3 Y"
        using A2 A3 A4 sorry
      thus " False "
        using A2 A4 sorry
    qed
    thus " not (X,boolZFMISC-1K1 X)are-equipotentWELLORD2R2"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$N Cantor Theorem*)
mtheorem card_1_th_14:
" for X be setHIDDENM2 holds cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (boolZFMISC-1K1 X)"
proof-
  have " for X be setHIDDENM2 holds cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (boolZFMISC-1K1 X)"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?f = "\<lambda>Lamb1. {TARSKIK1 Lamb1}"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for x be objectHIDDENM1 holds x inHIDDENR3 X implies f .FUNCT-1K1 x =XBOOLE-0R4 ?f(x))"
      using funct_1_sch_3 sorry
    have A2: "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 X"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 boolZFMISC-1K1 X"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A3: "y inHIDDENR3 domRELAT-1K1 f"and A4: "x =HIDDENR1 f .FUNCT-1K1 y"
          using funct_1_def_3 sorry
        have A5: "{TARSKIK1 y} c=TARSKIR1 X"
          using A1 A3 tarski_def_1 sorry
        have "f .FUNCT-1K1 y =XBOOLE-0R4 {TARSKIK1 y}"
          using A1 A3 sorry
        thus "x inHIDDENR3 boolZFMISC-1K1 X"
          using A4 A5 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 f c=TARSKIR1 boolZFMISC-1K1 X"
        using tarski_def_3 sorry
    qed
    have A6: "cardCARD-1K1 X <>HIDDENR2 cardCARD-1K1 (boolZFMISC-1K1 X)"
      using card_1_th_5 card_1_th_13 sorry
    have "f be one-to-oneFUNCT-1V2"
    proof-
      have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y implies x =HIDDENR1 y"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume A7: "x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 domRELAT-1K1 f"
          and A8: "f .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 y"
        have "f .FUNCT-1K1 x =XBOOLE-0R4 {TARSKIK1 x} & f .FUNCT-1K1 y =XBOOLE-0R4 {TARSKIK1 y}"
          using A1 A7 sorry
        thus "x =HIDDENR1 y"
          using A8 zfmisc_1_th_3 sorry
      qed "sorry"
      thus "f be one-to-oneFUNCT-1V2"
        using funct_1_def_4 sorry
    qed
    then have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 (boolZFMISC-1K1 X)"
      using A1 A2 card_1_th_10 sorry
    thus "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (boolZFMISC-1K1 X)"
      using A6 ordinal1_th_11 xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef card_1_def_3 ("nextcardCARD-1K2  _ " [228]228 ) where
  mlet "X be setHIDDENM2"
"func nextcardCARD-1K2 X \<rightarrow> CardinalCARD-1M1 means
  \<lambda>it. cardCARD-1K1 X inTARSKIR2 it & ( for M be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 M implies it c=ORDINAL1R1 M)"
proof-
  (*existence*)
    show " ex it be CardinalCARD-1M1 st cardCARD-1K1 X inTARSKIR2 it & ( for M be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 M implies it c=ORDINAL1R1 M)"
    proof-
      have " ex tVar13 be CardinalCARD-1M1 st cardCARD-1K1 X inTARSKIR2 tVar13 & ( for N be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 N implies tVar13 c=ORDINAL1R1 N)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex M be CardinalCARD-1M1 st Lamb1 =XBOOLE-0R4 M & cardCARD-1K1 X inTARSKIR2 M"
        have "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 (boolZFMISC-1K1 X)"
          using card_1_th_14 sorry
        then have A1: " ex A be OrdinalORDINAL1M3 st ?P(A)"
           sorry
        obtain A where
          [ty]:"A be OrdinalORDINAL1M3" and 
          A2: "?P(A)"and A3: " for B be OrdinalORDINAL1M3 holds ?P(B) implies A c=ORDINAL1R1 B"
          using ordinal1_sch_1 A1 sorry
        obtain M where
          [ty]:"M be CardinalCARD-1M1" and 
          A4: "A =XBOOLE-0R4 M"and A5: "cardCARD-1K1 X inTARSKIR2 M"
          using A2 sorry
        show " ex tVar13 be CardinalCARD-1M1 st cardCARD-1K1 X inTARSKIR2 tVar13 & ( for N be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 N implies tVar13 c=ORDINAL1R1 N)"
        proof(rule bexI[of _ "M"],rule conjMI,rule ballI,rule impI)
          show "cardCARD-1K1 X inTARSKIR2 M"
            using A5 sorry
          fix N assume [ty]: "N be CardinalCARD-1M1"
          assume "cardCARD-1K1 X inTARSKIR2 N"
          thus "M c=ORDINAL1R1 N"
            using A3 A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be CardinalCARD-1M1 holds  for it2 be CardinalCARD-1M1 holds (cardCARD-1K1 X inTARSKIR2 it1 & ( for M be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 M implies it1 c=ORDINAL1R1 M)) & (cardCARD-1K1 X inTARSKIR2 it2 & ( for M be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 M implies it2 c=ORDINAL1R1 M)) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem card_1_th_15:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 nextcardCARD-1K2 X"
proof-
  have " for X be setHIDDENM2 holds {}XBOOLE-0K1 inTARSKIR2 nextcardCARD-1K2 X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have "cardCARD-1K1 ({}XBOOLE-0K1) c=ORDINAL1R1 cardCARD-1K1 X & cardCARD-1K1 X inTARSKIR2 nextcardCARD-1K2 X"
      using card_1_def_3 sorry
    thus "{}XBOOLE-0K1 inTARSKIR2 nextcardCARD-1K2 X"
      using ordinal1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_16:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
    have "cardCARD-1K1 X inTARSKIR2 nextcardCARD-1K2 X & ( for N be CardinalCARD-1M1 holds cardCARD-1K1 X inTARSKIR2 N implies nextcardCARD-1K2 X c=ORDINAL1R1 N)"
      using card_1_def_3 sorry
    thus "nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
      using A1 card_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 implies nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "(X,Y)are-equipotentWELLORD2R2"
    then have "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Y"
      using card_1_th_5 sorry
    thus "nextcardCARD-1K2 X =XBOOLE-0R4 nextcardCARD-1K2 Y"
      using card_1_th_16 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_18:
" for A be OrdinalORDINAL1M3 holds A inTARSKIR2 nextcardCARD-1K2 A"
proof-
  have " for A be OrdinalORDINAL1M3 holds  not A inTARSKIR2 nextcardCARD-1K2 A implies  False "
  proof(rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    assume " not A inTARSKIR2 nextcardCARD-1K2 A"
    then have A1: "cardCARD-1K1 (nextcardCARD-1K2 A) c=ORDINAL1R1 cardCARD-1K1 A"
      using card_1_th_11 ordinal1_th_16 sorry
    have A2: "nextcardCARD-1K2 (cardCARD-1K1 A) =XBOOLE-0R4 nextcardCARD-1K2 A"
      using card_1_def_2 card_1_th_17 sorry
    have A3: "cardCARD-1K1 (cardCARD-1K1 A) inTARSKIR2 nextcardCARD-1K2 (cardCARD-1K1 A)"
      using card_1_def_3 sorry
    show " False "
      using A1 A2 A3 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve S for "SequenceORDINAL1M4"
mdef card_1_def_4 ("limit-cardinalCARD-1V2" 70 ) where
"attr limit-cardinalCARD-1V2 for CardinalCARD-1M1 means
  (\<lambda>M.  not ( ex N be CardinalCARD-1M1 st M =XBOOLE-0R4 nextcardCARD-1K2 N))"..

mdef card_1_def_5 ("alephCARD-1K3  _ " [228]228 ) where
  mlet "A be OrdinalORDINAL1M3"
"func alephCARD-1K3 A \<rightarrow> setHIDDENM2 means
  \<lambda>it.  ex S be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B))) & ( for B be OrdinalORDINAL1M3 holds (B inTARSKIR2 succORDINAL1K1 A & B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  ex S be SequenceORDINAL1M4 st (((it =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B))) & ( for B be OrdinalORDINAL1M3 holds (B inTARSKIR2 succORDINAL1K1 A & B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) &  not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?B = "cardCARD-1K1 (omegaORDINAL1K4)"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. cardCARD-1K1 supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. nextcardCARD-1K2 Lamb2"
        have "( ex x be objectHIDDENM1 st  ex S be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex S be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) & ( ex S be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) &  not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( ex S be SequenceORDINAL1M4 st (((it1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B))) & ( for B be OrdinalORDINAL1M3 holds (B inTARSKIR2 succORDINAL1K1 A & B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))) & ( ex S be SequenceORDINAL1M4 st (((it2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B))) & ( for B be OrdinalORDINAL1M3 holds (B inTARSKIR2 succORDINAL1K1 A & B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))) implies it1 =HIDDENR1 it2"
    proof-
      have " not ( for VarFor1 be setHIDDENM2 holds  for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) &  not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
      proof-
        let ?B = "cardCARD-1K1 (omegaORDINAL1K4)"
        let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. cardCARD-1K1 supORDINAL2K4 Lamb2"
        let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. nextcardCARD-1K2 Lamb2"
        have "( ex x be objectHIDDENM1 st  ex S be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) & ( for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds ( ex S be SequenceORDINAL1M4 st (((x1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) & ( ex S be SequenceORDINAL1M4 st (((x2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 ?B) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C))) implies x1 =XBOOLE-0R4 x2)"
          using ordinal2_sch_7 sorry
        thus " not ( for VarFor1 be setHIDDENM2 holds  for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) & ( for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not (( not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor1 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B))))) &  not ( for S be SequenceORDINAL1M4 holds  not ((((VarFor2 =XBOOLE-0R4 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for B be OrdinalORDINAL1M3 holds  not (succORDINAL1K1 B inTARSKIR2 succORDINAL1K1 A &  not S .FUNCT-1K1 succORDINAL1K1 B =XBOOLE-0R4 nextcardCARD-1K2 (S .FUNCT-1K1 B)))) & ( for B be OrdinalORDINAL1M3 holds  not (((B inTARSKIR2 succORDINAL1K1 A &  not B <>HIDDENR2 0ORDINAL1K5) & B be limit-ordinalORDINAL1V4) &  not S .FUNCT-1K1 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 (S  |RELAT-1K8 B)))))) &  not VarFor1 =HIDDENR1 VarFor2))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma card_1_lm_1:
"alephCARD-1K3 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4) & (( for A be OrdinalORDINAL1M3 holds alephCARD-1K3 (succORDINAL1K1 A) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 A)) & ( for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4 implies ( for S be SequenceORDINAL1M4 holds domRELAT-1K1 S =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 alephCARD-1K3 B) implies alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S)))"
proof(rule conjMI,rule conjMI)
  let ?D = "\<lambda>Lamb1. \<lambda>Lamb2. cardCARD-1K1 supORDINAL2K4 Lamb2"
  let ?C = "\<lambda>Lamb1. \<lambda>Lamb2. nextcardCARD-1K2 Lamb2"
  let ?F = "\<lambda>Lamb1. alephCARD-1K3 Lamb1"
  have A1: " for A be OrdinalORDINAL1M3 holds  for x be objectHIDDENM1 holds x =HIDDENR1 ?F(A) iff ( ex S be SequenceORDINAL1M4 st (((x =HIDDENR1 lastORDINAL2K1 S & domRELAT-1K1 S =XBOOLE-0R4 succORDINAL1K1 A) & S .FUNCT-1K1 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)) & ( for C be OrdinalORDINAL1M3 holds succORDINAL1K1 C inTARSKIR2 succORDINAL1K1 A implies S .FUNCT-1K1 succORDINAL1K1 C =XBOOLE-0R4 ?C(C,S .FUNCT-1K1 C))) & ( for C be OrdinalORDINAL1M3 holds (C inTARSKIR2 succORDINAL1K1 A & C <>HIDDENR2 0ORDINAL1K5) & C be limit-ordinalORDINAL1V4 implies S .FUNCT-1K1 C =XBOOLE-0R4 ?D(C,S  |RELAT-1K8 C)))"
    using card_1_def_5 sorry
  have "?F(0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)"
    using ordinal2_sch_8 A1 sorry
  thus "alephCARD-1K3 (0ORDINAL1K5) =XBOOLE-0R4 cardCARD-1K1 (omegaORDINAL1K4)"
     sorry
  show " for A be OrdinalORDINAL1M3 holds alephCARD-1K3 (succORDINAL1K1 A) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 A)"
    using ordinal2_sch_9 A1 sorry
  show " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4 implies ( for S be SequenceORDINAL1M4 holds domRELAT-1K1 S =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 alephCARD-1K3 B) implies alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S)"
  proof-
    have " for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4 implies ( for S be SequenceORDINAL1M4 holds domRELAT-1K1 S =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 alephCARD-1K3 B) implies alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S)"
    proof(rule ballI,rule impI,rule ballI,rule impMI ,rule impI)
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume A2: "A <>HIDDENR2 0ORDINAL1K5 & A be limit-ordinalORDINAL1V4"
      fix S assume [ty]: "S be SequenceORDINAL1M4"
      assume A3: "domRELAT-1K1 S =XBOOLE-0R4 A"
        and A4: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 ?F(B)"
      show "alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S"
        using ordinal2_sch_10 A1 A2 A3 A4 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed

mtheorem card_1_cl_8:
  mlet "A be OrdinalORDINAL1M3"
"cluster alephCARD-1K3 A as-term-is cardinalCARD-1V1"
proof
(*coherence*)
  show "alephCARD-1K3 A be cardinalCARD-1V1"
  proof-
    have A1: "A <>HIDDENR2 {}XBOOLE-0K1 & ( for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B) implies alephCARD-1K3 A be CardinalCARD-1M1"
    proof(rule impMI ,rule impI)
      obtain S where
        [ty]:"S be SequenceORDINAL1M4" and 
        A2: "domRELAT-1K1 S =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 alephCARD-1K3 B)"
        using ordinal2_sch_2 sorry
      assume A3: "A <>HIDDENR2 {}XBOOLE-0K1"
        and A4: " for B be OrdinalORDINAL1M3 holds A <>HIDDENR2 succORDINAL1K1 B"
      have "alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S"
        using A3 A2 card_1_lm_1 A4 ordinal1_th_29 sorry
      thus "alephCARD-1K3 A be CardinalCARD-1M1"
         sorry
    qed
    have "( ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B) implies alephCARD-1K3 A be cardinalCARD-1V1"
    proof(rule impI)
      assume Given: " ex B be OrdinalORDINAL1M3 st A =XBOOLE-0R4 succORDINAL1K1 B"
      then obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A5: "A =XBOOLE-0R4 succORDINAL1K1 B"
         sorry
      have "alephCARD-1K3 A =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 B)"
        using A5 card_1_lm_1 sorry
      thus "alephCARD-1K3 A be cardinalCARD-1V1"
         sorry
    qed
    thus "alephCARD-1K3 A be cardinalCARD-1V1"
      using A1 card_1_lm_1 sorry
  qed
qed "sorry"

mtheorem card_1_th_19:
" for A be OrdinalORDINAL1M3 holds alephCARD-1K3 (succORDINAL1K1 A) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 A)"
  using card_1_lm_1 sorry

mtheorem card_1_th_20:
" for A be OrdinalORDINAL1M3 holds A <>HIDDENR2 {}XBOOLE-0K1 & A be limit-ordinalORDINAL1V4 implies ( for S be SequenceORDINAL1M4 holds domRELAT-1K1 S =XBOOLE-0R4 A & ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies S .FUNCT-1K1 B =XBOOLE-0R4 alephCARD-1K3 B) implies alephCARD-1K3 A =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S)"
  using card_1_lm_1 sorry

mtheorem card_1_th_21:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A inTARSKIR2 B iff alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds (A inTARSKIR2 B implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B) & (alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B implies A inTARSKIR2 B)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    let ?P = "\<lambda>Lamb1.  for A be OrdinalORDINAL1M3 holds A inTARSKIR2 Lamb1 implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 Lamb1"
    have A1: " for B be OrdinalORDINAL1M3 holds ?P(B) implies ?P(succORDINAL1K1 B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B) implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 succORDINAL1K1 B implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 (succORDINAL1K1 B))"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A2: "?P(B)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        have A3: "alephCARD-1K3 (succORDINAL1K1 B) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 B)"
          using card_1_lm_1 sorry
        have A4: "A inTARSKIR2 B implies  not (A inTARSKIR2 succORDINAL1K1 B &  not alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 (succORDINAL1K1 B))"
        proof(rule impI)
          assume "A inTARSKIR2 B"
          then have A5: "alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
            using A2 sorry
          have "alephCARD-1K3 B inTARSKIR2 nextcardCARD-1K2 (alephCARD-1K3 B)"
            using card_1_th_18 sorry
          thus " not (A inTARSKIR2 succORDINAL1K1 B &  not alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 (succORDINAL1K1 B))"
            using A3 A5 ordinal1_th_10 sorry
        qed
        have A6: "A c<XBOOLE-0R2 B iff A c=ORDINAL1R1 B & A <>HIDDENR2 B"
           sorry
        assume "A inTARSKIR2 succORDINAL1K1 B"
        thus "alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 (succORDINAL1K1 B)"
          using A3 A6 A4 card_1_th_18 ordinal1_th_11 ordinal1_th_22 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for B be OrdinalORDINAL1M3 holds (B <>HIDDENR2 0ORDINAL1K5 & B be limit-ordinalORDINAL1V4) & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ?P(C)) implies ?P(B)"
    proof-
      have " for B be OrdinalORDINAL1M3 holds B <>HIDDENR2 0ORDINAL1K5 & (B be limit-ordinalORDINAL1V4 & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 C implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 C))) implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 B implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B)"
      proof(rule ballI,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
        fix B assume [ty]: "B be OrdinalORDINAL1M3"
        assume A8: "B <>HIDDENR2 0ORDINAL1K5"
          and A9: "B be limit-ordinalORDINAL1V4"
          and " for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies ( for A be OrdinalORDINAL1M3 holds A inTARSKIR2 C implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 C)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        obtain S where
          [ty]:"S be SequenceORDINAL1M4" and 
          A10: "domRELAT-1K1 S =XBOOLE-0R4 B & ( for C be OrdinalORDINAL1M3 holds C inTARSKIR2 B implies S .FUNCT-1K1 C =XBOOLE-0R4 alephCARD-1K3 C)"
          using ordinal2_sch_2 sorry
        assume "A inTARSKIR2 B"
        then have "succORDINAL1K1 A inTARSKIR2 B"
          using A9 ordinal1_th_28 sorry
        then have A11: "S .FUNCT-1K1 succORDINAL1K1 A inTARSKIR2 rngFUNCT-1K2 S & S .FUNCT-1K1 succORDINAL1K1 A =XBOOLE-0R4 alephCARD-1K3 (succORDINAL1K1 A)"
          using A10 funct_1_def_3 sorry
        have "supORDINAL2K3 (rngFUNCT-1K2 S) =XBOOLE-0R4 supORDINAL2K4 S"
          using ordinal2_th_26 sorry
        then have A12: "alephCARD-1K3 (succORDINAL1K1 A) c=ORDINAL1R1 supORDINAL2K4 S"
          using A11 ordinal1_def_2 ordinal2_th_19 sorry
        have A13: "cardCARD-1K1 (alephCARD-1K3 (succORDINAL1K1 A)) =XBOOLE-0R4 alephCARD-1K3 (succORDINAL1K1 A)"
           sorry
        have A14: "alephCARD-1K3 (succORDINAL1K1 A) =XBOOLE-0R4 nextcardCARD-1K2 (alephCARD-1K3 A) & alephCARD-1K3 A inTARSKIR2 nextcardCARD-1K2 (alephCARD-1K3 A)"
          using card_1_th_18 card_1_lm_1 sorry
        have "alephCARD-1K3 B =XBOOLE-0R4 cardCARD-1K1 supORDINAL2K4 S"
          using A8 A9 A10 card_1_lm_1 sorry
        then have "alephCARD-1K3 (succORDINAL1K1 A) c=ORDINAL1R1 alephCARD-1K3 B"
          using A12 A13 card_1_th_11 sorry
        thus "alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
          using A14 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A15: "?P(0ORDINAL1K5)"
       sorry
    have A16: " for B be OrdinalORDINAL1M3 holds ?P(B)"
      using ordinal2_sch_1 A15 A1 A7 sorry
    thus "A inTARSKIR2 B implies alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
       sorry
    assume A17: "alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
    then have A18: "alephCARD-1K3 A <>HIDDENR2 alephCARD-1K3 B"
       sorry
    have " not B inTARSKIR2 A"
      using A16 A17 sorry
    thus "A inTARSKIR2 B"
      using A18 ordinal1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_22:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds alephCARD-1K3 A =XBOOLE-0R4 alephCARD-1K3 B implies A =XBOOLE-0R4 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds alephCARD-1K3 A =XBOOLE-0R4 alephCARD-1K3 B implies A =XBOOLE-0R4 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    assume A1: "alephCARD-1K3 A =XBOOLE-0R4 alephCARD-1K3 B"
    have A2: "B inTARSKIR2 A implies  False "
    proof(rule impI)
      assume "B inTARSKIR2 A"
      then have "alephCARD-1K3 B inTARSKIR2 alephCARD-1K3 A"
        using card_1_th_21 sorry
      thus " False "
        using A1 sorry
    qed
    have "A inTARSKIR2 B implies  False "
    proof(rule impI)
      assume "A inTARSKIR2 B"
      then have "alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
        using card_1_th_21 sorry
      thus " False "
        using A1 sorry
    qed
    thus "A =XBOOLE-0R4 B"
      using A2 ordinal1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_23:
" for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds A c=ORDINAL1R1 B iff alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for B be OrdinalORDINAL1M3 holds  not (A c=ORDINAL1R1 B &  not alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B) &  not (alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B &  not A c=ORDINAL1R1 B)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix B assume [ty]: "B be OrdinalORDINAL1M3"
    have A1: "alephCARD-1K3 A c<XBOOLE-0R2 alephCARD-1K3 B iff alephCARD-1K3 A <>HIDDENR2 alephCARD-1K3 B & alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B"
       sorry
    have "A inTARSKIR2 B iff alephCARD-1K3 A inTARSKIR2 alephCARD-1K3 B"
      using card_1_th_21 sorry
    thus " not (A c=ORDINAL1R1 B &  not alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B) &  not (alephCARD-1K3 A c=ORDINAL1R1 alephCARD-1K3 B &  not A c=ORDINAL1R1 B)"
      using A1 card_1_th_22 ordinal1_th_11 xboole_0_def_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_24:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 Y & Y c=TARSKIR1 Z) & (X,Z)are-equipotentWELLORD2R2 implies (X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds (X c=TARSKIR1 Y & Y c=TARSKIR1 Z) & (X,Z)are-equipotentWELLORD2R2 implies (X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    assume A1: "X c=TARSKIR1 Y & Y c=TARSKIR1 Z"
      and A2: "(X,Z)are-equipotentWELLORD2R2"
    have A3: "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 Z"
      using A2 card_1_th_5 sorry
    have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y & cardCARD-1K1 Y c=ORDINAL1R1 cardCARD-1K1 Z"
      using A1 card_1_th_11 sorry
    thus "(X,Y)are-equipotentWELLORD2R2 & (Y,Z)are-equipotentWELLORD2R2"
      using A3 card_1_th_5 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_25:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds boolZFMISC-1K1 Y c=TARSKIR1 X implies cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X &  not (Y,X)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds boolZFMISC-1K1 Y c=TARSKIR1 X implies cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X &  not (Y,X)are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "boolZFMISC-1K1 Y c=TARSKIR1 X"
    then have "cardCARD-1K1 (boolZFMISC-1K1 Y) c=ORDINAL1R1 cardCARD-1K1 X"
      using card_1_th_11 sorry
    thus "cardCARD-1K1 Y inTARSKIR2 cardCARD-1K1 X"
      using card_1_th_14 sorry
    then have "cardCARD-1K1 Y <>HIDDENR2 cardCARD-1K1 X"
       sorry
    thus " not (Y,X)are-equipotentWELLORD2R2"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_26:
" for X be setHIDDENM2 holds (X,{}XBOOLE-0K1)are-equipotentWELLORD2R2 implies X =XBOOLE-0R4 {}XBOOLE-0K1"
  using relat_1_th_42 sorry

mtheorem card_1_th_27:
"cardCARD-1K1 ({}XBOOLE-0K1) =XBOOLE-0R4 0ORDINAL1K5"
   sorry

mtheorem card_1_th_28:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (X,{TARSKIK1 x})are-equipotentWELLORD2R2 iff ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds ((X,{TARSKIK1 x})are-equipotentWELLORD2R2 implies ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})) & (( ex y be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 y}) implies (X,{TARSKIK1 x})are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    show "(X,{TARSKIK1 x})are-equipotentWELLORD2R2 implies ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
    proof-
      have "(X,{TARSKIK1 x})are-equipotentWELLORD2R2 implies  not ( for x be objectHIDDENM1 holds  not X =XBOOLE-0R4 {TARSKIK1 x})"
      proof(rule impI)
        assume "(X,{TARSKIK1 x})are-equipotentWELLORD2R2"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          "f be one-to-oneFUNCT-1V2"and A1: "domRELAT-1K1 f =XBOOLE-0R4 {TARSKIK1 x}"and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 X"
          using wellord2_def_4 sorry
        have "rngFUNCT-1K2 f =XBOOLE-0R4 {TARSKIK1 f .FUNCT-1K1 x }"
          using A1 funct_1_th_4 sorry
        thus " not ( for x be objectHIDDENM1 holds  not X =XBOOLE-0R4 {TARSKIK1 x})"
          using A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex y be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 y}"
    then obtain y where
      [ty]:"y be objectHIDDENM1" and 
      A3: "X =XBOOLE-0R4 {TARSKIK1 y}"
       sorry
    obtain f where 
      [ty]:"f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])" and fDef:"f = X -->FUNCOP-1K7 x"
       sorry
    have " ex f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :]) st f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngRELAT-1K2 f =HIDDENR1 {TARSKIK1 x})"
    proof(rule bexI[of _ "f"],rule conjMI,rule conjMI)
      have A4: "domRELAT-1K1 f =XBOOLE-0R4 X"
        using funcop_1_th_13 sorry
      show "f be one-to-oneFUNCT-1V2"
      proof-
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds a inHIDDENR3 domRELAT-1K1 f & (b inHIDDENR3 domRELAT-1K1 f & f .FUNCT-1K1 a =XBOOLE-0R4 f .FUNCT-1K1 b) implies a =HIDDENR1 b"
        proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          assume A5: "a inHIDDENR3 domRELAT-1K1 f"
            and A6: "b inHIDDENR3 domRELAT-1K1 f"
            and "f .FUNCT-1K1 a =XBOOLE-0R4 f .FUNCT-1K1 b"
          have "a =HIDDENR1 y"
            using A3 A4 A5 tarski_def_1 sorry
          thus "a =HIDDENR1 b"
            using A3 A4 A6 tarski_def_1 sorry
        qed "sorry"
        thus "f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 f =XBOOLE-0R4 X"
        using funcop_1_th_13 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 x} & {TARSKIK1 x} c=TARSKIR1 rngRELAT-1K2 f"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 {TARSKIK1 x}"
          using funcop_1_th_13 sorry
        have " for a be objectHIDDENM1 holds a inHIDDENR3 {TARSKIK1 x} implies a inHIDDENR3 rngRELAT-1K2 f"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          assume "a inHIDDENR3 {TARSKIK1 x}"
          then have A7: "a =HIDDENR1 x"
            using tarski_def_1 sorry
          have A8: "y inHIDDENR3 {TARSKIK1 y}"
            using tarski_def_1 sorry
          then have "f .FUNCT-1K1 y =HIDDENR1 x"
            using A3 funcop_1_th_7 sorry
          thus "a inHIDDENR3 rngRELAT-1K2 f"
            using A3 A4 A7 A8 funct_1_def_3 sorry
        qed "sorry"
        thus "{TARSKIK1 x} c=TARSKIR1 rngRELAT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus "rngRELAT-1K2 f =HIDDENR1 {TARSKIK1 x}"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus "(X,{TARSKIK1 x})are-equipotentWELLORD2R2"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_29:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 {TARSKIK1 x} iff ( ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x})"
  using card_1_th_5 card_1_th_28 sorry

mtheorem card_1_th_30:
" for x be objectHIDDENM1 holds cardCARD-1K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
proof(rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  have A1: "\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
     sorry
  have "\<one>\<^sub>M be cardinalCARD-1V1"
  proof-
    obtain IT where 
      [ty]:"IT be ElementSUBSET-1M1-of omegaORDINAL1K4" and ITDef:"IT = \<one>\<^sub>M"
       sorry
    have " ex IT be ElementSUBSET-1M1-of omegaORDINAL1K4 st \<one>\<^sub>M =XBOOLE-0R4 IT & ( for A be OrdinalORDINAL1M3 holds (A,IT)are-equipotentWELLORD2R2 implies IT c=ORDINAL1R1 A)"
    proof(rule bexI[of _ "IT"],rule conjMI,rule ballI,rule impI)
      show "\<one>\<^sub>M =XBOOLE-0R4 IT"
         sorry
      fix A assume [ty]: "A be OrdinalORDINAL1M3"
      assume "(A,IT)are-equipotentWELLORD2R2"
      then have " ex y be objectHIDDENM1 st A =XBOOLE-0R4 {TARSKIK1 y}"
        using A1 card_1_th_28 sorry
      thus "IT c=ORDINAL1R1 A"
        using A1 zfmisc_1_th_33 sorry
    qed "sorry"
    thus "\<one>\<^sub>M be cardinalCARD-1V1"
      using card_1_def_1 sorry
  qed
  then obtain M where 
    [ty]:"M be CardinalCARD-1M1" and MDef:"M = \<one>\<^sub>M"
     sorry
  have "({TARSKIK1 x},M)are-equipotentWELLORD2R2"
    using A1 card_1_th_28 sorry
  thus "cardCARD-1K1 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
    using card_1_def_2 sorry
qed "sorry"

mtheorem card_1_th_31:
" for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds ((X missesXBOOLE-0R1 X1 & Y missesXBOOLE-0R1 Y1) & (X,Y)are-equipotentWELLORD2R2) & (X1,Y1)are-equipotentWELLORD2R2 implies (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for X1 be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Y1 be setHIDDENM2 holds  not ((((X missesXBOOLE-0R1 X1 & Y missesXBOOLE-0R1 Y1) & (X,Y)are-equipotentWELLORD2R2) & (X1,Y1)are-equipotentWELLORD2R2) &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix X1 assume [ty]: "X1 be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Y1 assume [ty]: "Y1 be setHIDDENM2"
    have "X /\\XBOOLE-0K3 X1 =XBOOLE-0R4 {}XBOOLE-0K1 & Y /\\XBOOLE-0K3 Y1 =XBOOLE-0R4 {}XBOOLE-0K1 implies  not (((X,Y)are-equipotentWELLORD2R2 & (X1,Y1)are-equipotentWELLORD2R2) &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
    proof(rule impMI ,rule impI)
      assume A1: "X /\\XBOOLE-0K3 X1 =XBOOLE-0R4 {}XBOOLE-0K1"
        and A2: "Y /\\XBOOLE-0K3 Y1 =XBOOLE-0R4 {}XBOOLE-0K1"
      have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies  not ((X1,Y1)are-equipotentWELLORD2R2 &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
      proof(rule impI)
        assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A3: "f be one-to-oneFUNCT-1V2"and A4: "domRELAT-1K1 f =XBOOLE-0R4 X"and A5: "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
           sorry
        have "( ex g be FunctionFUNCT-1M1 st (g be one-to-oneFUNCT-1V2 & domRELAT-1K1 g =XBOOLE-0R4 X1) & rngFUNCT-1K2 g =XBOOLE-0R4 Y1) implies (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2"
        proof(rule impI)
          assume Given: " ex g be FunctionFUNCT-1M1 st (g be one-to-oneFUNCT-1V2 & domRELAT-1K1 g =XBOOLE-0R4 X1) & rngFUNCT-1K2 g =XBOOLE-0R4 Y1"
          then obtain g where
            [ty]:"g be FunctionFUNCT-1M1" and 
            A6: "g be one-to-oneFUNCT-1V2"and A7: "domRELAT-1K1 g =XBOOLE-0R4 X1"and A8: "rngFUNCT-1K2 g =XBOOLE-0R4 Y1"
             sorry
          let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 inHIDDENR3 X & Lamb2 =HIDDENR1 f .FUNCT-1K1 Lamb1 or Lamb1 inHIDDENR3 X1 & Lamb2 =HIDDENR1 g .FUNCT-1K1 Lamb1"
          have A9: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 X1 implies ( ex y be objectHIDDENM1 st ?P(x,y))"
          proof-
            have " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 X1 implies  not ( for y be objectHIDDENM1 holds  not (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x or x inHIDDENR3 X1 & y =HIDDENR1 g .FUNCT-1K1 x))"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be objectHIDDENM1"
              assume "x inHIDDENR3 X \\/XBOOLE-0K2 X1"
              then have "x inHIDDENR3 X or x inHIDDENR3 X1"
                using xboole_0_def_3 sorry
              thus " not ( for y be objectHIDDENM1 holds  not (x inHIDDENR3 X & y =HIDDENR1 f .FUNCT-1K1 x or x inHIDDENR3 X1 & y =HIDDENR1 g .FUNCT-1K1 x))"
                 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          have A10: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 X \\/XBOOLE-0K2 X1 & ?P(x,y)) & ?P(x,z) implies y =HIDDENR1 z"
            using A1 xboole_0_def_4 sorry
          obtain h where
            [ty]:"h be FunctionFUNCT-1M1" and 
            A11: "domRELAT-1K1 h =XBOOLE-0R4 X \\/XBOOLE-0K2 X1"and A12: " for x be objectHIDDENM1 holds x inHIDDENR3 X \\/XBOOLE-0K2 X1 implies ?P(x,h .FUNCT-1K1 x)"
            using funct_1_sch_2 A10 A9 sorry
          have "h be one-to-oneFUNCT-1V2 & (domRELAT-1K1 h =XBOOLE-0R4 X \\/XBOOLE-0K2 X1 & rngRELAT-1K2 h =HIDDENR1 Y \\/XBOOLE-0K2 Y1)"
          proof(rule conjMI,rule conjMI)
            show "h be one-to-oneFUNCT-1V2"
            proof-
              have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 h & (y inHIDDENR3 domRELAT-1K1 h & h .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 y) implies x =HIDDENR1 y"
              proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                fix y assume [ty]: "y be objectHIDDENM1"
                assume A13: "x inHIDDENR3 domRELAT-1K1 h"
                  and A14: "y inHIDDENR3 domRELAT-1K1 h"
                  and A15: "h .FUNCT-1K1 x =XBOOLE-0R4 h .FUNCT-1K1 y"
                have A16: "y inHIDDENR3 X & h .FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 y or y inHIDDENR3 X1 & h .FUNCT-1K1 y =XBOOLE-0R4 g .FUNCT-1K1 y"
                  using A11 A12 A14 sorry
                have A17: "x inHIDDENR3 X & h .FUNCT-1K1 x =XBOOLE-0R4 f .FUNCT-1K1 x or x inHIDDENR3 X1 & h .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 x"
                  using A11 A12 A13 sorry
                have A18: "y inHIDDENR3 X & x inHIDDENR3 X1 implies  False "
                proof(rule impI)
                  assume A19: "y inHIDDENR3 X & x inHIDDENR3 X1"
                  then have "f .FUNCT-1K1 y inTARSKIR2 Y & g .FUNCT-1K1 x inTARSKIR2 Y1"
                    using A4 A5 A7 A8 funct_1_def_3 sorry
                  thus " False "
                    using A1 A2 A15 A17 A16 A19 xboole_0_def_4 sorry
                qed
                have "x inHIDDENR3 X & y inHIDDENR3 X1 implies  False "
                proof(rule impI)
                  assume A20: "x inHIDDENR3 X & y inHIDDENR3 X1"
                  then have "f .FUNCT-1K1 x inTARSKIR2 Y & g .FUNCT-1K1 y inTARSKIR2 Y1"
                    using A4 A5 A7 A8 funct_1_def_3 sorry
                  thus " False "
                    using A1 A2 A15 A17 A16 A20 xboole_0_def_4 sorry
                qed
                thus "x =HIDDENR1 y"
                  using A3 A4 A6 A7 A15 A17 A16 A18 sorry
              qed "sorry"
              thus "h be one-to-oneFUNCT-1V2"
                using funct_1_def_4 sorry
            qed
            show "domRELAT-1K1 h =XBOOLE-0R4 X \\/XBOOLE-0K2 X1"
              using A11 sorry
            have "rngFUNCT-1K2 h c=TARSKIR1 Y \\/XBOOLE-0K2 Y1 & Y \\/XBOOLE-0K2 Y1 c=TARSKIR1 rngRELAT-1K2 h"
            proof(rule conjMI)
              show "rngFUNCT-1K2 h c=TARSKIR1 Y \\/XBOOLE-0K2 Y1"
              proof-
                have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 h implies x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                proof(rule ballI,rule impI)
                  fix x assume [ty]: "x be objectHIDDENM1"
                  assume "x inHIDDENR3 rngFUNCT-1K2 h"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A21: "y inHIDDENR3 domRELAT-1K1 h"and A22: "x =HIDDENR1 h .FUNCT-1K1 y"
                    using funct_1_def_3 sorry
                  have A23: "y inHIDDENR3 X & x =HIDDENR1 f .FUNCT-1K1 y or y inHIDDENR3 X1 & x =HIDDENR1 g .FUNCT-1K1 y"
                    using A11 A12 A21 A22 sorry
                  have A24: "y inHIDDENR3 X1 implies x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                  proof(rule impI)
                    assume "y inHIDDENR3 X1"
                    then have "x inHIDDENR3 Y1"
                      using A1 A7 A8 A23 funct_1_def_3 xboole_0_def_4 sorry
                    thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                      using xboole_0_def_3 sorry
                  qed
                  have "y inHIDDENR3 X implies x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                  proof(rule impI)
                    assume "y inHIDDENR3 X"
                    then have "x inHIDDENR3 Y"
                      using A1 A4 A5 A23 funct_1_def_3 xboole_0_def_4 sorry
                    thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                      using xboole_0_def_3 sorry
                  qed
                  thus "x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                    using A11 A21 A24 xboole_0_def_3 sorry
                qed "sorry"
                thus "rngFUNCT-1K2 h c=TARSKIR1 Y \\/XBOOLE-0K2 Y1"
                  using tarski_def_3 sorry
              qed
              have " for x be objectHIDDENM1 holds x inHIDDENR3 Y \\/XBOOLE-0K2 Y1 implies x inHIDDENR3 rngRELAT-1K2 h"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume A25: "x inHIDDENR3 Y \\/XBOOLE-0K2 Y1"
                have A26: "x inHIDDENR3 Y1 implies x inHIDDENR3 rngRELAT-1K2 h"
                proof(rule impI)
                  assume "x inHIDDENR3 Y1"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A27: "y inHIDDENR3 domRELAT-1K1 g"and A28: "x =HIDDENR1 g .FUNCT-1K1 y"
                    using A8 funct_1_def_3 sorry
                  have A29: "y inHIDDENR3 X \\/XBOOLE-0K2 X1"
                    using A7 A27 xboole_0_def_3 sorry
                  then have "?P(y,h .FUNCT-1K1 y)"
                    using A12 sorry
                  thus "x inHIDDENR3 rngRELAT-1K2 h"
                    using A1 A7 A11 A27 A28 A29 funct_1_def_3 xboole_0_def_4 sorry
                qed
                have "x inHIDDENR3 Y implies x inHIDDENR3 rngRELAT-1K2 h"
                proof(rule impI)
                  assume "x inHIDDENR3 Y"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A30: "y inHIDDENR3 domRELAT-1K1 f"and A31: "x =HIDDENR1 f .FUNCT-1K1 y"
                    using A5 funct_1_def_3 sorry
                  have A32: "y inHIDDENR3 X \\/XBOOLE-0K2 X1"
                    using A4 A30 xboole_0_def_3 sorry
                  then have "?P(y,h .FUNCT-1K1 y)"
                    using A12 sorry
                  thus "x inHIDDENR3 rngRELAT-1K2 h"
                    using A1 A4 A11 A30 A31 A32 funct_1_def_3 xboole_0_def_4 sorry
                qed
                thus "x inHIDDENR3 rngRELAT-1K2 h"
                  using A25 A26 xboole_0_def_3 sorry
              qed "sorry"
              thus "Y \\/XBOOLE-0K2 Y1 c=TARSKIR1 rngRELAT-1K2 h"
                using tarski_def_3 sorry
            qed
            thus "rngRELAT-1K2 h =HIDDENR1 Y \\/XBOOLE-0K2 Y1"
              using xboole_0_def_10 sorry
          qed
          thus "(X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2"
            using bexI[of _ "h"] wellord2_def_4 sorry
        qed
        thus " not ((X1,Y1)are-equipotentWELLORD2R2 &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
          using wellord2_def_4 sorry
      qed
      thus " not (((X,Y)are-equipotentWELLORD2R2 & (X1,Y1)are-equipotentWELLORD2R2) &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
        using wellord2_def_4 sorry
    qed
    thus " not ((((X missesXBOOLE-0R1 X1 & Y missesXBOOLE-0R1 Y1) & (X,Y)are-equipotentWELLORD2R2) & (X1,Y1)are-equipotentWELLORD2R2) &  not (X \\/XBOOLE-0K2 X1,Y \\/XBOOLE-0K2 Y1)are-equipotentWELLORD2R2)"
      using xboole_0_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_32:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 X implies (X \\SUBSET-1K6 {TARSKIK1 x},X \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 X & y inHIDDENR3 X implies (X \\SUBSET-1K6 {TARSKIK1 x},X \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume A1: "x inHIDDENR3 X"
      and A2: "y inHIDDENR3 X"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. Lamb1 =HIDDENR1 y & Lamb2 =HIDDENR1 x or Lamb1 <>HIDDENR2 y & Lamb1 =HIDDENR1 Lamb2"
    have A3: " for a be objectHIDDENM1 holds a inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x} implies ( ex b be objectHIDDENM1 st ?P(a,b))"
    proof-
      have " for a be objectHIDDENM1 holds a inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x} implies  not ( for b be objectHIDDENM1 holds  not (a =HIDDENR1 y & b =HIDDENR1 x or a <>HIDDENR2 y & a =HIDDENR1 b))"
      proof(rule ballI,rule impI)
        fix a assume [ty]: "a be objectHIDDENM1"
        assume "a inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
        have "a =HIDDENR1 y implies  not ( for b be objectHIDDENM1 holds  not ?P(a,b))"
           sorry
        thus " not ( for b be objectHIDDENM1 holds  not (a =HIDDENR1 y & b =HIDDENR1 x or a <>HIDDENR2 y & a =HIDDENR1 b))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for a be objectHIDDENM1 holds  for b1 be objectHIDDENM1 holds  for b2 be objectHIDDENM1 holds (a inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x} & ?P(a,b1)) & ?P(a,b2) implies b1 =HIDDENR1 b2"
       sorry
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A5: "domRELAT-1K1 f =XBOOLE-0R4 X \\SUBSET-1K6 {TARSKIK1 x} & ( for a be objectHIDDENM1 holds a inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x} implies ?P(a,f .FUNCT-1K1 a))"
      using funct_1_sch_2 A4 A3 sorry
    have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X \\SUBSET-1K6 {TARSKIK1 x} & rngRELAT-1K2 f =HIDDENR1 X \\SUBSET-1K6 {TARSKIK1 y})"
    proof(rule conjMI,rule conjMI)
      show "f be one-to-oneFUNCT-1V2"
      proof-
        have " for b1 be objectHIDDENM1 holds  for b2 be objectHIDDENM1 holds (b1 inHIDDENR3 domRELAT-1K1 f & b2 inHIDDENR3 domRELAT-1K1 f) & (f .FUNCT-1K1 b1 =XBOOLE-0R4 f .FUNCT-1K1 b2 & b1 <>HIDDENR2 b2) implies  not  True "
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix b1 assume [ty]: "b1 be objectHIDDENM1"
          fix b2 assume [ty]: "b2 be objectHIDDENM1"
          assume A6: "b1 inHIDDENR3 domRELAT-1K1 f & b2 inHIDDENR3 domRELAT-1K1 f"
            and A7: "f .FUNCT-1K1 b1 =XBOOLE-0R4 f .FUNCT-1K1 b2 & b1 <>HIDDENR2 b2"
          have A8: " not b1 inHIDDENR3 {TARSKIK1 x} &  not b2 inHIDDENR3 {TARSKIK1 x}"
            using A5 A6 xboole_0_def_5 sorry
          have "?P(b1,f .FUNCT-1K1 b1) & ?P(b2,f .FUNCT-1K1 b2)"
            using A5 A6 sorry
          thus " not  True "
            using A7 A8 tarski_def_1 sorry
        qed "sorry"
        thus "f be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 f =XBOOLE-0R4 X \\SUBSET-1K6 {TARSKIK1 x}"
        using A5 sorry
      have "rngFUNCT-1K2 f c=TARSKIR1 X \\SUBSET-1K6 {TARSKIK1 y} & X \\SUBSET-1K6 {TARSKIK1 y} c=TARSKIR1 rngRELAT-1K2 f"
      proof(rule conjMI)
        show "rngFUNCT-1K2 f c=TARSKIR1 X \\SUBSET-1K6 {TARSKIK1 y}"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngFUNCT-1K2 f implies z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 rngFUNCT-1K2 f"
            then obtain a where
              [ty]:"a be objectHIDDENM1" and 
              A9: "a inHIDDENR3 domRELAT-1K1 f"and A10: "z =HIDDENR1 f .FUNCT-1K1 a"
              using funct_1_def_3 sorry
            have A11: "a =HIDDENR1 y implies z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
            proof(rule impI)
              assume A12: "a =HIDDENR1 y"
              then have " not y inHIDDENR3 {TARSKIK1 x} & z =HIDDENR1 x"
                using A5 A9 A10 xboole_0_def_5 sorry
              then have "y <>HIDDENR2 z"
                using tarski_def_1 sorry
              then have A13: " not z inHIDDENR3 {TARSKIK1 y}"
                using tarski_def_1 sorry
              have "z inHIDDENR3 X"
                using A1 A5 A9 A10 A12 sorry
              thus "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
                using A13 xboole_0_def_5 sorry
            qed
            have "a <>HIDDENR2 y implies z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
            proof(rule impI)
              assume "a <>HIDDENR2 y"
              then have " not a inHIDDENR3 {TARSKIK1 y} & a =HIDDENR1 z"
                using A5 A9 A10 tarski_def_1 sorry
              thus "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
                using A5 A9 xboole_0_def_5 sorry
            qed
            thus "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
              using A11 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 f c=TARSKIR1 X \\SUBSET-1K6 {TARSKIK1 y}"
            using tarski_def_3 sorry
        qed
        have " for z be objectHIDDENM1 holds z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y} implies z inHIDDENR3 rngRELAT-1K2 f"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A14: "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 y}"
          then have " not z inHIDDENR3 {TARSKIK1 y}"
            using xboole_0_def_5 sorry
          then have A15: "z <>HIDDENR2 y"
            using tarski_def_1 sorry
          have A16: "z <>HIDDENR2 x implies z inHIDDENR3 rngRELAT-1K2 f"
          proof(rule impI)
            assume "z <>HIDDENR2 x"
            then have " not z inHIDDENR3 {TARSKIK1 x}"
              using tarski_def_1 sorry
            then have A17: "z inHIDDENR3 X \\SUBSET-1K6 {TARSKIK1 x}"
              using A14 xboole_0_def_5 sorry
            then have "z =HIDDENR1 f .FUNCT-1K1 z"
              using A5 A15 sorry
            thus "z inHIDDENR3 rngRELAT-1K2 f"
              using A5 A17 funct_1_def_3 sorry
          qed
          have "z =HIDDENR1 x implies z inHIDDENR3 rngRELAT-1K2 f"
          proof(rule impI)
            assume A18: "z =HIDDENR1 x"
            then have " not y inHIDDENR3 {TARSKIK1 x}"
              using A15 tarski_def_1 sorry
            then have A19: "y inHIDDENR3 domRELAT-1K1 f"
              using A2 A5 xboole_0_def_5 sorry
            then have "z =HIDDENR1 f .FUNCT-1K1 y"
              using A5 A18 sorry
            thus "z inHIDDENR3 rngRELAT-1K2 f"
              using A19 funct_1_def_3 sorry
          qed
          thus "z inHIDDENR3 rngRELAT-1K2 f"
            using A16 sorry
        qed "sorry"
        thus "X \\SUBSET-1K6 {TARSKIK1 y} c=TARSKIR1 rngRELAT-1K2 f"
          using tarski_def_3 sorry
      qed
      thus "rngRELAT-1K2 f =HIDDENR1 X \\SUBSET-1K6 {TARSKIK1 y}"
        using xboole_0_def_10 sorry
    qed
    thus "(X \\SUBSET-1K6 {TARSKIK1 x},X \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
      using bexI[of _ "f"] wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_33:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f be one-to-oneFUNCT-1V2 implies (X,f .:FUNCT-1K5 X)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds X c=TARSKIR1 domRELAT-1K1 f & f be one-to-oneFUNCT-1V2 implies (X,f .:FUNCT-1K5 X)are-equipotentWELLORD2R2"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "X c=TARSKIR1 domRELAT-1K1 f"
      and A2: "f be one-to-oneFUNCT-1V2"
    obtain g where 
      [ty]:"g be setHIDDENM2" and gDef:"g = f  |RELAT-1K8 X"
       sorry
    have " ex g be setHIDDENM2 st g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 X & rngRELAT-1K2 g =HIDDENR1 f .:FUNCT-1K5 X)"
    proof(rule bexI[of _ "g"],rule conjMI,rule conjMI)
      show "g be one-to-oneFUNCT-1V2"
        using A2 funct_1_th_52 sorry
      show "domRELAT-1K1 g =XBOOLE-0R4 X"
        using A1 relat_1_th_62 sorry
      show "rngRELAT-1K2 g =HIDDENR1 f .:FUNCT-1K5 X"
        using relat_1_th_115 sorry
    qed "sorry"
    thus "(X,f .:FUNCT-1K5 X)are-equipotentWELLORD2R2"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_34:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ((X,Y)are-equipotentWELLORD2R2 & x inHIDDENR3 X) & y inHIDDENR3 Y implies (X \\SUBSET-1K6 {TARSKIK1 x},Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ((((X,Y)are-equipotentWELLORD2R2 & x inHIDDENR3 X) & y inHIDDENR3 Y) &  not (X \\SUBSET-1K6 {TARSKIK1 x},Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "( ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y) implies (x inHIDDENR3 X & y inHIDDENR3 Y implies (X \\SUBSET-1K6 {TARSKIK1 x},Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2)"
    proof(rule impI,rule impMI ,rule impI)
      assume Given: " ex f be FunctionFUNCT-1M1 st (f be one-to-oneFUNCT-1V2 & domRELAT-1K1 f =XBOOLE-0R4 X) & rngFUNCT-1K2 f =XBOOLE-0R4 Y"
      then obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A1: "f be one-to-oneFUNCT-1V2"and A2: "domRELAT-1K1 f =XBOOLE-0R4 X"and A3: "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
         sorry
      have A4: "(X \\SUBSET-1K6 {TARSKIK1 x},f .:FUNCT-1K5 (X \\SUBSET-1K6 {TARSKIK1 x}))are-equipotentWELLORD2R2"
        using A1 A2 card_1_th_33 sorry
      assume A5: "x inHIDDENR3 X"
        and A6: "y inHIDDENR3 Y"
      have "f .FUNCT-1K1 x inTARSKIR2 Y"
        using A2 A3 A5 funct_1_def_3 sorry
      then have A7: "(Y \\SUBSET-1K6 {TARSKIK1 f .FUNCT-1K1 x },Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
        using A6 card_1_th_32 sorry
      have "f .:FUNCT-1K5 (X \\SUBSET-1K6 {TARSKIK1 x}) =HIDDENR1 f .:FUNCT-1K5 X \\SUBSET-1K6 ImRELAT-1K12(f,x)"
        using A1 funct_1_th_64 sorry
      also have "... = Y \\SUBSET-1K6 ImRELAT-1K12(f,x)"
        using A2 A3 relat_1_th_113 sorry
      also have "... = Y \\SUBSET-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
        using A2 A5 funct_1_th_59 sorry
      finally have "f .:FUNCT-1K5 (X \\SUBSET-1K6 {TARSKIK1 x}) =HIDDENR1 Y \\SUBSET-1K6 {TARSKIK1 f .FUNCT-1K1 x }"
         sorry
      thus "(X \\SUBSET-1K6 {TARSKIK1 x},Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2"
        using A4 A7 wellord2_th_15 sorry
    qed
    thus " not ((((X,Y)are-equipotentWELLORD2R2 & x inHIDDENR3 X) & y inHIDDENR3 Y) &  not (X \\SUBSET-1K6 {TARSKIK1 x},Y \\SUBSET-1K6 {TARSKIK1 y})are-equipotentWELLORD2R2)"
      using wellord2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_35:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (succORDINAL1K1 X,succORDINAL1K1 Y)are-equipotentWELLORD2R2 implies (X,Y)are-equipotentWELLORD2R2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  not ((succORDINAL1K1 X,succORDINAL1K1 Y)are-equipotentWELLORD2R2 &  not (X,Y)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    have A1: "X inTARSKIR2 succORDINAL1K1 X & Y inTARSKIR2 succORDINAL1K1 Y"
      using ordinal1_th_6 sorry
    have "X =XBOOLE-0R4 succORDINAL1K1 X \\SUBSET-1K6 {TARSKIK1 X} & Y =XBOOLE-0R4 succORDINAL1K1 Y \\SUBSET-1K6 {TARSKIK1 Y}"
      using ordinal1_th_37 sorry
    thus " not ((succORDINAL1K1 X,succORDINAL1K1 Y)are-equipotentWELLORD2R2 &  not (X,Y)are-equipotentWELLORD2R2)"
      using A1 card_1_th_34 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_36:
" for n be NatORDINAL1M6 holds n =XBOOLE-0R4 {}XBOOLE-0K1 or ( ex m be NatORDINAL1M6 st n =XBOOLE-0R4 succORDINAL1K1 m)"
proof-
  have " for n be NatORDINAL1M6 holds n =XBOOLE-0R4 {}XBOOLE-0K1 or ( ex m be NatORDINAL1M6 st n =XBOOLE-0R4 succORDINAL1K1 m)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1. Lamb1 =XBOOLE-0R4 {}XBOOLE-0K1 or ( ex m be NatORDINAL1M6 st Lamb1 =XBOOLE-0R4 succORDINAL1K1 m)"
    have A1: " for a be NatORDINAL1M6 holds ?P(a) implies ?P(succORDINAL1K1 a)"
       sorry
    have A2: "?P(0ORDINAL1K5)"
       sorry
    show "n =XBOOLE-0R4 {}XBOOLE-0K1 or ( ex m be NatORDINAL1M6 st n =XBOOLE-0R4 succORDINAL1K1 m)"
      using ordinal2_sch_17 A2 A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_1_lm_2:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds (n,m)are-equipotentWELLORD2R2 implies n =XBOOLE-0R4 m"
proof-
  have " for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds  not ((n,m)are-equipotentWELLORD2R2 &  not n =XBOOLE-0R4 m)"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatORDINAL1M6"
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1.  for n be NatORDINAL1M6 holds (n,Lamb1)are-equipotentWELLORD2R2 implies n =XBOOLE-0R4 Lamb1"
    have A1: " for a be NatORDINAL1M6 holds ?P(a) implies ?P(succORDINAL1K1 a)"
    proof-
      have " for a be NatORDINAL1M6 holds ?P(a) implies ( for n be NatORDINAL1M6 holds (n,succORDINAL1K1 a)are-equipotentWELLORD2R2 implies n =XBOOLE-0R4 succORDINAL1K1 a)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix a assume [ty]: "a be NatORDINAL1M6"
        assume A2: "?P(a)"
        fix n assume [ty]: "n be NatORDINAL1M6"
        assume A3: "(n,succORDINAL1K1 a)are-equipotentWELLORD2R2"
        show "n =XBOOLE-0R4 succORDINAL1K1 a"
        proof-
          have cases: "n =XBOOLE-0R4 {}XBOOLE-0K1 or n <>HIDDENR2 {}XBOOLE-0K1"
             sorry
          have case1: "n =XBOOLE-0R4 {}XBOOLE-0K1 implies n =XBOOLE-0R4 succORDINAL1K1 a"
          proof(rule impI)
            assume "n =XBOOLE-0R4 {}XBOOLE-0K1"
            thus "n =XBOOLE-0R4 succORDINAL1K1 a"
              using A3 relat_1_th_42 sorry
          qed
          have case2: "n <>HIDDENR2 {}XBOOLE-0K1 implies n =XBOOLE-0R4 succORDINAL1K1 a"
          proof(rule impI)
            assume "n <>HIDDENR2 {}XBOOLE-0K1"
            then have " ex m be NatORDINAL1M6 st n =XBOOLE-0R4 succORDINAL1K1 m"
              using card_1_th_36 sorry
            thus "n =XBOOLE-0R4 succORDINAL1K1 a"
              using A2 A3 card_1_th_35 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P(0ORDINAL1K5)"
      using card_1_th_26 sorry
    have "?P(m)"
      using ordinal2_sch_17 A4 A1 sorry
    thus " not ((n,m)are-equipotentWELLORD2R2 &  not n =XBOOLE-0R4 m)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_37:
" for x be objectHIDDENM1 holds x inHIDDENR3 omegaORDINAL1K4 implies x be cardinalCARD-1V1"
proof-
  have " for x be objectHIDDENM1 holds  not (x inHIDDENR3 omegaORDINAL1K4 &  not x be cardinalCARD-1V1)"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    have "x inHIDDENR3 omegaORDINAL1K4 & ( for B be OrdinalORDINAL1M3 holds x =HIDDENR1 B implies ( ex C be OrdinalORDINAL1M3 st (C,B)are-equipotentWELLORD2R2 &  not B c=ORDINAL1R1 C)) implies  False "
    proof(rule impMI ,rule impI)
      assume A1: "x inHIDDENR3 omegaORDINAL1K4"
        and A2: " for B be OrdinalORDINAL1M3 holds x =HIDDENR1 B implies ( ex C be OrdinalORDINAL1M3 st (C,B)are-equipotentWELLORD2R2 &  not B c=ORDINAL1R1 C)"
      obtain A where 
        [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
        using A1 sorry
      obtain B where
        [ty]:"B be OrdinalORDINAL1M3" and 
        A3: "(B,A)are-equipotentWELLORD2R2"and A4: " not A c=ORDINAL1R1 B"
        using A2 sorry
      have "B inTARSKIR2 A"
        using A4 ordinal1_th_16 sorry
      then have "B inTARSKIR2 omegaORDINAL1K4"
        using A1 ordinal1_th_10 sorry
      then obtain n m where 
        [ty]:"n be NatORDINAL1M6" and nDef:"n = A" and
        [ty]:"m be NatORDINAL1M6" and mDef:"m = B"
        using A1 sorry
      have "(n,m)are-equipotentWELLORD2R2"
        using A3 sorry
      thus " False "
        using A4 card_1_lm_2 sorry
    qed
    thus " not (x inHIDDENR3 omegaORDINAL1K4 &  not x be cardinalCARD-1V1)"
      using card_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_cl_9:
"cluster naturalORDINAL1V7 also-is cardinalCARD-1V1 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it be naturalORDINAL1V7 implies it be cardinalCARD-1V1"
    using card_1_th_37 sorry
qed "sorry"

mtheorem card_1_th_38:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 & X be finiteFINSET-1V1 implies Y be finiteFINSET-1V1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (X,Y)are-equipotentWELLORD2R2 implies  not (X be finiteFINSET-1V1 &  not Y be finiteFINSET-1V1)"
  proof(rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume "(X,Y)are-equipotentWELLORD2R2"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      "f be one-to-oneFUNCT-1V2"and A1: "domRELAT-1K1 f =XBOOLE-0R4 X"and A2: "rngFUNCT-1K2 f =XBOOLE-0R4 Y"
       sorry
    have "( ex p be FunctionFUNCT-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 X & domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4) implies Y be finiteFINSET-1V1"
    proof(rule impI)
      assume Given: " ex p be FunctionFUNCT-1M1 st rngFUNCT-1K2 p =XBOOLE-0R4 X & domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
      then obtain p where
        [ty]:"p be FunctionFUNCT-1M1" and 
        A3: "rngFUNCT-1K2 p =XBOOLE-0R4 X"and A4: "domRELAT-1K1 p inTARSKIR2 omegaORDINAL1K4"
         sorry
      have "rngFUNCT-1K2 (f *FUNCT-1K3 p) =XBOOLE-0R4 Y & domRELAT-1K1 (f *FUNCT-1K3 p) inTARSKIR2 omegaORDINAL1K4"
      proof(rule conjMI)
        show "rngFUNCT-1K2 (f *FUNCT-1K3 p) =XBOOLE-0R4 Y"
          using A1 A2 A3 relat_1_th_28 sorry
        show "domRELAT-1K1 (f *FUNCT-1K3 p) inTARSKIR2 omegaORDINAL1K4"
          using A1 A3 A4 relat_1_th_27 sorry
      qed
      thus "Y be finiteFINSET-1V1"
        using bexI[of _ "f *FUNCT-1K3 p"] finset_1_def_1 sorry
    qed
    thus " not (X be finiteFINSET-1V1 &  not Y be finiteFINSET-1V1)"
      using finset_1_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_39:
" for n be NatORDINAL1M6 holds n be finiteFINSET-1V1 & cardCARD-1K1 n be finiteFINSET-1V1"
proof-
  have " for n be NatORDINAL1M6 holds n be finiteFINSET-1V1 & cardCARD-1K1 n be finiteFINSET-1V1"
  proof(rule ballI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    have 
      [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4"
      using ordinal1_def_12 sorry
    have "rngFUNCT-1K2 (idRELAT-1K7 n) =XBOOLE-0R4 n & domRELAT-1K1 (idRELAT-1K7 n) =XBOOLE-0R4 n"
      using relat_1_th_45 sorry
    thus "n be finiteFINSET-1V1 & cardCARD-1K1 n be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_40:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K1 n =XBOOLE-0R4 cardCARD-1K1 m implies n =XBOOLE-0R4 m"
   sorry

mtheorem card_1_th_41:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K1 n c=ORDINAL1R1 cardCARD-1K1 m iff n c=ORDINAL1R1 m"
   sorry

mtheorem card_1_th_42:
" for m be NatORDINAL1M6 holds  for n be NatORDINAL1M6 holds cardCARD-1K1 n inTARSKIR2 cardCARD-1K1 m iff n inTARSKIR2 m"
   sorry

mlemma card_1_lm_3:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex n be NatORDINAL1M6 st (X,n)are-equipotentWELLORD2R2)"
proof-
  have " for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies ( ex n be NatORDINAL1M6 st (X,n)are-equipotentWELLORD2R2)"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?P = "\<lambda>Lamb1.  ex n be NatORDINAL1M6 st (Lamb1,n)are-equipotentWELLORD2R2"
    have A1: "?P({}XBOOLE-0K1)"
       sorry
    have A2: " for Z be setHIDDENM2 holds  for Y be setHIDDENM2 holds (Z inTARSKIR2 X & Y c=TARSKIR1 X) & ?P(Y) implies ?P(Y \\/XBOOLE-0K2 {TARSKIK1 Z})"
    proof-
      have " for Z be setHIDDENM2 holds  for Y be setHIDDENM2 holds Z inTARSKIR2 X & Y c=TARSKIR1 X implies (( ex n be NatORDINAL1M6 st (Y,n)are-equipotentWELLORD2R2) implies ( ex n be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},n)are-equipotentWELLORD2R2))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
        fix Z assume [ty]: "Z be setHIDDENM2"
        fix Y assume [ty]: "Y be setHIDDENM2"
        assume "Z inTARSKIR2 X"
          and "Y c=TARSKIR1 X"
        assume Given: " ex n be NatORDINAL1M6 st (Y,n)are-equipotentWELLORD2R2"
        then obtain n where
          [ty]:"n be NatORDINAL1M6" and 
          A3: "(Y,n)are-equipotentWELLORD2R2"
           sorry
        have A4: " not Z inTARSKIR2 Y implies ?P(Y \\/XBOOLE-0K2 {TARSKIK1 Z})"
        proof-
          have " not Z inTARSKIR2 Y implies ( ex tVar20 be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},tVar20)are-equipotentWELLORD2R2)"
          proof(rule impI)
            assume A5: " not Z inTARSKIR2 Y"
            have "Y /\\XBOOLE-0K3 {TARSKIK1 Z} <>HIDDENR2 {}XBOOLE-0K1 implies  False "
            proof(rule impI)
              let ?x = "the ElementSUBSET-1M1-of Y /\\XBOOLE-0K3 {TARSKIK1 Z}"
              assume "Y /\\XBOOLE-0K3 {TARSKIK1 Z} <>HIDDENR2 {}XBOOLE-0K1"
              then have "?x inTARSKIR2 Y & ?x inTARSKIR2 {TARSKIK1 Z}"
                using xboole_0_def_4 sorry
              thus " False "
                using A5 tarski_def_1 sorry
            qed
            then have A6: "Y missesXBOOLE-0R1 {TARSKIK1 Z}"
               sorry
            have A7: "n meetsXBOOLE-0R5 {TARSKIK1 n} implies  False "
            proof(rule impI)
              assume "n meetsXBOOLE-0R5 {TARSKIK1 n}"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A8: "x inHIDDENR3 n"and A9: "x inHIDDENR3 {TARSKIK1 n}"
                using xboole_0_th_3 sorry
              have A: "x =HIDDENR1 n"
                using A9 tarski_def_1 sorry
              obtain xx where 
                [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
                using tarski_th_1 sorry
              have " not xx inTARSKIR2 xx"
                 sorry
              thus " False "
                using A8 A sorry
            qed
            show " ex tVar20 be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},tVar20)are-equipotentWELLORD2R2"
            proof(rule bexI[of _ "succORDINAL1K1 n"])
              have "({TARSKIK1 Z},{TARSKIK1 n})are-equipotentWELLORD2R2"
                using card_1_th_28 sorry
              thus "(Y \\/XBOOLE-0K2 {TARSKIK1 Z},succORDINAL1K1 n)are-equipotentWELLORD2R2"
                using A3 A7 A6 card_1_th_31 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        have "Z inTARSKIR2 Y implies ?P(Y \\/XBOOLE-0K2 {TARSKIK1 Z})"
        proof-
          have "Z inTARSKIR2 Y implies ( ex tVar21 be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},tVar21)are-equipotentWELLORD2R2)"
          proof(rule impI)
            assume A10: "Z inTARSKIR2 Y"
            show " ex tVar21 be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},tVar21)are-equipotentWELLORD2R2"
            proof(rule bexI[of _ "n"])
              show "(Y \\/XBOOLE-0K2 {TARSKIK1 Z},n)are-equipotentWELLORD2R2"
                using A3 A10 xboole_1_th_12 zfmisc_1_th_31 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        thus " ex n be NatORDINAL1M6 st (Y \\/XBOOLE-0K2 {TARSKIK1 Z},n)are-equipotentWELLORD2R2"
          using A4 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    assume A11: "X be finiteFINSET-1V1"
    show " ex n be NatORDINAL1M6 st (X,n)are-equipotentWELLORD2R2"
      using finset_1_sch_2 A11 A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*\$CT*)
mtheorem card_1_th_44:
" for n be NatORDINAL1M6 holds nextcardCARD-1K2 (cardCARD-1K1 n) =XBOOLE-0R4 cardCARD-1K1 (succORDINAL1K1 n)"
proof-
  have " for n be NatORDINAL1M6 holds nextcardCARD-1K2 (cardCARD-1K1 n) =XBOOLE-0R4 cardCARD-1K1 (succORDINAL1K1 n)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatORDINAL1M6"
    obtain sn where 
      [ty]:"sn be NatORDINAL1M6" and snDef:"sn = succORDINAL1K1 n"
       sorry
    have " for M be CardinalCARD-1M1 holds cardCARD-1K1 (cardCARD-1K1 n) inTARSKIR2 M implies cardCARD-1K1 (succORDINAL1K1 n) c=ORDINAL1R1 M"
      using ordinal1_th_21 sorry
    thus "nextcardCARD-1K2 (cardCARD-1K1 n) =XBOOLE-0R4 cardCARD-1K1 (succORDINAL1K1 n)"
      using card_1_def_3 ordinal1_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) CARD_1K4("cardCARD-1K4  _ " [228]228) where
  "cardCARD-1K4 X \<equiv> cardCARD-1K1 X"

mtheorem card_1_add_1:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is ElementSUBSET-1M1-of omegaORDINAL1K4"
proof
(*coherence*)
  show "cardCARD-1K1 X be ElementSUBSET-1M1-of omegaORDINAL1K4"
  proof-
    obtain n where
      [ty]:"n be NatORDINAL1M6" and 
      A1: "(X,n)are-equipotentWELLORD2R2"
      using card_1_lm_3 sorry
    have 
      [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4"
      using ordinal1_def_12 sorry
    have "(X,n)are-equipotentWELLORD2R2"
      using A1 sorry
    thus "cardCARD-1K1 X be ElementSUBSET-1M1-of omegaORDINAL1K4"
      using card_1_def_2 sorry
  qed
qed "sorry"

mtheorem card_1_th_45:
" for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies nextcardCARD-1K2 X be finiteFINSET-1V1"
proof-
  have " for X be setHIDDENM2 holds X be finiteFINSET-1V1 implies nextcardCARD-1K2 X be finiteFINSET-1V1"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    assume "X be finiteFINSET-1V1"
    then have 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2"
       sorry
    have "cardCARD-1K4 X =XBOOLE-0R4 cardCARD-1K1 (cardCARD-1K4 X)"
       sorry
    then have A1: "cardCARD-1K1 (succORDINAL1K1 (cardCARD-1K4 X)) =XBOOLE-0R4 nextcardCARD-1K2 (cardCARD-1K4 X)"
      using card_1_th_44 sorry
    have "nextcardCARD-1K2 (cardCARD-1K4 X) =XBOOLE-0R4 nextcardCARD-1K2 X"
      using card_1_def_2 card_1_th_17 sorry
    thus "nextcardCARD-1K2 X be finiteFINSET-1V1"
      using A1 card_1_th_39 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem card_1_sch_1:
  fixes Sigmap1 
  assumes
    A1: "Sigmap1({}XBOOLE-0K1)" and
   A2: " for M be CardinalCARD-1M1 holds Sigmap1(M) implies Sigmap1(nextcardCARD-1K2 M)" and
   A3: " for M be CardinalCARD-1M1 holds (M <>HIDDENR2 {}XBOOLE-0K1 & M be limit-cardinalCARD-1V2) & ( for N be CardinalCARD-1M1 holds N inTARSKIR2 M implies Sigmap1(N)) implies Sigmap1(M)"
  shows " for M be CardinalCARD-1M1 holds Sigmap1(M)"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 be CardinalCARD-1M1 implies Sigmap1(Lamb1)"
    have A4: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B be CardinalCARD-1M1 implies Sigmap1(B))) & A be CardinalCARD-1M1 implies Sigmap1(A)"
      proof(rule ballI,rule impMI ,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A5: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)"
          and A6: "A be CardinalCARD-1M1"
        obtain M where 
          [ty]:"M be CardinalCARD-1M1" and MDef:"M = A"
          using A6 sorry
        have A7: " not M be limit-cardinalCARD-1V2 implies Sigmap1(M)"
        proof(rule impI)
          assume " not M be limit-cardinalCARD-1V2"
          then obtain N where
            [ty]:"N be CardinalCARD-1M1" and 
            A8: "M =XBOOLE-0R4 nextcardCARD-1K2 N"
             sorry
          have "N inTARSKIR2 M"
            using A8 card_1_th_18 sorry
          thus "Sigmap1(M)"
            using A2 A5 A8 sorry
        qed
        have "M <>HIDDENR2 {}XBOOLE-0K1 & M be limit-cardinalCARD-1V2 implies Sigmap1(M)"
        proof(rule impI)
          assume A9: "M <>HIDDENR2 {}XBOOLE-0K1 & M be limit-cardinalCARD-1V2"
          have " for N be CardinalCARD-1M1 holds N inTARSKIR2 M implies Sigmap1(N)"
            using A5 sorry
          thus "Sigmap1(M)"
            using A3 A9 sorry
        qed
        thus "Sigmap1(A)"
          using A1 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal1_sch_2 A4 sorry
    thus "Sigmap1(M)"
       sorry
  qed "sorry"

theorem card_1_sch_2:
  fixes Sigmap1 
  assumes
    A1: " for M be CardinalCARD-1M1 holds ( for N be CardinalCARD-1M1 holds N inTARSKIR2 M implies Sigmap1(N)) implies Sigmap1(M)"
  shows " for M be CardinalCARD-1M1 holds Sigmap1(M)"
  proof(rule ballI)
    fix M assume [ty]: "M be CardinalCARD-1M1"
    let ?P = "\<lambda>Lamb1. Lamb1 be CardinalCARD-1M1 implies Sigmap1(Lamb1)"
    have A2: " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies ?P(B)) implies ?P(A)"
    proof-
      have " for A be OrdinalORDINAL1M3 holds ( for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B be CardinalCARD-1M1 implies Sigmap1(B))) implies (A be CardinalCARD-1M1 implies Sigmap1(A))"
      proof(rule ballI,rule impI,rule impI)
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        assume A3: " for B be OrdinalORDINAL1M3 holds B inTARSKIR2 A implies (B be CardinalCARD-1M1 implies Sigmap1(B))"
        assume "A be CardinalCARD-1M1"
        then obtain M where 
          [ty]:"M be CardinalCARD-1M1" and MDef:"M = A"
           sorry
        have " for N be CardinalCARD-1M1 holds N inTARSKIR2 M implies Sigmap1(N)"
          using A3 sorry
        thus "Sigmap1(A)"
          using A1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for A be OrdinalORDINAL1M3 holds ?P(A)"
      using ordinal1_sch_2 A2 sorry
    thus "Sigmap1(M)"
       sorry
  qed "sorry"

mtheorem card_1_th_46:
"alephCARD-1K3 (0ORDINAL1K5) =XBOOLE-0R4 omegaORDINAL1K4"
proof-
  have "alephCARD-1K3 (0ORDINAL1K5) c=ORDINAL1R1 omegaORDINAL1K4 & omegaORDINAL1K4 c=ORDINAL1R1 alephCARD-1K3 (0ORDINAL1K5)"
  proof(rule conjMI)
    show "alephCARD-1K3 (0ORDINAL1K5) c=ORDINAL1R1 omegaORDINAL1K4"
      using card_1_lm_1 card_1_th_8 sorry
    show "omegaORDINAL1K4 c=ORDINAL1R1 alephCARD-1K3 (0ORDINAL1K5)"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 omegaORDINAL1K4 implies x inHIDDENR3 alephCARD-1K3 (0ORDINAL1K5)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A1: "x inHIDDENR3 omegaORDINAL1K4"
        then obtain A where 
          [ty]:"A be OrdinalORDINAL1M3" and ADef:"A = x"
           sorry
        obtain n where
          [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4" and 
          A2: "A =XBOOLE-0R4 n"
          using A1 sorry
        have "cardCARD-1K1 (succORDINAL1K1 n) c=ORDINAL1R1 cardCARD-1K1 (omegaORDINAL1K4)"
          using card_1_th_11 ordinal1_th_21 sorry
        thus "x inHIDDENR3 alephCARD-1K3 (0ORDINAL1K5)"
          using A2 card_1_lm_1 ordinal1_th_6 sorry
      qed "sorry"
      thus "omegaORDINAL1K4 c=ORDINAL1R1 alephCARD-1K3 (0ORDINAL1K5)"
        using tarski_def_3 sorry
    qed
  qed
  thus "alephCARD-1K3 (0ORDINAL1K5) =XBOOLE-0R4 omegaORDINAL1K4"
    using xboole_0_def_10 sorry
qed

mtheorem card_1_cl_10:
"cluster omegaORDINAL1K4 as-term-is cardinalCARD-1V1 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it =HIDDENR1 omegaORDINAL1K4 implies it be cardinalCARD-1V1"
    using card_1_th_46 sorry
qed "sorry"

mtheorem card_1_th_47:
"cardCARD-1K1 (omegaORDINAL1K4) =XBOOLE-0R4 omegaORDINAL1K4"
   sorry

mtheorem card_1_cl_11:
"cluster omegaORDINAL1K4 as-term-is limit-cardinalCARD-1V2"
proof
(*coherence*)
  show "omegaORDINAL1K4 be limit-cardinalCARD-1V2"
  proof-
    have "( ex N be CardinalCARD-1M1 st omegaORDINAL1K4 =XBOOLE-0R4 nextcardCARD-1K2 N) implies  False "
    proof(rule impI)
      assume Given: " ex N be CardinalCARD-1M1 st omegaORDINAL1K4 =XBOOLE-0R4 nextcardCARD-1K2 N"
      then obtain N where
        [ty]:"N be CardinalCARD-1M1" and 
        A1: "omegaORDINAL1K4 =XBOOLE-0R4 nextcardCARD-1K2 N"
         sorry
      have "N inTARSKIR2 omegaORDINAL1K4"
        using A1 card_1_th_18 sorry
      then have A2: "succORDINAL1K1 N inTARSKIR2 omegaORDINAL1K4"
        using ordinal1_def_12 sorry
      obtain n where 
        [ty]:"n be ElementSUBSET-1M1-of omegaORDINAL1K4" and nDef:"n = N"
        using A1 card_1_th_18 sorry
      have "nextcardCARD-1K2 (cardCARD-1K1 n) =XBOOLE-0R4 cardCARD-1K1 (succORDINAL1K1 n) & cardCARD-1K1 n =XBOOLE-0R4 n"
        using card_1_th_44 sorry
      thus " False "
        using A1 A2 sorry
    qed
    thus "omegaORDINAL1K4 be limit-cardinalCARD-1V2"
      using card_1_def_4 sorry
  qed
qed "sorry"

mtheorem card_1_cl_12:
"cluster note-that finiteFINSET-1V1 for ElementSUBSET-1M1-of omegaORDINAL1K4"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of omegaORDINAL1K4 holds it be finiteFINSET-1V1"
    using card_1_th_39 sorry
qed "sorry"

mtheorem card_1_cl_13:
"cluster finiteFINSET-1V1 for CardinalCARD-1M1"
proof
(*existence*)
  show " ex it be CardinalCARD-1M1 st it be finiteFINSET-1V1"
  proof-
    have " ex tVar22 be CardinalCARD-1M1 st tVar22 be finiteFINSET-1V1"
    proof-
      let ?n = "the ElementSUBSET-1M1-of omegaORDINAL1K4"
      show " ex tVar22 be CardinalCARD-1M1 st tVar22 be finiteFINSET-1V1"
      proof(rule bexI[of _ "?n"])
        show "the ElementSUBSET-1M1-of omegaORDINAL1K4 be finiteFINSET-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_th_48:
" for M be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds  ex n be NatORDINAL1M6 st M =XBOOLE-0R4 cardCARD-1K1 n"
proof-
  have " for M be finiteFINSET-1V1\<bar>CardinalCARD-1M1 holds  not ( for n be NatORDINAL1M6 holds  not M =XBOOLE-0R4 cardCARD-1K1 n)"
  proof(rule ballI)
    fix M assume [ty]: "M be finiteFINSET-1V1\<bar>CardinalCARD-1M1"
    have "cardCARD-1K4 M =XBOOLE-0R4 M"
       sorry
    thus " not ( for n be NatORDINAL1M6 holds  not M =XBOOLE-0R4 cardCARD-1K1 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_cl_14:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster cardCARD-1K4 X as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "cardCARD-1K4 X be finiteFINSET-1V1"
     sorry
qed "sorry"

mlemma card_1_lm_4:
" for A be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds (A,n)are-equipotentWELLORD2R2 implies A =XBOOLE-0R4 n"
proof-
  have " for A be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds  not ((A,n)are-equipotentWELLORD2R2 &  not A =XBOOLE-0R4 n)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    fix n assume [ty]: "n be NatORDINAL1M6"
    let ?P = "\<lambda>Lamb1.  for A be OrdinalORDINAL1M3 holds (A,Lamb1)are-equipotentWELLORD2R2 implies A =XBOOLE-0R4 Lamb1"
    have A1: " for n be NatORDINAL1M6 holds ?P(n) implies ?P(succORDINAL1K1 n)"
    proof-
      have " for n be NatORDINAL1M6 holds ( for A be OrdinalORDINAL1M3 holds (A,n)are-equipotentWELLORD2R2 implies A =XBOOLE-0R4 n) implies ( for A be OrdinalORDINAL1M3 holds (A,succORDINAL1K1 n)are-equipotentWELLORD2R2 implies A =XBOOLE-0R4 succORDINAL1K1 n)"
      proof(rule ballI,rule impI,rule ballI,rule impI)
        fix n assume [ty]: "n be NatORDINAL1M6"
        assume A2: "?P(n)"
        fix A assume [ty]: "A be OrdinalORDINAL1M3"
        have A3: "n inTARSKIR2 succORDINAL1K1 n & succORDINAL1K1 n \\SUBSET-1K6 {TARSKIK1 n} =XBOOLE-0R4 n"
          using ordinal1_th_6 ordinal1_th_37 sorry
        assume A4: "(A,succORDINAL1K1 n)are-equipotentWELLORD2R2"
        then have "A <>HIDDENR2 {}XBOOLE-0K1"
          using relat_1_th_42 sorry
        then have A5: "{}XBOOLE-0K1 inTARSKIR2 A"
          using ordinal3_th_8 sorry
        have "A be limit-ordinalORDINAL1V4 implies  False "
        proof(rule impI)
          have A6: "succORDINAL1K1 n inTARSKIR2 omegaORDINAL1K4"
            using ordinal1_def_12 sorry
          assume "A be limit-ordinalORDINAL1V4"
          then have A7: "omegaORDINAL1K4 c=ORDINAL1R1 A"
            using A5 ordinal1_def_11 sorry
          have "cardCARD-1K1 A =XBOOLE-0R4 cardCARD-1K1 (succORDINAL1K1 n)"
            using A4 card_1_th_5 sorry
          thus " False "
            using A7 card_1_lm_1 card_1_th_11 ordinal1_th_5 A6 sorry
        qed
        then obtain B where
          [ty]:"B be OrdinalORDINAL1M3" and 
          A8: "A =XBOOLE-0R4 succORDINAL1K1 B"
          using ordinal1_th_29 sorry
        have "B inTARSKIR2 A & A \\SUBSET-1K6 {TARSKIK1 B} =XBOOLE-0R4 B"
          using A8 ordinal1_th_6 ordinal1_th_37 sorry
        thus "A =XBOOLE-0R4 succORDINAL1K1 n"
          using A2 A4 A8 A3 card_1_th_34 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: "?P(0ORDINAL1K5)"
      using card_1_th_26 sorry
    have "?P(n)"
      using ordinal2_sch_17 A9 A1 sorry
    thus " not ((A,n)are-equipotentWELLORD2R2 &  not A =XBOOLE-0R4 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma card_1_lm_5:
" for A be OrdinalORDINAL1M3 holds A be finiteFINSET-1V1 iff A inTARSKIR2 omegaORDINAL1K4"
proof-
  have " for A be OrdinalORDINAL1M3 holds (A be finiteFINSET-1V1 implies A inTARSKIR2 omegaORDINAL1K4) & (A inTARSKIR2 omegaORDINAL1K4 implies A be finiteFINSET-1V1)"
  proof(rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be OrdinalORDINAL1M3"
    show "A be finiteFINSET-1V1 implies A inTARSKIR2 omegaORDINAL1K4"
    proof(rule impI)
      assume "A be finiteFINSET-1V1"
      then obtain n where
        [ty]:"n be NatORDINAL1M6" and 
        A1: "(A,n)are-equipotentWELLORD2R2"
        using card_1_lm_3 sorry
      have "A =XBOOLE-0R4 n"
        using A1 card_1_lm_4 sorry
      thus "A inTARSKIR2 omegaORDINAL1K4"
        using ordinal1_def_12 sorry
    qed
    assume "A inTARSKIR2 omegaORDINAL1K4"
    thus "A be finiteFINSET-1V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_cl_15:
"cluster omegaORDINAL1K4 as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "omegaORDINAL1K4 be infiniteFINSET-1V2"
  proof-
    have " not omegaORDINAL1K4 be finiteFINSET-1V1"
    proof-
      have " not omegaORDINAL1K4 inTARSKIR2 omegaORDINAL1K4"
         sorry
      thus " not omegaORDINAL1K4 be finiteFINSET-1V1"
        using card_1_lm_5 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_16:
"cluster infiniteFINSET-1V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be infiniteFINSET-1V2"
  proof-
    have " ex tVar23 be setHIDDENM2 st  not tVar23 be infiniteFINSET-1V2"
    proof-
      show " ex tVar23 be setHIDDENM2 st  not tVar23 be infiniteFINSET-1V2"
      proof(rule bexI[of _ "omegaORDINAL1K4"])
        show " not omegaORDINAL1K4 be infiniteFINSET-1V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_17:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster cardCARD-1K1 X as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "cardCARD-1K1 X be infiniteFINSET-1V2"
  proof-
    have " not cardCARD-1K1 X be finiteFINSET-1V1"
    proof-
      have "(X,cardCARD-1K1 X)are-equipotentWELLORD2R2"
        using card_1_def_2 sorry
      thus " not cardCARD-1K1 X be finiteFINSET-1V1"
        using card_1_th_38 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*begin*)
mtheorem card_1_th_49:
"\<one>\<^sub>M =XBOOLE-0R4 {TARSKIK1 0ORDINAL1K5 }"
proof-
  have "\<one>\<^sub>M =HIDDENR1 {TARSKIK1 0ORDINAL1K5 }"
  proof-
    have "\<one>\<^sub>M =HIDDENR1 succORDINAL1K1 (0ORDINAL1K5)"
       sorry
    also have "... = {TARSKIK1 0ORDINAL1K5 }"
       sorry
    finally show "\<one>\<^sub>M =HIDDENR1 {TARSKIK1 0ORDINAL1K5 }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_50:
"\<two>\<^sub>M =XBOOLE-0R4 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
proof-
  have "\<two>\<^sub>M =HIDDENR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
  proof-
    have "\<two>\<^sub>M =HIDDENR1 succORDINAL1K1 \<one>\<^sub>M"
       sorry
    also have "... = {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
      using card_1_th_49 enumset1_th_1 sorry
    finally show "\<two>\<^sub>M =HIDDENR1 {TARSKIK2 0ORDINAL1K5,\<one>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_51:
"\<three>\<^sub>M =XBOOLE-0R4 {ENUMSET1K1 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M }"
proof-
  have "\<three>\<^sub>M =HIDDENR1 {ENUMSET1K1 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M }"
  proof-
    have "\<three>\<^sub>M =HIDDENR1 succORDINAL1K1 \<two>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K1 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M }"
      using card_1_th_50 enumset1_th_3 sorry
    finally show "\<three>\<^sub>M =HIDDENR1 {ENUMSET1K1 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_52:
"\<four>\<^sub>M =XBOOLE-0R4 {ENUMSET1K2 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
proof-
  have "\<four>\<^sub>M =HIDDENR1 {ENUMSET1K2 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
  proof-
    have "\<four>\<^sub>M =HIDDENR1 succORDINAL1K1 \<three>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K2 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
      using card_1_th_51 enumset1_th_6 sorry
    finally show "\<four>\<^sub>M =HIDDENR1 {ENUMSET1K2 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_53:
"\<five>\<^sub>M =XBOOLE-0R4 {ENUMSET1K3 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
proof-
  have "\<five>\<^sub>M =HIDDENR1 {ENUMSET1K3 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
  proof-
    have "\<five>\<^sub>M =HIDDENR1 succORDINAL1K1 \<four>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K3 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
      using card_1_th_52 enumset1_th_10 sorry
    finally show "\<five>\<^sub>M =HIDDENR1 {ENUMSET1K3 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_54:
"\<six>\<^sub>M =XBOOLE-0R4 {ENUMSET1K4 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M }"
proof-
  have "\<six>\<^sub>M =HIDDENR1 {ENUMSET1K4 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M }"
  proof-
    have "\<six>\<^sub>M =HIDDENR1 succORDINAL1K1 \<five>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K4 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M }"
      using card_1_th_53 enumset1_th_15 sorry
    finally show "\<six>\<^sub>M =HIDDENR1 {ENUMSET1K4 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_55:
"\<seven>\<^sub>M =XBOOLE-0R4 {ENUMSET1K5 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M }"
proof-
  have "\<seven>\<^sub>M =HIDDENR1 {ENUMSET1K5 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M }"
  proof-
    have "\<seven>\<^sub>M =HIDDENR1 succORDINAL1K1 \<six>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K5 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M }"
      using card_1_th_54 enumset1_th_21 sorry
    finally show "\<seven>\<^sub>M =HIDDENR1 {ENUMSET1K5 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_56:
"\<eight>\<^sub>M =XBOOLE-0R4 {ENUMSET1K6 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M }"
proof-
  have "\<eight>\<^sub>M =HIDDENR1 {ENUMSET1K6 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M }"
  proof-
    have "\<eight>\<^sub>M =HIDDENR1 succORDINAL1K1 \<seven>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K6 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M }"
      using card_1_th_55 enumset1_th_28 sorry
    finally show "\<eight>\<^sub>M =HIDDENR1 {ENUMSET1K6 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_57:
"\<nine>\<^sub>M =XBOOLE-0R4 {ENUMSET1K7 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M }"
proof-
  have "\<nine>\<^sub>M =HIDDENR1 {ENUMSET1K7 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M }"
  proof-
    have "\<nine>\<^sub>M =HIDDENR1 succORDINAL1K1 \<eight>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K7 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M }"
      using card_1_th_56 enumset1_th_84 sorry
    finally show "\<nine>\<^sub>M =HIDDENR1 {ENUMSET1K7 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_58:
"\<one>\<zero>\<^sub>M =XBOOLE-0R4 {ENUMSET1K8 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M,\<nine>\<^sub>M }"
proof-
  have "\<one>\<zero>\<^sub>M =HIDDENR1 {ENUMSET1K8 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M,\<nine>\<^sub>M }"
  proof-
    have "\<one>\<zero>\<^sub>M =HIDDENR1 succORDINAL1K1 \<nine>\<^sub>M"
       sorry
    also have "... = {ENUMSET1K8 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M,\<nine>\<^sub>M }"
      using card_1_th_57 enumset1_th_85 sorry
    finally show "\<one>\<zero>\<^sub>M =HIDDENR1 {ENUMSET1K8 0ORDINAL1K5,\<one>\<^sub>M,\<two>\<^sub>M,\<three>\<^sub>M,\<four>\<^sub>M,\<five>\<^sub>M,\<six>\<^sub>M,\<seven>\<^sub>M,\<eight>\<^sub>M,\<nine>\<^sub>M }"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_59:
" for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be infiniteFINSET-1V2 & f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 f be infiniteFINSET-1V2"
proof-
  have " for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f be infiniteFINSET-1V2 & f be one-to-oneFUNCT-1V2 implies  not rngFUNCT-1K2 f be infiniteFINSET-1V2"
  proof(rule ballI,rule impMI ,rule impI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f be infiniteFINSET-1V2"
      and A2: "f be one-to-oneFUNCT-1V2"
    have "(domRELAT-1K1 f,rngFUNCT-1K2 f)are-equipotentWELLORD2R2"
      using A2 sorry
    thus " not rngFUNCT-1K2 f be infiniteFINSET-1V2"
      using A1 card_1_th_38 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve k, n, m for "NatORDINAL1M6"
mtheorem card_1_cl_18:
"cluster  non zeroORDINAL1V8\<bar>naturalORDINAL1V7 for objectHIDDENM1"
proof
(*existence*)
  show " ex it be objectHIDDENM1 st it be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7"
  proof-
    have " ex tVar24 be objectHIDDENM1 st  not tVar24 be zeroORDINAL1V8 & tVar24 be naturalORDINAL1V7"
    proof-
      show " ex tVar24 be objectHIDDENM1 st  not tVar24 be zeroORDINAL1V8 & tVar24 be naturalORDINAL1V7"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        show " not \<one>\<^sub>M be zeroORDINAL1V8 & \<one>\<^sub>M be naturalORDINAL1V7"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_19:
"cluster  non zeroORDINAL1V8 for NatORDINAL1M6"
proof
(*existence*)
  show " ex it be NatORDINAL1M6 st it be  non zeroORDINAL1V8"
  proof-
    have " ex tVar25 be NatORDINAL1M6 st  not tVar25 be zeroORDINAL1V8"
    proof-
      show " ex tVar25 be NatORDINAL1M6 st  not tVar25 be zeroORDINAL1V8"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        show " not \<one>\<^sub>M be zeroORDINAL1V8"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_20:
  mlet "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegmORDINAL1K6 n as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "SegmORDINAL1K6 n be  non emptyXBOOLE-0V1"
  proof-
    have " not SegmORDINAL1K6 n be emptyXBOOLE-0V1"
    proof-
      have "n <>HIDDENR2 0ORDINAL1K5"
         sorry
      thus " not SegmORDINAL1K6 n be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) CARD_1K5("SegmCARD-1K5  _ " [164]164) where
  "SegmCARD-1K5 n \<equiv> SegmORDINAL1K6 n"

mtheorem card_1_add_2:
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegmORDINAL1K6 n as-term-is SubsetSUBSET-1M2-of omegaORDINAL1K4"
proof
(*coherence*)
  show "SegmORDINAL1K6 n be SubsetSUBSET-1M2-of omegaORDINAL1K4"
  proof-
    have 
      [ty]:"n be NatORDINAL1M6"
      using tarski_th_1 sorry
    have "n inTARSKIR2 omegaORDINAL1K4"
      using ordinal1_def_12 sorry
    thus "SegmORDINAL1K6 n be SubsetSUBSET-1M2-of omegaORDINAL1K4"
      using ordinal1_th_16 sorry
  qed
qed "sorry"

mtheorem card_1_th_60:
" for A be OrdinalORDINAL1M3 holds  for n be NatORDINAL1M6 holds (A,n)are-equipotentWELLORD2R2 implies A =XBOOLE-0R4 n"
  using card_1_lm_4 sorry

mtheorem card_1_th_61:
" for A be OrdinalORDINAL1M3 holds A be finiteFINSET-1V1 iff A inTARSKIR2 omegaORDINAL1K4"
  using card_1_lm_5 sorry

mtheorem card_1_cl_21:
"cluster naturalORDINAL1V7 also-is finiteFINSET-1V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be naturalORDINAL1V7 implies it be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem card_1_cl_22:
  mlet "A be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster boolZFMISC-1K1 A as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "boolZFMISC-1K1 A be infiniteFINSET-1V2"
  proof-
    have "boolZFMISC-1K1 A be finiteFINSET-1V1 implies  not  True "
    proof(rule impI)
      let ?P = "\<lambda>Lamb1.  ex y be objectHIDDENM1 st Lamb1 =HIDDENR1 {TARSKIK1 y}"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 boolZFMISC-1K1 A & ?P(x)"
        using xboole_0_sch_1 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 unionTARSKIK3 X iff x inHIDDENR3 A"
      proof-
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 unionTARSKIK3 X implies x inHIDDENR3 A) & (x inHIDDENR3 A implies x inHIDDENR3 unionTARSKIK3 X)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 unionTARSKIK3 X implies x inHIDDENR3 A"
          proof(rule impI)
            assume "x inHIDDENR3 unionTARSKIK3 X"
            then obtain B where
              [ty]:"B be setHIDDENM2" and 
              A2: "x inHIDDENR3 B"and A3: "B inTARSKIR2 X"
              using tarski_def_4 sorry
            have "B inTARSKIR2 boolZFMISC-1K1 A"
              using A1 A3 sorry
            thus "x inHIDDENR3 A"
              using A2 sorry
          qed
          assume "x inHIDDENR3 A"
          then have "{TARSKIK1 x} c=TARSKIR1 A"
            using zfmisc_1_th_31 sorry
          then have A4: "{TARSKIK1 x} inTARSKIR2 X"
            using A1 sorry
          have "x inHIDDENR3 {TARSKIK1 x}"
            using tarski_def_1 sorry
          thus "x inHIDDENR3 unionTARSKIK3 X"
            using A4 tarski_def_4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have A5: "unionTARSKIK3 X =XBOOLE-0R4 A"
        using tarski_th_2 sorry
      have A6: " for B be setHIDDENM2 holds B inTARSKIR2 X implies B be finiteFINSET-1V1"
      proof(rule ballI,rule impI)
        fix B assume [ty]: "B be setHIDDENM2"
        assume "B inTARSKIR2 X"
        then have " ex y be objectHIDDENM1 st B =XBOOLE-0R4 {TARSKIK1 y}"
          using A1 sorry
        thus "B be finiteFINSET-1V1"
           sorry
      qed "sorry"
      have A7: "X c=TARSKIR1 boolZFMISC-1K1 A"
        using A1 sorry
      assume "boolZFMISC-1K1 A be finiteFINSET-1V1"
      thus " not  True "
        using A5 A6 A7 finset_1_th_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_23:
  mlet "A be infiniteFINSET-1V2\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 A,B :] as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "[:ZFMISC-1K2 A,B :] be infiniteFINSET-1V2"
  proof-
    have "[:ZFMISC-1K2 A,B :] be finiteFINSET-1V1 implies  False "
    proof(rule impI)
      let ?F = "\<lambda>Lamb1. Lamb1 `1XTUPLE-0K1"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A8: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 A,B :]"and A9: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 A,B :] implies f .FUNCT-1K1 x =HIDDENR1 ?F(x)"
        using funct_1_sch_3 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f iff x inHIDDENR3 A"
      proof-
        have " for x be objectHIDDENM1 holds (x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 A) & (x inHIDDENR3 A implies x inHIDDENR3 rngFUNCT-1K2 f)"
        proof(rule ballI,rule conjMI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          show "x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 A"
          proof(rule impI)
            assume "x inHIDDENR3 rngFUNCT-1K2 f"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A10: "y inHIDDENR3 domRELAT-1K1 f"and A11: "f .FUNCT-1K1 y =HIDDENR1 x"
              using funct_1_def_3 sorry
            have "x =HIDDENR1 y `1XTUPLE-0K1"
              using A8 A9 A10 A11 sorry
            thus "x inHIDDENR3 A"
              using A8 A10 mcart_1_th_10 sorry
          qed
          let ?y = "the ElementSUBSET-1M1-of B"
          assume A12: "x inHIDDENR3 A"
          then have A13: "[TARSKIK4 x,?y ] inHIDDENR3 domRELAT-1K1 f"
            using A8 zfmisc_1_th_87 sorry
          have "f .FUNCT-1K1 [TARSKIK4 x,?y ] =HIDDENR1 [TARSKIK4 x,?y ] `1XTUPLE-0K1"
            using A9 A12 zfmisc_1_th_87 sorry
          also have "... = x"
             sorry
          finally have "f .FUNCT-1K1 [TARSKIK4 x,?y ] =HIDDENR1 x"
             sorry
          thus "x inHIDDENR3 rngFUNCT-1K2 f"
            using A13 funct_1_def_3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "rngFUNCT-1K2 f =XBOOLE-0R4 A"
        using tarski_th_2 sorry
      then have A14: "f .:FUNCT-1K5 ([:ZFMISC-1K2 A,B :]) =XBOOLE-0R4 A"
        using A8 relat_1_th_113 sorry
      assume "[:ZFMISC-1K2 A,B :] be finiteFINSET-1V1"
      thus " False "
        using A14 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_24:
  mlet "A be infiniteFINSET-1V2\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster [:ZFMISC-1K2 B,A :] as-term-is infiniteFINSET-1V2"
proof
(*coherence*)
  show "[:ZFMISC-1K2 B,A :] be infiniteFINSET-1V2"
  proof-
    have "[:ZFMISC-1K2 B,A :] be finiteFINSET-1V1 implies  False "
    proof(rule impI)
      let ?F = "\<lambda>Lamb1. Lamb1 `2XTUPLE-0K2"
      obtain f where
        [ty]:"f be FunctionFUNCT-1M1" and 
        A15: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 B,A :]"and A16: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 B,A :] implies f .FUNCT-1K1 x =HIDDENR1 ?F(x)"
        using funct_1_sch_3 sorry
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f iff y inHIDDENR3 A"
      proof-
        have " for y be objectHIDDENM1 holds (y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 A) & (y inHIDDENR3 A implies y inHIDDENR3 rngFUNCT-1K2 f)"
        proof(rule ballI,rule conjMI,rule impI)
          fix y assume [ty]: "y be objectHIDDENM1"
          show "y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 A"
          proof(rule impI)
            assume "y inHIDDENR3 rngFUNCT-1K2 f"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A17: "x inHIDDENR3 domRELAT-1K1 f"and A18: "f .FUNCT-1K1 x =HIDDENR1 y"
              using funct_1_def_3 sorry
            have "y =HIDDENR1 x `2XTUPLE-0K2"
              using A15 A16 A17 A18 sorry
            thus "y inHIDDENR3 A"
              using A15 A17 mcart_1_th_10 sorry
          qed
          let ?x = "the ElementSUBSET-1M1-of B"
          assume A19: "y inHIDDENR3 A"
          then have A20: "[TARSKIK4 ?x,y ] inHIDDENR3 domRELAT-1K1 f"
            using A15 zfmisc_1_th_87 sorry
          have "[TARSKIK4 ?x,y ] `2XTUPLE-0K2 =HIDDENR1 y"
             sorry
          then have "f .FUNCT-1K1 [TARSKIK4 ?x,y ] =HIDDENR1 y"
            using A16 A19 zfmisc_1_th_87 sorry
          thus "y inHIDDENR3 rngFUNCT-1K2 f"
            using A20 funct_1_def_3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      then have "rngFUNCT-1K2 f =XBOOLE-0R4 A"
        using tarski_th_2 sorry
      then have A21: "f .:FUNCT-1K5 ([:ZFMISC-1K2 B,A :]) =XBOOLE-0R4 A"
        using A15 relat_1_th_113 sorry
      assume "[:ZFMISC-1K2 B,A :] be finiteFINSET-1V1"
      thus " False "
        using A21 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_25:
  mlet "X be infiniteFINSET-1V2\<bar>setHIDDENM2"
"cluster infiniteFINSET-1V2 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be infiniteFINSET-1V2"
  proof-
    have " not ( for VarFor1 be SubsetSUBSET-1M2-of X holds VarFor1 be infiniteFINSET-1V2)"
    proof-
      have "X c=TARSKIR1 X"
         sorry
      thus " not ( for VarFor1 be SubsetSUBSET-1M2-of X holds VarFor1 be infiniteFINSET-1V2)"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_26:
"cluster finiteFINSET-1V1\<bar>ordinalORDINAL1V3 also-is naturalORDINAL1V7 for numberORDINAL1M2"
proof
(*coherence*)
  show " for it be numberORDINAL1M2 holds it be finiteFINSET-1V1\<bar>ordinalORDINAL1V3 implies it be naturalORDINAL1V7"
    using card_1_lm_5 sorry
qed "sorry"

mtheorem card_1_th_62:
" for f be FunctionFUNCT-1M1 holds cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 f)"
proof(rule ballI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  have "(domRELAT-1K1 f,f)are-equipotentWELLORD2R2"
  proof-
    let ?F = "\<lambda>Lamb1. [TARSKIK4 Lamb1,f .FUNCT-1K1 Lamb1 ]"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies g .FUNCT-1K1 x =HIDDENR1 ?F(x)"
      using funct_1_sch_3 sorry
    have "g be one-to-oneFUNCT-1V2 & (domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f & rngRELAT-1K2 g =HIDDENR1 f)"
    proof(rule conjMI,rule conjMI)
      show "g be one-to-oneFUNCT-1V2"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 g & y inHIDDENR3 domRELAT-1K1 g implies (g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y implies x =HIDDENR1 y)"
        proof(rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A3: "x inHIDDENR3 domRELAT-1K1 g"
            and A4: "y inHIDDENR3 domRELAT-1K1 g"
          assume "g .FUNCT-1K1 x =XBOOLE-0R4 g .FUNCT-1K1 y"
          then have "[TARSKIK4 x,f .FUNCT-1K1 x ] =HIDDENR1 g .FUNCT-1K1 y"
            using A1 A2 A3 sorry
          also have "... = [TARSKIK4 y,f .FUNCT-1K1 y ]"
            using A1 A2 A4 sorry
          finally have "[TARSKIK4 x,f .FUNCT-1K1 x ] =HIDDENR1 [TARSKIK4 y,f .FUNCT-1K1 y ]"
             sorry
          thus "x =HIDDENR1 y"
            using xtuple_0_th_1 sorry
        qed "sorry"
        thus "g be one-to-oneFUNCT-1V2"
          using funct_1_def_4 sorry
      qed
      show "domRELAT-1K1 g =XBOOLE-0R4 domRELAT-1K1 f"
        using A1 sorry
      have "rngFUNCT-1K2 g c=TARSKIR1 f & f c=TARSKIR1 rngRELAT-1K2 g"
      proof(rule conjMI)
        show "rngFUNCT-1K2 g c=TARSKIR1 f"
        proof-
          have " for i be objectHIDDENM1 holds i inHIDDENR3 rngFUNCT-1K2 g implies i inHIDDENR3 f"
          proof(rule ballI,rule impI)
            fix i assume [ty]: "i be objectHIDDENM1"
            assume "i inHIDDENR3 rngFUNCT-1K2 g"
            then obtain x where
              [ty]:"x be objectHIDDENM1" and 
              A5: "x inHIDDENR3 domRELAT-1K1 g"and A6: "g .FUNCT-1K1 x =HIDDENR1 i"
              using funct_1_def_3 sorry
            have "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,f .FUNCT-1K1 x ]"
              using A1 A2 A5 sorry
            thus "i inHIDDENR3 f"
              using A1 A5 A6 funct_1_th_1 sorry
          qed "sorry"
          thus "rngFUNCT-1K2 g c=TARSKIR1 f"
            using tarski_def_3 sorry
        qed
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 f implies [TARSKIK4 x,y ] inHIDDENR3 rngRELAT-1K2 g"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A7: "[TARSKIK4 x,y ] inHIDDENR3 f"
          then have A8: "x inHIDDENR3 domRELAT-1K1 f"
            using funct_1_th_1 sorry
          have "y =HIDDENR1 f .FUNCT-1K1 x"
            using A7 funct_1_th_1 sorry
          then have "g .FUNCT-1K1 x =HIDDENR1 [TARSKIK4 x,y ]"
            using A2 A7 funct_1_th_1 sorry
          thus "[TARSKIK4 x,y ] inHIDDENR3 rngRELAT-1K2 g"
            using A1 A8 funct_1_def_3 sorry
        qed "sorry"
        thus "f c=TARSKIR1 rngRELAT-1K2 g"
          using relat_1_def_3 sorry
      qed
      thus "rngRELAT-1K2 g =HIDDENR1 f"
        using xboole_0_def_10 sorry
    qed
    thus "(domRELAT-1K1 f,f)are-equipotentWELLORD2R2"
      using bexI[of _ "g"] wellord2_def_4 sorry
  qed
  thus "cardCARD-1K1 f =XBOOLE-0R4 cardCARD-1K1 (domRELAT-1K1 f)"
    using card_1_th_5 sorry
qed "sorry"

mtheorem card_1_cl_27:
  mlet "X be finiteFINSET-1V1\<bar>setHIDDENM2"
"cluster RelInclWELLORD2K1 X as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "RelInclWELLORD2K1 X be finiteFINSET-1V1"
  proof-
    have "RelInclWELLORD2K1 X c=RELAT-1R2 [:ZFMISC-1K2 X,X :]"
      using wellord2_th_23 sorry
    thus "RelInclWELLORD2K1 X be finiteFINSET-1V1"
       sorry
  qed
qed "sorry"

mtheorem card_1_th_63:
" for X be setHIDDENM2 holds RelInclWELLORD2K1 X be finiteFINSET-1V1 implies X be finiteFINSET-1V1"
proof-
  have " for X be setHIDDENM2 holds RelInclWELLORD2K1 X be finiteFINSET-1V1 implies X be finiteFINSET-1V1"
  proof(rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    let ?R = "RelInclWELLORD2K1 X"
    assume "?R be finiteFINSET-1V1"
    then obtain A where 
      [ty]:"A be finiteFINSET-1V1\<bar>RelationRELAT-1M1" and ADef:"A = ?R"
       sorry
    have "fieldRELAT-1K3 A be finiteFINSET-1V1"
       sorry
    thus "X be finiteFINSET-1V1"
      using wellord2_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_64:
" for x be objectHIDDENM1 holds  for k be NatORDINAL1M6 holds cardCARD-1K1 (k -->FUNCOP-1K7 x) =XBOOLE-0R4 k"
proof-
  have " for x be objectHIDDENM1 holds  for k be NatORDINAL1M6 holds cardCARD-1K1 (k -->FUNCOP-1K7 x) =HIDDENR1 k"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix k assume [ty]: "k be NatORDINAL1M6"
    have "domRELAT-1K1 (k -->FUNCOP-1K7 x) =XBOOLE-0R4 k"
      using funcop_1_th_13 sorry
    then have "cardCARD-1K1 (k -->FUNCOP-1K7 x) =HIDDENR1 cardCARD-1K4 k"
      using card_1_th_62 sorry
    also have "... = k"
       sorry
    finally show "cardCARD-1K1 (k -->FUNCOP-1K7 x) =HIDDENR1 k"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
(*\$CD*)
mdef card_1_def_7 (" _ -elementCARD-1V3" [70]70 ) where
  mlet "N be objectHIDDENM1"
"attr N -elementCARD-1V3 for setHIDDENM2 means
  (\<lambda>X. cardCARD-1K1 X =HIDDENR1 N)"..

mtheorem card_1_cl_28:
  mlet "N be CardinalCARD-1M1"
"cluster N -elementCARD-1V3 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be N -elementCARD-1V3"
  proof-
    have " ex tVar27 be setHIDDENM2 st tVar27 be tVar27 -elementCARD-1V3"
    proof-
      show " ex tVar27 be setHIDDENM2 st tVar27 be tVar27 -elementCARD-1V3"
      proof(rule bexI[of _ "N"])
        have "cardCARD-1K1 N =XBOOLE-0R4 N"
        proof-
          show "cardCARD-1K1 N =XBOOLE-0R4 N"
             sorry
        qed
        thus "N be N -elementCARD-1V3"
          using card_1_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_29:
"cluster 0ORDINAL1K5 -elementCARD-1V3 also-is emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be 0ORDINAL1K5 -elementCARD-1V3 implies it be emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem card_1_cl_30:
"cluster emptyXBOOLE-0V1 also-is 0ORDINAL1K5 -elementCARD-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be 0ORDINAL1K5 -elementCARD-1V3"
     sorry
qed "sorry"

mtheorem card_1_cl_31:
  mlet "x be objectHIDDENM1"
"cluster {TARSKIK1 x} as-term-is \<one>\<^sub>M -elementCARD-1V3"
proof
(*coherence*)
  show "{TARSKIK1 x} be \<one>\<^sub>M -elementCARD-1V3"
  proof-
    have Cut1756: "\<one>\<^sub>M =XBOOLE-0R4 succORDINAL1K1 (0ORDINAL1K5)"
       sorry
    have "cardCARD-1K4 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
    proof-
      show "cardCARD-1K4 {TARSKIK1 x} =XBOOLE-0R4 \<one>\<^sub>M"
        using card_1_def_2 card_1_th_28 Cut1756 sorry
    qed
    thus "{TARSKIK1 x} be \<one>\<^sub>M -elementCARD-1V3"
      using card_1_def_7 sorry
  qed
qed "sorry"

mtheorem card_1_cl_32:
  mlet "N be CardinalCARD-1M1"
"cluster N -elementCARD-1V3 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be N -elementCARD-1V3"
  proof-
    have " ex f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 N,{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } :]) st f be N -elementCARD-1V3"
    proof-
      obtain f where 
        [ty]:"f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 N,{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } :])" and fDef:"f = N -->FUNCOP-1K7 {TARSKIK1 {}XBOOLE-0K1 }"
         sorry
      show " ex f be ElementSUBSET-1M1-of boolZFMISC-1K1 ([:ZFMISC-1K2 N,{TARSKIK1 {TARSKIK1 {}XBOOLE-0K1 } } :]) st f be N -elementCARD-1V3"
      proof(rule bexI[of _ "f"])
        have "domRELAT-1K1 f =XBOOLE-0R4 N"
          using funcop_1_th_13 sorry
        then have Cut1767: "cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 N"
           sorry
        have "cardCARD-1K1 f =XBOOLE-0R4 N"
        proof-
          show "cardCARD-1K1 f =XBOOLE-0R4 N"
            using card_1_th_62 Cut1767 sorry
        qed
        thus "f be N -elementCARD-1V3"
          using card_1_def_7 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_33:
  mlet "N be CardinalCARD-1M1", "f be N -elementCARD-1V3\<bar>FunctionFUNCT-1M1"
"cluster domRELAT-1K1 f as-term-is N -elementCARD-1V3"
proof
(*coherence*)
  show "domRELAT-1K1 f be N -elementCARD-1V3"
  proof-
    have Cut1776: "cardCARD-1K1 f =XBOOLE-0R4 N"
      using card_1_def_7 sorry
    have "cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 N"
    proof-
      show "cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 N"
        using card_1_th_62 Cut1776 sorry
    qed
    thus "domRELAT-1K1 f be N -elementCARD-1V3"
      using card_1_def_7 sorry
  qed
qed "sorry"

mtheorem card_1_cl_34:
"cluster \<one>\<^sub>M -elementCARD-1V3 also-is trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be \<one>\<^sub>M -elementCARD-1V3 implies it be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1"
  proof-
    have " for X be setHIDDENM2 holds X be \<one>\<^sub>M -elementCARD-1V3 implies X be trivialSUBSET-1V2 &  not X be emptyXBOOLE-0V1"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X be \<one>\<^sub>M -elementCARD-1V3"
      then have "cardCARD-1K1 X =HIDDENR1 \<one>\<^sub>M"
         sorry
      also have "... = cardCARD-1K4 {TARSKIK1 0ORDINAL1K5 }"
        using card_1_th_30 sorry
      finally have "cardCARD-1K1 X =HIDDENR1 cardCARD-1K4 {TARSKIK1 0ORDINAL1K5 }"
         sorry
      then have " ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x}"
        using card_1_th_5 card_1_th_28 sorry
      thus "X be trivialSUBSET-1V2 &  not X be emptyXBOOLE-0V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_35:
"cluster trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1 also-is \<one>\<^sub>M -elementCARD-1V3 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1 implies it be \<one>\<^sub>M -elementCARD-1V3"
  proof-
    have " for X be setHIDDENM2 holds X be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1 implies X be \<one>\<^sub>M -elementCARD-1V3"
    proof(rule ballI,rule impI)
      fix X assume [ty]: "X be setHIDDENM2"
      assume "X be trivialSUBSET-1V2\<bar> non emptyXBOOLE-0V1"
      then have " ex x be objectHIDDENM1 st X =XBOOLE-0R4 {TARSKIK1 x}"
        using zfmisc_1_th_131 sorry
      thus "X be \<one>\<^sub>M -elementCARD-1V3"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_36:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster \<one>\<^sub>M -elementCARD-1V3 for SubsetSUBSET-1M2-of X"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of X st it be \<one>\<^sub>M -elementCARD-1V3"
  proof-
    have " ex tVar29 be SubsetSUBSET-1M2-of X st tVar29 be \<one>\<^sub>M -elementCARD-1V3"
    proof-
      show " ex tVar29 be SubsetSUBSET-1M2-of X st tVar29 be \<one>\<^sub>M -elementCARD-1V3"
      proof(rule bexI[of _ "the  non emptyXBOOLE-0V1\<bar>trivialSUBSET-1V2\<bar>SubsetSUBSET-1M2-of X"])
        show "the  non emptyXBOOLE-0V1\<bar>trivialSUBSET-1V2\<bar>SubsetSUBSET-1M2-of X be \<one>\<^sub>M -elementCARD-1V3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax CARD_1M2 :: " Set \<Rightarrow> Ty" ("SingletonCARD-1M2-of  _ " [70]70)
translations "SingletonCARD-1M2-of X" \<rightharpoonup> "\<one>\<^sub>M -elementCARD-1V3\<bar>SubsetSUBSET-1M2-of X"

mtheorem card_1_th_65:
" for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SingletonCARD-1M2-of X holds  ex x be ElementSUBSET-1M1-of X st A =XBOOLE-0R4 {TARSKIK1 x}"
proof-
  have " for X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for A be SingletonCARD-1M2-of X holds  ex tVar30 be ElementSUBSET-1M1-of X st A =XBOOLE-0R4 {TARSKIK1 tVar30}"
  proof(rule ballI,rule ballI)
    fix X assume [ty]: "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix A assume [ty]: "A be SingletonCARD-1M2-of X"
    obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A1: "A =XBOOLE-0R4 {TARSKIK1 x}"
      using zfmisc_1_th_131 sorry
    have "x inHIDDENR3 A"
      using A1 tarski_def_1 sorry
    then have 
      [ty]:"x be ElementSUBSET-1M1-of X"
       sorry
    show " ex tVar30 be ElementSUBSET-1M1-of X st A =XBOOLE-0R4 {TARSKIK1 tVar30}"
    proof(rule bexI[of _ "x"])
      show "A =XBOOLE-0R4 {TARSKIK1 x}"
        using A1 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_66:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y iff ( ex f be FunctionFUNCT-1M1 st X c=TARSKIR1 f .:FUNCT-1K5 Y)"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds (cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st X c=TARSKIR1 f .:FUNCT-1K5 Y)) & (( ex f be FunctionFUNCT-1M1 st X c=TARSKIR1 f .:FUNCT-1K5 Y) implies cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y)"
  proof(rule ballI,rule ballI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    let ?G = "\<lambda>Lamb1. Lamb1"
    show "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex f be FunctionFUNCT-1M1 st X c=TARSKIR1 f .:FUNCT-1K5 Y)"
    proof-
      have "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y implies ( ex tVar31 be FunctionFUNCT-1M1 st X c=TARSKIR1 tVar31 .:FUNCT-1K5 Y)"
      proof(rule impI)
        assume "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
        then obtain f where
          [ty]:"f be FunctionFUNCT-1M1" and 
          A1: "domRELAT-1K1 f =XBOOLE-0R4 Y & X c=TARSKIR1 rngFUNCT-1K2 f"
          using card_1_th_12 sorry
        show " ex tVar31 be FunctionFUNCT-1M1 st X c=TARSKIR1 tVar31 .:FUNCT-1K5 Y"
        proof(rule bexI[of _ "f"])
          show "X c=TARSKIR1 f .:FUNCT-1K5 Y"
            using A1 relat_1_th_113 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    assume Given: " ex f be FunctionFUNCT-1M1 st X c=TARSKIR1 f .:FUNCT-1K5 Y"
    then obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A2: "X c=TARSKIR1 f .:FUNCT-1K5 Y"
       sorry
    let ?C = "\<lambda>Lamb1. Lamb1 inHIDDENR3 domRELAT-1K1 f"
    let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 Lamb1"
    obtain g where
      [ty]:"g be FunctionFUNCT-1M1" and 
      A3: "domRELAT-1K1 g =XBOOLE-0R4 Y & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y implies (?C(x) implies g .FUNCT-1K1 x =XBOOLE-0R4 ?F(x)) & ( not ?C(x) implies g .FUNCT-1K1 x =HIDDENR1 ?G(x)))"
      using partfun1_sch_1 sorry
    have "X c=TARSKIR1 rngFUNCT-1K2 g"
    proof-
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 rngFUNCT-1K2 g"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 X"
        then obtain y where
          [ty]:"y be objectHIDDENM1" and 
          A4: "y inHIDDENR3 domRELAT-1K1 f"and A5: "y inHIDDENR3 Y"and A6: "x =HIDDENR1 f .FUNCT-1K1 y"
          using A2 funct_1_def_6 sorry
        have "x =HIDDENR1 g .FUNCT-1K1 y"
          using A3 A4 A5 A6 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 g"
          using A3 A5 funct_1_def_3 sorry
      qed "sorry"
      thus "X c=TARSKIR1 rngFUNCT-1K2 g"
        using tarski_def_3 sorry
    qed
    thus "cardCARD-1K1 X c=ORDINAL1R1 cardCARD-1K1 Y"
      using A3 card_1_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_67:
" for X be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds cardCARD-1K1 (f .:FUNCT-1K5 X) c=ORDINAL1R1 cardCARD-1K1 X"
  using card_1_th_66 sorry

mtheorem card_1_th_68:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y implies Y \\SUBSET-1K6 X <>HIDDENR2 {}XBOOLE-0K1"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y & Y \\SUBSET-1K6 X =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    assume A1: "cardCARD-1K1 X inTARSKIR2 cardCARD-1K1 Y"
      and A2: "Y \\SUBSET-1K6 X =XBOOLE-0R4 {}XBOOLE-0K1"
    have "Y c=TARSKIR1 X"
      using A2 xboole_1_th_37 sorry
    thus " False "
      using A1 card_1_th_11 ordinal1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_69:
" for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (X,[:ZFMISC-1K2 X,{TARSKIK1 x} :])are-equipotentWELLORD2R2 & cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
proof-
  have " for X be setHIDDENM2 holds  for x be objectHIDDENM1 holds (X,[:ZFMISC-1K2 X,{TARSKIK1 x} :])are-equipotentWELLORD2R2 & cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
  proof(rule ballI,rule ballI,rule conjMI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    let ?f = "\<lambda>Lamb1. [TARSKIK4 Lamb1,x ]"
    obtain f where
      [ty]:"f be FunctionFUNCT-1M1" and 
      A1: "domRELAT-1K1 f =XBOOLE-0R4 X & ( for y be objectHIDDENM1 holds y inHIDDENR3 X implies f .FUNCT-1K1 y =HIDDENR1 ?f(y))"
      using funct_1_sch_3 sorry
    show "(X,[:ZFMISC-1K2 X,{TARSKIK1 x} :])are-equipotentWELLORD2R2"
    proof-
      have "f be one-to-oneFUNCT-1V2 & (domRELAT-1K1 f =XBOOLE-0R4 X & rngRELAT-1K2 f =HIDDENR1 [:ZFMISC-1K2 X,{TARSKIK1 x} :])"
      proof(rule conjMI,rule conjMI)
        show "f be one-to-oneFUNCT-1V2"
        proof-
          have " for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (y inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f) & f .FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 z implies y =HIDDENR1 z"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            fix z assume [ty]: "z be objectHIDDENM1"
            assume A2: "y inHIDDENR3 domRELAT-1K1 f & z inHIDDENR3 domRELAT-1K1 f"
              and A3: "f .FUNCT-1K1 y =XBOOLE-0R4 f .FUNCT-1K1 z"
            have A4: "[TARSKIK4 y,x ] `1XTUPLE-0K1 =HIDDENR1 y & [TARSKIK4 z,x ] `1XTUPLE-0K1 =HIDDENR1 z"
               sorry
            have "f .FUNCT-1K1 y =HIDDENR1 [TARSKIK4 y,x ] & f .FUNCT-1K1 z =HIDDENR1 [TARSKIK4 z,x ]"
              using A1 A2 sorry
            thus "y =HIDDENR1 z"
              using A3 A4 sorry
          qed "sorry"
          thus "f be one-to-oneFUNCT-1V2"
            using funct_1_def_4 sorry
        qed
        show "domRELAT-1K1 f =XBOOLE-0R4 X"
          using A1 sorry
        have "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,{TARSKIK1 x} :] & [:ZFMISC-1K2 X,{TARSKIK1 x} :] c=TARSKIR1 rngRELAT-1K2 f"
        proof(rule conjMI)
          show "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
          proof-
            have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 f implies y inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
            proof(rule ballI,rule impI)
              fix y assume [ty]: "y be objectHIDDENM1"
              have A5: "x inHIDDENR3 {TARSKIK1 x}"
                using tarski_def_1 sorry
              assume "y inHIDDENR3 rngFUNCT-1K2 f"
              then obtain z where
                [ty]:"z be objectHIDDENM1" and 
                A6: "z inHIDDENR3 domRELAT-1K1 f"and A7: "y =HIDDENR1 f .FUNCT-1K1 z"
                using funct_1_def_3 sorry
              have "y =HIDDENR1 [TARSKIK4 z,x ]"
                using A1 A6 A7 sorry
              thus "y inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
                using A1 A6 A5 zfmisc_1_th_87 sorry
            qed "sorry"
            thus "rngFUNCT-1K2 f c=TARSKIR1 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
              using tarski_def_3 sorry
          qed
          have " for y be objectHIDDENM1 holds y inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 x} :] implies y inHIDDENR3 rngRELAT-1K2 f"
          proof(rule ballI,rule impI)
            fix y assume [ty]: "y be objectHIDDENM1"
            assume "y inHIDDENR3 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
            then obtain y1 y2 where
              [ty]:"y1 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
              A8: "y1 inHIDDENR3 X"and A9: "y2 inHIDDENR3 {TARSKIK1 x}"and A10: "y =HIDDENR1 [TARSKIK4 y1,y2 ]"
              using zfmisc_1_th_84 sorry
            have "y2 =HIDDENR1 x"
              using A9 tarski_def_1 sorry
            then have "y =HIDDENR1 f .FUNCT-1K1 y1"
              using A1 A8 A10 sorry
            thus "y inHIDDENR3 rngRELAT-1K2 f"
              using A1 A8 funct_1_def_3 sorry
          qed "sorry"
          thus "[:ZFMISC-1K2 X,{TARSKIK1 x} :] c=TARSKIR1 rngRELAT-1K2 f"
            using tarski_def_3 sorry
        qed
        thus "rngRELAT-1K2 f =HIDDENR1 [:ZFMISC-1K2 X,{TARSKIK1 x} :]"
          using xboole_0_def_10 sorry
      qed
      thus "(X,[:ZFMISC-1K2 X,{TARSKIK1 x} :])are-equipotentWELLORD2R2"
        using bexI[of _ "f"] wellord2_def_4 sorry
    qed
    thus "cardCARD-1K1 X =XBOOLE-0R4 cardCARD-1K1 ([:ZFMISC-1K2 X,{TARSKIK1 x} :])"
      using card_1_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_th_70:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 implies cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 cardCARD-1K1 (rngFUNCT-1K2 f)"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  assume A1: "f be one-to-oneFUNCT-1V2"
  have "f .:FUNCT-1K5 domRELAT-1K1 f =XBOOLE-0R4 rngFUNCT-1K2 f"
    using relat_1_th_113 sorry
  thus "cardCARD-1K1 (domRELAT-1K1 f) =XBOOLE-0R4 cardCARD-1K1 (rngFUNCT-1K2 f)"
    using A1 card_1_th_5 card_1_th_33 sorry
qed "sorry"

mtheorem card_1_cl_37:
  mlet "F be  non trivialSUBSET-1V2\<bar>setHIDDENM2", "A be SingletonCARD-1M2-of F"
"cluster F \\SUBSET-1K6 A as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "F \\SUBSET-1K6 A be  non emptyXBOOLE-0V1"
  proof-
    have " not F \\SUBSET-1K6 A be emptyXBOOLE-0V1"
    proof-
      have " ex x be ElementSUBSET-1M1-of F st A =XBOOLE-0R4 {TARSKIK1 x}"
        using card_1_th_65 sorry
      thus " not F \\SUBSET-1K6 A be emptyXBOOLE-0V1"
        using zfmisc_1_th_139 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem card_1_cl_38:
  mlet "k be  non emptyXBOOLE-0V1\<bar>CardinalCARD-1M1"
"cluster k -elementCARD-1V3 also-is  non emptyXBOOLE-0V1 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be k -elementCARD-1V3 implies it be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem card_1_cl_39:
  mlet "k be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegmCARD-1K5 k as-term-is finiteFINSET-1V1"
proof
(*coherence*)
  show "SegmCARD-1K5 k be finiteFINSET-1V1"
     sorry
qed "sorry"

mtheorem card_1_th_71:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds cardCARD-1K1 (f +~FUNCT-4K8(x,y)) =XBOOLE-0R4 cardCARD-1K1 f"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds cardCARD-1K1 (f +~FUNCT-4K8(x,y)) =HIDDENR1 cardCARD-1K1 f"
  proof(rule ballI,rule ballI,rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    have "cardCARD-1K1 (f +~FUNCT-4K8(x,y)) =HIDDENR1 cardCARD-1K1 (domRELAT-1K1 (f +~FUNCT-4K8(x,y)))"
      using card_1_th_62 sorry
    also have "... = cardCARD-1K1 (domRELAT-1K1 f)"
      using funct_4_th_99 sorry
    also have "... = cardCARD-1K1 f"
      using card_1_th_62 sorry
    finally show "cardCARD-1K1 (f +~FUNCT-4K8(x,y)) =HIDDENR1 cardCARD-1K1 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem card_1_cl_40:
  mlet "n be  non zeroORDINAL1V8\<bar>naturalORDINAL1V7\<bar>NumberORDINAL1M1"
"cluster SegmCARD-1K5 n as-term-is with-zeroORDINAL1V10"
proof
(*coherence*)
  show "SegmCARD-1K5 n be with-zeroORDINAL1V10"
    using ordinal3_th_8 sorry
qed "sorry"

end
