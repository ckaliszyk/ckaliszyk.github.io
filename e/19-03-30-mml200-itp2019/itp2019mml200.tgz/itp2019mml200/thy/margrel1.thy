theory margrel1
  imports xboolean finseq_3
   "../mizar_extension/E_number"
begin
(*begin*)
reserve k for "ElementSUBSET-1M1-of NATNUMBERSK1"
reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
abbreviation(input) MARGREL1V1("with-common-domainMARGREL1V1" 70) where
  "with-common-domainMARGREL1V1 \<equiv> with-common-domainCARD-3V2"

mtheorem margrel1_def_1:
  mlet "IT be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
"redefine attr with-common-domainMARGREL1V1 for FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2 means
  (\<lambda>IT.  for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
proof
(*compatibility*)
  show " for IT be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2 holds IT be with-common-domainMARGREL1V1 iff ( for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
  proof(rule ballI)
    fix IT assume [ty]: "IT be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
    show "IT be with-common-domainMARGREL1V1 iff ( for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
    proof-
      have "(IT be with-common-domainCARD-3V2 implies ( for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) & (( for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b) implies IT be with-common-domainCARD-3V2)"
      proof(rule conjMI,rule impI)
        show "IT be with-common-domainCARD-3V2 implies ( for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
        proof(rule impI,rule ballI,rule ballI,rule impI)
          assume A1: "IT be with-common-domainCARD-3V2"
          fix a assume [ty]: "a be FinSequenceFINSEQ-1M1"
          fix b assume [ty]: "b be FinSequenceFINSEQ-1M1"
          assume "a inTARSKIR2 IT & b inTARSKIR2 IT"
          then have "domFINSEQ-1K5 a =XBOOLE-0R4 domFINSEQ-1K5 b"
            using A1 sorry
          thus "lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
            using finseq_3_th_29 sorry
        qed "sorry"
        assume A2: " for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 IT & b inTARSKIR2 IT implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
        have " for f be FunctionFUNCT-1M1 holds  for g be FunctionFUNCT-1M1 holds f inTARSKIR2 IT & g inTARSKIR2 IT implies domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 g"
        proof(rule ballI,rule ballI,rule impI)
          fix f assume [ty]: "f be FunctionFUNCT-1M1"
          fix g assume [ty]: "g be FunctionFUNCT-1M1"
          assume A3: "f inTARSKIR2 IT & g inTARSKIR2 IT"
          then have 
            [ty]:"f be FinSequenceFINSEQ-1M1" and
            [ty]:"g be FinSequenceFINSEQ-1M1"
             sorry
          have "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g"
            using A2 A3 sorry
          thus "domRELAT-1K1 f =HIDDENR1 domRELAT-1K1 g"
            using finseq_3_th_29 sorry
        qed "sorry"
        thus "IT be with-common-domainCARD-3V2"
          using card_3_def_10 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem margrel1_cl_1:
"cluster FinSequence-memberedFINSEQ-1V3\<bar>with-common-domainCARD-3V2 for setHIDDENM2"
proof
(*existence*)
  show " ex it be setHIDDENM2 st it be FinSequence-memberedFINSEQ-1V3\<bar>with-common-domainCARD-3V2"
  proof-
    have " ex tVar1 be setHIDDENM2 st tVar1 be FinSequence-memberedFINSEQ-1V3 & tVar1 be with-common-domainCARD-3V2"
    proof-
      show " ex tVar1 be setHIDDENM2 st tVar1 be FinSequence-memberedFINSEQ-1V3 & tVar1 be with-common-domainCARD-3V2"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        show "{}XBOOLE-0K1 be FinSequence-memberedFINSEQ-1V3 & {}XBOOLE-0K1 be with-common-domainCARD-3V2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax MARGREL1M1 :: "Ty" ("relationMARGREL1M1" 70)
translations "relationMARGREL1M1" \<rightharpoonup> "FinSequence-memberedFINSEQ-1V3\<bar>with-common-domainCARD-3V2\<bar>setHIDDENM2"

reserve X for "setHIDDENM2"
reserve p, r for "relationMARGREL1M1"
reserve a, a1, a2, b for "FinSequenceFINSEQ-1M1"
mtheorem margrel1_th_1:
" for X be setHIDDENM2 holds  for p be relationMARGREL1M1 holds X c=TARSKIR1 p implies X be relationMARGREL1M1"
   sorry

mtheorem margrel1_th_2:
" for a be FinSequenceFINSEQ-1M1 holds {TARSKIK1 a} be relationMARGREL1M1"
proof-
  have " for a be FinSequenceFINSEQ-1M1 holds {TARSKIK1 a} be relationMARGREL1M1"
  proof(rule ballI)
    fix a assume [ty]: "a be FinSequenceFINSEQ-1M1"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 {TARSKIK1 a} implies z be FinSequenceFINSEQ-1M1"
      using tarski_def_1 sorry
    then obtain X where 
      [ty]:"X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2" and XDef:"X = {TARSKIK1 a}"
      using finseq_1_def_18 sorry
    have "X be with-common-domainMARGREL1V1"
       sorry
    thus "{TARSKIK1 a} be relationMARGREL1M1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem margrel1_sch_1:
  fixes Af0 Pp1 
  assumes
[ty]: "Af0 be setHIDDENM2" and
   A1: " for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds Pp1(a) & Pp1(b) implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
  shows " ex r be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 r iff a inTARSKIR2 Af0 & Pp1(a)"
  proof-
    have " not ( for r be relationMARGREL1M1 holds  not ( for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 r &  not (a inTARSKIR2 Af0 & Pp1(a))) &  not ((a inTARSKIR2 Af0 & Pp1(a)) &  not a inTARSKIR2 r)))"
    proof-
      let ?P1 = "\<lambda>Lamb1.  ex a be FinSequenceFINSEQ-1M1 st Pp1(a) & Lamb1 =HIDDENR1 a"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Af0 & ?P1(x)"
        using xboole_0_sch_1 sorry
      have "X be FinSequence-memberedFINSEQ-1V3"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x be setHIDDENM2"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 X"
          then have " ex a be FinSequenceFINSEQ-1M1 st Pp1(a) & x =HIDDENR1 a"
            using A2 sorry
          thus "x be setHIDDENM2"
             sorry
        qed "sorry"
        thus "X be FinSequence-memberedFINSEQ-1V3"
          using finseq_1_def_18 sorry
      qed
      then have 
        [ty]:"X be FinSequence-memberedFINSEQ-1V3\<bar>setHIDDENM2"
         sorry
      have "X be with-common-domainMARGREL1V1"
      proof-
        have " for a be FinSequenceFINSEQ-1M1 holds  for b be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix a assume [ty]: "a be FinSequenceFINSEQ-1M1"
          fix b assume [ty]: "b be FinSequenceFINSEQ-1M1"
          assume A3: "a inTARSKIR2 X"
            and A4: "b inTARSKIR2 X"
          have A5: " ex d be FinSequenceFINSEQ-1M1 st Pp1(d) & b =FINSEQ-1R1 d"
            using A2 A4 sorry
          have " ex c be FinSequenceFINSEQ-1M1 st Pp1(c) & a =FINSEQ-1R1 c"
            using A2 A3 sorry
          thus "lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
            using A1 A5 sorry
        qed "sorry"
        thus "X be with-common-domainMARGREL1V1"
          using margrel1_def_1 sorry
      qed
      then obtain r where 
        [ty]:"r be relationMARGREL1M1" and rDef:"r = X"
         sorry
      have " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 r iff a inTARSKIR2 Af0 & Pp1(a)"
      proof-
        have " for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 r &  not (a inTARSKIR2 Af0 & Pp1(a))) &  not ((a inTARSKIR2 Af0 & Pp1(a)) &  not a inTARSKIR2 r)"
        proof(rule ballI)
          fix a assume [ty]: "a be FinSequenceFINSEQ-1M1"
          have "a inTARSKIR2 r implies a inTARSKIR2 Af0 & Pp1(a)"
          proof(rule impI)
            assume A6: "a inTARSKIR2 r"
            then have " ex c be FinSequenceFINSEQ-1M1 st Pp1(c) & a =FINSEQ-1R1 c"
              using A2 sorry
            thus "a inTARSKIR2 Af0 & Pp1(a)"
              using A2 A6 sorry
          qed
          thus " not (a inTARSKIR2 r &  not (a inTARSKIR2 Af0 & Pp1(a))) &  not ((a inTARSKIR2 Af0 & Pp1(a)) &  not a inTARSKIR2 r)"
            using A2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not ( for r be relationMARGREL1M1 holds  not ( for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 r &  not (a inTARSKIR2 Af0 & Pp1(a))) &  not ((a inTARSKIR2 Af0 & Pp1(a)) &  not a inTARSKIR2 r)))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

abbreviation(input) MARGREL1R1(" _ =MARGREL1R1  _ " [50,50]50) where
  "p =MARGREL1R1 r \<equiv> p =HIDDENR1 r"

mtheorem margrel1_def_2:
  mlet "p be relationMARGREL1M1", "r be relationMARGREL1M1"
"redefine pred p =MARGREL1R1 r means
   for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r"
proof
(*compatibility*)
  show "p =MARGREL1R1 r iff ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r)"
  proof-
    have "(p =XBOOLE-0R4 r implies ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r)) & (( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r) implies p =HIDDENR1 r)"
    proof(rule conjMI,rule impI)
      show "p =XBOOLE-0R4 r implies ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r)"
         sorry
      assume " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p iff a inTARSKIR2 r"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 p iff x inHIDDENR3 r"
         sorry
      thus "p =HIDDENR1 r"
        using tarski_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_2:
"cluster emptyXBOOLE-0V1 also-is with-common-domainCARD-3V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be emptyXBOOLE-0V1 implies it be with-common-domainCARD-3V2"
     sorry
qed "sorry"

mtheorem margrel1_th_3:
" for p be relationMARGREL1M1 holds ( for a be FinSequenceFINSEQ-1M1 holds  not a inTARSKIR2 p) implies p =MARGREL1R1 {}XBOOLE-0K1"
   sorry

mdef margrel1_def_3 ("the-arity-ofMARGREL1K1  _ " [120]120 ) where
  mlet "p be relationMARGREL1M1"
"assume p <>HIDDENR2 {}XBOOLE-0K1 func the-arity-ofMARGREL1K1 p \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it.  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a"
proof-
  (*existence*)
    show "p <>HIDDENR2 {}XBOOLE-0K1 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a)"
    proof(rule impI)
      assume Assume: "p <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "p <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a"
      proof-
        have " not ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 p &  not VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 a)))"
        proof-
          obtain c where
            [ty]:"c be FinSequenceFINSEQ-1M1" and 
            A2: "c inTARSKIR2 p"
            using A1 sorry
          have " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies lenFINSEQ-1K4 c =XBOOLE-0R4 lenFINSEQ-1K4 a"
            using A2 margrel1_def_1 sorry
          thus " not ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 p &  not VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 a)))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p <>HIDDENR2 {}XBOOLE-0K1 implies ( for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p <>HIDDENR2 {}XBOOLE-0K1"
      have A1: "p <>HIDDENR2 {}XBOOLE-0K1"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies it2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies it1 =HIDDENR1 it2"
      proof-
        have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies n1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies n2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies n1 =HIDDENR1 n2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume A3: " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies n1 =XBOOLE-0R4 lenFINSEQ-1K4 a"
            and A4: " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 p implies n2 =XBOOLE-0R4 lenFINSEQ-1K4 a"
          obtain a where
            [ty]:"a be FinSequenceFINSEQ-1M1" and 
            A5: "a inTARSKIR2 p"
            using A1 sorry
          have "lenFINSEQ-1K4 a =XBOOLE-0R4 n1"
            using A3 A5 sorry
          thus "n1 =HIDDENR1 n2"
            using A4 A5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mdef margrel1_def_4 ("relation-lengthMARGREL1M2-of  _ " [70]70 ) where
  mlet "k be ElementSUBSET-1M1-of NATNUMBERSK1"
"mode relation-lengthMARGREL1M2-of k \<rightarrow> relationMARGREL1M1 means
  (\<lambda>it.  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 it implies lenFINSEQ-1K4 a =XBOOLE-0R4 k)"
proof-
  (*existence*)
    show " ex it be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 it implies lenFINSEQ-1K4 a =XBOOLE-0R4 k"
    proof-
      have " ex tVar2 be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 tVar2 &  not lenFINSEQ-1K4 a =XBOOLE-0R4 k)"
      proof-
        show " ex tVar2 be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 tVar2 &  not lenFINSEQ-1K4 a =XBOOLE-0R4 k)"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          show " for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 {}XBOOLE-0K1 &  not lenFINSEQ-1K4 a =XBOOLE-0R4 k)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef margrel1_def_5 ("relationMARGREL1M3-of  _ " [70]70 ) where
  mlet "X be setHIDDENM2"
"mode relationMARGREL1M3-of X \<rightarrow> relationMARGREL1M1 means
  (\<lambda>it.  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 it implies rngRELAT-1K2 a c=TARSKIR1 X)"
proof-
  (*existence*)
    show " ex it be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 it implies rngRELAT-1K2 a c=TARSKIR1 X"
    proof-
      have " ex tVar3 be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 tVar3 &  not rngRELAT-1K2 a c=TARSKIR1 X)"
      proof-
        show " ex tVar3 be relationMARGREL1M1 st  for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 tVar3 &  not rngRELAT-1K2 a c=TARSKIR1 X)"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          show " for a be FinSequenceFINSEQ-1M1 holds  not (a inTARSKIR2 {}XBOOLE-0K1 &  not rngRELAT-1K2 a c=TARSKIR1 X)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem margrel1_th_4:
" for X be setHIDDENM2 holds {}XBOOLE-0K1 be relationMARGREL1M3-of X"
proof-
  have " for X be setHIDDENM2 holds {}XBOOLE-0K1 be relationMARGREL1M3-of X"
  proof(rule ballI)
    fix X assume [ty]: "X be setHIDDENM2"
    have " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 {}XBOOLE-0K1 implies rngRELAT-1K2 a c=TARSKIR1 X"
    proof-
      show " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 {}XBOOLE-0K1 implies rngRELAT-1K2 a c=TARSKIR1 X"
         sorry
    qed
    thus "{}XBOOLE-0K1 be relationMARGREL1M3-of X"
      using margrel1_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem margrel1_th_5:
" for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds {}XBOOLE-0K1 be relation-lengthMARGREL1M2-of k"
proof-
  have " for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds {}XBOOLE-0K1 be relation-lengthMARGREL1M2-of k"
  proof(rule ballI)
    fix k assume [ty]: "k be ElementSUBSET-1M1-of NATNUMBERSK1"
    have " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 a =XBOOLE-0R4 k"
    proof-
      show " for a be FinSequenceFINSEQ-1M1 holds a inTARSKIR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 a =XBOOLE-0R4 k"
         sorry
    qed
    thus "{}XBOOLE-0K1 be relation-lengthMARGREL1M2-of k"
      using margrel1_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef margrel1_def_6 ("relationMARGREL1M4-of'( _ , _ ')" [0,0]70 ) where
  mlet "X be setHIDDENM2", "k be ElementSUBSET-1M1-of NATNUMBERSK1"
"mode relationMARGREL1M4-of(X,k) \<rightarrow> relationMARGREL1M1 means
  (\<lambda>it. it be relationMARGREL1M3-of X & it be relation-lengthMARGREL1M2-of k)"
proof-
  (*existence*)
    show " ex it be relationMARGREL1M1 st it be relationMARGREL1M3-of X & it be relation-lengthMARGREL1M2-of k"
    proof-
      have " ex tVar4 be relationMARGREL1M1 st tVar4 be relationMARGREL1M3-of X & tVar4 be relation-lengthMARGREL1M2-of k"
      proof-
        show " ex tVar4 be relationMARGREL1M1 st tVar4 be relationMARGREL1M3-of X & tVar4 be relation-lengthMARGREL1M2-of k"
        proof(rule bexI[of _ "{}XBOOLE-0K1"])
          show "{}XBOOLE-0K1 be relationMARGREL1M3-of X & {}XBOOLE-0K1 be relation-lengthMARGREL1M2-of k"
            using margrel1_th_4 margrel1_th_5 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef margrel1_def_7 ("relations-onMARGREL1K2  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func relations-onMARGREL1K2 D \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for X be setHIDDENM2 holds X inTARSKIR2 it iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for X be setHIDDENM2 holds X inTARSKIR2 it iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
    proof-
      have " ex tVar5 be setHIDDENM2 st  for X be setHIDDENM2 holds  not (X inTARSKIR2 tVar5 &  not (X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)))) &  not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 tVar5)"
      proof-
        let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st (Y =HIDDENR1 Lamb1 & Y c=TARSKIR1 D * FINSEQ-2K3) & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 Y & b inTARSKIR2 Y implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
        obtain A where
          [ty]:"A be setHIDDENM2" and 
          A1: " for x be objectHIDDENM1 holds x inHIDDENR3 A iff x inHIDDENR3 boolZFMISC-1K1 (D * FINSEQ-2K3) & ?P(x)"
          using xboole_0_sch_1 sorry
        show " ex tVar5 be setHIDDENM2 st  for X be setHIDDENM2 holds  not (X inTARSKIR2 tVar5 &  not (X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)))) &  not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 tVar5)"
        proof(rule bexI[of _ "A"])
          have " for X be setHIDDENM2 holds X inTARSKIR2 A iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
          proof-
            have " for X be setHIDDENM2 holds (X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) &  not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 A)"
            proof(rule ballI,rule conjMI)
              fix X assume [ty]: "X be setHIDDENM2"
              show "X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
              proof-
                have "X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))"
                proof(rule impI)
                  assume "X inTARSKIR2 A"
                  then have " ex Y be setHIDDENM2 st (Y =XBOOLE-0R4 X & Y c=TARSKIR1 D * FINSEQ-2K3) & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 Y & b inTARSKIR2 Y implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
                    using A1 sorry
                  thus "X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))"
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              show " not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 A)"
                using A1 sorry
            qed "sorry"
            thus " ?thesis "
               sorry
          qed
          thus " for X be setHIDDENM2 holds  not (X inTARSKIR2 A &  not (X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)))) &  not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 A)"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 it1 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) & ( for X be setHIDDENM2 holds X inTARSKIR2 it2 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) implies it1 =HIDDENR1 it2"
    proof-
      have " for A1 be setHIDDENM2 holds  for A2 be setHIDDENM2 holds ( for X be setHIDDENM2 holds X inTARSKIR2 A1 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) & ( for X be setHIDDENM2 holds X inTARSKIR2 A2 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) implies A1 =HIDDENR1 A2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix A1 assume [ty]: "A1 be setHIDDENM2"
        fix A2 assume [ty]: "A2 be setHIDDENM2"
        assume A2: " for X be setHIDDENM2 holds X inTARSKIR2 A1 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
          and A3: " for X be setHIDDENM2 holds X inTARSKIR2 A2 iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 A1 iff x inHIDDENR3 A2"
        proof-
          have " for x be objectHIDDENM1 holds (x inHIDDENR3 A1 implies x inHIDDENR3 A2) & (x inHIDDENR3 A2 implies x inHIDDENR3 A1)"
          proof(rule ballI,rule conjMI)
            fix x assume [ty]: "x be objectHIDDENM1"
            obtain xx where 
              [ty]:"xx be setHIDDENM2" and xxDef:"xx = x"
              using tarski_th_1 sorry
            show "x inHIDDENR3 A1 implies x inHIDDENR3 A2"
            proof(rule impI)
              assume A4: "x inHIDDENR3 A1"
              then have A5: " for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 xx & b inTARSKIR2 xx implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
                using A2 sorry
              have "xx c=TARSKIR1 D * FINSEQ-2K3"
                using A2 A4 sorry
              thus "x inHIDDENR3 A2"
                using A3 A5 sorry
            qed
            show "x inHIDDENR3 A2 implies x inHIDDENR3 A1"
            proof(rule impI)
              assume A6: "x inHIDDENR3 A2"
              then have A7: " for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 xx & b inTARSKIR2 xx implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
                using A3 sorry
              have "xx c=TARSKIR1 D * FINSEQ-2K3"
                using A3 A6 sorry
              thus "x inHIDDENR3 A1"
                using A2 A7 sorry
            qed
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "A1 =HIDDENR1 A2"
          using tarski_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem margrel1_cl_3:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster relations-onMARGREL1K2 D as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "relations-onMARGREL1K2 D be  non emptyXBOOLE-0V1"
  proof-
    have " not relations-onMARGREL1K2 D be emptyXBOOLE-0V1"
    proof-
      have A1: " for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 {}XBOOLE-0K1 & b inTARSKIR2 {}XBOOLE-0K1 implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
         sorry
      let ?P = "\<lambda>Lamb1.  ex Y be setHIDDENM2 st (Y =HIDDENR1 Lamb1 & Y c=TARSKIR1 D * FINSEQ-2K3) & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 Y & b inTARSKIR2 Y implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
      obtain XX where
        [ty]:"XX be setHIDDENM2" and 
        A2: " for x be objectHIDDENM1 holds x inHIDDENR3 XX iff x inHIDDENR3 boolZFMISC-1K1 (D * FINSEQ-2K3) & ?P(x)"
        using xboole_0_sch_1 sorry
      have "{}XBOOLE-0K1 c=RELAT-1R2 D * FINSEQ-2K3"
         sorry
      then obtain A where 
        [ty]:"A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and ADef:"A = XX"
        using A2 A1 sorry
      have " for X be setHIDDENM2 holds X inTARSKIR2 A iff X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
      proof-
        have " for X be setHIDDENM2 holds (X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)) &  not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 A)"
        proof(rule ballI,rule conjMI)
          fix X assume [ty]: "X be setHIDDENM2"
          show "X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
          proof-
            have "X inTARSKIR2 A implies X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))"
            proof(rule impI)
              assume "X inTARSKIR2 A"
              then have " ex Y be setHIDDENM2 st (Y =XBOOLE-0R4 X & Y c=TARSKIR1 D * FINSEQ-2K3) & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 Y & b inTARSKIR2 Y implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b)"
                using A2 sorry
              thus "X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))"
                 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          show " not ((X c=TARSKIR1 D * FINSEQ-2K3 & ( for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds  not ((a inTARSKIR2 X & b inTARSKIR2 X) &  not lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b))) &  not X inTARSKIR2 A)"
            using A2 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not relations-onMARGREL1K2 D be emptyXBOOLE-0V1"
        using margrel1_def_7 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

abbreviation(input) MARGREL1M5("relationMARGREL1M5-of  _ " [70]70) where
  "relationMARGREL1M5-of D \<equiv> ElementSUBSET-1M1-of relations-onMARGREL1K2 D"

reserve a, b for "FinSequenceFINSEQ-1M3-of D"
reserve p, r for "ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
mtheorem margrel1_th_6:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be setHIDDENM2 holds  for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 D holds X c=TARSKIR1 r implies X be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for X be setHIDDENM2 holds  for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 D holds X c=TARSKIR1 r implies X be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix X assume [ty]: "X be setHIDDENM2"
    fix r assume [ty]: "r be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
    assume A1: "X c=TARSKIR1 r"
    then have A2: " for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
      using margrel1_def_7 sorry
    have "r c=TARSKIR1 D * FINSEQ-2K3"
      using margrel1_def_7 sorry
    then have "X c=TARSKIR1 D * FINSEQ-2K3"
      using A1 sorry
    thus "X be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
      using A2 margrel1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem margrel1_th_7:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of D holds {TARSKIK1 a} be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be FinSequenceFINSEQ-1M3-of D holds {TARSKIK1 a} be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of D"
    have A1: " for a1 be FinSequenceFINSEQ-1M3-of D holds  for a2 be FinSequenceFINSEQ-1M3-of D holds a1 inTARSKIR2 {TARSKIK1 a} & a2 inTARSKIR2 {TARSKIK1 a} implies lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a1 assume [ty]: "a1 be FinSequenceFINSEQ-1M3-of D"
      fix a2 assume [ty]: "a2 be FinSequenceFINSEQ-1M3-of D"
      assume A2: "a1 inTARSKIR2 {TARSKIK1 a}"
        and A3: "a2 inTARSKIR2 {TARSKIK1 a}"
      have "a1 =FINSEQ-1R1 a"
        using A2 tarski_def_1 sorry
      thus "lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
        using A3 tarski_def_1 sorry
    qed "sorry"
    have "a inTARSKIR2 D * FINSEQ-2K3"
      using finseq_1_def_11 sorry
    then have "{TARSKIK1 a} c=TARSKIR1 D * FINSEQ-2K3"
      using zfmisc_1_th_31 sorry
    thus "{TARSKIK1 a} be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
      using A1 margrel1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem margrel1_th_8:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of D holds  for y be ElementSUBSET-1M1-of D holds {TARSKIK1 <*FINSEQ-1K11 x,y *> } be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for x be ElementSUBSET-1M1-of D holds  for y be ElementSUBSET-1M1-of D holds {TARSKIK1 <*FINSEQ-1K11 x,y *> } be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of D"
    fix y assume [ty]: "y be ElementSUBSET-1M1-of D"
    have A1: " for a1 be FinSequenceFINSEQ-1M3-of D holds  for a2 be FinSequenceFINSEQ-1M3-of D holds a1 inTARSKIR2 {TARSKIK1 <*FINSEQ-1K11 x,y *> } & a2 inTARSKIR2 {TARSKIK1 <*FINSEQ-1K11 x,y *> } implies lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix a1 assume [ty]: "a1 be FinSequenceFINSEQ-1M3-of D"
      fix a2 assume [ty]: "a2 be FinSequenceFINSEQ-1M3-of D"
      assume A2: "a1 inTARSKIR2 {TARSKIK1 <*FINSEQ-1K11 x,y *> }"
        and A3: "a2 inTARSKIR2 {TARSKIK1 <*FINSEQ-1K11 x,y *> }"
      have "a1 =FINSEQ-1R1 <*FINSEQ-1K11 x,y *>"
        using A2 tarski_def_1 sorry
      thus "lenFINSEQ-1K4 a1 =XBOOLE-0R4 lenFINSEQ-1K4 a2"
        using A3 tarski_def_1 sorry
    qed "sorry"
    have "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> x*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> y*>) be FinSequenceFINSEQ-1M3-of D"
       sorry
    then have "<*FINSEQ-1K11 x,y *> inTARSKIR2 D * FINSEQ-2K3"
      using finseq_1_def_11 sorry
    then have "{TARSKIK1 <*FINSEQ-1K11 x,y *> } c=TARSKIR1 D * FINSEQ-2K3"
      using zfmisc_1_th_31 sorry
    thus "{TARSKIK1 <*FINSEQ-1K11 x,y *> } be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
      using A1 margrel1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax MARGREL1R2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =MARGREL1R2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "p =MARGREL1R2\<^bsub>(D)\<^esub> r" \<rightharpoonup> "p =HIDDENR1 r"

mtheorem margrel1_def_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of relations-onMARGREL1K2 D", "r be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
"redefine pred p =MARGREL1R2\<^bsub>(D)\<^esub> r means
   for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r"
proof
(*compatibility*)
  show "p =MARGREL1R2\<^bsub>(D)\<^esub> r iff ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r)"
  proof-
    have "(p =XBOOLE-0R4 r implies ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r)) & (( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r) implies p =HIDDENR1 r)"
    proof(rule conjMI,rule impI)
      show "p =XBOOLE-0R4 r implies ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r)"
         sorry
      assume A1: " for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p iff a inTARSKIR2 r"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 p iff x inHIDDENR3 r"
      proof(rule ballI)
        fix x assume [ty]: "x be objectHIDDENM1"
        have A2: "x inHIDDENR3 r implies x inHIDDENR3 p"
        proof(rule impI)
          assume A3: "x inHIDDENR3 r"
          have "r be SubsetSUBSET-1M2-of D * FINSEQ-2K3"
            using margrel1_def_7 sorry
          then have "x be FinSequenceFINSEQ-1M3-of D"
            using A3 finseq_1_def_11 sorry
          thus "x inHIDDENR3 p"
            using A1 A3 sorry
        qed
        have "x inHIDDENR3 p implies x inHIDDENR3 r"
        proof(rule impI)
          assume A4: "x inHIDDENR3 p"
          have "p be SubsetSUBSET-1M2-of D * FINSEQ-2K3"
            using margrel1_def_7 sorry
          then have "x be FinSequenceFINSEQ-1M3-of D"
            using A4 finseq_1_def_11 sorry
          thus "x inHIDDENR3 r"
            using A1 A4 sorry
        qed
        thus "x inHIDDENR3 p iff x inHIDDENR3 r"
          using A2 sorry
      qed "sorry"
      thus "p =HIDDENR1 r"
        using tarski_th_2 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

theorem margrel1_sch_2:
  fixes Df0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for a be FinSequenceFINSEQ-1M3-of Df0 holds  for b be FinSequenceFINSEQ-1M3-of Df0 holds Pp1(a) & Pp1(b) implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
  shows " ex r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 st  for a be FinSequenceFINSEQ-1M3-of Df0 holds a inTARSKIR2 r iff Pp1(a)"
  proof-
    have " not ( for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 holds  not ( for a be FinSequenceFINSEQ-1M3-of Df0 holds  not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)))"
    proof-
      let ?P1 = "\<lambda>Lamb1.  ex a be FinSequenceFINSEQ-1M3-of Df0 st Pp1(a) & Lamb1 =HIDDENR1 a"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A2: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Df0 * FINSEQ-2K3 & ?P1(x)"
        using xboole_0_sch_1 sorry
      have A3: " for a be FinSequenceFINSEQ-1M3-of Df0 holds  for b be FinSequenceFINSEQ-1M3-of Df0 holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of Df0"
        fix b assume [ty]: "b be FinSequenceFINSEQ-1M3-of Df0"
        assume A4: "a inTARSKIR2 X"
          and A5: "b inTARSKIR2 X"
        have A6: " ex d be FinSequenceFINSEQ-1M3-of Df0 st Pp1(d) & b =FINSEQ-1R1 d"
          using A2 A5 sorry
        have " ex c be FinSequenceFINSEQ-1M3-of Df0 st Pp1(c) & a =FINSEQ-1R1 c"
          using A2 A4 sorry
        thus "lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
          using A1 A6 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Df0 * FINSEQ-2K3"
        using A2 sorry
      then have "X c=TARSKIR1 Df0 * FINSEQ-2K3"
         sorry
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0" and rDef:"r = X"
        using A3 margrel1_def_7 sorry
      have " for a be FinSequenceFINSEQ-1M3-of Df0 holds a inTARSKIR2 r iff Pp1(a)"
      proof-
        have " for a be FinSequenceFINSEQ-1M3-of Df0 holds  not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)"
        proof(rule ballI)
          fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of Df0"
          have A7: "Pp1(a) implies a inTARSKIR2 r"
          proof(rule impI)
            have A8: "a inTARSKIR2 Df0 * FINSEQ-2K3"
              using finseq_1_def_11 sorry
            assume "Pp1(a)"
            thus "a inTARSKIR2 r"
              using A2 A8 sorry
          qed
          have "a inTARSKIR2 r implies Pp1(a)"
          proof(rule impI)
            assume "a inTARSKIR2 r"
            then have " ex c be FinSequenceFINSEQ-1M3-of Df0 st Pp1(c) & a =FINSEQ-1R1 c"
              using A2 sorry
            thus "Pp1(a)"
               sorry
          qed
          thus " not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)"
            using A7 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not ( for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 holds  not ( for a be FinSequenceFINSEQ-1M3-of Df0 holds  not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

mdef margrel1_def_9 ("empty-relMARGREL1K3  _ " [164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"func empty-relMARGREL1K3 D \<rightarrow> ElementSUBSET-1M1-of relations-onMARGREL1K2 D means
  \<lambda>it.  for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 it"
proof-
  (*existence*)
    show " ex it be ElementSUBSET-1M1-of relations-onMARGREL1K2 D st  for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 it"
    proof-
      have " ex tVar6 be ElementSUBSET-1M1-of relations-onMARGREL1K2 D st  for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 tVar6"
      proof-
        let ?P = "\<lambda>Lamb1.  False "
        have A1: " for a be FinSequenceFINSEQ-1M3-of D holds  for b be FinSequenceFINSEQ-1M3-of D holds ?P(a) & ?P(b) implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
           sorry
        obtain r where
          [ty]:"r be ElementSUBSET-1M1-of relations-onMARGREL1K2 D" and 
          A2: " for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 r iff ?P(a)"
          using margrel1_sch_2 A1 sorry
        show " ex tVar6 be ElementSUBSET-1M1-of relations-onMARGREL1K2 D st  for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 tVar6"
        proof(rule bexI[of _ "r"])
          show " for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 r"
            using A2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be ElementSUBSET-1M1-of relations-onMARGREL1K2 D holds  for it2 be ElementSUBSET-1M1-of relations-onMARGREL1K2 D holds ( for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 it1) & ( for a be FinSequenceFINSEQ-1M3-of D holds  not a inTARSKIR2 it2) implies it1 =HIDDENR1 it2"
       sorry
qed "sorry"

mtheorem margrel1_th_9:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds empty-relMARGREL1K3 D =XBOOLE-0R4 {}XBOOLE-0K1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  not empty-relMARGREL1K3 D =XBOOLE-0R4 {}XBOOLE-0K1 implies  False "
  proof(rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    assume A1: " not empty-relMARGREL1K3 D =XBOOLE-0R4 {}XBOOLE-0K1"
    let ?x = "the ElementSUBSET-1M1-of empty-relMARGREL1K3 D"
    have "empty-relMARGREL1K3 D be SubsetSUBSET-1M2-of D * FINSEQ-2K3"
      using margrel1_def_7 sorry
    then have "?x inTARSKIR2 D * FINSEQ-2K3"
      using A1 tarski_def_3 sorry
    then obtain a where 
      [ty]:"a be FinSequenceFINSEQ-1M3-of D" and aDef:"a = ?x"
      using finseq_1_def_11 sorry
    have "a inTARSKIR2 empty-relMARGREL1K3 D"
      using A1 sorry
    thus " False "
      using margrel1_def_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef margrel1_def_10 ("the-arity-ofMARGREL1K4\<^bsub>'( _ ')\<^esub>  _ " [0,120]120 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of relations-onMARGREL1K2 D"
"assume p <>HIDDENR2 empty-relMARGREL1K3 D func the-arity-ofMARGREL1K4\<^bsub>(D)\<^esub> p \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it.  for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a"
proof-
  (*existence*)
    show "p <>HIDDENR2 empty-relMARGREL1K3 D implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a)"
    proof(rule impI)
      assume Assume: "p <>HIDDENR2 empty-relMARGREL1K3 D"
      have A1: "p <>HIDDENR2 empty-relMARGREL1K3 D"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st  for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it =XBOOLE-0R4 lenFINSEQ-1K4 a"
      proof-
        have " not ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for a be FinSequenceFINSEQ-1M3-of D holds  not (a inTARSKIR2 p &  not VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 a)))"
        proof-
          obtain c where
            [ty]:"c be FinSequenceFINSEQ-1M3-of D" and 
            A2: "c inTARSKIR2 p"
            using A1 margrel1_def_9 sorry
          have " for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies lenFINSEQ-1K4 c =XBOOLE-0R4 lenFINSEQ-1K4 a"
            using A2 margrel1_def_7 sorry
          thus " not ( for VarFor1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not ( for a be FinSequenceFINSEQ-1M3-of D holds  not (a inTARSKIR2 p &  not VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 a)))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p <>HIDDENR2 empty-relMARGREL1K3 D implies ( for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p <>HIDDENR2 empty-relMARGREL1K3 D"
      have A1: "p <>HIDDENR2 empty-relMARGREL1K3 D"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies it2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies it1 =HIDDENR1 it2"
      proof-
        have " for n1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for n2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies n1 =XBOOLE-0R4 lenFINSEQ-1K4 a) & ( for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies n2 =XBOOLE-0R4 lenFINSEQ-1K4 a) implies n1 =HIDDENR1 n2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix n1 assume [ty]: "n1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix n2 assume [ty]: "n2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume A3: " for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies n1 =XBOOLE-0R4 lenFINSEQ-1K4 a"
            and A4: " for a be FinSequenceFINSEQ-1M3-of D holds a inTARSKIR2 p implies n2 =XBOOLE-0R4 lenFINSEQ-1K4 a"
          obtain a where
            [ty]:"a be FinSequenceFINSEQ-1M3-of D" and 
            A5: "a inTARSKIR2 p"
            using A1 margrel1_def_9 sorry
          have "lenFINSEQ-1K4 a =XBOOLE-0R4 n1"
            using A3 A5 sorry
          thus "n1 =HIDDENR1 n2"
            using A4 A5 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

theorem margrel1_sch_3:
  fixes Df0 kf0 Pp1 
  assumes
[ty]: "Df0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "kf0 be ElementSUBSET-1M1-of NATNUMBERSK1"
  shows " ex r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 st  for a be FinSequenceFINSEQ-1M3-of Df0 holds lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 implies (a inTARSKIR2 r iff Pp1(a))"
  proof-
    have " not ( for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 holds  not ( for a be FinSequenceFINSEQ-1M3-of Df0 holds  not (lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 &  not ( not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)))))"
    proof-
      let ?P1 = "\<lambda>Lamb1.  ex a be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 & Pp1(a)) & Lamb1 =HIDDENR1 a"
      obtain X where
        [ty]:"X be setHIDDENM2" and 
        A1: " for x be objectHIDDENM1 holds x inHIDDENR3 X iff x inHIDDENR3 Df0 * FINSEQ-2K3 & ?P1(x)"
        using xboole_0_sch_1 sorry
      have A2: " for a be FinSequenceFINSEQ-1M3-of Df0 holds  for b be FinSequenceFINSEQ-1M3-of Df0 holds a inTARSKIR2 X & b inTARSKIR2 X implies lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of Df0"
        fix b assume [ty]: "b be FinSequenceFINSEQ-1M3-of Df0"
        assume A3: "a inTARSKIR2 X"
          and A4: "b inTARSKIR2 X"
        have A5: " ex d be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 d =XBOOLE-0R4 kf0 & Pp1(d)) & b =FINSEQ-1R1 d"
          using A1 A4 sorry
        have " ex c be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 c =XBOOLE-0R4 kf0 & Pp1(c)) & a =FINSEQ-1R1 c"
          using A1 A3 sorry
        thus "lenFINSEQ-1K4 a =XBOOLE-0R4 lenFINSEQ-1K4 b"
          using A5 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 X implies x inHIDDENR3 Df0 * FINSEQ-2K3"
        using A1 sorry
      then have "X c=TARSKIR1 Df0 * FINSEQ-2K3"
         sorry
      then obtain r where 
        [ty]:"r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0" and rDef:"r = X"
        using A2 margrel1_def_7 sorry
      have " for a be FinSequenceFINSEQ-1M3-of Df0 holds lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 implies (a inTARSKIR2 r iff Pp1(a))"
      proof-
        have " for a be FinSequenceFINSEQ-1M3-of Df0 holds lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 implies  not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)"
        proof(rule ballI,rule impI)
          fix a assume [ty]: "a be FinSequenceFINSEQ-1M3-of Df0"
          assume A6: "lenFINSEQ-1K4 a =XBOOLE-0R4 kf0"
          have A7: "Pp1(a) implies a inTARSKIR2 r"
          proof(rule impI)
            have A8: "a inTARSKIR2 Df0 * FINSEQ-2K3"
              using finseq_1_def_11 sorry
            assume "Pp1(a)"
            thus "a inTARSKIR2 r"
              using A1 A6 A8 sorry
          qed
          have "a inTARSKIR2 r implies Pp1(a)"
          proof(rule impI)
            assume "a inTARSKIR2 r"
            then have " ex c be FinSequenceFINSEQ-1M3-of Df0 st (lenFINSEQ-1K4 c =XBOOLE-0R4 kf0 & Pp1(c)) & a =FINSEQ-1R1 c"
              using A1 sorry
            thus "Pp1(a)"
               sorry
          qed
          thus " not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)"
            using A7 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      thus " not ( for r be ElementSUBSET-1M1-of relations-onMARGREL1K2 Df0 holds  not ( for a be FinSequenceFINSEQ-1M3-of Df0 holds  not (lenFINSEQ-1K4 a =XBOOLE-0R4 kf0 &  not ( not (a inTARSKIR2 r &  not Pp1(a)) &  not (Pp1(a) &  not a inTARSKIR2 r)))))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed

mdef margrel1_def_11 ("BOOLEANMARGREL1K5" 164 ) where
"func BOOLEANMARGREL1K5 \<rightarrow> setHIDDENM2 equals
  {TARSKIK2 0NUMBERSK6,\<one>\<^sub>M }"
proof-
  (*coherence*)
    show "{TARSKIK2 0NUMBERSK6,\<one>\<^sub>M } be setHIDDENM2"
       sorry
qed "sorry"

mtheorem margrel1_cl_4:
"cluster BOOLEANMARGREL1K5 as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "BOOLEANMARGREL1K5 be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

abbreviation(input) MARGREL1K6("FALSEMARGREL1K6" 164) where
  "FALSEMARGREL1K6 \<equiv> FALSEXBOOLEANK1"

mtheorem margrel1_add_1:
"cluster FALSEXBOOLEANK1 as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "FALSEXBOOLEANK1 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    using tarski_def_2 sorry
qed "sorry"

abbreviation(input) MARGREL1K7("TRUEMARGREL1K7" 164) where
  "TRUEMARGREL1K7 \<equiv> TRUEXBOOLEANK2"

mtheorem margrel1_add_2:
"cluster TRUEXBOOLEANK2 as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "TRUEXBOOLEANK2 be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    using tarski_def_2 sorry
qed "sorry"

abbreviation(input) MARGREL1V2("booleanMARGREL1V2" 70) where
  "booleanMARGREL1V2 \<equiv> booleanXBOOLEANV1"

mtheorem margrel1_def_12:
  mlet "x be objectHIDDENM1"
"redefine attr booleanMARGREL1V2 for objectHIDDENM1 means
  (\<lambda>x. x inHIDDENR3 BOOLEANMARGREL1K5)"
proof
(*compatibility*)
  show " for x be objectHIDDENM1 holds x be booleanMARGREL1V2 iff x inHIDDENR3 BOOLEANMARGREL1K5"
  proof(rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    show "x be booleanMARGREL1V2 iff x inHIDDENR3 BOOLEANMARGREL1K5"
      using tarski_def_2 sorry
  qed "sorry"
qed "sorry"

mtheorem margrel1_cl_5:
"cluster note-that booleanMARGREL1V2 for ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of BOOLEANMARGREL1K5 holds it be booleanMARGREL1V2"
     sorry
qed "sorry"

reserve u, v, w for "booleanMARGREL1V2\<bar>objectHIDDENM1"
abbreviation(input) MARGREL1K8("''not''MARGREL1K8  _ " [182]182) where
  "'not'MARGREL1K8 v \<equiv> 'not'XBOOLEANK3 v"

mtheorem margrel1_def_13:
  mlet "v be booleanMARGREL1V2\<bar>objectHIDDENM1"
"redefine func 'not'MARGREL1K8 v \<rightarrow> objectHIDDENM1 equals
  TRUEMARGREL1K7 if v =HIDDENR1 FALSEMARGREL1K6 otherwise FALSEMARGREL1K6"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds (v =HIDDENR1 FALSEMARGREL1K6 implies (it =HIDDENR1 'not'MARGREL1K8 v iff it =HIDDENR1 TRUEMARGREL1K7)) & ( not v =HIDDENR1 FALSEMARGREL1K6 implies (it =HIDDENR1 'not'MARGREL1K8 v iff it =HIDDENR1 FALSEMARGREL1K6))"
  proof-
    have " for w be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (v =HIDDENR1 FALSEMARGREL1K6 implies (w =HIDDENR1 'not'XBOOLEANK3 v iff w =HIDDENR1 TRUEMARGREL1K7)) & (v <>HIDDENR2 FALSEMARGREL1K6 implies  not (w =HIDDENR1 'not'XBOOLEANK3 v &  not w =HIDDENR1 FALSEMARGREL1K6) &  not (w =HIDDENR1 FALSEMARGREL1K6 &  not w =HIDDENR1 'not'XBOOLEANK3 v))"
    proof(rule ballI,rule conjMI,rule impI)
      fix w assume [ty]: "w be booleanMARGREL1V2\<bar>objectHIDDENM1"
      show "v =HIDDENR1 FALSEMARGREL1K6 implies (w =HIDDENR1 'not'XBOOLEANK3 v iff w =HIDDENR1 TRUEMARGREL1K7)"
         sorry
      assume "v <>HIDDENR2 FALSEMARGREL1K6"
      then have "v =HIDDENR1 TRUEMARGREL1K7"
        using xboolean_def_3 sorry
      thus " not (w =HIDDENR1 'not'XBOOLEANK3 v &  not w =HIDDENR1 FALSEMARGREL1K6) &  not (w =HIDDENR1 FALSEMARGREL1K6 &  not w =HIDDENR1 'not'XBOOLEANK3 v)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
(*consistency*)
  show " for it be objectHIDDENM1 holds  True "
     sorry
qed "sorry"

abbreviation(input) MARGREL1K9(" _ ''&''MARGREL1K9  _ " [180,180]180) where
  "v '&'MARGREL1K9 w \<equiv> v '&'XBOOLEANK4 w"

mtheorem margrel1_def_14:
  mlet "v be booleanMARGREL1V2\<bar>objectHIDDENM1", "w be booleanMARGREL1V2\<bar>objectHIDDENM1"
"redefine func v '&'MARGREL1K9 w \<rightarrow> objectHIDDENM1 equals
  TRUEMARGREL1K7 if v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7 otherwise FALSEMARGREL1K6"
proof
(*compatibility*)
  show " for it be objectHIDDENM1 holds (v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7 implies (it =HIDDENR1 v '&'MARGREL1K9 w iff it =HIDDENR1 TRUEMARGREL1K7)) & ( not (v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7) implies (it =HIDDENR1 v '&'MARGREL1K9 w iff it =HIDDENR1 FALSEMARGREL1K6))"
  proof-
    have " for u be objectHIDDENM1 holds (v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7 implies (u =HIDDENR1 v '&'XBOOLEANK4 w iff u =HIDDENR1 TRUEMARGREL1K7)) & (v <>HIDDENR2 TRUEMARGREL1K7 or w <>HIDDENR2 TRUEMARGREL1K7 implies  not (u =HIDDENR1 v '&'XBOOLEANK4 w &  not u =HIDDENR1 FALSEMARGREL1K6) &  not (u =HIDDENR1 FALSEMARGREL1K6 &  not u =HIDDENR1 v '&'XBOOLEANK4 w))"
    proof(rule ballI,rule conjMI,rule impI)
      fix u assume [ty]: "u be objectHIDDENM1"
      show "v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7 implies (u =HIDDENR1 v '&'XBOOLEANK4 w iff u =HIDDENR1 TRUEMARGREL1K7)"
         sorry
      assume "v <>HIDDENR2 TRUEMARGREL1K7 or w <>HIDDENR2 TRUEMARGREL1K7"
      then have "v =HIDDENR1 FALSEMARGREL1K6 or w =HIDDENR1 FALSEMARGREL1K6"
        using xboolean_def_3 sorry
      thus " not (u =HIDDENR1 v '&'XBOOLEANK4 w &  not u =HIDDENR1 FALSEMARGREL1K6) &  not (u =HIDDENR1 FALSEMARGREL1K6 &  not u =HIDDENR1 v '&'XBOOLEANK4 w)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
(*consistency*)
  show " for it be objectHIDDENM1 holds  True "
     sorry
qed "sorry"

abbreviation(input) MARGREL1K10("''not''MARGREL1K10  _ " [182]182) where
  "'not'MARGREL1K10 v \<equiv> 'not'XBOOLEANK3 v"

mtheorem margrel1_add_3:
  mlet "v be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster 'not'XBOOLEANK3 v as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "'not'XBOOLEANK3 v be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    using margrel1_def_12 sorry
qed "sorry"

abbreviation(input) MARGREL1K11(" _ ''&''MARGREL1K11  _ " [180,180]180) where
  "v '&'MARGREL1K11 w \<equiv> v '&'XBOOLEANK4 w"

mtheorem margrel1_add_4:
  mlet "v be ElementSUBSET-1M1-of BOOLEANMARGREL1K5", "w be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
"cluster v '&'XBOOLEANK4 w as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "v '&'XBOOLEANK4 w be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    using margrel1_def_12 sorry
qed "sorry"

(*\$CT*)
mtheorem margrel1_th_11:
" for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (v =HIDDENR1 FALSEMARGREL1K6 iff 'not'MARGREL1K8 v =HIDDENR1 TRUEMARGREL1K7) & (v =HIDDENR1 TRUEMARGREL1K7 iff 'not'MARGREL1K8 v =HIDDENR1 FALSEMARGREL1K6)"
   sorry

mtheorem margrel1_th_12:
" for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for w be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (v '&'MARGREL1K9 w =HIDDENR1 TRUEMARGREL1K7 iff v =HIDDENR1 TRUEMARGREL1K7 & w =HIDDENR1 TRUEMARGREL1K7) & (v '&'MARGREL1K9 w =HIDDENR1 FALSEMARGREL1K6 iff v =HIDDENR1 FALSEMARGREL1K6 or w =HIDDENR1 FALSEMARGREL1K6)"
  using xboolean_th_101 xboolean_th_140 sorry

mtheorem margrel1_th_13:
" for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (FALSEMARGREL1K6)'&'MARGREL1K9 v =HIDDENR1 FALSEMARGREL1K6"
   sorry

mtheorem margrel1_th_14:
" for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds (TRUEMARGREL1K7)'&'MARGREL1K9 v =HIDDENR1 v"
   sorry

mtheorem margrel1_th_15:
" for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds v '&'MARGREL1K9 v =HIDDENR1 FALSEMARGREL1K6 implies v =HIDDENR1 FALSEMARGREL1K6"
   sorry

mtheorem margrel1_th_16:
" for u be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for v be booleanMARGREL1V2\<bar>objectHIDDENM1 holds  for w be booleanMARGREL1V2\<bar>objectHIDDENM1 holds v '&'MARGREL1K9 (w '&'MARGREL1K9 u) =HIDDENR1 (v '&'MARGREL1K9 w)'&'MARGREL1K9 u"
   sorry

mdef margrel1_def_15 ("ALLMARGREL1K12  _ " [164]164 ) where
  mlet "X be setHIDDENM2"
"func ALLMARGREL1K12 X \<rightarrow> setHIDDENM2 equals
  TRUEMARGREL1K7 if  not FALSEMARGREL1K6 inTARSKIR2 X otherwise FALSEMARGREL1K6"
proof-
  (*coherence*)
    show "( not FALSEMARGREL1K6 inTARSKIR2 X implies TRUEMARGREL1K7 be setHIDDENM2) & ( not ( not FALSEMARGREL1K6 inTARSKIR2 X) implies FALSEMARGREL1K6 be setHIDDENM2)"
       sorry
  (*consistency*)
    show " for it be setHIDDENM2 holds  True "
       sorry
qed "sorry"

mtheorem margrel1_cl_6:
  mlet "X be setHIDDENM2"
"cluster ALLMARGREL1K12 X as-term-is booleanMARGREL1V2"
proof
(*coherence*)
  show "ALLMARGREL1K12 X be booleanMARGREL1V2"
    using margrel1_def_15 sorry
qed "sorry"

abbreviation(input) MARGREL1K13("ALLMARGREL1K13  _ " [164]164) where
  "ALLMARGREL1K13 X \<equiv> ALLMARGREL1K12 X"

mtheorem margrel1_add_5:
  mlet "X be setHIDDENM2"
"cluster ALLMARGREL1K12 X as-term-is ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
proof
(*coherence*)
  show "ALLMARGREL1K12 X be ElementSUBSET-1M1-of BOOLEANMARGREL1K5"
    using margrel1_def_12 sorry
qed "sorry"

mtheorem margrel1_th_17:
" for X be setHIDDENM2 holds ( not FALSEMARGREL1K6 inTARSKIR2 X iff ALLMARGREL1K13 X =XBOOLE-0R4 TRUEMARGREL1K7) & (FALSEMARGREL1K6 inTARSKIR2 X iff ALLMARGREL1K13 X =XBOOLE-0R4 FALSEMARGREL1K6)"
  using margrel1_def_15 sorry

(*begin*)
mdef margrel1_def_16 ("boolean-valuedMARGREL1V3" 70 ) where
"attr boolean-valuedMARGREL1V3 for RelationRELAT-1M1 means
  (\<lambda>f. rngRELAT-1K2 f c=TARSKIR1 BOOLEANMARGREL1K5)"..

mtheorem margrel1_cl_7:
"cluster boolean-valuedMARGREL1V3 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be boolean-valuedMARGREL1V3"
  proof-
    have " ex tVar7 be FunctionFUNCT-1M1 st tVar7 be boolean-valuedMARGREL1V3"
    proof-
      show " ex tVar7 be FunctionFUNCT-1M1 st tVar7 be boolean-valuedMARGREL1V3"
      proof(rule bexI[of _ "{}XBOOLE-0K1"])
        have "rngRELAT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 BOOLEANMARGREL1K5"
        proof-
          show "rngRELAT-1K2 ({}XBOOLE-0K1) c=RELAT-1R2 BOOLEANMARGREL1K5"
             sorry
        qed
        thus "{}XBOOLE-0K1 be boolean-valuedMARGREL1V3"
          using margrel1_def_16 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_8:
  mlet "f be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1", "x be objectHIDDENM1"
"cluster f .FUNCT-1K1 x as-term-is booleanMARGREL1V2"
proof
(*coherence*)
  show "f .FUNCT-1K1 x be booleanMARGREL1V2"
  proof-
    have "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
    proof-
      show "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
      proof-
        have cases: " not x inHIDDENR3 domRELAT-1K1 f or x inHIDDENR3 domRELAT-1K1 f"
           sorry
        have case1: " not x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be booleanXBOOLEANV1"
        proof(rule impI)
          assume " not x inHIDDENR3 domRELAT-1K1 f"
          then have Cut704: "f .FUNCT-1K1 x =XBOOLE-0R4 FALSEMARGREL1K6"
            using funct_1_def_2 sorry
          have "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
          proof-
            show "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
              using Cut704 sorry
          qed
          thus "f .FUNCT-1K1 x be booleanXBOOLEANV1"
            using margrel1_def_12 sorry
        qed
        have case2: "x inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x be booleanXBOOLEANV1"
        proof(rule impI)
          assume A1: "x inHIDDENR3 domRELAT-1K1 f"
          have A2: "rngRELAT-1K2 f c=TARSKIR1 BOOLEANMARGREL1K5"
            using margrel1_def_16 sorry
          have Cut710: "f .FUNCT-1K1 x inTARSKIR2 rngRELAT-1K2 f"
            using A1 funct_1_def_3 sorry
          have "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
          proof-
            show "f .FUNCT-1K1 x inTARSKIR2 BOOLEANMARGREL1K5"
              using A2 Cut710 sorry
          qed
          thus "f .FUNCT-1K1 x be booleanXBOOLEANV1"
            using margrel1_def_12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef margrel1_def_17 ("''not''MARGREL1K14  _ " [182]182 ) where
  mlet "p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
"func 'not'MARGREL1K14 p \<rightarrow> boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies it .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies it .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x)"
    proof-
      have " not ( for VarFor1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 p &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x))))"
      proof-
        let ?F = "\<lambda>Lamb1. 'not'MARGREL1K8 p .FUNCT-1K1 Lamb1"
        obtain q where
          [ty]:"q be FunctionFUNCT-1M1" and 
          A1: "domRELAT-1K1 q =XBOOLE-0R4 domRELAT-1K1 p"and A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          using funct_1_sch_3 sorry
        have "q be boolean-valuedMARGREL1V3"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 q implies x inHIDDENR3 BOOLEANMARGREL1K5"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELAT-1K2 q"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A3: "y inHIDDENR3 domRELAT-1K1 q"and A4: "x =HIDDENR1 q .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have "x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 y"
              using A1 A2 A3 A4 sorry
            then have "x =HIDDENR1 FALSEMARGREL1K6 or x =HIDDENR1 TRUEMARGREL1K7"
              using xboolean_def_3 sorry
            thus "x inHIDDENR3 BOOLEANMARGREL1K5"
               sorry
          qed "sorry"
          thus "q be boolean-valuedMARGREL1V3"
            using tarski_def_3 margrel1_def_16 sorry
        qed
        thus " not ( for VarFor1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 p &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x))))"
          using A1 A2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for it2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies it1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies it2 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
    proof-
      have " for q1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for q2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 q1 =XBOOLE-0R4 domRELAT-1K1 p & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x) & (domRELAT-1K1 q2 =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q2 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x))) implies q1 =HIDDENR1 q2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix q1 assume [ty]: "q1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        fix q2 assume [ty]: "q2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        assume A5: "domRELAT-1K1 q1 =XBOOLE-0R4 domRELAT-1K1 p"
          and A6: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x"
          and A7: "domRELAT-1K1 q2 =XBOOLE-0R4 domRELAT-1K1 p"
          and A8: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q2 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q1 .FUNCT-1K1 x =XBOOLE-0R4 q2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A9: "x inHIDDENR3 domRELAT-1K1 p"
          then have "q1 .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x"
            using A6 sorry
          thus "q1 .FUNCT-1K1 x =XBOOLE-0R4 q2 .FUNCT-1K1 x"
            using A8 A9 sorry
        qed "sorry"
        thus "q1 =HIDDENR1 q2"
          using A5 A7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem MARGREL1K14_involutiveness:
" for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds 'not'MARGREL1K14 ('not'MARGREL1K14 p) =HIDDENR1 p"
proof-
  have " for it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 'not'MARGREL1K14 p implies p =HIDDENR1 'not'MARGREL1K14 it"
  proof-
    have " for it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies it .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x) implies domRELAT-1K1 p =XBOOLE-0R4 domRELAT-1K1 it & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies p .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 it .FUNCT-1K1 x)"
    proof-
      have " for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 q =XBOOLE-0R4 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x) implies domRELAT-1K1 p =XBOOLE-0R4 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 q implies p .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 q .FUNCT-1K1 x)"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
        fix q assume [ty]: "q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        fix p assume [ty]: "p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        assume A10: "domRELAT-1K1 q =XBOOLE-0R4 domRELAT-1K1 p"
          and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies q .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x"
        show "domRELAT-1K1 p =XBOOLE-0R4 domRELAT-1K1 q"
          using A10 sorry
        fix x assume [ty]: "x be objectHIDDENM1"
        assume A12: "x inHIDDENR3 domRELAT-1K1 q"
        have "p .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 ('not'MARGREL1K8 p .FUNCT-1K1 x)"
           sorry
        also have "... = 'not'MARGREL1K8 q .FUNCT-1K1 x"
          using A10 A11 A12 sorry
        finally show "p .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 q .FUNCT-1K1 x"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using margrel1_def_17 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef margrel1_def_18 (" _ ''&''MARGREL1K15  _ " [180,180]180 ) where
  mlet "p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1", "q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
"func p '&'MARGREL1K15 q \<rightarrow> boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 means
  \<lambda>it. domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x)"
proof-
  (*existence*)
    show " ex it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 st domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x)"
    proof-
      have " not ( for VarFor1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x))))"
      proof-
        let ?F = "\<lambda>Lamb1. p .FUNCT-1K1 Lamb1 '&'MARGREL1K9 q .FUNCT-1K1 Lamb1"
        obtain s where
          [ty]:"s be FunctionFUNCT-1M1" and 
          A13: "domRELAT-1K1 s =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q"and A14: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q implies s .FUNCT-1K1 x =HIDDENR1 ?F(x)"
          using funct_1_sch_3 sorry
        have "s be boolean-valuedMARGREL1V3"
        proof-
          have " for x be objectHIDDENM1 holds x inHIDDENR3 rngRELAT-1K2 s implies x inHIDDENR3 BOOLEANMARGREL1K5"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            assume "x inHIDDENR3 rngRELAT-1K2 s"
            then obtain y where
              [ty]:"y be objectHIDDENM1" and 
              A15: "y inHIDDENR3 domRELAT-1K1 s"and A16: "x =HIDDENR1 s .FUNCT-1K1 y"
              using funct_1_def_3 sorry
            have "x =HIDDENR1 p .FUNCT-1K1 y '&'MARGREL1K9 q .FUNCT-1K1 y"
              using A13 A14 A15 A16 sorry
            then have "x =HIDDENR1 FALSEMARGREL1K6 or x =HIDDENR1 TRUEMARGREL1K7"
              using xboolean_def_3 sorry
            thus "x inHIDDENR3 BOOLEANMARGREL1K5"
               sorry
          qed "sorry"
          thus "s be boolean-valuedMARGREL1V3"
            using tarski_def_3 margrel1_def_16 sorry
        qed
        thus " not ( for VarFor1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  not (domRELAT-1K1 VarFor1 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds  not (x inHIDDENR3 domRELAT-1K1 VarFor1 &  not VarFor1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x))))"
          using A13 A14 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for it2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds (domRELAT-1K1 it1 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it1 implies it1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x)) & (domRELAT-1K1 it2 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it2 implies it2 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x)) implies it1 =HIDDENR1 it2"
    proof-
      have " for s1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for s2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 s1 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 s1 implies s1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x) & (domRELAT-1K1 s2 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 s2 implies s2 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x))) implies s1 =HIDDENR1 s2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        fix s2 assume [ty]: "s2 be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1"
        assume A17: "domRELAT-1K1 s1 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q"
          and A18: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 s1 implies s1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x"
          and A19: "domRELAT-1K1 s2 =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q"
          and A20: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 s2 implies s2 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x"
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 s1 implies s1 .FUNCT-1K1 x =XBOOLE-0R4 s2 .FUNCT-1K1 x"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A21: "x inHIDDENR3 domRELAT-1K1 s1"
          then have "s1 .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x"
            using A18 sorry
          thus "s1 .FUNCT-1K1 x =XBOOLE-0R4 s2 .FUNCT-1K1 x"
            using A17 A19 A20 A21 sorry
        qed "sorry"
        thus "s1 =HIDDENR1 s2"
          using A17 A19 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem MARGREL1K15_commutativity:
" for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds p '&'MARGREL1K15 q =HIDDENR1 q '&'MARGREL1K15 p"
proof-
  have " for it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds it =HIDDENR1 p '&'MARGREL1K15 q implies it =HIDDENR1 q '&'MARGREL1K15 p"
  proof-
    have " for it be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for p be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds  for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x) implies domRELAT-1K1 it =XBOOLE-0R4 domRELAT-1K1 q /\\XBOOLE-0K3 domRELAT-1K1 p & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 it implies it .FUNCT-1K1 x =HIDDENR1 q .FUNCT-1K1 x '&'MARGREL1K9 p .FUNCT-1K1 x)"
       sorry
    thus " ?thesis "
      using margrel1_def_18 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem MARGREL1K15_idempotence:
" for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds q =HIDDENR1 q '&'MARGREL1K15 q"
proof-
  have " for q be boolean-valuedMARGREL1V3\<bar>FunctionFUNCT-1M1 holds domRELAT-1K1 q =XBOOLE-0R4 domRELAT-1K1 q /\\XBOOLE-0K3 domRELAT-1K1 q & ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 q implies q .FUNCT-1K1 x =HIDDENR1 q .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x)"
     sorry
  thus " ?thesis "
    using margrel1_def_18 sorry
qed

mtheorem margrel1_cl_9:
  mlet "A be setHIDDENM2"
"cluster note-that boolean-valuedMARGREL1V3 for FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
proof
(*coherence*)
  show " for it be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) holds it be boolean-valuedMARGREL1V3"
    using relat_1_def_19 sorry
qed "sorry"

syntax MARGREL1K16 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("''not''MARGREL1K16\<^bsub>'( _ ')\<^esub>  _ " [0,182]182)
translations "'not'MARGREL1K16\<^bsub>(A)\<^esub> p" \<rightharpoonup> "'not'MARGREL1K14 p"

mtheorem margrel1_def_19:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
"redefine func 'not'MARGREL1K16\<^bsub>(A)\<^esub> p \<rightarrow> FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) holds it =HIDDENR1 'not'MARGREL1K16\<^bsub>(A)\<^esub> p iff ( for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)"
  proof-
    have " for IT be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) holds (IT =RELAT-1R1 'not'MARGREL1K14 p implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)) & (( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x) implies IT =HIDDENR1 'not'MARGREL1K14 p)"
    proof(rule ballI,rule conjMI,rule impI)
      fix IT assume [ty]: "IT be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
      have A2: "domRELAT-1K1 IT =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      show "IT =RELAT-1R1 'not'MARGREL1K14 p implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)"
      proof(rule impI,rule ballI)
        assume A3: "IT =RELAT-1R1 'not'MARGREL1K14 p"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
        have "x inTARSKIR2 A"
           sorry
        then have "x inTARSKIR2 domRELAT-1K1 p"
          using funct_2_def_1 sorry
        thus "IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
          using A3 margrel1_def_17 sorry
      qed "sorry"
      have A4: "domRELAT-1K1 p =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      assume " for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 'not'MARGREL1K10 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 p implies IT .FUNCT-1K1 x =HIDDENR1 'not'MARGREL1K8 p .FUNCT-1K1 x"
        using A4 sorry
      thus "IT =HIDDENR1 'not'MARGREL1K14 p"
        using A2 A4 margrel1_def_17 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_add_6:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
"cluster 'not'MARGREL1K14 p as-term-is FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
proof
(*coherence*)
  show "'not'MARGREL1K14 p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
  proof-
    have A1: "domRELAT-1K1 ('not'MARGREL1K14 p) =HIDDENR1 domRELAT-1K1 p"
      using margrel1_def_17 sorry
    also have "... = A"
      using partfun1_def_2 sorry
    finally have "domRELAT-1K1 ('not'MARGREL1K14 p) =HIDDENR1 A"
       sorry
    have "rngRELAT-1K2 ('not'MARGREL1K14 p) c=TARSKIR1 BOOLEANMARGREL1K5"
      using margrel1_def_16 sorry
    thus "'not'MARGREL1K14 p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
      using A1 funct_2_th_2 sorry
  qed
qed "sorry"

syntax MARGREL1K17 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ ''&''MARGREL1K17\<^bsub>'( _ ')\<^esub>  _ " [180,0,180]180)
translations "p '&'MARGREL1K17\<^bsub>(A)\<^esub> q" \<rightharpoonup> "p '&'MARGREL1K15 q"

mtheorem margrel1_def_20:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)", "q be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
"redefine func p '&'MARGREL1K17\<^bsub>(A)\<^esub> q \<rightarrow> FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) means
  \<lambda>it.  for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
proof
(*compatibility*)
  show " for it be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) holds it =HIDDENR1 p '&'MARGREL1K17\<^bsub>(A)\<^esub> q iff ( for x be ElementSUBSET-1M1-of A holds it .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)"
  proof-
    have " for IT be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5) holds (IT =RELAT-1R1 p '&'MARGREL1K15 q implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)) & (( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x) implies IT =HIDDENR1 p '&'MARGREL1K15 q)"
    proof(rule ballI,rule conjMI,rule impI)
      fix IT assume [ty]: "IT be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
      have A6: "domRELAT-1K1 IT =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      show "IT =RELAT-1R1 p '&'MARGREL1K15 q implies ( for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x)"
      proof(rule impI,rule ballI)
        assume A7: "IT =RELAT-1R1 p '&'MARGREL1K15 q"
        fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
        have A8: "domRELAT-1K1 q =XBOOLE-0R4 A"
          using funct_2_def_1 sorry
        have "domRELAT-1K1 p =XBOOLE-0R4 A"
          using funct_2_def_1 sorry
        then have "domRELAT-1K1 (p '&'MARGREL1K15 q) =HIDDENR1 A /\\XBOOLE-0K3 A"
          using A8 margrel1_def_18 sorry
        also have "... = A"
           sorry
        finally have "domRELAT-1K1 (p '&'MARGREL1K15 q) =HIDDENR1 A"
           sorry
        thus "IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
          using A7 margrel1_def_18 sorry
      qed "sorry"
      have A9: "domRELAT-1K1 q =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      have A10: "domRELAT-1K1 IT =HIDDENR1 A /\\XBOOLE-0K3 A"
        using funct_2_def_1 sorry
      also have "... = domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q"
        using A9 funct_2_def_1 sorry
      finally have "domRELAT-1K1 IT =HIDDENR1 domRELAT-1K1 p /\\XBOOLE-0K3 domRELAT-1K1 q"
         sorry
      assume " for x be ElementSUBSET-1M1-of A holds IT .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x =XBOOLE-0R4 p .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x '&'MARGREL1K11 q .FUNCT-2K3\<^bsub>(A,BOOLEANMARGREL1K5)\<^esub> x"
      then have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 IT implies IT .FUNCT-1K1 x =HIDDENR1 p .FUNCT-1K1 x '&'MARGREL1K9 q .FUNCT-1K1 x"
        using A6 sorry
      thus "IT =HIDDENR1 p '&'MARGREL1K15 q"
        using A10 margrel1_def_18 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_add_7:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)", "q be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
"cluster p '&'MARGREL1K15 q as-term-is FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
proof
(*coherence*)
  show "p '&'MARGREL1K15 q be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
  proof-
    have A5: "rngRELAT-1K2 (p '&'MARGREL1K15 q) c=TARSKIR1 BOOLEANMARGREL1K5"
      using margrel1_def_16 sorry
    have "domRELAT-1K1 p =XBOOLE-0R4 A & domRELAT-1K1 q =XBOOLE-0R4 A"
      using partfun1_def_2 sorry
    then have "domRELAT-1K1 (p '&'MARGREL1K15 q) =HIDDENR1 A /\\XBOOLE-0K3 A"
      using margrel1_def_18 sorry
    also have "... = A"
       sorry
    finally have "domRELAT-1K1 (p '&'MARGREL1K15 q) =HIDDENR1 A"
       sorry
    thus "p '&'MARGREL1K15 q be FunctionFUNCT-2M1-of(A,BOOLEANMARGREL1K5)"
      using A5 funct_2_th_2 sorry
  qed
qed "sorry"

(*begin*)
reserve A, z for "setHIDDENM2"
reserve x, y for "FinSequenceFINSEQ-1M3-of A"
reserve h for "PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
reserve n, m for "NatNAT-1M1"
mdef margrel1_def_21 ("homogeneousMARGREL1V4" 70 ) where
"attr homogeneousMARGREL1V4 for RelationRELAT-1M1 means
  (\<lambda>IT. domRELAT-1K1 IT be with-common-domainCARD-3V2)"..

mdef margrel1_def_22 ("quasi-totalMARGREL1V5\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr quasi-totalMARGREL1V5\<^bsub>(A)\<^esub> for PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) means
  (\<lambda>IT.  for x be FinSequenceFINSEQ-1M3-of A holds  for y be FinSequenceFINSEQ-1M3-of A holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & x inTARSKIR2 domRELAT-1K1 IT implies y inTARSKIR2 domRELAT-1K1 IT)"..

mtheorem margrel1_cl_10:
  mlet "f be RelationRELAT-1M1", "X be with-common-domainCARD-3V2\<bar>setHIDDENM2"
"cluster f  |RELAT-1K8 X as-term-is homogeneousMARGREL1V4"
proof
(*coherence*)
  show "f  |RELAT-1K8 X be homogeneousMARGREL1V4"
  proof-
    have Cut912: "domRELAT-1K1 (f  |RELAT-1K8 X) c=TARSKIR1 X"
      using relat_1_th_58 sorry
    have "domRELAT-1K1 (f  |RELAT-1K8 X) be with-common-domainCARD-3V2"
    proof-
      show "domRELAT-1K1 (f  |RELAT-1K8 X) be with-common-domainCARD-3V2"
        using Cut912 sorry
    qed
    thus "f  |RELAT-1K8 X be homogeneousMARGREL1V4"
      using margrel1_def_21 sorry
  qed
qed "sorry"

mtheorem margrel1_cl_11:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
"cluster domRELAT-1K1 f as-term-is FinSequence-memberedFINSEQ-1V3"
proof
(*coherence*)
  show "domRELAT-1K1 f be FinSequence-memberedFINSEQ-1V3"
  proof-
    have "domRELAT-1K1 f c=TARSKIR1 A * FINSEQ-2K3"
      using relat_1_def_18 sorry
    thus "domRELAT-1K1 f be FinSequence-memberedFINSEQ-1V3"
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_12:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>\<bar> non emptyXBOOLE-0V1 for PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
proof
(*existence*)
  show " ex it be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) st it be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>\<bar> non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds  not ((VarFor1 be homogeneousMARGREL1V4 & VarFor1 be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>) &  not VarFor1 be emptyXBOOLE-0V1))"
    proof-
      let ?a = "the ElementSUBSET-1M1-of A"
      let ?f = "<*>FINSEQ-1K7 A .-->FUNCOP-1K17 ?a"
      have A1: "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK1 <*>FINSEQ-1K7 A }"
        using funcop_1_th_13 sorry
      have A2: "domRELAT-1K1 ?f c=TARSKIR1 A * FINSEQ-2K3"
      proof-
        have "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) c=TARSKIR1 A * FINSEQ-2K3"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) implies z inHIDDENR3 A * FINSEQ-2K3"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 domRELAT-1K1 ?f"
            then have "z =HIDDENR1 <*>FINSEQ-1K7 A"
              using A1 tarski_def_1 sorry
            thus "z inHIDDENR3 A * FINSEQ-2K3"
              using finseq_1_def_11 sorry
          qed "sorry"
          thus "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) c=TARSKIR1 A * FINSEQ-2K3"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have A3: "rngRELAT-1K2 ?f =XBOOLE-0R4 {TARSKIK1 ?a}"
        using funcop_1_th_8 sorry
      have "rngRELAT-1K2 ?f c=TARSKIR1 A"
      proof-
        have "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) c=TARSKIR1 A"
        proof-
          have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) implies z inHIDDENR3 A"
          proof(rule ballI,rule impI)
            fix z assume [ty]: "z be objectHIDDENM1"
            assume "z inHIDDENR3 rngRELAT-1K2 ?f"
            then have "z =HIDDENR1 ?a"
              using A3 tarski_def_1 sorry
            thus "z inHIDDENR3 A"
               sorry
          qed "sorry"
          thus "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 (the ElementSUBSET-1M1-of A)) c=TARSKIR1 A"
            using tarski_def_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      then obtain f where 
        [ty]:"f be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)" and fDef:"f = ?f"
        using A2 relset_1_th_4 sorry
      have A4: "f be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
      proof-
        have " for x be FinSequenceFINSEQ-1M3-of A holds  for y be FinSequenceFINSEQ-1M3-of A holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & x inTARSKIR2 domRELAT-1K1 f implies y inTARSKIR2 domRELAT-1K1 f"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be FinSequenceFINSEQ-1M3-of A"
          fix y assume [ty]: "y be FinSequenceFINSEQ-1M3-of A"
          assume A5: "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
            and A6: "x inTARSKIR2 domRELAT-1K1 f"
          have "x =FINSEQ-1R1 <*>FINSEQ-1K7 A"
            using A1 A6 tarski_def_1 sorry
          then have "lenFINSEQ-1K4 x =XBOOLE-0R4 0NUMBERSK6"
             sorry
          then have "y =FINSEQ-1R1 <*>FINSEQ-1K7 A"
            using A5 sorry
          thus "y inTARSKIR2 domRELAT-1K1 f"
            using A1 tarski_def_1 sorry
        qed "sorry"
        thus "f be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
          using margrel1_def_22 sorry
      qed
      have "f be homogeneousMARGREL1V4"
        using A1 sorry
      thus " not ( for VarFor1 be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds  not ((VarFor1 be homogeneousMARGREL1V4 & VarFor1 be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>) &  not VarFor1 be emptyXBOOLE-0V1))"
        using A4 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_13:
"cluster homogeneousMARGREL1V4\<bar> non emptyXBOOLE-0V1 for FunctionFUNCT-1M1"
proof
(*existence*)
  show " ex it be FunctionFUNCT-1M1 st it be homogeneousMARGREL1V4\<bar> non emptyXBOOLE-0V1"
  proof-
    have " ex tVar8 be FunctionFUNCT-1M1 st the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be homogeneousMARGREL1V4 &  not the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be emptyXBOOLE-0V1"
    proof-
      let ?f = "the homogeneousMARGREL1V4\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 })"
      show " ex tVar8 be FunctionFUNCT-1M1 st the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be homogeneousMARGREL1V4 &  not the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be emptyXBOOLE-0V1"
      proof(rule bexI[of _ "?f"])
        show "the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be homogeneousMARGREL1V4 &  not the  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>PartFuncPARTFUN1M1-of({TARSKIK1 {}XBOOLE-0K1 } * FINSEQ-2K3,{TARSKIK1 {}XBOOLE-0K1 }) be emptyXBOOLE-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_14:
  mlet "R be homogeneousMARGREL1V4\<bar>RelationRELAT-1M1"
"cluster domRELAT-1K1 R as-term-is with-common-domainCARD-3V2"
proof
(*coherence*)
  show "domRELAT-1K1 R be with-common-domainCARD-3V2"
    using margrel1_def_21 sorry
qed "sorry"

mtheorem margrel1_th_18:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of A holds <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of A holds <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a be  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>\<bar>PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
  proof(rule ballI,rule ballI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
    let ?f = "<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a"
    have A1: "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK1 <*>FINSEQ-1K7 A }"
      using funcop_1_th_13 sorry
    have A2: "domRELAT-1K1 ?f c=TARSKIR1 A * FINSEQ-2K3"
    proof-
      have "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A * FINSEQ-2K3"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) implies z inHIDDENR3 A * FINSEQ-2K3"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 domRELAT-1K1 ?f"
          then have "z =HIDDENR1 <*>FINSEQ-1K7 A"
            using A1 tarski_def_1 sorry
          thus "z inHIDDENR3 A * FINSEQ-2K3"
            using finseq_1_def_11 sorry
        qed "sorry"
        thus "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A * FINSEQ-2K3"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A3: "rngRELAT-1K2 ?f =XBOOLE-0R4 {TARSKIK1 a}"
      using funcop_1_th_8 sorry
    have "rngRELAT-1K2 ?f c=TARSKIR1 A"
    proof-
      have "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A"
      proof-
        have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) implies z inHIDDENR3 A"
        proof(rule ballI,rule impI)
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "z inHIDDENR3 rngRELAT-1K2 ?f"
          then have "z =HIDDENR1 a"
            using A3 tarski_def_1 sorry
          thus "z inHIDDENR3 A"
             sorry
        qed "sorry"
        thus "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then obtain f where 
      [ty]:"f be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)" and fDef:"f = ?f"
      using A2 relset_1_th_4 sorry
    have A4: "f be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
    proof-
      have " for x be FinSequenceFINSEQ-1M3-of A holds  for y be FinSequenceFINSEQ-1M3-of A holds lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y & x inTARSKIR2 domRELAT-1K1 f implies y inTARSKIR2 domRELAT-1K1 f"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix x assume [ty]: "x be FinSequenceFINSEQ-1M3-of A"
        fix y assume [ty]: "y be FinSequenceFINSEQ-1M3-of A"
        assume A5: "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
          and A6: "x inTARSKIR2 domRELAT-1K1 f"
        have "x =FINSEQ-1R1 <*>FINSEQ-1K7 A"
          using A1 A6 tarski_def_1 sorry
        then have "lenFINSEQ-1K4 x =XBOOLE-0R4 0NUMBERSK6"
           sorry
        then have "y =FINSEQ-1R1 <*>FINSEQ-1K7 A"
          using A5 sorry
        thus "y inTARSKIR2 domRELAT-1K1 f"
          using A1 tarski_def_1 sorry
      qed "sorry"
      thus "f be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
        using margrel1_def_22 sorry
    qed
    have "f be homogeneousMARGREL1V4"
      using A1 sorry
    thus "<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a be  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>\<bar>PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem margrel1_th_19:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of A holds <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
proof(rule ballI,rule ballI)
  fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
  let ?f = "<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a"
  have A1: "domRELAT-1K1 ?f =XBOOLE-0R4 {TARSKIK1 <*>FINSEQ-1K7 A }"
    using funcop_1_th_13 sorry
  have A2: "domRELAT-1K1 ?f c=TARSKIR1 A * FINSEQ-2K3"
  proof-
    have "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A * FINSEQ-2K3"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) implies z inHIDDENR3 A * FINSEQ-2K3"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 domRELAT-1K1 ?f"
        then have "z =HIDDENR1 <*>FINSEQ-1K7 A"
          using A1 tarski_def_1 sorry
        thus "z inHIDDENR3 A * FINSEQ-2K3"
          using finseq_1_def_11 sorry
      qed "sorry"
      thus "domRELAT-1K1 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A * FINSEQ-2K3"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have A3: "rngRELAT-1K2 ?f =XBOOLE-0R4 {TARSKIK1 a}"
    using funcop_1_th_8 sorry
  have "rngRELAT-1K2 ?f c=TARSKIR1 A"
  proof-
    have "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A"
    proof-
      have " for z be objectHIDDENM1 holds z inHIDDENR3 rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) implies z inHIDDENR3 A"
      proof(rule ballI,rule impI)
        fix z assume [ty]: "z be objectHIDDENM1"
        assume "z inHIDDENR3 rngRELAT-1K2 ?f"
        then have "z =HIDDENR1 a"
          using A3 tarski_def_1 sorry
        thus "z inHIDDENR3 A"
           sorry
      qed "sorry"
      thus "rngRELAT-1K2 (<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a) c=TARSKIR1 A"
        using tarski_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
  then obtain f where 
    [ty]:"f be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)" and fDef:"f = ?f"
    using A2 relset_1_th_4 sorry
  have "f inTARSKIR2 PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
    using partfun1_th_45 sorry
  thus "<*>FINSEQ-1K7 A .-->FUNCOP-1K17 a be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
     sorry
qed "sorry"

abbreviation(input) MARGREL1M6("PFuncFinSequenceMARGREL1M6-of  _ " [70]70) where
  "PFuncFinSequenceMARGREL1M6-of A \<equiv> FinSequenceFINSEQ-1M3-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"

mdef margrel1_def_23 ("homogeneousMARGREL1V6\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr homogeneousMARGREL1V6\<^bsub>(A)\<^esub> for PFuncFinSequenceMARGREL1M6-of A means
  (\<lambda>IT.  for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 IT & h =RELAT-1R1 IT .FUNCT-1K1 n implies h be homogeneousMARGREL1V4)"..

mdef margrel1_def_24 ("quasi-totalMARGREL1V7\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr quasi-totalMARGREL1V7\<^bsub>(A)\<^esub> for PFuncFinSequenceMARGREL1M6-of A means
  (\<lambda>IT.  for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 IT & h =RELAT-1R1 IT .FUNCT-1K1 n implies h be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>)"..

syntax MARGREL1K18 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("<*MARGREL1K18\<^bsub>'( _ ')\<^esub>  _ *>" [0,0]164)
translations "<*MARGREL1K18\<^bsub>(A)\<^esub> x*>" \<rightharpoonup> "<*FINSEQ-1K6 x*>"

mtheorem margrel1_add_8:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
"cluster <*FINSEQ-1K6 x*> as-term-is PFuncFinSequenceMARGREL1M6-of A"
proof
(*coherence*)
  show "<*FINSEQ-1K6 x*> be PFuncFinSequenceMARGREL1M6-of A"
  proof-
    have "<*FINSEQ-1K13\<^bsub>(PFuncsPARTFUN1K4(A * FINSEQ-2K3,A))\<^esub> x*> be FinSequenceFINSEQ-1M3-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
       sorry
    thus "<*FINSEQ-1K6 x*> be PFuncFinSequenceMARGREL1M6-of A"
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_15:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster homogeneousMARGREL1V6\<^bsub>(A)\<^esub>\<bar>quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>\<bar>non-emptyRELAT-1V2 for PFuncFinSequenceMARGREL1M6-of A"
proof
(*existence*)
  show " ex it be PFuncFinSequenceMARGREL1M6-of A st it be homogeneousMARGREL1V6\<^bsub>(A)\<^esub>\<bar>quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>\<bar>non-emptyRELAT-1V2"
  proof-
    have " ex tVar9 be PFuncFinSequenceMARGREL1M6-of A st tVar9 be homogeneousMARGREL1V6\<^bsub>(A)\<^esub> & (tVar9 be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub> & tVar9 be non-emptyRELAT-1V2)"
    proof-
      let ?a = "the ElementSUBSET-1M1-of A"
      obtain f where 
        [ty]:"f be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)" and fDef:"f = <*>FINSEQ-1K7 A .-->FUNCOP-1K17 ?a"
        using margrel1_th_18 sorry
      have 
        [ty]:"f be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
        using partfun1_th_45 sorry
      show " ex tVar9 be PFuncFinSequenceMARGREL1M6-of A st tVar9 be homogeneousMARGREL1V6\<^bsub>(A)\<^esub> & (tVar9 be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub> & tVar9 be non-emptyRELAT-1V2)"
      proof(rule bexI[of _ "<*MARGREL1K18\<^bsub>(A)\<^esub> f*>"],rule conjMI,rule conjMI)
        show "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be homogeneousMARGREL1V6\<^bsub>(A)\<^esub>"
        proof-
          have " for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>) & h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n implies h be homogeneousMARGREL1V4"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
            assume A1: "n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>)"
              and A2: "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n"
            have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
              using A1 finseq_1_th_2 finseq_1_def_8 sorry
            then have "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 \<one>\<^sub>M"
              using A2 tarski_def_1 sorry
            then have "h =RELAT-1R1 f"
              using finseq_1_def_8 sorry
            thus "h be homogeneousMARGREL1V4"
              using margrel1_th_18 sorry
          qed "sorry"
          thus "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be homogeneousMARGREL1V6\<^bsub>(A)\<^esub>"
            using margrel1_def_23 sorry
        qed
        show "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>"
        proof-
          have " for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>) & h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n implies h be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
          proof(rule ballI,rule ballI,rule impMI ,rule impI)
            fix n assume [ty]: "n be NatNAT-1M1"
            fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
            assume A3: "n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>)"
              and A4: "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n"
            have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
              using A3 finseq_1_th_2 finseq_1_def_8 sorry
            then have "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 \<one>\<^sub>M"
              using A4 tarski_def_1 sorry
            then have "h =RELAT-1R1 f"
              using finseq_1_def_8 sorry
            thus "h be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
              using margrel1_th_18 sorry
          qed "sorry"
          thus "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>"
            using margrel1_def_24 sorry
        qed
        show "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be non-emptyRELAT-1V2"
        proof-
          have " for n be objectHIDDENM1 holds n inHIDDENR3 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>) implies  not (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n be emptyXBOOLE-0V1"
          proof(rule ballI,rule impI)
            fix n assume [ty]: "n be objectHIDDENM1"
            assume A5: "n inHIDDENR3 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>)"
            then have 
              [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
               sorry
            have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
              using A5 finseq_1_th_2 finseq_1_def_8 sorry
            then have "n =XBOOLE-0R4 \<one>\<^sub>M"
              using tarski_def_1 sorry
            thus " not (<*MARGREL1K18\<^bsub>(A)\<^esub> f*>).FUNCT-1K1 n be emptyXBOOLE-0V1"
              using finseq_1_def_8 sorry
          qed "sorry"
          thus "<*MARGREL1K18\<^bsub>(A)\<^esub> f*> be non-emptyRELAT-1V2"
            using funct_1_def_9 sorry
        qed
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem margrel1_cl_16:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be homogeneousMARGREL1V6\<^bsub>(A)\<^esub>\<bar>PFuncFinSequenceMARGREL1M6-of A", "i be setHIDDENM2"
"cluster f .FUNCT-1K1 i as-term-is homogeneousMARGREL1V4"
proof
(*coherence*)
  show "f .FUNCT-1K1 i be homogeneousMARGREL1V4"
  proof-
    show "f .FUNCT-1K1 i be homogeneousMARGREL1V4"
    proof-
      have cases: "i inTARSKIR2 domFINSEQ-1K5 f or  not i inTARSKIR2 domFINSEQ-1K5 f"
         sorry
      have case1: "i inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 i be homogeneousMARGREL1V4"
      proof(rule impI)
        assume A1: "i inTARSKIR2 domFINSEQ-1K5 f"
        have A2: "rngRELAT-1K2 f c=TARSKIR1 PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
          using relat_1_def_19 sorry
        have "f .FUNCT-1K1 i inTARSKIR2 rngRELAT-1K2 f"
          using A1 funct_1_th_3 sorry
        then have "f .FUNCT-1K1 i be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
          using A2 partfun1_th_46 sorry
        thus "f .FUNCT-1K1 i be homogeneousMARGREL1V4"
          using A1 margrel1_def_23 sorry
      qed
      have case2: " not i inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 i be homogeneousMARGREL1V4"
      proof(rule impI)
        assume A3: " not i inTARSKIR2 domFINSEQ-1K5 f"
        have " for x be FunctionFUNCT-1M1 holds  for VarFor1 be setHIDDENM2 holds  not ((x inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 i) & VarFor1 inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 i)) &  not domRELAT-1K1 x =HIDDENR1 domRELAT-1K1 VarFor1)"
        proof(rule ballI)
          fix x assume [ty]: "x be FunctionFUNCT-1M1"
          show " for VarFor1 be setHIDDENM2 holds  not ((x inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 i) & VarFor1 inTARSKIR2 domRELAT-1K1 (f .FUNCT-1K1 i)) &  not domRELAT-1K1 x =HIDDENR1 domRELAT-1K1 VarFor1)"
            using A3 funct_1_def_2 relat_1_th_38 sorry
        qed "sorry"
        thus "f .FUNCT-1K1 i be homogeneousMARGREL1V4"
          using card_3_def_10 margrel1_def_21 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

reserve A for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve h for "PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
reserve a for "ElementSUBSET-1M1-of A"
mtheorem margrel1_th_20:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of A holds  for x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A) holds x =RELAT-1R1 <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a implies <*MARGREL1K18\<^bsub>(A)\<^esub> x*> be homogeneousMARGREL1V6\<^bsub>(A)\<^esub>\<bar>quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>\<bar>non-emptyRELAT-1V2"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for a be ElementSUBSET-1M1-of A holds  for x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A) holds x =RELAT-1R1 <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a implies (<*MARGREL1K18\<^bsub>(A)\<^esub> x*> be homogeneousMARGREL1V6\<^bsub>(A)\<^esub> & <*MARGREL1K18\<^bsub>(A)\<^esub> x*> be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>) & <*MARGREL1K18\<^bsub>(A)\<^esub> x*> be non-emptyRELAT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of PFuncsPARTFUN1K4(A * FINSEQ-2K3,A)"
    assume A1: "x =RELAT-1R1 <*>FINSEQ-1K7 A .-->FUNCOP-1K17 a"
    have A2: " for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>) & h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n implies h be homogeneousMARGREL1V4"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
      assume A3: "n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>)"
        and A4: "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n"
      have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
        using A3 finseq_1_th_2 finseq_1_def_8 sorry
      then have "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 \<one>\<^sub>M"
        using A4 tarski_def_1 sorry
      then have "h =RELAT-1R1 x"
        using finseq_1_def_8 sorry
      thus "h be homogeneousMARGREL1V4"
        using A1 margrel1_th_18 sorry
    qed "sorry"
    have A5: " for n be NatNAT-1M1 holds  for h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A) holds n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>) & h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n implies h be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      fix h assume [ty]: "h be PartFuncPARTFUN1M1-of(A * FINSEQ-2K3,A)"
      assume A6: "n inTARSKIR2 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>)"
        and A7: "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n"
      have "n inTARSKIR2 {TARSKIK1 \<one>\<^sub>M}"
        using A6 finseq_1_th_2 finseq_1_def_8 sorry
      then have "h =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 \<one>\<^sub>M"
        using A7 tarski_def_1 sorry
      then have "h =RELAT-1R1 x"
        using finseq_1_def_8 sorry
      thus "h be quasi-totalMARGREL1V5\<^bsub>(A)\<^esub>"
        using A1 margrel1_th_18 sorry
    qed "sorry"
    have " for n be objectHIDDENM1 holds n inHIDDENR3 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>) implies (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n be  non emptyXBOOLE-0V1"
    proof-
      have " for n be objectHIDDENM1 holds n inHIDDENR3 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>) implies  not (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n be emptyXBOOLE-0V1"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be objectHIDDENM1"
        assume "n inHIDDENR3 domFINSEQ-1K5 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>)"
        then have "n inHIDDENR3 {TARSKIK1 \<one>\<^sub>M}"
          using finseq_1_th_2 finseq_1_def_8 sorry
        then have "(<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n =RELAT-1R1 (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 \<one>\<^sub>M"
          using tarski_def_1 sorry
        thus " not (<*MARGREL1K18\<^bsub>(A)\<^esub> x*>).FUNCT-1K1 n be emptyXBOOLE-0V1"
          using A1 finseq_1_def_8 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(<*MARGREL1K18\<^bsub>(A)\<^esub> x*> be homogeneousMARGREL1V6\<^bsub>(A)\<^esub> & <*MARGREL1K18\<^bsub>(A)\<^esub> x*> be quasi-totalMARGREL1V7\<^bsub>(A)\<^esub>) & <*MARGREL1K18\<^bsub>(A)\<^esub> x*> be non-emptyRELAT-1V2"
      using A2 A5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef margrel1_def_25 ("arityMARGREL1K19  _ " [228]228 ) where
  mlet "f be homogeneousMARGREL1V4\<bar>RelationRELAT-1M1"
"func arityMARGREL1K19 f \<rightarrow> NatNAT-1M1 means
  \<lambda>it.  for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies it =XBOOLE-0R4 lenFINSEQ-1K4 x if  ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f otherwise \<lambda>it. it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be NatNAT-1M1 holds  True "
       sorry
  (*existence*)
    show "(( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies ( ex it be NatNAT-1M1 st  for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies it =XBOOLE-0R4 lenFINSEQ-1K4 x)) & ( not ( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies ( ex it be NatNAT-1M1 st it =XBOOLE-0R4 0NUMBERSK6))"
    proof-
      have "(( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies ( ex n be NatNAT-1M1 st  for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies n =XBOOLE-0R4 lenFINSEQ-1K4 x)) &  not (( for x be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 domRELAT-1K1 f) & ( for VarFor1 be NatNAT-1M1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
      proof(rule conjMI)
        show "( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies ( ex n be NatNAT-1M1 st  for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies n =XBOOLE-0R4 lenFINSEQ-1K4 x)"
        proof-
          have "( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies ( ex tVar10 be NatNAT-1M1 st  for y be FinSequenceFINSEQ-1M1 holds y inTARSKIR2 domRELAT-1K1 f implies tVar10 =XBOOLE-0R4 lenFINSEQ-1K4 y)"
          proof(rule impI)
            assume Given: " ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f"
            then obtain x where
              [ty]:"x be FinSequenceFINSEQ-1M1" and 
              A1: "x inTARSKIR2 domRELAT-1K1 f"
               sorry
            show " ex tVar10 be NatNAT-1M1 st  for y be FinSequenceFINSEQ-1M1 holds y inTARSKIR2 domRELAT-1K1 f implies tVar10 =XBOOLE-0R4 lenFINSEQ-1K4 y"
            proof(rule bexI[of _ "lenFINSEQ-1K4 x"],rule ballI,rule impI)
              fix y assume [ty]: "y be FinSequenceFINSEQ-1M1"
              assume "y inTARSKIR2 domRELAT-1K1 f"
              then have "domFINSEQ-1K5 x =XBOOLE-0R4 domFINSEQ-1K5 y"
                using A1 card_3_def_10 sorry
              thus "lenFINSEQ-1K4 x =XBOOLE-0R4 lenFINSEQ-1K4 y"
                using finseq_3_th_29 sorry
            qed "sorry"
          qed
          thus " ?thesis "
             sorry
        qed
        show " not (( for x be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 domRELAT-1K1 f) & ( for VarFor1 be NatNAT-1M1 holds  not VarFor1 =XBOOLE-0R4 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be NatNAT-1M1 holds  for it2 be NatNAT-1M1 holds (( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies (( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies it1 =XBOOLE-0R4 lenFINSEQ-1K4 x) & ( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies it2 =XBOOLE-0R4 lenFINSEQ-1K4 x) implies it1 =HIDDENR1 it2)) & ( not ( ex x be FinSequenceFINSEQ-1M1 st x inTARSKIR2 domRELAT-1K1 f) implies (it1 =XBOOLE-0R4 0NUMBERSK6 & it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have " for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds (( ex x0 be FinSequenceFINSEQ-1M1 st x0 inTARSKIR2 domRELAT-1K1 f) implies (( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies n =XBOOLE-0R4 lenFINSEQ-1K4 x) & ( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies m =XBOOLE-0R4 lenFINSEQ-1K4 x) implies n =XBOOLE-0R4 m)) &  not (((( for x be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 domRELAT-1K1 f) & n =XBOOLE-0R4 0NUMBERSK6) & m =XBOOLE-0R4 0NUMBERSK6) &  not n =HIDDENR1 m)"
      proof(rule ballI,rule ballI,rule conjMI)
        fix n assume [ty]: "n be NatNAT-1M1"
        fix m assume [ty]: "m be NatNAT-1M1"
        show "( ex x0 be FinSequenceFINSEQ-1M1 st x0 inTARSKIR2 domRELAT-1K1 f) implies (( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies n =XBOOLE-0R4 lenFINSEQ-1K4 x) & ( for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies m =XBOOLE-0R4 lenFINSEQ-1K4 x) implies n =XBOOLE-0R4 m)"
        proof(rule impI,rule impMI ,rule impI)
          assume Given: " ex x0 be FinSequenceFINSEQ-1M1 st x0 inTARSKIR2 domRELAT-1K1 f"
          then obtain x0 where
            [ty]:"x0 be FinSequenceFINSEQ-1M1" and 
            A2: "x0 inTARSKIR2 domRELAT-1K1 f"
             sorry
          assume A3: " for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies n =XBOOLE-0R4 lenFINSEQ-1K4 x"
            and A4: " for x be FinSequenceFINSEQ-1M1 holds x inTARSKIR2 domRELAT-1K1 f implies m =XBOOLE-0R4 lenFINSEQ-1K4 x"
          have "n =XBOOLE-0R4 lenFINSEQ-1K4 x0"
            using A2 A3 sorry
          thus "n =XBOOLE-0R4 m"
            using A2 A4 sorry
        qed
        show " not (((( for x be FinSequenceFINSEQ-1M1 holds  not x inTARSKIR2 domRELAT-1K1 f) & n =XBOOLE-0R4 0NUMBERSK6) & m =XBOOLE-0R4 0NUMBERSK6) &  not n =HIDDENR1 m)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

abbreviation(input) MARGREL1K20("arityMARGREL1K20  _ " [228]228) where
  "arityMARGREL1K20 f \<equiv> arityMARGREL1K19 f"

mtheorem margrel1_add_9:
  mlet "f be homogeneousMARGREL1V4\<bar>FunctionFUNCT-1M1"
"cluster arityMARGREL1K19 f as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "arityMARGREL1K19 f be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

(*begin*)
mtheorem margrel1_th_21:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for D1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of D holds n -tuples-onFINSEQ-2K4 D /\\XBOOLE-0K3 n -tuples-onFINSEQ-2K4 D1 =XBOOLE-0R4 n -tuples-onFINSEQ-2K4 D1"
proof(rule ballI,rule ballI,rule ballI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix D1 assume [ty]: "D1 be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of D"
  have "n -tuples-onFINSEQ-2K4 D1 c=TARSKIR1 n -tuples-onFINSEQ-2K4 D"
  proof-
    have " for z be objectHIDDENM1 holds z inHIDDENR3 n -tuples-onFINSEQ-2K4 D1 implies z inHIDDENR3 n -tuples-onFINSEQ-2K4 D"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume "z inHIDDENR3 n -tuples-onFINSEQ-2K4 D1"
      then have "z be TupleFINSEQ-2M3-of(n,D1)"
        using finseq_2_th_131 sorry
      then have "z be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of n -tuples-onFINSEQ-2K4 D"
        using finseq_2_th_109 sorry
      thus "z inHIDDENR3 n -tuples-onFINSEQ-2K4 D"
         sorry
    qed "sorry"
    thus "n -tuples-onFINSEQ-2K4 D1 c=TARSKIR1 n -tuples-onFINSEQ-2K4 D"
      using tarski_def_3 sorry
  qed
  thus "n -tuples-onFINSEQ-2K4 D /\\XBOOLE-0K3 n -tuples-onFINSEQ-2K4 D1 =XBOOLE-0R4 n -tuples-onFINSEQ-2K4 D1"
    using xboole_1_th_28 sorry
qed "sorry"

mtheorem margrel1_th_22:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for h be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D) holds domRELAT-1K1 h =XBOOLE-0R4 (arityMARGREL1K20 h)-tuples-onFINSEQ-2K4 D"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D) holds domRELAT-1K1 f =XBOOLE-0R4 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
    let ?y = "the ElementSUBSET-1M1-of domRELAT-1K1 f"
    have A1: "domRELAT-1K1 f c=TARSKIR1 D * FINSEQ-2K3"
      using relat_1_def_18 sorry
    then have A2: "?y inTARSKIR2 D * FINSEQ-2K3"
       sorry
    have "domRELAT-1K1 f c=TARSKIR1 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D & (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D c=TARSKIR1 domRELAT-1K1 f"
    proof(rule conjMI)
      show "domRELAT-1K1 f c=TARSKIR1 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies x inHIDDENR3 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume A3: "x inHIDDENR3 domRELAT-1K1 f"
          then obtain x9 where 
            [ty]:"x9 be FinSequenceFINSEQ-1M3-of D" and x9Def:"x9 = x"
            using A1 finseq_1_def_11 sorry
          have "lenFINSEQ-1K4 x9 =XBOOLE-0R4 arityMARGREL1K20 f"
            using A3 margrel1_def_25 sorry
          then have "x9 be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
            using finseq_2_th_92 sorry
          thus "x inHIDDENR3 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
             sorry
        qed "sorry"
        thus "domRELAT-1K1 f c=TARSKIR1 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
          using tarski_def_3 sorry
      qed
      obtain y where 
        [ty]:"y be FinSequenceFINSEQ-1M3-of D" and yDef:"y = ?y"
        using A2 finseq_1_def_11 sorry
      have " for x be objectHIDDENM1 holds x inHIDDENR3 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D implies x inHIDDENR3 domRELAT-1K1 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
        then have "x inHIDDENR3 {s where s be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of D * FINSEQ-2K3 : lenFINSEQ-1K4 s =XBOOLE-0R4 arityMARGREL1K20 f }"
          using finseq_2_def_4 sorry
        then have A4: " ex s be ElementFINSEQ-2M2\<^bsub>(D)\<^esub>-of D * FINSEQ-2K3 st x =HIDDENR1 s & lenFINSEQ-1K4 s =XBOOLE-0R4 arityMARGREL1K20 f"
           sorry
        have "lenFINSEQ-1K4 y =XBOOLE-0R4 arityMARGREL1K20 f"
          using margrel1_def_25 sorry
        thus "x inHIDDENR3 domRELAT-1K1 f"
          using A4 margrel1_def_22 sorry
      qed "sorry"
      thus "(arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D c=TARSKIR1 domRELAT-1K1 f"
        using tarski_def_3 sorry
    qed
    thus "domRELAT-1K1 f =XBOOLE-0R4 (arityMARGREL1K20 f)-tuples-onFINSEQ-2K4 D"
      using xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef margrel1_def_26 ("PFuncsDomHQNMARGREL1M7-of  _ " [70]70 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"mode PFuncsDomHQNMARGREL1M7-of D \<rightarrow>  non emptyXBOOLE-0V1\<bar>setHIDDENM2 means
  (\<lambda>it.  for x be ElementSUBSET-1M1-of it holds x be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D))"
proof-
  (*existence*)
    show " ex it be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be ElementSUBSET-1M1-of it holds x be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
    proof-
      have " ex tVar11 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be ElementSUBSET-1M1-of tVar11 holds x be  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
      proof-
        let ?a = "the ElementSUBSET-1M1-of D"
        obtain A where 
          [ty]:"A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and ADef:"A = {TARSKIK1 {TARSKIK1 <*>FINSEQ-1K7 D } -->FUNCOP-1K8\<^bsub>(D)\<^esub> ?a }"
           sorry
        show " ex tVar11 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 st  for x be ElementSUBSET-1M1-of tVar11 holds x be  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
        proof(rule bexI[of _ "A"],rule ballI)
          fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
          have "x =XBOOLE-0R4 <*>FINSEQ-1K7 D .-->FUNCOP-1K17 ?a"
            using tarski_def_1 sorry
          thus "x be  non emptyXBOOLE-0V1\<bar>homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
            using margrel1_th_18 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

syntax MARGREL1M8 :: " Set \<Rightarrow>  Set \<Rightarrow> Ty" ("ElementMARGREL1M8\<^bsub>'( _ ')\<^esub>-of  _ " [0,70]70)
translations "ElementMARGREL1M8\<^bsub>(D)\<^esub>-of P" \<rightharpoonup> "ElementSUBSET-1M1-of P"

mtheorem margrel1_add_10:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "P be PFuncsDomHQNMARGREL1M7-of D"
"cluster note-that homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D) for ElementSUBSET-1M1-of P"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of P holds it be homogeneousMARGREL1V4\<bar>quasi-totalMARGREL1V5\<^bsub>(D)\<^esub>\<bar> non emptyXBOOLE-0V1\<bar>PartFuncPARTFUN1M1-of(D * FINSEQ-2K3,D)"
    using margrel1_def_26 sorry
qed "sorry"

end
