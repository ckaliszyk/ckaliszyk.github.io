theory prepower
  imports newton rfunct_2
   "../mizar_extension/E_number"
begin
(*begin*)
mtheorem prepower_cl_1:
  mlet "i be IntegerINT-1M1"
"cluster  |.INT-2K1 i.| as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show " |.INT-2K1 i.| be naturalORDINAL1V7"
     sorry
qed "sorry"

reserve a, b, c for "RealXREAL-0M1"
reserve m, n, m1, m2 for "NatNAT-1M1"
reserve k, l for "IntegerINT-1M1"
reserve p, q for "RationalRAT-1M1"
reserve s1, s2 for "Real-SequenceSEQ-1M1"
mtheorem prepower_th_1:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 a) implies limSEQ-2K1 s1 >=XXREAL-0R2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 a) implies limSEQ-2K1 s1 >=XXREAL-0R2 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 a"
    let ?s = "seq-constSEQ-1K1 a"
    have A3: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s1 .FUNCT-1K1 n >=XXREAL-0R2 a"
        using A2 sorry
      thus "s1 .FUNCT-1K1 n >=XXREAL-0R2 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
        using seq_1_th_57 sorry
    qed "sorry"
    have "limSEQ-2K1 ?s =HIDDENR1 ?s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = a"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?s =HIDDENR1 a"
       sorry
    thus "limSEQ-2K1 s1 >=XXREAL-0R2 a"
      using A1 A3 seq_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_2:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 a) implies limSEQ-2K1 s1 <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 a) implies limSEQ-2K1 s1 <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 a"
    let ?s = "seq-constSEQ-1K1 a"
    have A3: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s1 .FUNCT-1K1 n <=XXREAL-0R1 a"
        using A2 sorry
      thus "s1 .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
        using seq_1_th_57 sorry
    qed "sorry"
    have "limSEQ-2K1 ?s =HIDDENR1 ?s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = a"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?s =HIDDENR1 a"
       sorry
    thus "limSEQ-2K1 s1 <=XXREAL-0R1 a"
      using A1 A3 seq_2_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_1 (" _ GeoSeqPREPOWERK1" [220]220 ) where
  mlet "a be RealXREAL-0M1"
"func a GeoSeqPREPOWERK1 \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for m be NatNAT-1M1 holds it .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for m be NatNAT-1M1 holds it .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
    proof-
      have " ex tVar1 be Real-SequenceSEQ-1M1 st  for m be NatNAT-1M1 holds tVar1 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
      proof-
        have 
          [ty]:"a be RealXREAL-0M1"
           sorry
        let ?F = "\<lambda>Lamb1. InSUBSET-1K10(a  |^NEWTONK1 Lamb1,REALNUMBERSK2)"
        obtain f where
          [ty]:"f be Real-SequenceSEQ-1M1" and 
          A1: " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds f .FUNCT-1K1 m =COMPLEX1R1 ?F(m)"
          using funct_2_sch_4 sorry
        show " ex tVar1 be Real-SequenceSEQ-1M1 st  for m be NatNAT-1M1 holds tVar1 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
        proof(rule bexI[of _ "f"],rule ballI)
          fix m assume [ty]: "m be NatNAT-1M1"
          have 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "f .FUNCT-1K1 m =COMPLEX1R1 ?F(m)"
            using A1 sorry
          thus "f .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m"
             sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for m be NatNAT-1M1 holds it1 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m) & ( for m be NatNAT-1M1 holds it2 .FUNCT-1K1 m =COMPLEX1R1 a  |^NEWTONK1 m) implies it1 =HIDDENR1 it2"
    proof-
      have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 a  |^NEWTONK1 n) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a  |^NEWTONK1 n) implies s1 =HIDDENR1 s2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
        assume A2: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 a  |^NEWTONK1 n"
          and A3: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a  |^NEWTONK1 n"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 s2 .FUNCT-1K1 n"
        proof-
          have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
          proof(rule ballI)
            fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "s1 .FUNCT-1K1 n =HIDDENR1 a  |^NEWTONK1 n"
              using A2 sorry
            also have "... = s2 .FUNCT-1K1 n"
              using A3 sorry
            finally show "s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
               sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        thus "s1 =HIDDENR1 s2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem prepower_th_3:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds s1 =FUNCT-1R1 a GeoSeqPREPOWERK1 iff s1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a)"
proof-
  have " for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds (s1 =FUNCT-1R1 a GeoSeqPREPOWERK1 implies s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M & ( for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a)) & (s1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M & ( for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a) implies s1 =FUNCT-1R1 a GeoSeqPREPOWERK1)"
  proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    let ?P = "\<lambda>Lamb1. s1 .FUNCT-1K1 Lamb1 =COMPLEX1R1 a GeoSeqPREPOWERK1 .FUNCT-1K1 Lamb1"
    show "s1 =FUNCT-1R1 a GeoSeqPREPOWERK1 implies s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M & ( for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a)"
    proof(rule impI,rule conjMI,rule ballI)
      assume A1: "s1 =FUNCT-1R1 a GeoSeqPREPOWERK1"
      then have "s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 a  |^NEWTONK1 (0NUMBERSK6)"
        using prepower_def_1 sorry
      also have "... = \<one>\<^sub>M"
        using newton_th_4 sorry
      finally show "s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
         sorry
      fix m assume [ty]: "m be NatNAT-1M1"
      have "s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
        using A1 prepower_def_1 sorry
      also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 a"
        using newton_th_6 sorry
      also have "... = s1 .FUNCT-1K1 m *XCMPLX-0K3 a"
        using A1 prepower_def_1 sorry
      finally show "s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a"
         sorry
    qed "sorry"
    assume A2: "s1 .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
      and A3: " for m be NatNAT-1M1 holds s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a"
    have A4: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds s1 .FUNCT-1K1 m =COMPLEX1R1 a GeoSeqPREPOWERK1 .FUNCT-1K1 m implies s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "s1 .FUNCT-1K1 m =COMPLEX1R1 a GeoSeqPREPOWERK1 .FUNCT-1K1 m"
        have "s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 s1 .FUNCT-1K1 m *XCMPLX-0K3 a"
          using A3 sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 a"
          using A5 prepower_def_1 sorry
        also have "... = a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
          using prepower_def_1 sorry
        finally show "s1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 a  |^NEWTONK1 (0NUMBERSK6)"
      using A2 newton_th_4 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    finally have "s1 .FUNCT-1K1 (0NUMBERSK6) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
       sorry
    then have A6: "?P(0NUMBERSK6)"
       sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A6 A4 sorry
    then have " for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds ?P(m)"
       sorry
    thus "s1 =FUNCT-1R1 a GeoSeqPREPOWERK1"
      using funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_4:
" for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( for m be NatNAT-1M1 holds a GeoSeqPREPOWERK1 .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6)"
proof-
  have " for a be RealXREAL-0M1 holds a <>HIDDENR2 0NUMBERSK6 implies ( for n be NatNAT-1M1 holds a GeoSeqPREPOWERK1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6)"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    let ?P = "\<lambda>Lamb1. a GeoSeqPREPOWERK1 .FUNCT-1K1 Lamb1 <>HIDDENR2 0NUMBERSK6"
    have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds a GeoSeqPREPOWERK1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6 implies a GeoSeqPREPOWERK1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A3: "a GeoSeqPREPOWERK1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        have "a GeoSeqPREPOWERK1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =COMPLEX1R1 a GeoSeqPREPOWERK1 .FUNCT-1K1 n *XCMPLX-0K3 a"
          using prepower_th_3 sorry
        thus "a GeoSeqPREPOWERK1 .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P(0NUMBERSK6)"
      using prepower_th_3 sorry
    show " for n be NatNAT-1M1 holds a GeoSeqPREPOWERK1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
      using nat_1_sch_2 A4 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_5:
" for a be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <>HIDDENR2 a implies 0NUMBERSK6 <>HIDDENR2 a  |^NEWTONK1 n"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <>HIDDENR2 a implies  not 0NUMBERSK6 <>HIDDENR2 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. a  |^NEWTONK1 Lamb1 <>HIDDENR2 0NUMBERSK6"
    assume A2: "0NUMBERSK6 <>HIDDENR2 a"
    have A3: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds a  |^NEWTONK1 m <>HIDDENR2 0NUMBERSK6 implies a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "a  |^NEWTONK1 m <>HIDDENR2 0NUMBERSK6"
        then have "a  |^NEWTONK1 m *XCMPLX-0K3 a <>HIDDENR2 0NUMBERSK6"
          using A2 sorry
        thus "a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P(0NUMBERSK6)"
      using newton_th_4 sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A4 A3 sorry
    thus " not 0NUMBERSK6 <>HIDDENR2 a  |^NEWTONK1 n"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_6:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a implies  not 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 Lamb1"
    assume A2: "0NUMBERSK6 <XXREAL-0R3 a"
    have A3: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds a  |^NEWTONK1 m >XXREAL-0R4 0NUMBERSK6 implies 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "a  |^NEWTONK1 m >XXREAL-0R4 0NUMBERSK6"
        then have "a  |^NEWTONK1 m *XCMPLX-0K3 a >XXREAL-0R4 (0NUMBERSK6)*XCMPLX-0K3 a"
          using A2 sorry
        thus "0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P(0NUMBERSK6)"
      using newton_th_4 sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A4 A3 sorry
    thus " not 0NUMBERSK6 <XXREAL-0R3 a  |^NEWTONK1 n"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_7:
" for a be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 n"
proof(rule ballI,rule ballI)
  fix a assume [ty]: "a be ComplexXCMPLX-0M1"
  fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
  have A1: "n be NatNAT-1M1"
    using tarski_th_1 sorry
  let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 Lamb1 =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 Lamb1"
  have A2: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for m be NatNAT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 m implies (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 m =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 m"
      then have "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 m)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)"
        using newton_th_6 sorry
      also have "... = (\<one>\<^sub>M *NAT-1K2 \<one>\<^sub>M)/XCMPLX-0K7 (a  |^NEWTONK1 m *XCMPLX-0K3 a)"
        using xcmplx_1_th_76 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
        using newton_th_6 sorry
      finally show "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
    using newton_th_4 sorry
  also have "... = \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
     sorry
  also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (0NUMBERSK6)"
    using newton_th_4 sorry
  finally have "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (0NUMBERSK6)"
     sorry
  then have A3: "?P(0NUMBERSK6)"
     sorry
  have " for m be NatNAT-1M1 holds ?P(m)"
    using nat_1_sch_2 A3 A2 sorry
  thus "(\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 n"
    using A1 sorry
qed "sorry"

mtheorem prepower_th_8:
" for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (b /XCMPLX-0K7 a) |^NEWTONK1 n =COMPLEX1R1 b  |^NEWTONK1 n /XCMPLX-0K7 a  |^NEWTONK1 n"
proof-
  have " for a be ComplexXCMPLX-0M1 holds  for b be ComplexXCMPLX-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (b /XCMPLX-0K7 a) |^NEWTONK1 n =HIDDENR1 b  |^NEWTONK1 n /XCMPLX-0K7 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be ComplexXCMPLX-0M1"
    fix b assume [ty]: "b be ComplexXCMPLX-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have "(b /XCMPLX-0K7 a) |^NEWTONK1 n =HIDDENR1 (b *XCMPLX-0K3 a \<inverse>XCMPLX-0K5) |^NEWTONK1 n"
       sorry
    also have "... = b  |^NEWTONK1 n *XCMPLX-0K3 a \<inverse>XCMPLX-0K5  |^NEWTONK1 n"
      using newton_th_7 sorry
    also have "... = b  |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 n"
       sorry
    also have "... = b  |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 n)"
      using prepower_th_7 sorry
    also have "... = (b  |^NEWTONK1 n *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 a  |^NEWTONK1 n"
       sorry
    also have "... = b  |^NEWTONK1 n /XCMPLX-0K7 a  |^NEWTONK1 n"
       sorry
    finally show "(b /XCMPLX-0K7 a) |^NEWTONK1 n =HIDDENR1 b  |^NEWTONK1 n /XCMPLX-0K7 a  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies a  |^NEWTONK1 n <=XXREAL-0R1 b  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 b implies a  |^NEWTONK1 n <=XXREAL-0R1 b  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    assume A2: "0NUMBERSK6 <XXREAL-0R3 a"
      and A3: "a <=XXREAL-0R1 b"
    let ?P = "\<lambda>Lamb1. a  |^NEWTONK1 Lamb1 <=XXREAL-0R1 b  |^NEWTONK1 Lamb1"
    have A4: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a  |^NEWTONK1 m1 <=XXREAL-0R1 b  |^NEWTONK1 m1 implies a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 b  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume A5: "a  |^NEWTONK1 m1 <=XXREAL-0R1 b  |^NEWTONK1 m1"
        have "a  |^NEWTONK1 m1 >XXREAL-0R4 0NUMBERSK6"
          using A2 prepower_th_6 sorry
        then have "a  |^NEWTONK1 m1 *XCMPLX-0K3 a <=XXREAL-0R1 b  |^NEWTONK1 m1 *XCMPLX-0K3 b"
          using A2 A3 A5 xreal_1_th_66 sorry
        then have "a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 b  |^NEWTONK1 m1 *XCMPLX-0K3 b"
          using newton_th_6 sorry
        thus "a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 b  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "b  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 b GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_3 sorry
    finally have "b  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    have "a  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_3 sorry
    finally have "a  |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A7: "?P(0NUMBERSK6)"
      using A6 sorry
    have " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A7 A4 sorry
    thus "a  |^NEWTONK1 n <=XXREAL-0R1 b  |^NEWTONK1 n"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_1:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 b) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & (a <XXREAL-0R3 b & \<one>\<^sub>M <=XXREAL-0R1 n) implies  not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <XXREAL-0R3 b"
      and A3: "\<one>\<^sub>M <=XXREAL-0R1 n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A4: "n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 m"
      using A3 nat_1_th_10 sorry
    let ?P = "\<lambda>Lamb1. a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 Lamb1) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 Lamb1)"
    have A5: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) implies a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume A6: "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1)"
        have "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        then have "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 a <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 b"
          using A1 A2 A6 xreal_1_th_97 sorry
        then have "a  |^NEWTONK1 ((\<one>\<^sub>M +XCMPLX-0K2 m1)+NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 b"
          using newton_th_6 sorry
        thus "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 b  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M))"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "?P(0NUMBERSK6)"
      using A2 sorry
    have A8: " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A7 A5 sorry
    show " not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
      using A4 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 b) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (a <XXREAL-0R3 b & \<one>\<^sub>M <=XXREAL-0R1 n) implies  not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <XXREAL-0R3 b"
      and A3: "\<one>\<^sub>M <=XXREAL-0R1 n"
    show " not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
    proof-
      have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
        using A1 sorry
      have case1: "a >XXREAL-0R4 0NUMBERSK6 implies  not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
      proof(rule impI)
        assume "a >XXREAL-0R4 0NUMBERSK6"
        thus " not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
          using A2 A3 prepower_lm_1 sorry
      qed
      have case2: "a =COMPLEX1R1 0NUMBERSK6 implies  not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
      proof(rule impI)
        assume A4: "a =COMPLEX1R1 0NUMBERSK6"
        obtain k k1 where 
          [ty]:"k be IntegerINT-1M1" and kDef:"k = n" and
          [ty]:"k1 be IntegerINT-1M1" and k1Def:"k1 = \<one>\<^sub>M"
           sorry
        obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = k -XCMPLX-0K6 k1"
          using A3 int_1_th_5 sorry
        have "a  |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 a  |^NEWTONK1 \<one>\<^sub>M"
          using newton_th_8 sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
          using prepower_def_1 sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 (a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (0NUMBERSK6))"
          using A4 prepower_th_3 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "a  |^NEWTONK1 n =HIDDENR1 0NUMBERSK6"
           sorry
        thus " not a  |^NEWTONK1 n <XXREAL-0R3 b  |^NEWTONK1 n"
          using A1 A2 prepower_th_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_11:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M implies a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume "a >=XXREAL-0R2 \<one>\<^sub>M"
    then have "a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M  |^NEWTONK1 n"
      using prepower_th_9 sorry
    thus "a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
      using newton_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_12:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M <=XXREAL-0R1 a & \<one>\<^sub>M <=XXREAL-0R1 n implies a <=XXREAL-0R1 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds \<one>\<^sub>M <=XXREAL-0R1 a & \<one>\<^sub>M <=XXREAL-0R1 n implies a <=XXREAL-0R1 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 a"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "n =COMPLEX1R1 m +NAT-1K1 \<one>\<^sub>M"
      using A2 nat_1_th_6 sorry
    let ?P = "\<lambda>Lamb1. a <=XXREAL-0R1 a  |^NEWTONK1 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    have A4: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a <=XXREAL-0R1 a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M) implies a <=XXREAL-0R1 a  |^NEWTONK1 ((m1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume "a <=XXREAL-0R1 a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
        then have "a *XCMPLX-0K3 \<one>\<^sub>M <=XXREAL-0R1 a  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
          using A1 xreal_1_th_66 sorry
        thus "a <=XXREAL-0R1 a  |^NEWTONK1 ((m1 +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
       sorry
    have A6: " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A5 A4 sorry
    show "a <=XXREAL-0R1 a  |^NEWTONK1 n"
      using A3 A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_13:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 a & \<two>\<^sub>M <=XXREAL-0R1 n implies a <XXREAL-0R3 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 a & \<two>\<^sub>M <=XXREAL-0R1 n implies  not a <XXREAL-0R3 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 a"
      and A2: "\<two>\<^sub>M <=XXREAL-0R1 n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "n =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 m"
      using A2 nat_1_th_10 sorry
    let ?P = "\<lambda>Lamb1. a <XXREAL-0R3 a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 Lamb1)"
    have A4: "a *XCMPLX-0K3 a >XXREAL-0R4 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 xreal_1_th_68 sorry
    have A5: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a <XXREAL-0R3 a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1) implies a <XXREAL-0R3 a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume "a <XXREAL-0R3 a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1)"
        then have "a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 a >XXREAL-0R4 a *XCMPLX-0K3 a"
          using A1 xreal_1_th_68 sorry
        then have "a  |^NEWTONK1 ((\<two>\<^sub>M +XCMPLX-0K2 m1)+NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 a *XCMPLX-0K3 a"
          using newton_th_6 sorry
        thus "a <XXREAL-0R3 a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M))"
          using A4 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using prepower_def_1 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = (a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = a *XCMPLX-0K3 a"
       sorry
    finally have "a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a *XCMPLX-0K3 a"
       sorry
    then have A6: "?P(0NUMBERSK6)"
      using A4 sorry
    have A7: " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A6 A5 sorry
    show " not a <XXREAL-0R3 a  |^NEWTONK1 n"
      using A3 A7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_14:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <=XXREAL-0R1 \<one>\<^sub>M) & \<one>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <=XXREAL-0R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & (a <=XXREAL-0R1 \<one>\<^sub>M & \<one>\<^sub>M <=XXREAL-0R1 n) implies a  |^NEWTONK1 n <=XXREAL-0R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "\<one>\<^sub>M <=XXREAL-0R1 n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A4: "n =COMPLEX1R1 \<one>\<^sub>M +XCMPLX-0K2 m"
      using A3 nat_1_th_10 sorry
    let ?P = "\<lambda>Lamb1. a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 Lamb1) <=XXREAL-0R1 a"
    have A5: "a *XCMPLX-0K3 a <=XXREAL-0R1 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_th_64 sorry
    have A6: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) <=XXREAL-0R1 a implies a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 a"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) <=XXREAL-0R1 a"
        then have "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 a <=XXREAL-0R1 a *XCMPLX-0K3 a"
          using A1 xreal_1_th_64 sorry
        then have "a  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 (m1 +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 a *XCMPLX-0K3 a"
          using newton_th_6 sorry
        thus "a  |^NEWTONK1 (\<one>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <=XXREAL-0R1 a"
          using A5 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: "?P(0NUMBERSK6)"
       sorry
    have A8: " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A7 A6 sorry
    show "a  |^NEWTONK1 n <=XXREAL-0R1 a"
      using A4 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_15:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M) & \<two>\<^sub>M <=XXREAL-0R1 n implies a  |^NEWTONK1 n <XXREAL-0R3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & (a <XXREAL-0R3 \<one>\<^sub>M & \<two>\<^sub>M <=XXREAL-0R1 n) implies  not a  |^NEWTONK1 n <XXREAL-0R3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 a"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "\<two>\<^sub>M <=XXREAL-0R1 n"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A4: "n =COMPLEX1R1 \<two>\<^sub>M +XCMPLX-0K2 m"
      using A3 nat_1_th_10 sorry
    let ?P = "\<lambda>Lamb1. a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 Lamb1) <XXREAL-0R3 a"
    have A5: "a *XCMPLX-0K3 a <XXREAL-0R3 a *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 A2 xreal_1_th_68 sorry
    have A6: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1) <XXREAL-0R3 a implies a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 a"
      proof(rule ballI,rule impI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume "a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1) <XXREAL-0R3 a"
        then have "a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 m1) *XCMPLX-0K3 a <XXREAL-0R3 a *XCMPLX-0K3 a"
          using A1 xreal_1_th_68 sorry
        then have "a  |^NEWTONK1 ((\<two>\<^sub>M +XCMPLX-0K2 m1)+NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 a *XCMPLX-0K3 a"
          using newton_th_6 sorry
        thus "a  |^NEWTONK1 (\<two>\<^sub>M +XCMPLX-0K2 (m1 +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 a"
          using A5 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
      using prepower_def_1 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = (a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 a)*XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = (\<one>\<^sub>M *XCMPLX-0K3 a)*XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = a *XCMPLX-0K3 a"
       sorry
    finally have "a  |^NEWTONK1 (\<two>\<^sub>M +NAT-1K1 0NUMBERSK6) =HIDDENR1 a *XCMPLX-0K3 a"
       sorry
    then have A7: "?P(0NUMBERSK6)"
      using A5 sorry
    have A8: " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A7 A6 sorry
    show " not a  |^NEWTONK1 n <XXREAL-0R3 a"
      using A4 A8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_16:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds -XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 Lamb1 >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 Lamb1 *XCMPLX-0K3 a"
    assume A2: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 a"
    have A3: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 m >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 m *XCMPLX-0K3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a"
      proof(rule ballI,rule impI)
        have A4: "(-XCMPLX-0K4 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 a"
          using A2 xreal_1_th_6 sorry
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 m >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 m *XCMPLX-0K3 a"
        then have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 m *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a) >=XXREAL-0R2 (\<one>\<^sub>M +XCMPLX-0K2 m *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a)"
          using A4 xreal_1_th_64 sorry
        then have A5: "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 ((\<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 a)+XCMPLX-0K2 m *XCMPLX-0K3 a)+XCMPLX-0K2 (m *XCMPLX-0K3 a)*XCMPLX-0K3 a"
          using newton_th_6 sorry
        have "0NUMBERSK6 <=XXREAL-0R1 a *XCMPLX-0K3 a"
          using xreal_1_th_63 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 0NUMBERSK6 <=XXREAL-0R1 (\<one>\<^sub>M +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a)+XCMPLX-0K2 m *XCMPLX-0K3 (a *XCMPLX-0K3 a)"
          using xreal_1_th_7 sorry
        thus "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 (m +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a"
          using A5 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 a)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_3 sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A6: "?P(0NUMBERSK6)"
       sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A6 A3 sorry
    thus "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 a"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_17:
" for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be naturalORDINAL1V7\<bar>NumberORDINAL1M1 holds 0NUMBERSK6 <XXREAL-0R3 a & a <XXREAL-0R3 \<one>\<^sub>M implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1"
    have A1: "n be NatNAT-1M1"
      using tarski_th_1 sorry
    assume A2: "0NUMBERSK6 <XXREAL-0R3 a"
      and A3: "a <XXREAL-0R3 \<one>\<^sub>M"
    have A4: "\<one>\<^sub>M +NAT-1K1 0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 a"
      using A2 xreal_1_th_6 sorry
    let ?P = "\<lambda>Lamb1. (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 Lamb1 <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 Lamb1 *XCMPLX-0K3 a"
    have A5: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a implies (\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
        then have A6: "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a) <=XXREAL-0R1 (\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a)"
          using A2 xreal_1_th_64 sorry
        have A7: "(\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a)+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n)*XCMPLX-0K3 a =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M +NAT-1K1 \<two>\<^sub>M))*XCMPLX-0K3 a"
           sorry
        also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
          using newton_th_6 sorry
        finally have "(\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a)+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n)*XCMPLX-0K3 a =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
           sorry
        have A8: "\<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
        proof-
          show "\<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
          proof-
            have cases: "0NUMBERSK6 =COMPLEX1R1 n or 0NUMBERSK6 <>HIDDENR2 n"
               sorry
            have case1: "0NUMBERSK6 =COMPLEX1R1 n implies \<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
            proof(rule impI)
              assume A9: "0NUMBERSK6 =COMPLEX1R1 n"
              have "\<three>\<^sub>M  |^NEWTONK1 n =HIDDENR1 \<three>\<^sub>M GeoSeqPREPOWERK1 .FUNCT-1K1 n"
                using prepower_def_1 sorry
              also have "... = \<one>\<^sub>M"
                using A9 prepower_th_3 sorry
              finally have "\<three>\<^sub>M  |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M"
                 sorry
              thus "\<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
                 sorry
            qed
            have case2: "0NUMBERSK6 <>HIDDENR2 n implies \<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
            proof(rule impI)
              assume "0NUMBERSK6 <>HIDDENR2 n"
              then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
                using nat_1_th_13 sorry
              then have "\<one>\<^sub>M  |^NEWTONK1 n <XXREAL-0R3 \<three>\<^sub>M  |^NEWTONK1 n"
                using prepower_lm_1 sorry
              thus "\<one>\<^sub>M <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        then have "\<one>\<^sub>M *XCMPLX-0K3 a <=XXREAL-0R1 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
          using A2 xreal_1_th_64 sorry
        then have A10: "\<one>\<^sub>M +XCMPLX-0K2 a <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
          using xreal_1_th_7 sorry
        have "a *XCMPLX-0K3 a <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 a"
          using A2 A3 xreal_1_th_68 sorry
        then have "\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 a) <XXREAL-0R3 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
          using A8 xreal_1_th_68 sorry
        then have A11: "\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 a) <XXREAL-0R3 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
          using xreal_1_th_6 sorry
        have "(\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a) =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 a)+XCMPLX-0K2 (\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 (a *XCMPLX-0K3 a))"
           sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a) <XXREAL-0R3 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
          using A10 A7 A11 xreal_1_th_8 sorry
        then have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n *XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 a) <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
          using A6 xxreal_0_th_2 sorry
        thus "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 a"
          using newton_th_6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A12: "\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) *XCMPLX-0K3 a =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 a"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = \<one>\<^sub>M +XCMPLX-0K2 a"
       sorry
    finally have "\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) *XCMPLX-0K3 a =HIDDENR1 \<one>\<^sub>M +XCMPLX-0K2 a"
       sorry
    have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 a)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_3 sorry
    finally have "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A13: "?P(0NUMBERSK6)"
      using A12 A4 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A13 A5 sorry
    thus "(\<one>\<^sub>M +XCMPLX-0K2 a) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 a"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_18:
" for m be NatNAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m) implies s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m"
proof-
  have " for m be NatNAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m) implies s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m"
    let ?P = "\<lambda>Lamb1.  for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 Lamb1) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 Lamb1"
    have A3: "?P(0NUMBERSK6)"
    proof-
      have " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 (0NUMBERSK6)) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 (limSEQ-2K1 s1) |^NEWTONK1 (0NUMBERSK6)"
      proof(rule ballI,rule impI,rule conjMI)
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        assume A4: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 (0NUMBERSK6)"
        obtain j where 
          [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
          using numbers_th_19 sorry
        have A5: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =HIDDENR1 j"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "s .FUNCT-1K1 n =HIDDENR1 s1 .FUNCT-1K1 n  |^NEWTONK1 (0NUMBERSK6)"
            using A4 sorry
          also have "... = (s1 .FUNCT-1K1 n)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
            using prepower_def_1 sorry
          also have "... = j"
            using prepower_th_3 sorry
          finally show "s .FUNCT-1K1 n =HIDDENR1 j"
             sorry
        qed "sorry"
        then have A6: "s be constantVALUED-0V15"
          using valued_0_def_18 sorry
        thus "s be convergentSEQ-2V5"
           sorry
        have "limSEQ-2K1 s =HIDDENR1 s .FUNCT-1K1 (0NUMBERSK6)"
          using A6 seq_4_th_26 sorry
        also have "... = \<one>\<^sub>M"
          using A5 sorry
        also have "... = (limSEQ-2K1 s1)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
          using prepower_th_3 sorry
        also have "... = (limSEQ-2K1 s1) |^NEWTONK1 (0NUMBERSK6)"
          using prepower_def_1 sorry
        finally show "limSEQ-2K1 s =HIDDENR1 (limSEQ-2K1 s1) |^NEWTONK1 (0NUMBERSK6)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for m1 be NatNAT-1M1 holds ?P(m1) implies ?P(m1 +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m1 be NatNAT-1M1 holds ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m1) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m1) implies ( for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =HIDDENR1 (limSEQ-2K1 s1) |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI,rule ballI,rule impI,rule conjMI)
        fix m1 assume [ty]: "m1 be NatNAT-1M1"
        assume A8: " for s be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 m1) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m1"
        let ?O = "\<lambda>Lamb1. s1 .FUNCT-1K1 Lamb1  |^NEWTONK1 m1"
        fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
        obtain s3 where
          [ty]:"s3 be Real-SequenceSEQ-1M1" and 
          A9: " for n be NatNAT-1M1 holds s3 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using seq_1_sch_1 sorry
        assume A10: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 s1 .FUNCT-1K1 n  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
        have " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =HIDDENR1 s3 .FUNCT-1K1 n *XCMPLX-0K3 s1 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "s .FUNCT-1K1 n =HIDDENR1 s1 .FUNCT-1K1 n  |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
            using A10 sorry
          also have "... = s1 .FUNCT-1K1 n  |^NEWTONK1 m1 *XCMPLX-0K3 s1 .FUNCT-1K1 n"
            using newton_th_6 sorry
          also have "... = s3 .FUNCT-1K1 n *XCMPLX-0K3 s1 .FUNCT-1K1 n"
            using A9 sorry
          finally show "s .FUNCT-1K1 n =HIDDENR1 s3 .FUNCT-1K1 n *XCMPLX-0K3 s1 .FUNCT-1K1 n"
             sorry
        qed "sorry"
        then have A11: "s =FUNCT-1R1 s3 (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
          using seq_1_th_8 sorry
        have A12: "s3 be convergentSEQ-2V5"
          using A8 A9 sorry
        thus "s be convergentSEQ-2V5"
          using A1 A11 sorry
        have "limSEQ-2K1 s3 =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m1"
          using A8 A9 sorry
        then have "limSEQ-2K1 s =HIDDENR1 (limSEQ-2K1 s1) |^NEWTONK1 m1 *XCMPLX-0K3 (limSEQ-2K1 s1)"
          using A1 A12 A11 seq_2_th_15 sorry
        also have "... = (limSEQ-2K1 s1) |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        finally show "limSEQ-2K1 s =HIDDENR1 (limSEQ-2K1 s1) |^NEWTONK1 (m1 +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for m1 be NatNAT-1M1 holds ?P(m1)"
      using nat_1_sch_2 A3 A7 sorry
    thus "s2 be convergentSEQ-2V5 & limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1) |^NEWTONK1 m"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_2 (" _ -RootPREPOWERK2  _ " [220,220]220 ) where
  mlet "n be naturalORDINAL1V7\<bar>NumberORDINAL1M1", "a be RealXREAL-0M1"
"assume \<one>\<^sub>M <=XXREAL-0R1 n func n -RootPREPOWERK2 a \<rightarrow> RealXREAL-0M1 means
  \<lambda>it. it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6 if a >XXREAL-0R4 0NUMBERSK6,
  \<lambda>it. it =COMPLEX1R1 0NUMBERSK6 if a =COMPLEX1R1 0NUMBERSK6"
proof-
  (*consistency*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies ( for it be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a =COMPLEX1R1 0NUMBERSK6 implies (it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6 iff it =COMPLEX1R1 0NUMBERSK6))"
    proof(rule impI)
      assume Assume: "\<one>\<^sub>M <=XXREAL-0R1 n"
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
        using Assume sorry
      show " for it be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & a =COMPLEX1R1 0NUMBERSK6 implies (it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6 iff it =COMPLEX1R1 0NUMBERSK6)"
         sorry
    qed
  (*existence*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies (a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6)) & (a =COMPLEX1R1 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6))"
    proof(rule impI)
      assume Assume: "\<one>\<^sub>M <=XXREAL-0R1 n"
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
        using Assume sorry
      show "(a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it  |^NEWTONK1 n =COMPLEX1R1 a & it >XXREAL-0R4 0NUMBERSK6)) & (a =COMPLEX1R1 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st it =COMPLEX1R1 0NUMBERSK6))"
      proof-
        have " not ( not a >XXREAL-0R4 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not (VarFor1  |^NEWTONK1 n =COMPLEX1R1 a &  not VarFor1 >XXREAL-0R4 0NUMBERSK6))) &  not (a =COMPLEX1R1 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))"
        proof-
          have "a >XXREAL-0R4 0NUMBERSK6 implies ( ex d be objectHIDDENM1 st a =COMPLEX1R1 d  |^NEWTONK1 n & d >XXREAL-0R4 0NUMBERSK6)"
          proof(rule impI)
            let ?X = "{b where b be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 b & b  |^NEWTONK1 n <=XXREAL-0R1 a }"
            have " for x be objectHIDDENM1 holds x inHIDDENR3 ?X implies x inHIDDENR3 REALNUMBERSK2"
            proof-
              have " for x be objectHIDDENM1 holds x inHIDDENR3 {b where b be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 b & b  |^NEWTONK1 n <=XXREAL-0R1 a } implies x inHIDDENR3 REALNUMBERSK2"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 ?X"
                then have " ex b be RealXREAL-0M1 st (x =HIDDENR1 b & 0NUMBERSK6 <XXREAL-0R3 b) & b  |^NEWTONK1 n <=XXREAL-0R1 a"
                   sorry
                thus "x inHIDDENR3 REALNUMBERSK2"
                  using xreal_0_def_1 sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            then obtain X where 
              [ty]:"X be SubsetSUBSET-1M2-of REALNUMBERSK2" and XDef:"X = ?X"
              using tarski_def_3 sorry
            obtain a1 where 
              [ty]:"a1 be RealXREAL-0M1" and a1Def:"a1 = a"
               sorry
            obtain j where 
              [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
              using numbers_th_19 sorry
            have A2: "j <=XXREAL-0R1 a implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 X)"
            proof-
              have "j <=XXREAL-0R1 a implies ( ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 X)"
              proof(rule impI)
                assume A3: "j <=XXREAL-0R1 a"
                show " ex tVar2 be RealXREAL-0M1 st tVar2 inHIDDENR3 X"
                proof(rule bexI[of _ "j"])
                  have "j  |^NEWTONK1 n <=XXREAL-0R1 a"
                    using A3 newton_th_10 sorry
                  thus "j inHIDDENR3 X"
                     sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            have A4: "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex c be RealXREAL-0M1 st c be UpperBoundXXREAL-2M1-of X)"
            proof-
              have "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex tVar3 be RealXREAL-0M1 st tVar3 be UpperBoundXXREAL-2M1-of X)"
              proof(rule impI)
                obtain c where
                  [ty]:"c be RealXREAL-0M1" and 
                  A5: "c =COMPLEX1R1 \<one>\<^sub>M"
                   sorry
                assume A6: "a <XXREAL-0R3 \<one>\<^sub>M"
                show " ex tVar3 be RealXREAL-0M1 st tVar3 be UpperBoundXXREAL-2M1-of X"
                proof(rule bexI[of _ "c"])
                  have " for b be ExtRealXXREAL-0M1 holds b inHIDDENR3 X implies ( not b <=XXREAL-0R1 c implies  False )"
                  proof(rule ballI,rule impI,rule impI)
                    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
                    assume "b inHIDDENR3 X"
                    then obtain d where
                      [ty]:"d be RealXREAL-0M1" and 
                      A7: "(d =HIDDENR1 b & 0NUMBERSK6 <XXREAL-0R3 d) & d  |^NEWTONK1 n <=XXREAL-0R1 a"
                       sorry
                    assume " not b <=XXREAL-0R1 c"
                    then have "\<one>\<^sub>M  |^NEWTONK1 n <XXREAL-0R3 d  |^NEWTONK1 n"
                      using A1 A5 prepower_lm_1 A7 sorry
                    then have "\<one>\<^sub>M <XXREAL-0R3 d  |^NEWTONK1 n"
                      using newton_th_10 sorry
                    thus " False "
                      using A6 A7 xxreal_0_th_2 sorry
                  qed "sorry"
                  thus "c be UpperBoundXXREAL-2M1-of X"
                    using xxreal_2_def_1 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            assume A8: "a >XXREAL-0R4 0NUMBERSK6"
            have "\<one>\<^sub>M <=XXREAL-0R1 a implies ( ex c be RealXREAL-0M1 st c be UpperBoundXXREAL-2M1-of X)"
            proof-
              have "\<one>\<^sub>M <=XXREAL-0R1 a implies ( ex tVar4 be RealXREAL-0M1 st tVar4 be UpperBoundXXREAL-2M1-of X)"
              proof(rule impI)
                assume A9: "\<one>\<^sub>M <=XXREAL-0R1 a"
                show " ex tVar4 be RealXREAL-0M1 st tVar4 be UpperBoundXXREAL-2M1-of X"
                proof(rule bexI[of _ "a"])
                  have " for b be ExtRealXXREAL-0M1 holds b inHIDDENR3 X implies (a <XXREAL-0R3 b implies  False )"
                  proof(rule ballI,rule impI,rule impI)
                    fix b assume [ty]: "b be ExtRealXXREAL-0M1"
                    assume "b inHIDDENR3 X"
                    then obtain d where
                      [ty]:"d be RealXREAL-0M1" and 
                      A10: "(b =HIDDENR1 d & 0NUMBERSK6 <XXREAL-0R3 d) & d  |^NEWTONK1 n <=XXREAL-0R1 a"
                       sorry
                    assume "a <XXREAL-0R3 b"
                    then have "a  |^NEWTONK1 n <XXREAL-0R3 d  |^NEWTONK1 n"
                      using A1 A8 prepower_lm_1 A10 sorry
                    then have "a  |^NEWTONK1 n <XXREAL-0R3 a"
                      using A10 xxreal_0_th_2 sorry
                    thus " False "
                      using A1 A9 prepower_th_12 sorry
                  qed "sorry"
                  thus "a be UpperBoundXXREAL-2M1-of X"
                    using xxreal_2_def_1 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            then have A11: "X be bounded-aboveXXREAL-2V4"
              using A4 sorry
            obtain d where 
              [ty]:"d be objectHIDDENM1" and dDef:"d = upper-boundSEQ-4K2 X"
               sorry
            show " ex d be objectHIDDENM1 st a =COMPLEX1R1 d  |^NEWTONK1 n & d >XXREAL-0R4 0NUMBERSK6"
            proof(rule bexI[of _ "d"])
              have A12: "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex c be RealXREAL-0M1 st c inHIDDENR3 X)"
              proof-
                have "a <XXREAL-0R3 \<one>\<^sub>M implies ( ex tVar6 be RealXREAL-0M1 st tVar6 inHIDDENR3 X)"
                proof(rule impI)
                  assume A13: "a <XXREAL-0R3 \<one>\<^sub>M"
                  have 
                    [ty]:"a be RealXREAL-0M1"
                     sorry
                  show " ex tVar6 be RealXREAL-0M1 st tVar6 inHIDDENR3 X"
                  proof(rule bexI[of _ "a"])
                    have "a  |^NEWTONK1 n <=XXREAL-0R1 a"
                      using A1 A8 A13 prepower_th_14 sorry
                    thus "a inHIDDENR3 X"
                      using A8 sorry
                  qed "sorry"
                qed
                thus " ?thesis "
                   sorry
              qed
              have A14: "0NUMBERSK6 <XXREAL-0R3 d"
              proof-
                have " not 0NUMBERSK6 <XXREAL-0R3 d"
                proof-
                  obtain c where
                    [ty]:"c be RealXREAL-0M1" and 
                    A15: "c inHIDDENR3 X"
                    using A2 A12 sorry
                  have " ex e be RealXREAL-0M1 st (e =COMPLEX1R1 c & 0NUMBERSK6 <XXREAL-0R3 e) & e  |^NEWTONK1 n <=XXREAL-0R1 a"
                    using A15 sorry
                  thus " not 0NUMBERSK6 <XXREAL-0R3 d"
                    using A11 A15 seq_4_def_1 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have A16: " not a <XXREAL-0R3 d  |^NEWTONK1 n"
              proof-
                have "a <XXREAL-0R3 d  |^NEWTONK1 n implies  False "
                proof(rule impI)
                  let ?b = "(d *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n))/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
                  assume A17: "a <XXREAL-0R3 d  |^NEWTONK1 n"
                  then have A18: "(\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 d  |^NEWTONK1 n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a"
                    using xreal_1_th_68 sorry
                  have "a *XCMPLX-0K3 (d  |^NEWTONK1 n)\<inverse>XCMPLX-0K5 >XXREAL-0R4 (0NUMBERSK6)*XCMPLX-0K3 a"
                    using A8 A17 sorry
                  then have "-XCMPLX-0K4 (-XCMPLX-0K4 a /XCMPLX-0K7 d  |^NEWTONK1 n) >XXREAL-0R4 0NUMBERSK6"
                     sorry
                  then have "-XCMPLX-0K4 a /XCMPLX-0K7 d  |^NEWTONK1 n <XXREAL-0R3 0NUMBERSK6"
                     sorry
                  then have "\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 a /XCMPLX-0K7 d  |^NEWTONK1 n) <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                    using xreal_1_th_6 sorry
                  then have A19: "(\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
                    using xreal_1_th_68 sorry
                  have "\<one>\<^sub>M <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
                    using A1 nat_1_th_13 sorry
                  then have "(n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M"
                    using xreal_1_th_212 sorry
                  then have "(\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 \<one>\<^sub>M"
                    using A19 xxreal_0_th_2 sorry
                  then have A20: "d *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)) <XXREAL-0R3 d *XCMPLX-0K3 \<one>\<^sub>M"
                    using A14 xreal_1_th_68 sorry
                  then have "?b /XCMPLX-0K7 d <XXREAL-0R3 d /XCMPLX-0K7 d"
                    using A14 xreal_1_th_74 sorry
                  then have "?b /XCMPLX-0K7 d <XXREAL-0R3 \<one>\<^sub>M"
                    using A14 xcmplx_1_th_60 sorry
                  then have "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 -XCMPLX-0K4 ?b /XCMPLX-0K7 d"
                    using xreal_1_th_24 sorry
                  then have A21: "(\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d)) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d)"
                    using prepower_th_16 sorry
                  have "a /XCMPLX-0K7 d  |^NEWTONK1 n <XXREAL-0R3 d  |^NEWTONK1 n /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using A8 A17 xreal_1_th_74 sorry
                  then have "0NUMBERSK6 +XCMPLX-0K2 a /XCMPLX-0K7 d  |^NEWTONK1 n <XXREAL-0R3 \<one>\<^sub>M"
                    using A8 A17 xcmplx_1_th_60 sorry
                  then have "0NUMBERSK6 <XXREAL-0R3 \<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using xreal_1_th_20 sorry
                  then have "d *XCMPLX-0K3 (0NUMBERSK6) <XXREAL-0R3 d *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)"
                    using A14 sorry
                  then have "(0NUMBERSK6)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (d *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n))/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
                     sorry
                  then obtain c where
                    [ty]:"c be RealXREAL-0M1" and 
                    A22: "c inHIDDENR3 X"and A23: "d -XCMPLX-0K6 ?b <XXREAL-0R3 c"
                    using A2 A12 A11 seq_4_def_1 sorry
                  have "0NUMBERSK6 <XXREAL-0R3 d -XCMPLX-0K6 ?b"
                    using A20 xreal_1_th_50 sorry
                  then have A24: "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n <XXREAL-0R3 c  |^NEWTONK1 n"
                    using A1 A23 prepower_lm_1 sorry
                  have "(\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n =HIDDENR1 (\<one>\<^sub>M -XCMPLX-0K6 n *XCMPLX-0K3 (((d *XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n))/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M -XCMPLX-0K6 n *XCMPLX-0K3 ((d *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))/XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M -XCMPLX-0K6 n *XCMPLX-0K3 ((((\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))/XCMPLX-0K7 d)*XCMPLX-0K3 d))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M -XCMPLX-0K6 n *XCMPLX-0K3 ((\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 d  |^NEWTONK1 n"
                    using A14 xcmplx_1_th_87 sorry
                  also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M -XCMPLX-0K6 a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 (a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 d  |^NEWTONK1 n"
                    using xcmplx_1_th_60 sorry
                  also have "... = (((n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 n)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 (a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)))*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 ((n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)/XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 d  |^NEWTONK1 n +XCMPLX-0K2 (((n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a)/XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 d  |^NEWTONK1 n +XCMPLX-0K2 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a"
                    using A8 A17 xcmplx_1_th_87 sorry
                  finally have "(\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 d  |^NEWTONK1 n +XCMPLX-0K2 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a"
                     sorry
                  then have A25: "(\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a +XCMPLX-0K2 (n /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a"
                    using A18 xreal_1_th_6 sorry
                  have "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n =HIDDENR1 ((d -XCMPLX-0K6 ?b)*XCMPLX-0K3 \<one>\<^sub>M) |^NEWTONK1 n"
                     sorry
                  also have "... = ((d -XCMPLX-0K6 ?b)*XCMPLX-0K3 (d \<inverse>XCMPLX-0K5 *XCMPLX-0K3 d)) |^NEWTONK1 n"
                    using A14 xcmplx_0_def_7 sorry
                  also have "... = (((d -XCMPLX-0K6 ?b)*XCMPLX-0K3 d \<inverse>XCMPLX-0K5)*XCMPLX-0K3 d) |^NEWTONK1 n"
                     sorry
                  also have "... = (((d -XCMPLX-0K6 ?b)/XCMPLX-0K7 d)*XCMPLX-0K3 d) |^NEWTONK1 n"
                     sorry
                  also have "... = ((d /XCMPLX-0K7 d -XCMPLX-0K6 ?b /XCMPLX-0K7 d)*XCMPLX-0K3 d) |^NEWTONK1 n"
                     sorry
                  also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 ?b /XCMPLX-0K7 d)*XCMPLX-0K3 d) |^NEWTONK1 n"
                    using A14 xcmplx_1_th_60 sorry
                  also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d)) |^NEWTONK1 n *XCMPLX-0K3 d  |^NEWTONK1 n"
                    using newton_th_7 sorry
                  finally have "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d)) |^NEWTONK1 n *XCMPLX-0K3 d  |^NEWTONK1 n"
                     sorry
                  then have "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n >=XXREAL-0R2 (\<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (-XCMPLX-0K4 ?b /XCMPLX-0K7 d))*XCMPLX-0K3 d  |^NEWTONK1 n"
                    using A8 A17 A21 xreal_1_th_64 sorry
                  then have "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n >XXREAL-0R4 ((n +NAT-1K1 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 a"
                    using A25 xxreal_0_th_2 sorry
                  then have A26: "(d -XCMPLX-0K6 ?b) |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 a"
                    using xcmplx_1_th_60 sorry
                  have " ex e be RealXREAL-0M1 st (e =COMPLEX1R1 c & 0NUMBERSK6 <XXREAL-0R3 e) & e  |^NEWTONK1 n <=XXREAL-0R1 a"
                    using A22 sorry
                  thus " False "
                    using A24 A26 xxreal_0_th_2 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              have " not d  |^NEWTONK1 n <XXREAL-0R3 a"
              proof-
                have "d  |^NEWTONK1 n <XXREAL-0R3 a implies  False "
                proof(rule impI)
                  let ?b = "minXXREAL-0K4(\<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M,(a1 /XCMPLX-0K7 d  |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M  |^NEWTONK1 n)"
                  let ?c = "(\<one>\<^sub>M +XCMPLX-0K2 ?b)*XCMPLX-0K3 d"
                  have A27: "?c  |^NEWTONK1 n =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 ?b) |^NEWTONK1 n *XCMPLX-0K3 d  |^NEWTONK1 n"
                    using newton_th_7 sorry
                  have A28: "0NUMBERSK6 <XXREAL-0R3 \<three>\<^sub>M  |^NEWTONK1 n"
                    using prepower_th_6 sorry
                  have "\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ?b <=XXREAL-0R1 ((a /XCMPLX-0K7 d  |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M  |^NEWTONK1 n)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK1 n"
                    using xreal_1_th_64 xxreal_0_th_17 sorry
                  then have "\<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ?b <=XXREAL-0R1 a /XCMPLX-0K7 d  |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M"
                    using A28 xcmplx_1_th_87 sorry
                  then have A29: "\<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ?b <=XXREAL-0R1 a /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using xreal_1_th_19 sorry
                  have A30: "d  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
                    using A14 prepower_th_6 sorry
                  have A31: "d  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
                    using A14 prepower_th_6 sorry
                  assume "d  |^NEWTONK1 n <XXREAL-0R3 a"
                  then have "d  |^NEWTONK1 n /XCMPLX-0K7 d  |^NEWTONK1 n <XXREAL-0R3 a /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using A30 xreal_1_th_74 sorry
                  then have "\<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using A31 xcmplx_1_th_60 sorry
                  then have "\<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M <XXREAL-0R3 a /XCMPLX-0K7 d  |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M"
                    using xreal_1_th_9 sorry
                  then have "(a /XCMPLX-0K7 d  |^NEWTONK1 n -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 \<three>\<^sub>M  |^NEWTONK1 n >XXREAL-0R4 (0NUMBERSK6)/XCMPLX-0K7 \<three>\<^sub>M  |^NEWTONK1 n"
                    using A28 sorry
                  then have A32: "?b >XXREAL-0R4 0NUMBERSK6"
                    using xxreal_0_th_15 sorry
                  then have "\<one>\<^sub>M +XCMPLX-0K2 ?b >XXREAL-0R4 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
                    using xreal_1_th_6 sorry
                  then have A33: "(\<one>\<^sub>M +XCMPLX-0K2 ?b)*XCMPLX-0K3 d >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 d"
                    using A14 xreal_1_th_68 sorry
                  have "?b <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 \<two>\<^sub>M"
                    using xxreal_0_th_17 sorry
                  then have "?b <XXREAL-0R3 \<one>\<^sub>M"
                    using xxreal_0_th_2 sorry
                  then have "(\<one>\<^sub>M +XCMPLX-0K2 ?b) |^NEWTONK1 n <=XXREAL-0R1 \<one>\<^sub>M +XCMPLX-0K2 \<three>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 ?b"
                    using A32 prepower_th_17 sorry
                  then have "(\<one>\<^sub>M +XCMPLX-0K2 ?b) |^NEWTONK1 n <=XXREAL-0R1 a /XCMPLX-0K7 d  |^NEWTONK1 n"
                    using A29 xxreal_0_th_2 sorry
                  then have "?c  |^NEWTONK1 n <=XXREAL-0R1 (a /XCMPLX-0K7 d  |^NEWTONK1 n)*XCMPLX-0K3 d  |^NEWTONK1 n"
                    using A30 A27 xreal_1_th_64 sorry
                  then have A34: "?c  |^NEWTONK1 n <=XXREAL-0R1 a"
                    using A31 xcmplx_1_th_87 sorry
                  have "(\<one>\<^sub>M +XCMPLX-0K2 ?b)*XCMPLX-0K3 d >XXREAL-0R4 (0NUMBERSK6)*XCMPLX-0K3 d"
                    using A14 A32 sorry
                  then have "?c inTARSKIR2 X"
                    using A34 sorry
                  thus " False "
                    using A11 A33 seq_4_def_1 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "a =COMPLEX1R1 d  |^NEWTONK1 n & d >XXREAL-0R4 0NUMBERSK6"
                using A14 A16 xxreal_0_th_1 sorry
            qed "sorry"
          qed
          thus " not ( not a >XXREAL-0R4 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not (VarFor1  |^NEWTONK1 n =COMPLEX1R1 a &  not VarFor1 >XXREAL-0R4 0NUMBERSK6))) &  not (a =COMPLEX1R1 0NUMBERSK6 & ( for VarFor1 be RealXREAL-0M1 holds  not VarFor1 =COMPLEX1R1 0NUMBERSK6))"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "\<one>\<^sub>M <=XXREAL-0R1 n implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 implies ((it1  |^NEWTONK1 n =COMPLEX1R1 a & it1 >XXREAL-0R4 0NUMBERSK6) & (it2  |^NEWTONK1 n =COMPLEX1R1 a & it2 >XXREAL-0R4 0NUMBERSK6) implies it1 =HIDDENR1 it2)) & (a =COMPLEX1R1 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2)))"
    proof(rule impI)
      assume Assume: "\<one>\<^sub>M <=XXREAL-0R1 n"
      have A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 implies ((it1  |^NEWTONK1 n =COMPLEX1R1 a & it1 >XXREAL-0R4 0NUMBERSK6) & (it2  |^NEWTONK1 n =COMPLEX1R1 a & it2 >XXREAL-0R4 0NUMBERSK6) implies it1 =HIDDENR1 it2)) & (a =COMPLEX1R1 0NUMBERSK6 implies (it1 =COMPLEX1R1 0NUMBERSK6 & it2 =COMPLEX1R1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
      proof-
        have " for VarFor1 be RealXREAL-0M1 holds  for VarFor2 be RealXREAL-0M1 holds  not ((((( not a >XXREAL-0R4 0NUMBERSK6 & VarFor1  |^NEWTONK1 n =COMPLEX1R1 a) &  not VarFor1 >XXREAL-0R4 0NUMBERSK6) & VarFor2  |^NEWTONK1 n =COMPLEX1R1 a) &  not VarFor2 >XXREAL-0R4 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2) &  not (((a =COMPLEX1R1 0NUMBERSK6 & VarFor1 =COMPLEX1R1 0NUMBERSK6) & VarFor2 =COMPLEX1R1 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2)"
        proof-
          have " for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds b  |^NEWTONK1 n =COMPLEX1R1 a & (b >XXREAL-0R4 0NUMBERSK6 & (c  |^NEWTONK1 n =COMPLEX1R1 a & (c >XXREAL-0R4 0NUMBERSK6 & b <>HIDDENR2 c))) implies  False "
          proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
            fix b assume [ty]: "b be RealXREAL-0M1"
            fix c assume [ty]: "c be RealXREAL-0M1"
            assume A35: "b  |^NEWTONK1 n =COMPLEX1R1 a"
              and A36: "b >XXREAL-0R4 0NUMBERSK6"
              and A37: "c  |^NEWTONK1 n =COMPLEX1R1 a"
              and A38: "c >XXREAL-0R4 0NUMBERSK6"
              and A39: "b <>HIDDENR2 c"
            show " False "
            proof-
              have cases: "b >XXREAL-0R4 c or c >XXREAL-0R4 b"
                using A39 xxreal_0_th_1 sorry
              have case1: "b >XXREAL-0R4 c implies  False "
              proof(rule impI)
                assume "b >XXREAL-0R4 c"
                thus " False "
                  using A1 A35 A37 A38 prepower_lm_1 sorry
              qed
              have case2: "c >XXREAL-0R4 b implies  False "
              proof(rule impI)
                assume "c >XXREAL-0R4 b"
                thus " False "
                  using A1 A35 A36 A37 prepower_lm_1 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed "sorry"
          thus " for VarFor1 be RealXREAL-0M1 holds  for VarFor2 be RealXREAL-0M1 holds  not ((((( not a >XXREAL-0R4 0NUMBERSK6 & VarFor1  |^NEWTONK1 n =COMPLEX1R1 a) &  not VarFor1 >XXREAL-0R4 0NUMBERSK6) & VarFor2  |^NEWTONK1 n =COMPLEX1R1 a) &  not VarFor2 >XXREAL-0R4 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2) &  not (((a =COMPLEX1R1 0NUMBERSK6 & VarFor1 =COMPLEX1R1 0NUMBERSK6) & VarFor2 =COMPLEX1R1 0NUMBERSK6) &  not VarFor1 =HIDDENR1 VarFor2)"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem prepower_cl_2:
  mlet "n be NatNAT-1M1", "a be RealXREAL-0M1"
"cluster n -RootPREPOWERK2 a as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "n -RootPREPOWERK2 a be realXREAL-0V1"
     sorry
qed "sorry"

mlemma prepower_lm_2:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & (n -RootPREPOWERK2 (a  |^NEWTONK1 n) <>HIDDENR2 a implies  False )"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    show "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a"
      using A1 A2 prepower_def_2 sorry
    assume A3: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) <>HIDDENR2 a"
    show " False "
    proof-
      have cases: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) >XXREAL-0R4 a or n -RootPREPOWERK2 (a  |^NEWTONK1 n) <XXREAL-0R3 a"
        using A3 xxreal_0_th_1 sorry
      have case1: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) >XXREAL-0R4 a implies  False "
      proof(rule impI)
        assume A4: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) >XXREAL-0R4 a"
        have "a  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        thus " False "
          using A1 A2 A4 prepower_def_2 sorry
      qed
      have case2: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) <XXREAL-0R3 a implies  False "
      proof(rule impI)
        assume A5: "n -RootPREPOWERK2 (a  |^NEWTONK1 n) <XXREAL-0R3 a"
        have "a  |^NEWTONK1 n >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        thus " False "
          using A1 A2 A5 prepower_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_19:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    show "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
    proof-
      have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
        using A1 sorry
      have case1: "a >XXREAL-0R4 0NUMBERSK6 implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
      proof(rule impI)
        assume "a >XXREAL-0R4 0NUMBERSK6"
        thus "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
          using A2 prepower_lm_2 sorry
      qed
      have case2: "a =COMPLEX1R1 0NUMBERSK6 implies n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a & n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
      proof(rule impI,rule conjMI)
        assume A3: "a =COMPLEX1R1 0NUMBERSK6"
        obtain k k1 where 
          [ty]:"k be IntegerINT-1M1" and kDef:"k = n" and
          [ty]:"k1 be IntegerINT-1M1" and k1Def:"k1 = \<one>\<^sub>M"
           sorry
        obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = k -XCMPLX-0K6 k1"
          using A2 int_1_th_5 sorry
        have A4: "(0NUMBERSK6) |^NEWTONK1 n =HIDDENR1 (0NUMBERSK6) |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = (0NUMBERSK6) |^NEWTONK11 m *NAT-1K2 (0NUMBERSK6) |^NEWTONK11 \<one>\<^sub>M"
          using newton_th_8 sorry
        also have "... = (0NUMBERSK6) |^NEWTONK11 m *XCMPLX-0K3 (0NUMBERSK6)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
          using prepower_def_1 sorry
        also have "... = (0NUMBERSK6) |^NEWTONK11 m *XCMPLX-0K3 ((0NUMBERSK6)GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 (0NUMBERSK6))"
          using prepower_th_3 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "(0NUMBERSK6) |^NEWTONK1 n =HIDDENR1 0NUMBERSK6"
           sorry
        thus "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a"
          using A2 A3 prepower_def_2 sorry
        show "n -RootPREPOWERK2 (a  |^NEWTONK1 n) =COMPLEX1R1 a"
          using A2 A3 A4 prepower_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_20:
" for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "\<one>\<^sub>M  |^NEWTONK1 n =COMPLEX1R1 \<one>\<^sub>M"
       sorry
    assume "n >=XXREAL-0R2 \<one>\<^sub>M"
    thus "n -RootPREPOWERK2 \<one>\<^sub>M =COMPLEX1R1 \<one>\<^sub>M"
      using A1 prepower_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_21:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies \<one>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies \<one>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
    have "a  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using prepower_def_1 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = a"
       sorry
    finally have "a  |^NEWTONK1 \<one>\<^sub>M =HIDDENR1 a"
       sorry
    thus "\<one>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 a"
      using A1 prepower_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_22:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (a *XCMPLX-0K3 b) =COMPLEX1R1 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (b >=XXREAL-0R2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 (a *XCMPLX-0K3 b) <>HIDDENR2 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) <>HIDDENR2 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
    have A5: "(n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b) |^NEWTONK1 n =HIDDENR1 n -RootPREPOWERK2 a  |^NEWTONK1 n *XCMPLX-0K3 n -RootPREPOWERK2 b  |^NEWTONK1 n"
      using newton_th_7 sorry
    also have "... = a *XCMPLX-0K3 n -RootPREPOWERK2 b  |^NEWTONK1 n"
      using A1 A3 prepower_th_19 sorry
    also have "... = a *XCMPLX-0K3 b"
      using A2 A3 prepower_th_19 sorry
    finally have "(n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b) |^NEWTONK1 n =HIDDENR1 a *XCMPLX-0K3 b"
       sorry
    show " False "
    proof-
      have cases: "((a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) or a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6) or a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6"
        using A1 A2 sorry
      have case1: "a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A6: "a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
        then have A7: "n -RootPREPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        have A8: "n -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A3 A6 prepower_def_2 sorry
        have "a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6"
          using A6 sorry
        then have A9: "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) >XXREAL-0R4 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        show " False "
        proof-
          have cases: "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) <XXREAL-0R3 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b or n -RootPREPOWERK2 (a *XCMPLX-0K3 b) >XXREAL-0R4 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
            using A4 xxreal_0_th_1 sorry
          have case1: "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) <XXREAL-0R3 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) <XXREAL-0R3 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
            thus " False "
              using A3 A5 A9 prepower_th_19 sorry
          qed
          have case2: "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) >XXREAL-0R4 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) >XXREAL-0R4 n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b"
            thus " False "
              using A3 A5 A8 A7 prepower_th_19 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A10: "a =COMPLEX1R1 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6"
        then have "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) =COMPLEX1R1 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        thus " False "
          using A4 A10 sorry
      qed
      have case3: "a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A11: "a >XXREAL-0R4 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6"
        then have "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) =COMPLEX1R1 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        thus " False "
          using A4 A11 sorry
      qed
      have case4: "a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A12: "a =COMPLEX1R1 0NUMBERSK6 & b =COMPLEX1R1 0NUMBERSK6"
        then have "n -RootPREPOWERK2 (a *XCMPLX-0K3 b) =COMPLEX1R1 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        thus " False "
          using A4 A12 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_23:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) <>HIDDENR2 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a) implies  False "
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) <>HIDDENR2 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
    have A4: "n -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 prepower_def_2 sorry
    have A5: "(\<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a) |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a  |^NEWTONK1 n"
      using prepower_th_7 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 a"
      using A1 A2 prepower_lm_2 sorry
    finally have "(\<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a) |^NEWTONK1 n =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a"
       sorry
    have A6: "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 prepower_def_2 sorry
    show " False "
    proof-
      have cases: "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a or n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
        using A3 xxreal_0_th_1 sorry
      have case1: "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a implies  False "
      proof(rule impI)
        assume "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) >XXREAL-0R4 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
        thus " False "
          using A2 A4 A5 prepower_lm_2 sorry
      qed
      have case2: "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a implies  False "
      proof(rule impI)
        assume "n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 a"
        thus " False "
          using A2 A5 A6 prepower_lm_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_24:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (a /XCMPLX-0K7 b) =COMPLEX1R1 n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (b >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) implies n -RootPREPOWERK2 (a /XCMPLX-0K7 b) =HIDDENR1 n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n -RootPREPOWERK2 (a /XCMPLX-0K7 b) =HIDDENR1 n -RootPREPOWERK2 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5)"
       sorry
    also have "... = n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 b \<inverse>XCMPLX-0K5"
      using A1 A2 A3 prepower_th_22 sorry
    also have "... = n -RootPREPOWERK2 a *XCMPLX-0K3 n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 b)"
       sorry
    also have "... = n -RootPREPOWERK2 a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 b)"
      using A2 A3 prepower_th_23 sorry
    also have "... = (n -RootPREPOWERK2 a *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 n -RootPREPOWERK2 b"
       sorry
    also have "... = n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
       sorry
    finally show "n -RootPREPOWERK2 (a /XCMPLX-0K7 b) =HIDDENR1 n -RootPREPOWERK2 a /XCMPLX-0K7 n -RootPREPOWERK2 b"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_25:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 (m -RootPREPOWERK2 a) =COMPLEX1R1 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & (m >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 (m -RootPREPOWERK2 a) <>HIDDENR2 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "m >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "n -RootPREPOWERK2 (m -RootPREPOWERK2 a) <>HIDDENR2 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a"
    show " False "
    proof-
      have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
        using A1 sorry
      have case1: "a >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A5: "a >XXREAL-0R4 0NUMBERSK6"
        then have A6: "m -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        then have A7: "n -RootPREPOWERK2 (m -RootPREPOWERK2 a) >XXREAL-0R4 0NUMBERSK6"
          using A2 prepower_def_2 sorry
        have A8: "n -RootPREPOWERK2 (m -RootPREPOWERK2 a)  |^NEWTONK1 (n *XCMPLX-0K3 m) =HIDDENR1 (n -RootPREPOWERK2 (m -RootPREPOWERK2 a)  |^NEWTONK1 n) |^NEWTONK1 m"
          using newton_th_9 sorry
        also have "... = m -RootPREPOWERK2 a  |^NEWTONK1 m"
          using A2 A6 prepower_lm_2 sorry
        also have "... = a"
          using A1 A3 prepower_th_19 sorry
        finally have "n -RootPREPOWERK2 (m -RootPREPOWERK2 a)  |^NEWTONK1 (n *XCMPLX-0K3 m) =HIDDENR1 a"
           sorry
        have A9: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
          using A2 A3 xreal_1_th_159 sorry
        then have A10: "(n *XCMPLX-0K3 m)-RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A5 prepower_def_2 sorry
        show " False "
        proof-
          have cases: "n -RootPREPOWERK2 (m -RootPREPOWERK2 a) <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a or (n *XCMPLX-0K3 m)-RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 (m -RootPREPOWERK2 a)"
            using A4 xxreal_0_th_1 sorry
          have case1: "n -RootPREPOWERK2 (m -RootPREPOWERK2 a) <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 (m -RootPREPOWERK2 a) <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 a"
            thus " False "
              using A5 A8 A9 A7 prepower_def_2 sorry
          qed
          have case2: "(n *XCMPLX-0K3 m)-RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 (m -RootPREPOWERK2 a) implies  False "
          proof(rule impI)
            assume "(n *XCMPLX-0K3 m)-RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 (m -RootPREPOWERK2 a)"
            thus " False "
              using A5 A8 A9 A10 prepower_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "a =COMPLEX1R1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A11: "a =COMPLEX1R1 0NUMBERSK6"
        have "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
          using A2 A3 xreal_1_th_159 sorry
        then have A12: "(n *XCMPLX-0K3 m)-RootPREPOWERK2 a =COMPLEX1R1 0NUMBERSK6"
          using A11 prepower_def_2 sorry
        have "m -RootPREPOWERK2 a =COMPLEX1R1 0NUMBERSK6"
          using A3 A11 prepower_def_2 sorry
        thus " False "
          using A2 A4 A12 prepower_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_26:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M) & m >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a =COMPLEX1R1 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
proof-
  have " for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (n >=XXREAL-0R2 \<one>\<^sub>M & (m >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a <>HIDDENR2 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)))) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "m >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a <>HIDDENR2 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
    have A5: "(n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a) |^NEWTONK1 (n *XCMPLX-0K3 m) =HIDDENR1 n -RootPREPOWERK2 a  |^NEWTONK1 (n *XCMPLX-0K3 m) *XCMPLX-0K3 m -RootPREPOWERK2 a  |^NEWTONK1 (n *XCMPLX-0K3 m)"
      using newton_th_7 sorry
    also have "... = (n -RootPREPOWERK2 a  |^NEWTONK1 n) |^NEWTONK1 m *XCMPLX-0K3 m -RootPREPOWERK2 a  |^NEWTONK1 (n *XCMPLX-0K3 m)"
      using newton_th_9 sorry
    also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 m -RootPREPOWERK2 a  |^NEWTONK1 (m *XCMPLX-0K3 n)"
      using A1 A2 prepower_th_19 sorry
    also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 (m -RootPREPOWERK2 a  |^NEWTONK1 m) |^NEWTONK1 n"
      using newton_th_9 sorry
    also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 a  |^NEWTONK1 n"
      using A1 A3 prepower_th_19 sorry
    also have "... = a  |^NEWTONK1 (n +XCMPLX-0K2 m)"
      using newton_th_8 sorry
    finally have "(n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a) |^NEWTONK1 (n *XCMPLX-0K3 m) =HIDDENR1 a  |^NEWTONK1 (n +XCMPLX-0K2 m)"
       sorry
    have A6: "n *XCMPLX-0K3 m >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 A3 xreal_1_th_159 sorry
    show " False "
    proof-
      have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
        using A1 sorry
      have case1: "a >XXREAL-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A7: "a >XXREAL-0R4 0NUMBERSK6"
        then have A8: "m -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A3 prepower_def_2 sorry
        have "n -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A2 A7 prepower_def_2 sorry
        then have A9: "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
          using A8 sorry
        have A10: "a  |^NEWTONK1 (n +XCMPLX-0K2 m) >XXREAL-0R4 0NUMBERSK6"
          using A7 prepower_th_6 sorry
        then have A11: "(n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)) >XXREAL-0R4 0NUMBERSK6"
          using A6 prepower_def_2 sorry
        show " False "
        proof-
          have cases: "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)) or n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a >XXREAL-0R4 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
            using A4 xxreal_0_th_1 sorry
          have case1: "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)) implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a <XXREAL-0R3 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
            thus " False "
              using A5 A6 A10 A9 prepower_def_2 sorry
          qed
          have case2: "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a >XXREAL-0R4 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m)) implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 a *XCMPLX-0K3 m -RootPREPOWERK2 a >XXREAL-0R4 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 (n +XCMPLX-0K2 m))"
            thus " False "
              using A5 A6 A10 A11 prepower_def_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "a =COMPLEX1R1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A12: "a =COMPLEX1R1 0NUMBERSK6"
        obtain k k1 where 
          [ty]:"k be IntegerINT-1M1" and kDef:"k = n" and
          [ty]:"k1 be IntegerINT-1M1" and k1Def:"k1 = \<one>\<^sub>M"
           sorry
        obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = k -XCMPLX-0K6 k1"
          using A2 int_1_th_5 sorry
        have A13: "a  |^NEWTONK1 (n +XCMPLX-0K2 m) =HIDDENR1 a  |^NEWTONK1 ((m1 +XCMPLX-0K2 m)+NAT-1K1 \<one>\<^sub>M)"
           sorry
        also have "... = a  |^NEWTONK1 (m1 +XCMPLX-0K2 m) *XCMPLX-0K3 a"
          using newton_th_6 sorry
        also have "... = 0NUMBERSK6"
          using A12 sorry
        finally have "a  |^NEWTONK1 (n +XCMPLX-0K2 m) =HIDDENR1 0NUMBERSK6"
           sorry
        have "n -RootPREPOWERK2 a =COMPLEX1R1 0NUMBERSK6"
          using A2 A12 prepower_def_2 sorry
        thus " False "
          using A4 A6 A13 prepower_def_2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_27:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <=XXREAL-0R1 b) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a <=XXREAL-0R1 n -RootPREPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (a <=XXREAL-0R1 b & (n >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 a >XXREAL-0R4 n -RootPREPOWERK2 b)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "a <=XXREAL-0R1 b"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "n -RootPREPOWERK2 a >XXREAL-0R4 n -RootPREPOWERK2 b"
    have A5: "n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "b >XXREAL-0R4 0NUMBERSK6 or b =COMPLEX1R1 0NUMBERSK6"
          using A1 A2 sorry
        have case1: "b >XXREAL-0R4 0NUMBERSK6 implies n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume "b >XXREAL-0R4 0NUMBERSK6"
          thus "n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
            using A3 prepower_def_2 sorry
        qed
        have case2: "b =COMPLEX1R1 0NUMBERSK6 implies n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume "b =COMPLEX1R1 0NUMBERSK6"
          thus "n -RootPREPOWERK2 b >=XXREAL-0R2 0NUMBERSK6"
            using A3 prepower_def_2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a"
      using A1 A3 prepower_th_19 sorry
    then have "n -RootPREPOWERK2 a  |^NEWTONK1 n <=XXREAL-0R1 n -RootPREPOWERK2 b  |^NEWTONK1 n"
      using A1 A2 A3 prepower_th_19 sorry
    thus " False "
      using A3 A4 A5 prepower_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (a >=XXREAL-0R2 0NUMBERSK6 & a <XXREAL-0R3 b) & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & (a <XXREAL-0R3 b & (n >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 a >=XXREAL-0R2 n -RootPREPOWERK2 b)) implies  False "
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 b"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A4: "n -RootPREPOWERK2 a >=XXREAL-0R2 n -RootPREPOWERK2 b"
    have "n -RootPREPOWERK2 a  |^NEWTONK1 n =COMPLEX1R1 a"
      using A1 A3 prepower_th_19 sorry
    then have A5: "n -RootPREPOWERK2 a  |^NEWTONK1 n <XXREAL-0R3 n -RootPREPOWERK2 b  |^NEWTONK1 n"
      using A1 A2 A3 prepower_lm_2 sorry
    have "n -RootPREPOWERK2 b >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 A3 prepower_def_2 sorry
    thus " False "
      using A4 A5 prepower_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_29:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -RootPREPOWERK2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a >=XXREAL-0R2 \<one>\<^sub>M & a >=XXREAL-0R2 n -RootPREPOWERK2 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n -RootPREPOWERK2 a >=XXREAL-0R2 n -RootPREPOWERK2 \<one>\<^sub>M"
      using A1 A2 prepower_th_27 sorry
    thus "n -RootPREPOWERK2 a >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 prepower_th_20 sorry
    have "n -RootPREPOWERK2 a <=XXREAL-0R1 n -RootPREPOWERK2 (a  |^NEWTONK1 n)"
      using A1 A2 prepower_th_12 prepower_th_27 sorry
    thus "a >=XXREAL-0R2 n -RootPREPOWERK2 a"
      using A1 A2 prepower_lm_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_30:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds (0NUMBERSK6 <=XXREAL-0R1 a & a <XXREAL-0R3 \<one>\<^sub>M) & n >=XXREAL-0R2 \<one>\<^sub>M implies a <=XXREAL-0R1 n -RootPREPOWERK2 a & n -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a & (a <XXREAL-0R3 \<one>\<^sub>M & n >=XXREAL-0R2 \<one>\<^sub>M) implies a <=XXREAL-0R1 n -RootPREPOWERK2 a &  not n -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI,rule conjMI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "0NUMBERSK6 <=XXREAL-0R1 a"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have A4: "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
    proof-
      show "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
      proof-
        have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
          using A1 sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume "a >XXREAL-0R4 0NUMBERSK6"
          thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
            using prepower_th_6 sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
        proof(rule impI)
          assume "a =COMPLEX1R1 0NUMBERSK6"
          thus "a  |^NEWTONK1 n >=XXREAL-0R2 0NUMBERSK6"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    have "a  |^NEWTONK1 n <=XXREAL-0R1 a"
    proof-
      show "a  |^NEWTONK1 n <=XXREAL-0R1 a"
      proof-
        have cases: "a >XXREAL-0R4 0NUMBERSK6 or a =COMPLEX1R1 0NUMBERSK6"
          using A1 sorry
        have case1: "a >XXREAL-0R4 0NUMBERSK6 implies a  |^NEWTONK1 n <=XXREAL-0R1 a"
        proof(rule impI)
          assume "a >XXREAL-0R4 0NUMBERSK6"
          thus "a  |^NEWTONK1 n <=XXREAL-0R1 a"
            using A2 A3 prepower_th_14 sorry
        qed
        have case2: "a =COMPLEX1R1 0NUMBERSK6 implies a  |^NEWTONK1 n <=XXREAL-0R1 a"
        proof(rule impI)
          assume "a =COMPLEX1R1 0NUMBERSK6"
          thus "a  |^NEWTONK1 n <=XXREAL-0R1 a"
            using A3 newton_th_11 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    then have "n -RootPREPOWERK2 (a  |^NEWTONK1 n) <=XXREAL-0R1 n -RootPREPOWERK2 a"
      using A3 A4 prepower_th_27 sorry
    thus "a <=XXREAL-0R1 n -RootPREPOWERK2 a"
      using A1 A3 prepower_th_19 sorry
    have "n -RootPREPOWERK2 a <XXREAL-0R3 n -RootPREPOWERK2 \<one>\<^sub>M"
      using A1 A2 A3 prepower_th_28 sorry
    thus " not n -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
      using A3 prepower_th_20 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_31:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have "n -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 prepower_def_2 sorry
    then have "n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have "(\<one>\<^sub>M +XCMPLX-0K2 (n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)) |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
      using prepower_th_16 sorry
    then have "a >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 n *XCMPLX-0K3 (n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
      using A1 A2 prepower_lm_2 sorry
    then have "a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 n *XCMPLX-0K3 (n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
      using xreal_1_th_19 sorry
    then have "(a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n >=XXREAL-0R2 (n *XCMPLX-0K3 (n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 n"
      using xreal_1_th_72 sorry
    thus "n -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 n"
      using A2 xcmplx_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_32:
" for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies \<two>\<^sub>M -RootPREPOWERK2 a =COMPLEX1R1 sqrtSQUARE-1K3 a"
proof-
  have " for a be RealXREAL-0M1 holds a >=XXREAL-0R2 0NUMBERSK6 & \<two>\<^sub>M -RootPREPOWERK2 a <>HIDDENR2 sqrtSQUARE-1K3 a implies  False "
  proof(rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "\<two>\<^sub>M -RootPREPOWERK2 a <>HIDDENR2 sqrtSQUARE-1K3 a"
    have A3: "sqrtSQUARE-1K3 a >=XXREAL-0R2 0NUMBERSK6"
      using A1 square_1_def_2 sorry
    have "sqrtSQUARE-1K3 a  |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 (sqrtSQUARE-1K3 a)^2SQUARE-1K1"
      using newton_th_81 sorry
    also have "... = a"
      using A1 square_1_def_2 sorry
    finally have "sqrtSQUARE-1K3 a  |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 a"
       sorry
    thus " False "
      using A2 A3 prepower_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_3:
" for s be Real-SequenceSEQ-1M1 holds  for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for s be Real-SequenceSEQ-1M1 holds  for a be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI,rule conjMI)
    let ?s2 = "seq-constSEQ-1K1 \<one>\<^sub>M"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
    let ?O = "\<lambda>Lamb1. (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s1 where
      [ty]:"s1 be Real-SequenceSEQ-1M1" and 
      A2: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    let ?s3 = "?s2 +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1"
    have A3: "s1 be convergentSEQ-2V5"
      using A2 seq_4_th_31 sorry
    then have A4: "?s3 be convergentSEQ-2V5"
       sorry
    assume A5: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a"
    have A6: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 \<one>\<^sub>M).FUNCT-1K1 n <=XXREAL-0R1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 \<one>\<^sub>M +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A7: "n +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      let ?b = "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M"
      have A8: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =HIDDENR1 s .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
        using nat_1_def_3 sorry
      also have "... = (n +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
        using A5 A7 sorry
      finally have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
         sorry
      then have A9: "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n >=XXREAL-0R2 \<one>\<^sub>M"
        using A1 A7 prepower_th_29 sorry
      then have "(s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
        using xreal_1_th_48 sorry
      then have A10: "-XCMPLX-0K4 \<one>\<^sub>M <XXREAL-0R3 ?b"
         sorry
      have "a =COMPLEX1R1 (\<one>\<^sub>M +XCMPLX-0K2 ?b) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
        using A1 A7 A8 prepower_lm_2 sorry
      then have "a >=XXREAL-0R2 \<one>\<^sub>M +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 ?b"
        using A10 prepower_th_16 sorry
      then have "a -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 (\<one>\<^sub>M +XCMPLX-0K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 ?b)-XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      then have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 ?b)"
        using xreal_1_th_64 sorry
      then have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 ((n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 ?b"
         sorry
      then have "(a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 ?b"
        using xcmplx_0_def_7 sorry
      then have "(a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 ((s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
        using xreal_1_th_6 sorry
      then have "?s2 .FUNCT-1K1 n +XCMPLX-0K2 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n"
        using seq_1_th_57 sorry
      then have "?s2 .FUNCT-1K1 n +XCMPLX-0K2 s1 .FUNCT-1K1 n >=XXREAL-0R2 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n"
        using A2 sorry
      thus "(seq-constSEQ-1K1 \<one>\<^sub>M).FUNCT-1K1 n <=XXREAL-0R1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n & (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M).FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 \<one>\<^sub>M +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 n"
        using A9 seq_1_th_57 seq_1_th_7 sorry
    qed "sorry"
    have "limSEQ-2K1 s1 =COMPLEX1R1 0NUMBERSK6"
      using A2 seq_4_th_31 sorry
    then have A11: "limSEQ-2K1 ?s3 =HIDDENR1 ?s2 .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 0NUMBERSK6"
      using A3 seq_4_th_42 sorry
    also have "... = \<one>\<^sub>M"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?s3 =HIDDENR1 \<one>\<^sub>M"
       sorry
    have A12: "limSEQ-2K1 ?s2 =HIDDENR1 ?s2 .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = \<one>\<^sub>M"
      using seq_1_th_57 sorry
    finally have "limSEQ-2K1 ?s2 =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A13: "s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M be convergentSEQ-2V5"
      using A4 A11 A6 seq_2_th_19 sorry
    thus "s be convergentSEQ-2V5"
      using seq_4_th_21 sorry
    have "limSEQ-2K1 (s ^\\VALUED-0K1\<^bsub>(REALNUMBERSK2)\<^esub> \<one>\<^sub>M) =COMPLEX1R1 \<one>\<^sub>M"
      using A4 A11 A12 A6 seq_2_th_20 sorry
    thus "limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
      using A13 seq_4_th_22 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_33:
" for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Real-SequenceSEQ-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (( for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a) implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Real-SequenceSEQ-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    assume A2: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 a"
    show "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
    proof-
      have cases: "a >=XXREAL-0R2 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
         sorry
      have case1: "a >=XXREAL-0R2 \<one>\<^sub>M implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "a >=XXREAL-0R2 \<one>\<^sub>M"
        thus "s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
          using A2 prepower_lm_3 sorry
      qed
      have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
      proof(rule impI,rule conjMI)
        assume A3: "a <XXREAL-0R3 \<one>\<^sub>M"
        then have "a /XCMPLX-0K7 a <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A1 xreal_1_th_74 sorry
        then have A4: "\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A1 xcmplx_1_th_60 sorry
        let ?O = "\<lambda>Lamb1. Lamb1 -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a)"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A5: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using seq_1_sch_1 sorry
        have A6: " for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M implies s1 .FUNCT-1K1 n =COMPLEX1R1 n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a)"
          using A5 sorry
        then have A7: "limSEQ-2K1 s1 =COMPLEX1R1 \<one>\<^sub>M"
          using A4 prepower_lm_3 sorry
        have A8: "s1 be convergentSEQ-2V5"
          using A4 A6 prepower_lm_3 sorry
        have A9: " for b be RealXREAL-0M1 holds b >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b)"
        proof(rule ballI,rule impI)
          fix b assume [ty]: "b be RealXREAL-0M1"
          assume "b >XXREAL-0R4 0NUMBERSK6"
          then obtain m1 where
            [ty]:"m1 be NatNAT-1M1" and 
            A10: " for m be NatNAT-1M1 holds m1 <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
            using A8 A7 seq_2_def_7 sorry
          obtain n where 
            [ty]:"n be NatNAT-1M1" and nDef:"n = m1 +NAT-1K1 \<one>\<^sub>M"
             sorry
          show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A11: "n <=XXREAL-0R1 m"
            have A12: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            then have A13: "\<one>\<^sub>M <=XXREAL-0R1 m"
              using A11 xxreal_0_th_2 sorry
            then have A14: "m -RootPREPOWERK2 a <XXREAL-0R3 \<one>\<^sub>M"
              using A1 A3 prepower_th_30 sorry
            have A15: "m -RootPREPOWERK2 a <>HIDDENR2 0NUMBERSK6"
              using A1 A13 prepower_def_2 sorry
            then have A16: " |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 m -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 m -RootPREPOWERK2 a -XCMPLX-0K6 m -RootPREPOWERK2 a /XCMPLX-0K7 m -RootPREPOWERK2 a .|"
              using xcmplx_1_th_60 sorry
            also have "... =  |.COMPLEX1K10 (\<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a)/XCMPLX-0K7 m -RootPREPOWERK2 a .|"
               sorry
            also have "... =  |.COMPLEX1K10 (\<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a)*XCMPLX-0K3 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5 .|"
               sorry
            also have "... = ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a .|)*XCMPLX-0K3 ( |.COMPLEX1K10 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5.|)"
              using complex1_th_65 sorry
            finally have " |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 m -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a .|)*XCMPLX-0K3 ( |.COMPLEX1K10 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5.|)"
               sorry
            have "0NUMBERSK6 <XXREAL-0R3 m -RootPREPOWERK2 a"
              using A1 A3 A13 prepower_th_30 sorry
            then have "m -RootPREPOWERK2 a *XCMPLX-0K3 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5 <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5"
              using A14 xreal_1_th_68 sorry
            then have "\<one>\<^sub>M <XXREAL-0R3 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5"
              using A15 xcmplx_0_def_7 sorry
            then have A17: "\<one>\<^sub>M <XXREAL-0R3  |.COMPLEX1K10 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5.|"
              using absvalue_def_1 sorry
            have "0NUMBERSK6 <>HIDDENR2 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a"
              using A1 A3 A13 prepower_th_30 sorry
            then have " |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a .| >XXREAL-0R4 0NUMBERSK6"
              using complex1_th_47 sorry
            then have A18: "\<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a .|) <XXREAL-0R3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 m -RootPREPOWERK2 a .|)*XCMPLX-0K3 ( |.COMPLEX1K10 (m -RootPREPOWERK2 a)\<inverse>XCMPLX-0K5.|)"
              using A17 xreal_1_th_68 sorry
            have "m1 <=XXREAL-0R1 n"
              using xreal_1_th_29 sorry
            then have "m1 <=XXREAL-0R1 m"
              using A11 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
              using A10 sorry
            then have " |.COMPLEX1K10 m -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
              using A5 sorry
            then have " |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 m -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
              using A1 A13 prepower_th_23 sorry
            then have " |.COMPLEX1K10 -XCMPLX-0K4 (m -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M) .| <XXREAL-0R3 b"
              using A16 A18 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 m -RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
              using complex1_th_52 sorry
            thus " |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 b"
              using A2 A12 A11 xxreal_0_th_2 sorry
          qed "sorry"
        qed "sorry"
        thus "s be convergentSEQ-2V5"
          using seq_2_def_6 sorry
        thus "limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
          using A9 seq_2_def_7 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_3 (" _ #ZPREPOWERK3  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "k be IntegerINT-1M1"
"func a #ZPREPOWERK3 k \<rightarrow> numberORDINAL1M2 equals
  a  |^NEWTONK1 ( |.INT-2K1 k.|) if k >=XXREAL-0R2 0NUMBERSK6,
  (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 if k <XXREAL-0R3 0NUMBERSK6"
proof-
  (*consistency*)
    show " for it be numberORDINAL1M2 holds k >=XXREAL-0R2 0NUMBERSK6 & k <XXREAL-0R3 0NUMBERSK6 implies (it =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 k.|) iff it =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5)"
       sorry
  (*coherence*)
    show "(k >=XXREAL-0R2 0NUMBERSK6 implies a  |^NEWTONK1 ( |.INT-2K1 k.|) be numberORDINAL1M2) & (k <XXREAL-0R3 0NUMBERSK6 implies (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 be numberORDINAL1M2)"
      using tarski_th_1 sorry
qed "sorry"

mtheorem prepower_cl_3:
  mlet "a be RealXREAL-0M1", "k be IntegerINT-1M1"
"cluster a #ZPREPOWERK3 k as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "a #ZPREPOWERK3 k be realXREAL-0V1"
  proof-
    have "a #ZPREPOWERK3 k =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 k.|) or a #ZPREPOWERK3 k =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
      using prepower_def_3 sorry
    thus "a #ZPREPOWERK3 k be realXREAL-0V1"
       sorry
  qed
qed "sorry"

mtheorem prepower_th_34:
" for a be RealXREAL-0M1 holds a #ZPREPOWERK3 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a #ZPREPOWERK3 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a #ZPREPOWERK3 (0NUMBERSK6) =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 0NUMBERSK6 .|)"
      using prepower_def_3 sorry
    also have "... = a  |^NEWTONK1 (0NUMBERSK6)"
      using absvalue_th_2 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
      using prepower_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_3 sorry
    finally show "a #ZPREPOWERK3 (0NUMBERSK6) =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_35:
" for a be RealXREAL-0M1 holds a #ZPREPOWERK3 \<one>\<^sub>M =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds a #ZPREPOWERK3 \<one>\<^sub>M =HIDDENR1 a"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    have "a #ZPREPOWERK3 \<one>\<^sub>M =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 \<one>\<^sub>M.|)"
      using prepower_def_3 sorry
    also have "... = a  |^NEWTONK1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using absvalue_def_1 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)"
      using prepower_def_1 sorry
    also have "... = a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6) *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = \<one>\<^sub>M *XCMPLX-0K3 a"
      using prepower_th_3 sorry
    also have "... = a"
       sorry
    finally show "a #ZPREPOWERK3 \<one>\<^sub>M =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_36:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a #ZPREPOWERK3 n =COMPLEX1R1 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds a #ZPREPOWERK3 n =HIDDENR1 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "a #ZPREPOWERK3 n =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 n.|)"
      using prepower_def_3 sorry
    also have "... = a  |^NEWTONK1 n"
      using absvalue_def_1 sorry
    finally show "a #ZPREPOWERK3 n =HIDDENR1 a  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_4:
"\<one>\<^sub>M \<inverse>XCMPLX-0K5 =COMPLEX1R1 \<one>\<^sub>M"
   sorry

mtheorem prepower_th_37:
" for k be IntegerINT-1M1 holds \<one>\<^sub>M #ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for k be IntegerINT-1M1 holds \<one>\<^sub>M #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix k assume [ty]: "k be IntegerINT-1M1"
    show "\<one>\<^sub>M #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M"
    proof-
      have cases: "k >=XXREAL-0R2 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 implies \<one>\<^sub>M #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M"
      proof(rule impI)
        assume "k >=XXREAL-0R2 0NUMBERSK6"
        then have "\<one>\<^sub>M #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M  |^NEWTONK11 ( |.INT-2K1 k.|)"
          using prepower_def_3 sorry
        also have "... = \<one>\<^sub>M"
           sorry
        finally show "\<one>\<^sub>M #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M"
           sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies \<one>\<^sub>M #ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M"
      proof(rule impI)
        assume "k <XXREAL-0R3 0NUMBERSK6"
        have "\<one>\<^sub>M #ZPREPOWERK3 k =COMPLEX1R1 (\<one>\<^sub>M  |^NEWTONK11 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        thus "\<one>\<^sub>M #ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_38:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies  not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    show " not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
    proof-
      have cases: "k >=XXREAL-0R2 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 implies  not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
      proof(rule impI)
        assume "k >=XXREAL-0R2 0NUMBERSK6"
        then have "a #ZPREPOWERK3 k =COMPLEX1R1 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using prepower_def_3 sorry
        thus " not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_5 sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies  not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
      proof(rule impI)
        assume "k <XXREAL-0R3 0NUMBERSK6"
        then have "a #ZPREPOWERK3 k =COMPLEX1R1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        thus " not a #ZPREPOWERK3 k <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_5 xcmplx_1_th_202 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_39:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies  not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    show " not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
    proof-
      have cases: "k >=XXREAL-0R2 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 implies  not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume "k >=XXREAL-0R2 0NUMBERSK6"
        then have "a #ZPREPOWERK3 k =COMPLEX1R1 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using prepower_def_3 sorry
        thus " not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies  not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
      proof(rule impI)
        assume A2: "k <XXREAL-0R3 0NUMBERSK6"
        have A3: "a  |^NEWTONK1 ( |.INT-2K1 k.|) >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        have "a #ZPREPOWERK3 k =COMPLEX1R1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using A2 prepower_def_3 sorry
        thus " not a #ZPREPOWERK3 k >XXREAL-0R4 0NUMBERSK6"
          using A3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_40:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (a *XCMPLX-0K3 b)#ZPREPOWERK3 k =COMPLEX1R1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    show "(a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
    proof-
      have cases: "k >=XXREAL-0R2 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
      proof(rule impI)
        assume A1: "k >=XXREAL-0R2 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 (a *XCMPLX-0K3 b) |^NEWTONK1 ( |.INT-2K1 k.|)"
          using prepower_def_3 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 b  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using newton_th_7 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 b  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using A1 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
          using A1 prepower_def_3 sorry
        finally show "(a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
           sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
      proof(rule impI)
        assume A2: "k <XXREAL-0R3 0NUMBERSK6"
        then have "(a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 ((a *XCMPLX-0K3 b) |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 b  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using newton_th_7 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (b  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_204 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 (b  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using A2 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
          using A2 prepower_def_3 sorry
        finally show "(a *XCMPLX-0K3 b)#ZPREPOWERK3 k =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 b #ZPREPOWERK3 k"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_41:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a #ZPREPOWERK3 (-XCMPLX-0K4 k) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    show "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
    proof-
      have cases: "(k >XXREAL-0R4 0NUMBERSK6 or k =COMPLEX1R1 0NUMBERSK6) or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >XXREAL-0R4 0NUMBERSK6 implies a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
      proof(rule impI)
        assume A1: "k >XXREAL-0R4 0NUMBERSK6"
        then have "-XCMPLX-0K4 k <XXREAL-0R3 -XCMPLX-0K4 0NUMBERSK6"
           sorry
        then have "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 -XCMPLX-0K4 k .|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using complex1_th_52 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
           sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
          using A1 prepower_def_3 sorry
        finally show "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
      qed
      have case2: "k =COMPLEX1R1 0NUMBERSK6 implies a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
      proof(rule impI)
        assume A2: "k =COMPLEX1R1 0NUMBERSK6"
        then have "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 \<one>\<^sub>M"
          using prepower_th_34 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a GeoSeqPREPOWERK1 .FUNCT-1K1 (0NUMBERSK6)"
          using prepower_th_3 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (0NUMBERSK6)"
          using prepower_def_1 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
          using A2 prepower_th_36 sorry
        finally show "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
      qed
      have case3: "k <XXREAL-0R3 0NUMBERSK6 implies a #ZPREPOWERK3 (-XCMPLX-0K4 k) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
      proof(rule impI)
        assume A3: "k <XXREAL-0R3 0NUMBERSK6"
        then have "a #ZPREPOWERK3 k =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
           sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 -XCMPLX-0K4 k .|)"
          using complex1_th_52 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 (-XCMPLX-0K4 k)"
          using A3 prepower_def_3 sorry
        finally have "a #ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 (-XCMPLX-0K4 k)"
           sorry
        thus "a #ZPREPOWERK3 (-XCMPLX-0K4 k) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_42:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds (\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
  proof(rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    show "(\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
    proof-
      have cases: "k >=XXREAL-0R2 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
      proof(rule impI)
        assume A1: "k >=XXREAL-0R2 0NUMBERSK6"
        then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 ( |.INT-2K1 k.|)"
          using prepower_def_3 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using prepower_th_7 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
          using A1 prepower_def_3 sorry
        finally show "(\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
      proof(rule impI)
        assume A2: "k <XXREAL-0R3 0NUMBERSK6"
        then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 ((\<one>\<^sub>M /XCMPLX-0K7 a) |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_def_3 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using prepower_th_7 sorry
        also have "... = ((a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = (a #ZPREPOWERK3 k)\<inverse>XCMPLX-0K5"
          using A2 prepower_def_3 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
        finally show "(\<one>\<^sub>M /XCMPLX-0K7 a)#ZPREPOWERK3 k =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 k"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_43:
" for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    show "a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
    proof-
      have cases: "m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 or m -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
      proof(rule impI)
        assume "m -XCMPLX-0K6 n >=XXREAL-0R2 0NUMBERSK6"
        then obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = m -XCMPLX-0K6 n"
          using int_1_th_3 sorry
        have A2: "a #ZPREPOWERK3 (m -XCMPLX-0K6 n) *XCMPLX-0K3 a  |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 m1 *XCMPLX-0K3 a  |^NEWTONK1 n"
          using prepower_th_36 sorry
        also have "... = a  |^NEWTONK1 (m1 +XCMPLX-0K2 n)"
          using newton_th_8 sorry
        also have "... = a  |^NEWTONK1 m"
           sorry
        finally have "a #ZPREPOWERK3 (m -XCMPLX-0K6 n) *XCMPLX-0K3 a  |^NEWTONK1 n =HIDDENR1 a  |^NEWTONK1 m"
           sorry
        have "a  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_5 sorry
        thus "a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
          using A2 xcmplx_1_th_89 sorry
      qed
      have case2: "m -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6 implies a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
      proof(rule impI)
        assume "m -XCMPLX-0K6 n <XXREAL-0R3 0NUMBERSK6"
        then have "-XCMPLX-0K4 (m -XCMPLX-0K6 n) >XXREAL-0R4 0NUMBERSK6"
           sorry
        then obtain m1 where 
          [ty]:"m1 be ElementSUBSET-1M1-of NATNUMBERSK1" and m1Def:"m1 = n -XCMPLX-0K6 m"
          using int_1_th_3 sorry
        have A3: "a #ZPREPOWERK3 (n -XCMPLX-0K6 m) =HIDDENR1 a #ZPREPOWERK3 (-XCMPLX-0K4 (m -XCMPLX-0K6 n))"
           sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 (m -XCMPLX-0K6 n)"
          using prepower_th_41 sorry
        finally have "a #ZPREPOWERK3 (n -XCMPLX-0K6 m) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 (m -XCMPLX-0K6 n)"
           sorry
        have "a #ZPREPOWERK3 (n -XCMPLX-0K6 m) *XCMPLX-0K3 a  |^NEWTONK1 m =HIDDENR1 a  |^NEWTONK1 m1 *XCMPLX-0K3 a  |^NEWTONK1 m"
          using prepower_th_36 sorry
        also have "... = a  |^NEWTONK1 (m1 +XCMPLX-0K2 m)"
          using newton_th_8 sorry
        also have "... = a  |^NEWTONK1 n"
           sorry
        finally have "a #ZPREPOWERK3 (n -XCMPLX-0K6 m) *XCMPLX-0K3 a  |^NEWTONK1 m =HIDDENR1 a  |^NEWTONK1 n"
           sorry
        then have A4: "a  |^NEWTONK1 m /XCMPLX-0K7 a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 n"
          using A3 sorry
        have "a  |^NEWTONK1 n <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_5 sorry
        thus "a #ZPREPOWERK3 (m -XCMPLX-0K6 n) =COMPLEX1R1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
          using A4 xcmplx_1_th_54 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_44:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =COMPLEX1R1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds a <>HIDDENR2 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    fix l assume [ty]: "l be IntegerINT-1M1"
    assume A1: "a <>HIDDENR2 0NUMBERSK6"
    show "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
    proof-
      have cases: "((k >=XXREAL-0R2 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6 or k >=XXREAL-0R2 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6) or k <XXREAL-0R3 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6) or k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "k >=XXREAL-0R2 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
      proof(rule impI)
        assume A2: "k >=XXREAL-0R2 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6"
        then have A3: "k *XCMPLX-0K3 l >=XXREAL-0R2 0NUMBERSK6"
           sorry
        have "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a  |^NEWTONK1 ( |.INT-2K1 k +XCMPLX-0K2 l .|)"
          using A2 prepower_def_3 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.| +NAT-1K1  |.INT-2K1 l.|)"
          using A3 absvalue_th_11 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 a  |^NEWTONK1 ( |.INT-2K1 l.|)"
          using newton_th_8 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 a  |^NEWTONK1 ( |.INT-2K1 l.|)"
          using A2 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
          using A2 prepower_def_3 sorry
        finally show "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
           sorry
      qed
      have case2: "k >=XXREAL-0R2 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
      proof(rule impI)
        assume A4: "k >=XXREAL-0R2 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
        then obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = k"
          using int_1_th_3 sorry
        obtain n where 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = -XCMPLX-0K4 l"
          using A4 int_1_th_3 sorry
        have "k +XCMPLX-0K2 l =COMPLEX1R1 m -XCMPLX-0K6 n"
           sorry
        then have "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
          using A1 prepower_th_43 sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 (a  |^NEWTONK1 n)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 (a  |^NEWTONK1 n)\<inverse>XCMPLX-0K5"
          using absvalue_def_1 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 -XCMPLX-0K4 l .|))\<inverse>XCMPLX-0K5"
          using absvalue_def_1 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using complex1_th_52 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using A4 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
          using A4 prepower_def_3 sorry
        finally show "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
           sorry
      qed
      have case3: "k <XXREAL-0R3 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
      proof(rule impI)
        assume A5: "k <XXREAL-0R3 0NUMBERSK6 & l >=XXREAL-0R2 0NUMBERSK6"
        then obtain m where 
          [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and mDef:"m = l"
          using int_1_th_3 sorry
        obtain n where 
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = -XCMPLX-0K4 k"
          using A5 int_1_th_3 sorry
        have "k +XCMPLX-0K2 l =COMPLEX1R1 m -XCMPLX-0K6 n"
           sorry
        then have "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a  |^NEWTONK1 m /XCMPLX-0K7 a  |^NEWTONK1 n"
          using A1 prepower_th_43 sorry
        also have "... = a  |^NEWTONK1 m *XCMPLX-0K3 (a  |^NEWTONK1 n)\<inverse>XCMPLX-0K5"
           sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 l.|) *XCMPLX-0K3 (a  |^NEWTONK1 n)\<inverse>XCMPLX-0K5"
          using absvalue_def_1 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 l.|) *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 -XCMPLX-0K4 k .|))\<inverse>XCMPLX-0K5"
          using absvalue_def_1 sorry
        also have "... = a  |^NEWTONK1 ( |.INT-2K1 l.|) *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using complex1_th_52 sorry
        also have "... = a #ZPREPOWERK3 l *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using A5 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
          using A5 prepower_def_3 sorry
        finally show "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
           sorry
      qed
      have case4: "k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6 implies a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
      proof(rule impI)
        assume A6: "k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
        then have A7: "k *XCMPLX-0K3 l >=XXREAL-0R2 0NUMBERSK6"
           sorry
        have "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 (a  |^NEWTONK1 ( |.INT-2K1 k +XCMPLX-0K2 l .|))\<inverse>XCMPLX-0K5"
          using A6 prepower_def_3 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.| +NAT-1K1  |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using A7 absvalue_th_11 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|) *XCMPLX-0K3 a  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using newton_th_8 sorry
        also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using xcmplx_1_th_204 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 (a  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
          using A6 prepower_def_3 sorry
        also have "... = a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
          using A6 prepower_def_3 sorry
        finally show "a #ZPREPOWERK3 (k +XCMPLX-0K2 l) =HIDDENR1 a #ZPREPOWERK3 k *XCMPLX-0K3 a #ZPREPOWERK3 l"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_45:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =COMPLEX1R1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds  for l be IntegerINT-1M1 holds (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
  proof(rule ballI,rule ballI,rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    fix l assume [ty]: "l be IntegerINT-1M1"
    show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
    proof-
      have cases: "(k *XCMPLX-0K3 l >XXREAL-0R4 0NUMBERSK6 or k *XCMPLX-0K3 l <XXREAL-0R3 0NUMBERSK6) or k *XCMPLX-0K3 l =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "k *XCMPLX-0K3 l >XXREAL-0R4 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
      proof(rule impI)
        assume A1: "k *XCMPLX-0K3 l >XXREAL-0R4 0NUMBERSK6"
        show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
        proof-
          have cases: "k >XXREAL-0R4 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
            using A1 xreal_1_th_134 sorry
          have case1: "k >XXREAL-0R4 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume A2: "k >XXREAL-0R4 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 k  |^NEWTONK1 ( |.INT-2K1 l.|)"
              using prepower_def_3 sorry
            also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|)"
              using A2 prepower_def_3 sorry
            also have "... = a  |^NEWTONK1 (( |.INT-2K1 k.|)*NAT-1K2 ( |.INT-2K1 l.|))"
              using newton_th_9 sorry
            also have "... = a  |^NEWTONK1 ( |.INT-2K1 k *XCMPLX-0K3 l .|)"
              using complex1_th_65 sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A1 prepower_def_3 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          have case2: "k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume A3: "k <XXREAL-0R3 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 (a #ZPREPOWERK3 k  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
              using prepower_def_3 sorry
            also have "... = ((a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
              using A3 prepower_def_3 sorry
            also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
               sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
              using prepower_th_7 sorry
            also have "... = (((a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5"
               sorry
            also have "... = a  |^NEWTONK1 (( |.INT-2K1 k.|)*NAT-1K2 ( |.INT-2K1 l.|))"
              using newton_th_9 sorry
            also have "... = a  |^NEWTONK1 ( |.INT-2K1 k *XCMPLX-0K3 l .|)"
              using complex1_th_65 sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A1 prepower_def_3 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "k *XCMPLX-0K3 l <XXREAL-0R3 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
      proof(rule impI)
        assume A4: "k *XCMPLX-0K3 l <XXREAL-0R3 0NUMBERSK6"
        show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
        proof-
          have cases: "k <XXREAL-0R3 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6 or k >XXREAL-0R4 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
            using A4 xreal_1_th_133 sorry
          have case1: "k <XXREAL-0R3 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume A5: "k <XXREAL-0R3 0NUMBERSK6 & l >XXREAL-0R4 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 k  |^NEWTONK1 ( |.INT-2K1 l.|)"
              using prepower_def_3 sorry
            also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5  |^NEWTONK1 ( |.INT-2K1 l.|)"
              using A5 prepower_def_3 sorry
            also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|)"
               sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 (a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|)"
              using prepower_th_7 sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 (( |.INT-2K1 k.|)*NAT-1K2 ( |.INT-2K1 l.|))"
              using newton_th_9 sorry
            also have "... = \<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k *XCMPLX-0K3 l .|)"
              using complex1_th_65 sorry
            also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k *XCMPLX-0K3 l .|))\<inverse>XCMPLX-0K5"
               sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A4 prepower_def_3 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          have case2: "k >XXREAL-0R4 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume A6: "k >XXREAL-0R4 0NUMBERSK6 & l <XXREAL-0R3 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 (a #ZPREPOWERK3 k  |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
              using prepower_def_3 sorry
            also have "... = ((a  |^NEWTONK1 ( |.INT-2K1 k.|)) |^NEWTONK1 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5"
              using A6 prepower_def_3 sorry
            also have "... = (a  |^NEWTONK1 (( |.INT-2K1 k.|)*NAT-1K2 ( |.INT-2K1 l.|)))\<inverse>XCMPLX-0K5"
              using newton_th_9 sorry
            also have "... = (a  |^NEWTONK1 ( |.INT-2K1 k *XCMPLX-0K3 l .|))\<inverse>XCMPLX-0K5"
              using complex1_th_65 sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A4 prepower_def_3 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case3: "k *XCMPLX-0K3 l =COMPLEX1R1 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
      proof(rule impI)
        assume A7: "k *XCMPLX-0K3 l =COMPLEX1R1 0NUMBERSK6"
        show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
        proof-
          have cases: "k =COMPLEX1R1 0NUMBERSK6 or l =COMPLEX1R1 0NUMBERSK6"
            using A7 sorry
          have case1: "k =COMPLEX1R1 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume "k =COMPLEX1R1 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 \<one>\<^sub>M #ZPREPOWERK3 l"
              using prepower_th_34 sorry
            also have "... = \<one>\<^sub>M"
              using prepower_th_37 sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A7 prepower_th_34 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          have case2: "l =COMPLEX1R1 0NUMBERSK6 implies (a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
          proof(rule impI)
            assume "l =COMPLEX1R1 0NUMBERSK6"
            then have "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 \<one>\<^sub>M"
              using prepower_th_34 sorry
            also have "... = a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
              using A7 prepower_th_34 sorry
            finally show "(a #ZPREPOWERK3 k)#ZPREPOWERK3 l =HIDDENR1 a #ZPREPOWERK3 (k *XCMPLX-0K3 l)"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_46:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =COMPLEX1R1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds  for k be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & n >=XXREAL-0R2 \<one>\<^sub>M implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "n >=XXREAL-0R2 \<one>\<^sub>M"
    have A3: "n -RootPREPOWERK2 a >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 prepower_def_2 sorry
    have A4: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 \<one>\<^sub>M implies n -RootPREPOWERK2 a  |^NEWTONK1 m =COMPLEX1R1 n -RootPREPOWERK2 (a  |^NEWTONK1 m)"
    proof-
      have " for m be NatNAT-1M1 holds m >=XXREAL-0R2 \<one>\<^sub>M & n -RootPREPOWERK2 a  |^NEWTONK1 m <>HIDDENR2 n -RootPREPOWERK2 (a  |^NEWTONK1 m) implies  False "
      proof(rule ballI,rule impMI ,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A5: "m >=XXREAL-0R2 \<one>\<^sub>M"
          and A6: "n -RootPREPOWERK2 a  |^NEWTONK1 m <>HIDDENR2 n -RootPREPOWERK2 (a  |^NEWTONK1 m)"
        have A7: "a  |^NEWTONK1 m >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        then have A8: "n -RootPREPOWERK2 (a  |^NEWTONK1 m) >=XXREAL-0R2 0NUMBERSK6"
          using A2 prepower_def_2 sorry
        have A9: "m -RootPREPOWERK2 (n -RootPREPOWERK2 (a  |^NEWTONK1 m)) =HIDDENR1 (n *XCMPLX-0K3 m)-RootPREPOWERK2 (a  |^NEWTONK1 m)"
          using A2 A5 A7 prepower_th_25 sorry
        also have "... = n -RootPREPOWERK2 (m -RootPREPOWERK2 (a  |^NEWTONK1 m))"
          using A2 A5 A7 prepower_th_25 sorry
        also have "... = n -RootPREPOWERK2 a"
          using A1 A5 prepower_lm_2 sorry
        finally have "m -RootPREPOWERK2 (n -RootPREPOWERK2 (a  |^NEWTONK1 m)) =HIDDENR1 n -RootPREPOWERK2 a"
           sorry
        have A10: "m -RootPREPOWERK2 (n -RootPREPOWERK2 a  |^NEWTONK1 m) =COMPLEX1R1 n -RootPREPOWERK2 a"
          using A3 A5 prepower_lm_2 sorry
        have A11: "n -RootPREPOWERK2 a  |^NEWTONK1 m >=XXREAL-0R2 0NUMBERSK6"
          using A3 prepower_th_6 sorry
        show " False "
        proof-
          have cases: "n -RootPREPOWERK2 a  |^NEWTONK1 m <XXREAL-0R3 n -RootPREPOWERK2 (a  |^NEWTONK1 m) or n -RootPREPOWERK2 a  |^NEWTONK1 m >XXREAL-0R4 n -RootPREPOWERK2 (a  |^NEWTONK1 m)"
            using A6 xxreal_0_th_1 sorry
          have case1: "n -RootPREPOWERK2 a  |^NEWTONK1 m <XXREAL-0R3 n -RootPREPOWERK2 (a  |^NEWTONK1 m) implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 a  |^NEWTONK1 m <XXREAL-0R3 n -RootPREPOWERK2 (a  |^NEWTONK1 m)"
            thus " False "
              using A5 A9 A11 prepower_lm_2 sorry
          qed
          have case2: "n -RootPREPOWERK2 a  |^NEWTONK1 m >XXREAL-0R4 n -RootPREPOWERK2 (a  |^NEWTONK1 m) implies  False "
          proof(rule impI)
            assume "n -RootPREPOWERK2 a  |^NEWTONK1 m >XXREAL-0R4 n -RootPREPOWERK2 (a  |^NEWTONK1 m)"
            thus " False "
              using A5 A9 A10 A8 prepower_th_28 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
    proof-
      have cases: "(k >XXREAL-0R4 0NUMBERSK6 or k <XXREAL-0R3 0NUMBERSK6) or k =COMPLEX1R1 0NUMBERSK6"
         sorry
      have case1: "k >XXREAL-0R4 0NUMBERSK6 implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
      proof(rule impI)
        assume A12: "k >XXREAL-0R4 0NUMBERSK6"
        then have " |.INT-2K1 k.| >XXREAL-0R4 0NUMBERSK6"
          using absvalue_def_1 sorry
        then have A13: " |.INT-2K1 k.| >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        have "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 a  |^NEWTONK1 ( |.INT-2K1 k.|)"
          using A12 prepower_def_3 sorry
        also have "... = n -RootPREPOWERK2 (a  |^NEWTONK1 ( |.INT-2K1 k.|))"
          using A4 A13 sorry
        also have "... = n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
          using A12 prepower_def_3 sorry
        finally show "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
           sorry
      qed
      have case2: "k <XXREAL-0R3 0NUMBERSK6 implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
      proof(rule impI)
        assume A14: "k <XXREAL-0R3 0NUMBERSK6"
        then have " |.INT-2K1 k.| >XXREAL-0R4 0NUMBERSK6"
          using complex1_th_47 sorry
        then have A15: " |.INT-2K1 k.| >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        have A16: "a  |^NEWTONK1 ( |.INT-2K1 k.|) >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_6 sorry
        have "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 (n -RootPREPOWERK2 a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
          using A14 prepower_def_3 sorry
        also have "... = (n -RootPREPOWERK2 (a  |^NEWTONK1 ( |.INT-2K1 k.|)))\<inverse>XCMPLX-0K5"
          using A4 A15 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 n -RootPREPOWERK2 (a  |^NEWTONK1 ( |.INT-2K1 k.|))"
           sorry
        also have "... = n -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a  |^NEWTONK1 ( |.INT-2K1 k.|))"
          using A2 A16 prepower_th_23 sorry
        also have "... = n -RootPREPOWERK2 (a  |^NEWTONK1 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5"
           sorry
        also have "... = n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
          using A14 prepower_def_3 sorry
        finally show "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =HIDDENR1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
           sorry
      qed
      have case3: "k =COMPLEX1R1 0NUMBERSK6 implies (n -RootPREPOWERK2 a)#ZPREPOWERK3 k =COMPLEX1R1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
      proof(rule impI)
        assume A17: "k =COMPLEX1R1 0NUMBERSK6"
        then have "n -RootPREPOWERK2 (a #ZPREPOWERK3 k) =HIDDENR1 n -RootPREPOWERK2 \<one>\<^sub>M"
          using prepower_th_34 sorry
        also have "... = \<one>\<^sub>M"
          using A2 prepower_th_20 sorry
        finally have "n -RootPREPOWERK2 (a #ZPREPOWERK3 k) =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus "(n -RootPREPOWERK2 a)#ZPREPOWERK3 k =COMPLEX1R1 n -RootPREPOWERK2 (a #ZPREPOWERK3 k)"
          using A17 prepower_th_34 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_4 (" _ #QPREPOWERK4  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "p be RationalRAT-1M1"
"func a #QPREPOWERK4 p \<rightarrow> numberORDINAL1M2 equals
  denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p)"
proof-
  (*coherence*)
    show "denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) be numberORDINAL1M2"
      using tarski_th_1 sorry
qed "sorry"

mtheorem prepower_cl_4:
  mlet "a be RealXREAL-0M1", "p be RationalRAT-1M1"
"cluster a #QPREPOWERK4 p as-term-is realXREAL-0V1"
proof
(*coherence*)
  show "a #QPREPOWERK4 p be realXREAL-0V1"
     sorry
qed "sorry"

mtheorem prepower_th_47:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds p =COMPLEX1R1 0NUMBERSK6 implies a #QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds p =COMPLEX1R1 0NUMBERSK6 implies a #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    obtain i where 
      [ty]:"i be IntegerINT-1M1" and iDef:"i = 0NUMBERSK6"
       sorry
    assume A1: "p =COMPLEX1R1 0NUMBERSK6"
    have "numeratorRAT-1K3 p =COMPLEX1R1 0NUMBERSK6"
      using A1 rat_1_th_14 sorry
    then have "a #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M -RootPREPOWERK2 (a #ZPREPOWERK3 i)"
      using A1 rat_1_th_19 sorry
    also have "... = \<one>\<^sub>M -RootPREPOWERK2 \<one>\<^sub>M"
      using prepower_th_34 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_21 sorry
    finally show "a #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_48:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & p =COMPLEX1R1 \<one>\<^sub>M implies a #QPREPOWERK4 p =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & p =COMPLEX1R1 \<one>\<^sub>M implies a #QPREPOWERK4 p =HIDDENR1 a"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "p =COMPLEX1R1 \<one>\<^sub>M"
    have A3: "denominatorRAT-1K2 p =COMPLEX1R1 \<one>\<^sub>M"
      using A2 rat_1_th_17 sorry
    have "numeratorRAT-1K3 p =COMPLEX1R1 p"
      using A2 rat_1_th_17 sorry
    then have "a #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M -RootPREPOWERK2 a"
      using A2 A3 prepower_th_35 sorry
    also have "... = a"
      using A1 prepower_th_21 sorry
    finally show "a #QPREPOWERK4 p =HIDDENR1 a"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_5:
" for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for k be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix k assume [ty]: "k be IntegerINT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
    show "a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "a =COMPLEX1R1 0NUMBERSK6 or a >XXREAL-0R4 0NUMBERSK6"
        using A1 sorry
      have case1: "a =COMPLEX1R1 0NUMBERSK6 implies a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume A2: "a =COMPLEX1R1 0NUMBERSK6"
        have " |.INT-2K1 k.| =COMPLEX1R1 0NUMBERSK6 or  |.INT-2K1 k.| >=XXREAL-0R2 \<one>\<^sub>M"
          using nat_1_th_14 sorry
        then have "((0NUMBERSK6) |^NEWTONK11 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 =COMPLEX1R1 (0NUMBERSK6)\<inverse>XCMPLX-0K5 or ((0NUMBERSK6) |^NEWTONK11 ( |.INT-2K1 k.|))\<inverse>XCMPLX-0K5 =COMPLEX1R1 \<one>\<^sub>M \<inverse>XCMPLX-0K5"
          using newton_th_4 newton_th_11 sorry
        thus "a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
          using A2 prepower_def_3 sorry
      qed
      have case2: "a >XXREAL-0R4 0NUMBERSK6 implies a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "a >XXREAL-0R4 0NUMBERSK6"
        thus "a #ZPREPOWERK3 k >=XXREAL-0R2 0NUMBERSK6"
          using prepower_th_39 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_49:
" for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies a #QPREPOWERK4 n =COMPLEX1R1 a  |^NEWTONK1 n"
proof-
  have " for a be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <=XXREAL-0R1 a implies a #QPREPOWERK4 n =HIDDENR1 a  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "denominatorRAT-1K2 n =COMPLEX1R1 \<one>\<^sub>M"
      using rat_1_th_17 sorry
    have A2: "numeratorRAT-1K3 n =COMPLEX1R1 n"
      using rat_1_th_17 sorry
    assume "0NUMBERSK6 <=XXREAL-0R1 a"
    then have "a #QPREPOWERK4 n =HIDDENR1 a #ZPREPOWERK3 n"
      using A1 A2 prepower_lm_5 prepower_th_21 sorry
    also have "... = a  |^NEWTONK1 n"
      using prepower_th_36 sorry
    finally show "a #QPREPOWERK4 n =HIDDENR1 a  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_50:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & p =COMPLEX1R1 n \<inverse>XCMPLX-0K5 implies a #QPREPOWERK4 p =COMPLEX1R1 n -RootPREPOWERK2 a"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for n be NatNAT-1M1 holds n >=XXREAL-0R2 \<one>\<^sub>M & p =COMPLEX1R1 n \<inverse>XCMPLX-0K5 implies a #QPREPOWERK4 p =COMPLEX1R1 n -RootPREPOWERK2 a"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "p =COMPLEX1R1 n \<inverse>XCMPLX-0K5"
    obtain q where 
      [ty]:"q be RationalRAT-1M1" and qDef:"q = n"
       sorry
    have A3: "p =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 n"
      using A2 sorry
    then have "denominatorRAT-1K2 p =COMPLEX1R1 numeratorRAT-1K3 q"
      using A1 rat_1_th_44 sorry
    then have A4: "denominatorRAT-1K2 p =COMPLEX1R1 n"
      using rat_1_th_17 sorry
    have "numeratorRAT-1K3 p =COMPLEX1R1 denominatorRAT-1K2 q"
      using A1 A3 rat_1_th_44 sorry
    then have "numeratorRAT-1K3 p =COMPLEX1R1 \<one>\<^sub>M"
      using rat_1_th_17 sorry
    thus "a #QPREPOWERK4 p =COMPLEX1R1 n -RootPREPOWERK2 a"
      using A4 prepower_th_35 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_51:
" for p be RationalRAT-1M1 holds \<one>\<^sub>M #QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for p be RationalRAT-1M1 holds \<one>\<^sub>M #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    have "\<one>\<^sub>M #QPREPOWERK4 p =HIDDENR1 denominatorRAT-1K2 p -RootPREPOWERK2 \<one>\<^sub>M"
      using prepower_th_37 sorry
    also have "... = \<one>\<^sub>M"
      using prepower_th_20 rat_1_th_11 sorry
    finally show "\<one>\<^sub>M #QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_52:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies  not a #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume "a >XXREAL-0R4 0NUMBERSK6"
    then have A1: "a #ZPREPOWERK3 numeratorRAT-1K3 p >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_39 sorry
    have "denominatorRAT-1K2 p >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    thus " not a #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
      using A1 prepower_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_53:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p +XCMPLX-0K2 q)"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 q =HIDDENR1 a #QPREPOWERK4 (p +XCMPLX-0K2 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    let ?dp = "denominatorRAT-1K2 p"
    let ?dq = "denominatorRAT-1K2 q"
    let ?np = "numeratorRAT-1K3 p"
    let ?nq = "numeratorRAT-1K3 q"
    have A1: "?dp >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    obtain ddq where 
      [ty]:"ddq be IntegerINT-1M1" and ddqDef:"ddq = ?dq"
       sorry
    obtain ddp where 
      [ty]:"ddp be IntegerINT-1M1" and ddpDef:"ddp = ?dp"
       sorry
    have A2: "denominatorRAT-1K2 (p +XCMPLX-0K2 q) >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    have A3: "?dq >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    then have A4: "?dp *XCMPLX-0K3 ?dq >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 xreal_1_th_159 sorry
    have "p +XCMPLX-0K2 q =HIDDENR1 ?np /XCMPLX-0K7 ?dp +XCMPLX-0K2 q"
      using rat_1_th_15 sorry
    also have "... = ?np /XCMPLX-0K7 ?dp +XCMPLX-0K2 ?nq /XCMPLX-0K7 ?dq"
      using rat_1_th_15 sorry
    also have "... = (?np *XCMPLX-0K3 ?dq +XCMPLX-0K2 ?nq *XCMPLX-0K3 ?dp)/XCMPLX-0K7 (?dp *XCMPLX-0K3 ?dq)"
      using xcmplx_1_th_116 sorry
    finally have "p +XCMPLX-0K2 q =HIDDENR1 (?np *XCMPLX-0K3 ?dq +XCMPLX-0K2 ?nq *XCMPLX-0K3 ?dp)/XCMPLX-0K7 (?dp *XCMPLX-0K3 ?dq)"
       sorry
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A5: "?np *XCMPLX-0K3 ?dq +XCMPLX-0K2 ?nq *XCMPLX-0K3 ?dp =COMPLEX1R1 numeratorRAT-1K3 (p +XCMPLX-0K2 q) *XCMPLX-0K3 n"and A6: "?dp *XCMPLX-0K3 ?dq =COMPLEX1R1 denominatorRAT-1K2 (p +XCMPLX-0K2 q) *XCMPLX-0K3 n"
      using rat_1_th_27 sorry
    obtain k where 
      [ty]:"k be IntegerINT-1M1" and kDef:"k = n"
       sorry
    assume A7: "a >XXREAL-0R4 0NUMBERSK6"
    then have A8: "a #ZPREPOWERK3 (?nq -XCMPLX-0K6 ?np) >=XXREAL-0R2 0NUMBERSK6"
      using prepower_th_39 sorry
    have "n >XXREAL-0R4 0NUMBERSK6"
      using A6 sorry
    then have A9: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have A10: "a #ZPREPOWERK3 ?np >XXREAL-0R4 0NUMBERSK6"
      using A7 prepower_th_39 sorry
    then have A11: "a #ZPREPOWERK3 ?np  |^NEWTONK1 (?dp +XCMPLX-0K2 ?dq) >=XXREAL-0R2 0NUMBERSK6"
      using prepower_th_6 sorry
    have A12: "a #ZPREPOWERK3 (?nq -XCMPLX-0K6 ?np) >XXREAL-0R4 0NUMBERSK6"
      using A7 prepower_th_39 sorry
    then have A13: "a #ZPREPOWERK3 (?nq -XCMPLX-0K6 ?np)  |^NEWTONK1 ?dp >=XXREAL-0R2 0NUMBERSK6"
      using prepower_th_6 sorry
    have A14: "a #QPREPOWERK4 (p +XCMPLX-0K2 q) >XXREAL-0R4 0NUMBERSK6"
      using A7 prepower_th_52 sorry
    have A15: "a #ZPREPOWERK3 numeratorRAT-1K3 (p +XCMPLX-0K2 q) >XXREAL-0R4 0NUMBERSK6"
      using A7 prepower_th_39 sorry
    have "a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 q =HIDDENR1 denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 p +XCMPLX-0K2 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)))"
       sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p *XCMPLX-0K3 a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p))"
      using A7 prepower_th_44 sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) *XCMPLX-0K3 (denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)))"
      using A10 A8 prepower_th_22 rat_1_th_11 sorry
    also have "... = (denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p))*XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p))"
       sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p  |^NEWTONK1 (denominatorRAT-1K2 p +XCMPLX-0K2 denominatorRAT-1K2 q)) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p))"
      using A10 A3 A1 prepower_th_26 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p  |^NEWTONK1 (denominatorRAT-1K2 p +XCMPLX-0K2 denominatorRAT-1K2 q)) *XCMPLX-0K3 denominatorRAT-1K2 q -RootPREPOWERK2 (denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)  |^NEWTONK1 denominatorRAT-1K2 p))"
      using A12 A1 prepower_lm_2 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p  |^NEWTONK1 (denominatorRAT-1K2 p +XCMPLX-0K2 denominatorRAT-1K2 q)) *XCMPLX-0K3 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)  |^NEWTONK1 denominatorRAT-1K2 p)"
      using A3 A1 A13 prepower_th_25 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p  |^NEWTONK1 (denominatorRAT-1K2 p +XCMPLX-0K2 denominatorRAT-1K2 q) *XCMPLX-0K3 a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)  |^NEWTONK1 denominatorRAT-1K2 p)"
      using A3 A1 A13 A11 prepower_th_22 xreal_1_th_159 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 ((a #ZPREPOWERK3 numeratorRAT-1K3 p)#ZPREPOWERK3 (ddp +XCMPLX-0K2 ddq) *XCMPLX-0K3 a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)  |^NEWTONK1 denominatorRAT-1K2 p)"
      using prepower_th_36 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 ((a #ZPREPOWERK3 numeratorRAT-1K3 p)#ZPREPOWERK3 (ddp +XCMPLX-0K2 ddq) *XCMPLX-0K3 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p))#ZPREPOWERK3 ddp)"
      using prepower_th_36 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 p *XCMPLX-0K3 (ddp +XCMPLX-0K2 ddq)) *XCMPLX-0K3 (a #ZPREPOWERK3 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p))#ZPREPOWERK3 ddp)"
      using prepower_th_45 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 p *XCMPLX-0K3 (ddp +XCMPLX-0K2 ddq)) *XCMPLX-0K3 a #ZPREPOWERK3 ((numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)*XCMPLX-0K3 ddp))"
      using prepower_th_45 sorry
    also have "... = (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)-RootPREPOWERK2 (a #ZPREPOWERK3 ((numeratorRAT-1K3 p *XCMPLX-0K3 ddp +XCMPLX-0K2 numeratorRAT-1K3 p *XCMPLX-0K3 ddq)+XCMPLX-0K2 (numeratorRAT-1K3 q -XCMPLX-0K6 numeratorRAT-1K3 p)*XCMPLX-0K3 ddp))"
      using A7 prepower_th_44 sorry
    also have "... = (denominatorRAT-1K2 (p +XCMPLX-0K2 q) *XCMPLX-0K3 n)-RootPREPOWERK2 ((a #ZPREPOWERK3 numeratorRAT-1K3 (p +XCMPLX-0K2 q))#ZPREPOWERK3 k)"
      using A5 A6 prepower_th_45 sorry
    also have "... = ((denominatorRAT-1K2 (p +XCMPLX-0K2 q) *XCMPLX-0K3 n)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 (p +XCMPLX-0K2 q)))#ZPREPOWERK3 k"
      using A4 A6 A15 prepower_th_46 sorry
    also have "... = (n *XCMPLX-0K3 denominatorRAT-1K2 (p +XCMPLX-0K2 q))-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 (p +XCMPLX-0K2 q))  |^NEWTONK1 n"
      using prepower_th_36 sorry
    also have "... = n -RootPREPOWERK2 (a #QPREPOWERK4 (p +XCMPLX-0K2 q))  |^NEWTONK1 n"
      using A9 A2 A15 prepower_th_25 sorry
    also have "... = a #QPREPOWERK4 (p +XCMPLX-0K2 q)"
      using A9 A14 prepower_lm_2 sorry
    finally show "a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 q =HIDDENR1 a #QPREPOWERK4 (p +XCMPLX-0K2 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_54:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 (-XCMPLX-0K4 p)"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 (-XCMPLX-0K4 p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume "a >XXREAL-0R4 0NUMBERSK6"
    then have A1: "a #ZPREPOWERK3 numeratorRAT-1K3 p >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_39 sorry
    have "a #QPREPOWERK4 (-XCMPLX-0K4 p) =HIDDENR1 denominatorRAT-1K2 (-XCMPLX-0K4 p) -RootPREPOWERK2 (a #ZPREPOWERK3 (-XCMPLX-0K4 numeratorRAT-1K3 p))"
      using rat_1_th_43 sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 (-XCMPLX-0K4 numeratorRAT-1K3 p))"
      using rat_1_th_43 sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 numeratorRAT-1K3 p)"
      using prepower_th_41 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
      using A1 prepower_th_23 rat_1_th_11 sorry
    finally show "a #QPREPOWERK4 (-XCMPLX-0K4 p) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_55:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p -XCMPLX-0K6 q)"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 (p -XCMPLX-0K6 q) =HIDDENR1 a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "a #QPREPOWERK4 (p -XCMPLX-0K6 q) =HIDDENR1 a #QPREPOWERK4 (p +XCMPLX-0K2 (-XCMPLX-0K4 q))"
       sorry
    also have "... = a #QPREPOWERK4 p *XCMPLX-0K3 a #QPREPOWERK4 (-XCMPLX-0K4 q)"
      using A1 prepower_th_53 sorry
    also have "... = a #QPREPOWERK4 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 q)"
      using A1 prepower_th_54 sorry
    also have "... = (a #QPREPOWERK4 p *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 a #QPREPOWERK4 q"
       sorry
    also have "... = a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q"
       sorry
    finally show "a #QPREPOWERK4 (p -XCMPLX-0K6 q) =HIDDENR1 a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_56:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 p *XCMPLX-0K3 b #QPREPOWERK4 p"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#QPREPOWERK4 p =HIDDENR1 a #QPREPOWERK4 p *XCMPLX-0K3 b #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have A3: "a #ZPREPOWERK3 numeratorRAT-1K3 p >=XXREAL-0R2 0NUMBERSK6"
      using A1 prepower_th_39 sorry
    have A4: "b #ZPREPOWERK3 numeratorRAT-1K3 p >=XXREAL-0R2 0NUMBERSK6"
      using A2 prepower_th_39 sorry
    have "(a *XCMPLX-0K3 b)#QPREPOWERK4 p =HIDDENR1 denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p *XCMPLX-0K3 b #ZPREPOWERK3 numeratorRAT-1K3 p)"
      using prepower_th_40 sorry
    also have "... = a #QPREPOWERK4 p *XCMPLX-0K3 b #QPREPOWERK4 p"
      using A3 A4 prepower_th_22 rat_1_th_11 sorry
    finally show "(a *XCMPLX-0K3 b)#QPREPOWERK4 p =HIDDENR1 a #QPREPOWERK4 p *XCMPLX-0K3 b #QPREPOWERK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_57:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p =HIDDENR1 denominatorRAT-1K2 p -RootPREPOWERK2 (\<one>\<^sub>M /XCMPLX-0K7 a #ZPREPOWERK3 numeratorRAT-1K3 p)"
      using prepower_th_42 sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 (-XCMPLX-0K4 numeratorRAT-1K3 p))"
      using prepower_th_41 sorry
    also have "... = denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 (-XCMPLX-0K4 p))"
      using rat_1_th_43 sorry
    also have "... = a #QPREPOWERK4 (-XCMPLX-0K4 p)"
      using rat_1_th_43 sorry
    also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
      using A1 prepower_th_54 sorry
    finally show "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_58:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK4 p /XCMPLX-0K7 b #QPREPOWERK4 p"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#QPREPOWERK4 p =HIDDENR1 a #QPREPOWERK4 p /XCMPLX-0K7 b #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have "(a /XCMPLX-0K7 b)#QPREPOWERK4 p =HIDDENR1 (a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b))#QPREPOWERK4 p"
       sorry
    also have "... = a #QPREPOWERK4 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b)#QPREPOWERK4 p"
      using A1 A2 prepower_th_56 sorry
    also have "... = a #QPREPOWERK4 p *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b #QPREPOWERK4 p)"
      using A2 prepower_th_57 sorry
    also have "... = a #QPREPOWERK4 p /XCMPLX-0K7 b #QPREPOWERK4 p"
       sorry
    finally show "(a /XCMPLX-0K7 b)#QPREPOWERK4 p =HIDDENR1 a #QPREPOWERK4 p /XCMPLX-0K7 b #QPREPOWERK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_59:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #QPREPOWERK4 p)#QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p *XCMPLX-0K3 q)"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #QPREPOWERK4 p)#QPREPOWERK4 q =HIDDENR1 a #QPREPOWERK4 (p *XCMPLX-0K3 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    have A1: "denominatorRAT-1K2 p >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    have "p =COMPLEX1R1 numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p"
      using rat_1_th_15 sorry
    then have "p *XCMPLX-0K3 q =HIDDENR1 (numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 (numeratorRAT-1K3 q /XCMPLX-0K7 denominatorRAT-1K2 q)"
      using rat_1_th_15 sorry
    also have "... = ((numeratorRAT-1K3 p /XCMPLX-0K7 denominatorRAT-1K2 p)*XCMPLX-0K3 numeratorRAT-1K3 q)/XCMPLX-0K7 denominatorRAT-1K2 q"
       sorry
    also have "... = (numeratorRAT-1K3 p *XCMPLX-0K3 numeratorRAT-1K3 q)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)"
      using xcmplx_1_th_83 sorry
    finally have "p *XCMPLX-0K3 q =HIDDENR1 (numeratorRAT-1K3 p *XCMPLX-0K3 numeratorRAT-1K3 q)/XCMPLX-0K7 (denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q)"
       sorry
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "numeratorRAT-1K3 p *XCMPLX-0K3 numeratorRAT-1K3 q =COMPLEX1R1 numeratorRAT-1K3 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n"and A3: "denominatorRAT-1K2 p *XCMPLX-0K3 denominatorRAT-1K2 q =COMPLEX1R1 denominatorRAT-1K2 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n"
      using rat_1_th_27 sorry
    have A4: "denominatorRAT-1K2 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A3 nat_1_th_13 sorry
    have "n >XXREAL-0R4 0NUMBERSK6"
      using A3 sorry
    then have A5: "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    obtain k where 
      [ty]:"k be IntegerINT-1M1" and kDef:"k = n"
       sorry
    have A6: "denominatorRAT-1K2 q >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    have A7: "denominatorRAT-1K2 (p *XCMPLX-0K3 q) >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    assume A8: "a >XXREAL-0R4 0NUMBERSK6"
    then have A9: "a #ZPREPOWERK3 (numeratorRAT-1K3 p *XCMPLX-0K3 numeratorRAT-1K3 q) >=XXREAL-0R2 0NUMBERSK6"
      using prepower_th_39 sorry
    have A10: "a #QPREPOWERK4 (p *XCMPLX-0K3 q) >XXREAL-0R4 0NUMBERSK6"
      using A8 prepower_th_52 sorry
    have A11: "a #ZPREPOWERK3 numeratorRAT-1K3 (p *XCMPLX-0K3 q) >XXREAL-0R4 0NUMBERSK6"
      using A8 prepower_th_39 sorry
    have "a #ZPREPOWERK3 numeratorRAT-1K3 p >XXREAL-0R4 0NUMBERSK6"
      using A8 prepower_th_39 sorry
    then have "(a #QPREPOWERK4 p)#QPREPOWERK4 q =HIDDENR1 denominatorRAT-1K2 q -RootPREPOWERK2 (denominatorRAT-1K2 p -RootPREPOWERK2 ((a #ZPREPOWERK3 numeratorRAT-1K3 p)#ZPREPOWERK3 numeratorRAT-1K3 q))"
      using prepower_th_46 rat_1_th_11 sorry
    also have "... = denominatorRAT-1K2 q -RootPREPOWERK2 (denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 p *XCMPLX-0K3 numeratorRAT-1K3 q)))"
      using prepower_th_45 sorry
    also have "... = (denominatorRAT-1K2 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n)-RootPREPOWERK2 (a #ZPREPOWERK3 (numeratorRAT-1K3 (p *XCMPLX-0K3 q) *XCMPLX-0K3 k))"
      using A1 A6 A9 A2 A3 prepower_th_25 sorry
    also have "... = (denominatorRAT-1K2 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n)-RootPREPOWERK2 ((a #ZPREPOWERK3 numeratorRAT-1K3 (p *XCMPLX-0K3 q))#ZPREPOWERK3 k)"
      using prepower_th_45 sorry
    also have "... = ((denominatorRAT-1K2 (p *XCMPLX-0K3 q) *XCMPLX-0K3 n)-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 (p *XCMPLX-0K3 q)))#ZPREPOWERK3 k"
      using A11 A4 prepower_th_46 sorry
    also have "... = (n *XCMPLX-0K3 denominatorRAT-1K2 (p *XCMPLX-0K3 q))-RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 (p *XCMPLX-0K3 q))  |^NEWTONK1 n"
      using prepower_th_36 sorry
    also have "... = n -RootPREPOWERK2 (a #QPREPOWERK4 (p *XCMPLX-0K3 q))  |^NEWTONK1 n"
      using A5 A7 A11 prepower_th_25 sorry
    also have "... = a #QPREPOWERK4 (p *XCMPLX-0K3 q)"
      using A5 A10 prepower_lm_2 sorry
    finally show "(a #QPREPOWERK4 p)#QPREPOWERK4 q =HIDDENR1 a #QPREPOWERK4 (p *XCMPLX-0K3 q)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_60:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 0NUMBERSK6 implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 0NUMBERSK6 implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "p >=XXREAL-0R2 0NUMBERSK6"
    have "numeratorRAT-1K3 p >=XXREAL-0R2 0NUMBERSK6"
      using A2 rat_1_th_37 sorry
    then obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = numeratorRAT-1K3 p"
      using int_1_th_3 sorry
    have A3: "a #ZPREPOWERK3 numeratorRAT-1K3 p =COMPLEX1R1 a  |^NEWTONK1 n"
      using prepower_th_36 sorry
    have "a  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M  |^NEWTONK11 n"
      using A1 prepower_th_9 sorry
    then have A4: "a #ZPREPOWERK3 numeratorRAT-1K3 p >=XXREAL-0R2 \<one>\<^sub>M"
      using A3 sorry
    have "denominatorRAT-1K2 p >=XXREAL-0R2 \<one>\<^sub>M"
      using rat_1_th_11 sorry
    thus "a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
      using A4 prepower_th_29 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_61:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p <=XXREAL-0R1 0NUMBERSK6 implies a #QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p <=XXREAL-0R1 0NUMBERSK6 implies a #QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "p <=XXREAL-0R1 0NUMBERSK6"
    have "a #QPREPOWERK4 (-XCMPLX-0K4 p) >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 prepower_th_60 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 prepower_th_54 sorry
    thus "a #QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
      using xreal_1_th_191 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_62:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 0NUMBERSK6 implies  not a #QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "p >XXREAL-0R4 0NUMBERSK6"
    have A3: "numeratorRAT-1K3 p >XXREAL-0R4 0NUMBERSK6"
      using A2 rat_1_th_38 sorry
    then obtain n where 
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and nDef:"n = numeratorRAT-1K3 p"
      using int_1_th_3 sorry
    have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using A3 nat_1_th_13 sorry
    then have A4: "a  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M  |^NEWTONK11 n"
      using A1 prepower_lm_1 sorry
    have "a #ZPREPOWERK3 numeratorRAT-1K3 p =COMPLEX1R1 a  |^NEWTONK1 n"
      using prepower_th_36 sorry
    then have "a #ZPREPOWERK3 numeratorRAT-1K3 p >XXREAL-0R4 \<one>\<^sub>M"
      using A4 sorry
    then have "denominatorRAT-1K2 p -RootPREPOWERK2 (a #ZPREPOWERK3 numeratorRAT-1K3 p) >XXREAL-0R4 denominatorRAT-1K2 p -RootPREPOWERK2 \<one>\<^sub>M"
      using prepower_th_28 rat_1_th_11 sorry
    thus " not a #QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
      using prepower_th_20 rat_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_63:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 q implies a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & p >=XXREAL-0R2 q implies a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "p >=XXREAL-0R2 q"
    show "a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
    proof-
      have cases: "p =COMPLEX1R1 q or p >XXREAL-0R4 q"
        using A2 xxreal_0_th_1 sorry
      have case1: "p =COMPLEX1R1 q implies a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
      proof(rule impI)
        assume "p =COMPLEX1R1 q"
        thus "a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
           sorry
      qed
      have case2: "p >XXREAL-0R4 q implies a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
      proof(rule impI)
        assume "p >XXREAL-0R4 q"
        then have A3: "p -XCMPLX-0K6 q >=XXREAL-0R2 0NUMBERSK6"
          using xreal_1_th_50 sorry
        have A4: "a #QPREPOWERK4 q <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_52 sorry
        have A5: "a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p -XCMPLX-0K6 q)"
          using A1 prepower_th_55 sorry
        have "a #QPREPOWERK4 q >=XXREAL-0R2 0NUMBERSK6"
          using A1 prepower_th_52 sorry
        then have "(a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q)*XCMPLX-0K3 a #QPREPOWERK4 q >=XXREAL-0R2 \<one>\<^sub>M *XCMPLX-0K3 a #QPREPOWERK4 q"
          using A1 A3 A5 prepower_th_60 xreal_1_th_64 sorry
        thus "a #QPREPOWERK4 p >=XXREAL-0R2 a #QPREPOWERK4 q"
          using A4 xcmplx_1_th_87 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_64:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 q implies a #QPREPOWERK4 p >XXREAL-0R4 a #QPREPOWERK4 q"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds  for q be RationalRAT-1M1 holds a >XXREAL-0R4 \<one>\<^sub>M & p >XXREAL-0R4 q implies  not a #QPREPOWERK4 p >XXREAL-0R4 a #QPREPOWERK4 q"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix q assume [ty]: "q be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "p >XXREAL-0R4 q"
    have A3: "p -XCMPLX-0K6 q >XXREAL-0R4 0NUMBERSK6"
      using A2 xreal_1_th_50 sorry
    have A4: "a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q =COMPLEX1R1 a #QPREPOWERK4 (p -XCMPLX-0K6 q)"
      using A1 prepower_th_55 sorry
    have A5: "a #QPREPOWERK4 q <>HIDDENR2 0NUMBERSK6"
      using A1 prepower_th_52 sorry
    have "a #QPREPOWERK4 q >XXREAL-0R4 0NUMBERSK6"
      using A1 prepower_th_52 sorry
    then have "(a #QPREPOWERK4 p /XCMPLX-0K7 a #QPREPOWERK4 q)*XCMPLX-0K3 a #QPREPOWERK4 q >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 a #QPREPOWERK4 q"
      using A1 A3 A4 prepower_th_62 xreal_1_th_68 sorry
    thus " not a #QPREPOWERK4 p >XXREAL-0R4 a #QPREPOWERK4 q"
      using A5 xcmplx_1_th_87 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_65:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <XXREAL-0R3 \<one>\<^sub>M) & p >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 p <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <XXREAL-0R3 \<one>\<^sub>M & p >XXREAL-0R4 0NUMBERSK6) implies  not a #QPREPOWERK4 p <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    obtain q where 
      [ty]:"q be RationalRAT-1M1" and qDef:"q = 0NUMBERSK6"
       sorry
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <XXREAL-0R3 \<one>\<^sub>M"
      and A3: "p >XXREAL-0R4 0NUMBERSK6"
    have "\<one>\<^sub>M /XCMPLX-0K7 a >XXREAL-0R4 \<one>\<^sub>M"
      using A1 A2 prepower_lm_4 xreal_1_th_88 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p >XXREAL-0R4 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 q"
      using A3 prepower_th_64 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
      using prepower_th_47 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 prepower_th_57 sorry
    thus " not a #QPREPOWERK4 p <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_185 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_66:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <=XXREAL-0R1 \<one>\<^sub>M) & p <=XXREAL-0R1 0NUMBERSK6 implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <=XXREAL-0R1 \<one>\<^sub>M & p <=XXREAL-0R1 0NUMBERSK6) implies a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "p <=XXREAL-0R1 0NUMBERSK6"
    have "\<one>\<^sub>M /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 prepower_lm_4 xreal_1_th_85 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
      using A3 prepower_th_61 sorry
    then have A4: "\<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 prepower_th_57 sorry
    have "a #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
      using A1 prepower_th_52 sorry
    thus "a #QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
      using A4 xreal_1_th_187 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_cl_5:
"cluster REALNUMBERSK2 -valuedRELAT-1V5 for Real-SequenceSEQ-1M1"
proof
(*existence*)
  show " ex it be Real-SequenceSEQ-1M1 st it be REALNUMBERSK2 -valuedRELAT-1V5"
  proof-
    have " ex tVar8 be Real-SequenceSEQ-1M1 st tVar8 be RATRAT-1K1 -valuedRELAT-1V5"
    proof-
      show " ex tVar8 be Real-SequenceSEQ-1M1 st tVar8 be RATRAT-1K1 -valuedRELAT-1V5"
      proof(rule bexI[of _ "seq-constSEQ-1K1 (0NUMBERSK6)"])
        show "seq-constSEQ-1K1 (0NUMBERSK6) be RATRAT-1K1 -valuedRELAT-1V5"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CD*)
syntax PREPOWERM1 :: "Ty" ("Rational-SequencePREPOWERM1" 70)
translations "Rational-SequencePREPOWERM1" \<rightharpoonup> "RATRAT-1K1 -valuedRELAT-1V5\<bar>Real-SequenceSEQ-1M1"

mtheorem prepower_th_67:
" for a be RealXREAL-0M1 holds  ex s be Rational-SequencePREPOWERM1 st (s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 a) & ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 a)"
proof-
  have " for a be RealXREAL-0M1 holds  ex tVar9 be Rational-SequencePREPOWERM1 st tVar9 be convergentSEQ-2V5 & (limSEQ-2K1 tVar9 =COMPLEX1R1 a & ( for n be NatNAT-1M1 holds tVar9 .FUNCT-1K1 n <=XXREAL-0R1 a))"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    let ?O = "\<lambda>Lamb1. ([\\INT-1K2 (Lamb1 +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])/XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s where
      [ty]:"s be Real-SequenceSEQ-1M1" and 
      A1: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    have "rngFUNCT-1K2 s c=TARSKIR1 RATRAT-1K1"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 s implies y inHIDDENR3 RATRAT-1K1"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 s"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A2: "s .FUNCT-1K1 n =HIDDENR1 y"
          using funct_2_th_113 sorry
        have "s .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using A1 sorry
        thus "y inHIDDENR3 RATRAT-1K1"
          using A2 rat_1_def_2 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 s c=TARSKIR1 RATRAT-1K1"
        using tarski_def_3 sorry
    qed
    then have 
      [ty]:"s be Rational-SequencePREPOWERM1"
      using relat_1_def_19 sorry
    let ?O = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    obtain a1 where 
      [ty]:"a1 be ElementSUBSET-1M1-of REALNUMBERSK2" and a1Def:"a1 = a"
      using xreal_0_def_1 sorry
    let ?s1 = "seq-constSEQ-1K1 a"
    show " ex tVar9 be Rational-SequencePREPOWERM1 st tVar9 be convergentSEQ-2V5 & (limSEQ-2K1 tVar9 =COMPLEX1R1 a & ( for n be NatNAT-1M1 holds tVar9 .FUNCT-1K1 n <=XXREAL-0R1 a))"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI,rule ballI)
      let ?s3 = "?s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
      have A4: "s2 be convergentSEQ-2V5"
        using A3 seq_4_th_31 sorry
      then have A5: "?s3 be convergentSEQ-2V5"
         sorry
      have A6: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 a -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n & s .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "(n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a <=XXREAL-0R1 [\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M"
          using int_1_th_29 sorry
        then have "(n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 ([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /] +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        then have "((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 ([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_64 sorry
        then have "(a /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 s .FUNCT-1K1 n"
          using A1 sorry
        then have "a -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 s .FUNCT-1K1 n"
          using xcmplx_1_th_87 sorry
        then have "?s1 .FUNCT-1K1 n -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 s .FUNCT-1K1 n"
          using seq_1_th_57 sorry
        then have A7: "?s1 .FUNCT-1K1 n -XCMPLX-0K6 s2 .FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n"
          using A3 sorry
        have "[\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /] <=XXREAL-0R1 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a"
          using int_1_def_6 sorry
        then have "([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (a *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using xreal_1_th_64 sorry
        then have "([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 a *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5)"
           sorry
        then have "([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 a *XCMPLX-0K3 \<one>\<^sub>M"
          using xcmplx_0_def_7 sorry
        then have "([\\INT-1K2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a /])/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 ?s1 .FUNCT-1K1 n"
          using seq_1_th_57 sorry
        thus "(seq-constSEQ-1K1 a -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n & s .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a).FUNCT-1K1 n"
          using A1 A7 rfunct_2_th_1 sorry
      qed "sorry"
      have "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6"
        using A3 seq_4_th_31 sorry
      then have A8: "limSEQ-2K1 ?s3 =HIDDENR1 ?s1 .FUNCT-1K1 (0NUMBERSK6) -XCMPLX-0K6 0NUMBERSK6"
        using A4 seq_4_th_42 sorry
      also have "... = a"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?s3 =HIDDENR1 a"
         sorry
      have A9: "limSEQ-2K1 ?s1 =HIDDENR1 ?s1 .FUNCT-1K1 (0NUMBERSK6)"
        using seq_4_th_26 sorry
      also have "... = a"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?s1 =HIDDENR1 a"
         sorry
      thus "s be convergentSEQ-2V5"
        using A5 A8 A6 seq_2_th_19 sorry
      show "limSEQ-2K1 s =COMPLEX1R1 a"
        using A5 A8 A9 A6 seq_2_th_20 sorry
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s .FUNCT-1K1 n <=XXREAL-0R1 ?s1 .FUNCT-1K1 n"
        using A6 sorry
      thus "s .FUNCT-1K1 n <=XXREAL-0R1 a"
        using seq_1_th_57 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_68:
" for a be RealXREAL-0M1 holds  ex s be Rational-SequencePREPOWERM1 st (s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 a) & ( for n be NatNAT-1M1 holds s .FUNCT-1K1 n >=XXREAL-0R2 a)"
proof-
  have " for a be RealXREAL-0M1 holds  ex tVar10 be Rational-SequencePREPOWERM1 st tVar10 be convergentSEQ-2V5 & (limSEQ-2K1 tVar10 =COMPLEX1R1 a & ( for n be NatNAT-1M1 holds tVar10 .FUNCT-1K1 n >=XXREAL-0R2 a))"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    let ?O = "\<lambda>Lamb1. ([/INT-1K3 (Lamb1 +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])/XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s where
      [ty]:"s be Real-SequenceSEQ-1M1" and 
      A1: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    have "rngFUNCT-1K2 s c=TARSKIR1 RATRAT-1K1"
    proof-
      have " for y be objectHIDDENM1 holds y inHIDDENR3 rngFUNCT-1K2 s implies y inHIDDENR3 RATRAT-1K1"
      proof(rule ballI,rule impI)
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "y inHIDDENR3 rngFUNCT-1K2 s"
        then obtain n where
          [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A2: "s .FUNCT-1K1 n =HIDDENR1 y"
          using funct_2_th_113 sorry
        have "s .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using A1 sorry
        thus "y inHIDDENR3 RATRAT-1K1"
          using A2 rat_1_def_2 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 s c=TARSKIR1 RATRAT-1K1"
        using tarski_def_3 sorry
    qed
    then have 
      [ty]:"s be Rational-SequencePREPOWERM1"
      using relat_1_def_19 sorry
    let ?O = "\<lambda>Lamb1. \<one>\<^sub>M /XCMPLX-0K7 (Lamb1 +NAT-1K1 \<one>\<^sub>M)"
    obtain s2 where
      [ty]:"s2 be Real-SequenceSEQ-1M1" and 
      A3: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    show " ex tVar10 be Rational-SequencePREPOWERM1 st tVar10 be convergentSEQ-2V5 & (limSEQ-2K1 tVar10 =COMPLEX1R1 a & ( for n be NatNAT-1M1 holds tVar10 .FUNCT-1K1 n >=XXREAL-0R2 a))"
    proof(rule bexI[of _ "s"],rule conjMI,rule conjMI,rule ballI)
      let ?s1 = "seq-constSEQ-1K1 a"
      let ?s3 = "?s1 +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2"
      have A4: "s2 be convergentSEQ-2V5"
        using A3 seq_4_th_31 sorry
      then have A5: "?s3 be convergentSEQ-2V5"
         sorry
      have A6: " for n be NatNAT-1M1 holds (seq-constSEQ-1K1 a).FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n & s .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 n"
      proof(rule ballI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have "(n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M >=XXREAL-0R2 [/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\]"
          using int_1_def_7 sorry
        then have "((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a +XCMPLX-0K2 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 ([/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M)"
          using xreal_1_th_64 sorry
        then have "(a /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 s .FUNCT-1K1 n"
          using A1 sorry
        then have "a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 s .FUNCT-1K1 n"
          using xcmplx_1_th_87 sorry
        then have "?s1 .FUNCT-1K1 n +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 s .FUNCT-1K1 n"
          using seq_1_th_57 sorry
        then have A7: "?s1 .FUNCT-1K1 n +XCMPLX-0K2 s2 .FUNCT-1K1 n >=XXREAL-0R2 s .FUNCT-1K1 n"
          using A3 sorry
        have "[/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\] >=XXREAL-0R2 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a"
          using int_1_def_7 sorry
        then have "([/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 (a *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using xreal_1_th_64 sorry
        then have "([/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 a *XCMPLX-0K3 ((n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5)"
           sorry
        then have "([/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])*XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 a *XCMPLX-0K3 \<one>\<^sub>M"
          using xcmplx_0_def_7 sorry
        then have "([/INT-1K3 (n +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 a \\])/XCMPLX-0K7 (n +NAT-1K1 \<one>\<^sub>M) >=XXREAL-0R2 ?s1 .FUNCT-1K1 n"
          using seq_1_th_57 sorry
        thus "(seq-constSEQ-1K1 a).FUNCT-1K1 n <=XXREAL-0R1 s .FUNCT-1K1 n & s .FUNCT-1K1 n <=XXREAL-0R1 (seq-constSEQ-1K1 a +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 n"
          using A1 A7 seq_1_th_7 sorry
      qed "sorry"
      have "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6"
        using A3 seq_4_th_31 sorry
      then have A8: "limSEQ-2K1 ?s3 =HIDDENR1 ?s1 .FUNCT-1K1 (0NUMBERSK6) +XCMPLX-0K2 0NUMBERSK6"
        using A4 seq_4_th_42 sorry
      also have "... = a"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?s3 =HIDDENR1 a"
         sorry
      have A9: "limSEQ-2K1 ?s1 =HIDDENR1 ?s1 .FUNCT-1K1 (0NUMBERSK6)"
        using seq_4_th_26 sorry
      also have "... = a"
        using seq_1_th_57 sorry
      finally have "limSEQ-2K1 ?s1 =HIDDENR1 a"
         sorry
      thus "s be convergentSEQ-2V5"
        using A5 A8 A6 seq_2_th_19 sorry
      show "limSEQ-2K1 s =COMPLEX1R1 a"
        using A5 A8 A9 A6 seq_2_th_20 sorry
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s .FUNCT-1K1 n >=XXREAL-0R2 ?s1 .FUNCT-1K1 n"
        using A6 sorry
      thus "s .FUNCT-1K1 n >=XXREAL-0R2 a"
        using seq_1_th_57 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_6 (" _ #QPREPOWERK5  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "s be Rational-SequencePREPOWERM1"
"func a #QPREPOWERK5 s \<rightarrow> Real-SequenceSEQ-1M1 means
  \<lambda>it.  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
proof-
  (*existence*)
    show " ex it be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds it .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
    proof-
      have " ex tVar11 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar11 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
      proof-
        let ?O = "\<lambda>Lamb1. a #QPREPOWERK4 (s .FUNCT-1K1 Lamb1)"
        obtain s1 where
          [ty]:"s1 be Real-SequenceSEQ-1M1" and 
          A1: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using seq_1_sch_1 sorry
        show " ex tVar11 be Real-SequenceSEQ-1M1 st  for n be NatNAT-1M1 holds tVar11 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
        proof(rule bexI[of _ "s1"])
          show " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
            using A1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Real-SequenceSEQ-1M1 holds  for it2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds it1 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) & ( for n be NatNAT-1M1 holds it2 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) implies it1 =HIDDENR1 it2"
    proof-
      have " for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)) implies s1 =HIDDENR1 s2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
        fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
        assume A2: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
          and A3: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
        have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
        proof(rule ballI)
          fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
          have "s1 .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
            using A2 sorry
          also have "... = s2 .FUNCT-1K1 n"
            using A3 sorry
          finally show "s1 .FUNCT-1K1 n =HIDDENR1 s2 .FUNCT-1K1 n"
             sorry
        qed "sorry"
        thus "s1 =HIDDENR1 s2"
          using funct_2_th_63 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mlemma prepower_lm_6:
" for s be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds s be convergentSEQ-2V5 & a >=XXREAL-0R2 \<one>\<^sub>M implies a #QPREPOWERK5 s be convergentSEQ-2V5"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix s assume [ty]: "s be Rational-SequencePREPOWERM1"
  fix a assume [ty]: "a be RealXREAL-0M1"
  assume A1: "s be convergentSEQ-2V5"
    and A2: "a >=XXREAL-0R2 \<one>\<^sub>M"
  have "s be boundedSEQ-2V6"
    using A1 sorry
  then obtain d where
    [ty]:"d be RealXREAL-0M1" and 
    "0NUMBERSK6 <XXREAL-0R3 d"and A3: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s .FUNCT-1K1 n.| <XXREAL-0R3 d"
    using seq_2_th_3 sorry
  obtain m2 where
    [ty]:"m2 be NatNAT-1M1" and 
    A4: "d <XXREAL-0R3 m2"
    using seq_4_th_3 sorry
  have 
    [ty]:"m2 be RationalRAT-1M1"
     sorry
  have " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c)"
  proof(rule ballI,rule impI)
    have A5: "a #QPREPOWERK4 m2 >=XXREAL-0R2 0NUMBERSK6"
      using A2 prepower_th_52 sorry
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A6: "c >XXREAL-0R4 0NUMBERSK6"
    obtain m1 where
      [ty]:"m1 be NatNAT-1M1" and 
      A7: "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1"
      using seq_4_th_3 sorry
    have "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 m1"
      using xreal_1_th_29 sorry
    then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1 +NAT-1K1 \<one>\<^sub>M"
      using A7 xxreal_0_th_2 sorry
    then have "((a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c)*XCMPLX-0K3 c <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
      using A6 xreal_1_th_68 sorry
    then have "a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
      using A6 xcmplx_1_th_87 sorry
    then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 ((m1 +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 c)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
      using xreal_1_th_74 sorry
    then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (c /XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
       sorry
    then have A8: "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 c"
      using xcmplx_1_th_87 sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n .| <XXREAL-0R3 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
      using A1 seq_4_th_41 sorry
    show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c"
    proof(rule bexI[of _ "n"],rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "m >=XXREAL-0R2 n"
      then have A10: " |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
        using A9 sorry
      have A11: "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using nat_1_th_13 sorry
      then have "(m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A2 prepower_th_31 sorry
      then have A12: "a #QPREPOWERK4 m2 *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 a #QPREPOWERK4 m2 *XCMPLX-0K3 ((a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))"
        using A5 xreal_1_th_64 sorry
      have A13: "a #QPREPOWERK4 (s .FUNCT-1K1 n) <>HIDDENR2 0NUMBERSK6"
        using A2 prepower_th_52 sorry
      have A14: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| =HIDDENR1  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n))*XCMPLX-0K3 \<one>\<^sub>M .|"
         sorry
      also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n))*XCMPLX-0K3 (a #QPREPOWERK4 (s .FUNCT-1K1 n) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n)) .|"
        using A13 xcmplx_1_th_60 sorry
      also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 n) *XCMPLX-0K3 (a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n)))/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|"
         sorry
      also have "... =  |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n) *XCMPLX-0K3 ((a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n))/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n)) .|"
         sorry
      also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n))/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)"
        using complex1_th_65 sorry
      also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)"
         sorry
      also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .|)"
        using A13 xcmplx_1_th_60 sorry
      also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .|)"
        using A2 prepower_th_55 sorry
      finally have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .|)"
         sorry
      have A15: "s .FUNCT-1K1 n <=XXREAL-0R1  |.COMPLEX1K10 s .FUNCT-1K1 n.|"
        using absvalue_th_4 sorry
      obtain m3 where 
        [ty]:"m3 be RationalRAT-1M1" and m3Def:"m3 = (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
         sorry
      have A16: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
        using complex1_th_46 sorry
      have A17: "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <>HIDDENR2 0NUMBERSK6"
        using A2 prepower_th_52 sorry
      have "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n <=XXREAL-0R1  |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n .|"
        using absvalue_th_4 sorry
      then have "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
        using A10 xxreal_0_th_2 sorry
      then have "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <=XXREAL-0R1 a #QPREPOWERK4 m3"
        using A2 prepower_th_63 sorry
      then have "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
        using A11 prepower_th_50 sorry
      then have A18: "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
        using xreal_1_th_9 sorry
      have A19: "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) >XXREAL-0R4 0NUMBERSK6"
        using A2 prepower_th_52 sorry
      have A20: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
      proof-
        show " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
        proof-
          have cases: "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6 or s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
             sorry
          have case1: "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          proof(rule impI)
            assume "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
            then have "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) >=XXREAL-0R2 \<one>\<^sub>M"
              using A2 prepower_th_60 sorry
            then have "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using xreal_1_th_48 sorry
            thus " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
              using A18 absvalue_def_1 sorry
          qed
          have case2: "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          proof(rule impI)
            assume A21: "s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n <XXREAL-0R3 0NUMBERSK6"
            have A22: "-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|"
              using absvalue_th_4 sorry
            have " |.COMPLEX1K10 s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n .| =COMPLEX1R1  |.COMPLEX1K10 -XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|"
              using complex1_th_52 sorry
            then have "-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <=XXREAL-0R1 m3"
              using A10 A22 xxreal_0_th_2 sorry
            then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) <=XXREAL-0R1 a #QPREPOWERK4 m3"
              using A2 prepower_th_63 sorry
            then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
              using A11 prepower_th_50 sorry
            then have A23: "a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
              using xreal_1_th_9 sorry
            have "a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) >=XXREAL-0R2 \<one>\<^sub>M"
              using A2 A21 prepower_th_60 sorry
            then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
              using xreal_1_th_48 sorry
            then have A24: " |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
              using A23 absvalue_def_1 sorry
            have "a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) <=XXREAL-0R1 \<one>\<^sub>M"
              using A2 A21 prepower_th_61 sorry
            then have A25: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).| <=XXREAL-0R1 \<one>\<^sub>M"
              using A19 absvalue_def_1 sorry
            have " |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
              using complex1_th_46 sorry
            then have A26: "( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
              using A25 xreal_1_th_64 sorry
            have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M .|"
               sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) .|"
              using A17 xcmplx_1_th_60 sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) *XCMPLX-0K3 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|"
               sorry
            also have "... =  |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) *XCMPLX-0K3 ((a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) .|"
               sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|)"
              using complex1_th_65 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|)"
               sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) .|)"
              using A17 xcmplx_1_th_60 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) .|)"
              using A2 prepower_th_54 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 -XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n))) .|)"
              using complex1_th_52 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
               sorry
            finally have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
               sorry
            thus " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
              using A24 A26 xxreal_0_th_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have A27: "a #QPREPOWERK4 (s .FUNCT-1K1 n) >XXREAL-0R4 0NUMBERSK6"
        using A2 prepower_th_52 sorry
      have " |.COMPLEX1K10 s .FUNCT-1K1 n.| <=XXREAL-0R1 m2"
        using A3 A4 xxreal_0_th_2 sorry
      then have "s .FUNCT-1K1 n <=XXREAL-0R1 m2"
        using A15 xxreal_0_th_2 sorry
      then have "a #QPREPOWERK4 (s .FUNCT-1K1 n) <=XXREAL-0R1 a #QPREPOWERK4 m2"
        using A2 prepower_th_63 sorry
      then have A28: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).| <=XXREAL-0R1 a #QPREPOWERK4 m2"
        using A27 absvalue_def_1 sorry
      have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).| >=XXREAL-0R2 0NUMBERSK6"
        using A27 absvalue_def_1 sorry
      then have "( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m -XCMPLX-0K6 s .FUNCT-1K1 n) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 a #QPREPOWERK4 m2 *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
        using A20 A16 A28 xreal_1_th_66 sorry
      then have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <=XXREAL-0R1 (a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A14 A12 xxreal_0_th_2 sorry
      then have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <XXREAL-0R3 c"
        using A8 xxreal_0_th_2 sorry
      then have " |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <XXREAL-0R3 c"
        using prepower_def_6 sorry
      thus " |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c"
        using prepower_def_6 sorry
    qed "sorry"
  qed "sorry"
  thus "a #QPREPOWERK5 s be convergentSEQ-2V5"
    using seq_4_th_41 sorry
qed "sorry"

mtheorem prepower_th_69:
" for a be RealXREAL-0M1 holds  for s be Rational-SequencePREPOWERM1 holds s be convergentSEQ-2V5 & a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK5 s be convergentSEQ-2V5"
proof-
  have " for a be RealXREAL-0M1 holds  for s be Rational-SequencePREPOWERM1 holds s be convergentSEQ-2V5 & a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK5 s be convergentSEQ-2V5"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s assume [ty]: "s be Rational-SequencePREPOWERM1"
    assume A1: "s be convergentSEQ-2V5"
      and A2: "a >XXREAL-0R4 0NUMBERSK6"
    show "a #QPREPOWERK5 s be convergentSEQ-2V5"
    proof-
      have cases: "a >=XXREAL-0R2 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
         sorry
      have case1: "a >=XXREAL-0R2 \<one>\<^sub>M implies a #QPREPOWERK5 s be convergentSEQ-2V5"
      proof(rule impI)
        assume "a >=XXREAL-0R2 \<one>\<^sub>M"
        thus "a #QPREPOWERK5 s be convergentSEQ-2V5"
          using A1 prepower_lm_6 sorry
      qed
      have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies a #QPREPOWERK5 s be convergentSEQ-2V5"
      proof(rule impI)
        assume A3: "a <XXREAL-0R3 \<one>\<^sub>M"
        then have "a /XCMPLX-0K7 a <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A2 xreal_1_th_74 sorry
        then have "\<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A2 xcmplx_1_th_60 sorry
        then have A4: "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s be convergentSEQ-2V5"
          using A1 prepower_lm_6 sorry
        have "s be boundedSEQ-2V6"
          using A1 sorry
        then obtain d where
          [ty]:"d be RealXREAL-0M1" and 
          "0NUMBERSK6 <XXREAL-0R3 d"and A5: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s .FUNCT-1K1 n.| <XXREAL-0R3 d"
          using seq_2_th_3 sorry
        have 
          [ty]:"d be RealXREAL-0M1"
           sorry
        obtain m1 where
          [ty]:"m1 be NatNAT-1M1" and 
          A6: "\<two>\<^sub>M *XCMPLX-0K3 d <XXREAL-0R3 m1"
          using seq_4_th_3 sorry
        have 
          [ty]:"m1 be RationalRAT-1M1"
           sorry
        have A7: "a #QPREPOWERK4 m1 >XXREAL-0R4 0NUMBERSK6"
          using A2 prepower_th_52 sorry
        have " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c)"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be RealXREAL-0M1"
          assume A8: "c >XXREAL-0R4 0NUMBERSK6"
          then have "c *XCMPLX-0K3 a #QPREPOWERK4 m1 >XXREAL-0R4 0NUMBERSK6"
            using A7 sorry
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A9: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c *XCMPLX-0K3 a #QPREPOWERK4 m1"
            using A4 seq_4_th_41 sorry
          show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "m >=XXREAL-0R2 n"
            then have A10: " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c *XCMPLX-0K3 a #QPREPOWERK4 m1"
              using A9 sorry
            have A11: "a #QPREPOWERK4 (s .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
              using A2 prepower_th_52 sorry
            have A12: "a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) >XXREAL-0R4 0NUMBERSK6"
              using A2 prepower_th_52 sorry
            have " |.COMPLEX1K10 s .FUNCT-1K1 m.| <XXREAL-0R3 d"
              using A5 sorry
            then have A13: " |.COMPLEX1K10 s .FUNCT-1K1 m.| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 n.| <XXREAL-0R3 d +XCMPLX-0K2 d"
              using A5 xreal_1_th_8 sorry
            have " |.COMPLEX1K10 s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n .| <=XXREAL-0R1  |.COMPLEX1K10 s .FUNCT-1K1 m.| +XCMPLX-0K2  |.COMPLEX1K10 s .FUNCT-1K1 n.|"
              using complex1_th_56 sorry
            then have " |.COMPLEX1K10 s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n .| <XXREAL-0R3 d +XCMPLX-0K2 d"
              using A13 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n .| <XXREAL-0R3 m1"
              using A6 xxreal_0_th_2 sorry
            then have A14: " |.COMPLEX1K10 -XCMPLX-0K4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) .| <XXREAL-0R3 m1"
              using complex1_th_52 sorry
            have "-XCMPLX-0K4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) .|"
              using absvalue_th_4 sorry
            then have "-XCMPLX-0K4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) <XXREAL-0R3 m1"
              using A14 xxreal_0_th_2 sorry
            then have A15: "m1 -XCMPLX-0K6 (-XCMPLX-0K4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)) >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_50 sorry
            have A16: "a #QPREPOWERK4 (s .FUNCT-1K1 n) <>HIDDENR2 0NUMBERSK6"
              using A2 prepower_th_52 sorry
            have " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 n .| =HIDDENR1  |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 n .|"
              using prepower_def_6 sorry
            also have "... =  |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s .FUNCT-1K1 n) .|"
              using prepower_def_6 sorry
            also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s .FUNCT-1K1 n) .|"
              using A2 prepower_th_57 sorry
            also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|"
              using A2 prepower_th_57 sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m))\<inverse>XCMPLX-0K5 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|"
               sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s .FUNCT-1K1 m))\<inverse>XCMPLX-0K5 -XCMPLX-0K6 (a #QPREPOWERK4 (s .FUNCT-1K1 n))\<inverse>XCMPLX-0K5 .|"
               sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 (( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 n).|))"
              using A11 A16 seq_2_th_2 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) *XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)"
              using complex1_th_65 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n).|)"
              using A2 prepower_th_53 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)"
              using A12 absvalue_def_1 sorry
            finally have " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s .FUNCT-1K1 n .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)"
               sorry
            then have A17: "(( |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n))*XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) <XXREAL-0R3 (c *XCMPLX-0K3 a #QPREPOWERK4 m1)*XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)"
              using A10 A12 xreal_1_th_68 sorry
            have "a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) <>HIDDENR2 0NUMBERSK6"
              using A2 prepower_th_52 sorry
            then have A18: " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <XXREAL-0R3 (c *XCMPLX-0K3 a #QPREPOWERK4 m1)*XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)"
              using A17 xcmplx_1_th_87 sorry
            have "a #QPREPOWERK4 m1 *XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n) =COMPLEX1R1 a #QPREPOWERK4 (m1 +XCMPLX-0K2 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n))"
              using A2 prepower_th_53 sorry
            then have "c *XCMPLX-0K3 (a #QPREPOWERK4 m1 *XCMPLX-0K3 a #QPREPOWERK4 (s .FUNCT-1K1 m +XCMPLX-0K2 s .FUNCT-1K1 n)) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 c"
              using A2 A3 A8 A15 prepower_th_65 xreal_1_th_68 sorry
            then have " |.COMPLEX1K10 a #QPREPOWERK4 (s .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <XXREAL-0R3 c"
              using A18 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK4 (s .FUNCT-1K1 n) .| <XXREAL-0R3 c"
              using prepower_def_6 sorry
            thus " |.COMPLEX1K10 a #QPREPOWERK5 s .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s .FUNCT-1K1 n .| <XXREAL-0R3 c"
              using prepower_def_6 sorry
          qed "sorry"
        qed "sorry"
        thus "a #QPREPOWERK5 s be convergentSEQ-2V5"
          using seq_4_th_41 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_7:
" for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2) & a >=XXREAL-0R2 \<one>\<^sub>M implies limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
proof-
  have " for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & (limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2 & a >=XXREAL-0R2 \<one>\<^sub>M)) implies limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix s1 assume [ty]: "s1 be Rational-SequencePREPOWERM1"
    fix s2 assume [ty]: "s2 be Rational-SequencePREPOWERM1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: "s2 be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2"
      and A4: "a >=XXREAL-0R2 \<one>\<^sub>M"
    have A5: "s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2 be convergentSEQ-2V5"
      using A1 A2 sorry
    have A6: "a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using A2 A4 prepower_th_69 sorry
    have A7: " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2)+VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 s1 .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      have "((a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2)+VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 n =HIDDENR1 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 n +XCMPLX-0K2 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using seq_1_th_7 sorry
      also have "... = (a #QPREPOWERK5 s1 .FUNCT-1K1 n -XCMPLX-0K6 a #QPREPOWERK5 s2 .FUNCT-1K1 n)+XCMPLX-0K2 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using rfunct_2_th_1 sorry
      also have "... = a #QPREPOWERK5 s1 .FUNCT-1K1 n"
         sorry
      finally show "((a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2)+VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 s1 .FUNCT-1K1 n"
         sorry
    qed "sorry"
    have "s2 be boundedSEQ-2V6"
      using A2 sorry
    then obtain d where
      [ty]:"d be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 d"and A8: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s2 .FUNCT-1K1 n.| <XXREAL-0R3 d"
      using seq_2_th_3 sorry
    obtain m2 where
      [ty]:"m2 be NatNAT-1M1" and 
      A9: "d <XXREAL-0R3 m2"
      using seq_4_th_3 sorry
    have 
      [ty]:"m2 be RationalRAT-1M1"
       sorry
    have A10: "limSEQ-2K1 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2) =HIDDENR1 limSEQ-2K1 s1 -XCMPLX-0K6 limSEQ-2K1 s2"
      using A1 A2 seq_2_th_12 sorry
    also have "... = 0NUMBERSK6"
      using A3 sorry
    finally have "limSEQ-2K1 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2) =HIDDENR1 0NUMBERSK6"
       sorry
    have A11: " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c)"
    proof(rule ballI,rule impI)
      have A12: "a #QPREPOWERK4 m2 >=XXREAL-0R2 0NUMBERSK6"
        using A4 prepower_th_52 sorry
      fix c assume [ty]: "c be RealXREAL-0M1"
      assume A13: "c >XXREAL-0R4 0NUMBERSK6"
      obtain m1 where
        [ty]:"m1 be NatNAT-1M1" and 
        A14: "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1"
        using seq_4_th_3 sorry
      have "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 m1"
        using xreal_1_th_29 sorry
      then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1 +NAT-1K1 \<one>\<^sub>M"
        using A14 xxreal_0_th_2 sorry
      then have "((a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c)*XCMPLX-0K3 c <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A13 xreal_1_th_68 sorry
      then have "a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A13 xcmplx_1_th_87 sorry
      then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 ((m1 +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 c)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using xreal_1_th_74 sorry
      then have "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (c /XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have A15: "(a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 c"
        using xcmplx_1_th_87 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A16: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
        using A5 A10 seq_2_def_7 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "m >=XXREAL-0R2 n"
        then have " |.COMPLEX1K10 (s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using A16 sorry
        then have A17: " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using rfunct_2_th_1 sorry
        have A18: "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "(m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using A4 prepower_th_31 sorry
        then have A19: "a #QPREPOWERK4 m2 *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 a #QPREPOWERK4 m2 *XCMPLX-0K3 ((a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))"
          using A12 xreal_1_th_64 sorry
        have A20: "a #QPREPOWERK4 (s2 .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
          using A4 prepower_th_52 sorry
        have A21: " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| =HIDDENR1  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m))*XCMPLX-0K3 \<one>\<^sub>M .|"
           sorry
        also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m))*XCMPLX-0K3 (a #QPREPOWERK4 (s2 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m)) .|"
          using A20 xcmplx_1_th_60 sorry
        also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s2 .FUNCT-1K1 m) *XCMPLX-0K3 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m)))/XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|"
           sorry
        also have "... =  |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) *XCMPLX-0K3 ((a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m))/XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m)) .|"
           sorry
        also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m))/XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)"
          using complex1_th_65 sorry
        also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)"
           sorry
        also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .|)"
          using A20 xcmplx_1_th_60 sorry
        also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .|)"
          using A4 prepower_th_55 sorry
        finally have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .|)"
           sorry
        have A22: "s2 .FUNCT-1K1 m <=XXREAL-0R1  |.COMPLEX1K10 s2 .FUNCT-1K1 m.|"
          using absvalue_th_4 sorry
        obtain m3 where 
          [ty]:"m3 be RationalRAT-1M1" and m3Def:"m3 = (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
           sorry
        have A23: " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
          using complex1_th_46 sorry
        have A24: "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
          using A4 prepower_th_52 sorry
        have "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m <=XXREAL-0R1  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m .|"
          using absvalue_th_4 sorry
        then have "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using A17 xxreal_0_th_2 sorry
        then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <=XXREAL-0R1 a #QPREPOWERK4 m3"
          using A4 prepower_th_63 sorry
        then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
          using A18 prepower_th_50 sorry
        then have A25: "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        have A26: "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) >XXREAL-0R4 0NUMBERSK6"
          using A4 prepower_th_52 sorry
        have A27: " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
        proof-
          show " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          proof-
            have cases: "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m >=XXREAL-0R2 0NUMBERSK6 or s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule impI)
              assume "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m >=XXREAL-0R2 0NUMBERSK6"
              then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) >=XXREAL-0R2 \<one>\<^sub>M"
                using A4 prepower_th_60 sorry
              then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
                using xreal_1_th_48 sorry
              thus " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A25 absvalue_def_1 sorry
            qed
            have case2: "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule impI)
              assume A28: "s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m <XXREAL-0R3 0NUMBERSK6"
              have A29: "-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|"
                using absvalue_th_4 sorry
              have " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m .| =COMPLEX1R1  |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|"
                using complex1_th_52 sorry
              then have "-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <=XXREAL-0R1 m3"
                using A17 A29 xxreal_0_th_2 sorry
              then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) <=XXREAL-0R1 a #QPREPOWERK4 m3"
                using A4 prepower_th_63 sorry
              then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
                using A18 prepower_th_50 sorry
              then have A30: "a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              have "a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) >=XXREAL-0R2 \<one>\<^sub>M"
                using A4 A28 prepower_th_60 sorry
              then have "a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
                using xreal_1_th_48 sorry
              then have A31: " |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A30 absvalue_def_1 sorry
              have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) <=XXREAL-0R1 \<one>\<^sub>M"
                using A4 A28 prepower_th_61 sorry
              then have A32: " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).| <=XXREAL-0R1 \<one>\<^sub>M"
                using A26 absvalue_def_1 sorry
              have " |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
                using complex1_th_46 sorry
              then have A33: "( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                using A32 xreal_1_th_64 sorry
              have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M .|"
                 sorry
              also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) .|"
                using A24 xcmplx_1_th_60 sorry
              also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) *XCMPLX-0K3 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|"
                 sorry
              also have "... =  |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) *XCMPLX-0K3 ((a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) .|"
                 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|)"
                using complex1_th_65 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|)"
                 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) .|)"
                using A24 xcmplx_1_th_60 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) .|)"
                using A4 prepower_th_54 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 -XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m))) .|)"
                using complex1_th_52 sorry
              also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              finally have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              thus " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A31 A33 xxreal_0_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have A34: "a #QPREPOWERK4 (s2 .FUNCT-1K1 m) >XXREAL-0R4 0NUMBERSK6"
          using A4 prepower_th_52 sorry
        have " |.COMPLEX1K10 s2 .FUNCT-1K1 m.| <=XXREAL-0R1 m2"
          using A8 A9 xxreal_0_th_2 sorry
        then have "s2 .FUNCT-1K1 m <=XXREAL-0R1 m2"
          using A22 xxreal_0_th_2 sorry
        then have "a #QPREPOWERK4 (s2 .FUNCT-1K1 m) <=XXREAL-0R1 a #QPREPOWERK4 m2"
          using A4 prepower_th_63 sorry
        then have A35: " |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).| <=XXREAL-0R1 a #QPREPOWERK4 m2"
          using A34 absvalue_def_1 sorry
        have " |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).| >=XXREAL-0R2 0NUMBERSK6"
          using A34 absvalue_def_1 sorry
        then have "( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 s2 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 a #QPREPOWERK4 m2 *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
          using A27 A23 A35 xreal_1_th_66 sorry
        then have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <=XXREAL-0R1 (a #QPREPOWERK4 m2 *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using A21 A19 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <XXREAL-0R3 c"
          using A15 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 a #QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <XXREAL-0R3 c"
          using prepower_def_6 sorry
        then have " |.COMPLEX1K10 a #QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s2 .FUNCT-1K1 m .| <XXREAL-0R3 c"
          using prepower_def_6 sorry
        thus " |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c"
          using rfunct_2_th_1 sorry
      qed "sorry"
    qed "sorry"
    then have A36: "a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using seq_2_def_6 sorry
    then have "limSEQ-2K1 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2) =COMPLEX1R1 0NUMBERSK6"
      using A11 seq_2_def_7 sorry
    then have "limSEQ-2K1 ((a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2)+VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2) =HIDDENR1 0NUMBERSK6 +XCMPLX-0K2 limSEQ-2K1 a #QPREPOWERK5 s2"
      using A36 A6 seq_2_th_6 sorry
    also have "... = limSEQ-2K1 a #QPREPOWERK5 s2"
       sorry
    finally have "limSEQ-2K1 ((a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2)+VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2) =HIDDENR1 limSEQ-2K1 a #QPREPOWERK5 s2"
       sorry
    thus "limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
      using A7 funct_2_th_63 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_70:
" for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2) & a >XXREAL-0R4 0NUMBERSK6 implies (a #QPREPOWERK5 s1 be convergentSEQ-2V5 & a #QPREPOWERK5 s2 be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
proof-
  have " for s1 be Rational-SequencePREPOWERM1 holds  for s2 be Rational-SequencePREPOWERM1 holds  for a be RealXREAL-0M1 holds s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & (limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2 & a >XXREAL-0R4 0NUMBERSK6)) implies a #QPREPOWERK5 s1 be convergentSEQ-2V5 & (a #QPREPOWERK5 s2 be convergentSEQ-2V5 & limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI,rule conjMI,rule conjMI)
    fix s1 assume [ty]: "s1 be Rational-SequencePREPOWERM1"
    fix s2 assume [ty]: "s2 be Rational-SequencePREPOWERM1"
    fix a assume [ty]: "a be RealXREAL-0M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: "s2 be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 s1 =COMPLEX1R1 limSEQ-2K1 s2"
      and A4: "a >XXREAL-0R4 0NUMBERSK6"
    show A5: "a #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A1 A4 prepower_th_69 sorry
    have "s2 be boundedSEQ-2V6"
      using A2 sorry
    then obtain e where
      [ty]:"e be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 e"and A6: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s2 .FUNCT-1K1 n.| <XXREAL-0R3 e"
      using seq_2_th_3 sorry
    have "s1 be boundedSEQ-2V6"
      using A1 sorry
    then obtain d where
      [ty]:"d be RealXREAL-0M1" and 
      "0NUMBERSK6 <XXREAL-0R3 d"and A7: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s1 .FUNCT-1K1 n.| <XXREAL-0R3 d"
      using seq_2_th_3 sorry
    obtain m1 where
      [ty]:"m1 be NatNAT-1M1" and 
      A8: "d +XCMPLX-0K2 e <XXREAL-0R3 m1"
      using seq_4_th_3 sorry
    show A9: "a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using A2 A4 prepower_th_69 sorry
    have 
      [ty]:"m1 be RationalRAT-1M1"
       sorry
    have A10: "a #QPREPOWERK4 m1 >XXREAL-0R4 0NUMBERSK6"
      using A4 prepower_th_52 sorry
    show "limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
    proof-
      have cases: "a >=XXREAL-0R2 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
         sorry
      have case1: "a >=XXREAL-0R2 \<one>\<^sub>M implies limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
      proof(rule impI)
        assume "a >=XXREAL-0R2 \<one>\<^sub>M"
        thus "limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
          using A1 A2 A3 prepower_lm_7 sorry
      qed
      have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
      proof(rule impI)
        assume A11: "a <XXREAL-0R3 \<one>\<^sub>M"
        then have "a /XCMPLX-0K7 a <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A4 xreal_1_th_74 sorry
        then have "\<one>\<^sub>M <XXREAL-0R3 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A4 xcmplx_1_th_60 sorry
        then have A12: "limSEQ-2K1 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2"
          using A1 A2 A3 prepower_lm_7 sorry
        have A13: "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 be convergentSEQ-2V5"
          using A2 A4 prepower_th_69 sorry
        have A14: "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 be convergentSEQ-2V5"
          using A1 A4 prepower_th_69 sorry
        then have A15: "(\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 be convergentSEQ-2V5"
          using A13 sorry
        have A16: "limSEQ-2K1 ((\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2) =HIDDENR1 limSEQ-2K1 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -XCMPLX-0K6 limSEQ-2K1 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2"
          using A14 A13 seq_2_th_12 sorry
        also have "... = 0NUMBERSK6"
          using A12 sorry
        finally have "limSEQ-2K1 ((\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2) =HIDDENR1 0NUMBERSK6"
           sorry
        have A17: " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c)"
        proof(rule ballI,rule impI)
          fix c assume [ty]: "c be RealXREAL-0M1"
          assume A18: "c >XXREAL-0R4 0NUMBERSK6"
          then have "c *XCMPLX-0K3 a #QPREPOWERK4 m1 >XXREAL-0R4 0NUMBERSK6"
            using A10 sorry
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A19: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 ((\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c *XCMPLX-0K3 a #QPREPOWERK4 m1"
            using A15 A16 seq_2_def_7 sorry
          show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c"
          proof(rule bexI[of _ "n"],rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume "m >=XXREAL-0R2 n"
            then have " |.COMPLEX1K10 ((\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c *XCMPLX-0K3 a #QPREPOWERK4 m1"
              using A19 sorry
            then have A20: " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 .FUNCT-1K1 m .| <XXREAL-0R3 c *XCMPLX-0K3 a #QPREPOWERK4 m1"
              using rfunct_2_th_1 sorry
            have A21: "a #QPREPOWERK4 (s1 .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            have " |.COMPLEX1K10 s1 .FUNCT-1K1 m.| <XXREAL-0R3 d"
              using A7 sorry
            then have A22: " |.COMPLEX1K10 s1 .FUNCT-1K1 m.| +XCMPLX-0K2  |.COMPLEX1K10 s2 .FUNCT-1K1 m.| <XXREAL-0R3 d +XCMPLX-0K2 e"
              using A6 xreal_1_th_8 sorry
            have " |.COMPLEX1K10 s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m .| <=XXREAL-0R1  |.COMPLEX1K10 s1 .FUNCT-1K1 m.| +XCMPLX-0K2  |.COMPLEX1K10 s2 .FUNCT-1K1 m.|"
              using complex1_th_56 sorry
            then have " |.COMPLEX1K10 s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m .| <XXREAL-0R3 d +XCMPLX-0K2 e"
              using A22 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m .| <XXREAL-0R3 m1"
              using A8 xxreal_0_th_2 sorry
            then have A23: " |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) .| <XXREAL-0R3 m1"
              using complex1_th_52 sorry
            have "-XCMPLX-0K4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) .|"
              using absvalue_th_4 sorry
            then have "-XCMPLX-0K4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) <XXREAL-0R3 m1"
              using A23 xxreal_0_th_2 sorry
            then have A24: "m1 -XCMPLX-0K6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)) >XXREAL-0R4 0NUMBERSK6"
              using xreal_1_th_50 sorry
            have A25: "a #QPREPOWERK4 (s2 .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            have A26: "a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) >XXREAL-0R4 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            have " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 .FUNCT-1K1 m .| =HIDDENR1  |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 .FUNCT-1K1 m .|"
              using prepower_def_6 sorry
            also have "... =  |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s2 .FUNCT-1K1 m) .|"
              using prepower_def_6 sorry
            also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK4 (s2 .FUNCT-1K1 m) .|"
              using A4 prepower_th_57 sorry
            also have "... =  |.COMPLEX1K10 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|"
              using A4 prepower_th_57 sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m))\<inverse>XCMPLX-0K5 -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|"
               sorry
            also have "... =  |.COMPLEX1K10 (a #QPREPOWERK4 (s1 .FUNCT-1K1 m))\<inverse>XCMPLX-0K5 -XCMPLX-0K6 (a #QPREPOWERK4 (s2 .FUNCT-1K1 m))\<inverse>XCMPLX-0K5 .|"
               sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 (( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #QPREPOWERK4 (s2 .FUNCT-1K1 m).|))"
              using A21 A25 seq_2_th_2 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) *XCMPLX-0K3 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)"
              using complex1_th_65 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m).|)"
              using A4 prepower_th_53 sorry
            also have "... = ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)"
              using A26 absvalue_def_1 sorry
            finally have " |.COMPLEX1K10 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 a)#QPREPOWERK5 s2 .FUNCT-1K1 m .| =HIDDENR1 ( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)"
               sorry
            then have A27: "(( |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .|)/XCMPLX-0K7 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m))*XCMPLX-0K3 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) <XXREAL-0R3 (c *XCMPLX-0K3 a #QPREPOWERK4 m1)*XCMPLX-0K3 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)"
              using A20 A26 xreal_1_th_68 sorry
            have "a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) <>HIDDENR2 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            then have A28: " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <XXREAL-0R3 (c *XCMPLX-0K3 a #QPREPOWERK4 m1)*XCMPLX-0K3 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)"
              using A27 xcmplx_1_th_87 sorry
            have "a #QPREPOWERK4 m1 *XCMPLX-0K3 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m) =COMPLEX1R1 a #QPREPOWERK4 (m1 +XCMPLX-0K2 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m))"
              using A4 prepower_th_53 sorry
            then have "c *XCMPLX-0K3 (a #QPREPOWERK4 m1 *XCMPLX-0K3 a #QPREPOWERK4 (s1 .FUNCT-1K1 m +XCMPLX-0K2 s2 .FUNCT-1K1 m)) <XXREAL-0R3 \<one>\<^sub>M *XCMPLX-0K3 c"
              using A4 A11 A18 A24 prepower_th_65 xreal_1_th_68 sorry
            then have " |.COMPLEX1K10 a #QPREPOWERK4 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <XXREAL-0R3 c"
              using A28 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 a #QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK4 (s2 .FUNCT-1K1 m) .| <XXREAL-0R3 c"
              using prepower_def_6 sorry
            then have " |.COMPLEX1K10 a #QPREPOWERK5 s1 .FUNCT-1K1 m -XCMPLX-0K6 a #QPREPOWERK5 s2 .FUNCT-1K1 m .| <XXREAL-0R3 c"
              using prepower_def_6 sorry
            thus " |.COMPLEX1K10 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2).FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 c"
              using rfunct_2_th_1 sorry
          qed "sorry"
        qed "sorry"
        then have "a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2 be convergentSEQ-2V5"
          using seq_2_def_6 sorry
        then have "limSEQ-2K1 (a #QPREPOWERK5 s1 -VALUED-1K49\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 s2) =COMPLEX1R1 0NUMBERSK6"
          using A17 seq_2_def_7 sorry
        then have "0NUMBERSK6 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s1 -XCMPLX-0K6 limSEQ-2K1 a #QPREPOWERK5 s2"
          using A5 A9 seq_2_th_12 sorry
        thus "limSEQ-2K1 a #QPREPOWERK5 s1 =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef prepower_def_7 (" _ #RPREPOWERK6  _ " [220,220]220 ) where
  mlet "a be RealXREAL-0M1", "b be RealXREAL-0M1"
"assume a >XXREAL-0R4 0NUMBERSK6 func a #RPREPOWERK6 b \<rightarrow> RealXREAL-0M1 means
  \<lambda>it.  ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it"
proof-
  (*existence*)
    show "a >XXREAL-0R4 0NUMBERSK6 implies ( ex it be RealXREAL-0M1 st  ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it)"
    proof(rule impI)
      assume Assume: "a >XXREAL-0R4 0NUMBERSK6"
      have A1: "a >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      show " ex it be RealXREAL-0M1 st  ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it"
      proof-
        have " ex IT be objectHIDDENM1 st  not ( for s be Rational-SequencePREPOWERM1 holds  not (((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 IT))"
        proof-
          obtain s where
            [ty]:"s be Rational-SequencePREPOWERM1" and 
            A2: "s be convergentSEQ-2V5"and A3: "limSEQ-2K1 s =COMPLEX1R1 b"and " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 b"
            using prepower_th_67 sorry
          obtain IT where 
            [ty]:"IT be objectHIDDENM1" and ITDef:"IT = limSEQ-2K1 a #QPREPOWERK5 s"
             sorry
          show " ex IT be objectHIDDENM1 st  not ( for s be Rational-SequencePREPOWERM1 holds  not (((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 IT))"
          proof(rule bexI[of _ "IT"])
            show " not ( for s be Rational-SequencePREPOWERM1 holds  not (((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 IT))"
              using A1 A2 A3 prepower_th_69 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "a >XXREAL-0R4 0NUMBERSK6 implies ( for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it1) & ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "a >XXREAL-0R4 0NUMBERSK6"
      have A1: "a >XXREAL-0R4 0NUMBERSK6"
        using Assume sorry
      show " for it1 be RealXREAL-0M1 holds  for it2 be RealXREAL-0M1 holds ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it1) & ( ex s be Rational-SequencePREPOWERM1 st ((s be convergentSEQ-2V5 & limSEQ-2K1 s =COMPLEX1R1 b) & a #QPREPOWERK5 s be convergentSEQ-2V5) & limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 it2) implies it1 =HIDDENR1 it2"
        using A1 prepower_th_70 sorry
    qed
qed "sorry"

mtheorem prepower_th_71:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    let ?s = "seq-constSEQ-1K1 (0NUMBERSK6)"
    obtain s where 
      [ty]:"s be Rational-SequencePREPOWERM1" and sDef:"s = ?s"
       sorry
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "s .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 0NUMBERSK6"
      using seq_1_th_57 sorry
    then have A2: "limSEQ-2K1 s =COMPLEX1R1 0NUMBERSK6"
      using seq_4_th_26 sorry
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using numbers_th_19 sorry
    have A3: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 j"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain nn where 
        [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
        using ordinal1_def_12 sorry
      have "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 (s .FUNCT-1K1 nn)"
        using prepower_def_6 sorry
      also have "... = j"
        using prepower_th_47 seq_1_th_57 sorry
      finally show "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 j"
         sorry
    qed "sorry"
    then have A4: "a #QPREPOWERK5 s be constantVALUED-0V15"
      using valued_0_def_18 sorry
    have "a #QPREPOWERK5 s .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
      using A3 sorry
    then have "limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 \<one>\<^sub>M"
      using A4 seq_4_th_26 sorry
    thus "a #RPREPOWERK6 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
      using A1 A2 A4 prepower_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_72:
" for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 \<one>\<^sub>M =COMPLEX1R1 a"
proof-
  have " for a be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 \<one>\<^sub>M =COMPLEX1R1 a"
  proof(rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    let ?s = "seq-constSEQ-1K1 \<one>\<^sub>M"
    obtain s where 
      [ty]:"s be Rational-SequencePREPOWERM1" and sDef:"s = ?s"
       sorry
    have "s .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 \<one>\<^sub>M"
      using seq_1_th_57 sorry
    then have A1: "limSEQ-2K1 s =COMPLEX1R1 \<one>\<^sub>M"
      using seq_4_th_26 sorry
    assume A2: "a >XXREAL-0R4 0NUMBERSK6"
    have A3: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain nn where 
        [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
        using ordinal1_def_12 sorry
      have "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 (s .FUNCT-1K1 nn)"
        using prepower_def_6 sorry
      also have "... = a"
        using A2 prepower_th_48 seq_1_th_57 sorry
      finally show "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a"
         sorry
    qed "sorry"
    have "a inHIDDENR3 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A4: "a #QPREPOWERK5 s be constantVALUED-0V15"
      using A3 valued_0_def_18 sorry
    have "a #QPREPOWERK5 s .FUNCT-1K1 (0NUMBERSK6) =COMPLEX1R1 a"
      using A3 sorry
    then have "limSEQ-2K1 a #QPREPOWERK5 s =COMPLEX1R1 a"
      using A4 seq_4_th_26 sorry
    thus "a #RPREPOWERK6 \<one>\<^sub>M =COMPLEX1R1 a"
      using A2 A1 A4 prepower_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_73:
" for a be RealXREAL-0M1 holds \<one>\<^sub>M #RPREPOWERK6 a =COMPLEX1R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds \<one>\<^sub>M #RPREPOWERK6 a =COMPLEX1R1 \<one>\<^sub>M"
  proof(rule ballI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    obtain s where
      [ty]:"s be Rational-SequencePREPOWERM1" and 
      A1: "s be convergentSEQ-2V5"and A2: "a =COMPLEX1R1 limSEQ-2K1 s"and " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 a"
      using prepower_th_67 sorry
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
      using numbers_th_19 sorry
    have A3: " for n be NatNAT-1M1 holds j #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 j"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain nn where 
        [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
        using ordinal1_def_12 sorry
      have "j #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 j #QPREPOWERK4 (s .FUNCT-1K1 nn)"
        using prepower_def_6 sorry
      also have "... = j"
        using prepower_th_51 sorry
      finally show "j #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 j"
         sorry
    qed "sorry"
    then have "j #QPREPOWERK5 s be constantVALUED-0V15"
      using valued_0_def_18 sorry
    then have A4: "limSEQ-2K1 \<one>\<^sub>M #QPREPOWERK5 s =HIDDENR1 \<one>\<^sub>M #QPREPOWERK5 s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = \<one>\<^sub>M"
      using A3 sorry
    finally have "limSEQ-2K1 \<one>\<^sub>M #QPREPOWERK5 s =HIDDENR1 \<one>\<^sub>M"
       sorry
    have "\<one>\<^sub>M #QPREPOWERK5 s be convergentSEQ-2V5"
      using A1 prepower_th_69 sorry
    thus "\<one>\<^sub>M #RPREPOWERK6 a =COMPLEX1R1 \<one>\<^sub>M"
      using A1 A2 A4 prepower_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_74:
" for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 p =COMPLEX1R1 a #QPREPOWERK4 p"
proof-
  have " for a be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 p =COMPLEX1R1 a #QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    let ?s = "seq-constSEQ-1K1 p"
    have A2: "limSEQ-2K1 ?s =HIDDENR1 ?s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = p"
      using funcop_1_th_7 sorry
    finally have "limSEQ-2K1 ?s =HIDDENR1 p"
       sorry
    obtain s where 
      [ty]:"s be Rational-SequencePREPOWERM1" and sDef:"s = ?s"
       sorry
    have A3: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 p"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      obtain nn where 
        [ty]:"nn be ElementSUBSET-1M1-of NATNUMBERSK1" and nnDef:"nn = n"
        using ordinal1_def_12 sorry
      have "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 (s .FUNCT-1K1 nn)"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK4 p"
        using funcop_1_th_7 sorry
      finally show "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 p"
         sorry
    qed "sorry"
    have "a #QPREPOWERK4 p inTARSKIR2 REALNUMBERSK2"
      using xreal_0_def_1 sorry
    then have A4: "a #QPREPOWERK5 s be constantVALUED-0V15"
      using A3 valued_0_def_18 sorry
    then have "limSEQ-2K1 a #QPREPOWERK5 s =HIDDENR1 a #QPREPOWERK5 s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = a #QPREPOWERK4 p"
      using A3 sorry
    finally have "limSEQ-2K1 a #QPREPOWERK5 s =HIDDENR1 a #QPREPOWERK4 p"
       sorry
    thus "a #RPREPOWERK6 p =COMPLEX1R1 a #QPREPOWERK4 p"
      using A1 A2 A4 prepower_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_75:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b +XCMPLX-0K2 c) =COMPLEX1R1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b +XCMPLX-0K2 c) =HIDDENR1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    obtain sb where
      [ty]:"sb be Rational-SequencePREPOWERM1" and 
      A1: "sb be convergentSEQ-2V5"and A2: "b =COMPLEX1R1 limSEQ-2K1 sb"and " for n be NatNAT-1M1 holds sb .FUNCT-1K1 n <=XXREAL-0R1 b"
      using prepower_th_67 sorry
    obtain sc where
      [ty]:"sc be Rational-SequencePREPOWERM1" and 
      A3: "sc be convergentSEQ-2V5"and A4: "c =COMPLEX1R1 limSEQ-2K1 sc"and " for n be NatNAT-1M1 holds sc .FUNCT-1K1 n <=XXREAL-0R1 c"
      using prepower_th_67 sorry
    assume A5: "a >XXREAL-0R4 0NUMBERSK6"
    then have A6: "a #QPREPOWERK5 sb be convergentSEQ-2V5"
      using A1 prepower_th_69 sorry
    have A7: "a #QPREPOWERK5 sc be convergentSEQ-2V5"
      using A5 A3 prepower_th_69 sorry
    obtain s where 
      [ty]:"s be Rational-SequencePREPOWERM1" and sDef:"s = sb +VALUED-1K3\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> sc"
       sorry
    have A8: "limSEQ-2K1 s =COMPLEX1R1 b +XCMPLX-0K2 c"
      using A1 A2 A3 A4 seq_2_th_6 sorry
    have A9: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 sb .FUNCT-1K1 n *XCMPLX-0K3 a #QPREPOWERK5 sc .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK4 (sb .FUNCT-1K1 n +XCMPLX-0K2 sc .FUNCT-1K1 n)"
        using seq_1_th_7 sorry
      also have "... = a #QPREPOWERK4 (sb .FUNCT-1K1 n) *XCMPLX-0K3 a #QPREPOWERK4 (sc .FUNCT-1K1 n)"
        using A5 prepower_th_53 sorry
      also have "... = a #QPREPOWERK4 (sb .FUNCT-1K1 n) *XCMPLX-0K3 a #QPREPOWERK5 sc .FUNCT-1K1 n"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK5 sb .FUNCT-1K1 n *XCMPLX-0K3 a #QPREPOWERK5 sc .FUNCT-1K1 n"
        using prepower_def_6 sorry
      finally show "a #QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 sb .FUNCT-1K1 n *XCMPLX-0K3 a #QPREPOWERK5 sc .FUNCT-1K1 n"
         sorry
    qed "sorry"
    have A10: "s be convergentSEQ-2V5"
      using A1 A3 sorry
    then have "a #QPREPOWERK5 s be convergentSEQ-2V5"
      using A5 prepower_th_69 sorry
    then have "a #RPREPOWERK6 (b +XCMPLX-0K2 c) =HIDDENR1 limSEQ-2K1 a #QPREPOWERK5 s"
      using A5 A10 A8 prepower_def_7 sorry
    also have "... = limSEQ-2K1 (a #QPREPOWERK5 sb (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> a #QPREPOWERK5 sc)"
      using A9 seq_1_th_8 sorry
    also have "... = (limSEQ-2K1 a #QPREPOWERK5 sb)*XCMPLX-0K3 (limSEQ-2K1 a #QPREPOWERK5 sc)"
      using A6 A7 seq_2_th_15 sorry
    also have "... = a #RPREPOWERK6 b *XCMPLX-0K3 (limSEQ-2K1 a #QPREPOWERK5 sc)"
      using A5 A1 A2 A6 prepower_def_7 sorry
    also have "... = a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
      using A5 A3 A4 A7 prepower_def_7 sorry
    finally show "a #RPREPOWERK6 (b +XCMPLX-0K2 c) =HIDDENR1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_8:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    obtain s where
      [ty]:"s be Rational-SequencePREPOWERM1" and 
      A1: "s be convergentSEQ-2V5"and A2: "b =COMPLEX1R1 limSEQ-2K1 s"and " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 b"
      using prepower_th_67 sorry
    assume A3: "a >XXREAL-0R4 0NUMBERSK6"
    have A4: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "a #QPREPOWERK5 s .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      thus "a #QPREPOWERK5 s .FUNCT-1K1 n >=XXREAL-0R2 0NUMBERSK6"
        using A3 prepower_th_52 sorry
    qed "sorry"
    have "a #QPREPOWERK5 s be convergentSEQ-2V5"
      using A3 A1 prepower_th_69 sorry
    then have "a #RPREPOWERK6 b =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s"
      using A3 A1 A2 prepower_def_7 sorry
    thus "a #RPREPOWERK6 b >=XXREAL-0R2 0NUMBERSK6"
      using A3 A1 A4 prepower_th_69 seq_2_th_17 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_9:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b <>HIDDENR2 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b =COMPLEX1R1 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    assume "a #RPREPOWERK6 b =COMPLEX1R1 0NUMBERSK6"
    then have "0NUMBERSK6 =HIDDENR1 a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 b)"
       sorry
    also have "... = a #RPREPOWERK6 (b +XCMPLX-0K2 (-XCMPLX-0K4 b))"
      using A1 prepower_th_75 sorry
    also have "... = \<one>\<^sub>M"
      using A1 prepower_th_71 sorry
    finally have "0NUMBERSK6 =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus " False "
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_76:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "\<one>\<^sub>M =HIDDENR1 a #RPREPOWERK6 (c +XCMPLX-0K2 (-XCMPLX-0K4 c))"
      using prepower_th_71 sorry
    also have "... = a #RPREPOWERK6 (-XCMPLX-0K4 c) *XCMPLX-0K3 a #RPREPOWERK6 c"
      using A1 prepower_th_75 sorry
    finally have "\<one>\<^sub>M =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 c) *XCMPLX-0K3 a #RPREPOWERK6 c"
       sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 c) *XCMPLX-0K3 (a #RPREPOWERK6 c /XCMPLX-0K7 a #RPREPOWERK6 c)"
      using xcmplx_1_th_74 sorry
    also have "... = a #RPREPOWERK6 (-XCMPLX-0K4 c) *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 prepower_lm_9 xcmplx_1_th_60 sorry
    finally have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 (-XCMPLX-0K4 c) *XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "a #RPREPOWERK6 (-XCMPLX-0K4 c) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_77:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b -XCMPLX-0K6 c) =COMPLEX1R1 a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 (b -XCMPLX-0K6 c) =HIDDENR1 a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "a #RPREPOWERK6 (b -XCMPLX-0K6 c) =HIDDENR1 a #RPREPOWERK6 (b +XCMPLX-0K2 (-XCMPLX-0K4 c))"
       sorry
    also have "... = a #RPREPOWERK6 b *XCMPLX-0K3 a #RPREPOWERK6 (-XCMPLX-0K4 c)"
      using A1 prepower_th_75 sorry
    also have "... = a #RPREPOWERK6 b *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c)"
      using A1 prepower_th_76 sorry
    also have "... = a #RPREPOWERK6 b *XCMPLX-0K3 (\<one>\<^sub>M *XCMPLX-0K3 (a #RPREPOWERK6 c)\<inverse>XCMPLX-0K5)"
       sorry
    also have "... = a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
       sorry
    finally show "a #RPREPOWERK6 (b -XCMPLX-0K6 c) =HIDDENR1 a #RPREPOWERK6 b /XCMPLX-0K7 a #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_78:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 b)#RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have A3: "a *XCMPLX-0K3 b >XXREAL-0R4 0NUMBERSK6"
      using A1 A2 sorry
    obtain s1 where
      [ty]:"s1 be Rational-SequencePREPOWERM1" and 
      A4: "s1 be convergentSEQ-2V5"and A5: "c =COMPLEX1R1 limSEQ-2K1 s1"and " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 c"
      using prepower_th_68 sorry
    have A6: "a #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A1 A4 prepower_th_69 sorry
    have A7: "b #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A2 A4 prepower_th_69 sorry
    have " for n be NatNAT-1M1 holds (a *XCMPLX-0K3 b)#QPREPOWERK5 s1 .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 s1 .FUNCT-1K1 n *XCMPLX-0K3 b #QPREPOWERK5 s1 .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(a *XCMPLX-0K3 b)#QPREPOWERK5 s1 .FUNCT-1K1 n =HIDDENR1 (a *XCMPLX-0K3 b)#QPREPOWERK4 (s1 .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK4 (s1 .FUNCT-1K1 n) *XCMPLX-0K3 b #QPREPOWERK4 (s1 .FUNCT-1K1 n)"
        using A1 A2 prepower_th_56 sorry
      also have "... = a #QPREPOWERK5 s1 .FUNCT-1K1 n *XCMPLX-0K3 b #QPREPOWERK4 (s1 .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK5 s1 .FUNCT-1K1 n *XCMPLX-0K3 b #QPREPOWERK5 s1 .FUNCT-1K1 n"
        using prepower_def_6 sorry
      finally show "(a *XCMPLX-0K3 b)#QPREPOWERK5 s1 .FUNCT-1K1 n =HIDDENR1 a #QPREPOWERK5 s1 .FUNCT-1K1 n *XCMPLX-0K3 b #QPREPOWERK5 s1 .FUNCT-1K1 n"
         sorry
    qed "sorry"
    then have A8: "(a *XCMPLX-0K3 b)#QPREPOWERK5 s1 =FUNCT-1R1 a #QPREPOWERK5 s1 (#)VALUED-1K21\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> b #QPREPOWERK5 s1"
      using seq_1_th_8 sorry
    then have "(a *XCMPLX-0K3 b)#QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A6 A7 sorry
    then have "(a *XCMPLX-0K3 b)#RPREPOWERK6 c =HIDDENR1 limSEQ-2K1 (a *XCMPLX-0K3 b)#QPREPOWERK5 s1"
      using A3 A4 A5 prepower_def_7 sorry
    also have "... = (limSEQ-2K1 a #QPREPOWERK5 s1)*XCMPLX-0K3 (limSEQ-2K1 b #QPREPOWERK5 s1)"
      using A6 A7 A8 seq_2_th_15 sorry
    also have "... = a #RPREPOWERK6 c *XCMPLX-0K3 (limSEQ-2K1 b #QPREPOWERK5 s1)"
      using A1 A4 A5 A6 prepower_def_7 sorry
    also have "... = a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
      using A2 A4 A5 A7 prepower_def_7 sorry
    finally show "(a *XCMPLX-0K3 b)#RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 c *XCMPLX-0K3 b #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_79:
" for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    have "\<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M #RPREPOWERK6 c"
      using prepower_th_73 sorry
    also have "... = ((\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 a)#RPREPOWERK6 c"
      using A1 xcmplx_1_th_106 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c *XCMPLX-0K3 a #RPREPOWERK6 c"
      using A1 prepower_th_78 sorry
    finally have "\<one>\<^sub>M =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c *XCMPLX-0K3 a #RPREPOWERK6 c"
       sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c *XCMPLX-0K3 (a #RPREPOWERK6 c /XCMPLX-0K7 a #RPREPOWERK6 c)"
      using xcmplx_1_th_74 sorry
    also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c *XCMPLX-0K3 \<one>\<^sub>M"
      using A1 prepower_lm_9 xcmplx_1_th_60 sorry
    finally have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c *XCMPLX-0K3 \<one>\<^sub>M"
       sorry
    thus "(\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_80:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & b >XXREAL-0R4 0NUMBERSK6 implies (a /XCMPLX-0K7 b)#RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have "(a /XCMPLX-0K7 b)#RPREPOWERK6 c =HIDDENR1 (a *XCMPLX-0K3 b \<inverse>XCMPLX-0K5)#RPREPOWERK6 c"
       sorry
    also have "... = a #RPREPOWERK6 c *XCMPLX-0K3 b \<inverse>XCMPLX-0K5 #RPREPOWERK6 c"
      using A1 A2 prepower_th_78 sorry
    also have "... = a #RPREPOWERK6 c *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b)#RPREPOWERK6 c"
       sorry
    also have "... = a #RPREPOWERK6 c *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 b #RPREPOWERK6 c)"
      using A2 prepower_th_79 sorry
    also have "... = (a #RPREPOWERK6 c *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 b #RPREPOWERK6 c"
       sorry
    also have "... = a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
       sorry
    finally show "(a /XCMPLX-0K7 b)#RPREPOWERK6 c =HIDDENR1 a #RPREPOWERK6 c /XCMPLX-0K7 b #RPREPOWERK6 c"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_81:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies  not a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #RPREPOWERK6 b <>HIDDENR2 0NUMBERSK6"
      using prepower_lm_9 sorry
    thus " not a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
      using A1 prepower_lm_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_82:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & c >=XXREAL-0R2 b implies a #RPREPOWERK6 c >=XXREAL-0R2 a #RPREPOWERK6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & c >=XXREAL-0R2 b implies a #RPREPOWERK6 c >=XXREAL-0R2 a #RPREPOWERK6 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "c >=XXREAL-0R2 b"
    obtain s1 where
      [ty]:"s1 be Rational-SequencePREPOWERM1" and 
      A3: "s1 be convergentSEQ-2V5"and A4: "c =COMPLEX1R1 limSEQ-2K1 s1"and A5: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 c"
      using prepower_th_68 sorry
    have A6: "a #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A1 A3 prepower_th_69 sorry
    obtain s2 where
      [ty]:"s2 be Rational-SequencePREPOWERM1" and 
      A7: "s2 be convergentSEQ-2V5"and A8: "b =COMPLEX1R1 limSEQ-2K1 s2"and A9: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <=XXREAL-0R1 b"
      using prepower_th_67 sorry
    have A10: "a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using A1 A7 prepower_th_69 sorry
    have " for n be NatNAT-1M1 holds a #QPREPOWERK5 s1 .FUNCT-1K1 n >=XXREAL-0R2 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s1 .FUNCT-1K1 n >=XXREAL-0R2 c"
        using A5 sorry
      then have A11: "s1 .FUNCT-1K1 n >=XXREAL-0R2 b"
        using A2 xxreal_0_th_2 sorry
      have "s2 .FUNCT-1K1 n <=XXREAL-0R1 b"
        using A9 sorry
      then have "s1 .FUNCT-1K1 n >=XXREAL-0R2 s2 .FUNCT-1K1 n"
        using A11 xxreal_0_th_2 sorry
      then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 n) >=XXREAL-0R2 a #QPREPOWERK4 (s2 .FUNCT-1K1 n)"
        using A1 prepower_th_63 sorry
      then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 n) >=XXREAL-0R2 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using prepower_def_6 sorry
      thus "a #QPREPOWERK5 s1 .FUNCT-1K1 n >=XXREAL-0R2 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using prepower_def_6 sorry
    qed "sorry"
    then have "limSEQ-2K1 a #QPREPOWERK5 s1 >=XXREAL-0R2 limSEQ-2K1 a #QPREPOWERK5 s2"
      using A6 A10 seq_2_th_18 sorry
    then have "a #RPREPOWERK6 c >=XXREAL-0R2 limSEQ-2K1 a #QPREPOWERK5 s2"
      using A1 A3 A4 A6 prepower_def_7 sorry
    thus "a #RPREPOWERK6 c >=XXREAL-0R2 a #RPREPOWERK6 b"
      using A1 A7 A8 A10 prepower_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_83:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & c >XXREAL-0R4 b implies a #RPREPOWERK6 c >XXREAL-0R4 a #RPREPOWERK6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & c >XXREAL-0R4 b implies  not a #RPREPOWERK6 c >XXREAL-0R4 a #RPREPOWERK6 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "c >XXREAL-0R4 b"
    obtain p where
      [ty]:"p be RationalRAT-1M1" and 
      A3: "b <XXREAL-0R3 p"and A4: "p <XXREAL-0R3 c"
      using A2 rat_1_th_7 sorry
    obtain q where
      [ty]:"q be RationalRAT-1M1" and 
      A5: "b <XXREAL-0R3 q"and A6: "q <XXREAL-0R3 p"
      using A3 rat_1_th_7 sorry
    obtain s2 where
      [ty]:"s2 be Rational-SequencePREPOWERM1" and 
      A7: "s2 be convergentSEQ-2V5"and A8: "b =COMPLEX1R1 limSEQ-2K1 s2"and A9: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <=XXREAL-0R1 b"
      using prepower_th_67 sorry
    have A10: "a #QPREPOWERK4 q <XXREAL-0R3 a #QPREPOWERK4 p"
      using A1 A6 prepower_th_64 sorry
    have " for n be NatNAT-1M1 holds a #QPREPOWERK5 s2 .FUNCT-1K1 n <=XXREAL-0R1 a #QPREPOWERK4 q"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s2 .FUNCT-1K1 n <=XXREAL-0R1 b"
        using A9 sorry
      then have "s2 .FUNCT-1K1 n <=XXREAL-0R1 q"
        using A5 xxreal_0_th_2 sorry
      then have "a #QPREPOWERK4 (s2 .FUNCT-1K1 n) <=XXREAL-0R1 a #QPREPOWERK4 q"
        using A1 prepower_th_63 sorry
      thus "a #QPREPOWERK5 s2 .FUNCT-1K1 n <=XXREAL-0R1 a #QPREPOWERK4 q"
        using prepower_def_6 sorry
    qed "sorry"
    then have A11: "limSEQ-2K1 a #QPREPOWERK5 s2 <=XXREAL-0R1 a #QPREPOWERK4 q"
      using A1 A7 prepower_th_2 prepower_th_69 sorry
    have "a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using A1 A7 prepower_th_69 sorry
    then have "a #RPREPOWERK6 b <=XXREAL-0R1 a #QPREPOWERK4 q"
      using A1 A7 A8 A11 prepower_def_7 sorry
    then have A12: "a #RPREPOWERK6 b <XXREAL-0R3 a #QPREPOWERK4 p"
      using A10 xxreal_0_th_2 sorry
    obtain s1 where
      [ty]:"s1 be Rational-SequencePREPOWERM1" and 
      A13: "s1 be convergentSEQ-2V5"and A14: "c =COMPLEX1R1 limSEQ-2K1 s1"and A15: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 c"
      using prepower_th_68 sorry
    have " for n be NatNAT-1M1 holds a #QPREPOWERK5 s1 .FUNCT-1K1 n >=XXREAL-0R2 a #QPREPOWERK4 p"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "s1 .FUNCT-1K1 n >=XXREAL-0R2 c"
        using A15 sorry
      then have "s1 .FUNCT-1K1 n >=XXREAL-0R2 p"
        using A4 xxreal_0_th_2 sorry
      then have "a #QPREPOWERK4 (s1 .FUNCT-1K1 n) >=XXREAL-0R2 a #QPREPOWERK4 p"
        using A1 prepower_th_63 sorry
      thus "a #QPREPOWERK5 s1 .FUNCT-1K1 n >=XXREAL-0R2 a #QPREPOWERK4 p"
        using prepower_def_6 sorry
    qed "sorry"
    then have A16: "limSEQ-2K1 a #QPREPOWERK5 s1 >=XXREAL-0R2 a #QPREPOWERK4 p"
      using A1 A13 prepower_th_1 prepower_th_69 sorry
    have "a #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A1 A13 prepower_th_69 sorry
    then have "a #RPREPOWERK6 c >=XXREAL-0R2 a #QPREPOWERK4 p"
      using A1 A13 A14 A16 prepower_def_7 sorry
    thus " not a #RPREPOWERK6 c >XXREAL-0R4 a #RPREPOWERK6 b"
      using A12 xxreal_0_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_84:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds (a >XXREAL-0R4 0NUMBERSK6 & a <=XXREAL-0R1 \<one>\<^sub>M) & c >=XXREAL-0R2 b implies a #RPREPOWERK6 c <=XXREAL-0R1 a #RPREPOWERK6 b"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 & (a <=XXREAL-0R1 \<one>\<^sub>M & c >=XXREAL-0R2 b) implies a #RPREPOWERK6 c <=XXREAL-0R1 a #RPREPOWERK6 b"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "a <=XXREAL-0R1 \<one>\<^sub>M"
      and A3: "c >=XXREAL-0R2 b"
    have "\<one>\<^sub>M /XCMPLX-0K7 a >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 prepower_lm_4 xreal_1_th_85 sorry
    then have "(\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 c >=XXREAL-0R2 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 b"
      using A3 prepower_th_82 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c >=XXREAL-0R2 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 b"
      using A1 prepower_th_79 sorry
    then have A4: "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 c >=XXREAL-0R2 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b"
      using A1 prepower_th_79 sorry
    have "a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
      using A1 prepower_th_81 sorry
    thus "a #RPREPOWERK6 c <=XXREAL-0R1 a #RPREPOWERK6 b"
      using A4 xreal_1_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_85:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b >=XXREAL-0R2 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b >=XXREAL-0R2 0NUMBERSK6 implies a #RPREPOWERK6 b >=XXREAL-0R2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
    obtain s where
      [ty]:"s be Rational-SequencePREPOWERM1" and 
      A3: "s be convergentSEQ-2V5"and A4: "b =COMPLEX1R1 limSEQ-2K1 s"and A5: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n >=XXREAL-0R2 b"
      using prepower_th_68 sorry
    have A6: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s .FUNCT-1K1 n >=XXREAL-0R2 \<one>\<^sub>M"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A7: "a #QPREPOWERK5 s .FUNCT-1K1 n =COMPLEX1R1 a #QPREPOWERK4 (s .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      have "s .FUNCT-1K1 n >=XXREAL-0R2 b"
        using A5 sorry
      thus "a #QPREPOWERK5 s .FUNCT-1K1 n >=XXREAL-0R2 \<one>\<^sub>M"
        using A1 A2 A7 prepower_th_60 sorry
    qed "sorry"
    have "a #QPREPOWERK5 s be convergentSEQ-2V5"
      using A1 A3 prepower_th_69 sorry
    then have "a #RPREPOWERK6 b =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s"
      using A1 A3 A4 prepower_def_7 sorry
    thus "a #RPREPOWERK6 b >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A3 A6 prepower_th_1 prepower_th_69 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_86:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b >XXREAL-0R4 0NUMBERSK6 implies  not a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b >XXREAL-0R4 0NUMBERSK6"
    have "a #RPREPOWERK6 b >XXREAL-0R4 a #RPREPOWERK6 (0NUMBERSK6)"
      using A1 A2 prepower_th_83 sorry
    thus " not a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
      using A1 prepower_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_87:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b <=XXREAL-0R1 0NUMBERSK6 implies a #RPREPOWERK6 b <=XXREAL-0R1 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & b <=XXREAL-0R1 0NUMBERSK6 implies a #RPREPOWERK6 b <=XXREAL-0R1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "b <=XXREAL-0R1 0NUMBERSK6"
    have "a #RPREPOWERK6 (-XCMPLX-0K4 b) >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 A2 prepower_th_85 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 prepower_th_76 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b) <=XXREAL-0R1 \<one>\<^sub>M"
      using xreal_1_th_211 sorry
    thus "a #RPREPOWERK6 b <=XXREAL-0R1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_88:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies a #RPREPOWERK6 b <XXREAL-0R3 \<one>\<^sub>M"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds a >XXREAL-0R4 \<one>\<^sub>M & b <XXREAL-0R3 0NUMBERSK6 implies  not a #RPREPOWERK6 b <XXREAL-0R3 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    assume A1: "a >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "b <XXREAL-0R3 0NUMBERSK6"
    have "-XCMPLX-0K4 b >XXREAL-0R4 0NUMBERSK6"
      using A2 sorry
    then have "a #RPREPOWERK6 (-XCMPLX-0K4 b) >XXREAL-0R4 \<one>\<^sub>M"
      using A1 prepower_th_86 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b >XXREAL-0R4 \<one>\<^sub>M"
      using A1 prepower_th_76 sorry
    then have "\<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 b) <XXREAL-0R3 \<one>\<^sub>M"
      using xreal_1_th_212 sorry
    thus " not a #RPREPOWERK6 b <XXREAL-0R3 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_10:
" for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds (((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6) & p >=XXREAL-0R2 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
proof-
  have " for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & (limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6 & (p >=XXREAL-0R2 0NUMBERSK6 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p)))) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: "s2 be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6"
      and A4: "p >=XXREAL-0R2 0NUMBERSK6"
      and A5: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p"
    obtain ls where 
      [ty]:"ls be ElementSUBSET-1M1-of REALNUMBERSK2" and lsDef:"ls = limSEQ-2K1 s1"
      using xreal_0_def_1 sorry
    let ?s = "seq-constSEQ-1K1 (limSEQ-2K1 s1)"
    obtain m0 where
      [ty]:"m0 be NatNAT-1M1" and 
      A6: "p <XXREAL-0R3 m0"
      using seq_4_th_3 sorry
    have A7: "limSEQ-2K1 ?s =HIDDENR1 ?s .FUNCT-1K1 (0NUMBERSK6)"
      using seq_4_th_26 sorry
    also have "... = limSEQ-2K1 s1"
      using funcop_1_th_7 sorry
    finally have "limSEQ-2K1 ?s =HIDDENR1 limSEQ-2K1 s1"
       sorry
    then have A8: "s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s be convergentSEQ-2V5"
      using A1 A3 seq_2_th_23 sorry
    let ?O = "\<lambda>Lamb1. (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 Lamb1  |^NEWTONK1 m0"
    obtain s3 where
      [ty]:"s3 be Real-SequenceSEQ-1M1" and 
      A9: " for n be NatNAT-1M1 holds s3 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    have " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
      using A5 sorry
    then have A10: "s1 be non-zeroORDINAL1V9"
      using seq_1_th_5 sorry
    then have A11: "?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1 be convergentSEQ-2V5"
      using A1 A3 seq_2_th_23 sorry
    then have A12: "s3 be convergentSEQ-2V5"
      using A9 prepower_th_18 sorry
    obtain q where 
      [ty]:"q be RationalRAT-1M1" and qDef:"q = m0"
       sorry
    let ?O = "\<lambda>Lamb1. (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 Lamb1  |^NEWTONK1 m0"
    obtain s4 where
      [ty]:"s4 be Real-SequenceSEQ-1M1" and 
      A13: " for n be NatNAT-1M1 holds s4 .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
      using seq_1_sch_1 sorry
    have "limSEQ-2K1 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) =HIDDENR1 (limSEQ-2K1 ?s)/XCMPLX-0K7 (limSEQ-2K1 s1)"
      using A1 A3 A10 seq_2_th_24 sorry
    also have "... = \<one>\<^sub>M"
      using A3 A7 xcmplx_1_th_60 sorry
    finally have "limSEQ-2K1 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have "limSEQ-2K1 s3 =COMPLEX1R1 \<one>\<^sub>M  |^NEWTONK1 m0"
      using A11 A9 prepower_th_18 sorry
    then have A14: "limSEQ-2K1 s3 =COMPLEX1R1 \<one>\<^sub>M"
       sorry
    have "limSEQ-2K1 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s) =HIDDENR1 (limSEQ-2K1 s1)/XCMPLX-0K7 (limSEQ-2K1 ?s)"
      using A1 A3 A7 seq_2_th_24 sorry
    also have "... = \<one>\<^sub>M"
      using A3 A7 xcmplx_1_th_60 sorry
    finally have "limSEQ-2K1 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have "limSEQ-2K1 s4 =COMPLEX1R1 \<one>\<^sub>M  |^NEWTONK1 m0"
      using A8 A13 prepower_th_18 sorry
    then have A15: "limSEQ-2K1 s4 =COMPLEX1R1 \<one>\<^sub>M"
       sorry
    have "s2 be boundedSEQ-2V6"
      using A2 sorry
    then obtain d where
      [ty]:"d be RealXREAL-0M1" and 
      A16: "d >XXREAL-0R4 0NUMBERSK6"and A17: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s2 .FUNCT-1K1 n.| <XXREAL-0R3 d"
      using seq_2_th_3 sorry
    have A18: "s4 be convergentSEQ-2V5"
      using A8 A13 prepower_th_18 sorry
    have " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c)"
    proof(rule ballI,rule impI)
      fix c assume [ty]: "c be RealXREAL-0M1"
      assume A19: "c >XXREAL-0R4 0NUMBERSK6"
      then have "c /XCMPLX-0K7 d >XXREAL-0R4 0NUMBERSK6"
        using A16 sorry
      then obtain m1 where
        [ty]:"m1 be NatNAT-1M1" and 
        A20: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 m1 implies  |.COMPLEX1K10 s3 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 d"
        using A12 A14 seq_2_def_7 sorry
      have A21: "(limSEQ-2K1 s1)#QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
        using A3 prepower_th_52 sorry
      then have A22: " |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.| >XXREAL-0R4 0NUMBERSK6"
        using absvalue_def_1 sorry
      then have "c /XCMPLX-0K7 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|) >XXREAL-0R4 0NUMBERSK6"
        using A19 sorry
      then obtain m2 where
        [ty]:"m2 be NatNAT-1M1" and 
        A23: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 m2 implies  |.COMPLEX1K10 s4 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)"
        using A18 A15 seq_2_def_7 sorry
      obtain n where 
        [ty]:"n be setHIDDENM2" and nDef:"n = m1 +XCMPLX-0K2 m2"
         sorry
      show " ex n be setHIDDENM2 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A24: "m >=XXREAL-0R2 n"
        have "m2 <=XXREAL-0R1 n"
          using nat_1_th_11 sorry
        then have A25: "m >=XXREAL-0R2 m2"
          using A24 xxreal_0_th_2 sorry
        have "m1 <=XXREAL-0R1 n"
          using nat_1_th_11 sorry
        then have A26: "m >=XXREAL-0R2 m1"
          using A24 xxreal_0_th_2 sorry
        have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
        proof-
          show " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
          proof-
            have cases: "s1 .FUNCT-1K1 m >=XXREAL-0R2 limSEQ-2K1 s1 or s1 .FUNCT-1K1 m <=XXREAL-0R1 limSEQ-2K1 s1"
               sorry
            have case1: "s1 .FUNCT-1K1 m >=XXREAL-0R2 limSEQ-2K1 s1 implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
            proof(rule impI)
              assume A27: "s1 .FUNCT-1K1 m >=XXREAL-0R2 limSEQ-2K1 s1"
              have "m inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have A28: "s1 .FUNCT-1K1 m /XCMPLX-0K7 (limSEQ-2K1 s1) =HIDDENR1 s1 .FUNCT-1K1 m /XCMPLX-0K7 ?s .FUNCT-1K1 m"
                using funcop_1_th_7 sorry
              also have "... = s1 .FUNCT-1K1 m *XCMPLX-0K3 (?s .FUNCT-1K1 m)\<inverse>XCMPLX-0K5"
                 sorry
              also have "... = s1 .FUNCT-1K1 m *XCMPLX-0K3 ?s \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m"
                using valued_1_th_10 sorry
              also have "... = (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m"
                using seq_1_th_8 sorry
              finally have "s1 .FUNCT-1K1 m /XCMPLX-0K7 (limSEQ-2K1 s1) =HIDDENR1 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m"
                 sorry
              have "s1 .FUNCT-1K1 m *XCMPLX-0K3 (limSEQ-2K1 s1)\<inverse>XCMPLX-0K5 >=XXREAL-0R2 (limSEQ-2K1 s1)*XCMPLX-0K3 (limSEQ-2K1 s1)\<inverse>XCMPLX-0K5"
                using A3 A27 xreal_1_th_64 sorry
              then have A29: "(s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m >=XXREAL-0R2 \<one>\<^sub>M"
                using A3 A28 xcmplx_0_def_7 sorry
              then have "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 ((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 q"
                using A6 prepower_th_63 sorry
              then have "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m  |^NEWTONK1 m0"
                using A29 prepower_th_49 sorry
              then have A30: "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              have "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
                using A4 A29 prepower_th_60 sorry
              then have "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then have A31: "((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1  |.COMPLEX1K10 ((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|"
                using absvalue_def_1 sorry
              have A32: "(limSEQ-2K1 s1)#QPREPOWERK4 p <>HIDDENR2 0NUMBERSK6"
                using A3 prepower_th_52 sorry
              have A33: " |.COMPLEX1K10 s4 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)"
                using A23 A25 sorry
              have A34: "s1 .FUNCT-1K1 m >XXREAL-0R4 0NUMBERSK6"
                using A5 sorry
              have "(s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m  |^NEWTONK1 m0 >=XXREAL-0R2 \<one>\<^sub>M"
                using A29 prepower_th_11 sorry
              then have "(s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then have " |.COMPLEX1K10 ((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1  |.COMPLEX1K10 (s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M .|"
                using A30 A31 absvalue_def_1 sorry
              then have " |.COMPLEX1K10 ((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1  |.COMPLEX1K10 s4 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .|"
                using A13 sorry
              then have A35: " |.COMPLEX1K10 ((s1 /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> ?s).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)"
                using A33 xxreal_0_th_2 sorry
              have A36: " |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.| <>HIDDENR2 0NUMBERSK6"
                using A21 absvalue_def_1 sorry
              have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| =HIDDENR1  |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)*XCMPLX-0K3 \<one>\<^sub>M .|"
                using A5 sorry
              also have "... =  |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)*XCMPLX-0K3 ((limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p) .|"
                using A32 xcmplx_1_th_60 sorry
              also have "... =  |.COMPLEX1K10 ((limSEQ-2K1 s1)#QPREPOWERK4 p *XCMPLX-0K3 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p))/XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p .|"
                 sorry
              also have "... =  |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p *XCMPLX-0K3 (((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)/XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p) .|"
                 sorry
              also have "... = ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)/XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p .|)"
                using complex1_th_65 sorry
              also have "... = ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p /XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p .|)"
                 sorry
              also have "... = ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p /XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                using A32 xcmplx_1_th_60 sorry
              also have "... = ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m /XCMPLX-0K7 (limSEQ-2K1 s1))#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                using A3 A34 prepower_th_58 sorry
              finally have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| =HIDDENR1 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m /XCMPLX-0K7 (limSEQ-2K1 s1))#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              then have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|)*XCMPLX-0K3 (c /XCMPLX-0K7 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p.|))"
                using A22 A28 A35 xreal_1_th_68 sorry
              thus " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
                using A36 xcmplx_1_th_87 sorry
            qed
            have case2: "s1 .FUNCT-1K1 m <=XXREAL-0R1 limSEQ-2K1 s1 implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
            proof(rule impI)
              assume A37: "s1 .FUNCT-1K1 m <=XXREAL-0R1 limSEQ-2K1 s1"
              have A38: "m inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              have A39: "(limSEQ-2K1 s1)/XCMPLX-0K7 s1 .FUNCT-1K1 m =HIDDENR1 ?s .FUNCT-1K1 m /XCMPLX-0K7 s1 .FUNCT-1K1 m"
                using funcop_1_th_7 A38 sorry
              also have "... = ?s .FUNCT-1K1 m *XCMPLX-0K3 (s1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5"
                 sorry
              also have "... = ?s .FUNCT-1K1 m *XCMPLX-0K3 s1 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .FUNCT-1K1 m"
                using valued_1_th_10 sorry
              also have "... = (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m"
                using seq_1_th_8 sorry
              finally have "(limSEQ-2K1 s1)/XCMPLX-0K7 s1 .FUNCT-1K1 m =HIDDENR1 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m"
                 sorry
              have A40: "s1 .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6"
                using A5 sorry
              have A41: "s1 .FUNCT-1K1 m >XXREAL-0R4 0NUMBERSK6"
                using A5 sorry
              then have "s1 .FUNCT-1K1 m *XCMPLX-0K3 (s1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5 <=XXREAL-0R1 (limSEQ-2K1 s1)*XCMPLX-0K3 (s1 .FUNCT-1K1 m)\<inverse>XCMPLX-0K5"
                using A37 xreal_1_th_64 sorry
              then have A42: "(?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m >=XXREAL-0R2 \<one>\<^sub>M"
                using A40 A39 xcmplx_0_def_7 sorry
              then have "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 ((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 q"
                using A6 prepower_th_63 sorry
              then have "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m  |^NEWTONK1 m0"
                using A42 prepower_th_49 sorry
              then have A43: "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              have "(s1 .FUNCT-1K1 m)#QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
                using A5 prepower_th_52 sorry
              then have A44: " |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.| >XXREAL-0R4 0NUMBERSK6"
                using absvalue_def_1 sorry
              have A45: " |.COMPLEX1K10 s3 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 d"
                using A20 A26 sorry
              have "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p >=XXREAL-0R2 \<one>\<^sub>M"
                using A4 A42 prepower_th_60 sorry
              then have "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then have A46: "((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M =COMPLEX1R1  |.COMPLEX1K10 ((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|"
                using absvalue_def_1 sorry
              have "(?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m  |^NEWTONK1 m0 >=XXREAL-0R2 \<one>\<^sub>M"
                using A42 prepower_th_11 sorry
              then have "(?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then have " |.COMPLEX1K10 ((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1  |.COMPLEX1K10 (?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m  |^NEWTONK1 m0 -XCMPLX-0K6 \<one>\<^sub>M .|"
                using A43 A46 absvalue_def_1 sorry
              then have " |.COMPLEX1K10 ((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1  |.COMPLEX1K10 s3 .FUNCT-1K1 m -XCMPLX-0K6 \<one>\<^sub>M .|"
                using A9 sorry
              then have A47: " |.COMPLEX1K10 ((?s /\<inverse>VALUED-1K54\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2,REALNUMBERSK2)\<^esub> s1).FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .| <XXREAL-0R3 c /XCMPLX-0K7 d"
                using A45 xxreal_0_th_2 sorry
              have " |.COMPLEX1K10 s2 .FUNCT-1K1 m.| <XXREAL-0R3 d"
                using A17 sorry
              then have " |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.| <XXREAL-0R3 d"
                using A5 sorry
              then have "( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)/XCMPLX-0K7 d <XXREAL-0R3 d /XCMPLX-0K7 d"
                using A16 xreal_1_th_74 sorry
              then have "( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)/XCMPLX-0K7 d <XXREAL-0R3 \<one>\<^sub>M"
                using A16 xcmplx_1_th_60 sorry
              then have A48: "c *XCMPLX-0K3 (( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)/XCMPLX-0K7 d) <XXREAL-0R3 c *XCMPLX-0K3 \<one>\<^sub>M"
                using A19 xreal_1_th_68 sorry
              have A49: "(s1 .FUNCT-1K1 m)#QPREPOWERK4 p <>HIDDENR2 0NUMBERSK6"
                using A5 prepower_th_52 sorry
              have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| =HIDDENR1  |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)*XCMPLX-0K3 \<one>\<^sub>M .|"
                using A5 sorry
              also have "... =  |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)*XCMPLX-0K3 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p) .|"
                using A49 xcmplx_1_th_60 sorry
              also have "... =  |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p *XCMPLX-0K3 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p))/XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p .|"
                 sorry
              also have "... =  |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p *XCMPLX-0K3 (((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)/XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p) .|"
                 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 ((s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p)/XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p .|)"
                using complex1_th_65 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p .|)"
                 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p .|)"
                using A49 xcmplx_1_th_60 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 -XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p) .|)"
                using complex1_th_52 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 (limSEQ-2K1 s1)#QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              also have "... = ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 ((limSEQ-2K1 s1)/XCMPLX-0K7 s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                using A3 A41 prepower_th_58 sorry
              finally have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| =HIDDENR1 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 ( |.COMPLEX1K10 ((limSEQ-2K1 s1)/XCMPLX-0K7 s1 .FUNCT-1K1 m)#QPREPOWERK4 p -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              then have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 ( |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.|)*XCMPLX-0K3 (c /XCMPLX-0K7 d)"
                using A44 A39 A47 xreal_1_th_68 sorry
              thus " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
                using A48 xxreal_0_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 (limSEQ-2K1 s1)#QPREPOWERK4 p .| <XXREAL-0R3 c"
           sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
      using A2 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_89:
" for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((s1 be convergentSEQ-2V5 & s2 be convergentSEQ-2V5) & limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6) & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
proof-
  have " for p be RationalRAT-1M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & (limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6 & ( for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p))) implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix p assume [ty]: "p be RationalRAT-1M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
    assume A1: "s1 be convergentSEQ-2V5"
      and A2: "s2 be convergentSEQ-2V5"
      and A3: "limSEQ-2K1 s1 >XXREAL-0R4 0NUMBERSK6"
      and A4: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s2 .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p"
    show "limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
    proof-
      have cases: "p >=XXREAL-0R2 0NUMBERSK6 or p <=XXREAL-0R1 0NUMBERSK6"
         sorry
      have case1: "p >=XXREAL-0R2 0NUMBERSK6 implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
      proof(rule impI)
        assume "p >=XXREAL-0R2 0NUMBERSK6"
        thus "limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
          using A1 A2 A3 A4 prepower_lm_10 sorry
      qed
      have case2: "p <=XXREAL-0R1 0NUMBERSK6 implies limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
      proof(rule impI)
        assume A5: "p <=XXREAL-0R1 0NUMBERSK6"
        have "s1 be boundedSEQ-2V6"
          using A1 sorry
        then obtain d where
          [ty]:"d be RealXREAL-0M1" and 
          A6: "d >XXREAL-0R4 0NUMBERSK6"and A7: " for n be NatNAT-1M1 holds  |.COMPLEX1K10 s1 .FUNCT-1K1 n.| <XXREAL-0R3 d"
          using seq_2_th_3 sorry
        have 
          [ty]:"d be RealXREAL-0M1"
           sorry
        have A8: "d #QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
          using A6 prepower_th_52 sorry
        have A9: "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6"
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A10: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 d #QPREPOWERK4 p"
            using A2 A8 seq_2_def_7 sorry
          have " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  False "
          proof(rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            have A11: "s1 .FUNCT-1K1 m >XXREAL-0R4 0NUMBERSK6"
              using A4 sorry
            have A12: "s1 .FUNCT-1K1 m <>HIDDENR2 0NUMBERSK6"
              using A4 sorry
            have A13: "(s1 .FUNCT-1K1 m)#QPREPOWERK4 p >XXREAL-0R4 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            have " |.COMPLEX1K10 s1 .FUNCT-1K1 m.| <XXREAL-0R3 d"
              using A7 sorry
            then have "s1 .FUNCT-1K1 m <XXREAL-0R3 d"
              using A11 absvalue_def_1 sorry
            then have "s1 .FUNCT-1K1 m /XCMPLX-0K7 s1 .FUNCT-1K1 m <XXREAL-0R3 d /XCMPLX-0K7 s1 .FUNCT-1K1 m"
              using A11 xreal_1_th_74 sorry
            then have "\<one>\<^sub>M <=XXREAL-0R1 d /XCMPLX-0K7 s1 .FUNCT-1K1 m"
              using A12 xcmplx_1_th_60 sorry
            then have "(d /XCMPLX-0K7 s1 .FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
              using A5 prepower_th_61 sorry
            then have "d #QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M"
              using A6 A11 prepower_th_58 sorry
            then have A14: "(d #QPREPOWERK4 p /XCMPLX-0K7 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p)*XCMPLX-0K3 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p"
              using A13 xreal_1_th_64 sorry
            have A15: "(s1 .FUNCT-1K1 m)#QPREPOWERK4 p <>HIDDENR2 0NUMBERSK6"
              using A4 prepower_th_52 sorry
            assume "m >=XXREAL-0R2 n"
            then have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 d #QPREPOWERK4 p"
              using A10 sorry
            then have " |.COMPLEX1K10 (s1 .FUNCT-1K1 m)#QPREPOWERK4 p.| <XXREAL-0R3 d #QPREPOWERK4 p"
              using A4 sorry
            then have "(s1 .FUNCT-1K1 m)#QPREPOWERK4 p <XXREAL-0R3 d #QPREPOWERK4 p"
              using A13 absvalue_def_1 sorry
            thus " False "
              using A15 A14 xcmplx_1_th_87 sorry
          qed "sorry"
          thus " False "
             sorry
        qed
        have " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "(s1 .FUNCT-1K1 n)#QPREPOWERK4 p <>HIDDENR2 0NUMBERSK6"
            using A4 prepower_th_52 sorry
          thus "s2 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
            using A4 sorry
        qed "sorry"
        then have A16: "s2 be non-zeroORDINAL1V9"
          using seq_1_th_5 sorry
        then have A17: "limSEQ-2K1 s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 s2)\<inverse>XCMPLX-0K5"
          using A2 A9 seq_2_th_22 sorry
        let ?O = "\<lambda>Lamb1. (s2 .FUNCT-1K1 Lamb1)\<inverse>XCMPLX-0K5"
        obtain s where
          [ty]:"s be Real-SequenceSEQ-1M1" and 
          A18: " for n be NatNAT-1M1 holds s .FUNCT-1K1 n =COMPLEX1R1 ?O(n)"
          using seq_1_sch_1 sorry
        have A19: " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 (-XCMPLX-0K4 p)"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "s .FUNCT-1K1 n =HIDDENR1 (s2 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
            using A18 sorry
          also have "... = ((s1 .FUNCT-1K1 n)#QPREPOWERK4 p)\<inverse>XCMPLX-0K5"
            using A4 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 (s1 .FUNCT-1K1 n)#QPREPOWERK4 p"
             sorry
          also have "... = (s1 .FUNCT-1K1 n)#QPREPOWERK4 (-XCMPLX-0K4 p)"
            using A4 prepower_th_54 sorry
          finally have "s .FUNCT-1K1 n =HIDDENR1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 (-XCMPLX-0K4 p)"
             sorry
          thus "s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & s .FUNCT-1K1 n =COMPLEX1R1 (s1 .FUNCT-1K1 n)#QPREPOWERK4 (-XCMPLX-0K4 p)"
            using A4 sorry
        qed "sorry"
        have A20: "domRELAT-1K1 s2 =HIDDENR1 NATNUMBERSK1"
          using funct_2_def_1 sorry
        have A21: "domRELAT-1K1 s =HIDDENR1 NATNUMBERSK1"
          using funct_2_def_1 sorry
        have " for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 s implies s .FUNCT-1K1 n =COMPLEX1R1 (s2 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
          using A18 sorry
        then have A22: "s =FUNCT-1R1 s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub>"
          using A21 A20 valued_1_def_7 sorry
        have "s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
          using A2 A16 A9 seq_2_th_21 sorry
        then have "(limSEQ-2K1 s2)\<inverse>XCMPLX-0K5 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 (-XCMPLX-0K4 p)"
          using A1 A3 A5 A17 A22 A19 prepower_lm_10 sorry
        then have "\<one>\<^sub>M /XCMPLX-0K7 (limSEQ-2K1 s2) =COMPLEX1R1 \<one>\<^sub>M /XCMPLX-0K7 (limSEQ-2K1 s1)#QPREPOWERK4 p"
          using A3 prepower_th_54 sorry
        thus "limSEQ-2K1 s2 =COMPLEX1R1 (limSEQ-2K1 s1)#QPREPOWERK4 p"
          using xcmplx_1_th_59 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#QPREPOWERK4 p =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 p)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for p be RationalRAT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#QPREPOWERK4 p =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 p)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix p assume [ty]: "p be RationalRAT-1M1"
    obtain s1 where
      [ty]:"s1 be Rational-SequencePREPOWERM1" and 
      A1: "s1 be convergentSEQ-2V5"and A2: "b =COMPLEX1R1 limSEQ-2K1 s1"and " for n be NatNAT-1M1 holds s1 .FUNCT-1K1 n >=XXREAL-0R2 b"
      using prepower_th_68 sorry
    obtain s2 where 
      [ty]:"s2 be Rational-SequencePREPOWERM1" and s2Def:"s2 = p (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s1"
       sorry
    assume A3: "a >XXREAL-0R4 0NUMBERSK6"
    have A4: " for n be NatNAT-1M1 holds a #QPREPOWERK5 s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & (a #QPREPOWERK5 s1 .FUNCT-1K1 n)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have A5: "a #QPREPOWERK4 (s1 .FUNCT-1K1 n) >XXREAL-0R4 0NUMBERSK6"
        using A3 prepower_th_52 sorry
      have "(a #QPREPOWERK5 s1 .FUNCT-1K1 n)#QPREPOWERK4 p =HIDDENR1 (a #QPREPOWERK4 (s1 .FUNCT-1K1 n))#QPREPOWERK4 p"
        using prepower_def_6 sorry
      also have "... = a #QPREPOWERK4 (p *XCMPLX-0K3 s1 .FUNCT-1K1 n)"
        using A3 prepower_th_59 sorry
      also have "... = a #QPREPOWERK4 (s2 .FUNCT-1K1 n)"
        using seq_1_th_9 sorry
      also have "... = a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using prepower_def_6 sorry
      finally have "(a #QPREPOWERK5 s1 .FUNCT-1K1 n)#QPREPOWERK4 p =HIDDENR1 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
         sorry
      thus "a #QPREPOWERK5 s1 .FUNCT-1K1 n >XXREAL-0R4 0NUMBERSK6 & (a #QPREPOWERK5 s1 .FUNCT-1K1 n)#QPREPOWERK4 p =COMPLEX1R1 a #QPREPOWERK5 s2 .FUNCT-1K1 n"
        using A5 prepower_def_6 sorry
    qed "sorry"
    have A6: "s2 be convergentSEQ-2V5"
      using A1 sorry
    then have A7: "a #QPREPOWERK5 s2 be convergentSEQ-2V5"
      using A3 prepower_th_69 sorry
    have "limSEQ-2K1 s2 =COMPLEX1R1 b *XCMPLX-0K3 p"
      using A1 A2 seq_2_th_8 sorry
    then have A8: "a #RPREPOWERK6 (b *XCMPLX-0K3 p) =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s2"
      using A3 A6 A7 prepower_def_7 sorry
    have A9: "a #QPREPOWERK5 s1 be convergentSEQ-2V5"
      using A3 A1 prepower_th_69 sorry
    then have "a #RPREPOWERK6 b =COMPLEX1R1 limSEQ-2K1 a #QPREPOWERK5 s1"
      using A3 A1 A2 prepower_def_7 sorry
    thus "(a #RPREPOWERK6 b)#QPREPOWERK4 p =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 p)"
      using A3 A9 A7 A8 A4 prepower_th_81 prepower_th_89 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma prepower_lm_12:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((a >=XXREAL-0R2 \<one>\<^sub>M & s1 be convergentSEQ-2V5) & s2 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
proof-
  have " for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds a >=XXREAL-0R2 \<one>\<^sub>M & (s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)))) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
    assume A1: "a >=XXREAL-0R2 \<one>\<^sub>M"
      and A2: "s1 be convergentSEQ-2V5"
      and A3: "s2 be convergentSEQ-2V5"
      and A4: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)"
    let ?d = " |.COMPLEX1K10 limSEQ-2K1 s1 .| +XCMPLX-0K2 \<one>\<^sub>M"
    have A5: " |.COMPLEX1K10 limSEQ-2K1 s1 .| <XXREAL-0R3  |.COMPLEX1K10 limSEQ-2K1 s1 .| +XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_1_th_29 sorry
    have " for c be RealXREAL-0M1 holds c >XXREAL-0R4 0NUMBERSK6 implies ( ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| <XXREAL-0R3 c)"
    proof(rule ballI,rule impI)
      have "limSEQ-2K1 s1 <=XXREAL-0R1  |.COMPLEX1K10 limSEQ-2K1 s1 .|"
        using absvalue_th_4 sorry
      then have "limSEQ-2K1 s1 <=XXREAL-0R1 ?d"
        using A5 xxreal_0_th_2 sorry
      then have A6: "a #RPREPOWERK6 (limSEQ-2K1 s1) <=XXREAL-0R1 a #RPREPOWERK6 ?d"
        using A1 prepower_th_82 sorry
      have "a #RPREPOWERK6 (limSEQ-2K1 s1) >XXREAL-0R4 0NUMBERSK6"
        using A1 prepower_th_81 sorry
      then have A7: " |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).| <=XXREAL-0R1 a #RPREPOWERK6 ?d"
        using A6 absvalue_def_1 sorry
      have A8: "a #RPREPOWERK6 ?d >=XXREAL-0R2 0NUMBERSK6"
        using A1 prepower_th_81 sorry
      fix c assume [ty]: "c be RealXREAL-0M1"
      assume A9: "c >XXREAL-0R4 0NUMBERSK6"
      obtain m1 where
        [ty]:"m1 be NatNAT-1M1" and 
        A10: "(a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1"
        using seq_4_th_3 sorry
      have "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 m1"
        using xreal_1_th_29 sorry
      then have "(a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c <XXREAL-0R3 m1 +NAT-1K1 \<one>\<^sub>M"
        using A10 xxreal_0_th_2 sorry
      then have "((a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 c)*XCMPLX-0K3 c <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A9 xreal_1_th_68 sorry
      then have "a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M) <XXREAL-0R3 c *XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using A9 xcmplx_1_th_87 sorry
      then have "(a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 ((m1 +NAT-1K1 \<one>\<^sub>M)*XCMPLX-0K3 c)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
        using xreal_1_th_74 sorry
      then have "(a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 (c /XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))*XCMPLX-0K3 (m1 +NAT-1K1 \<one>\<^sub>M)"
         sorry
      then have A11: "(a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M) <XXREAL-0R3 c"
        using xcmplx_1_th_87 sorry
      obtain m3 where 
        [ty]:"m3 be RationalRAT-1M1" and m3Def:"m3 = (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
         sorry
      have A12: " |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).| >=XXREAL-0R2 0NUMBERSK6"
        using complex1_th_46 sorry
      obtain n where
        [ty]:"n be NatNAT-1M1" and 
        A13: " for m be NatNAT-1M1 holds n <=XXREAL-0R1 m implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
        using A2 seq_2_def_7 sorry
      show " ex n be NatNAT-1M1 st  for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| <XXREAL-0R3 c"
      proof(rule bexI[of _ "n"],rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "m >=XXREAL-0R2 n"
        then have A14: " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using A13 sorry
        have A15: "m1 +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "(m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using A1 prepower_th_31 sorry
        then have A16: "a #RPREPOWERK6 ?d *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M) <=XXREAL-0R1 a #RPREPOWERK6 ?d *XCMPLX-0K3 ((a -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M))"
          using A8 xreal_1_th_64 sorry
        have "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <=XXREAL-0R1  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .|"
          using absvalue_th_4 sorry
        then have "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)\<inverse>XCMPLX-0K5"
          using A14 xxreal_0_th_2 sorry
        then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 a #RPREPOWERK6 m3"
          using A1 prepower_th_82 sorry
        then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 a #QPREPOWERK4 m3"
          using A1 prepower_th_74 sorry
        then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
          using A15 prepower_th_50 sorry
        then have A17: "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          using xreal_1_th_9 sorry
        have A18: "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_81 sorry
        have A19: "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) >XXREAL-0R4 0NUMBERSK6"
          using A1 prepower_th_81 sorry
        have A20: " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
        proof-
          show " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
          proof-
            have cases: "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 >=XXREAL-0R2 0NUMBERSK6 or s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 0NUMBERSK6"
               sorry
            have case1: "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 >=XXREAL-0R2 0NUMBERSK6 implies  |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule impI)
              assume "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 >=XXREAL-0R2 0NUMBERSK6"
              then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) >=XXREAL-0R2 \<one>\<^sub>M"
                using A1 prepower_th_85 sorry
              then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
                using xreal_1_th_48 sorry
              thus " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A17 absvalue_def_1 sorry
            qed
            have case2: "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 0NUMBERSK6 implies  |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule impI)
              assume A21: "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 0NUMBERSK6"
              have A22: "-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1  |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|"
                using absvalue_th_4 sorry
              have " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| =COMPLEX1R1  |.COMPLEX1K10 -XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|"
                using complex1_th_52 sorry
              then have "-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 m3"
                using A14 A22 xxreal_0_th_2 sorry
              then have "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) <=XXREAL-0R1 a #RPREPOWERK6 m3"
                using A1 prepower_th_82 sorry
              then have "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) <=XXREAL-0R1 a #QPREPOWERK4 m3"
                using A1 prepower_th_74 sorry
              then have "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a"
                using A15 prepower_th_50 sorry
              then have A23: "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              have "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) >=XXREAL-0R2 \<one>\<^sub>M"
                using A1 A21 prepower_th_85 sorry
              then have "a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
                using xreal_1_th_48 sorry
              then have A24: " |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A23 absvalue_def_1 sorry
              have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) <=XXREAL-0R1 \<one>\<^sub>M"
                using A1 A21 prepower_th_87 sorry
              then have A25: " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).| <=XXREAL-0R1 \<one>\<^sub>M"
                using A19 absvalue_def_1 sorry
              have " |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
                using complex1_th_46 sorry
              then have A26: "( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                using A25 xreal_1_th_64 sorry
              have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1  |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<one>\<^sub>M .|"
                 sorry
              also have "... =  |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) /XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) .|"
                using A18 xcmplx_1_th_60 sorry
              also have "... =  |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) *XCMPLX-0K3 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|"
                 sorry
              also have "... =  |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) *XCMPLX-0K3 ((a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) .|"
                 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M)/XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|)"
                using complex1_th_65 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) /XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|)"
                 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) .|)"
                using A18 xcmplx_1_th_60 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 \<one>\<^sub>M -XCMPLX-0K6 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) .|)"
                using A1 prepower_th_76 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 -XCMPLX-0K4 (\<one>\<^sub>M -XCMPLX-0K6 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1))) .|)"
                using complex1_th_52 sorry
              also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              finally have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| =HIDDENR1 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (-XCMPLX-0K4 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)) -XCMPLX-0K6 \<one>\<^sub>M .|)"
                 sorry
              thus " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| <=XXREAL-0R1 (m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M"
                using A24 A26 xxreal_0_th_2 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .| >=XXREAL-0R2 0NUMBERSK6"
          using complex1_th_46 sorry
        then have A27: "( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .|) <=XXREAL-0R1 a #RPREPOWERK6 ?d *XCMPLX-0K3 ((m1 +NAT-1K1 \<one>\<^sub>M)-RootPREPOWERK2 a -XCMPLX-0K6 \<one>\<^sub>M)"
          using A20 A12 A7 xreal_1_th_66 sorry
        have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| =HIDDENR1  |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1))*XCMPLX-0K3 \<one>\<^sub>M .|"
           sorry
        also have "... =  |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1))*XCMPLX-0K3 (a #RPREPOWERK6 (limSEQ-2K1 s1) /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1)) .|"
          using A1 prepower_lm_9 xcmplx_1_th_60 sorry
        also have "... =  |.COMPLEX1K10 (a #RPREPOWERK6 (limSEQ-2K1 s1) *XCMPLX-0K3 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1)))/XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1) .|"
           sorry
        also have "... =  |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1) *XCMPLX-0K3 ((a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1))/XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1)) .|"
           sorry
        also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 (a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1))/XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1) .|)"
          using complex1_th_65 sorry
        also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1) .|)"
           sorry
        also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .|)"
          using A1 prepower_lm_9 xcmplx_1_th_60 sorry
        also have "... = ( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .|)"
          using A1 prepower_th_77 sorry
        finally have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| =HIDDENR1 ( |.COMPLEX1K10 a #RPREPOWERK6 (limSEQ-2K1 s1).|)*XCMPLX-0K3 ( |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1) -XCMPLX-0K6 \<one>\<^sub>M .|)"
           sorry
        then have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| <=XXREAL-0R1 (a #RPREPOWERK6 ?d *XCMPLX-0K3 (a -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (m1 +NAT-1K1 \<one>\<^sub>M)"
          using A27 A16 xxreal_0_th_2 sorry
        then have " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m) -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| <XXREAL-0R3 c"
          using A11 xxreal_0_th_2 sorry
        thus " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 a #RPREPOWERK6 (limSEQ-2K1 s1) .| <XXREAL-0R3 c"
          using A4 sorry
      qed "sorry"
    qed "sorry"
    thus "limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
      using A3 seq_2_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_90:
" for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds ((a >XXREAL-0R4 0NUMBERSK6 & s1 be convergentSEQ-2V5) & s2 be convergentSEQ-2V5) & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
proof-
  have " for a be RealXREAL-0M1 holds  for s1 be Real-SequenceSEQ-1M1 holds  for s2 be Real-SequenceSEQ-1M1 holds a >XXREAL-0R4 0NUMBERSK6 & (s1 be convergentSEQ-2V5 & (s2 be convergentSEQ-2V5 & ( for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)))) implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix s1 assume [ty]: "s1 be Real-SequenceSEQ-1M1"
    fix s2 assume [ty]: "s2 be Real-SequenceSEQ-1M1"
    assume A1: "a >XXREAL-0R4 0NUMBERSK6"
      and A2: "s1 be convergentSEQ-2V5"
      and A3: "s2 be convergentSEQ-2V5"
      and A4: " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)"
    show "limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
    proof-
      have cases: "a >=XXREAL-0R2 \<one>\<^sub>M or a <XXREAL-0R3 \<one>\<^sub>M"
         sorry
      have case1: "a >=XXREAL-0R2 \<one>\<^sub>M implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
      proof(rule impI)
        assume "a >=XXREAL-0R2 \<one>\<^sub>M"
        thus "limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
          using A2 A3 A4 prepower_lm_12 sorry
      qed
      have case2: "a <XXREAL-0R3 \<one>\<^sub>M implies limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
      proof(rule impI)
        assume A5: "a <XXREAL-0R3 \<one>\<^sub>M"
        have A6: "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6 implies  False "
        proof(rule impI)
          assume A7: "limSEQ-2K1 s2 =COMPLEX1R1 0NUMBERSK6"
          have "a #RPREPOWERK6 (limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
            using A1 prepower_th_81 sorry
          then obtain n where
            [ty]:"n be NatNAT-1M1" and 
            A8: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n implies  |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 a #RPREPOWERK6 (limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M)"
            using A3 A7 seq_2_def_7 sorry
          obtain n1 where
            [ty]:"n1 be NatNAT-1M1" and 
            A9: " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n1 implies  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 \<one>\<^sub>M"
            using A2 seq_2_def_7 sorry
          have " for m be NatNAT-1M1 holds m >=XXREAL-0R2 n +XCMPLX-0K2 n1 implies  False "
          proof(rule ballI,rule impI)
            fix m assume [ty]: "m be NatNAT-1M1"
            assume A10: "m >=XXREAL-0R2 n +XCMPLX-0K2 n1"
            have "n +XCMPLX-0K2 n1 >=XXREAL-0R2 n1"
              using nat_1_th_12 sorry
            then have "m >=XXREAL-0R2 n1"
              using A10 xxreal_0_th_2 sorry
            then have A11: " |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .| <XXREAL-0R3 \<one>\<^sub>M"
              using A9 sorry
            have "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <=XXREAL-0R1  |.COMPLEX1K10 s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 .|"
              using absvalue_th_4 sorry
            then have "s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1 <XXREAL-0R3 \<one>\<^sub>M"
              using A11 xxreal_0_th_2 sorry
            then have A12: "(s1 .FUNCT-1K1 m -XCMPLX-0K6 limSEQ-2K1 s1)+XCMPLX-0K2 limSEQ-2K1 s1 <XXREAL-0R3 limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M"
              using xreal_1_th_6 sorry
            have "n +XCMPLX-0K2 n1 >=XXREAL-0R2 n"
              using nat_1_th_12 sorry
            then have "m >=XXREAL-0R2 n"
              using A10 xxreal_0_th_2 sorry
            then have " |.COMPLEX1K10 s2 .FUNCT-1K1 m -XCMPLX-0K6 0NUMBERSK6 .| <XXREAL-0R3 a #RPREPOWERK6 (limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M)"
              using A8 sorry
            then have A13: " |.COMPLEX1K10 a #RPREPOWERK6 (s1 .FUNCT-1K1 m).| <XXREAL-0R3 a #RPREPOWERK6 (limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M)"
              using A4 sorry
            have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m) >XXREAL-0R4 0NUMBERSK6"
              using A1 prepower_th_81 sorry
            then have "a #RPREPOWERK6 (s1 .FUNCT-1K1 m) <XXREAL-0R3 a #RPREPOWERK6 (limSEQ-2K1 s1 +XCMPLX-0K2 \<one>\<^sub>M)"
              using A13 absvalue_def_1 sorry
            thus " False "
              using A1 A5 A12 prepower_th_84 sorry
          qed "sorry"
          thus " False "
             sorry
        qed
        have A14: " for n be NatNAT-1M1 holds s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 (s1 .FUNCT-1K1 n)"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (s2 .FUNCT-1K1 n)\<inverse>XCMPLX-0K5"
            using valued_1_th_10 sorry
          also have "... = (a #RPREPOWERK6 (s1 .FUNCT-1K1 n))\<inverse>XCMPLX-0K5"
            using A4 sorry
          also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)"
             sorry
          also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 (s1 .FUNCT-1K1 n)"
            using A1 prepower_th_79 sorry
          finally show "s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> .FUNCT-1K1 n =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 (s1 .FUNCT-1K1 n)"
             sorry
        qed "sorry"
        have "a *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a) <=XXREAL-0R1 \<one>\<^sub>M *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a)"
          using A1 A5 xreal_1_th_64 sorry
        then have A15: "\<one>\<^sub>M <=XXREAL-0R1 \<one>\<^sub>M /XCMPLX-0K7 a"
          using A1 xcmplx_1_th_106 sorry
        have A16: "a #RPREPOWERK6 (limSEQ-2K1 s1) <>HIDDENR2 0NUMBERSK6"
          using A1 prepower_th_81 sorry
        have " for n be NatNAT-1M1 holds s2 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
        proof(rule ballI)
          fix n assume [ty]: "n be NatNAT-1M1"
          have "s2 .FUNCT-1K1 n =COMPLEX1R1 a #RPREPOWERK6 (s1 .FUNCT-1K1 n)"
            using A4 sorry
          thus "s2 .FUNCT-1K1 n <>HIDDENR2 0NUMBERSK6"
            using A1 prepower_th_81 sorry
        qed "sorry"
        then have A17: "s2 be non-zeroORDINAL1V9"
          using seq_1_th_5 sorry
        then have A18: "limSEQ-2K1 s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> =COMPLEX1R1 (limSEQ-2K1 s2)\<inverse>XCMPLX-0K5"
          using A3 A6 seq_2_th_22 sorry
        have "s2 \<inverse>VALUED-1K39\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> be convergentSEQ-2V5"
          using A3 A6 A17 seq_2_th_21 sorry
        then have "(limSEQ-2K1 s2)\<inverse>XCMPLX-0K5 =HIDDENR1 (\<one>\<^sub>M /XCMPLX-0K7 a)#RPREPOWERK6 (limSEQ-2K1 s1)"
          using A2 A15 A18 A14 prepower_lm_12 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1)"
          using A1 prepower_th_79 sorry
        finally have "(limSEQ-2K1 s2)\<inverse>XCMPLX-0K5 =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1)"
           sorry
        then have "\<one>\<^sub>M =COMPLEX1R1 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1))*XCMPLX-0K3 (limSEQ-2K1 s2)"
          using A6 xcmplx_0_def_7 sorry
        then have "a #RPREPOWERK6 (limSEQ-2K1 s1) =HIDDENR1 a #RPREPOWERK6 (limSEQ-2K1 s1) *XCMPLX-0K3 ((\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1))*XCMPLX-0K3 (limSEQ-2K1 s2))"
           sorry
        also have "... = (a #RPREPOWERK6 (limSEQ-2K1 s1) *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 a #RPREPOWERK6 (limSEQ-2K1 s1)))*XCMPLX-0K3 (limSEQ-2K1 s2)"
           sorry
        also have "... = \<one>\<^sub>M *XCMPLX-0K3 (limSEQ-2K1 s2)"
          using A16 xcmplx_1_th_106 sorry
        finally have "a #RPREPOWERK6 (limSEQ-2K1 s1) =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 (limSEQ-2K1 s2)"
           sorry
        thus "limSEQ-2K1 s2 =COMPLEX1R1 a #RPREPOWERK6 (limSEQ-2K1 s1)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_91:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 c)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds a >XXREAL-0R4 0NUMBERSK6 implies (a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 c)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    obtain s where
      [ty]:"s be Rational-SequencePREPOWERM1" and 
      A1: "s be convergentSEQ-2V5"and A2: "c =COMPLEX1R1 limSEQ-2K1 s"and " for n be NatNAT-1M1 holds s .FUNCT-1K1 n <=XXREAL-0R1 c"
      using prepower_th_67 sorry
    have A3: "limSEQ-2K1 (b (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s) =COMPLEX1R1 b *XCMPLX-0K3 c"
      using A1 A2 seq_2_th_8 sorry
    have A4: "b (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s be convergentSEQ-2V5"
      using A1 sorry
    assume A5: "a >XXREAL-0R4 0NUMBERSK6"
    then have A6: "(a #RPREPOWERK6 b)#QPREPOWERK5 s be convergentSEQ-2V5"
      using A1 prepower_th_69 prepower_th_81 sorry
    have A7: " for n be NatNAT-1M1 holds (a #RPREPOWERK6 b)#QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #RPREPOWERK6 ((b (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s).FUNCT-1K1 n)"
    proof(rule ballI)
      fix n assume [ty]: "n be NatNAT-1M1"
      have "(a #RPREPOWERK6 b)#QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 (a #RPREPOWERK6 b)#QPREPOWERK4 (s .FUNCT-1K1 n)"
        using prepower_def_6 sorry
      also have "... = a #RPREPOWERK6 (b *XCMPLX-0K3 s .FUNCT-1K1 n)"
        using A5 prepower_lm_11 sorry
      also have "... = a #RPREPOWERK6 ((b (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s).FUNCT-1K1 n)"
        using seq_1_th_9 sorry
      finally show "(a #RPREPOWERK6 b)#QPREPOWERK5 s .FUNCT-1K1 n =HIDDENR1 a #RPREPOWERK6 ((b (#)VALUED-1K28\<^bsub>(omegaORDINAL1K4,REALNUMBERSK2)\<^esub> s).FUNCT-1K1 n)"
         sorry
    qed "sorry"
    have "a #RPREPOWERK6 b >XXREAL-0R4 0NUMBERSK6"
      using A5 prepower_th_81 sorry
    then have "(a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 limSEQ-2K1 (a #RPREPOWERK6 b)#QPREPOWERK5 s"
      using A1 A2 A6 prepower_def_7 sorry
    thus "(a #RPREPOWERK6 b)#RPREPOWERK6 c =COMPLEX1R1 a #RPREPOWERK6 (b *XCMPLX-0K3 c)"
      using A5 A6 A4 A3 A7 prepower_th_90 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
reserve r, u for "RealXREAL-0M1"
reserve k for "NatNAT-1M1"
mtheorem prepower_th_92:
" for r be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & u >XXREAL-0R4 0NUMBERSK6 implies ( ex k be NatNAT-1M1 st u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 k <=XXREAL-0R1 r)"
proof-
  have " for r be RealXREAL-0M1 holds  for u be RealXREAL-0M1 holds r >XXREAL-0R4 0NUMBERSK6 & u >XXREAL-0R4 0NUMBERSK6 implies ( ex tVar19 be NatNAT-1M1 st u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 tVar19 <=XXREAL-0R1 r)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix u assume [ty]: "u be RealXREAL-0M1"
    let ?P = "\<lambda>Lamb1. Lamb1 <=XXREAL-0R1 \<two>\<^sub>M  |^NEWTONK1 Lamb1"
    assume A1: "r >XXREAL-0R4 0NUMBERSK6"
      and A2: "u >XXREAL-0R4 0NUMBERSK6"
    let ?t = "\<one>\<^sub>M /XCMPLX-0K7 r"
    obtain t where 
      [ty]:"t be RealXREAL-0M1" and tDef:"t = ?t"
       sorry
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "u *XCMPLX-0K3 t <XXREAL-0R3 n"
      using seq_4_th_3 sorry
    have A4: "0NUMBERSK6 <XXREAL-0R3 u *XCMPLX-0K3 t"
      using A1 A2 sorry
    then have A5: "u /XCMPLX-0K7 (u *XCMPLX-0K3 t) >XXREAL-0R4 u /XCMPLX-0K7 n"
      using A2 A3 xreal_1_th_76 sorry
    have A6: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds k <=XXREAL-0R1 \<two>\<^sub>M  |^NEWTONK1 k implies k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<two>\<^sub>M  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume "k <=XXREAL-0R1 \<two>\<^sub>M  |^NEWTONK1 k"
        then have A7: "\<two>\<^sub>M  |^NEWTONK1 k +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 k +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        have "\<two>\<^sub>M  |^NEWTONK1 k >=XXREAL-0R2 \<one>\<^sub>M"
          using prepower_th_11 sorry
        then have A8: "\<two>\<^sub>M  |^NEWTONK1 k +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 k >=XXREAL-0R2 \<two>\<^sub>M  |^NEWTONK1 k +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_7 sorry
        have "\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M"
          using newton_th_8 sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK1 k *XCMPLX-0K3 \<two>\<^sub>M"
           sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK1 k +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 k"
           sorry
        finally have "\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 k +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 k"
           sorry
        thus "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 \<two>\<^sub>M  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
          using A8 A7 xxreal_0_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    show " ex tVar19 be NatNAT-1M1 st u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 tVar19 <=XXREAL-0R1 r"
    proof(rule bexI[of _ "n"])
      have A9: "r =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 t"
         sorry
      also have "... = (u *XCMPLX-0K3 \<one>\<^sub>M)/XCMPLX-0K7 (u *XCMPLX-0K3 t)"
        using A2 xcmplx_1_th_91 sorry
      also have "... = u /XCMPLX-0K7 (u *XCMPLX-0K3 t)"
         sorry
      finally have "r =HIDDENR1 u /XCMPLX-0K7 (u *XCMPLX-0K3 t)"
         sorry
      have A10: "?P(0NUMBERSK6)"
         sorry
      have " for k be NatNAT-1M1 holds ?P(k)"
        using nat_1_sch_2 A10 A6 sorry
      then have "u /XCMPLX-0K7 n >=XXREAL-0R2 u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 n"
        using A2 A3 A4 xreal_1_th_118 sorry
      thus "u /XCMPLX-0K7 \<two>\<^sub>M  |^NEWTONK1 n <=XXREAL-0R1 r"
        using A9 A5 xxreal_0_th_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_93:
" for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for k be NatNAT-1M1 holds k >=XXREAL-0R2 n & r >=XXREAL-0R2 \<one>\<^sub>M implies r  |^NEWTONK1 k >=XXREAL-0R2 r  |^NEWTONK1 n"
proof-
  have " for n be NatNAT-1M1 holds  for r be RealXREAL-0M1 holds  for k be NatNAT-1M1 holds k >=XXREAL-0R2 n & r >=XXREAL-0R2 \<one>\<^sub>M implies r  |^NEWTONK1 k >=XXREAL-0R2 r  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "k >=XXREAL-0R2 n"
      and A2: "r >=XXREAL-0R2 \<one>\<^sub>M"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "k =COMPLEX1R1 n +XCMPLX-0K2 m"
      using A1 nat_1_th_10 sorry
    have A4: "r  |^NEWTONK1 k =COMPLEX1R1 r  |^NEWTONK1 n *XCMPLX-0K3 r  |^NEWTONK1 m"
      using A3 newton_th_8 sorry
    have "r  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 prepower_th_11 sorry
    thus "r  |^NEWTONK1 k >=XXREAL-0R2 r  |^NEWTONK1 n"
      using A2 A4 prepower_th_11 xreal_1_th_151 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_94:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for l be NatNAT-1M1 holds n dividesNAT-DR1 m & n dividesNAT-DR1 l implies n dividesINT-1R1 m -XCMPLX-0K6 l"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix l assume [ty]: "l be NatNAT-1M1"
  assume A1: "n dividesNAT-DR1 m"
    and A2: "n dividesNAT-DR1 l"
  have A3: "-XCMPLX-0K4 l =HIDDENR1 -XCMPLX-0K4 n *XCMPLX-0K3 (l divNAT-DK3 n)"
    using A2 nat_d_th_3 sorry
  also have "... = n *XCMPLX-0K3 (-XCMPLX-0K4 (l divNAT-DK3 n))"
     sorry
  finally have "-XCMPLX-0K4 l =HIDDENR1 n *XCMPLX-0K3 (-XCMPLX-0K4 (l divNAT-DK3 n))"
     sorry
  have "m =COMPLEX1R1 n *XCMPLX-0K3 (m divNAT-DK3 n)"
    using A1 nat_d_th_3 sorry
  then have "m -XCMPLX-0K6 l =COMPLEX1R1 n *XCMPLX-0K3 ((m divNAT-DK3 n)+XCMPLX-0K2 (-XCMPLX-0K4 (l divNAT-DK3 n)))"
    using A3 sorry
  thus "n dividesINT-1R1 m -XCMPLX-0K6 l"
    using int_1_def_3 sorry
qed "sorry"

mtheorem prepower_th_95:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m dividesNAT-DR1 n iff m dividesINT-1R1 n"
   sorry

mtheorem prepower_th_96:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?x = "m gcdNAT-DK8 n"
    let ?y = "m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
    have A1: "?x dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    have A2: "?x dividesNAT-DR1 n"
      using nat_d_def_5 sorry
    have A3: "?y dividesNAT-DR1 m"
      using nat_d_def_5 sorry
    show "m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
    proof-
      have cases: "n -XCMPLX-0K6 m >=XXREAL-0R2 0NUMBERSK6 or n -XCMPLX-0K6 m <XXREAL-0R3 0NUMBERSK6"
         sorry
      have case1: "n -XCMPLX-0K6 m >=XXREAL-0R2 0NUMBERSK6 implies m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
      proof(rule impI)
        assume "n -XCMPLX-0K6 m >=XXREAL-0R2 0NUMBERSK6"
        then obtain nm where 
          [ty]:"nm be ElementSUBSET-1M1-of NATNUMBERSK1" and nmDef:"nm = n -XCMPLX-0K6 m"
          using int_1_th_3 sorry
        have A4: " |.INT-2K1 n -XCMPLX-0K6 m .| =COMPLEX1R1 nm"
          using absvalue_def_1 sorry
        then have "?y dividesNAT-DR1 nm"
          using nat_d_def_5 sorry
        then have "?y dividesNAT-DR1 nm +XCMPLX-0K2 m"
          using A3 nat_d_th_8 sorry
        then have A5: "?y dividesNAT-DR1 ?x"
          using A3 nat_d_def_5 sorry
        have "?x dividesINT-1R1 n -XCMPLX-0K6 m"
          using A1 A2 prepower_th_94 sorry
        then have "?x dividesNAT-DR1 ?y"
          using A1 A4 nat_d_def_5 sorry
        thus "m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
          using A5 nat_d_th_5 sorry
      qed
      have case2: "n -XCMPLX-0K6 m <XXREAL-0R3 0NUMBERSK6 implies m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
      proof(rule impI)
        assume A6: "n -XCMPLX-0K6 m <XXREAL-0R3 0NUMBERSK6"
        obtain nn where 
          [ty]:"nn be IntegerINT-1M1" and nnDef:"nn = n"
           sorry
        have A7: " |.INT-2K1 n -XCMPLX-0K6 m .| =HIDDENR1 -XCMPLX-0K4 (n -XCMPLX-0K6 m)"
          using A6 absvalue_def_1 sorry
        also have "... = m -XCMPLX-0K6 n"
           sorry
        finally have " |.INT-2K1 n -XCMPLX-0K6 m .| =HIDDENR1 m -XCMPLX-0K6 n"
           sorry
        then obtain mn where 
          [ty]:"mn be ElementSUBSET-1M1-of NATNUMBERSK1" and mnDef:"mn = m -XCMPLX-0K6 n"
           sorry
        have "?y dividesNAT-DR1 mn"
          using A7 nat_d_def_5 sorry
        then have "?y dividesINT-1R1 mn -XCMPLX-0K6 m"
          using A3 prepower_th_94 sorry
        then have "?y dividesINT-1R1 nn"
          using int_2_th_10 sorry
        then have A8: "?y dividesNAT-DR1 ?x"
          using A3 nat_d_def_5 sorry
        have "?x dividesINT-1R1 m -XCMPLX-0K6 n"
          using A1 A2 prepower_th_94 sorry
        then have "?x dividesNAT-DR1 ?y"
          using A1 A7 nat_d_def_5 sorry
        thus "m gcdNAT-DK8 n =COMPLEX1R1 m gcdNAT-DK8  |.INT-2K1 n -XCMPLX-0K6 m .|"
          using A8 nat_d_th_5 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_97:
" for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b =COMPLEX1R1 a gcdINT-2K3 (b -XCMPLX-0K6 a)"
proof-
  have " for a be IntegerINT-1M1 holds  for b be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 & b >=XXREAL-0R2 0NUMBERSK6 implies a gcdINT-2K3 b =HIDDENR1 a gcdINT-2K3 (b -XCMPLX-0K6 a)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be IntegerINT-1M1"
    fix b assume [ty]: "b be IntegerINT-1M1"
    assume A1: "a >=XXREAL-0R2 0NUMBERSK6"
      and A2: "b >=XXREAL-0R2 0NUMBERSK6"
    have "a gcdINT-2K3 b =HIDDENR1  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b.|"
      using int_2_th_34 sorry
    also have "... =  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1  |.INT-2K1 b.| -XCMPLX-0K6  |.INT-2K1 a.| .|"
      using prepower_th_96 sorry
    also have "... =  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b -XCMPLX-0K6  |.INT-2K1 a.| .|"
      using A2 absvalue_def_1 sorry
    also have "... =  |.INT-2K1 a.| gcdNAT-DK8  |.INT-2K1 b -XCMPLX-0K6 a .|"
      using A1 absvalue_def_1 sorry
    also have "... = a gcdINT-2K3 (b -XCMPLX-0K6 a)"
      using int_2_th_34 sorry
    finally show "a gcdINT-2K3 b =HIDDENR1 a gcdINT-2K3 (b -XCMPLX-0K6 a)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_98:
" for a be RealXREAL-0M1 holds  for l be IntegerINT-1M1 holds a >=XXREAL-0R2 0NUMBERSK6 implies a #ZPREPOWERK3 l >=XXREAL-0R2 0NUMBERSK6"
  using prepower_lm_5 sorry

mtheorem prepower_th_99:
" for a be RealXREAL-0M1 holds  for l be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 l =COMPLEX1R1 a #ZPREPOWERK3 l"
proof-
  have " for a be RealXREAL-0M1 holds  for l be IntegerINT-1M1 holds a >XXREAL-0R4 0NUMBERSK6 implies a #QPREPOWERK4 l =HIDDENR1 a #ZPREPOWERK3 l"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix l assume [ty]: "l be IntegerINT-1M1"
    assume "a >XXREAL-0R4 0NUMBERSK6"
    then have "a #ZPREPOWERK3 l >XXREAL-0R4 0NUMBERSK6"
      using prepower_th_39 sorry
    then have A1: "a #ZPREPOWERK3 l =COMPLEX1R1 \<one>\<^sub>M -RootPREPOWERK2 (a #ZPREPOWERK3 l)  |^NEWTONK1 \<one>\<^sub>M"
      using prepower_def_2 sorry
    have "denominatorRAT-1K2 l =COMPLEX1R1 \<one>\<^sub>M"
      using rat_1_th_17 sorry
    then have "a #QPREPOWERK4 l =HIDDENR1 \<one>\<^sub>M -RootPREPOWERK2 (a #ZPREPOWERK3 l)"
      using rat_1_th_17 sorry
    also have "... = a #ZPREPOWERK3 l"
      using A1 sorry
    finally show "a #QPREPOWERK4 l =HIDDENR1 a #ZPREPOWERK3 l"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem prepower_th_100:
" for l be IntegerINT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
proof-
  have " for l be IntegerINT-1M1 holds l <>HIDDENR2 0NUMBERSK6 implies (0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix l assume [ty]: "l be IntegerINT-1M1"
    assume A1: "l <>HIDDENR2 0NUMBERSK6"
    show "(0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
    proof-
      have cases: "l >XXREAL-0R4 0NUMBERSK6 or l <XXREAL-0R3 0NUMBERSK6"
        using A1 sorry
      have case1: "l >XXREAL-0R4 0NUMBERSK6 implies (0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
      proof(rule impI)
        assume A2: "l >XXREAL-0R4 0NUMBERSK6"
        then have 
          [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
          using int_1_th_3 sorry
        have "l >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using A2 nat_1_th_13 sorry
        then have A3: "(0NUMBERSK6) |^NEWTONK11 l =COMPLEX1R1 0NUMBERSK6"
          using newton_th_11 sorry
        have " |.INT-2K1 l.| =COMPLEX1R1 l"
          using absvalue_def_1 sorry
        thus "(0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
          using A3 prepower_def_3 sorry
      qed
      have case2: "l <XXREAL-0R3 0NUMBERSK6 implies (0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
      proof(rule impI)
        assume A4: "l <XXREAL-0R3 0NUMBERSK6"
        then obtain k where 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = -XCMPLX-0K4 l"
          using int_1_th_3 sorry
        have "k >XXREAL-0R4 -XCMPLX-0K4 0NUMBERSK6"
          using A4 sorry
        then have "k >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have A5: "(0NUMBERSK6) |^NEWTONK11 k =COMPLEX1R1 0NUMBERSK6"
          using newton_th_11 sorry
        have " |.INT-2K1 l.| =COMPLEX1R1 k"
          using A4 absvalue_def_1 sorry
        then have "((0NUMBERSK6) |^NEWTONK11 ( |.INT-2K1 l.|))\<inverse>XCMPLX-0K5 =COMPLEX1R1 0NUMBERSK6"
          using A5 sorry
        thus "(0NUMBERSK6)#ZPREPOWERK3 l =COMPLEX1R1 0NUMBERSK6"
          using A4 prepower_def_3 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
