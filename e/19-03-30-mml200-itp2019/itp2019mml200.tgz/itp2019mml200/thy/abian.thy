theory abian
  imports seq_4 eqrel_1 funct_7 scheme1 realset1
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, y, z, E, E1, E2, E3 for "setHIDDENM2"
reserve sE for "Subset-FamilySETFAM-1M1-of E"
reserve f for "FunctionFUNCT-2M1-of(E,E)"
reserve k, l, m, n for "NatNAT-1M1"
mdef abian_def_1 ("evenABIANV1" 70 ) where
"attr evenABIANV1 for IntegerINT-1M1 means
  (\<lambda>i. \<two>\<^sub>M dividesINT-1R1 i)"..

syntax ABIANV2 :: "Ty" ("oddABIANV2" 70)
translations "oddABIANV2" \<rightharpoonup> " non evenABIANV1"

mlemma abian_lm_1:
" for i be IntegerINT-1M1 holds i be evenABIANV1 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j)"
  using int_1_def_3 sorry

abbreviation(input) ABIANV3("evenABIANV3" 70) where
  "evenABIANV3 \<equiv> evenABIANV1"

mtheorem abian_def_2:
  mlet "n be NatNAT-1M1"
"redefine attr evenABIANV3 for NatNAT-1M1 means
  (\<lambda>n.  ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
proof
(*compatibility*)
  show " for n be NatNAT-1M1 holds n be evenABIANV3 iff ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    show "n be evenABIANV3 iff ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
    proof-
      have "(n be evenABIANV1 implies ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)) &  not ( not ( for k be NatNAT-1M1 holds  not n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k) &  not n be evenABIANV1)"
      proof(rule conjMI)
        show "n be evenABIANV1 implies ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k)"
        proof(rule impI)
          assume "n be evenABIANV1"
          then have "\<two>\<^sub>M dividesNAT-DR1 n"
             sorry
          then obtain k where
            [ty]:"k be IntegerINT-1M1" and 
            A1: "n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
             sorry
          have "0NUMBERSK6 <=XXREAL-0R1 k"
            using A1 xreal_1_th_132 sorry
          then have "k inHIDDENR3 NATNUMBERSK1"
            using int_1_th_3 sorry
          then have 
            [ty]:"k be NatNAT-1M1"
             sorry
          show " ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
          proof(rule bexI[of _ "k"])
            show "n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
              using A1 sorry
          qed "sorry"
        qed
        show " not ( not ( for k be NatNAT-1M1 holds  not n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k) &  not n be evenABIANV1)"
          using abian_lm_1 sorry
      qed
      thus " ?thesis "
         sorry
    qed
  qed "sorry"
qed "sorry"

mtheorem abian_cl_1:
"cluster evenABIANV3 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be evenABIANV3"
  proof-
    have " ex tVar2 be NatNAT-1M1 st tVar2 be evenABIANV3"
    proof-
      show " ex tVar2 be NatNAT-1M1 st tVar2 be evenABIANV3"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
        proof-
          show "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
             sorry
        qed
        thus "0NUMBERSK6 be evenABIANV3"
          using bexI[of _ "0NUMBERSK6"] abian_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_2:
"cluster oddABIANV2 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be oddABIANV2"
  proof-
    have " ex tVar4 be NatNAT-1M1 st  not tVar4 be oddABIANV2"
    proof-
      show " ex tVar4 be NatNAT-1M1 st  not tVar4 be oddABIANV2"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        have " for k be NatNAT-1M1 holds  not \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
        proof(rule ballI)
          fix k assume [ty]: "k be NatNAT-1M1"
          show " not \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
            using nat_1_th_15 sorry
        qed "sorry"
        thus " not \<one>\<^sub>M be oddABIANV2"
          using abian_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_3:
"cluster evenABIANV3 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be evenABIANV3"
  proof-
    have " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be evenABIANV3"
    proof-
      show " ex tVar5 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar5 be evenABIANV3"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
        proof-
          show "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
             sorry
        qed
        thus "0NUMBERSK6 be evenABIANV3"
          using bexI[of _ "0NUMBERSK6"] abian_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_4:
"cluster oddABIANV2 for ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*existence*)
  show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st it be oddABIANV2"
  proof-
    have " ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not tVar7 be oddABIANV2"
    proof-
      show " ex tVar7 be ElementSUBSET-1M1-of NATNUMBERSK1 st  not tVar7 be oddABIANV2"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        have " for k be NatNAT-1M1 holds  not \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
        proof(rule ballI)
          fix k assume [ty]: "k be NatNAT-1M1"
          show " not \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
            using nat_1_th_15 sorry
        qed "sorry"
        thus " not \<one>\<^sub>M be oddABIANV2"
          using abian_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_5:
"cluster evenABIANV1 for IntegerINT-1M1"
proof
(*existence*)
  show " ex it be IntegerINT-1M1 st it be evenABIANV1"
  proof-
    have " ex tVar8 be IntegerINT-1M1 st tVar8 be evenABIANV1"
    proof-
      show " ex tVar8 be IntegerINT-1M1 st tVar8 be evenABIANV1"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
        proof-
          show "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (0NUMBERSK6)"
             sorry
        qed
        thus "0NUMBERSK6 be evenABIANV1"
          using bexI[of _ "0NUMBERSK6"] abian_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_6:
"cluster oddABIANV2 for IntegerINT-1M1"
proof
(*existence*)
  show " ex it be IntegerINT-1M1 st it be oddABIANV2"
  proof-
    have " ex tVar10 be IntegerINT-1M1 st tVar10 be evenABIANV3 implies  False "
    proof-
      show " ex tVar10 be IntegerINT-1M1 st tVar10 be evenABIANV3 implies  False "
      proof(rule bexI[of _ "\<one>\<^sub>M"],rule impI)
        assume "\<one>\<^sub>M be evenABIANV3"
        then have " ex k be IntegerINT-1M1 st \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k"
           sorry
        thus " False "
          using int_1_th_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_th_1:
" for i be IntegerINT-1M1 holds i be oddABIANV2 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M)"
proof-
  have " for i be IntegerINT-1M1 holds (i be oddABIANV2 implies (( for j be IntegerINT-1M1 holds i <>HIDDENR2 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M) implies  False )) & (( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M) implies  not i be oddABIANV2)"
  proof(rule ballI,rule conjMI,rule impI)
    fix i assume [ty]: "i be IntegerINT-1M1"
    show "i be oddABIANV2 implies (( for j be IntegerINT-1M1 holds i <>HIDDENR2 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M) implies  False )"
    proof(rule impI,rule impI)
      obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A1: "i =HIDDENR1 k or i =HIDDENR1 -XCMPLX-0K4 k"
        using int_1_th_2 sorry
      obtain m where
        [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and 
        A2: "k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m or k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
        using scheme1_th_1 sorry
      assume A3: "i be oddABIANV2"
      assume A4: " for j be IntegerINT-1M1 holds i <>HIDDENR2 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
      show " False "
      proof-
        have cases: "((i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m or i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m) or i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M) or i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
          using A1 A2 sorry
        have case1: "i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m implies  False "
        proof(rule impI)
          assume "i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m"
          thus " False "
            using A3 abian_lm_1 sorry
        qed
        have case2: "i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m implies  False "
        proof(rule impI)
          assume "i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m"
          then have "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 m)"
             sorry
          thus " False "
            using A3 abian_lm_1 sorry
        qed
        have case3: "i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "i =HIDDENR1 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
          thus " False "
            using A4 sorry
        qed
        have case4: "i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M implies  False "
        proof(rule impI)
          assume "i =HIDDENR1 -XCMPLX-0K4 k & k =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 m +NAT-1K1 \<one>\<^sub>M"
          then have "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 (-XCMPLX-0K4 (m +NAT-1K1 \<one>\<^sub>M)) +XCMPLX-0K2 \<one>\<^sub>M"
             sorry
          thus " False "
            using A4 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 case4 sorry
      qed
    qed
    assume Given: " ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
    then obtain j where
      [ty]:"j be IntegerINT-1M1" and 
      A5: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    have "( ex k be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k) implies  False "
    proof(rule impI)
      assume Given: " ex k be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
      then obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A6: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
         sorry
      have "\<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k -XCMPLX-0K6 j)"
        using A5 A6 sorry
      thus " False "
        using int_1_th_9 sorry
    qed
    thus " not i be oddABIANV2"
      using int_1_def_3 abian_def_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem abian_cl_7:
  mlet "i be IntegerINT-1M1"
"cluster \<two>\<^sub>M *XCMPLX-0K3 i as-term-is evenABIANV1"
proof
(*coherence*)
  show "\<two>\<^sub>M *XCMPLX-0K3 i be evenABIANV1"
    using abian_lm_1 sorry
qed "sorry"

mtheorem abian_cl_8:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 \<one>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "i +XCMPLX-0K2 \<one>\<^sub>M be oddABIANV2"
  proof-
    have " not i +XCMPLX-0K2 \<one>\<^sub>M be evenABIANV1"
    proof-
      have " ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j"
        using abian_lm_1 sorry
      thus " not i +XCMPLX-0K2 \<one>\<^sub>M be evenABIANV1"
        using abian_th_1 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_9:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 \<one>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 \<one>\<^sub>M be evenABIANV1"
  proof-
    obtain j where
      [ty]:"j be IntegerINT-1M1" and 
      A1: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    have "i +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (j +XCMPLX-0K2 \<one>\<^sub>M)"
      using A1 sorry
    thus "i +XCMPLX-0K2 \<one>\<^sub>M be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_10:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 \<one>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "i -XCMPLX-0K6 \<one>\<^sub>M be oddABIANV2"
  proof-
    have " not i -XCMPLX-0K6 \<one>\<^sub>M be evenABIANV1"
    proof-
      obtain j where
        [ty]:"j be IntegerINT-1M1" and 
        A1: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j"
        using abian_lm_1 sorry
      have "i -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (j -XCMPLX-0K6 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M"
        using A1 sorry
      thus " not i -XCMPLX-0K6 \<one>\<^sub>M be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_11:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 \<one>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "i -XCMPLX-0K6 \<one>\<^sub>M be evenABIANV1"
  proof-
    have " ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    thus "i -XCMPLX-0K6 \<one>\<^sub>M be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_12:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be IntegerINT-1M1"
"cluster i *XCMPLX-0K3 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i *XCMPLX-0K3 j be evenABIANV1"
  proof-
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A1: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
      using abian_lm_1 sorry
    have "i *XCMPLX-0K3 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k *XCMPLX-0K3 j)"
      using A1 sorry
    thus "i *XCMPLX-0K3 j be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_13:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be IntegerINT-1M1"
"cluster j *XCMPLX-0K3 i as-term-is evenABIANV1"
proof
(*coherence*)
  show "j *XCMPLX-0K3 i be evenABIANV1"
     sorry
qed "sorry"

mtheorem abian_cl_14:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i *XCMPLX-0K3 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i *XCMPLX-0K3 j be oddABIANV2"
  proof-
    have " not i *XCMPLX-0K3 j be evenABIANV1"
    proof-
      obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      have "i *XCMPLX-0K3 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((k *XCMPLX-0K3 (\<two>\<^sub>M *XCMPLX-0K3 l) +XCMPLX-0K2 k *XCMPLX-0K3 \<one>\<^sub>M)+XCMPLX-0K2 l *XCMPLX-0K3 \<one>\<^sub>M) +XCMPLX-0K2 \<one>\<^sub>M"
        using A2 A1 sorry
      thus " not i *XCMPLX-0K3 j be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_15:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be evenABIANV1\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be evenABIANV1"
  proof-
    obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l"
      using abian_lm_1 sorry
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
      using abian_lm_1 sorry
    have "i +XCMPLX-0K2 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k +XCMPLX-0K2 l)"
      using A2 A1 sorry
    thus "i +XCMPLX-0K2 j be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_16:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be oddABIANV2"
  proof-
    have " not i +XCMPLX-0K2 j be evenABIANV1"
    proof-
      obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
        using abian_lm_1 sorry
      have "i +XCMPLX-0K2 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k +XCMPLX-0K2 l) +XCMPLX-0K2 \<one>\<^sub>M"
        using A2 A1 sorry
      thus " not i +XCMPLX-0K2 j be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_17:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster j +XCMPLX-0K2 i as-term-is oddABIANV2"
proof
(*coherence*)
  show "j +XCMPLX-0K2 i be oddABIANV2"
     sorry
qed "sorry"

mtheorem abian_cl_18:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i +XCMPLX-0K2 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i +XCMPLX-0K2 j be evenABIANV1"
  proof-
    obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    have "j +XCMPLX-0K2 i =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 ((k +XCMPLX-0K2 l)+XCMPLX-0K2 \<one>\<^sub>M)"
      using A2 A1 sorry
    thus "i +XCMPLX-0K2 j be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_19:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 j as-term-is oddABIANV2"
proof
(*coherence*)
  show "i -XCMPLX-0K6 j be oddABIANV2"
  proof-
    have " not i -XCMPLX-0K6 j be evenABIANV1"
    proof-
      obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
        using abian_lm_1 sorry
      have "i -XCMPLX-0K6 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k -XCMPLX-0K6 l) -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A1 sorry
      thus " not i -XCMPLX-0K6 j be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_20:
  mlet "i be evenABIANV1\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster j -XCMPLX-0K6 i as-term-is oddABIANV2"
proof
(*coherence*)
  show "j -XCMPLX-0K6 i be oddABIANV2"
  proof-
    have " not j -XCMPLX-0K6 i be evenABIANV1"
    proof-
      obtain l where
        [ty]:"l be IntegerINT-1M1" and 
        A3: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      obtain k where
        [ty]:"k be IntegerINT-1M1" and 
        A4: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k"
        using abian_lm_1 sorry
      have "j -XCMPLX-0K6 i =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (l -XCMPLX-0K6 k) +XCMPLX-0K2 \<one>\<^sub>M"
        using A4 A3 sorry
      thus " not j -XCMPLX-0K6 i be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_21:
  mlet "i be oddABIANV2\<bar>IntegerINT-1M1", "j be oddABIANV2\<bar>IntegerINT-1M1"
"cluster i -XCMPLX-0K6 j as-term-is evenABIANV1"
proof
(*coherence*)
  show "i -XCMPLX-0K6 j be evenABIANV1"
  proof-
    obtain l where
      [ty]:"l be IntegerINT-1M1" and 
      A1: "j =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 l +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    obtain k where
      [ty]:"k be IntegerINT-1M1" and 
      A2: "i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 k +XCMPLX-0K2 \<one>\<^sub>M"
      using abian_th_1 sorry
    have "i -XCMPLX-0K6 j =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 (k -XCMPLX-0K6 l)"
      using A2 A1 sorry
    thus "i -XCMPLX-0K6 j be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_22:
  mlet "m be evenABIANV1\<bar>IntegerINT-1M1"
"cluster m +XCMPLX-0K2 \<two>\<^sub>M as-term-is evenABIANV1"
proof
(*coherence*)
  show "m +XCMPLX-0K2 \<two>\<^sub>M be evenABIANV1"
  proof-
    have "\<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
       sorry
    then obtain t where 
      [ty]:"t be evenABIANV1\<bar>IntegerINT-1M1" and tDef:"t = \<two>\<^sub>M"
       sorry
    have "m +XCMPLX-0K2 t be evenABIANV1"
       sorry
    thus "m +XCMPLX-0K2 \<two>\<^sub>M be evenABIANV1"
       sorry
  qed
qed "sorry"

mtheorem abian_cl_23:
  mlet "m be oddABIANV2\<bar>IntegerINT-1M1"
"cluster m +XCMPLX-0K2 \<two>\<^sub>M as-term-is oddABIANV2"
proof
(*coherence*)
  show "m +XCMPLX-0K2 \<two>\<^sub>M be oddABIANV2"
  proof-
    have " not m +XCMPLX-0K2 \<two>\<^sub>M be evenABIANV1"
    proof-
      have "\<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M"
         sorry
      then obtain t where 
        [ty]:"t be evenABIANV1\<bar>IntegerINT-1M1" and tDef:"t = \<two>\<^sub>M"
         sorry
      have "m +XCMPLX-0K2 t be oddABIANV2"
         sorry
      thus " not m +XCMPLX-0K2 \<two>\<^sub>M be evenABIANV1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax ABIANK1 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" ("iterABIANK1\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [0,0,0]164)
translations "iterABIANK1\<^bsub>(E)\<^esub>(f,n)" \<rightharpoonup> "iterFUNCT-7K8(f,n)"

mtheorem abian_add_1:
  mlet "E be setHIDDENM2", "f be FunctionFUNCT-2M1-of(E,E)", "n be NatNAT-1M1"
"cluster iterFUNCT-7K8(f,n) as-term-is FunctionFUNCT-2M1-of(E,E)"
proof
(*coherence*)
  show "iterFUNCT-7K8(f,n) be FunctionFUNCT-2M1-of(E,E)"
    using funct_7_th_83 sorry
qed "sorry"

mtheorem abian_th_2:
" for S be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1 holds 0NUMBERSK6 inTARSKIR2 S implies minSEQ-4K4 S =XBOOLE-0R4 0NUMBERSK6"
  using xxreal_2_def_7 sorry

mtheorem abian_th_3:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for x be ElementSUBSET-1M1-of E holds (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 x"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for x be ElementSUBSET-1M1-of E holds (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> x =HIDDENR1 x"
  proof(rule ballI,rule ballI,rule ballI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(E,E)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of E"
    have "domRELAT-1K1 f =XBOOLE-0R4 E"
      using funct_2_def_1 sorry
    then have A1: "x inTARSKIR2 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
      using xboole_0_def_3 sorry
    have "(iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> x =HIDDENR1 idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 x"
      using funct_7_th_68 sorry
    also have "... = x"
      using A1 funct_1_th_17 sorry
    finally show "(iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> x =HIDDENR1 x"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef abian_def_3 (" _ is-a-fixpoint-ofABIANR1  _ " [50,50]50 ) where
  mlet "x be objectHIDDENM1", "f be FunctionFUNCT-1M1"
"pred x is-a-fixpoint-ofABIANR1 f means
  x inHIDDENR3 domRELAT-1K1 f & x =HIDDENR1 f .FUNCT-1K1 x"..

syntax ABIANR2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ is-a-fixpoint-ofABIANR2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50)
translations "a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f" \<rightharpoonup> "a is-a-fixpoint-ofABIANR1 f"

mtheorem abian_def_4:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "a be ElementSUBSET-1M1-of A", "f be FunctionFUNCT-2M1-of(A,A)"
"redefine pred a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f means
  a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
proof
(*compatibility*)
  show "a is-a-fixpoint-ofABIANR2\<^bsub>(A)\<^esub> f iff a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
  proof-
    have "(a is-a-fixpoint-ofABIANR1 f implies a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a) & (a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a implies a is-a-fixpoint-ofABIANR1 f)"
    proof(rule conjMI,rule impI)
      show "a is-a-fixpoint-ofABIANR1 f implies a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
         sorry
      assume A1: "a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
      have Cut389: "a inTARSKIR2 A"
         sorry
      have "a inTARSKIR2 domRELAT-1K1 f & a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
      proof(rule conjMI)
        show "a inTARSKIR2 domRELAT-1K1 f"
          using funct_2_th_52 Cut389 sorry
        show "a =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> a"
          using A1 sorry
      qed
      thus "a is-a-fixpoint-ofABIANR1 f"
        using abian_def_3 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef abian_def_5 ("with-fixpointABIANV4" 70 ) where
"attr with-fixpointABIANV4 for FunctionFUNCT-1M1 means
  (\<lambda>f.  ex x be objectHIDDENM1 st x is-a-fixpoint-ofABIANR1 f)"..

syntax ABIANV5 :: "Ty" ("without-fixpointsABIANV5" 70)
translations "without-fixpointsABIANV5" \<rightharpoonup> " non with-fixpointABIANV4"

mdef abian_def_6 ("coveringABIANV6\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "X be setHIDDENM2"
"attr coveringABIANV6\<^bsub>(X)\<^esub> for ElementSUBSET-1M1-of X means
  (\<lambda>x. unionTARSKIK3 x =XBOOLE-0R4 unionTARSKIK3 (unionTARSKIK3 X))"..

mtheorem abian_th_4:
" for E be setHIDDENM2 holds  for sE be Subset-FamilySETFAM-1M1-of E holds sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> iff unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E"
proof-
  have " for E be setHIDDENM2 holds  for sE be Subset-FamilySETFAM-1M1-of E holds  not (sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> &  not unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E) &  not (unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E &  not sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>)"
  proof(rule ballI,rule ballI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix sE assume [ty]: "sE be Subset-FamilySETFAM-1M1-of E"
    have "unionSETFAM-1K5\<^bsub>(E)\<^esub> (unionSETFAM-1K5\<^bsub>(boolSETFAM-1K9 E)\<^esub> (boolSETFAM-1K9 (boolSETFAM-1K9 E))) =HIDDENR1 unionSETFAM-1K5\<^bsub>(E)\<^esub> (boolSETFAM-1K9 E)"
      using zfmisc_1_th_81 sorry
    also have "... = E"
      using zfmisc_1_th_81 sorry
    finally have "unionSETFAM-1K5\<^bsub>(E)\<^esub> (unionSETFAM-1K5\<^bsub>(boolSETFAM-1K9 E)\<^esub> (boolSETFAM-1K9 (boolSETFAM-1K9 E))) =HIDDENR1 E"
       sorry
    thus " not (sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> &  not unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E) &  not (unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E &  not sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem abian_cl_24:
  mlet "E be setHIDDENM2"
"cluster  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub> for Subset-FamilySETFAM-1M1-of E"
proof
(*existence*)
  show " ex it be Subset-FamilySETFAM-1M1-of E st it be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>"
  proof-
    have " ex tVar11 be Subset-FamilySETFAM-1M1-of E st tVar11 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 & tVar11 be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>"
    proof-
      obtain sE where 
        [ty]:"sE be Subset-FamilySETFAM-1M1-of E" and sEDef:"sE = {TARSKIK1 E}"
        using zfmisc_1_th_68 sorry
      show " ex tVar11 be Subset-FamilySETFAM-1M1-of E st tVar11 be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1 & tVar11 be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>"
      proof(rule bexI[of _ "sE"],rule conjMI)
        show "sE be  non emptyXBOOLE-0V1\<bar>finiteFINSET-1V1"
           sorry
        have "unionSETFAM-1K5\<^bsub>(E)\<^esub> sE =XBOOLE-0R4 E"
          using zfmisc_1_th_25 sorry
        thus "sE be coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>"
          using abian_th_4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_th_5:
" for E be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for sE be  non emptyXBOOLE-0V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>\<bar>Subset-FamilySETFAM-1M1-of E holds ( for X be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of sE holds X missesXBOOLE-0R1 f .:FUNCT-1K5 X) implies f be without-fixpointsABIANV5"
proof-
  have " for E be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for sE be  non emptyXBOOLE-0V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>\<bar>Subset-FamilySETFAM-1M1-of E holds ( for X be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of sE holds X missesXBOOLE-0R1 f .:FUNCT-1K5 X) implies  not f be without-fixpointsABIANV5"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(E,E)"
    fix sE assume [ty]: "sE be  non emptyXBOOLE-0V1\<bar>coveringABIANV6\<^bsub>(boolZFMISC-1K1 (boolZFMISC-1K1 E))\<^esub>\<bar>Subset-FamilySETFAM-1M1-of E"
    assume A1: " for X be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of sE holds X missesXBOOLE-0R1 f .:FUNCT-1K5 X"
    have "( ex x be objectHIDDENM1 st x is-a-fixpoint-ofABIANR1 f) implies  False "
    proof(rule impI)
      assume Given: " ex x be objectHIDDENM1 st x is-a-fixpoint-ofABIANR1 f"
      then obtain x where
        [ty]:"x be objectHIDDENM1" and 
        A2: "x is-a-fixpoint-ofABIANR1 f"
         sorry
      have A3: "f .FUNCT-1K1 x =HIDDENR1 x"
        using A2 sorry
      have A4: "x inHIDDENR3 domRELAT-1K1 f"
        using A2 sorry
      have "domRELAT-1K1 f =XBOOLE-0R4 E"
        using funct_2_th_52 sorry
      then have "x inHIDDENR3 unionSETFAM-1K5\<^bsub>(E)\<^esub> sE"
        using A4 abian_th_4 sorry
      then obtain X where
        [ty]:"X be setHIDDENM2" and 
        A5: "x inHIDDENR3 X"and A6: "X inTARSKIR2 sE"
        using tarski_def_4 sorry
      have "f .FUNCT-1K1 x inTARSKIR2 f .:FUNCT-1K5 X"
        using A4 A5 funct_1_def_6 sorry
      then have "X meetsXBOOLE-0R5 f .:FUNCT-1K5 X"
        using A3 A5 xboole_0_th_3 sorry
      thus " False "
        using A1 A6 sorry
    qed
    thus " not f be without-fixpointsABIANV5"
      using abian_def_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef abian_def_7 ("=-ABIANK2\<^bsub>'( _ ')\<^esub>  _ " [0,164]164 ) where
  mlet "E be setHIDDENM2", "f be FunctionFUNCT-2M1-of(E,E)"
"func =-ABIANK2\<^bsub>(E)\<^esub> f \<rightarrow> Equivalence-RelationEQREL-1M2-of E means
  \<lambda>it.  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
proof-
  (*existence*)
    show " ex it be Equivalence-RelationEQREL-1M2-of E st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
    proof-
      have " ex tVar12 be Equivalence-RelationEQREL-1M2-of E st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies  not ([TARSKIK4 x,y ] inHIDDENR3 tVar12 & ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y)) &  not ( not ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar12)"
      proof-
        let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 inHIDDENR3 E & Lamb2 inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 Lamb1 =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 Lamb2)"
        have A1: " for x be objectHIDDENM1 holds x inHIDDENR3 E implies (x inHIDDENR3 E & x inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 x)"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have A2: "(iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
             sorry
          assume "x inHIDDENR3 E"
          thus "(x inHIDDENR3 E & x inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 x)"
            using A2 sorry
        qed "sorry"
        have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds ((x inHIDDENR3 E & y inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y)) & ((y inHIDDENR3 E & z inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 y =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 z)) implies (x inHIDDENR3 E & z inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 z)"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume A4: "?P(x,y)"
            and A5: "?P(y,z)"
          obtain k l where
            [ty]:"k be NatNAT-1M1" "l be NatNAT-1M1" and 
            A6: "(iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y"
            using A4 sorry
          obtain m n where
            [ty]:"m be NatNAT-1M1" "n be NatNAT-1M1" and 
            A7: "(iterABIANK1\<^bsub>(E)\<^esub>(f,m)).FUNCT-1K1 y =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-1K1 z"
            using A5 sorry
          have A8: "domRELAT-1K1 (iterABIANK1\<^bsub>(E)\<^esub>(f,m)) =XBOOLE-0R4 E"
            using funct_2_th_52 sorry
          have A9: "domRELAT-1K1 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)) =XBOOLE-0R4 E"
            using funct_2_th_52 sorry
          have A10: "domRELAT-1K1 (iterABIANK1\<^bsub>(E)\<^esub>(f,k)) =XBOOLE-0R4 E"
            using funct_2_th_52 sorry
          have A11: "domRELAT-1K1 (iterABIANK1\<^bsub>(E)\<^esub>(f,n)) =XBOOLE-0R4 E"
            using funct_2_th_52 sorry
          have "(iterABIANK1\<^bsub>(E)\<^esub>(f,k +XCMPLX-0K2 m)).FUNCT-1K1 x =HIDDENR1 ((iterABIANK1\<^bsub>(E)\<^esub>(f,m))*FUNCT-1K3 (iterABIANK1\<^bsub>(E)\<^esub>(f,k))).FUNCT-1K1 x"
            using funct_7_th_77 sorry
          also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,m)).FUNCT-1K1 ((iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y)"
            using A4 A6 A10 funct_1_th_13 sorry
          also have "... = ((iterABIANK1\<^bsub>(E)\<^esub>(f,m))*FUNCT-1K3 (iterABIANK1\<^bsub>(E)\<^esub>(f,l))).FUNCT-1K1 y"
            using A4 A9 funct_1_th_13 sorry
          also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,m +XCMPLX-0K2 l)).FUNCT-1K1 y"
            using funct_7_th_77 sorry
          also have "... = ((iterABIANK1\<^bsub>(E)\<^esub>(f,l))*FUNCT-1K3 (iterABIANK1\<^bsub>(E)\<^esub>(f,m))).FUNCT-1K1 y"
            using funct_7_th_77 sorry
          also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 ((iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-1K1 z)"
            using A4 A7 A8 funct_1_th_13 sorry
          also have "... = ((iterABIANK1\<^bsub>(E)\<^esub>(f,l))*FUNCT-1K3 (iterABIANK1\<^bsub>(E)\<^esub>(f,n))).FUNCT-1K1 z"
            using A5 A11 funct_1_th_13 sorry
          also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,l +XCMPLX-0K2 n)).FUNCT-1K1 z"
            using funct_7_th_77 sorry
          finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,k +XCMPLX-0K2 m)).FUNCT-1K1 x =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,l +XCMPLX-0K2 n)).FUNCT-1K1 z"
             sorry
          thus "(x inHIDDENR3 E & z inHIDDENR3 E) & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 z)"
            using A4 A5 sorry
        qed "sorry"
        have A12: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?P(x,y) implies ?P(y,x)"
           sorry
        obtain EqR where
          [ty]:"EqR be Equivalence-RelationEQREL-1M2-of E" and 
          A13: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 EqR iff (x inHIDDENR3 E & y inHIDDENR3 E) & ?P(x,y)"
          using eqrel_1_sch_1 A1 A12 A3 sorry
        show " ex tVar12 be Equivalence-RelationEQREL-1M2-of E st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies  not ([TARSKIK4 x,y ] inHIDDENR3 tVar12 & ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y)) &  not ( not ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 tVar12)"
        proof(rule bexI[of _ "EqR"],rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be setHIDDENM2"
          fix y assume [ty]: "y be setHIDDENM2"
          assume "x inTARSKIR2 E & y inTARSKIR2 E"
          thus " not ([TARSKIK4 x,y ] inHIDDENR3 EqR & ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y)) &  not ( not ( for k be NatNAT-1M1 holds  for l be NatNAT-1M1 holds  not (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y) &  not [TARSKIK4 x,y ] inHIDDENR3 EqR)"
            using A13 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be Equivalence-RelationEQREL-1M2-of E holds  for it2 be Equivalence-RelationEQREL-1M2-of E holds ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it1 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 it2 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) implies it1 =HIDDENR1 it2"
    proof-
      have " for IT1 be Equivalence-RelationEQREL-1M2-of E holds  for IT2 be Equivalence-RelationEQREL-1M2-of E holds ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 IT1 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) & ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 IT2 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))) implies IT1 =HIDDENR1 IT2"
      proof(rule ballI,rule ballI,rule impMI ,rule impI)
        fix IT1 assume [ty]: "IT1 be Equivalence-RelationEQREL-1M2-of E"
        fix IT2 assume [ty]: "IT2 be Equivalence-RelationEQREL-1M2-of E"
        assume A14: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 IT1 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
          and A15: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 E & y inTARSKIR2 E implies ([TARSKIK4 x,y ] inHIDDENR3 IT2 iff ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 x =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 y))"
        have " for a be objectHIDDENM1 holds  for b be objectHIDDENM1 holds ([TARSKIK4 a,b ] inHIDDENR3 IT1 implies [TARSKIK4 a,b ] inHIDDENR3 IT2) & ([TARSKIK4 a,b ] inHIDDENR3 IT2 implies [TARSKIK4 a,b ] inHIDDENR3 IT1)"
        proof(rule ballI,rule ballI,rule conjMI,rule impI)
          fix a assume [ty]: "a be objectHIDDENM1"
          fix b assume [ty]: "b be objectHIDDENM1"
          show "[TARSKIK4 a,b ] inHIDDENR3 IT1 implies [TARSKIK4 a,b ] inHIDDENR3 IT2"
          proof(rule impI)
            assume A16: "[TARSKIK4 a,b ] inHIDDENR3 IT1"
            then have A17: "a inHIDDENR3 E & b inHIDDENR3 E"
              using zfmisc_1_th_87 sorry
            then have " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 a =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 b"
              using A14 A16 sorry
            thus "[TARSKIK4 a,b ] inHIDDENR3 IT2"
              using A15 A17 sorry
          qed
          assume A18: "[TARSKIK4 a,b ] inHIDDENR3 IT2"
          then have A19: "a inHIDDENR3 E & b inHIDDENR3 E"
            using zfmisc_1_th_87 sorry
          then have " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-1K1 a =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,l)).FUNCT-1K1 b"
            using A15 A18 sorry
          thus "[TARSKIK4 a,b ] inHIDDENR3 IT1"
            using A14 A19 sorry
        qed "sorry"
        thus "IT1 =HIDDENR1 IT2"
          using relat_1_def_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem abian_th_6:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  for e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
proof(rule ballI,rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(E,E)"
  fix c assume [ty]: "c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)"
  fix e assume [ty]: "e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
  have "domRELAT-1K1 f =XBOOLE-0R4 E"
    using funct_2_def_1 sorry
  then have A1: "f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
    using xboole_0_def_3 sorry
  have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
    using eqrel_1_def_3 sorry
  then have A2: "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,e)"
    using eqrel_1_th_23 sorry
  have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e =HIDDENR1 f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e"
    using funct_7_th_70 sorry
  also have "... = idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
    using A1 funct_1_th_17 sorry
  also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
    using funct_7_th_68 sorry
  finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
     sorry
  then have "[DOMAIN-1K1\<^bsub>(E,c)\<^esub> f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e,e ] inTARSKIR2 =-ABIANK2\<^bsub>(E)\<^esub> f"
    using abian_def_7 sorry
  thus "f .FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
    using A2 eqrel_1_th_19 sorry
qed "sorry"

mtheorem abian_th_7:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds  for c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  for e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds  for n be NatNAT-1M1 holds (iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
  fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be FunctionFUNCT-2M1-of(E,E)"
  fix c assume [ty]: "c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)"
  fix e assume [ty]: "e be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
  fix n assume [ty]: "n be NatNAT-1M1"
  have "domRELAT-1K1 f =XBOOLE-0R4 E"
    using funct_2_def_1 sorry
  then have "(iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
    using xboole_0_def_3 sorry
  then have "(iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e =HIDDENR1 idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 ((iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
    using funct_1_th_17 sorry
  also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> ((iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
    using funct_7_th_68 sorry
  finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-2K3\<^bsub>(E,E)\<^esub> ((iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e)"
     sorry
  then have A1: "[DOMAIN-1K1\<^bsub>(E,c)\<^esub> (iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e,e ] inTARSKIR2 =-ABIANK2\<^bsub>(E)\<^esub> f"
    using abian_def_7 sorry
  have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
    using eqrel_1_def_3 sorry
  then have "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,e)"
    using eqrel_1_th_23 sorry
  thus "(iterABIANK1\<^bsub>(E)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(E,E)\<^esub> e inTARSKIR2 c"
    using A1 eqrel_1_th_19 sorry
qed "sorry"

mtheorem abian_cl_25:
"cluster empty-memberedSETFAM-1V2 also-is trivialSUBSET-1V2 for setHIDDENM2"
proof
(*coherence*)
  show " for it be setHIDDENM2 holds it be empty-memberedSETFAM-1V2 implies it be trivialSUBSET-1V2"
     sorry
qed "sorry"

mtheorem abian_cl_26:
  mlet "A be setHIDDENM2", "B be with-non-empty-elementSETFAM-1V3\<bar>setHIDDENM2"
"cluster non-emptyFUNCT-1V4 for FunctionFUNCT-2M1-of(A,B)"
proof
(*existence*)
  show " ex it be FunctionFUNCT-2M1-of(A,B) st it be non-emptyFUNCT-1V4"
  proof-
    have " ex tVar13 be FunctionFUNCT-2M1-of(A,B) st tVar13 be non-emptyFUNCT-1V4"
    proof-
      obtain X where
        [ty]:"X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and 
        A1: "X inTARSKIR2 B"
        using setfam_1_def_10 sorry
      obtain f where 
        [ty]:"f be FunctionFUNCT-2M1-of(A,B)" and fDef:"f = A -->FUNCOP-1K7 X"
        using A1 funcop_1_th_45 sorry
      show " ex tVar13 be FunctionFUNCT-2M1-of(A,B) st tVar13 be non-emptyFUNCT-1V4"
      proof(rule bexI[of _ "f"])
        have " for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 f implies  not f .FUNCT-1K1 n be emptyXBOOLE-0V1"
        proof(rule ballI,rule impI)
          fix n assume [ty]: "n be objectHIDDENM1"
          assume "n inHIDDENR3 domRELAT-1K1 f"
          then have "n inHIDDENR3 A"
            using funcop_1_th_13 sorry
          thus " not f .FUNCT-1K1 n be emptyXBOOLE-0V1"
            using funcop_1_th_7 sorry
        qed "sorry"
        thus "f be non-emptyFUNCT-1V4"
          using funct_1_def_9 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_27:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be with-non-empty-elementSETFAM-1V3\<bar>setHIDDENM2", "f be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-2M1-of(A,B)", "a be ElementSUBSET-1M1-of A"
"cluster f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a be  non emptyXBOOLE-0V1"
  proof-
    have " not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a be emptyXBOOLE-0V1"
    proof-
      have "domRELAT-1K1 f =XBOOLE-0R4 A"
        using funct_2_def_1 sorry
      then have "f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      thus " not f .FUNCT-2K3\<^bsub>(A,B)\<^esub> a be emptyXBOOLE-0V1"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_28:
  mlet "X be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster boolSETFAM-1K9 X as-term-is with-non-empty-elementSETFAM-1V3"
proof
(*coherence*)
  show "boolSETFAM-1K9 X be with-non-empty-elementSETFAM-1V3"
  proof-
    have " not boolSETFAM-1K9 X be empty-memberedSETFAM-1V2"
    proof-
      have "X inTARSKIR2 boolSETFAM-1K9 X"
      proof-
        show "X inTARSKIR2 boolSETFAM-1K9 X"
          using zfmisc_1_def_1 sorry
      qed
      thus " not boolSETFAM-1K9 X be empty-memberedSETFAM-1V2"
        using bexI[of _ "X"] setfam_1_def_10 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_th_8:
" for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds f be without-fixpointsABIANV5 implies ( ex E1 be setHIDDENM2 st  ex E2 be setHIDDENM2 st  ex E3 be setHIDDENM2 st (((E1 \\/XBOOLE-0K2 E2)\\/XBOOLE-0K2 E3 =XBOOLE-0R4 E & f .:FUNCT-1K5 E1 missesXBOOLE-0R1 E1) & f .:FUNCT-1K5 E2 missesXBOOLE-0R1 E2) & f .:FUNCT-1K5 E3 missesXBOOLE-0R1 E3)"
proof-
  have " for E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(E,E) holds f be without-fixpointsABIANV5 implies ( ex tVar21 be setHIDDENM2 st  ex tVar22 be setHIDDENM2 st  ex tVar23 be setHIDDENM2 st (tVar21 \\/XBOOLE-0K2 tVar22)\\/XBOOLE-0K2 tVar23 =XBOOLE-0R4 E & (f .:FUNCT-1K5 tVar21 missesXBOOLE-0R1 tVar21 & (f .:FUNCT-1K5 tVar22 missesXBOOLE-0R1 tVar22 & f .:FUNCT-1K5 tVar23 missesXBOOLE-0R1 tVar23)))"
  proof(rule ballI,rule ballI,rule impI)
    fix E assume [ty]: "E be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(E,E)"
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. (((Lamb2 `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> Lamb2 `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> Lamb2 `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> =XBOOLE-0R4 Lamb1 & f .:FUNCT-1K5 (Lamb2 `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 Lamb2 `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) & f .:FUNCT-1K5 (Lamb2 `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 Lamb2 `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) & f .:FUNCT-1K5 (Lamb2 `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 Lamb2 `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
    let ?i = "\<lambda>Lamb1. iterABIANK1\<^bsub>(E)\<^esub>(f,Lamb1)"
    assume A1: "f be without-fixpointsABIANV5"
    have A2: " for a be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  ex b be ElementSUBSET-1M3\<^bsub>([:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :])\<^esub>-of [:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :] st ?P(a,b)"
    proof-
      have " for c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds  ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>))"
      proof(rule ballI)
        obtain c3 where 
          [ty]:"c3 be SubsetSUBSET-1M2-of E" and c3Def:"c3 = {}XBOOLE-0K1"
          using xboole_1_th_2 sorry
        fix c assume [ty]: "c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)"
        obtain x0 where
          [ty]:"x0 be objectHIDDENM1" and 
          A3: "x0 inHIDDENR3 E"and A4: "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x0)"
          using eqrel_1_def_3 sorry
        have 
          [ty]:"x0 be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
          using A3 A4 eqrel_1_th_20 sorry
        let ?P = "\<lambda>Lamb1.  ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-1K1 Lamb1 =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be evenABIANV3) & l be evenABIANV3"
        let ?c1 = "{x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P(x) }"
        have "?c1 be SubsetSUBSET-1M2-of c"
          using domain_1_sch_7 sorry
        then obtain c1 where 
          [ty]:"c1 be SubsetSUBSET-1M2-of E" and c1Def:"c1 = ?c1"
          using xboole_1_th_1 sorry
        let ?P = "\<lambda>Lamb1.  ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-1K1 Lamb1 =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be oddABIANV2) & l be evenABIANV3"
        let ?c2 = "{x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P(x) }"
        have "?c2 be SubsetSUBSET-1M2-of c"
          using domain_1_sch_7 sorry
        then obtain c2 where 
          [ty]:"c2 be SubsetSUBSET-1M2-of E" and c2Def:"c2 = ?c2"
          using xboole_1_th_1 sorry
        show " ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>))"
        proof-
          have cases: "c1 missesXBOOLE-0R1 c2 or c1 meetsXBOOLE-0R5 c2"
             sorry
          have case1: "c1 missesXBOOLE-0R1 c2 implies ( ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)))"
          proof(rule impI)
            assume A5: "c1 missesXBOOLE-0R1 c2"
            obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :]" and bDef:"b = [DOMAIN-1K4\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> c1,c2,c3 ]"
               sorry
            show " ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>))"
            proof(rule bexI[of _ "b"],rule conjMI,rule conjMI,rule conjMI)
              have A6: "b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c2"
                using mcart_1_def_6 sorry
              have A7: "b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c3"
                using mcart_1_def_7 sorry
              have A8: "b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c1"
                using mcart_1_def_5 sorry
              show "(b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c"
              proof-
                have "( for x be objectHIDDENM1 holds x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> implies x inHIDDENR3 c) & c c=TARSKIR1 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                proof(rule conjMI)
                  show " for x be objectHIDDENM1 holds x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> implies x inHIDDENR3 c"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume A9: "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                    show "x inHIDDENR3 c"
                    proof-
                      have cases: "(x inHIDDENR3 c1 or x inHIDDENR3 c2) or x inHIDDENR3 c3"
                        using A8 A6 A7 A9 xboole_0_def_3 sorry
                      have case1: "x inHIDDENR3 c1 implies x inHIDDENR3 c"
                      proof(rule impI)
                        assume "x inHIDDENR3 c1"
                        then have " ex xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st x =HIDDENR1 xx & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be evenABIANV3) & l be evenABIANV3)"
                           sorry
                        thus "x inHIDDENR3 c"
                           sorry
                      qed
                      have case2: "x inHIDDENR3 c2 implies x inHIDDENR3 c"
                      proof(rule impI)
                        assume "x inHIDDENR3 c2"
                        then have " ex xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st x =HIDDENR1 xx & ( ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be oddABIANV2) & l be evenABIANV3)"
                           sorry
                        thus "x inHIDDENR3 c"
                           sorry
                      qed
                      have case3: "x inHIDDENR3 c3 implies x inHIDDENR3 c"
                      proof(rule impI)
                        assume "x inHIDDENR3 c3"
                        thus "x inHIDDENR3 c"
                           sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 case3 sorry
                    qed
                  qed "sorry"
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 c implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 c"
                    then obtain xc where 
                      [ty]:"xc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and xcDef:"xc = x"
                       sorry
                    have "[DOMAIN-1K1\<^bsub>(c,c)\<^esub> xc,x0 ] inTARSKIR2 =-ABIANK2\<^bsub>(E)\<^esub> f"
                      using A4 eqrel_1_th_19 sorry
                    then obtain k l where
                      [ty]:"k be NatNAT-1M1" "l be NatNAT-1M1" and 
                      A10: "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xc =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                      using abian_def_7 sorry
                    have A11: "domRELAT-1K1 ?i(l) =XBOOLE-0R4 E"
                      using funct_2_def_1 sorry
                    have A12: "domRELAT-1K1 ?i(k) =XBOOLE-0R4 E"
                      using funct_2_def_1 sorry
                    show "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                    proof-
                      have cases: "k be evenABIANV3 or k be oddABIANV2"
                         sorry
                      have case1: "k be evenABIANV3 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                      proof(rule impI)
                        assume A13: "k be evenABIANV3"
                        then have 
                          [ty]:"k be evenABIANV3\<bar>NatNAT-1M1"
                           sorry
                        show "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                        proof-
                          show "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                          proof-
                            have cases: "l be evenABIANV3 or l be oddABIANV2"
                               sorry
                            have case1: "l be evenABIANV3 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                            proof(rule impI)
                              assume "l be evenABIANV3"
                              then have "xc inTARSKIR2 c1"
                                using A10 A13 sorry
                              thus "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                                using A8 A7 xboole_0_def_3 sorry
                            qed
                            have case2: "l be oddABIANV2 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                            proof(rule impI)
                              assume "l be oddABIANV2"
                              then have 
                                [ty]:"l be oddABIANV2\<bar>NatNAT-1M1"
                                 sorry
                              have "?i(k +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xc =HIDDENR1 (f *FUNCT-1K3 ?i(k)).FUNCT-1K1 xc"
                                using funct_7_th_71 sorry
                              also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
                                using A10 A12 funct_1_th_13 sorry
                              also have "... = (f *FUNCT-1K3 ?i(l)).FUNCT-1K1 x0"
                                using A11 funct_1_th_13 sorry
                              also have "... = ?i(l +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                                using funct_7_th_71 sorry
                              finally have "?i(k +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xc =HIDDENR1 ?i(l +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                                 sorry
                              then have "xc inTARSKIR2 c2"
                                 sorry
                              thus "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                                using A6 A7 xboole_0_def_3 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                      qed
                      have case2: "k be oddABIANV2 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                      proof(rule impI)
                        assume A14: "k be oddABIANV2"
                        then have 
                          [ty]:"k be oddABIANV2\<bar>NatNAT-1M1"
                           sorry
                        show "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                        proof-
                          show "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                          proof-
                            have cases: "l be evenABIANV3 or l be oddABIANV2"
                               sorry
                            have case1: "l be evenABIANV3 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                            proof(rule impI)
                              assume "l be evenABIANV3"
                              then have "xc inTARSKIR2 c2"
                                using A10 A14 sorry
                              thus "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                                using A6 A7 xboole_0_def_3 sorry
                            qed
                            have case2: "l be oddABIANV2 implies x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                            proof(rule impI)
                              assume "l be oddABIANV2"
                              then have 
                                [ty]:"l be oddABIANV2\<bar>NatNAT-1M1"
                                 sorry
                              have "?i(k +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xc =HIDDENR1 (f *FUNCT-1K3 ?i(k)).FUNCT-1K1 xc"
                                using funct_7_th_71 sorry
                              also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
                                using A10 A12 funct_1_th_13 sorry
                              also have "... = (f *FUNCT-1K3 ?i(l)).FUNCT-1K1 x0"
                                using A11 funct_1_th_13 sorry
                              also have "... = ?i(l +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                                using funct_7_th_71 sorry
                              finally have "?i(k +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xc =HIDDENR1 ?i(l +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                                 sorry
                              then have "xc inTARSKIR2 c1"
                                 sorry
                              thus "x inHIDDENR3 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                                using A8 A7 xboole_0_def_3 sorry
                            qed
                            show " ?thesis "
                              using cases case1 case2 sorry
                          qed
                        qed
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                  thus "c c=TARSKIR1 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                    using tarski_def_3 sorry
                qed
                thus "(b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c"
                  using tarski_def_3 xboole_0_def_10 sorry
              qed
              have "f .:FUNCT-1K5 c1 c=TARSKIR1 c2"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 c1 implies y inHIDDENR3 c2"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  have A15: "domRELAT-1K1 f =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  assume "y inHIDDENR3 f .:FUNCT-1K5 c1"
                  then obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    "x inHIDDENR3 domRELAT-1K1 f"and A16: "x inHIDDENR3 c1"and A17: "y =HIDDENR1 f .FUNCT-1K1 x"
                    using funct_1_def_6 sorry
                  obtain xx where
                    [ty]:"xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
                    A18: "x =HIDDENR1 xx"and A19: " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be evenABIANV3) & l be evenABIANV3"
                    using A16 sorry
                  obtain k l where
                    [ty]:"k be NatNAT-1M1" "l be NatNAT-1M1" and 
                    A20: "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"and A21: "k be evenABIANV3 & l be evenABIANV3"
                    using A19 sorry
                  have 
                    [ty]:"k be evenABIANV3\<bar>NatNAT-1M1" and
                    [ty]:"l be evenABIANV3\<bar>NatNAT-1M1"
                    using A21 sorry
                  obtain k1 where 
                    [ty]:"k1 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = k +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  obtain l1 where 
                    [ty]:"l1 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = l +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  obtain l2 where 
                    [ty]:"l2 be evenABIANV3\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and l2Def:"l2 = l1 +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  have A22: "domRELAT-1K1 ?i(k) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  obtain yc where 
                    [ty]:"yc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and ycDef:"yc = y"
                    using A17 A18 abian_th_6 sorry
                  have A23: "domRELAT-1K1 ?i(l) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have A24: "domRELAT-1K1 ?i(k1) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have A25: "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 (?i(k1) *FUNCT-1K3 f).FUNCT-1K1 xx"
                    using funct_7_th_69 sorry
                  also have "... = ?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                    using A15 funct_1_th_13 sorry
                  finally have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 ?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                     sorry
                  have A26: "domRELAT-1K1 ?i(l1) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 (f *FUNCT-1K3 ?i(k1)).FUNCT-1K1 xx"
                    using funct_7_th_71 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                    using A24 funct_1_th_13 sorry
                  also have "... = f .FUNCT-1K1 ((f *FUNCT-1K3 ?i(k)).FUNCT-1K1 xx)"
                    using funct_7_th_71 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0))"
                    using A20 A22 funct_1_th_13 sorry
                  also have "... = f .FUNCT-1K1 ((f *FUNCT-1K3 ?i(l)).FUNCT-1K1 x0)"
                    using A23 funct_1_th_13 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
                    using funct_7_th_71 sorry
                  also have "... = (f *FUNCT-1K3 ?i(l1)).FUNCT-1K1 x0"
                    using A26 funct_1_th_13 sorry
                  also have "... = ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                    using funct_7_th_71 sorry
                  finally have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                     sorry
                  then have "yc inTARSKIR2 c2"
                    using A17 A18 A25 sorry
                  thus "y inHIDDENR3 c2"
                     sorry
                qed "sorry"
                thus "f .:FUNCT-1K5 c1 c=TARSKIR1 c2"
                  using tarski_def_3 sorry
              qed
              thus "f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                using A5 A8 xboole_1_th_63 sorry
              have "f .:FUNCT-1K5 c2 c=TARSKIR1 c1"
              proof-
                have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 c2 implies y inHIDDENR3 c1"
                proof(rule ballI,rule impI)
                  fix y assume [ty]: "y be objectHIDDENM1"
                  have A27: "domRELAT-1K1 f =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  assume "y inHIDDENR3 f .:FUNCT-1K5 c2"
                  then obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    "x inHIDDENR3 domRELAT-1K1 f"and A28: "x inHIDDENR3 c2"and A29: "y =HIDDENR1 f .FUNCT-1K1 x"
                    using funct_1_def_6 sorry
                  obtain xx where
                    [ty]:"xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
                    A30: "x =HIDDENR1 xx"and A31: " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be oddABIANV2) & l be evenABIANV3"
                    using A28 sorry
                  obtain k l where
                    [ty]:"k be NatNAT-1M1" "l be NatNAT-1M1" and 
                    A32: "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"and A33: "k be oddABIANV2"and A34: "l be evenABIANV3"
                    using A31 sorry
                  have 
                    [ty]:"l be evenABIANV3\<bar>NatNAT-1M1"
                    using A34 sorry
                  have 
                    [ty]:"k be oddABIANV2\<bar>NatNAT-1M1"
                    using A33 sorry
                  obtain k1 where 
                    [ty]:"k1 be evenABIANV3\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and k1Def:"k1 = k +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  obtain l1 where 
                    [ty]:"l1 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and l1Def:"l1 = l +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  obtain l2 where 
                    [ty]:"l2 be evenABIANV3\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and l2Def:"l2 = l1 +NAT-1K1 \<one>\<^sub>M"
                     sorry
                  have A35: "domRELAT-1K1 ?i(k) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  obtain yc where 
                    [ty]:"yc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and ycDef:"yc = y"
                    using A29 A30 abian_th_6 sorry
                  have A36: "domRELAT-1K1 ?i(l) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have A37: "domRELAT-1K1 ?i(k1) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have A38: "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 (?i(k1) *FUNCT-1K3 f).FUNCT-1K1 xx"
                    using funct_7_th_69 sorry
                  also have "... = ?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                    using A27 funct_1_th_13 sorry
                  finally have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 ?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                     sorry
                  have A39: "domRELAT-1K1 ?i(l1) =XBOOLE-0R4 E"
                    using funct_2_def_1 sorry
                  have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 (f *FUNCT-1K3 ?i(k1)).FUNCT-1K1 xx"
                    using funct_7_th_71 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx)"
                    using A37 funct_1_th_13 sorry
                  also have "... = f .FUNCT-1K1 ((f *FUNCT-1K3 ?i(k)).FUNCT-1K1 xx)"
                    using funct_7_th_71 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0))"
                    using A32 A35 funct_1_th_13 sorry
                  also have "... = f .FUNCT-1K1 ((f *FUNCT-1K3 ?i(l)).FUNCT-1K1 x0)"
                    using A36 funct_1_th_13 sorry
                  also have "... = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
                    using funct_7_th_71 sorry
                  also have "... = (f *FUNCT-1K3 ?i(l1)).FUNCT-1K1 x0"
                    using A39 funct_1_th_13 sorry
                  also have "... = ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                    using funct_7_th_71 sorry
                  finally have "?i(k1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> xx =HIDDENR1 ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
                     sorry
                  then have "yc inTARSKIR2 c1"
                    using A29 A30 A38 sorry
                  thus "y inHIDDENR3 c1"
                     sorry
                qed "sorry"
                thus "f .:FUNCT-1K5 c2 c=TARSKIR1 c1"
                  using tarski_def_3 sorry
              qed
              thus "f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                using A5 A6 xboole_1_th_63 sorry
              show "f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A7 sorry
            qed "sorry"
          qed
          have case2: "c1 meetsXBOOLE-0R5 c2 implies ( ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)))"
          proof(rule impI)
            assume "c1 meetsXBOOLE-0R5 c2"
            then obtain x1 where
              [ty]:"x1 be objectHIDDENM1" and 
              A40: "x1 inHIDDENR3 c1"and A41: "x1 inHIDDENR3 c2"
              using xboole_0_th_3 sorry
            obtain x11 where
              [ty]:"x11 be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
              A42: "x1 =HIDDENR1 x11"and A43: " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x11 =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be evenABIANV3) & l be evenABIANV3"
              using A40 sorry
            obtain x12 where
              [ty]:"x12 be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
              A44: "x1 =HIDDENR1 x12"and A45: " ex k be NatNAT-1M1 st  ex l be NatNAT-1M1 st (?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x12 =XBOOLE-0R4 ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0 & k be oddABIANV2) & l be evenABIANV3"
              using A41 sorry
            obtain k2 l2 where
              [ty]:"k2 be NatNAT-1M1" "l2 be NatNAT-1M1" and 
              A46: "?i(k2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x12 =XBOOLE-0R4 ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"and A47: "k2 be oddABIANV2"and A48: "l2 be evenABIANV3"
              using A45 sorry
            have 
              [ty]:"x1 be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
              using A42 sorry
            obtain k1 l1 where
              [ty]:"k1 be NatNAT-1M1" "l1 be NatNAT-1M1" and 
              A49: "?i(k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x11 =XBOOLE-0R4 ?i(l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"and A50: "k1 be evenABIANV3 & l1 be evenABIANV3"
              using A43 sorry
            have A51: "domRELAT-1K1 ?i(k1) =XBOOLE-0R4 E"
              using funct_2_def_1 sorry
            have A52: "domRELAT-1K1 ?i(l1) =XBOOLE-0R4 E"
              using funct_2_def_1 sorry
            have A53: "?i(l2 +XCMPLX-0K2 k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1 =HIDDENR1 (?i(l2) *FUNCT-1K3 ?i(k1)).FUNCT-1K1 x1"
              using funct_7_th_77 sorry
            also have "... = ?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
              using A42 A49 A51 funct_1_th_13 sorry
            also have "... = (?i(l2) *FUNCT-1K3 ?i(l1)).FUNCT-1K1 x0"
              using A52 funct_1_th_13 sorry
            also have "... = ?i(l1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
              using funct_7_th_77 sorry
            finally have "?i(l2 +XCMPLX-0K2 k1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1 =HIDDENR1 ?i(l1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
               sorry
            have A54: "domRELAT-1K1 ?i(l2) =XBOOLE-0R4 E"
              using funct_2_def_1 sorry
            have A55: "domRELAT-1K1 ?i(k2) =XBOOLE-0R4 E"
              using funct_2_def_1 sorry
            have A56: "?i(l1 +XCMPLX-0K2 k2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1 =HIDDENR1 (?i(l1) *FUNCT-1K3 ?i(k2)).FUNCT-1K1 x1"
              using funct_7_th_77 sorry
            also have "... = ?i(l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0)"
              using A44 A46 A55 funct_1_th_13 sorry
            also have "... = (?i(l1) *FUNCT-1K3 ?i(l2)).FUNCT-1K1 x0"
              using A54 funct_1_th_13 sorry
            also have "... = ?i(l1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
              using funct_7_th_77 sorry
            finally have "?i(l1 +XCMPLX-0K2 k2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1 =HIDDENR1 ?i(l1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x0"
               sorry
            have " ex r be ElementSUBSET-1M1-of E st  ex k be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st ?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
            proof-
              have " ex r be ElementSUBSET-1M1-of E st  ex tVar17 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar17)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
              proof-
                have 
                  [ty]:"k2 be oddABIANV2\<bar>NatNAT-1M1"
                  using A47 sorry
                have 
                  [ty]:"k1 be evenABIANV3\<bar>NatNAT-1M1" and
                  [ty]:"l1 be evenABIANV3\<bar>NatNAT-1M1" and
                  [ty]:"l2 be evenABIANV3\<bar>NatNAT-1M1"
                  using A50 A48 sorry
                have A57: "domRELAT-1K1 ?i(k1 +XCMPLX-0K2 l2) =XBOOLE-0R4 E"
                  using funct_2_def_1 sorry
                have A58: "domRELAT-1K1 ?i(k2 +XCMPLX-0K2 l1) =XBOOLE-0R4 E"
                  using funct_2_def_1 sorry
                show " ex r be ElementSUBSET-1M1-of E st  ex tVar17 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar17)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
                proof-
                  have cases: "k1 +XCMPLX-0K2 l2 <XXREAL-0R3 k2 +XCMPLX-0K2 l1 or k1 +XCMPLX-0K2 l2 >XXREAL-0R4 k2 +XCMPLX-0K2 l1"
                    using xxreal_0_th_1 sorry
                  have case1: "k1 +XCMPLX-0K2 l2 <XXREAL-0R3 k2 +XCMPLX-0K2 l1 implies ( ex r be ElementSUBSET-1M1-of E st  ex tVar17 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar17)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c)"
                  proof(rule impI)
                    assume "k1 +XCMPLX-0K2 l2 <XXREAL-0R3 k2 +XCMPLX-0K2 l1"
                    then obtain k where 
                      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = (k2 +XCMPLX-0K2 l1)-XCMPLX-0K6 (k1 +XCMPLX-0K2 l2)"
                      using int_1_th_5 sorry
                    obtain r where 
                      [ty]:"r be ElementSUBSET-1M1-of E" and rDef:"r = ?i(k1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                       sorry
                    show " ex r be ElementSUBSET-1M1-of E st  ex tVar17 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar17)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
                    proof(rule bexI[of _ "r"])
                      have 
                        [ty]:"k be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
                         sorry
                      show " ex tVar17 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar17)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
                      proof(rule bexI[of _ "k"],rule conjMI)
                        have "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1) =HIDDENR1 (?i(k) *FUNCT-1K3 ?i(k1 +XCMPLX-0K2 l2)).FUNCT-1K1 x1"
                          using A57 funct_1_th_13 sorry
                        also have "... = ?i(k +XCMPLX-0K2 (k1 +XCMPLX-0K2 l2)) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                          using funct_7_th_77 sorry
                        also have "... = ?i(k1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                          using A56 A53 sorry
                        finally have "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1) =HIDDENR1 ?i(k1 +XCMPLX-0K2 l2) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                           sorry
                        thus "(iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
                           sorry
                        show "r inTARSKIR2 c"
                          using abian_th_7 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  have case2: "k1 +XCMPLX-0K2 l2 >XXREAL-0R4 k2 +XCMPLX-0K2 l1 implies ( ex r be ElementSUBSET-1M1-of E st  ex tVar19 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar19)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c)"
                  proof(rule impI)
                    assume "k1 +XCMPLX-0K2 l2 >XXREAL-0R4 k2 +XCMPLX-0K2 l1"
                    then obtain k where 
                      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = (k1 +XCMPLX-0K2 l2)-XCMPLX-0K6 (k2 +XCMPLX-0K2 l1)"
                      using int_1_th_5 sorry
                    obtain r where 
                      [ty]:"r be ElementSUBSET-1M1-of E" and rDef:"r = ?i(k2 +XCMPLX-0K2 l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                       sorry
                    show " ex r be ElementSUBSET-1M1-of E st  ex tVar19 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar19)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
                    proof(rule bexI[of _ "r"])
                      have 
                        [ty]:"k be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1"
                         sorry
                      show " ex tVar19 be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1 st (iterABIANK1\<^bsub>(E)\<^esub>(f,tVar19)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r & r inTARSKIR2 c"
                      proof(rule bexI[of _ "k"],rule conjMI)
                        have "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k2 +XCMPLX-0K2 l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1) =HIDDENR1 (?i(k) *FUNCT-1K3 ?i(k2 +XCMPLX-0K2 l1)).FUNCT-1K1 x1"
                          using A58 funct_1_th_13 sorry
                        also have "... = ?i(k +XCMPLX-0K2 (k2 +XCMPLX-0K2 l1)) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                          using funct_7_th_77 sorry
                        also have "... = ?i(k2 +XCMPLX-0K2 l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                          using A56 A53 sorry
                        finally have "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(k2 +XCMPLX-0K2 l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1) =HIDDENR1 ?i(k2 +XCMPLX-0K2 l1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x1"
                           sorry
                        thus "(iterABIANK1\<^bsub>(E)\<^esub>(f,k)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
                           sorry
                        show "r inTARSKIR2 c"
                          using abian_th_7 sorry
                      qed "sorry"
                    qed "sorry"
                  qed
                  show " ?thesis "
                    using cases case1 case2 sorry
                qed
              qed
              thus " ?thesis "
                 sorry
            qed
            then obtain r k where
              [ty]:"r be ElementSUBSET-1M1-of E" "k be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A59: "?i(k) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"and A60: "r inTARSKIR2 c"
               sorry
            have 
              [ty]:"r be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
              using A60 sorry
            let ?F = "\<lambda>Lamb1. {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-1K1 Lamb1 =XBOOLE-0R4 r }"
            have A61: " for x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds ?F(x) inTARSKIR2 boolSETFAM-1K9 NATNUMBERSK1"
            proof-
              have " for x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds {lc where lc be ElementSUBSET-1M1-of NATNUMBERSK1 : (iterABIANK1\<^bsub>(E)\<^esub>(f,lc)).FUNCT-1K1 x =XBOOLE-0R4 r } inTARSKIR2 boolSETFAM-1K9 NATNUMBERSK1"
              proof(rule ballI)
                fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
                let ?P1 = "\<lambda>Lamb1. ?i(Lamb1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r"
                have "{l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?P1(l) } be SubsetSUBSET-1M2-of NATNUMBERSK1"
                  using domain_1_sch_7 sorry
                thus "{lc where lc be ElementSUBSET-1M1-of NATNUMBERSK1 : (iterABIANK1\<^bsub>(E)\<^esub>(f,lc)).FUNCT-1K1 x =XBOOLE-0R4 r } inTARSKIR2 boolSETFAM-1K9 NATNUMBERSK1"
                   sorry
              qed "sorry"
              thus " ?thesis "
                 sorry
            qed
            obtain Odl where
              [ty]:"Odl be FunctionFUNCT-2M1-of(c,boolSETFAM-1K9 NATNUMBERSK1)" and 
              A62: " for x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 ?F(x)"
              using funct_2_sch_8 A61 sorry
            have " for n be objectHIDDENM1 holds n inHIDDENR3 domRELAT-1K1 Odl implies Odl .FUNCT-1K1 n be  non emptyXBOOLE-0V1"
            proof(rule ballI,rule impI)
              let ?P = "\<lambda>Lamb1. ?i(k *XCMPLX-0K3 Lamb1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
              fix n assume [ty]: "n be objectHIDDENM1"
              assume "n inHIDDENR3 domRELAT-1K1 Odl"
              then obtain nc where 
                [ty]:"nc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and ncDef:"nc = n"
                using funct_2_def_1 sorry
              have A63: "Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> nc =XBOOLE-0R4 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> nc =XBOOLE-0R4 r }"
                using A62 sorry
              have A64: " for i be NatNAT-1M1 holds (iterABIANK1\<^bsub>(E)\<^esub>(f,k *XCMPLX-0K3 i)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r implies (iterABIANK1\<^bsub>(E)\<^esub>(f,k *XCMPLX-0K3 (i +NAT-1K1 \<one>\<^sub>M))).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
              proof(rule ballI,rule impI)
                fix i assume [ty]: "i be NatNAT-1M1"
                assume A65: "?P(i)"
                have A66: "domRELAT-1K1 ?i(k) =XBOOLE-0R4 E"
                  using funct_2_def_1 sorry
                have "?i(k *NAT-1K2 (i +NAT-1K1 \<one>\<^sub>M)) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =HIDDENR1 ?i(k *XCMPLX-0K3 i +NAT-1K1 k *NAT-1K2 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r"
                   sorry
                also have "... = (?i(k *XCMPLX-0K3 i) *FUNCT-1K3 ?i(k)).FUNCT-1K1 r"
                  using funct_7_th_77 sorry
                also have "... = r"
                  using A59 A65 A66 funct_1_th_13 sorry
                finally have "?i(k *NAT-1K2 (i +NAT-1K1 \<one>\<^sub>M)) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =HIDDENR1 r"
                   sorry
                thus "(iterABIANK1\<^bsub>(E)\<^esub>(f,k *XCMPLX-0K3 (i +NAT-1K1 \<one>\<^sub>M))).FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
                   sorry
              qed "sorry"
              have A67: "?P(0NUMBERSK6)"
                using abian_th_3 sorry
              have A68: " for i be NatNAT-1M1 holds ?P(i)"
                using nat_1_sch_2 A67 A64 sorry
              have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
                using eqrel_1_def_3 sorry
              then have "[DOMAIN-1K1\<^bsub>(c,c)\<^esub> nc,r ] inTARSKIR2 =-ABIANK2\<^bsub>(E)\<^esub> f"
                using eqrel_1_th_22 sorry
              then obtain kn ln where
                [ty]:"kn be NatNAT-1M1" "ln be NatNAT-1M1" and 
                A69: "(iterABIANK1\<^bsub>(E)\<^esub>(f,kn)).FUNCT-2K3\<^bsub>(E,E)\<^esub> nc =XBOOLE-0R4 (iterABIANK1\<^bsub>(E)\<^esub>(f,ln)).FUNCT-2K3\<^bsub>(E,E)\<^esub> r"
                using abian_def_7 sorry
              have A70: "domRELAT-1K1 ?i(ln) =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              let ?mk = "ln modNAT-DK4 k"
              let ?dk = "ln divNAT-DK3 k"
              have A71: "domRELAT-1K1 ?i(kn) =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              have A72: "\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) <>HIDDENR2 k"
                 sorry
              then have "?mk <XXREAL-0R3 k"
                using nat_d_th_1 sorry
              then obtain kmk where 
                [ty]:"kmk be ElementSUBSET-1M1-of NATNUMBERSK1" and kmkDef:"kmk = k -XCMPLX-0K6 ?mk"
                using int_1_th_5 sorry
              have "ln =XBOOLE-0R4 k *NAT-1K2 ?dk +NAT-1K1 ?mk"
                using A72 nat_d_th_2 sorry
              then have A73: "ln +NAT-1K1 kmk =XBOOLE-0R4 k *NAT-1K2 (?dk +NAT-1K1 \<one>\<^sub>M)"
                 sorry
              have "?i(kmk +XCMPLX-0K2 kn) .FUNCT-2K3\<^bsub>(E,E)\<^esub> nc =HIDDENR1 (?i(kmk) *FUNCT-1K3 ?i(kn)).FUNCT-1K1 nc"
                using funct_7_th_77 sorry
              also have "... = ?i(kmk) .FUNCT-2K3\<^bsub>(E,E)\<^esub> (?i(ln) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r)"
                using A69 A71 funct_1_th_13 sorry
              also have "... = (?i(kmk) *FUNCT-1K3 ?i(ln)).FUNCT-1K1 r"
                using A70 funct_1_th_13 sorry
              also have "... = ?i(k *NAT-1K2 (?dk +NAT-1K1 \<one>\<^sub>M)) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r"
                using A73 funct_7_th_77 sorry
              also have "... = r"
                using A68 sorry
              finally have "?i(kmk +XCMPLX-0K2 kn) .FUNCT-2K3\<^bsub>(E,E)\<^esub> nc =HIDDENR1 r"
                 sorry
              then have "kn +NAT-1K1 kmk inTARSKIR2 Odl .FUNCT-1K1 n"
                using A63 sorry
              thus "Odl .FUNCT-1K1 n be  non emptyXBOOLE-0V1"
                 sorry
            qed "sorry"
            then have 
              [ty]:"Odl be non-emptyFUNCT-1V4\<bar>FunctionFUNCT-2M1-of(c,boolSETFAM-1K9 NATNUMBERSK1)"
              using funct_1_def_9 sorry
            let ?F = "\<lambda>Lamb1. minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> Lamb1)"
            obtain odl where
              [ty]:"odl be FunctionFUNCT-2M1-of(c,NATNUMBERSK1)" and 
              A74: " for x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 ?F(x)"
              using funct_2_sch_4 sorry
            let ?P1 = "\<lambda>Lamb1. odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> Lamb1 be evenABIANV3"
            let ?c1 = "{x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P1(x) }"
            let ?d1 = "?c1 \\SUBSET-1K6 {DOMAIN-1K6\<^bsub>(c)\<^esub> r}"
            have "?c1 be SubsetSUBSET-1M2-of c"
              using domain_1_sch_7 sorry
            then have A75: "?d1 c=TARSKIR1 c"
              using xboole_1_th_1 sorry
            have "?i(0NUMBERSK6) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r"
              using abian_th_3 sorry
            then have "0NUMBERSK6 inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> r =XBOOLE-0R4 r }"
               sorry
            then have "0NUMBERSK6 inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> r"
              using A62 sorry
            then have "minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> r) =XBOOLE-0R4 0NUMBERSK6"
              using abian_th_2 sorry
            then have A76: "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> r =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)"
              using A74 sorry
            then have A77: "r inTARSKIR2 ?c1"
               sorry
            obtain d1 where 
              [ty]:"d1 be SubsetSUBSET-1M2-of E" and d1Def:"d1 = ?d1"
              using A75 xboole_1_th_1 sorry
            let ?P2 = "\<lambda>Lamb1. odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> Lamb1 be oddABIANV2"
            let ?d2 = "{x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P2(x) }"
            have "?d2 be SubsetSUBSET-1M2-of c"
              using domain_1_sch_7 sorry
            then obtain d2 where 
              [ty]:"d2 be SubsetSUBSET-1M2-of E" and d2Def:"d2 = ?d2"
              using xboole_1_th_1 sorry
            have A78: " for x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c holds x <>HIDDENR2 r implies odl .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> x) =XBOOLE-0R4 odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x -XCMPLX-0K6 \<one>\<^sub>M"
            proof(rule ballI,rule impI)
              fix x assume [ty]: "x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c"
              obtain fx where 
                [ty]:"fx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and fxDef:"fx = f .FUNCT-2K3\<^bsub>(E,E)\<^esub> x"
                using abian_th_6 sorry
              obtain ofx ox where 
                [ty]:"ofx be ElementSUBSET-1M1-of NATNUMBERSK1" and ofxDef:"ofx = odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> fx" and
                [ty]:"ox be ElementSUBSET-1M1-of NATNUMBERSK1" and oxDef:"ox = odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x"
                 sorry
              assume A79: "x <>HIDDENR2 r"
              have "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 0NUMBERSK6 implies  False "
              proof(rule impI)
                assume "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x =XBOOLE-0R4 0NUMBERSK6"
                then have "0NUMBERSK6 =XBOOLE-0R4 minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x)"
                  using A74 sorry
                then have "0NUMBERSK6 inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x"
                  using xxreal_2_def_7 sorry
                then have "0NUMBERSK6 inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r }"
                  using A62 sorry
                then have " ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 0NUMBERSK6 & ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r"
                   sorry
                thus " False "
                  using A79 abian_th_3 sorry
              qed
              then obtain ox1 where 
                [ty]:"ox1 be ElementSUBSET-1M1-of NATNUMBERSK1" and ox1Def:"ox1 = ox -XCMPLX-0K6 \<one>\<^sub>M"
                using int_1_th_5 nat_1_th_14 sorry
              have "ox =XBOOLE-0R4 minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x)"
                using A74 sorry
              then have "ox inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x"
                using xxreal_2_def_7 sorry
              then have "ox inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r }"
                using A62 sorry
              then have A80: " ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 ox & ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r"
                 sorry
              have A81: "domRELAT-1K1 f =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              then have "?i(ox1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx =HIDDENR1 (?i(ox1) *FUNCT-1K3 f).FUNCT-1K1 x"
                using funct_1_th_13 sorry
              also have "... = ?i(ox1 +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x"
                using funct_7_th_69 sorry
              also have "... = ?i(ox) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x"
                 sorry
              finally have "?i(ox1) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx =HIDDENR1 ?i(ox) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x"
                 sorry
              then have "ox1 inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx =XBOOLE-0R4 r }"
                using A80 sorry
              then have A82: "ox1 inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> fx"
                using A62 sorry
              have "ofx =XBOOLE-0R4 minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> fx)"
                using A74 sorry
              then have "ofx inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> fx"
                using xxreal_2_def_7 sorry
              then have "ofx inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx =XBOOLE-0R4 r }"
                using A62 sorry
              then have A83: " ex l be ElementSUBSET-1M1-of NATNUMBERSK1 st l =XBOOLE-0R4 ofx & ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx =XBOOLE-0R4 r"
                 sorry
              have "?i(ofx +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =HIDDENR1 (?i(ofx) *FUNCT-1K3 f).FUNCT-1K1 x"
                using funct_7_th_69 sorry
              also have "... = ?i(ofx) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx"
                using A81 funct_1_th_13 sorry
              finally have "?i(ofx +NAT-1K1 \<one>\<^sub>M) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =HIDDENR1 ?i(ofx) .FUNCT-2K3\<^bsub>(E,E)\<^esub> fx"
                 sorry
              then have "ofx +NAT-1K1 \<one>\<^sub>M inTARSKIR2 {l where l be ElementSUBSET-1M1-of NATNUMBERSK1 : ?i(l) .FUNCT-2K3\<^bsub>(E,E)\<^esub> x =XBOOLE-0R4 r }"
                using A83 sorry
              then have A84: "ofx +NAT-1K1 \<one>\<^sub>M inTARSKIR2 Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x"
                using A62 sorry
              have "ox =XBOOLE-0R4 minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> x)"
                using A74 sorry
              then have "ofx +NAT-1K1 \<one>\<^sub>M >=XXREAL-0R2 ox"
                using A84 xxreal_2_def_7 sorry
              then have A85: "ofx >=XXREAL-0R2 ox -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_20 sorry
              have "ofx =XBOOLE-0R4 minSEQ-4K4 (Odl .FUNCT-2K3\<^bsub>(c,boolSETFAM-1K9 NATNUMBERSK1)\<^esub> fx)"
                using A74 sorry
              then have "ofx <=XXREAL-0R1 ox -XCMPLX-0K6 \<one>\<^sub>M"
                using A82 xxreal_2_def_7 sorry
              thus "odl .FUNCT-1K1 (f .FUNCT-2K3\<^bsub>(E,E)\<^esub> x) =XBOOLE-0R4 odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x -XCMPLX-0K6 \<one>\<^sub>M"
                using A85 xxreal_0_th_1 sorry
            qed "sorry"
            have A86: "f .:FUNCT-1K5 d1 c=TARSKIR1 d2"
            proof-
              have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 d1 implies y inHIDDENR3 d2"
              proof(rule ballI,rule impI)
                fix y assume [ty]: "y be objectHIDDENM1"
                assume "y inHIDDENR3 f .:FUNCT-1K5 d1"
                then obtain x where
                  [ty]:"x be objectHIDDENM1" and 
                  "x inHIDDENR3 domRELAT-1K1 f"and A87: "x inHIDDENR3 d1"and A88: "y =HIDDENR1 f .FUNCT-1K1 x"
                  using funct_1_def_6 sorry
                have "x inHIDDENR3 ?c1"
                  using A87 sorry
                then obtain xx where
                  [ty]:"xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
                  A89: "x =HIDDENR1 xx"and A90: "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xx be evenABIANV3"
                   sorry
                obtain ox where 
                  [ty]:"ox be evenABIANV3\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and oxDef:"ox = odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xx"
                  using A90 sorry
                obtain yc where 
                  [ty]:"yc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and ycDef:"yc = y"
                  using A88 A89 abian_th_6 sorry
                have "r <>HIDDENR2 xx"
                  using A87 A89 zfmisc_1_th_56 sorry
                then have "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> yc =XBOOLE-0R4 ox -XCMPLX-0K6 \<one>\<^sub>M"
                  using A78 A88 A89 sorry
                thus "y inHIDDENR3 d2"
                   sorry
              qed "sorry"
              thus "f .:FUNCT-1K5 d1 c=TARSKIR1 d2"
                using tarski_def_3 sorry
            qed
            have A91: "?c1 \\/XBOOLE-0K2 d2 =XBOOLE-0R4 c"
            proof-
              have "({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 })\\/XBOOLE-0K2 d2 =XBOOLE-0R4 c"
              proof-
                have "( for x be objectHIDDENM1 holds x inHIDDENR3 ?c1 \\/XBOOLE-0K2 d2 implies x inHIDDENR3 c) & c c=TARSKIR1 ({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 })\\/XBOOLE-0K2 d2"
                proof(rule conjMI)
                  show " for x be objectHIDDENM1 holds x inHIDDENR3 ?c1 \\/XBOOLE-0K2 d2 implies x inHIDDENR3 c"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume A92: "x inHIDDENR3 ?c1 \\/XBOOLE-0K2 d2"
                    show "x inHIDDENR3 c"
                    proof-
                      have cases: "x inHIDDENR3 ?c1 or x inHIDDENR3 d2"
                        using A92 xboole_0_def_3 sorry
                      have case1: "x inHIDDENR3 {x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 } implies x inHIDDENR3 c"
                      proof(rule impI)
                        assume "x inHIDDENR3 ?c1"
                        then have " ex xc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st xc =HIDDENR1 x & odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xc be evenABIANV3"
                           sorry
                        thus "x inHIDDENR3 c"
                           sorry
                      qed
                      have case2: "x inHIDDENR3 d2 implies x inHIDDENR3 c"
                      proof(rule impI)
                        assume "x inHIDDENR3 d2"
                        then have " ex xc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st xc =HIDDENR1 x & odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xc be oddABIANV2"
                           sorry
                        thus "x inHIDDENR3 c"
                           sorry
                      qed
                      show " ?thesis "
                        using cases case1 case2 sorry
                    qed
                  qed "sorry"
                  have " for x be objectHIDDENM1 holds x inHIDDENR3 c implies x inHIDDENR3 ({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 })\\/XBOOLE-0K2 d2"
                  proof(rule ballI,rule impI)
                    fix x assume [ty]: "x be objectHIDDENM1"
                    assume "x inHIDDENR3 c"
                    then obtain xc where 
                      [ty]:"xc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and xcDef:"xc = x"
                       sorry
                    have "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xc be evenABIANV3 or odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xc be oddABIANV2"
                       sorry
                    then have "x inHIDDENR3 ?c1 or x inHIDDENR3 d2"
                       sorry
                    thus "x inHIDDENR3 ({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 })\\/XBOOLE-0K2 d2"
                      using xboole_0_def_3 sorry
                  qed "sorry"
                  thus "c c=TARSKIR1 ({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P1(x) })\\/XBOOLE-0K2 d2"
                    using tarski_def_3 sorry
                qed
                thus "({x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P1(x) })\\/XBOOLE-0K2 d2 =XBOOLE-0R4 c"
                  using tarski_def_3 xboole_0_def_10 sorry
              qed
              thus " ?thesis "
                 sorry
            qed
            obtain d3 where 
              [ty]:"d3 be SubsetSUBSET-1M2-of E" and d3Def:"d3 = {DOMAIN-1K6\<^bsub>(c)\<^esub> r}"
              using zfmisc_1_th_31 sorry
            obtain b where 
              [ty]:"b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :]" and bDef:"b = [DOMAIN-1K4\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> d1,d2,d3 ]"
               sorry
            show " ex b be ElementSUBSET-1M1-of [:ZFMISC-1K3 boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E :] st (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c & (f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & (f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> & f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>))"
            proof(rule bexI[of _ "b"],rule conjMI,rule conjMI,rule conjMI)
              have A93: "b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 d1"
                using mcart_1_def_5 sorry
              have A94: "b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 d2"
                using mcart_1_def_6 sorry
              have A95: "b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 d3"
                using mcart_1_def_7 sorry
              have "d1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> d3 =HIDDENR1 ?c1 \\/XBOOLE-0K2 d3"
                using xboole_1_th_39 sorry
              also have "... = ?c1"
                using A77 zfmisc_1_th_40 sorry
              finally have "d1 \\/SUBSET-1K4\<^bsub>(E)\<^esub> d3 =HIDDENR1 ?c1"
                 sorry
              thus "(b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> =XBOOLE-0R4 c"
                using A93 A94 A95 A91 xboole_1_th_4 sorry
              have A96: "?c1 missesXBOOLE-0R1 d2"
              proof-
                have "{x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 } meetsXBOOLE-0R5 d2 implies  False "
                proof(rule impI)
                  assume "?c1 meetsXBOOLE-0R5 d2"
                  then obtain z where
                    [ty]:"z be objectHIDDENM1" and 
                    A97: "z inHIDDENR3 ?c1 & z inHIDDENR3 d2"
                    using xboole_0_th_3 sorry
                  have "( ex x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st z =HIDDENR1 x & odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3) & ( ex x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c st z =HIDDENR1 x & odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be oddABIANV2)"
                    using A97 sorry
                  thus " False "
                     sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              then have "d1 missesXBOOLE-0R1 d2"
                using xboole_1_th_63 sorry
              thus "f .:FUNCT-1K5 (b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `1-3MCART-1K1\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                using A93 A86 xboole_1_th_63 sorry
              have "f .:FUNCT-1K5 d2 c=TARSKIR1 ?c1"
              proof-
                have "f .:FUNCT-1K5 d2 c=TARSKIR1 {x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 }"
                proof-
                  have " for y be objectHIDDENM1 holds y inHIDDENR3 f .:FUNCT-1K5 d2 implies y inHIDDENR3 {x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 }"
                  proof(rule ballI,rule impI)
                    fix y assume [ty]: "y be objectHIDDENM1"
                    assume "y inHIDDENR3 f .:FUNCT-1K5 d2"
                    then obtain x where
                      [ty]:"x be objectHIDDENM1" and 
                      "x inHIDDENR3 domRELAT-1K1 f"and A98: "x inHIDDENR3 d2"and A99: "y =HIDDENR1 f .FUNCT-1K1 x"
                      using funct_1_def_6 sorry
                    obtain xx where
                      [ty]:"xx be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and 
                      A100: "x =HIDDENR1 xx"and A101: "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xx be oddABIANV2"
                      using A98 sorry
                    obtain ox where 
                      [ty]:"ox be oddABIANV2\<bar>ElementSUBSET-1M1-of NATNUMBERSK1" and oxDef:"ox = odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> xx"
                      using A101 sorry
                    obtain yc where 
                      [ty]:"yc be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c" and ycDef:"yc = y"
                      using A99 A100 abian_th_6 sorry
                    have "odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> yc =XBOOLE-0R4 ox -XCMPLX-0K6 \<one>\<^sub>M"
                      using A76 A78 A99 A100 sorry
                    thus "y inHIDDENR3 {x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : odl .FUNCT-2K3\<^bsub>(c,NATNUMBERSK1)\<^esub> x be evenABIANV3 }"
                       sorry
                  qed "sorry"
                  thus "f .:FUNCT-1K5 d2 c=TARSKIR1 {x where x be ElementSUBSET-1M3\<^bsub>(E)\<^esub>-of c : ?P1(x) }"
                    using tarski_def_3 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
              thus "f .:FUNCT-1K5 (b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `2-3MCART-1K2\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                using A94 A96 xboole_1_th_63 sorry
              show "f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) missesXBOOLE-0R1 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
              proof-
                have "f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) meetsXBOOLE-0R5 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> implies  False "
                proof(rule impI)
                  assume "f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>) meetsXBOOLE-0R5 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                  then obtain y where
                    [ty]:"y be objectHIDDENM1" and 
                    A102: "y inHIDDENR3 f .:FUNCT-1K5 (b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>)"and A103: "y inHIDDENR3 b `3-3MCART-1K3\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub>"
                    using xboole_0_th_3 sorry
                  have A104: "y =HIDDENR1 r"
                    using A95 A103 tarski_def_1 sorry
                  obtain x where
                    [ty]:"x be objectHIDDENM1" and 
                    "x inHIDDENR3 domRELAT-1K1 f"and A105: "x inHIDDENR3 {DOMAIN-1K6\<^bsub>(c)\<^esub> r}"and A106: "y =HIDDENR1 f .FUNCT-1K1 x"
                    using A95 A102 funct_1_def_6 sorry
                  have "x =HIDDENR1 r"
                    using A105 tarski_def_1 sorry
                  then have "r is-a-fixpoint-ofABIANR2\<^bsub>(E)\<^esub> f"
                    using A104 A106 sorry
                  thus " False "
                    using A1 sorry
                qed
                thus " ?thesis "
                   sorry
              qed
            qed "sorry"
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    obtain F where
      [ty]:"F be FunctionFUNCT-2M1-of(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])" and 
      A107: " for a be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) holds ?P(a,F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> a)"
      using funct_2_sch_3 A2 sorry
    let ?E3c = "{F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }"
    let ?E2c = "{F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }"
    let ?E1c = "{F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }"
    let ?E1 = "unionTARSKIK3 ?E1c"
    let ?E2 = "unionTARSKIK3 ?E2c"
    let ?E3 = "unionTARSKIK3 ?E3c"
    show " ex tVar21 be setHIDDENM2 st  ex tVar22 be setHIDDENM2 st  ex tVar23 be setHIDDENM2 st (tVar21 \\/XBOOLE-0K2 tVar22)\\/XBOOLE-0K2 tVar23 =XBOOLE-0R4 E & (f .:FUNCT-1K5 tVar21 missesXBOOLE-0R1 tVar21 & (f .:FUNCT-1K5 tVar22 missesXBOOLE-0R1 tVar22 & f .:FUNCT-1K5 tVar23 missesXBOOLE-0R1 tVar23))"
    proof(rule bexI[of _ "?E1"])
      show " ex tVar22 be setHIDDENM2 st  ex tVar23 be setHIDDENM2 st (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 tVar22)\\/XBOOLE-0K2 tVar23 =XBOOLE-0R4 E & (f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) & (f .:FUNCT-1K5 tVar22 missesXBOOLE-0R1 tVar22 & f .:FUNCT-1K5 tVar23 missesXBOOLE-0R1 tVar23))"
      proof(rule bexI[of _ "?E2"])
        show " ex tVar23 be setHIDDENM2 st (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 tVar23 =XBOOLE-0R4 E & (f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) & (f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) & f .:FUNCT-1K5 tVar23 missesXBOOLE-0R1 tVar23))"
        proof(rule bexI[of _ "?E3"],rule conjMI,rule conjMI,rule conjMI)
          show "(unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) =XBOOLE-0R4 E"
          proof-
            have "( for x be objectHIDDENM1 holds x inHIDDENR3 (?E1 \\/XBOOLE-0K2 ?E2)\\/XBOOLE-0K2 ?E3 implies x inHIDDENR3 E) & E c=TARSKIR1 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
            proof(rule conjMI)
              show " for x be objectHIDDENM1 holds x inHIDDENR3 (?E1 \\/XBOOLE-0K2 ?E2)\\/XBOOLE-0K2 ?E3 implies x inHIDDENR3 E"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                assume "x inHIDDENR3 (?E1 \\/XBOOLE-0K2 ?E2)\\/XBOOLE-0K2 ?E3"
                then have A108: "x inHIDDENR3 ?E1 \\/XBOOLE-0K2 ?E2 or x inHIDDENR3 ?E3"
                  using xboole_0_def_3 sorry
                show "x inHIDDENR3 E"
                proof-
                  have cases: "(x inHIDDENR3 ?E1 or x inHIDDENR3 ?E2) or x inHIDDENR3 ?E3"
                    using A108 xboole_0_def_3 sorry
                  have case1: "x inHIDDENR3 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies x inHIDDENR3 E"
                  proof(rule impI)
                    assume "x inHIDDENR3 ?E1"
                    then obtain Y where
                      [ty]:"Y be setHIDDENM2" and 
                      A109: "x inHIDDENR3 Y"and A110: "Y inTARSKIR2 ?E1c"
                      using tarski_def_4 sorry
                    have " ex c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) st Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                      using A110 sorry
                    thus "x inHIDDENR3 E"
                      using A109 sorry
                  qed
                  have case2: "x inHIDDENR3 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies x inHIDDENR3 E"
                  proof(rule impI)
                    assume "x inHIDDENR3 ?E2"
                    then obtain Y where
                      [ty]:"Y be setHIDDENM2" and 
                      A111: "x inHIDDENR3 Y"and A112: "Y inTARSKIR2 ?E2c"
                      using tarski_def_4 sorry
                    have " ex c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) st Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                      using A112 sorry
                    thus "x inHIDDENR3 E"
                      using A111 sorry
                  qed
                  have case3: "x inHIDDENR3 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies x inHIDDENR3 E"
                  proof(rule impI)
                    assume "x inHIDDENR3 ?E3"
                    then obtain Y where
                      [ty]:"Y be setHIDDENM2" and 
                      A113: "x inHIDDENR3 Y"and A114: "Y inTARSKIR2 ?E3c"
                      using tarski_def_4 sorry
                    have " ex c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) st Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                      using A114 sorry
                    thus "x inHIDDENR3 E"
                      using A113 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 case3 sorry
                qed
              qed "sorry"
              have " for x be objectHIDDENM1 holds x inHIDDENR3 E implies x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
              proof(rule ballI,rule impI)
                fix x assume [ty]: "x be objectHIDDENM1"
                let ?c = "ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x)"
                assume A115: "x inHIDDENR3 E"
                then have A116: "x inHIDDENR3 ?c"
                  using eqrel_1_th_20 sorry
                obtain c where 
                  [ty]:"c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and cDef:"c = ?c"
                  using A115 eqrel_1_def_3 sorry
                have "x inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                  using A107 A116 sorry
                then have A117: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> or x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                  using xboole_0_def_3 sorry
                show "x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                proof-
                  have cases: "(x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> or x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>) or x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                    using A117 xboole_0_def_3 sorry
                  have case1: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> implies x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                  proof(rule impI)
                    assume A118: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                    have "F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> inTARSKIR2 ?E1c"
                       sorry
                    then have "x inHIDDENR3 ?E1"
                      using A118 tarski_def_4 sorry
                    then have "x inHIDDENR3 ?E1 \\/XBOOLE-0K2 ?E2"
                      using xboole_0_def_3 sorry
                    thus "x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                      using xboole_0_def_3 sorry
                  qed
                  have case2: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> implies x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                  proof(rule impI)
                    assume A119: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                    have "F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> inTARSKIR2 ?E2c"
                       sorry
                    then have "x inHIDDENR3 ?E2"
                      using A119 tarski_def_4 sorry
                    then have "x inHIDDENR3 ?E1 \\/XBOOLE-0K2 ?E2"
                      using xboole_0_def_3 sorry
                    thus "x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                      using xboole_0_def_3 sorry
                  qed
                  have case3: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> implies x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                  proof(rule impI)
                    assume A120: "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                    have "F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> inTARSKIR2 ?E3c"
                       sorry
                    then have "x inHIDDENR3 ?E3"
                      using A120 tarski_def_4 sorry
                    thus "x inHIDDENR3 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                      using xboole_0_def_3 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 case3 sorry
                qed
              qed "sorry"
              thus "E c=TARSKIR1 (unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
                using tarski_def_3 sorry
            qed
            thus "(unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) \\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }))\\/XBOOLE-0K2 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) =XBOOLE-0R4 E"
              using tarski_def_3 xboole_0_def_10 sorry
          qed
          show "f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
          proof-
            have " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies  False "
            proof(rule impI)
              assume " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A121: "x inHIDDENR3 f .:FUNCT-1K5 ?E1"and A122: "x inHIDDENR3 ?E1"
                using xboole_0_th_3 sorry
              obtain Y where
                [ty]:"Y be setHIDDENM2" and 
                A123: "x inHIDDENR3 Y"and A124: "Y inTARSKIR2 ?E1c"
                using A122 tarski_def_4 sorry
              obtain c where
                [ty]:"c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A125: "Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A124 sorry
              have "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A123 A125 xboole_0_def_3 sorry
              then have "x inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using xboole_0_def_3 sorry
              then have A126: "x inHIDDENR3 c"
                using A107 sorry
              have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
                using eqrel_1_def_3 sorry
              then have A127: "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x)"
                using A126 eqrel_1_th_23 sorry
              have "domRELAT-1K1 f =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              then have A128: "x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
                using A123 A125 xboole_0_def_3 sorry
              obtain xx where
                [ty]:"xx be objectHIDDENM1" and 
                A129: "xx inHIDDENR3 domRELAT-1K1 f"and A130: "xx inHIDDENR3 ?E1"and A131: "x =HIDDENR1 f .FUNCT-1K1 xx"
                using A121 funct_1_def_6 sorry
              obtain YY where
                [ty]:"YY be setHIDDENM2" and 
                A132: "xx inHIDDENR3 YY"and A133: "YY inTARSKIR2 ?E1c"
                using A130 tarski_def_4 sorry
              obtain cc where
                [ty]:"cc be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A134: "YY =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A133 sorry
              have "xx inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A132 A134 xboole_0_def_3 sorry
              then have "xx inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using xboole_0_def_3 sorry
              then have A135: "xx inHIDDENR3 cc"
                using A107 sorry
              have " ex xx9 be objectHIDDENM1 st xx9 inHIDDENR3 E & cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx9)"
                using eqrel_1_def_3 sorry
              then have A136: "cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A135 eqrel_1_th_23 sorry
              have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 x"
                using A131 funct_7_th_70 sorry
              also have "... = idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 x"
                using A128 funct_1_th_17 sorry
              also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                using funct_7_th_68 sorry
              finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                 sorry
              then have "[TARSKIK4 x,xx ] inHIDDENR3 =-ABIANK2\<^bsub>(E)\<^esub> f"
                using A123 A125 A132 A134 abian_def_7 sorry
              then have A137: "ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A123 A125 eqrel_1_th_35 sorry
              have A138: "f .FUNCT-1K1 xx inTARSKIR2 f .:FUNCT-1K5 YY"
                using A129 A132 funct_1_def_6 sorry
              have "f .:FUNCT-1K5 YY missesXBOOLE-0R1 YY"
                using A107 A134 sorry
              thus " False "
                using A123 A125 A131 A134 A127 A136 A137 A138 xboole_0_th_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          show "f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
          proof-
            have " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies  False "
            proof(rule impI)
              assume " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A139: "x inHIDDENR3 f .:FUNCT-1K5 ?E2"and A140: "x inHIDDENR3 ?E2"
                using xboole_0_th_3 sorry
              obtain Y where
                [ty]:"Y be setHIDDENM2" and 
                A141: "x inHIDDENR3 Y"and A142: "Y inTARSKIR2 ?E2c"
                using A140 tarski_def_4 sorry
              obtain c where
                [ty]:"c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A143: "Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A142 sorry
              have "x inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A141 A143 xboole_0_def_3 sorry
              then have "x inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using xboole_0_def_3 sorry
              then have A144: "x inHIDDENR3 c"
                using A107 sorry
              have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
                using eqrel_1_def_3 sorry
              then have A145: "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x)"
                using A144 eqrel_1_th_23 sorry
              have "domRELAT-1K1 f =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              then have A146: "x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
                using A141 A143 xboole_0_def_3 sorry
              obtain xx where
                [ty]:"xx be objectHIDDENM1" and 
                A147: "xx inHIDDENR3 domRELAT-1K1 f"and A148: "xx inHIDDENR3 ?E2"and A149: "x =HIDDENR1 f .FUNCT-1K1 xx"
                using A139 funct_1_def_6 sorry
              obtain YY where
                [ty]:"YY be setHIDDENM2" and 
                A150: "xx inHIDDENR3 YY"and A151: "YY inTARSKIR2 ?E2c"
                using A148 tarski_def_4 sorry
              obtain cc where
                [ty]:"cc be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A152: "YY =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A151 sorry
              have "xx inHIDDENR3 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A150 A152 xboole_0_def_3 sorry
              then have "xx inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using xboole_0_def_3 sorry
              then have A153: "xx inHIDDENR3 cc"
                using A107 sorry
              have " ex xx9 be objectHIDDENM1 st xx9 inHIDDENR3 E & cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx9)"
                using eqrel_1_def_3 sorry
              then have A154: "cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A153 eqrel_1_th_23 sorry
              have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 x"
                using A149 funct_7_th_70 sorry
              also have "... = idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 x"
                using A146 funct_1_th_17 sorry
              also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                using funct_7_th_68 sorry
              finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                 sorry
              then have "[TARSKIK4 x,xx ] inHIDDENR3 =-ABIANK2\<^bsub>(E)\<^esub> f"
                using A141 A143 A150 A152 abian_def_7 sorry
              then have A155: "ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A141 A143 eqrel_1_th_35 sorry
              have A156: "f .FUNCT-1K1 xx inTARSKIR2 f .:FUNCT-1K5 YY"
                using A147 A150 funct_1_def_6 sorry
              have "f .:FUNCT-1K5 YY missesXBOOLE-0R1 YY"
                using A107 A152 sorry
              thus " False "
                using A141 A143 A149 A152 A145 A154 A155 A156 xboole_0_th_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          show "f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
          proof-
            have " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) implies  False "
            proof(rule impI)
              assume " not f .:FUNCT-1K5 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  }) missesXBOOLE-0R1 unionTARSKIK3 ({F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> where c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f) :  True  })"
              then obtain x where
                [ty]:"x be objectHIDDENM1" and 
                A157: "x inHIDDENR3 f .:FUNCT-1K5 ?E3"and A158: "x inHIDDENR3 ?E3"
                using xboole_0_th_3 sorry
              obtain Y where
                [ty]:"Y be setHIDDENM2" and 
                A159: "x inHIDDENR3 Y"and A160: "Y inTARSKIR2 ?E3c"
                using A158 tarski_def_4 sorry
              obtain c where
                [ty]:"c be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A161: "Y =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A160 sorry
              have "x inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> c `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A159 A161 xboole_0_def_3 sorry
              then have A162: "x inHIDDENR3 c"
                using A107 sorry
              have " ex x9 be objectHIDDENM1 st x9 inHIDDENR3 E & c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x9)"
                using eqrel_1_def_3 sorry
              then have A163: "c =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x)"
                using A162 eqrel_1_th_23 sorry
              have "domRELAT-1K1 f =XBOOLE-0R4 E"
                using funct_2_def_1 sorry
              then have A164: "x inHIDDENR3 domRELAT-1K1 f \\/XBOOLE-0K2 rngFUNCT-1K2 f"
                using A159 A161 xboole_0_def_3 sorry
              obtain xx where
                [ty]:"xx be objectHIDDENM1" and 
                A165: "xx inHIDDENR3 domRELAT-1K1 f"and A166: "xx inHIDDENR3 ?E3"and A167: "x =HIDDENR1 f .FUNCT-1K1 xx"
                using A157 funct_1_def_6 sorry
              obtain YY where
                [ty]:"YY be setHIDDENM2" and 
                A168: "xx inHIDDENR3 YY"and A169: "YY inTARSKIR2 ?E3c"
                using A166 tarski_def_4 sorry
              obtain cc where
                [ty]:"cc be ElementSUBSET-1M3\<^bsub>(boolZFMISC-1K1 E)\<^esub>-of ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f)" and 
                A170: "YY =XBOOLE-0R4 F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A169 sorry
              have "xx inHIDDENR3 (F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `1-3MCART-1K1\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub> \\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `2-3MCART-1K2\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>)\\/SUBSET-1K4\<^bsub>(E)\<^esub> F .FUNCT-2K3\<^bsub>(ClassEQREL-1K9\<^bsub>(E)\<^esub> (=-ABIANK2\<^bsub>(E)\<^esub> f),[:MCART-1K9\<^bsub>(boolZFMISC-1K1 E,boolZFMISC-1K1 E,boolZFMISC-1K1 E)\<^esub> boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E :])\<^esub> cc `3-3MCART-1K3\<^bsub>(boolSETFAM-1K9 E,boolSETFAM-1K9 E,boolSETFAM-1K9 E)\<^esub>"
                using A168 A170 xboole_0_def_3 sorry
              then have A171: "xx inHIDDENR3 cc"
                using A107 sorry
              have " ex xx9 be objectHIDDENM1 st xx9 inHIDDENR3 E & cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx9)"
                using eqrel_1_def_3 sorry
              then have A172: "cc =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A171 eqrel_1_th_23 sorry
              have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 x"
                using A167 funct_7_th_70 sorry
              also have "... = idRELAT-1K7 (fieldRELAT-1K3 f) .FUNCT-1K1 x"
                using A164 funct_1_th_17 sorry
              also have "... = (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                using funct_7_th_68 sorry
              finally have "(iterABIANK1\<^bsub>(E)\<^esub>(f,\<one>\<^sub>M)).FUNCT-1K1 xx =HIDDENR1 (iterABIANK1\<^bsub>(E)\<^esub>(f,0NUMBERSK6)).FUNCT-1K1 x"
                 sorry
              then have "[TARSKIK4 x,xx ] inHIDDENR3 =-ABIANK2\<^bsub>(E)\<^esub> f"
                using A159 A161 A168 A170 abian_def_7 sorry
              then have A173: "ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,x) =XBOOLE-0R4 ClassEQREL-1K7\<^bsub>(E,E)\<^esub>(=-ABIANK2\<^bsub>(E)\<^esub> f,xx)"
                using A159 A161 eqrel_1_th_35 sorry
              have A174: "f .FUNCT-1K1 xx inTARSKIR2 f .:FUNCT-1K5 YY"
                using A165 A168 funct_1_def_6 sorry
              have "f .:FUNCT-1K5 YY missesXBOOLE-0R1 YY"
                using A107 A170 sorry
              thus " False "
                using A159 A161 A167 A170 A163 A172 A173 A174 xboole_0_th_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
        qed "sorry"
      qed "sorry"
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem abian_th_9:
" for n be NatNAT-1M1 holds n be oddABIANV2 iff ( ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds (n be oddABIANV2 implies ( ex j be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 j +NAT-1K1 \<one>\<^sub>M)) &  not ( not ( for k be NatNAT-1M1 holds  not n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) & n be oddABIANV2)"
  proof(rule ballI,rule conjMI)
    fix n assume [ty]: "n be NatNAT-1M1"
    show "n be oddABIANV2 implies ( ex j be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 j +NAT-1K1 \<one>\<^sub>M)"
    proof(rule impI)
      assume A1: "n be oddABIANV2"
      then obtain j where
        [ty]:"j be IntegerINT-1M1" and 
        A2: "n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M"
        using abian_th_1 sorry
      have "j <XXREAL-0R3 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "j <XXREAL-0R3 0NUMBERSK6"
        then have A3: "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M <=XXREAL-0R1 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)"
          using int_1_th_7 xreal_1_th_68 sorry
        show " False "
        proof-
          have cases: "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6 or \<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
            using A3 sorry
          have case1: "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M <XXREAL-0R3 0NUMBERSK6"
            thus " False "
              using A2 sorry
          qed
          have case2: "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 implies  False "
          proof(rule impI)
            assume "\<two>\<^sub>M *XCMPLX-0K3 j +XCMPLX-0K2 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
            then have "n =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)"
               sorry
            thus " False "
              using A1 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      then have "j inHIDDENR3 NATNUMBERSK1"
        using int_1_th_3 sorry
      then have 
        [ty]:"j be NatNAT-1M1"
         sorry
      show " ex j be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 j +NAT-1K1 \<one>\<^sub>M"
      proof(rule bexI[of _ "j"])
        show "n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 j +NAT-1K1 \<one>\<^sub>M"
          using A2 sorry
      qed "sorry"
    qed
    show " not ( not ( for k be NatNAT-1M1 holds  not n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M) & n be oddABIANV2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem abian_th_10:
" for n be NatNAT-1M1 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,A) holds  for x be ElementSUBSET-1M1-of A holds (iterABIANK1\<^bsub>(A)\<^esub>(f,n +NAT-1K1 \<one>\<^sub>M)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x =XBOOLE-0R4 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> ((iterABIANK1\<^bsub>(A)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x)"
proof-
  have " for n be NatNAT-1M1 holds  for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of(A,A) holds  for x be ElementSUBSET-1M1-of A holds (iterABIANK1\<^bsub>(A)\<^esub>(f,n +NAT-1K1 \<one>\<^sub>M)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x =HIDDENR1 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> ((iterABIANK1\<^bsub>(A)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of(A,A)"
    fix x assume [ty]: "x be ElementSUBSET-1M1-of A"
    have "(iterABIANK1\<^bsub>(A)\<^esub>(f,n +NAT-1K1 \<one>\<^sub>M)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x =HIDDENR1 (f *FUNCT-1K3 (iterABIANK1\<^bsub>(A)\<^esub>(f,n))).FUNCT-1K1 x"
      using funct_7_th_71 sorry
    also have "... = f .FUNCT-2K3\<^bsub>(A,A)\<^esub> ((iterABIANK1\<^bsub>(A)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x)"
      using funct_2_th_15 sorry
    finally show "(iterABIANK1\<^bsub>(A)\<^esub>(f,n +NAT-1K1 \<one>\<^sub>M)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x =HIDDENR1 f .FUNCT-2K3\<^bsub>(A,A)\<^esub> ((iterABIANK1\<^bsub>(A)\<^esub>(f,n)).FUNCT-2K3\<^bsub>(A,A)\<^esub> x)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem abian_th_11:
" for i be IntegerINT-1M1 holds i be evenABIANV1 iff ( ex j be IntegerINT-1M1 st i =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 j)"
  using abian_lm_1 sorry

mtheorem abian_cl_29:
"cluster oddABIANV2 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be oddABIANV2"
  proof-
    have " ex tVar25 be NatNAT-1M1 st  not tVar25 be oddABIANV2"
    proof-
      show " ex tVar25 be NatNAT-1M1 st  not tVar25 be oddABIANV2"
      proof(rule bexI[of _ "\<one>\<^sub>M"])
        have "\<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
           sorry
        thus " not \<one>\<^sub>M be oddABIANV2"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_cl_30:
"cluster evenABIANV3 for NatNAT-1M1"
proof
(*existence*)
  show " ex it be NatNAT-1M1 st it be evenABIANV3"
  proof-
    have " ex tVar26 be NatNAT-1M1 st tVar26 be evenABIANV3"
    proof-
      show " ex tVar26 be NatNAT-1M1 st tVar26 be evenABIANV3"
      proof(rule bexI[of _ "0NUMBERSK6"])
        have "0NUMBERSK6 =XBOOLE-0R4 \<two>\<^sub>M *NAT-1K2 (0NUMBERSK6)"
           sorry
        thus "0NUMBERSK6 be evenABIANV3"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem abian_th_12:
" for n be oddABIANV2\<bar>NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n"
proof(rule ballI)
  fix n assume [ty]: "n be oddABIANV2\<bar>NatNAT-1M1"
  have "\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) <XXREAL-0R3 n"
     sorry
  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 n"
    using nat_1_th_13 sorry
  thus "\<one>\<^sub>M <=XXREAL-0R1 n"
     sorry
qed "sorry"

mtheorem abian_cl_31:
"cluster oddABIANV2 also-is  non zeroORDINAL1V8 for IntegerINT-1M1"
proof
(*coherence*)
  show " for it be IntegerINT-1M1 holds it be oddABIANV2 implies it be  non zeroORDINAL1V8"
    using abian_th_12 sorry
qed "sorry"

end
