theory finseq_5
  imports rfinseq nat_d partfun2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve i, j, k, n for "NatNAT-1M1"
mtheorem finseq_5_th_1:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i <=XXREAL-0R1 n implies (n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume "i <=XXREAL-0R1 n"
  then obtain ni where 
    [ty]:"ni be ElementSUBSET-1M1-of NATNUMBERSK1" and niDef:"ni = n -XCMPLX-0K6 i"
    using int_1_th_5 sorry
  have "ni +NAT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
     sorry
  thus "(n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
     sorry
qed "sorry"

mtheorem finseq_5_th_2:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i inTARSKIR2 SegFINSEQ-1K2 n implies (n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "i inTARSKIR2 SegFINSEQ-1K2 n"
  then have "i <=XXREAL-0R1 n"
    using finseq_1_th_1 sorry
  then obtain ni where 
    [ty]:"ni be ElementSUBSET-1M1-of NATNUMBERSK1" and niDef:"ni = n -XCMPLX-0K6 i"
    using int_1_th_5 sorry
  obtain j where 
    [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = ni +NAT-1K1 \<one>\<^sub>M"
     sorry
  have A2: "j =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M implies  False "
  proof(rule impI)
    assume "j =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
    then have "-XCMPLX-0K4 0NUMBERSK6 =HIDDENR1 -XCMPLX-0K4 i"
       sorry
    thus " False "
      using A1 finseq_1_th_1 sorry
  qed
  have "j <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
    using xreal_1_th_6 xreal_1_th_43 sorry
  then have "j <XXREAL-0R3 n +NAT-1K1 \<one>\<^sub>M"
    using A2 xxreal_0_th_1 sorry
  then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 j & j <=XXREAL-0R1 n"
    using nat_1_th_13 sorry
  thus "(n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 n"
     sorry
qed "sorry"

mtheorem finseq_5_th_3:
" for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies (x inHIDDENR3 domRELAT-1K1 f & y inHIDDENR3 rngFUNCT-1K2 f) & f .FUNCT-1K1 x =HIDDENR1 y"
proof-
  have " for f be FunctionFUNCT-1M1 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x} implies x inHIDDENR3 domRELAT-1K1 f & (y inHIDDENR3 rngFUNCT-1K2 f & f .FUNCT-1K1 x =HIDDENR1 y)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    assume "f \<inverse>FUNCT-1K6 {TARSKIK1 y} =XBOOLE-0R4 {TARSKIK1 x}"
    then have A1: "x inHIDDENR3 f \<inverse>FUNCT-1K6 {TARSKIK1 y}"
      using tarski_def_1 sorry
    thus A2: "x inHIDDENR3 domRELAT-1K1 f"
      using funct_1_def_7 sorry
    have "f .FUNCT-1K1 x inTARSKIR2 {TARSKIK1 y}"
      using A1 funct_1_def_7 sorry
    then have "f .FUNCT-1K1 x =HIDDENR1 y"
      using tarski_def_1 sorry
    thus "y inHIDDENR3 rngFUNCT-1K2 f & f .FUNCT-1K1 x =HIDDENR1 y"
      using A2 funct_1_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_4:
" for f be FunctionFUNCT-1M1 holds f be one-to-oneFUNCT-1V2 iff ( for x be setHIDDENM2 holds x inTARSKIR2 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})"
proof-
  have " for f be FunctionFUNCT-1M1 holds  not (f be one-to-oneFUNCT-1V2 &  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}))) &  not (( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})) &  not f be one-to-oneFUNCT-1V2)"
  proof(rule ballI)
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    have "(( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})) & (( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x))"
    proof(rule conjMI,rule impI,rule ballI,rule impI)
      show "( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x) implies ( for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})"
      proof(rule impI,rule ballI,rule impI)
        assume A1: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f is-one-to-one-atFINSEQ-4R1 x"
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 domRELAT-1K1 f"
        then have "f is-one-to-one-atFINSEQ-4R1 x"
          using A1 sorry
        thus "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
          using finseq_4_th_2 sorry
      qed "sorry"
      assume A2: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 domRELAT-1K1 f"
      then have "f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}"
        using A2 sorry
      thus "f is-one-to-one-atFINSEQ-4R1 x"
        using A3 finseq_4_th_2 sorry
    qed "sorry"
    thus " not (f be one-to-oneFUNCT-1V2 &  not ( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x}))) &  not (( for x be setHIDDENM2 holds  not (x inTARSKIR2 domRELAT-1K1 f &  not f \<inverse>FUNCT-1K6 {TARSKIK1 f .FUNCT-1K1 x } =XBOOLE-0R4 {TARSKIK1 x})) &  not f be one-to-oneFUNCT-1V2)"
      using finseq_4_th_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_5:
" for f be FunctionFUNCT-1M1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds (f be one-to-oneFUNCT-1V2 & y1 inHIDDENR3 rngFUNCT-1K2 f) & f \<inverse>FUNCT-1K6 {TARSKIK1 y1} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y2} implies y1 =HIDDENR1 y2"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FunctionFUNCT-1M1"
  fix y1 assume [ty]: "y1 be objectHIDDENM1"
  fix y2 assume [ty]: "y2 be objectHIDDENM1"
  assume A1: "f be one-to-oneFUNCT-1V2 & y1 inHIDDENR3 rngFUNCT-1K2 f"
    and A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 y1} =XBOOLE-0R4 f \<inverse>FUNCT-1K6 {TARSKIK1 y2}"
  obtain x1 where
    [ty]:"x1 be objectHIDDENM1" and 
    A3: "f \<inverse>FUNCT-1K6 {TARSKIK1 y1} =XBOOLE-0R4 {TARSKIK1 x1}"
    using A1 funct_1_th_74 sorry
  have "f .FUNCT-1K1 x1 =HIDDENR1 y1"
    using A3 finseq_5_th_3 sorry
  thus "y1 =HIDDENR1 y2"
    using A2 A3 finseq_5_th_3 sorry
qed "sorry"

mtheorem finseq_5_cl_1:
  mlet "x be objectHIDDENM1"
"cluster <*FINSEQ-1K10 x*> as-term-is trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K10 x*> be trivialZFMISC-1V1"
     sorry
qed "sorry"

mtheorem finseq_5_cl_2:
  mlet "x be objectHIDDENM1", "y be objectHIDDENM1"
"cluster <*FINSEQ-1K11 x,y *> as-term-is  non trivialZFMISC-1V1"
proof
(*coherence*)
  show "<*FINSEQ-1K11 x,y *> be  non trivialZFMISC-1V1"
  proof-
    have " not <*FINSEQ-1K11 x,y *> be trivialSUBSET-1V2"
    proof-
      have "lenFINSEQ-1K4 (<*FINSEQ-1K11 x,y *>) =XBOOLE-0R4 \<two>\<^sub>M"
        using finseq_1_th_44 sorry
      thus " not <*FINSEQ-1K11 x,y *> be trivialSUBSET-1V2"
        using nat_d_th_60 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_5_cl_3:
"cluster one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (VarFor1 be one-to-oneFUNCT-1V2 &  not VarFor1 be emptyXBOOLE-0V1))"
    proof-
      let ?f = "<*FINSEQ-1K10 {}XBOOLE-0K1*>"
      have "?f be one-to-oneFUNCT-1V2"
        using finseq_3_th_93 sorry
      thus " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (VarFor1 be one-to-oneFUNCT-1V2 &  not VarFor1 be emptyXBOOLE-0V1))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_5_th_6:
" for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
proof(rule ballI,rule conjMI)
  fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
  have A1: "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M"
    using nat_1_th_14 sorry
  thus "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
    using finseq_3_th_25 sorry
  show "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
    using A1 finseq_3_th_25 sorry
qed "sorry"

mtheorem finseq_5_th_7:
" for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1 holds  ex i be NatNAT-1M1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
  using nat_1_th_6 sorry

mtheorem finseq_5_th_8:
" for x be objectHIDDENM1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f) =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
proof-
  have " for x be objectHIDDENM1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have "lenFINSEQ-1K4 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f) =HIDDENR1 lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) +NAT-1K1 lenFINSEQ-1K4 f"
      using finseq_1_th_22 sorry
    also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
      using finseq_1_th_39 sorry
    finally show "lenFINSEQ-1K4 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 f) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_9:
" for f be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds  for q be setHIDDENM2 holds (p inTARSKIR2 rngFUNCT-1K2 f & q inTARSKIR2 rngFUNCT-1K2 f) & p ..FINSEQ-4K4 f =XBOOLE-0R4 q ..FINSEQ-4K4 f implies p =XBOOLE-0R4 q"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for p be setHIDDENM2 holds  for q be setHIDDENM2 holds p inTARSKIR2 rngFUNCT-1K2 f & q inTARSKIR2 rngFUNCT-1K2 f implies (p ..FINSEQ-4K4 f =XBOOLE-0R4 q ..FINSEQ-4K4 f implies p =HIDDENR1 q)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI,rule impI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix p assume [ty]: "p be setHIDDENM2"
    fix q assume [ty]: "q be setHIDDENM2"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "q inTARSKIR2 rngFUNCT-1K2 f"
    assume "p ..FINSEQ-4K4 f =XBOOLE-0R4 q ..FINSEQ-4K4 f"
    then have "p =HIDDENR1 f .FUNCT-1K1 (q ..FINSEQ-4K4 f)"
      using A1 finseq_4_th_19 sorry
    also have "... = q"
      using A2 finseq_4_th_19 sorry
    finally show "p =HIDDENR1 q"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_10:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & g =FUNCT-1R1 f  |RELAT-1K8 SegFINSEQ-1K2 n implies f  |RELAT-1K8 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 g ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
proof-
  have " for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & g =FUNCT-1R1 f  |RELAT-1K8 SegFINSEQ-1K2 n implies f  |RELAT-1K8 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 g ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    assume A1: "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      and A2: "g =FUNCT-1R1 f  |RELAT-1K8 SegFINSEQ-1K2 n"
    obtain h where 
      [ty]:"h be FinSequenceFINSEQ-1M1" and hDef:"h = f  |RELAT-1K8 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_15 sorry
    have "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_3_th_25 sorry
    then have A3: "lenFINSEQ-1K4 h =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using finseq_1_th_17 sorry
    have "SegFINSEQ-1K2 n c=TARSKIR1 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_1_th_5 nat_1_th_11 sorry
    then have "h .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) & g =FUNCT-1R1 h  |RELAT-1K8 SegFINSEQ-1K2 n"
      using A2 finseq_1_th_4 funct_1_th_49 funct_1_th_51 sorry
    thus "f  |RELAT-1K8 SegFINSEQ-1K2 (n +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 g ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)*>)"
      using A3 finseq_3_th_55 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_11:
" for i be NatNAT-1M1 holds  for f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies (f .FUNCT-1K1 i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
proof-
  have " for i be NatNAT-1M1 holds  for f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies (f .FUNCT-1K1 i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 f"
    then have "f .FUNCT-1K1 i inTARSKIR2 rngFUNCT-1K2 f"
      using funct_1_def_3 sorry
    then have A2: "f just-once-valuesFINSEQ-4R2 f .FUNCT-1K1 i"
      using finseq_4_th_8 sorry
    then have "f <-FINSEQ-4K1 (f .FUNCT-1K1 i) =XBOOLE-0R4 (f .FUNCT-1K1 i)..FINSEQ-4K4 f"
      using finseq_4_th_25 sorry
    thus "(f .FUNCT-1K1 i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
      using A1 A2 finseq_4_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f, g for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_cl_4:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
"cluster one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1 for FinSequenceFINSEQ-1M3-of D"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M3-of D st it be one-to-oneFUNCT-1V2\<bar> non emptyXBOOLE-0V1"
  proof-
    have " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not (VarFor1 be one-to-oneFUNCT-1V2 &  not VarFor1 be emptyXBOOLE-0V1))"
    proof-
      let ?x = "the ElementSUBSET-1M1-of D"
      let ?f = "<*FINSEQ-1K13\<^bsub>(D)\<^esub> ?x*>"
      have "?f be one-to-oneFUNCT-1V2"
        using finseq_3_th_93 sorry
      thus " not ( for VarFor1 be FinSequenceFINSEQ-1M3-of D holds  not (VarFor1 be one-to-oneFUNCT-1V2 &  not VarFor1 be emptyXBOOLE-0V1))"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_5_th_12:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 g & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> i) implies f =FINSEQ-1R1 g"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 g & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> i) implies f =FINSEQ-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of D"
    assume A1: "domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 g"
      and A2: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
    have " for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 k =HIDDENR1 g .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "k inTARSKIR2 domFINSEQ-1K5 f"
      then have "f .FUNCT-1K1 k =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
        using partfun1_def_6 sorry
      also have "... = g /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
        using A2 A3 sorry
      also have "... = g .FUNCT-1K1 k"
        using A1 A3 partfun1_def_6 sorry
      finally show "f .FUNCT-1K1 k =HIDDENR1 g .FUNCT-1K1 k"
         sorry
    qed "sorry"
    thus "f =FINSEQ-1R1 g"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_13:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies f =FINSEQ-1R1 g"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> k) implies f =FINSEQ-1R1 g"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M3-of D"
    assume A1: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g"
      and A2: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> k =XBOOLE-0R4 g /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
    have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f implies f .FUNCT-1K1 k =HIDDENR1 g .FUNCT-1K1 k"
    proof(rule ballI,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A3: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      then have "f .FUNCT-1K1 k =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
        using finseq_4_th_15 sorry
      also have "... = g /.PARTFUN1K7\<^bsub>(D)\<^esub> k"
        using A2 A3 sorry
      also have "... = g .FUNCT-1K1 k"
        using A1 A3 finseq_4_th_15 sorry
      finally show "f .FUNCT-1K1 k =HIDDENR1 g .FUNCT-1K1 k"
         sorry
    qed "sorry"
    thus "f =FINSEQ-1R1 g"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_14:
" for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f =XBOOLE-0R4 \<one>\<^sub>M implies f =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
  using finseq_1_th_40 sorry

mtheorem finseq_5_th_15:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
proof(rule ballI,rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
  have "lenFINSEQ-1K4 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f) =XBOOLE-0R4 \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 f"
    using finseq_5_th_8 sorry
  then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)"
    using nat_1_th_11 sorry
  then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)"
    using finseq_3_th_25 sorry
  then have "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f).FUNCT-1K1 \<one>\<^sub>M"
    using partfun1_def_6 sorry
  thus "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
    using finseq_1_th_41 sorry
qed "sorry"

mlemma finseq_5_lm_1:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for g be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f ^FINSEQ-1K9\<^bsub>(D)\<^esub> g).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
  using finseq_1_def_7 sorry

mtheorem finseq_5_th_16:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  have "i <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
    using finseq_1_th_59 sorry
  thus "lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using finseq_1_th_58 sorry
qed "sorry"

mtheorem finseq_5_th_17:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 i"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  have "i <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
    using finseq_1_th_59 sorry
  thus "lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) <=XXREAL-0R1 i"
    using finseq_1_th_58 sorry
qed "sorry"

mtheorem finseq_5_th_18:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds domFINSEQ-1K5 (f  |FINSEQ-1K17 i) c=TARSKIR1 domFINSEQ-1K5 f"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  have "f  |FINSEQ-1K17 i c=RELAT-1R2 f"
    using relat_1_th_59 sorry
  thus "domFINSEQ-1K5 (f  |FINSEQ-1K17 i) c=TARSKIR1 domFINSEQ-1K5 f"
    using relat_1_th_11 sorry
qed "sorry"

mtheorem finseq_5_th_19:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds rngFUNCT-1K2 (f  |FINSEQ-1K17 i) c=TARSKIR1 rngFUNCT-1K2 f"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  have "f  |FINSEQ-1K17 i c=RELAT-1R2 f"
    using relat_1_th_59 sorry
  thus "rngFUNCT-1K2 (f  |FINSEQ-1K17 i) c=TARSKIR1 rngFUNCT-1K2 f"
    using relat_1_th_11 sorry
qed "sorry"

mtheorem finseq_5_th_20:
" for f be FinSequenceFINSEQ-1M1 holds f be  non emptyXBOOLE-0V1 implies f  |FINSEQ-1K17 \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
proof(rule ballI,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  assume "f be  non emptyXBOOLE-0V1"
  then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
    using finseq_5_th_6 sorry
  then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using finseq_3_th_25 sorry
  then have A1: "lenFINSEQ-1K4 (f  |FINSEQ-1K17 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_59 sorry
  have "(f  |RELAT-1K8 SegFINSEQ-1K2 \<one>\<^sub>M).FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
    using finseq_1_th_1 funct_1_th_49 sorry
  thus "f  |FINSEQ-1K17 \<one>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
    using A1 finseq_1_th_40 sorry
qed "sorry"

mtheorem finseq_5_th_21:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
    then have "f be  non emptyXBOOLE-0V1"
       sorry
    then have A2: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_5_th_6 sorry
    have "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M)"
      using A1 finseq_1_def_3 sorry
    then have "f =HIDDENR1 f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (i +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)*>)"
      using A2 finseq_5_th_10 sorry
    also have "... = f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
      using A1 A2 partfun1_def_6 sorry
    finally show "f =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f*>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_5_lm_2:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) & (m inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> m) implies n =XBOOLE-0R4 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      have A2: "domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) c=TARSKIR1 domFINSEQ-1K5 f"
        using finseq_5_th_18 sorry
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume A3: "n inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
        and A4: "m inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
        and A5: "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> n =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> m"
      have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> n"
        using A3 finseq_4_th_70 sorry
      also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
        using A4 A5 finseq_4_th_70 sorry
      finally have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> n =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> m"
         sorry
      thus "n =XBOOLE-0R4 m"
        using A1 A3 A4 A2 partfun2_th_10 sorry
    qed "sorry"
    thus "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
      using partfun2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_cl_5:
  mlet "i be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
    using finseq_5_lm_2 sorry
qed "sorry"

mtheorem finseq_5_th_22:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f ^FINSEQ-1K8 g) |FINSEQ-1K17 i =FINSEQ-1R1 f  |FINSEQ-1K17 i"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds i <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f ^FINSEQ-1K8 g) |FINSEQ-1K17 i =FINSEQ-1R1 f  |FINSEQ-1K17 i"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    assume A1: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
    then have A2: "lenFINSEQ-1K4 (f  |FINSEQ-1K17 i) =XBOOLE-0R4 i"
      using finseq_1_th_59 sorry
    then have A3: "domFINSEQ-1K5 (f  |FINSEQ-1K17 i) =XBOOLE-0R4 SegFINSEQ-1K2 i"
      using finseq_1_def_3 sorry
    have A4: " for j be NatNAT-1M1 holds j inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K17 i) implies ((f ^FINSEQ-1K8 g) |FINSEQ-1K17 i).FUNCT-1K1 j =HIDDENR1 (f  |FINSEQ-1K17 i).FUNCT-1K1 j"
    proof(rule ballI,rule impI)
      fix j assume [ty]: "j be NatNAT-1M1"
      assume A5: "j inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K17 i)"
      then have "j <=XXREAL-0R1 i"
        using A3 finseq_1_th_1 sorry
      then have A6: "j <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A1 xxreal_0_th_2 sorry
      have "j inTARSKIR2 NATNUMBERSK1 & \<one>\<^sub>M <=XXREAL-0R1 j"
        using A3 A5 finseq_1_th_1 sorry
      then have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
        using A6 sorry
      then have A7: "j inTARSKIR2 domFINSEQ-1K5 f"
        using finseq_1_def_3 sorry
      have "((f ^FINSEQ-1K8 g) |FINSEQ-1K17 i).FUNCT-1K1 j =HIDDENR1 (f ^FINSEQ-1K8 g).FUNCT-1K1 j"
        using A3 A5 funct_1_th_49 sorry
      also have "... = f .FUNCT-1K1 j"
        using A7 finseq_1_def_7 sorry
      also have "... = (f  |FINSEQ-1K17 i).FUNCT-1K1 j"
        using A3 A5 funct_1_th_49 sorry
      finally show "((f ^FINSEQ-1K8 g) |FINSEQ-1K17 i).FUNCT-1K1 j =HIDDENR1 (f  |FINSEQ-1K17 i).FUNCT-1K1 j"
         sorry
    qed "sorry"
    have "i <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
      using A1 nat_1_th_12 sorry
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g)"
      using finseq_1_th_22 sorry
    then have "lenFINSEQ-1K4 ((f ^FINSEQ-1K8 g) |FINSEQ-1K17 i) =XBOOLE-0R4 i"
      using finseq_1_th_59 sorry
    thus "(f ^FINSEQ-1K8 g) |FINSEQ-1K17 i =FINSEQ-1R1 f  |FINSEQ-1K17 i"
      using A2 A4 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_23:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g) |FINSEQ-1K17 lenFINSEQ-1K4 f =FINSEQ-1R1 f"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds f =HIDDENR1 (f ^FINSEQ-1K8 g) |FINSEQ-1K17 lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    have "f =HIDDENR1 f  |FINSEQ-1K17 lenFINSEQ-1K4 f"
      using finseq_2_th_20 sorry
    also have "... = (f ^FINSEQ-1K8 g) |FINSEQ-1K17 lenFINSEQ-1K4 f"
      using finseq_5_th_22 sorry
    finally show "f =HIDDENR1 (f ^FINSEQ-1K8 g) |FINSEQ-1K17 lenFINSEQ-1K4 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_24:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A2: "n =XBOOLE-0R4 p ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"and A3: "f -|FINSEQ-4K5 p =FUNCT-1R1 f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 n"
      using finseq_4_def_5 sorry
    have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f & f .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p"
      using A1 A2 finseq_4_th_19 finseq_4_th_20 sorry
    thus "(f -|FINSEQ-4K5 p)^FINSEQ-1K8 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
      using A2 A3 finseq_5_th_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_25:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    show "lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
    proof-
      have cases: "i <=XXREAL-0R1 lenFINSEQ-1K4 f or lenFINSEQ-1K4 f <XXREAL-0R3 i"
         sorry
      have case1: "i <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
      proof(rule impI)
        assume "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
        then have "lenFINSEQ-1K4 (f /^RFINSEQK1 i) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
          using rfinseq_def_1 sorry
        then have "lenFINSEQ-1K4 (f /^RFINSEQK1 i) +XCMPLX-0K2 i =XBOOLE-0R4 lenFINSEQ-1K4 f"
           sorry
        thus "lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using nat_1_th_11 sorry
      qed
      have case2: "lenFINSEQ-1K4 f <XXREAL-0R3 i implies lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
      proof(rule impI)
        assume "lenFINSEQ-1K4 f <XXREAL-0R3 i"
        then have "f /^RFINSEQK1 i =FINSEQ-1R1 {}XBOOLE-0K1"
          using rfinseq_def_1 sorry
        thus "lenFINSEQ-1K4 (f /^RFINSEQK1 i) <=XXREAL-0R1 lenFINSEQ-1K4 f"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for "setHIDDENM2"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_26:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n)"
    show "n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
    proof-
      have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 f or n >XXREAL-0R4 lenFINSEQ-1K4 f"
         sorry
      have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 f implies n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
      proof(rule impI)
        assume A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have "i <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 n)"
          using A1 finseq_3_th_25 sorry
        then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 n"
          using A2 rfinseq_def_1 sorry
        then have A3: "n +XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using xreal_1_th_19 sorry
        have "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 i +XCMPLX-0K2 n"
          using A1 finseq_3_th_25 nat_1_th_11 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 i +XCMPLX-0K2 n"
          using xxreal_0_th_2 sorry
        thus "n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
          using A3 finseq_3_th_25 sorry
      qed
      have case2: "n >XXREAL-0R4 lenFINSEQ-1K4 f implies n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
      proof(rule impI)
        assume "n >XXREAL-0R4 lenFINSEQ-1K4 f"
        then have "f /^RFINSEQK1 n =FINSEQ-1R1 {}XBOOLE-0K1"
          using rfinseq_def_1 sorry
        thus "n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
          using A1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_27:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds ( for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)) & (i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i))"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds ( for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)) & (i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show AA: " for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n) implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
    proof(rule ballI,rule impI)
      fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
      assume A1: "i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 n)"
      show "(f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
      proof-
        have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 f or n >XXREAL-0R4 lenFINSEQ-1K4 f"
           sorry
        have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
        proof(rule impI)
          assume "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
          thus "(f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
            using A1 rfinseq_def_1 sorry
        qed
        have case2: "n >XXREAL-0R4 lenFINSEQ-1K4 f implies (f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
        proof(rule impI)
          assume "n >XXREAL-0R4 lenFINSEQ-1K4 f"
          then have "f /^RFINSEQK1 n =FINSEQ-1R1 {}XBOOLE-0K1"
            using rfinseq_def_1 sorry
          thus "(f /^RFINSEQK1 n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
            using A1 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    assume B1: "i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
    then have B2: "n +XCMPLX-0K2 i inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_26 sorry
    have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
      using AA B1 sorry
    then have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f .FUNCT-1K1 (n +XCMPLX-0K2 i)"
      using B1 partfun1_def_6 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i)"
      using partfun1_def_6 B2 sorry
    finally have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i)"
       sorry
    thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> n)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (n +XCMPLX-0K2 i)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_28:
" for f be FinSequenceFINSEQ-1M1 holds f /^RFINSEQK1 (0NUMBERSK6) =FINSEQ-1R1 f"
proof(rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  have A1: "0NUMBERSK6 <=XXREAL-0R1 lenFINSEQ-1K4 f"
     sorry
  have A2: " for i be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (0NUMBERSK6)) implies (f /^RFINSEQK1 (0NUMBERSK6)).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 i"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "\<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK1 (0NUMBERSK6))"
    then have "i inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 (0NUMBERSK6))"
      using finseq_3_th_25 sorry
    then have "(f /^RFINSEQK1 (0NUMBERSK6)).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 (i +NAT-1K1 0NUMBERSK6)"
      using A1 rfinseq_def_1 sorry
    also have "... = f .FUNCT-1K1 i"
       sorry
    finally show "(f /^RFINSEQK1 (0NUMBERSK6)).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 i"
       sorry
  qed "sorry"
  have "lenFINSEQ-1K4 (f /^RFINSEQK1 (0NUMBERSK6)) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 0NUMBERSK6"
    using rfinseq_def_1 sorry
  also have "... = lenFINSEQ-1K4 f"
     sorry
  finally have "lenFINSEQ-1K4 (f /^RFINSEQK1 (0NUMBERSK6)) =HIDDENR1 lenFINSEQ-1K4 f"
     sorry
  thus "f /^RFINSEQK1 (0NUMBERSK6) =FINSEQ-1R1 f"
    using A2 sorry
qed "sorry"

reserve D for " non emptyXBOOLE-0V1\<bar>setHIDDENM2"
reserve p for "ElementSUBSET-1M1-of D"
reserve f, g for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_29:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be  non emptyXBOOLE-0V1"
    then have A2: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_6 sorry
    have "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 <*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>"
      using A1 finseq_5_th_20 sorry
    also have "... = <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>"
      using A2 partfun1_def_6 sorry
    finally have "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 <*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>"
       sorry
    thus "f =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using rfinseq_th_8 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_30:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f /^RFINSEQK1 i =FINSEQ-1R1 <*FINSEQ-1K10 f .FUNCT-1K1 lenFINSEQ-1K4 f*>"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f implies f /^RFINSEQK1 i =HIDDENR1 <*FINSEQ-1K10 f .FUNCT-1K1 lenFINSEQ-1K4 f*>"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using nat_1_th_11 sorry
    then have A2: "lenFINSEQ-1K4 (f /^RFINSEQK1 i) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
      using rfinseq_def_1 sorry
    also have "... = \<one>\<^sub>M"
      using A1 sorry
    finally have "lenFINSEQ-1K4 (f /^RFINSEQK1 i) =HIDDENR1 \<one>\<^sub>M"
       sorry
    then have A3: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK1 i)"
      using finseq_3_th_25 sorry
    have "f /^RFINSEQK1 i =HIDDENR1 <*FINSEQ-1K10 (f /^RFINSEQK1 i).FUNCT-1K1 \<one>\<^sub>M*>"
      using A2 finseq_5_th_14 sorry
    also have "... = <*FINSEQ-1K10 f .FUNCT-1K1 lenFINSEQ-1K4 f*>"
      using A1 A3 finseq_5_th_27 sorry
    finally show "f /^RFINSEQK1 i =HIDDENR1 <*FINSEQ-1K10 f .FUNCT-1K1 lenFINSEQ-1K4 f*>"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_31:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i & i inTARSKIR2 domFINSEQ-1K5 f implies (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> j"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i & i inTARSKIR2 domFINSEQ-1K5 f implies (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> j"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "j +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 i"
      and A2: "i inTARSKIR2 domFINSEQ-1K5 f"
    let ?g = "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
    have A3: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 finseq_3_th_25 sorry
    have "j <=XXREAL-0R1 i"
      using A1 nat_1_th_11 sorry
    then have A4: "j <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A3 xxreal_0_th_2 sorry
    have A5: "lenFINSEQ-1K4 ?g =XBOOLE-0R4 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) +NAT-1K1 \<one>\<^sub>M"
      using finseq_5_th_8 sorry
    then have A6: "lenFINSEQ-1K4 ?g =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
      using A3 rfinseq_def_1 sorry
    also have "... = lenFINSEQ-1K4 f -XCMPLX-0K6 j"
      using A1 sorry
    also have "... = lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j)"
      using A4 rfinseq_def_1 sorry
    finally have "lenFINSEQ-1K4 ?g =HIDDENR1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j)"
       sorry
    have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 ?g implies ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
    proof(rule ballI,rule impMI ,rule impI)
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A7: "\<one>\<^sub>M <=XXREAL-0R1 k"
        and A8: "k <=XXREAL-0R1 lenFINSEQ-1K4 ?g"
      have A9: "k inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j)"
        using A6 A7 A8 finseq_3_th_25 sorry
      show "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
      proof-
        have cases: "k =XBOOLE-0R4 \<one>\<^sub>M or k <>HIDDENR2 \<one>\<^sub>M"
           sorry
        have case1: "k =XBOOLE-0R4 \<one>\<^sub>M implies ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
        proof(rule impI)
          assume A10: "k =XBOOLE-0R4 \<one>\<^sub>M"
          then have "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
            using finseq_1_th_41 sorry
          also have "... = f .FUNCT-1K1 i"
            using A2 partfun1_def_6 sorry
          also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
            using A1 A4 A9 A10 rfinseq_def_1 sorry
          finally show "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
             sorry
        qed
        have case2: "k <>HIDDENR2 \<one>\<^sub>M implies ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
        proof(rule impI)
          assume "k <>HIDDENR2 \<one>\<^sub>M"
          then have A11: "\<one>\<^sub>M <XXREAL-0R3 k"
            using A7 xxreal_0_th_1 sorry
          obtain k9 where 
            [ty]:"k9 be ElementSUBSET-1M1-of NATNUMBERSK1" and k9Def:"k9 = k -XCMPLX-0K6 \<one>\<^sub>M"
            using A7 int_1_th_5 sorry
          have A12: "k9 <=XXREAL-0R1 lenFINSEQ-1K4 ?g -XCMPLX-0K6 \<one>\<^sub>M"
            using A8 xreal_1_th_9 sorry
          have "k9 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 k"
             sorry
          then have "\<one>\<^sub>M <=XXREAL-0R1 k9"
            using A11 nat_1_th_13 sorry
          then have A13: "k9 inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
            using A5 A12 finseq_3_th_25 sorry
          have "lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>) =XBOOLE-0R4 \<one>\<^sub>M"
            using finseq_1_th_39 sorry
          then have "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 k9"
            using A8 A11 finseq_1_th_24 sorry
          also have "... = f .FUNCT-1K1 (k9 +XCMPLX-0K2 i)"
            using A3 A13 rfinseq_def_1 sorry
          also have "... = f .FUNCT-1K1 (k +XCMPLX-0K2 j)"
            using A1 sorry
          also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
            using A4 A9 rfinseq_def_1 sorry
          finally show "((<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> j).FUNCT-1K1 k"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed "sorry"
    thus "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> i*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> j"
      using A6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_32:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f <=XXREAL-0R1 i implies f /^RFINSEQK1 i be emptyXBOOLE-0V1"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f <=XXREAL-0R1 i implies f /^RFINSEQK1 i be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "lenFINSEQ-1K4 f <=XXREAL-0R1 i"
    show "f /^RFINSEQK1 i be emptyXBOOLE-0V1"
    proof-
      have cases: "lenFINSEQ-1K4 f =XBOOLE-0R4 i or lenFINSEQ-1K4 f <>HIDDENR2 i"
         sorry
      have case1: "lenFINSEQ-1K4 f =XBOOLE-0R4 i implies f /^RFINSEQK1 i be emptyXBOOLE-0V1"
      proof(rule impI)
        assume "lenFINSEQ-1K4 f =XBOOLE-0R4 i"
        then have "lenFINSEQ-1K4 (f /^RFINSEQK1 i) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 lenFINSEQ-1K4 f"
          using rfinseq_def_1 sorry
        also have "... = 0NUMBERSK6"
           sorry
        finally have "lenFINSEQ-1K4 (f /^RFINSEQK1 i) =HIDDENR1 0NUMBERSK6"
           sorry
        thus "f /^RFINSEQK1 i be emptyXBOOLE-0V1"
           sorry
      qed
      have case2: "lenFINSEQ-1K4 f <>HIDDENR2 i implies f /^RFINSEQK1 i be emptyXBOOLE-0V1"
      proof(rule impI)
        assume "lenFINSEQ-1K4 f <>HIDDENR2 i"
        then have "lenFINSEQ-1K4 f <XXREAL-0R3 i"
          using A1 xxreal_0_th_1 sorry
        thus "f /^RFINSEQK1 i be emptyXBOOLE-0V1"
          using rfinseq_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_33:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (f /^RFINSEQK1 n) c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds rngFUNCT-1K2 (f /^RFINSEQK1 n) c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have " for p be objectHIDDENM1 holds p inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK1 n) implies p inHIDDENR3 rngFUNCT-1K2 f"
    proof(rule ballI,rule impI)
      fix p assume [ty]: "p be objectHIDDENM1"
      assume "p inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK1 n)"
      then obtain j where
        [ty]:"j be objectHIDDENM1" and 
        A1: "j inHIDDENR3 domFINSEQ-1K5 (f /^RFINSEQK1 n)"and A2: "(f /^RFINSEQK1 n).FUNCT-1K1 j =HIDDENR1 p"
        using funct_1_def_3 sorry
      obtain jj where 
        [ty]:"jj be NatNAT-1M1" and jjDef:"jj = j"
        using A1 sorry
      have "jj +XCMPLX-0K2 n inTARSKIR2 domFINSEQ-1K5 f"
        using A1 finseq_5_th_26 sorry
      then have "f .FUNCT-1K1 (jj +XCMPLX-0K2 n) inTARSKIR2 rngFUNCT-1K2 f"
        using funct_1_def_3 sorry
      thus "p inHIDDENR3 rngFUNCT-1K2 f"
        using A1 A2 finseq_5_th_27 sorry
    qed "sorry"
    thus "rngFUNCT-1K2 (f /^RFINSEQK1 n) c=TARSKIR1 rngFUNCT-1K2 f"
      using tarski_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma finseq_5_lm_3:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 implies f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have " for n be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds n inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) & (m inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i) & (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 n =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 m) implies n =XBOOLE-0R4 m"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of NATNUMBERSK1"
      fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
      assume A2: "n inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
        and A3: "m inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
        and A4: "(f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 n =XBOOLE-0R4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 m"
      have A5: "i +NAT-1K1 n inTARSKIR2 domFINSEQ-1K5 f & i +NAT-1K1 m inTARSKIR2 domFINSEQ-1K5 f"
        using A2 A3 finseq_5_th_26 sorry
      have "f .FUNCT-1K1 (i +NAT-1K1 n) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> i).FUNCT-1K1 n"
        using A2 finseq_5_th_27 sorry
      also have "... = f .FUNCT-1K1 (i +NAT-1K1 m)"
        using A3 A4 finseq_5_th_27 sorry
      finally have "f .FUNCT-1K1 (i +NAT-1K1 n) =HIDDENR1 f .FUNCT-1K1 (i +NAT-1K1 m)"
         sorry
      then have "i +NAT-1K1 n =XBOOLE-0R4 i +NAT-1K1 m"
        using A1 A5 sorry
      thus "n =XBOOLE-0R4 m"
         sorry
    qed "sorry"
    thus "f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_cl_6:
  mlet "i be NatNAT-1M1", "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f /^RFINSEQK2\<^bsub>(D)\<^esub> i as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f /^RFINSEQK2\<^bsub>(D)\<^esub> i be one-to-oneFUNCT-1V2"
    using finseq_5_lm_3 sorry
qed "sorry"

mtheorem finseq_5_th_34:
" for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds f be one-to-oneFUNCT-1V2 implies rngFUNCT-1K2 (f  |FINSEQ-1K17 n) missesXBOOLE-0R1 rngFUNCT-1K2 (f /^RFINSEQK1 n)"
proof-
  have " for n be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds f be one-to-oneFUNCT-1V2 implies (rngFUNCT-1K2 (f  |FINSEQ-1K17 n) meetsXBOOLE-0R5 rngFUNCT-1K2 (f /^RFINSEQK1 n) implies  False )"
  proof(rule ballI,rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    assume A1: "f be one-to-oneFUNCT-1V2"
    have A2: "domFINSEQ-1K5 (f  |FINSEQ-1K17 n) c=TARSKIR1 domFINSEQ-1K5 f"
      using finseq_5_th_18 sorry
    assume "rngFUNCT-1K2 (f  |FINSEQ-1K17 n) meetsXBOOLE-0R5 rngFUNCT-1K2 (f /^RFINSEQK1 n)"
    then obtain x where
      [ty]:"x be objectHIDDENM1" and 
      A3: "x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K17 n)"and A4: "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK1 n)"
      using xboole_0_th_3 sorry
    obtain i where
      [ty]:"i be objectHIDDENM1" and 
      A5: "i inHIDDENR3 domFINSEQ-1K5 (f  |FINSEQ-1K17 n)"and A6: "(f  |FINSEQ-1K17 n).FUNCT-1K1 i =HIDDENR1 x"
      using A3 funct_1_def_3 sorry
    obtain j where
      [ty]:"j be objectHIDDENM1" and 
      A7: "j inHIDDENR3 domFINSEQ-1K5 (f /^RFINSEQK1 n)"and A8: "(f /^RFINSEQK1 n).FUNCT-1K1 j =HIDDENR1 x"
      using A4 funct_1_def_3 sorry
    obtain ii jj where 
      [ty]:"ii be NatNAT-1M1" and iiDef:"ii = i" and
      [ty]:"jj be NatNAT-1M1" and jjDef:"jj = j"
      using A7 A5 sorry
    have A9: "jj +XCMPLX-0K2 n inTARSKIR2 domFINSEQ-1K5 f"
      using A7 finseq_5_th_26 sorry
    have A10: "ii =XBOOLE-0R4 jj +XCMPLX-0K2 n implies  False "
    proof(rule impI)
      have "ii <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K17 n) & lenFINSEQ-1K4 (f  |FINSEQ-1K17 n) <=XXREAL-0R1 n"
        using A5 finseq_5_th_17 finseq_3_th_25 sorry
      then have A11: "ii <=XXREAL-0R1 n"
        using xxreal_0_th_2 sorry
      assume A12: "ii =XBOOLE-0R4 jj +XCMPLX-0K2 n"
      then have "n <=XXREAL-0R1 ii"
        using nat_1_th_11 sorry
      then have "i =HIDDENR1 n"
        using A11 xxreal_0_th_1 sorry
      then have "j =HIDDENR1 0NUMBERSK6"
        using A12 sorry
      thus " False "
        using A7 finseq_3_th_25 sorry
    qed
    have "f .FUNCT-1K1 (jj +XCMPLX-0K2 n) =HIDDENR1 (f /^RFINSEQK1 n).FUNCT-1K1 j"
      using A7 finseq_5_th_27 sorry
    also have "... = f .FUNCT-1K1 i"
      using A5 funct_1_th_47 A6 A8 sorry
    finally have "f .FUNCT-1K1 (jj +XCMPLX-0K2 n) =HIDDENR1 f .FUNCT-1K1 i"
       sorry
    thus " False "
      using A1 A5 A2 A9 A10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_35:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f  |--FINSEQ-4K6 p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f  |--FINSEQ-4K6 p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have A2: "lenFINSEQ-1K4 (f  |--FINSEQ-4K6 p) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using finseq_4_def_6 sorry
    have A3: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    then have A4: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using rfinseq_def_1 sorry
    have A5: "SegFINSEQ-1K2 (lenFINSEQ-1K4 (f  |--FINSEQ-4K6 p)) =XBOOLE-0R4 domFINSEQ-1K5 (f  |--FINSEQ-4K6 p) & SegFINSEQ-1K2 (lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)) =XBOOLE-0R4 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
      using finseq_1_def_3 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f  |--FINSEQ-4K6 p) implies (f  |--FINSEQ-4K6 p).FUNCT-1K1 i =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f).FUNCT-1K1 i"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      assume A6: "i inTARSKIR2 domFINSEQ-1K5 (f  |--FINSEQ-4K6 p)"
      then have "(f  |--FINSEQ-4K6 p).FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 (i +NAT-1K1 p ..FINSEQ-4K4 f)"
        using A1 finseq_4_def_6 sorry
      also have "... = (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f).FUNCT-1K1 i"
        using A2 A3 A4 A5 A6 rfinseq_def_1 sorry
      finally show "(f  |--FINSEQ-4K6 p).FUNCT-1K1 i =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f).FUNCT-1K1 i"
         sorry
    qed "sorry"
    thus "f  |--FINSEQ-4K6 p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f"
      using A2 A4 finseq_2_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_36:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
  proof(rule ballI,rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    have A1: "lenFINSEQ-1K4 (f ^FINSEQ-1K8 g) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
      using finseq_1_th_22 sorry
    show "(f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
    proof-
      have cases: "i <=XXREAL-0R1 lenFINSEQ-1K4 g or i >XXREAL-0R4 lenFINSEQ-1K4 g"
         sorry
      have case1: "i <=XXREAL-0R1 lenFINSEQ-1K4 g implies (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
      proof(rule impI)
        assume A2: "i <=XXREAL-0R1 lenFINSEQ-1K4 g"
        then have "lenFINSEQ-1K4 f +XCMPLX-0K2 i <=XXREAL-0R1 lenFINSEQ-1K4 f +NAT-1K1 lenFINSEQ-1K4 g"
          using xreal_1_th_6 sorry
        then have A3: "lenFINSEQ-1K4 ((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)) =HIDDENR1 (lenFINSEQ-1K4 g +NAT-1K1 lenFINSEQ-1K4 f)-XCMPLX-0K6 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)"
          using A1 rfinseq_def_1 sorry
        also have "... = lenFINSEQ-1K4 g -XCMPLX-0K6 i"
           sorry
        also have "... = lenFINSEQ-1K4 (g /^RFINSEQK1 i)"
          using A2 rfinseq_def_1 sorry
        finally have "lenFINSEQ-1K4 ((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)) =HIDDENR1 lenFINSEQ-1K4 (g /^RFINSEQK1 i)"
           sorry
        have " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (g /^RFINSEQK1 i) implies ((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (g /^RFINSEQK1 i).FUNCT-1K1 k"
        proof(rule ballI,rule impI)
          fix k assume [ty]: "k be NatNAT-1M1"
          assume A4: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (g /^RFINSEQK1 i)"
          then have A5: "k inTARSKIR2 domFINSEQ-1K5 (g /^RFINSEQK1 i)"
            using finseq_3_th_25 sorry
          then have A6: "i +XCMPLX-0K2 k inTARSKIR2 domFINSEQ-1K5 g"
            using finseq_5_th_26 sorry
          have "k inTARSKIR2 domFINSEQ-1K5 ((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i))"
            using A3 A4 finseq_3_th_25 sorry
          then have "((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (f ^FINSEQ-1K8 g).FUNCT-1K1 ((lenFINSEQ-1K4 f +XCMPLX-0K2 i)+XCMPLX-0K2 k)"
            using finseq_5_th_27 sorry
          also have "... = (f ^FINSEQ-1K8 g).FUNCT-1K1 (lenFINSEQ-1K4 f +XCMPLX-0K2 (i +XCMPLX-0K2 k))"
             sorry
          also have "... = g .FUNCT-1K1 (i +XCMPLX-0K2 k)"
            using A6 finseq_1_def_7 sorry
          also have "... = (g /^RFINSEQK1 i).FUNCT-1K1 k"
            using A5 finseq_5_th_27 sorry
          finally show "((f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)).FUNCT-1K1 k =HIDDENR1 (g /^RFINSEQK1 i).FUNCT-1K1 k"
             sorry
        qed "sorry"
        thus "(f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =FINSEQ-1R1 g /^RFINSEQK1 i"
          using A3 sorry
      qed
      have case2: "i >XXREAL-0R4 lenFINSEQ-1K4 g implies (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =HIDDENR1 g /^RFINSEQK1 i"
      proof(rule impI)
        assume A7: "i >XXREAL-0R4 lenFINSEQ-1K4 g"
        then have "lenFINSEQ-1K4 f +XCMPLX-0K2 i >XXREAL-0R4 lenFINSEQ-1K4 (f ^FINSEQ-1K8 g)"
          using A1 xreal_1_th_6 sorry
        then have "(f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =HIDDENR1 {}XBOOLE-0K1"
          using rfinseq_def_1 sorry
        also have "... = g /^RFINSEQK1 i"
          using A7 rfinseq_def_1 sorry
        finally show "(f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +XCMPLX-0K2 i) =HIDDENR1 g /^RFINSEQK1 i"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_37:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 lenFINSEQ-1K4 f =FINSEQ-1R1 g"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds (f ^FINSEQ-1K8 g)/^RFINSEQK1 lenFINSEQ-1K4 f =HIDDENR1 g"
  proof(rule ballI,rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
    have "(f ^FINSEQ-1K8 g)/^RFINSEQK1 lenFINSEQ-1K4 f =HIDDENR1 (f ^FINSEQ-1K8 g)/^RFINSEQK1 (lenFINSEQ-1K4 f +NAT-1K1 0NUMBERSK6)"
       sorry
    also have "... = g /^RFINSEQK1 (0NUMBERSK6)"
      using finseq_5_th_36 sorry
    also have "... = g"
      using finseq_5_th_28 sorry
    finally show "(f ^FINSEQ-1K8 g)/^RFINSEQK1 lenFINSEQ-1K4 f =HIDDENR1 g"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_38:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f & f .FUNCT-1K1 (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
      using finseq_4_th_19 finseq_4_th_20 sorry
    thus "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
      using partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_39:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f <=XXREAL-0R1 i"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f <=XXREAL-0R1 i"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    let ?p = "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
    have A1: "?p ..FINSEQ-4K4 f =XBOOLE-0R4 SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}) .FUNCT-1K1 \<one>\<^sub>M"
      using finseq_4_def_4 sorry
    have "f \<inverse>FUNCT-1K6 {TARSKIK1 ?p} c=TARSKIR1 domFINSEQ-1K5 f"
      using relat_1_th_132 sorry
    then have A2: "f \<inverse>FUNCT-1K6 {TARSKIK1 ?p} c=TARSKIR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using finseq_1_def_3 sorry
    assume A3: "i inTARSKIR2 domFINSEQ-1K5 f"
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f .FUNCT-1K1 i"
      using partfun1_def_6 sorry
    then have "f .FUNCT-1K1 i inTARSKIR2 {TARSKIK1 ?p}"
      using tarski_def_1 sorry
    then have "i inTARSKIR2 f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}"
      using A3 funct_1_def_7 sorry
    then have "i inTARSKIR2 rngFUNCT-1K2 (SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}))"
      using A2 finseq_1_def_13 sorry
    then obtain l where
      [ty]:"l be objectHIDDENM1" and 
      A4: "l inHIDDENR3 domFINSEQ-1K5 (SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}))"and A5: "SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}) .FUNCT-1K1 l =XBOOLE-0R4 i"
      using funct_1_def_3 sorry
    have 
      [ty]:"l be ElementSUBSET-1M1-of NATNUMBERSK1"
      using A4 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 l & l <=XXREAL-0R1 lenFINSEQ-1K4 (SgmFINSEQ-1K15 (f \<inverse>FUNCT-1K6 {TARSKIK1 ?p}))"
      using A4 finseq_3_th_25 sorry
    thus "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f <=XXREAL-0R1 i"
      using A1 A2 A5 finseq_3_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_40:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) implies p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) implies p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) c=TARSKIR1 domFINSEQ-1K5 f"
      using finseq_5_th_18 sorry
    assume A2: "p inTARSKIR2 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
    then have A3: "p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      using finseq_4_th_20 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)) =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i))"
      using finseq_4_th_70 sorry
    also have "... = p"
      using A2 finseq_5_th_38 sorry
    finally have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)) =HIDDENR1 p"
       sorry
    then have A4: "p ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      using A3 A1 finseq_5_th_39 sorry
    have "p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      using A2 finseq_4_th_21 sorry
    then have A5: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      using A4 xxreal_0_th_2 sorry
    have A6: "rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) c=TARSKIR1 rngFUNCT-1K2 f"
      using finseq_5_th_19 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A2 finseq_4_th_21 sorry
    then have A7: "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)"
      using A5 finseq_3_th_25 sorry
    then have "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
      using finseq_4_th_70 sorry
    also have "... = p"
      using A2 A6 finseq_5_th_38 sorry
    finally have "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =HIDDENR1 p"
       sorry
    then have "p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A7 finseq_5_th_39 sorry
    thus "p ..FINSEQ-4K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using A4 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_41:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f & f be one-to-oneFUNCT-1V2 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds i inTARSKIR2 domFINSEQ-1K5 f implies (f be one-to-oneFUNCT-1V2 implies (f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f =XBOOLE-0R4 i)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 f"
    assume "f be one-to-oneFUNCT-1V2"
    then have "(f .FUNCT-1K1 i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
      using A1 finseq_5_th_11 sorry
    thus "(f /.PARTFUN1K7\<^bsub>(D)\<^esub> i)..FINSEQ-4K4 f =XBOOLE-0R4 i"
      using A1 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_5_def_1 (" _ -:FINSEQ-5K1\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be setHIDDENM2"
"func f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
proof-
  (*coherence*)
    show "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_42:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_4_th_20 sorry
    then have "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using finseq_3_th_25 sorry
    thus "lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 p ..FINSEQ-4K4 f"
      using finseq_1_th_59 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_43:
" for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
proof-
  have " for i be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f) implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
    have "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_4_th_20 sorry
    thus "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> i"
      using A2 finseq_4_th_71 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_44:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using finseq_4_th_21 sorry
    then have "\<one>\<^sub>M inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
       sorry
    thus "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A1 finseq_5_th_43 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_45:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =XBOOLE-0R4 p"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =HIDDENR1 p"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have A2: "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_4_th_20 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A1 finseq_4_th_21 sorry
    then have "p ..FINSEQ-4K4 f inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
       sorry
    then have "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)"
      using A1 finseq_5_th_43 sorry
    also have "... = f .FUNCT-1K1 (p ..FINSEQ-4K4 f)"
      using A2 partfun1_def_6 sorry
    also have "... = p"
      using A1 finseq_4_th_19 sorry
    finally show "(f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f) =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_46:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for x be setHIDDENM2 holds (x inTARSKIR2 rngFUNCT-1K2 f & p inTARSKIR2 rngFUNCT-1K2 f) & x ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f implies x inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for x be setHIDDENM2 holds x inTARSKIR2 rngFUNCT-1K2 f & (p inTARSKIR2 rngFUNCT-1K2 f & x ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f) implies x inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix x assume [ty]: "x be setHIDDENM2"
    assume A1: "x inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A3: "x ..FINSEQ-4K4 f <=XXREAL-0R1 p ..FINSEQ-4K4 f"
    let ?g = "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p"
    let ?i = "x ..FINSEQ-4K4 f"
    have "\<one>\<^sub>M <=XXREAL-0R1 ?i"
      using A1 finseq_4_th_21 sorry
    then have A4: "?i inTARSKIR2 SegFINSEQ-1K2 (p ..FINSEQ-4K4 f)"
      using A3 sorry
    have "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?g) =XBOOLE-0R4 domFINSEQ-1K5 ?g"
      using finseq_1_def_3 sorry
    then have A5: "?i inTARSKIR2 domFINSEQ-1K5 ?g"
      using A2 A4 finseq_5_th_42 sorry
    then have "?g .FUNCT-1K1 ?i inTARSKIR2 rngFUNCT-1K2 ?g"
      using funct_1_def_3 sorry
    then have "?g /.PARTFUN1K7\<^bsub>(D)\<^esub> ?i inTARSKIR2 rngFUNCT-1K2 ?g"
      using A5 partfun1_def_6 sorry
    then have A6: "f /.PARTFUN1K7\<^bsub>(D)\<^esub> ?i inTARSKIR2 rngFUNCT-1K2 ?g"
      using A2 A4 finseq_5_th_43 sorry
    have "?i inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_4_th_20 sorry
    then have "f .FUNCT-1K1 ?i inTARSKIR2 rngFUNCT-1K2 ?g"
      using A6 partfun1_def_6 sorry
    thus "x inTARSKIR2 rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using A1 finseq_4_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_47:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be  non emptyXBOOLE-0V1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies  not f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be emptyXBOOLE-0V1"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using finseq_4_th_21 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p)"
      using A1 finseq_5_th_42 sorry
    thus " not f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be emptyXBOOLE-0V1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_48:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
  using finseq_5_th_19 sorry

mtheorem finseq_5_cl_7:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M3-of D"
"cluster f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "f -:FINSEQ-5K1\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2"
     sorry
qed "sorry"

mdef finseq_5_def_2 (" _ :-FINSEQ-5K2\<^bsub>'( _ ')\<^esub>  _ " [164,0,164]164 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D"
"func f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
proof-
  (*coherence*)
    show "(<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_49:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies ( ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i)"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies ( ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f /^RFINSEQK2\<^bsub>(D)\<^esub> tVar1)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then obtain i where 
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and iDef:"i = p ..FINSEQ-4K4 f -XCMPLX-0K6 \<one>\<^sub>M"
      using finseq_4_th_21 int_1_th_5 sorry
    have A2: "p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_4_th_20 sorry
    show " ex tVar1 be ElementSUBSET-1M1-of NATNUMBERSK1 st tVar1 +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f /^RFINSEQK2\<^bsub>(D)\<^esub> tVar1"
    proof(rule bexI[of _ "i"],rule conjMI)
      show A3: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f"
         sorry
      have "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> (p ..FINSEQ-4K4 f)*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> p ..FINSEQ-4K4 f)"
        using A1 finseq_5_th_38 sorry
      also have "... = f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
        using A3 A2 finseq_5_th_31 sorry
      finally show "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =HIDDENR1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
         sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_50:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have A2: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using finseq_4_th_21 sorry
    obtain i where
      [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A3: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f"and A4: "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
      using A1 finseq_5_th_49 sorry
    have "i <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A3 nat_1_th_11 sorry
    then have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 lenFINSEQ-1K4 f -XCMPLX-0K6 i"
      using A4 rfinseq_def_1 sorry
    also have "... = (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
      using A3 sorry
    finally show "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_51:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies j +NAT-1K1 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
proof-
  have " for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies j +NAT-1K1 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix j assume [ty]: "j be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
    have "j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using A2 finseq_3_th_25 sorry
    then have "j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 (lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f)+XCMPLX-0K2 \<one>\<^sub>M"
      using A1 finseq_5_th_50 sorry
    then have "j <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using xreal_1_th_6 sorry
    then have A3: "j +NAT-1K1 p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using xreal_1_th_19 sorry
    have A4: "p ..FINSEQ-4K4 f <=XXREAL-0R1 j +NAT-1K1 p ..FINSEQ-4K4 f"
      using nat_1_th_11 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A1 finseq_4_th_21 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 p ..FINSEQ-4K4 f"
      using A4 xxreal_0_th_2 sorry
    thus "j +NAT-1K1 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using A3 finseq_3_th_25 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_cl_8:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "p be ElementSUBSET-1M1-of D", "f be FinSequenceFINSEQ-1M3-of D"
"cluster f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_5_th_52:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
proof-
  have " for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix j assume [ty]: "j be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "p inTARSKIR2 rngFUNCT-1K2 f"
      and A2: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
    have A3: "j +NAT-1K1 p ..FINSEQ-4K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using A1 A2 finseq_5_th_51 sorry
    let ?i = "j +NAT-1K1 \<one>\<^sub>M"
    have A4: "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A1 finseq_4_th_21 sorry
    obtain k where
      [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A5: "k +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f"and A6: "f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> k"
      using A1 finseq_5_th_49 sorry
    have "k <=XXREAL-0R1 p ..FINSEQ-4K4 f"
      using A5 nat_1_th_11 sorry
    then have A7: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A4 xxreal_0_th_2 sorry
    have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p).FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)"
      using A2 partfun1_def_6 sorry
    also have "... = f .FUNCT-1K1 ((j +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 k)"
      using A2 A6 A7 rfinseq_def_1 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
      using A5 A3 partfun1_def_6 sorry
    finally show "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_53:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 p"
  using finseq_5_th_15 sorry

mtheorem finseq_5_th_54:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) inTARSKIR2 domFINSEQ-1K5 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)"
      using finseq_5_th_6 sorry
    assume A2: "p inTARSKIR2 rngFUNCT-1K2 f"
    then have "p ..FINSEQ-4K4 f <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using finseq_4_th_21 sorry
    then obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = lenFINSEQ-1K4 f -XCMPLX-0K6 p ..FINSEQ-4K4 f"
      using int_1_th_5 sorry
    have "lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =XBOOLE-0R4 j +NAT-1K1 \<one>\<^sub>M"
      using A2 finseq_5_th_50 sorry
    then have "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (j +NAT-1K1 p ..FINSEQ-4K4 f)"
      using A2 A1 finseq_5_th_52 sorry
    also have "... = f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
       sorry
    finally show "(f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p)/.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) =HIDDENR1 f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_55:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have " ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
      using finseq_5_th_49 sorry
    thus "rngFUNCT-1K2 (f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p) c=TARSKIR1 rngFUNCT-1K2 f"
      using finseq_5_th_33 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_56:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f & f be one-to-oneFUNCT-1V2 implies f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 f implies  not (f be one-to-oneFUNCT-1V2 &  not f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume "p inTARSKIR2 rngFUNCT-1K2 f"
    then have " ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 p ..FINSEQ-4K4 f & f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p =FINSEQ-1R1 f /^RFINSEQK2\<^bsub>(D)\<^esub> i"
      using finseq_5_th_49 sorry
    thus " not (f be one-to-oneFUNCT-1V2 &  not f :-FINSEQ-5K2\<^bsub>(D)\<^esub> p be one-to-oneFUNCT-1V2)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve i for "NatNAT-1M1"
mdef finseq_5_def_3 ("RevFINSEQ-5K3  _ " [228]228 ) where
  mlet "f be FinSequenceFINSEQ-1M1"
"func RevFINSEQ-5K3 f \<rightarrow> FinSequenceFINSEQ-1M1 means
  \<lambda>it. lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
proof-
  (*existence*)
    show " ex it be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
    proof-
      have " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 VarFor1 &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)))))"
      proof-
        let ?F = "\<lambda>Lamb1. f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 Lamb1)+XCMPLX-0K2 \<one>\<^sub>M)"
        have " ex p be FinSequenceFINSEQ-1M1 st lenFINSEQ-1K4 p =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for k be NatNAT-1M1 holds k inTARSKIR2 domFINSEQ-1K5 p implies p .FUNCT-1K1 k =XBOOLE-0R4 ?F(k))"
          using finseq_1_sch_2 sorry
        thus " not ( for VarFor1 be FinSequenceFINSEQ-1M1 holds  not (lenFINSEQ-1K4 VarFor1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 VarFor1 &  not VarFor1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)))))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be FinSequenceFINSEQ-1M1 holds  for it2 be FinSequenceFINSEQ-1M1 holds (lenFINSEQ-1K4 it1 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it1 implies it1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))) & (lenFINSEQ-1K4 it2 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it2 implies it2 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))) implies it1 =HIDDENR1 it2"
    proof-
      have " for f1 be FinSequenceFINSEQ-1M1 holds  for f2 be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 f1 =XBOOLE-0R4 lenFINSEQ-1K4 f & (( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f1 implies f1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)) & (lenFINSEQ-1K4 f2 =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f2 implies f2 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)))) implies f1 =HIDDENR1 f2"
      proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
        have A1: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
          using finseq_1_def_3 sorry
        fix f1 assume [ty]: "f1 be FinSequenceFINSEQ-1M1"
        fix f2 assume [ty]: "f2 be FinSequenceFINSEQ-1M1"
        assume A2: "lenFINSEQ-1K4 f1 =XBOOLE-0R4 lenFINSEQ-1K4 f"
          and A3: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f1 implies f1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          and A4: "lenFINSEQ-1K4 f2 =XBOOLE-0R4 lenFINSEQ-1K4 f"
          and A5: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f2 implies f2 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
        have A6: "domFINSEQ-1K5 f1 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f1)"
          using finseq_1_def_3 sorry
        have A7: "domFINSEQ-1K5 f2 =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f2)"
          using finseq_1_def_3 sorry
        have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f1 .FUNCT-1K1 i =XBOOLE-0R4 f2 .FUNCT-1K1 i"
        proof(rule ballI,rule impI)
          fix i assume [ty]: "i be NatNAT-1M1"
          assume A8: "i inTARSKIR2 domFINSEQ-1K5 f"
          then have "f1 .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
            using A2 A3 A6 A1 sorry
          thus "f1 .FUNCT-1K1 i =XBOOLE-0R4 f2 .FUNCT-1K1 i"
            using A4 A5 A7 A1 A8 sorry
        qed "sorry"
        thus "f1 =HIDDENR1 f2"
          using A2 A4 A6 A1 finseq_2_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem FINSEQ_5K3_involutiveness:
" for f be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (RevFINSEQ-5K3 f) =HIDDENR1 f"
proof-
  have " for it be FinSequenceFINSEQ-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds it =HIDDENR1 RevFINSEQ-5K3 f implies f =HIDDENR1 RevFINSEQ-5K3 it"
  proof-
    have " for it be FinSequenceFINSEQ-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 it =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 it implies it .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)) implies lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 it & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 i =XBOOLE-0R4 it .FUNCT-1K1 ((lenFINSEQ-1K4 it -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
    proof-
      have " for g be FinSequenceFINSEQ-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 f & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 g implies g .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)) implies lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g & ( for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies f .FUNCT-1K1 i =HIDDENR1 g .FUNCT-1K1 ((lenFINSEQ-1K4 g -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule ballI,rule impI)
        fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
        fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
        assume A9: "lenFINSEQ-1K4 g =XBOOLE-0R4 lenFINSEQ-1K4 f"
          and A10: " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 g implies g .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
        show "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 g"
          using A9 sorry
        fix i assume [ty]: "i be NatNAT-1M1"
        assume A11: "i inTARSKIR2 domFINSEQ-1K5 f"
        then have "i inTARSKIR2 domFINSEQ-1K5 g"
          using A9 finseq_3_th_29 sorry
        then have "i <=XXREAL-0R1 lenFINSEQ-1K4 g"
          using finseq_3_th_25 sorry
        then obtain j where 
          [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = lenFINSEQ-1K4 g -XCMPLX-0K6 i"
          using int_1_th_5 sorry
        have "i >=XXREAL-0R2 \<one>\<^sub>M"
          using A11 finseq_3_th_25 sorry
        then have "j +XCMPLX-0K2 i >=XXREAL-0R2 j +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "j <XXREAL-0R3 lenFINSEQ-1K4 g"
          using nat_1_th_13 sorry
        then have "\<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M & j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 g"
          using nat_1_th_11 nat_1_th_13 sorry
        then have A12: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 g"
          using finseq_3_th_25 sorry
        have "f .FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 (j +NAT-1K1 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M)"
          using A9 sorry
        also have "... = g .FUNCT-1K1 ((lenFINSEQ-1K4 g -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A10 A12 sorry
        finally show "f .FUNCT-1K1 i =HIDDENR1 g .FUNCT-1K1 ((lenFINSEQ-1K4 g -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using finseq_5_def_3 sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_57:
" for f be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (RevFINSEQ-5K3 f) & rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds domFINSEQ-1K5 f =HIDDENR1 domFINSEQ-1K5 (RevFINSEQ-5K3 f) & rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
  proof(rule ballI,rule conjMI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have A1: "domFINSEQ-1K5 f =HIDDENR1 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
      using finseq_1_def_3 sorry
    also have "... = SegFINSEQ-1K2 (lenFINSEQ-1K4 (RevFINSEQ-5K3 f))"
      using finseq_5_def_3 sorry
    also have "... = domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
      using finseq_1_def_3 sorry
    finally show "domFINSEQ-1K5 f =HIDDENR1 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
       sorry
    have A2: "lenFINSEQ-1K4 f =XBOOLE-0R4 lenFINSEQ-1K4 (RevFINSEQ-5K3 f)"
      using finseq_5_def_3 sorry
    have "( for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 rngFUNCT-1K2 (RevFINSEQ-5K3 f)) & rngFUNCT-1K2 (RevFINSEQ-5K3 f) c=TARSKIR1 rngFUNCT-1K2 f"
    proof(rule conjMI)
      show " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 f implies x inHIDDENR3 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 f"
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A3: "i inTARSKIR2 domFINSEQ-1K5 f"and A4: "f .FUNCT-1K1 i =HIDDENR1 x"
          using finseq_2_th_10 sorry
        have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A3 finseq_3_th_25 sorry
        then obtain j where 
          [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = (lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
          using finseq_5_th_1 sorry
        have "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
          using finseq_1_def_3 sorry
        then have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (RevFINSEQ-5K3 f))"
          using A2 A3 finseq_5_th_2 sorry
        then have A5: "j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
          using finseq_1_def_3 sorry
        then have "RevFINSEQ-5K3 f .FUNCT-1K1 j =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
          using finseq_5_def_3 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
          using A4 A5 funct_1_def_3 sorry
      qed "sorry"
      have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (RevFINSEQ-5K3 f) implies x inHIDDENR3 rngFUNCT-1K2 f"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        assume "x inHIDDENR3 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
        then obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A6: "i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"and A7: "RevFINSEQ-5K3 f .FUNCT-1K1 i =HIDDENR1 x"
          using finseq_2_th_10 sorry
        have "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using A2 A6 finseq_3_th_25 sorry
        then obtain j where 
          [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = (lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
          using finseq_5_th_1 sorry
        have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (RevFINSEQ-5K3 f))"
          using A6 finseq_1_def_3 sorry
        then have "j inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (RevFINSEQ-5K3 f))"
          using A2 finseq_5_th_2 sorry
        then have A8: "j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
          using finseq_1_def_3 sorry
        have "RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A6 finseq_5_def_3 sorry
        thus "x inHIDDENR3 rngFUNCT-1K2 f"
          using A1 A7 A8 funct_1_def_3 sorry
      qed "sorry"
      thus "rngFUNCT-1K2 (RevFINSEQ-5K3 f) c=TARSKIR1 rngFUNCT-1K2 f"
        using tarski_def_3 sorry
    qed
    thus "rngFUNCT-1K2 f =XBOOLE-0R4 rngFUNCT-1K2 (RevFINSEQ-5K3 f)"
      using tarski_def_3 xboole_0_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_58:
" for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f implies RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
proof-
  have " for i be NatNAT-1M1 holds  for f be FinSequenceFINSEQ-1M1 holds  not (i inTARSKIR2 domFINSEQ-1K5 f &  not RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    have "domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
      using finseq_5_th_57 sorry
    thus " not (i inTARSKIR2 domFINSEQ-1K5 f &  not RevFINSEQ-5K3 f .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M))"
      using finseq_5_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_59:
" for f be FinSequenceFINSEQ-1M1 holds  for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f & i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M implies j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix i assume [ty]: "i be NatNAT-1M1"
  fix j assume [ty]: "j be NatNAT-1M1"
  assume A1: "i inTARSKIR2 domFINSEQ-1K5 f"
    and A2: "i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
  have A3: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f) & domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
    using finseq_5_th_57 finseq_1_def_3 sorry
  have "j =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
    using A2 sorry
  thus "j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
    using A1 A3 finseq_5_th_2 sorry
qed "sorry"

mtheorem finseq_5_cl_9:
  mlet "f be emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is emptyXBOOLE-0V1"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be emptyXBOOLE-0V1"
  proof-
    have "lenFINSEQ-1K4 ({}XBOOLE-0K1) =XBOOLE-0R4 0NUMBERSK6"
       sorry
    then have "lenFINSEQ-1K4 (RevFINSEQ-5K3 ({}XBOOLE-0K1)) =XBOOLE-0R4 0NUMBERSK6"
      using finseq_5_def_3 sorry
    thus "RevFINSEQ-5K3 f be emptyXBOOLE-0V1"
       sorry
  qed
qed "sorry"

mtheorem finseq_5_th_60:
" for x be objectHIDDENM1 holds RevFINSEQ-5K3 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
proof(rule ballI)
  fix x assume [ty]: "x be objectHIDDENM1"
  let ?f = "<*FINSEQ-1K10 x*>"
  have A1: "lenFINSEQ-1K4 ?f =XBOOLE-0R4 \<one>\<^sub>M"
    using finseq_1_th_39 sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (<*FINSEQ-1K10 x*>) implies (<*FINSEQ-1K10 x*>).FUNCT-1K1 i =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "i inTARSKIR2 domFINSEQ-1K5 ?f"
    then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?f)"
      using finseq_1_def_3 sorry
    then have "i =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 finseq_1_th_2 tarski_def_1 sorry
    thus "(<*FINSEQ-1K10 x*>).FUNCT-1K1 i =XBOOLE-0R4 (<*FINSEQ-1K10 x*>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K10 x*>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
      using finseq_1_th_39 sorry
  qed "sorry"
  thus "RevFINSEQ-5K3 (<*FINSEQ-1K10 x*>) =FINSEQ-1R1 <*FINSEQ-1K10 x*>"
    using finseq_5_def_3 sorry
qed "sorry"

mtheorem finseq_5_th_61:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds RevFINSEQ-5K3 (<*FINSEQ-1K11 x1,x2 *>) =FINSEQ-1R1 <*FINSEQ-1K11 x2,x1 *>"
proof(rule ballI,rule ballI)
  fix x1 assume [ty]: "x1 be objectHIDDENM1"
  fix x2 assume [ty]: "x2 be objectHIDDENM1"
  let ?f = "<*FINSEQ-1K11 x1,x2 *>"
  let ?g = "<*FINSEQ-1K11 x2,x1 *>"
  have A1: "lenFINSEQ-1K4 ?f =XBOOLE-0R4 \<two>\<^sub>M"
    using finseq_1_th_44 sorry
  have A2: "lenFINSEQ-1K4 ?g =XBOOLE-0R4 \<two>\<^sub>M"
    using finseq_1_th_44 sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 ?g implies (<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume "i inTARSKIR2 domFINSEQ-1K5 ?g"
    then have A3: "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?f)"
      using A1 A2 finseq_1_def_3 sorry
    show "(<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
    proof-
      have cases: "i =XBOOLE-0R4 \<one>\<^sub>M or i =XBOOLE-0R4 \<two>\<^sub>M"
        using A1 A3 finseq_1_th_2 tarski_def_2 sorry
      have case1: "i =XBOOLE-0R4 \<one>\<^sub>M implies (<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule impI)
        assume A4: "i =XBOOLE-0R4 \<one>\<^sub>M"
        then have "(<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 x2"
          using finseq_1_th_44 sorry
        also have "... = (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A1 A4 finseq_1_th_44 sorry
        finally show "(<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
      qed
      have case2: "i =XBOOLE-0R4 \<two>\<^sub>M implies (<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
      proof(rule impI)
        assume A5: "i =XBOOLE-0R4 \<two>\<^sub>M"
        then have "(<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 x1"
          using finseq_1_th_44 sorry
        also have "... = (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A1 A5 finseq_1_th_44 sorry
        finally show "(<*FINSEQ-1K11 x2,x1 *>).FUNCT-1K1 i =HIDDENR1 (<*FINSEQ-1K11 x1,x2 *>).FUNCT-1K1 ((lenFINSEQ-1K4 (<*FINSEQ-1K11 x1,x2 *>) -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "RevFINSEQ-5K3 (<*FINSEQ-1K11 x1,x2 *>) =FINSEQ-1R1 <*FINSEQ-1K11 x2,x1 *>"
    using A1 A2 finseq_5_def_3 sorry
qed "sorry"

mtheorem finseq_5_th_62:
" for f be FinSequenceFINSEQ-1M1 holds f .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f & f .FUNCT-1K1 lenFINSEQ-1K4 f =XBOOLE-0R4 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
proof-
  have " for f be FinSequenceFINSEQ-1M1 holds f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f & f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
    show "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f & f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
    proof-
      have cases: "f be emptyXBOOLE-0V1 or f be  non emptyXBOOLE-0V1"
         sorry
      have case1: "f be emptyXBOOLE-0V1 implies f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f & f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
      proof(rule impI,rule conjMI)
        assume A1: "f be emptyXBOOLE-0V1"
        then have "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 {}XBOOLE-0K1"
           sorry
        also have "... = RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f"
          using A1 sorry
        finally show "f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f"
           sorry
        have "f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 {}XBOOLE-0K1"
          using A1 sorry
        also have "... = RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
          using A1 sorry
        finally show "f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M"
           sorry
      qed
      have case2: "f be  non emptyXBOOLE-0V1 implies RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M & RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"
      proof(rule impI,rule conjMI)
        assume A3: "f be  non emptyXBOOLE-0V1"
        then have "lenFINSEQ-1K4 f inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
          using finseq_1_th_3 sorry
        then have "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
          using finseq_1_def_3 sorry
        then have "RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 lenFINSEQ-1K4 f)+XCMPLX-0K2 \<one>\<^sub>M)"
          using finseq_5_th_58 sorry
        also have "... = f .FUNCT-1K1 \<one>\<^sub>M"
           sorry
        finally show "RevFINSEQ-5K3 f .FUNCT-1K1 lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
           sorry
        have "lenFINSEQ-1K4 f >=XXREAL-0R2 \<one>\<^sub>M"
          using A3 nat_1_th_14 sorry
        then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
          using finseq_3_th_25 sorry
        then have "RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
          using finseq_5_th_58 sorry
        also have "... = f .FUNCT-1K1 lenFINSEQ-1K4 f"
           sorry
        finally show "RevFINSEQ-5K3 f .FUNCT-1K1 \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_cl_10:
  mlet "f be one-to-oneFUNCT-1V2\<bar>FinSequenceFINSEQ-1M1"
"cluster RevFINSEQ-5K3 f as-term-is one-to-oneFUNCT-1V2"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be one-to-oneFUNCT-1V2"
  proof-
    let ?g = "RevFINSEQ-5K3 f"
    have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds x1 inHIDDENR3 domFINSEQ-1K5 (RevFINSEQ-5K3 f) & (x2 inHIDDENR3 domFINSEQ-1K5 (RevFINSEQ-5K3 f) & RevFINSEQ-5K3 f .FUNCT-1K1 x1 =XBOOLE-0R4 RevFINSEQ-5K3 f .FUNCT-1K1 x2) implies x1 =HIDDENR1 x2"
    proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      assume A1: "x1 inHIDDENR3 domFINSEQ-1K5 ?g"
        and A2: "x2 inHIDDENR3 domFINSEQ-1K5 ?g"
        and A3: "?g .FUNCT-1K1 x1 =XBOOLE-0R4 ?g .FUNCT-1K1 x2"
      obtain i1 i2 where 
        [ty]:"i1 be ElementSUBSET-1M1-of NATNUMBERSK1" and i1Def:"i1 = x1" and
        [ty]:"i2 be ElementSUBSET-1M1-of NATNUMBERSK1" and i2Def:"i2 = x2"
        using A1 A2 sorry
      have A4: "lenFINSEQ-1K4 ?g =XBOOLE-0R4 lenFINSEQ-1K4 f"
        using finseq_5_def_3 sorry
      then have "i1 <=XXREAL-0R1 lenFINSEQ-1K4 f & i2 <=XXREAL-0R1 lenFINSEQ-1K4 f"
        using A1 A2 finseq_3_th_25 sorry
      then obtain i19 i29 where 
        [ty]:"i19 be ElementSUBSET-1M1-of NATNUMBERSK1" and i19Def:"i19 = (lenFINSEQ-1K4 f -XCMPLX-0K6 i1)+XCMPLX-0K2 \<one>\<^sub>M" and
        [ty]:"i29 be ElementSUBSET-1M1-of NATNUMBERSK1" and i29Def:"i29 = (lenFINSEQ-1K4 f -XCMPLX-0K6 i2)+XCMPLX-0K2 \<one>\<^sub>M"
        using finseq_5_th_1 sorry
      have A5: "f .FUNCT-1K1 i19 =HIDDENR1 ?g .FUNCT-1K1 x1"
        using A1 finseq_5_def_3 sorry
      also have "... = f .FUNCT-1K1 i29"
        using A2 A3 finseq_5_def_3 sorry
      finally have "f .FUNCT-1K1 i19 =HIDDENR1 f .FUNCT-1K1 i29"
         sorry
      have "domFINSEQ-1K5 ?g =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 ?g) & domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 (lenFINSEQ-1K4 f)"
        using finseq_1_def_3 sorry
      then have "i19 inTARSKIR2 domFINSEQ-1K5 f & i29 inTARSKIR2 domFINSEQ-1K5 f"
        using A1 A2 A4 finseq_5_th_2 sorry
      then have "i19 =XBOOLE-0R4 i29"
        using A5 funct_1_def_4 sorry
      thus "x1 =HIDDENR1 x2"
         sorry
    qed "sorry"
    thus "RevFINSEQ-5K3 f be one-to-oneFUNCT-1V2"
      using funct_1_def_4 sorry
  qed
qed "sorry"

mtheorem finseq_5_th_63:
" for f be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f"
proof(rule ballI,rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  fix x assume [ty]: "x be objectHIDDENM1"
  let ?n = "lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
  let ?g = "<*FINSEQ-1K10 x*>"
  have A1: "lenFINSEQ-1K4 (?g ^FINSEQ-1K8 RevFINSEQ-5K3 f) =HIDDENR1 lenFINSEQ-1K4 ?g +NAT-1K1 lenFINSEQ-1K4 (RevFINSEQ-5K3 f)"
    using finseq_1_th_22 sorry
  also have "... = \<one>\<^sub>M +NAT-1K1 lenFINSEQ-1K4 (RevFINSEQ-5K3 f)"
    using finseq_1_th_39 sorry
  also have "... = ?n"
    using finseq_5_def_3 sorry
  finally have "lenFINSEQ-1K4 (?g ^FINSEQ-1K8 RevFINSEQ-5K3 f) =HIDDENR1 ?n"
     sorry
  have A2: "lenFINSEQ-1K4 (f ^FINSEQ-1K8 ?g) =XBOOLE-0R4 ?n"
    using finseq_2_th_16 sorry
  then have A3: "lenFINSEQ-1K4 (RevFINSEQ-5K3 (f ^FINSEQ-1K8 ?g)) =XBOOLE-0R4 ?n"
    using finseq_5_def_3 sorry
  have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 (f ^FINSEQ-1K8 ?g)) implies RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    have A4: "lenFINSEQ-1K4 ?g =XBOOLE-0R4 \<one>\<^sub>M"
      using finseq_1_th_40 sorry
    assume A5: "i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 (f ^FINSEQ-1K8 ?g))"
    then have A6: "\<one>\<^sub>M <=XXREAL-0R1 i"
      using finseq_3_th_25 sorry
    have A7: "i <=XXREAL-0R1 ?n"
      using A3 A5 finseq_3_th_25 sorry
    show "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
    proof-
      have cases: "i =XBOOLE-0R4 \<one>\<^sub>M or i >XXREAL-0R4 \<one>\<^sub>M"
        using A6 xxreal_0_th_1 sorry
      have case1: "i =XBOOLE-0R4 \<one>\<^sub>M implies RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
      proof(rule impI)
        assume A8: "i =XBOOLE-0R4 \<one>\<^sub>M"
        have "SegFINSEQ-1K2 (lenFINSEQ-1K4 ?g) =XBOOLE-0R4 domFINSEQ-1K5 ?g"
          using finseq_1_def_3 sorry
        then have A9: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 ?g"
          using A4 sorry
        have "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A2 A5 A8 finseq_5_def_3 sorry
        also have "... = x"
          using finseq_1_th_42 sorry
        also have "... = (<*FINSEQ-1K10 x*>).FUNCT-1K1 \<one>\<^sub>M"
          using finseq_1_th_40 sorry
        also have "... = ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
          using A8 A9 finseq_1_def_7 sorry
        finally show "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
           sorry
      qed
      have case2: "i >XXREAL-0R4 \<one>\<^sub>M implies RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
      proof(rule impI)
        assume A10: "i >XXREAL-0R4 \<one>\<^sub>M"
        then obtain j where 
          [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 \<one>\<^sub>M"
          using nat_1_th_20 sorry
        obtain l where
          [ty]:"l be NatNAT-1M1" and 
          A11: "i =XBOOLE-0R4 l +NAT-1K1 \<one>\<^sub>M"
          using A10 nat_1_th_6 sorry
        obtain k where 
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and kDef:"k = (?n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
          using A7 finseq_5_th_1 sorry
        have "?n <XXREAL-0R3 lenFINSEQ-1K4 f +XCMPLX-0K2 i"
          using A10 xreal_1_th_8 sorry
        then have "?n -XCMPLX-0K6 i <XXREAL-0R3 (lenFINSEQ-1K4 f +XCMPLX-0K2 i)-XCMPLX-0K6 i"
          using xreal_1_th_9 sorry
        then have "k <XXREAL-0R3 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have A12: "k <=XXREAL-0R1 lenFINSEQ-1K4 f"
          using nat_1_th_13 sorry
        have "i -XCMPLX-0K6 i <=XXREAL-0R1 ?n -XCMPLX-0K6 i"
          using A7 xreal_1_th_9 sorry
        then have "0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 k"
          using xreal_1_th_6 sorry
        then have A13: "k inTARSKIR2 domFINSEQ-1K5 f"
          using A12 finseq_3_th_25 sorry
        have "l <>HIDDENR2 0NUMBERSK6"
          using A10 A11 sorry
        then have A14: "\<one>\<^sub>M <=XXREAL-0R1 j"
          using A11 nat_1_th_14 sorry
        have "j <=XXREAL-0R1 ?n -XCMPLX-0K6 \<one>\<^sub>M"
          using A7 xreal_1_th_9 sorry
        then have A15: "j inTARSKIR2 domFINSEQ-1K5 f"
          using A14 finseq_3_th_25 sorry
        have "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)).FUNCT-1K1 (((lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A2 A5 finseq_5_def_3 sorry
        also have "... = f .FUNCT-1K1 ((lenFINSEQ-1K4 f -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M)"
          using A13 finseq_1_def_7 sorry
        also have "... = RevFINSEQ-5K3 f .FUNCT-1K1 j"
          using A15 finseq_5_th_58 sorry
        also have "... = ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
          using A1 A7 A4 A10 finseq_1_th_24 sorry
        finally show "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) .FUNCT-1K1 i =HIDDENR1 ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f).FUNCT-1K1 i"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) =FINSEQ-1R1 (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 f"
    using A1 A3 finseq_2_th_9 sorry
qed "sorry"

mtheorem finseq_5_th_64:
" for f be FinSequenceFINSEQ-1M1 holds  for g be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 RevFINSEQ-5K3 g ^FINSEQ-1K8 RevFINSEQ-5K3 f"
proof(rule ballI)
  fix f assume [ty]: "f be FinSequenceFINSEQ-1M1"
  let ?P = "\<lambda>Lamb1. RevFINSEQ-5K3 (f ^FINSEQ-1K8 Lamb1) =FINSEQ-1R1 RevFINSEQ-5K3 Lamb1 ^FINSEQ-1K8 RevFINSEQ-5K3 f"
  have A1: "?P({}XBOOLE-0K1)"
  proof-
    have "RevFINSEQ-5K3 (f ^FINSEQ-1K8 {}XBOOLE-0K1) =HIDDENR1 RevFINSEQ-5K3 ({}XBOOLE-0K1) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
    proof-
      let ?g = "{}XBOOLE-0K1"
      have "RevFINSEQ-5K3 (f ^FINSEQ-1K8 {}XBOOLE-0K1) =HIDDENR1 RevFINSEQ-5K3 f"
        using finseq_1_th_34 sorry
      also have "... = RevFINSEQ-5K3 ({}XBOOLE-0K1) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
        using finseq_1_th_34 sorry
      finally show "RevFINSEQ-5K3 (f ^FINSEQ-1K8 {}XBOOLE-0K1) =HIDDENR1 RevFINSEQ-5K3 ({}XBOOLE-0K1) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
         sorry
    qed
    thus " ?thesis "
       sorry
  qed
  have A2: " for g be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds ?P(g) implies ?P(g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
  proof-
    have " for g be FinSequenceFINSEQ-1M1 holds  for x be objectHIDDENM1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 RevFINSEQ-5K3 g ^FINSEQ-1K8 RevFINSEQ-5K3 f implies RevFINSEQ-5K3 (f ^FINSEQ-1K8 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))) =HIDDENR1 RevFINSEQ-5K3 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
    proof(rule ballI,rule ballI,rule impI)
      fix g assume [ty]: "g be FinSequenceFINSEQ-1M1"
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "?P(g)"
      have "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))) =HIDDENR1 RevFINSEQ-5K3 ((f ^FINSEQ-1K8 g)^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))"
        using finseq_1_th_32 sorry
      also have "... = (<*FINSEQ-1K10 x*>)^FINSEQ-1K8 (RevFINSEQ-5K3 g ^FINSEQ-1K8 RevFINSEQ-5K3 f)"
        using A3 finseq_5_th_63 sorry
      also have "... = ((<*FINSEQ-1K10 x*>)^FINSEQ-1K8 RevFINSEQ-5K3 g)^FINSEQ-1K8 RevFINSEQ-5K3 f"
        using finseq_1_th_32 sorry
      also have "... = RevFINSEQ-5K3 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
        using finseq_5_th_63 sorry
      finally show "RevFINSEQ-5K3 (f ^FINSEQ-1K8 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>))) =HIDDENR1 RevFINSEQ-5K3 (g ^FINSEQ-1K8 (<*FINSEQ-1K10 x*>)) ^FINSEQ-1K8 RevFINSEQ-5K3 f"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  show " for g be FinSequenceFINSEQ-1M1 holds RevFINSEQ-5K3 (f ^FINSEQ-1K8 g) =FINSEQ-1R1 RevFINSEQ-5K3 g ^FINSEQ-1K8 RevFINSEQ-5K3 f"
    using finseq_1_sch_3 A1 A2 sorry
qed "sorry"

syntax FINSEQ_5K4 :: " Set \<Rightarrow>  Set \<Rightarrow> Set" ("RevFINSEQ-5K4\<^bsub>'( _ ')\<^esub>  _ " [0,228]228)
translations "RevFINSEQ-5K4\<^bsub>(D)\<^esub> f" \<rightharpoonup> "RevFINSEQ-5K3 f"

mtheorem finseq_5_add_1:
  mlet "D be setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D"
"cluster RevFINSEQ-5K3 f as-term-is FinSequenceFINSEQ-1M3-of D"
proof
(*coherence*)
  show "RevFINSEQ-5K3 f be FinSequenceFINSEQ-1M3-of D"
  proof-
    let ?n = "lenFINSEQ-1K4 f"
    have A1: "domFINSEQ-1K5 f =XBOOLE-0R4 SegFINSEQ-1K2 ?n"
      using finseq_1_def_3 sorry
    have " for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f) implies RevFINSEQ-5K3 f .FUNCT-1K1 i inTARSKIR2 D"
    proof(rule ballI,rule impI)
      fix i assume [ty]: "i be NatNAT-1M1"
      let ?j = "(?n -XCMPLX-0K6 i)+XCMPLX-0K2 \<one>\<^sub>M"
      assume "i inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K3 f)"
      then have "i inTARSKIR2 SegFINSEQ-1K2 (lenFINSEQ-1K4 (RevFINSEQ-5K3 f))"
        using finseq_1_def_3 sorry
      then have A2: "i inTARSKIR2 SegFINSEQ-1K2 ?n"
        using finseq_5_def_3 sorry
      then have "?j inTARSKIR2 SegFINSEQ-1K2 ?n"
        using finseq_5_th_2 sorry
      then have "f .FUNCT-1K1 ?j inTARSKIR2 D"
        using A1 finseq_2_th_11 sorry
      thus "RevFINSEQ-5K3 f .FUNCT-1K1 i inTARSKIR2 D"
        using A1 A2 finseq_5_th_58 sorry
    qed "sorry"
    thus "RevFINSEQ-5K3 f be FinSequenceFINSEQ-1M3-of D"
      using finseq_2_th_12 sorry
  qed
qed "sorry"

mtheorem finseq_5_th_65:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds f be  non emptyXBOOLE-0V1 implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f & f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "domFINSEQ-1K5 f =XBOOLE-0R4 domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using finseq_5_th_57 sorry
    assume A2: "f be  non emptyXBOOLE-0V1"
    then have A3: "lenFINSEQ-1K4 f inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_6 sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A2 finseq_5_th_6 sorry
    then have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 f .FUNCT-1K1 \<one>\<^sub>M"
      using partfun1_def_6 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f .FUNCT-1K1 lenFINSEQ-1K4 f"
      using finseq_5_th_62 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
      using A3 A1 partfun1_def_6 sorry
    finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f"
       sorry
    have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 f .FUNCT-1K1 lenFINSEQ-1K4 f"
      using A3 partfun1_def_6 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f .FUNCT-1K1 \<one>\<^sub>M"
      using finseq_5_th_62 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using A2 A1 finseq_5_th_6 partfun1_def_6 sorry
    finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> lenFINSEQ-1K4 f =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_66:
" for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f & i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =XBOOLE-0R4 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
proof-
  have " for j be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 f & i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M implies f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix j assume [ty]: "j be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 f"
      and A2: "i +XCMPLX-0K2 j =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
    have A3: "j inTARSKIR2 domFINSEQ-1K5 (RevFINSEQ-5K4\<^bsub>(D)\<^esub> f)"
      using A1 A2 finseq_5_th_59 sorry
    have A4: "i =XBOOLE-0R4 (lenFINSEQ-1K4 f -XCMPLX-0K6 j)+XCMPLX-0K2 \<one>\<^sub>M"
      using A2 sorry
    have "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 f .FUNCT-1K1 i"
      using A1 partfun1_def_6 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f .FUNCT-1K1 j"
      using A4 A3 finseq_5_def_3 sorry
    also have "... = RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
      using A3 partfun1_def_6 sorry
    finally show "f /.PARTFUN1K7\<^bsub>(D)\<^esub> i =HIDDENR1 RevFINSEQ-5K4\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> j"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef finseq_5_def_4 ("InsFINSEQ-5K5\<^bsub>'( _ ')\<^esub>'( _ , _ , _ ')" [0,0,0,0]228 ) where
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "p be ElementSUBSET-1M1-of D", "n be NatNAT-1M1"
"func InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) \<rightarrow> FinSequenceFINSEQ-1M3-of D equals
  (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
proof-
  (*coherence*)
    show "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) be FinSequenceFINSEQ-1M3-of D"
       sorry
qed "sorry"

mtheorem finseq_5_th_67:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,0NUMBERSK6,p) =FINSEQ-1R1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,0NUMBERSK6,p) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
  proof(rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,0NUMBERSK6,p) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> (0NUMBERSK6))"
      using finseq_1_th_34 sorry
    also have "... = (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
      using finseq_5_th_28 sorry
    finally show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,0NUMBERSK6,p) =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_68:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =FINSEQ-1R1 f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f <=XXREAL-0R1 n implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =HIDDENR1 f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "lenFINSEQ-1K4 f <=XXREAL-0R1 n"
    then have "f /^RFINSEQK2\<^bsub>(D)\<^esub> n be emptyXBOOLE-0V1"
      using finseq_5_th_32 sorry
    then have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =HIDDENR1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_34 sorry
    also have "... = f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using A1 finseq_1_th_58 sorry
    finally show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =HIDDENR1 f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_69:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    show "lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
    proof-
      have cases: "n <=XXREAL-0R1 lenFINSEQ-1K4 f or lenFINSEQ-1K4 f <XXREAL-0R3 n"
         sorry
      have case1: "n <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      proof(rule impI)
        assume A1: "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
        have "lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) +NAT-1K1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
          using finseq_1_th_22 sorry
        also have "... = lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) +XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 n)"
          using A1 rfinseq_def_1 sorry
        also have "... = (lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) +NAT-1K1 lenFINSEQ-1K4 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))+XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 n)"
          using finseq_1_th_22 sorry
        also have "... = (lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 n)"
          using finseq_1_th_39 sorry
        also have "... = (n +NAT-1K1 \<one>\<^sub>M)+XCMPLX-0K2 (lenFINSEQ-1K4 f -XCMPLX-0K6 n)"
          using A1 finseq_1_th_59 sorry
        also have "... = lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
           sorry
        finally show "lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
           sorry
      qed
      have case2: "lenFINSEQ-1K4 f <XXREAL-0R3 n implies lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
      proof(rule impI)
        assume "lenFINSEQ-1K4 f <XXREAL-0R3 n"
        then have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) =FINSEQ-1R1 f ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
          using finseq_5_th_68 sorry
        thus "lenFINSEQ-1K4 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 lenFINSEQ-1K4 f +NAT-1K1 \<one>\<^sub>M"
          using finseq_2_th_16 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_70:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =XBOOLE-0R4 {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      using finseq_1_th_31 sorry
    also have "... = (rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))\\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      using finseq_1_th_31 sorry
    also have "... = (rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) \\/XBOOLE-0K2 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n))\\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using xboole_1_th_4 sorry
    also have "... = rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_1_th_31 sorry
    also have "... = rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) \\/XBOOLE-0K2 rngFUNCT-1K2 f"
      using rfinseq_th_8 sorry
    also have "... = {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
      using finseq_1_th_38 sorry
    finally show "rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p)) =HIDDENR1 {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_cl_11:
  mlet "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "f be FinSequenceFINSEQ-1M3-of D", "n be NatNAT-1M1", "p be ElementSUBSET-1M1-of D"
"cluster InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) as-term-is  non emptyXBOOLE-0V1"
proof
(*coherence*)
  show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be  non emptyXBOOLE-0V1"
     sorry
qed "sorry"

mtheorem finseq_5_th_71:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p))"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds p inTARSKIR2 rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have "p inTARSKIR2 {TARSKIK1 p}"
      using tarski_def_1 sorry
    then have "p inTARSKIR2 {TARSKIK1 p} \\/XBOOLE-0K2 rngFUNCT-1K2 f"
      using xboole_0_def_3 sorry
    thus "p inTARSKIR2 rngFUNCT-1K2 (InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p))"
      using finseq_5_th_70 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_72:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 i =XBOOLE-0R4 f .FUNCT-1K1 i"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
    have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 i =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> ((<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> n))).FUNCT-1K1 i"
      using finseq_1_th_32 sorry
    also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n).FUNCT-1K1 i"
      using A1 finseq_5_lm_1 sorry
    also have "... = f .FUNCT-1K1 i"
      using A1 funct_1_th_47 sorry
    finally show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 i =HIDDENR1 f .FUNCT-1K1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_73:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds n <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 p"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds n <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "\<one>\<^sub>M <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    assume "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
    then have A2: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) =XBOOLE-0R4 n"
      using finseq_1_th_59 sorry
    then have "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    then have "n +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
      using A1 finseq_3_th_25 sorry
    then have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)).FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M)"
      using finseq_5_lm_1 sorry
    also have "... = p"
      using A2 finseq_1_th_42 sorry
    finally show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_74:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 f .FUNCT-1K1 i"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i & i <=XXREAL-0R1 lenFINSEQ-1K4 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 i"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "n +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 i"
      and A2: "i <=XXREAL-0R1 lenFINSEQ-1K4 f"
    obtain j where 
      [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and jDef:"j = i -XCMPLX-0K6 (n +NAT-1K1 \<one>\<^sub>M)"
      using A1 int_1_th_5 sorry
    have "n +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M) <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 sorry
    then have A3: "j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 n"
      using xreal_1_th_19 sorry
    have "n <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_11 sorry
    then have A4: "n <=XXREAL-0R1 i"
      using A1 xxreal_0_th_2 sorry
    then have "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) =XBOOLE-0R4 n"
      using A2 finseq_1_th_59 xxreal_0_th_2 sorry
    then have A5: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) =XBOOLE-0R4 n +NAT-1K1 \<one>\<^sub>M"
      using finseq_2_th_16 sorry
    have "n <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 A4 xxreal_0_th_2 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 j +NAT-1K1 \<one>\<^sub>M & j +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      using A3 nat_1_th_11 rfinseq_def_1 sorry
    then have A6: "j +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      using finseq_3_th_25 sorry
    have "(n +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 i +NAT-1K1 \<one>\<^sub>M"
       sorry
    then have "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n).FUNCT-1K1 (j +NAT-1K1 \<one>\<^sub>M)"
      using A5 A6 finseq_1_def_7 sorry
    also have "... = f .FUNCT-1K1 (n +NAT-1K1 (j +NAT-1K1 \<one>\<^sub>M))"
      using A6 finseq_5_th_27 sorry
    also have "... = f .FUNCT-1K1 i"
       sorry
    finally show "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 f .FUNCT-1K1 i"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_75:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & f be  non emptyXBOOLE-0V1 implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds \<one>\<^sub>M <=XXREAL-0R1 n & f be  non emptyXBOOLE-0V1 implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
      and A2: "f be  non emptyXBOOLE-0V1"
    have A3: "n <=XXREAL-0R1 lenFINSEQ-1K4 f implies lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) =XBOOLE-0R4 n"
      using finseq_1_th_59 sorry
    have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
      using A2 nat_1_th_14 sorry
    then have "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
      using A1 A3 finseq_1_th_58 sorry
    then have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
      using finseq_3_th_25 sorry
    thus "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 f .FUNCT-1K1 \<one>\<^sub>M"
      using finseq_5_th_72 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_76:
" for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 &  not p inTARSKIR2 rngFUNCT-1K2 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be one-to-oneFUNCT-1V2"
proof-
  have " for n be NatNAT-1M1 holds  for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be ElementSUBSET-1M1-of D holds  for f be FinSequenceFINSEQ-1M3-of D holds f be one-to-oneFUNCT-1V2 &  not p inTARSKIR2 rngFUNCT-1K2 f implies InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be one-to-oneFUNCT-1V2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix p assume [ty]: "p be ElementSUBSET-1M1-of D"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    assume A1: "f be one-to-oneFUNCT-1V2"
      and A2: " not p inTARSKIR2 rngFUNCT-1K2 f"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) implies  not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume A3: "x inHIDDENR3 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      have "rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n) c=TARSKIR1 rngFUNCT-1K2 f"
        using finseq_5_th_33 sorry
      then have "x inHIDDENR3 rngFUNCT-1K2 f"
        using A3 sorry
      then have " not x inHIDDENR3 {TARSKIK1 p}"
        using A2 tarski_def_1 sorry
      then have A4: " not x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
        using finseq_1_th_38 sorry
      have "rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) missesXBOOLE-0R1 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
        using A1 finseq_5_th_34 sorry
      then have " not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
        using A3 xboole_0_th_3 sorry
      then have " not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) \\/XBOOLE-0K2 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
        using A4 xboole_0_def_3 sorry
      thus " not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>))"
        using finseq_1_th_31 sorry
    qed "sorry"
    then have A5: "rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)) missesXBOOLE-0R1 rngFUNCT-1K2 (f /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
      using xboole_0_th_3 sorry
    have " for x be objectHIDDENM1 holds x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) implies  not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      assume "x inHIDDENR3 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      then have "x inHIDDENR3 {TARSKIK1 p}"
        using finseq_1_th_38 sorry
      then have A6: " not x inHIDDENR3 rngFUNCT-1K2 f"
        using A2 tarski_def_1 sorry
      have "rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) c=TARSKIR1 rngFUNCT-1K2 f"
        using finseq_5_th_19 sorry
      thus " not x inHIDDENR3 rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n)"
        using A6 sorry
    qed "sorry"
    then have "<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*> be one-to-oneFUNCT-1V2 & rngFUNCT-1K2 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n) missesXBOOLE-0R1 rngFUNCT-1K2 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>)"
      using finseq_3_th_93 xboole_0_th_3 sorry
    then have "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> n ^FINSEQ-1K9\<^bsub>(D)\<^esub> (<*FINSEQ-1K13\<^bsub>(D)\<^esub> p*>) be one-to-oneFUNCT-1V2"
      using A1 finseq_3_th_91 sorry
    thus "InsFINSEQ-5K5\<^bsub>(D)\<^esub>(f,n,p) be one-to-oneFUNCT-1V2"
      using A1 A5 finseq_3_th_91 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem finseq_5_th_77:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i1 be NatNAT-1M1 holds  for i2 be NatNAT-1M1 holds i1 <=XXREAL-0R1 i2 implies (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1) |FINSEQ-1K18\<^bsub>(D)\<^esub> i2 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i2) |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for i1 be NatNAT-1M1 holds  for i2 be NatNAT-1M1 holds i1 <=XXREAL-0R1 i2 implies (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1) |FINSEQ-1K18\<^bsub>(D)\<^esub> i2 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 & (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i2) |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule conjMI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix i1 assume [ty]: "i1 be NatNAT-1M1"
    fix i2 assume [ty]: "i2 be NatNAT-1M1"
    assume A1: "i1 <=XXREAL-0R1 i2"
    have "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1) <=XXREAL-0R1 i1"
      using finseq_5_th_17 sorry
    thus "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1) |FINSEQ-1K18\<^bsub>(D)\<^esub> i2 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1"
      using A1 finseq_1_th_58 xxreal_0_th_2 sorry
    have "SegFINSEQ-1K2 i1 c=TARSKIR1 SegFINSEQ-1K2 i2"
      using A1 finseq_1_th_5 sorry
    thus "(f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i2) |FINSEQ-1K18\<^bsub>(D)\<^esub> i1 =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> i1"
      using funct_1_th_51 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_78:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for i be NatNAT-1M1 holds <*>FINSEQ-1K7 D  |FINSEQ-1K18\<^bsub>(D)\<^esub> i =FINSEQ-1R1 <*>FINSEQ-1K7 D"
   sorry

mtheorem finseq_5_th_79:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds RevFINSEQ-5K4\<^bsub>(D)\<^esub> <*>FINSEQ-1K7 D =FINSEQ-1R1 <*>FINSEQ-1K7 D"
   sorry

mtheorem finseq_5_cl_12:
"cluster  non trivialZFMISC-1V1 for FinSequenceFINSEQ-1M1"
proof
(*existence*)
  show " ex it be FinSequenceFINSEQ-1M1 st it be  non trivialZFMISC-1V1"
  proof-
    have " ex tVar2 be FinSequenceFINSEQ-1M1 st  not tVar2 be trivialZFMISC-1V1"
    proof-
      show " ex tVar2 be FinSequenceFINSEQ-1M1 st  not tVar2 be trivialZFMISC-1V1"
      proof(rule bexI[of _ "<*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6,0NUMBERSK6 *>"])
        show " not <*FINSEQ-4K2\<^bsub>(NATNUMBERSK1)\<^esub> 0NUMBERSK6,0NUMBERSK6 *> be trivialZFMISC-1V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem finseq_5_th_80:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for l1 be NatNAT-1M1 holds  for l2 be NatNAT-1M1 holds (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds  for l1 be NatNAT-1M1 holds  for l2 be NatNAT-1M1 holds (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    fix l1 assume [ty]: "l1 be NatNAT-1M1"
    fix l2 assume [ty]: "l2 be NatNAT-1M1"
    show "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
    proof-
      have cases: "l1 <=XXREAL-0R1 l2 or l1 >XXREAL-0R4 l2"
         sorry
      have case1: "l1 <=XXREAL-0R1 l2 implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
      proof(rule impI)
        assume A1: "l1 <=XXREAL-0R1 l2"
        show "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
        proof-
          have cases: "l2 <=XXREAL-0R1 lenFINSEQ-1K4 f or l2 >XXREAL-0R4 lenFINSEQ-1K4 f"
             sorry
          have case1: "l2 <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
          proof(rule impI)
            assume A2: "l2 <=XXREAL-0R1 lenFINSEQ-1K4 f"
            then have A3: "l2 -XCMPLX-0K6 l1 <=XXREAL-0R1 lenFINSEQ-1K4 f -XCMPLX-0K6 l1"
              using xreal_1_th_9 sorry
            have A4: "l1 <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2)"
              using A1 A2 finseq_1_th_59 sorry
            then have A5: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1) =HIDDENR1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2) -XCMPLX-0K6 l1"
              using rfinseq_def_1 sorry
            also have "... = l2 -XCMPLX-0K6 l1"
              using A2 finseq_1_th_59 sorry
            also have "... = l2 -'NAT-DK9 l1"
              using A1 xreal_1_th_233 sorry
            finally have "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1) =HIDDENR1 l2 -'NAT-DK9 l1"
               sorry
            have A6: "l1 <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using A1 A2 xxreal_0_th_2 sorry
            then have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) =XBOOLE-0R4 lenFINSEQ-1K4 f -XCMPLX-0K6 l1"
              using rfinseq_def_1 sorry
            then have A7: "l2 -'NAT-DK9 l1 <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1)"
              using A1 A3 xreal_1_th_233 sorry
            have A8: " for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1) implies ((f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1)).FUNCT-1K1 k =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1).FUNCT-1K1 k"
            proof(rule ballI,rule impMI ,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A9: "\<one>\<^sub>M <=XXREAL-0R1 k"
                and A10: "k <=XXREAL-0R1 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1)"
              have A11: "k inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1)"
                using A9 A10 finseq_3_th_25 sorry
              have "k <=XXREAL-0R1 l2 -XCMPLX-0K6 l1"
                using A1 A5 A10 xreal_1_th_233 sorry
              then have A12: "k +XCMPLX-0K2 l1 <=XXREAL-0R1 (l2 -XCMPLX-0K6 l1)+XCMPLX-0K2 l1"
                using xreal_1_th_6 sorry
              have "k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1)"
                using A7 A5 A10 xxreal_0_th_2 sorry
              then have A13: "k inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1)"
                using A9 finseq_3_th_25 sorry
              have "k inTARSKIR2 SegFINSEQ-1K2 (l2 -'NAT-DK9 l1)"
                using A5 A9 A10 sorry
              then have "((f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1)).FUNCT-1K1 k =HIDDENR1 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1).FUNCT-1K1 k"
                using funct_1_th_49 sorry
              also have "... = f .FUNCT-1K1 (k +XCMPLX-0K2 l1)"
                using A6 A13 rfinseq_def_1 sorry
              also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2).FUNCT-1K1 (k +XCMPLX-0K2 l1)"
                using A12 finseq_3_th_112 sorry
              also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1).FUNCT-1K1 k"
                using A4 A11 rfinseq_def_1 sorry
              finally have "((f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1)).FUNCT-1K1 k =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1).FUNCT-1K1 k"
                 sorry
              thus "((f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1)).FUNCT-1K1 k =XBOOLE-0R4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1).FUNCT-1K1 k"
                 sorry
            qed "sorry"
            have "lenFINSEQ-1K4 ((f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1)) =XBOOLE-0R4 l2 -'NAT-DK9 l1"
              using A7 finseq_1_th_59 sorry
            thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
              using A5 A8 sorry
          qed
          have case2: "l2 >XXREAL-0R4 lenFINSEQ-1K4 f implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
          proof(rule impI)
            assume A14: "l2 >XXREAL-0R4 lenFINSEQ-1K4 f"
            have A15: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) =XBOOLE-0R4 lenFINSEQ-1K4 f -'NAT-DK9 l1"
              using rfinseq_th_29 sorry
            have "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 =FINSEQ-1R1 f"
              using A14 finseq_1_th_58 sorry
            thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
              using A14 A15 finseq_1_th_58 nat_d_th_42 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      have case2: "l1 >XXREAL-0R4 l2 implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
      proof(rule impI)
        assume A16: "l1 >XXREAL-0R4 l2"
        obtain l19 l29 where 
          [ty]:"l19 be ElementSUBSET-1M1-of NATNUMBERSK1" and l19Def:"l19 = l1" and
          [ty]:"l29 be ElementSUBSET-1M1-of NATNUMBERSK1" and l29Def:"l29 = l2"
          using ordinal1_def_12 sorry
        have "l1 -XCMPLX-0K6 l1 >XXREAL-0R4 l2 -XCMPLX-0K6 l1"
          using A16 xreal_1_th_9 sorry
        then have "l2 -'NAT-DK9 l1 =XBOOLE-0R4 0NUMBERSK6"
          using xreal_0_def_2 sorry
        then have A17: "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 {}XBOOLE-0K1"
           sorry
        show "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
        proof-
          have cases: "l1 <=XXREAL-0R1 lenFINSEQ-1K4 f or l1 >XXREAL-0R4 lenFINSEQ-1K4 f"
             sorry
          have case1: "l1 <=XXREAL-0R1 lenFINSEQ-1K4 f implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
          proof(rule impI)
            assume "l1 <=XXREAL-0R1 lenFINSEQ-1K4 f"
            then have "l19 >XXREAL-0R4 lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l29)"
              using A16 finseq_1_th_59 xxreal_0_th_2 sorry
            thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
              using A17 finseq_5_th_32 sorry
          qed
          have case2: "l1 >XXREAL-0R4 lenFINSEQ-1K4 f implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
          proof(rule impI)
            assume A18: "l1 >XXREAL-0R4 lenFINSEQ-1K4 f"
            have "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l29) <=XXREAL-0R1 lenFINSEQ-1K4 f"
              using finseq_5_th_16 sorry
            thus "(f /^RFINSEQK2\<^bsub>(D)\<^esub> l1) |FINSEQ-1K18\<^bsub>(D)\<^esub> (l2 -'NAT-DK9 l1) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> l2 /^RFINSEQK2\<^bsub>(D)\<^esub> l1"
              using A17 A18 finseq_5_th_32 xxreal_0_th_2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

reserve D for "setHIDDENM2"
reserve f for "FinSequenceFINSEQ-1M3-of D"
mtheorem finseq_5_th_81:
" for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f >=XXREAL-0R2 \<two>\<^sub>M implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K11 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M *>"
proof-
  have " for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds lenFINSEQ-1K4 f >=XXREAL-0R2 \<two>\<^sub>M implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K11 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M *>"
  proof(rule ballI,rule ballI,rule impI)
    fix D assume [ty]: "D be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    let ?d1 = "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
    let ?d2 = "f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M"
    assume A1: "lenFINSEQ-1K4 f >=XXREAL-0R2 \<two>\<^sub>M"
    then have A2: "lenFINSEQ-1K4 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M"
      using finseq_1_th_59 sorry
    have 
      [ty]:"D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
      using A1 sorry
    have 
      [ty]:"f be FinSequenceFINSEQ-1M3-of D"
       sorry
    have "\<two>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M)"
      using A2 finseq_3_th_25 sorry
    then have A3: "?d2 =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M"
      using finseq_4_th_70 sorry
    also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M).FUNCT-1K1 \<two>\<^sub>M"
      using A2 finseq_4_th_15 sorry
    finally have "?d2 =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M).FUNCT-1K1 \<two>\<^sub>M"
       sorry
    have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M)"
      using A2 finseq_3_th_25 sorry
    then have "?d1 =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M)/.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M"
      using finseq_4_th_70 sorry
    also have "... = (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M).FUNCT-1K1 \<one>\<^sub>M"
      using A2 finseq_4_th_15 sorry
    finally have "?d1 =HIDDENR1 (f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M).FUNCT-1K1 \<one>\<^sub>M"
       sorry
    thus "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> \<two>\<^sub>M =FINSEQ-1R1 <*FINSEQ-1K11 f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M,f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<two>\<^sub>M *>"
      using A2 A3 finseq_1_th_44 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_82:
" for k be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k ^FINSEQ-1K8 (<*FINSEQ-1K10 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)*>)"
proof-
  have " for k be NatNAT-1M1 holds  for D be setHIDDENM2 holds  for f be FinSequenceFINSEQ-1M3-of D holds k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f implies f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k ^FINSEQ-1K8 (<*FINSEQ-1K10 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)*>)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix D assume [ty]: "D be setHIDDENM2"
    fix f assume [ty]: "f be FinSequenceFINSEQ-1M3-of D"
    have A1: "\<one>\<^sub>M <=XXREAL-0R1 k +NAT-1K1 \<one>\<^sub>M"
      using nat_1_th_12 sorry
    assume "k +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    then have A2: "k +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using A1 finseq_3_th_25 sorry
    then have "f  |PARTFUN1K2\<^bsub>(NATNUMBERSK1,D)\<^esub> SegFINSEQ-1K2 (k +NAT-1K1 \<one>\<^sub>M) =FUNCT-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k ^FINSEQ-1K8 (<*FINSEQ-1K10 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)*>)"
      using finseq_5_th_10 sorry
    thus "f  |FINSEQ-1K18\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 f  |FINSEQ-1K18\<^bsub>(D)\<^esub> k ^FINSEQ-1K8 (<*FINSEQ-1K10 f /.PARTFUN1K7\<^bsub>(D)\<^esub> (k +NAT-1K1 \<one>\<^sub>M)*>)"
      using A2 partfun1_def_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem finseq_5_th_83:
" for D be setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for i be NatNAT-1M1 holds i <XXREAL-0R3 lenFINSEQ-1K4 p implies p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)*>)"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix D assume [ty]: "D be setHIDDENM2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
  fix i assume [ty]: "i be NatNAT-1M1"
  assume "i <XXREAL-0R3 lenFINSEQ-1K4 p"
  then have A1: "i +NAT-1K1 \<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 p"
    using nat_1_th_13 sorry
  have "\<one>\<^sub>M <=XXREAL-0R1 i +NAT-1K1 \<one>\<^sub>M"
    using nat_1_th_11 sorry
  then have A2: "i +NAT-1K1 \<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 p"
    using A1 finseq_3_th_25 sorry
  have "p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K8 (<*FINSEQ-1K10 p /.PARTFUN1K7\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M)*>)"
    using A1 finseq_5_th_82 sorry
  thus "p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (i +NAT-1K1 \<one>\<^sub>M) =FINSEQ-1R1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> i ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 (i +NAT-1K1 \<one>\<^sub>M)*>)"
    using A2 partfun1_def_6 sorry
qed "sorry"

mtheorem finseq_5_th_84:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for p be FinSequenceFINSEQ-1M3-of D holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 n & n <=XXREAL-0R1 lenFINSEQ-1K4 p implies p =FINSEQ-1R1 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 n*>))^FINSEQ-1K8 (p /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix p assume [ty]: "p be FinSequenceFINSEQ-1M3-of D"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "\<one>\<^sub>M <=XXREAL-0R1 n"
    and A2: "n <=XXREAL-0R1 lenFINSEQ-1K4 p"
  have "lenFINSEQ-1K4 p >=XXREAL-0R2 (n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
    using A1 A2 xreal_1_th_235 sorry
  then have A3: "lenFINSEQ-1K4 p >XXREAL-0R4 n -'NAT-DK9 \<one>\<^sub>M"
    using nat_1_th_13 sorry
  have "p  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =HIDDENR1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> ((n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
    using A1 xreal_1_th_235 sorry
  also have "... = p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 ((n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)*>)"
    using A3 finseq_5_th_83 sorry
  also have "... = p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 n*>)"
    using A1 xreal_1_th_235 sorry
  finally have "p  |FINSEQ-1K18\<^bsub>(D)\<^esub> n =HIDDENR1 p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 n*>)"
     sorry
  thus "p =FINSEQ-1R1 (p  |FINSEQ-1K18\<^bsub>(D)\<^esub> (n -'NAT-DK9 \<one>\<^sub>M) ^FINSEQ-1K8 (<*FINSEQ-1K10 p .FUNCT-1K1 n*>))^FINSEQ-1K8 (p /^RFINSEQK2\<^bsub>(D)\<^esub> n)"
    using rfinseq_th_8 sorry
qed "sorry"

mtheorem finseq_5_th_85:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 DelFINSEQ-3K2(f,\<one>\<^sub>M)"
proof(rule ballI,rule ballI)
  fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
  fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
  obtain i where
    [ty]:"i be NatNAT-1M1" and 
    A1: "i +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 lenFINSEQ-1K4 f"
    using nat_1_th_6 sorry
  have 
    [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
  have A2: "\<one>\<^sub>M <=XXREAL-0R1 lenFINSEQ-1K4 f"
    using A1 nat_1_th_11 sorry
  have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (DelFINSEQ-3K2(f,\<one>\<^sub>M)) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =XBOOLE-0R4 (DelFINSEQ-3K2(f,\<one>\<^sub>M)).FUNCT-1K1 k)"
  proof-
    have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (DelFINSEQ-3K2(f,\<one>\<^sub>M)) & ( for k be NatNAT-1M1 holds \<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) implies (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 (DelFINSEQ-3K2(f,\<one>\<^sub>M)).FUNCT-1K1 k)"
    proof(rule conjMI,rule ballI,rule impI)
      have A3: "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 (i +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
        using A1 A2 rfinseq_def_1 sorry
      also have "... = i"
         sorry
      finally have "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =HIDDENR1 i"
         sorry
      have "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using finseq_5_th_6 sorry
      thus "lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M) =XBOOLE-0R4 lenFINSEQ-1K4 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
        using A1 A3 finseq_3_th_109 sorry
      have A4: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
        using finseq_5_th_6 sorry
      fix k assume [ty]: "k be NatNAT-1M1"
      assume A5: "\<one>\<^sub>M <=XXREAL-0R1 k & k <=XXREAL-0R1 lenFINSEQ-1K4 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      have "k inTARSKIR2 domFINSEQ-1K5 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
        using A5 finseq_3_th_25 sorry
      then have "(f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 f .FUNCT-1K1 (k +NAT-1K1 \<one>\<^sub>M)"
        using A2 rfinseq_def_1 sorry
      also have "... = (DelFINSEQ-3K2(f,\<one>\<^sub>M)).FUNCT-1K1 k"
        using A1 A3 A5 A4 finseq_3_th_111 sorry
      finally show "(f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M).FUNCT-1K1 k =HIDDENR1 (DelFINSEQ-3K2(f,\<one>\<^sub>M)).FUNCT-1K1 k"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M =FINSEQ-1R1 DelFINSEQ-3K2(f,\<one>\<^sub>M)"
     sorry
qed "sorry"

mtheorem finseq_5_th_86:
" for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f =FINSEQ-1R1 (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
proof-
  have " for D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D holds f =HIDDENR1 (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
  proof(rule ballI,rule ballI)
    fix D assume [ty]: "D be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix f assume [ty]: "f be  non emptyXBOOLE-0V1\<bar>FinSequenceFINSEQ-1M3-of D"
    have A1: "\<one>\<^sub>M inTARSKIR2 domFINSEQ-1K5 f"
      using finseq_5_th_6 sorry
    have "f =HIDDENR1 (<*FINSEQ-1K13\<^bsub>(D)\<^esub> f /.PARTFUN1K7\<^bsub>(D)\<^esub> \<one>\<^sub>M*>)^FINSEQ-1K9\<^bsub>(D)\<^esub> (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using finseq_5_th_29 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (f /^RFINSEQK2\<^bsub>(D)\<^esub> \<one>\<^sub>M)"
      using A1 partfun1_def_6 sorry
    also have "... = (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
      using finseq_5_th_85 sorry
    finally show "f =HIDDENR1 (<*FINSEQ-1K10 f .FUNCT-1K1 \<one>\<^sub>M*>)^FINSEQ-1K8 (DelFINSEQ-3K2(f,\<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
