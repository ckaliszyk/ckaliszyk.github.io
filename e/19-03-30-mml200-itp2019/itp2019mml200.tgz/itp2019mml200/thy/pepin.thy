theory pepin
  imports nat_2 euler_2 pre_ff
   "../mizar_extension/E_number"
begin
(*begin*)
reserve d, i, j, k, m, n, p, q, x, k1, k2 for "NatNAT-1M1"
reserve a, c, i1, i2, i3, i5 for "IntegerINT-1M1"
mlemma pepin_lm_1:
" for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds (n >XXREAL-0R4 \<one>\<^sub>M & x >=XXREAL-0R2 \<one>\<^sub>M) & \<one>\<^sub>M =XBOOLE-0R4 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x)+XCMPLX-0K2 y implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds  for y be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M & (x >=XXREAL-0R2 \<one>\<^sub>M & \<one>\<^sub>M =XBOOLE-0R4 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x)+XCMPLX-0K2 y) implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be NatNAT-1M1"
    fix y assume [ty]: "y be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "x >=XXREAL-0R2 \<one>\<^sub>M"
      and A3: "\<one>\<^sub>M =XBOOLE-0R4 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x)+XCMPLX-0K2 y"
    have "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
    proof-
      show "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
      proof-
        have cases: "x >XXREAL-0R4 \<one>\<^sub>M or x =XBOOLE-0R4 \<one>\<^sub>M"
          using A2 xxreal_0_th_1 sorry
        have case1: "x >XXREAL-0R4 \<one>\<^sub>M implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A4: "x >XXREAL-0R4 \<one>\<^sub>M"
          have "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
          proof-
            show "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
            proof-
              have cases: "y >XXREAL-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6"
                 sorry
              have case1: "y >XXREAL-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
              proof(rule impI)
                assume A5: "y >XXREAL-0R4 0NUMBERSK6"
                then have "x *XCMPLX-0K3 y >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 y"
                  using A4 xreal_1_th_68 sorry
                then have "(x *XCMPLX-0K3 y)*XCMPLX-0K3 n >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 (x *XCMPLX-0K3 y)"
                  using A1 xreal_1_th_68 sorry
                then have "(x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x >XXREAL-0R4 0NUMBERSK6 +XCMPLX-0K2 x"
                  using xreal_1_th_6 sorry
                then have A6: "(x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x >XXREAL-0R4 \<one>\<^sub>M"
                  using A4 xxreal_0_th_2 sorry
                have "y +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                  using A5 xreal_1_th_6 sorry
                thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
                  using A3 A6 xreal_1_th_6 sorry
              qed
              have case2: "y =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
              proof(rule impI)
                assume "y =XBOOLE-0R4 0NUMBERSK6"
                thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
                  using A3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
             sorry
        qed
        have case2: "x =XBOOLE-0R4 \<one>\<^sub>M implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
        proof(rule impI)
          assume A7: "x =XBOOLE-0R4 \<one>\<^sub>M"
          have "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
          proof-
            show "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
            proof-
              have cases: "y >XXREAL-0R4 0NUMBERSK6 or y =XBOOLE-0R4 0NUMBERSK6"
                 sorry
              have case1: "y >XXREAL-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
              proof(rule impI)
                assume A8: "y >XXREAL-0R4 0NUMBERSK6"
                then have "(x *XCMPLX-0K3 y)*XCMPLX-0K3 n >XXREAL-0R4 0NUMBERSK6"
                  using A1 A7 xreal_1_th_68 sorry
                then have A9: "(x *XCMPLX-0K3 y)*XCMPLX-0K3 n +XCMPLX-0K2 x >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                  using A7 xreal_1_th_6 sorry
                have "y +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
                  using A8 xreal_1_th_6 sorry
                thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
                  using A3 A9 xreal_1_th_6 sorry
              qed
              have case2: "y =XBOOLE-0R4 0NUMBERSK6 implies x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
              proof(rule impI)
                assume "y =XBOOLE-0R4 0NUMBERSK6"
                thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
                  using A7 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
             sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "x =XBOOLE-0R4 \<one>\<^sub>M & y =XBOOLE-0R4 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_2:
" for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  not \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 Lamb1) >XXREAL-0R4 \<one>\<^sub>M"
    have A1: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 k) >XXREAL-0R4 \<one>\<^sub>M implies \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A2: "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 k) >XXREAL-0R4 \<one>\<^sub>M"
        then have "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 k) <XXREAL-0R3 (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 k)) |^NEWTONK1 \<two>\<^sub>M"
          using prepower_th_13 sorry
        then have "\<two>\<^sub>M  |^NEWTONK11 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 k *XCMPLX-0K3 \<two>\<^sub>M & \<one>\<^sub>M <XXREAL-0R3 (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 k)) |^NEWTONK1 \<two>\<^sub>M"
          using A2 newton_th_6 xxreal_0_th_2 sorry
        thus "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)) >XXREAL-0R4 \<one>\<^sub>M"
          using newton_th_9 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_4 sorry
    then have "\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)) =XBOOLE-0R4 \<two>\<^sub>M"
       sorry
    then have A3: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus " not \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) >XXREAL-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_3:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n <>HIDDENR2 0NUMBERSK6"
    then have "n >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have "n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    thus "n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_4:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n <>HIDDENR2 0NUMBERSK6"
    then have "n >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have "n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have "(n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (n +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    also have "... = (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    finally have "(n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =HIDDENR1 (n +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    thus "(n -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (n +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_1:
" for i be NatNAT-1M1 holds (i,i +NAT-1K1 \<one>\<^sub>M)are-coprimeINT-2R1"
proof-
  have " for k be NatNAT-1M1 holds (k,k +NAT-1K1 \<one>\<^sub>M)are-coprimeINT-2R1"
  proof(rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    have "k gcdNAT-DK8 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (\<one>\<^sub>M +XCMPLX-0K2 k *XCMPLX-0K3 \<one>\<^sub>M)gcdNAT-DK8 k"
       sorry
    also have "... = \<one>\<^sub>M gcdNAT-DK8 k"
      using euler_1_th_8 sorry
    also have "... = \<one>\<^sub>M"
      using newton_th_51 sorry
    finally have "k gcdNAT-DK8 (k +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "(k,k +NAT-1K1 \<one>\<^sub>M)are-coprimeINT-2R1"
      using int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_2:
" for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 implies (m,p)are-coprimeINT-2R1 or m gcdNAT-DK8 p =XBOOLE-0R4 p"
proof-
  have " for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 implies  not ( not (m,p)are-coprimeINT-2R1 &  not m gcdNAT-DK8 p =XBOOLE-0R4 p)"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    have A1: "m gcdNAT-DK8 p dividesNAT-DR1 p"
      using nat_d_def_5 sorry
    assume "p be primeINT-2V1"
    then have "m gcdNAT-DK8 p =XBOOLE-0R4 \<one>\<^sub>M or m gcdNAT-DK8 p =XBOOLE-0R4 p"
      using A1 int_2_def_4 sorry
    thus " not ( not (m,p)are-coprimeINT-2R1 &  not m gcdNAT-DK8 p =XBOOLE-0R4 p)"
      using int_2_def_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_3:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k dividesNAT-DR1 n *XCMPLX-0K3 m & (n,k)are-coprimeINT-2R1 implies k dividesNAT-DR1 m"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix k assume [ty]: "k be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "k dividesNAT-DR1 n *XCMPLX-0K3 m"
    and A2: "(n,k)are-coprimeINT-2R1"
  have 
    [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and
    [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and
    [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
  have "n gcdNAT-DK8 k =XBOOLE-0R4 \<one>\<^sub>M"
    using A2 int_2_def_3 sorry
  then have A3: "n *NAT-1K2 m gcdNAT-DK8 k *NAT-1K2 m =XBOOLE-0R4 m"
    using euler_1_th_5 sorry
  have "k dividesNAT-DR1 k *NAT-1K2 m"
     sorry
  thus "k dividesNAT-DR1 m"
    using A1 A3 newton_th_50 sorry
qed "sorry"

mtheorem pepin_th_4:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n dividesNAT-DR1 m & k dividesNAT-DR1 m) & (n,k)are-coprimeINT-2R1 implies n *XCMPLX-0K3 k dividesNAT-DR1 m"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n dividesNAT-DR1 m & (k dividesNAT-DR1 m & (n,k)are-coprimeINT-2R1) implies n *XCMPLX-0K3 k dividesNAT-DR1 m"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n dividesNAT-DR1 m"
      and A2: "k dividesNAT-DR1 m & (n,k)are-coprimeINT-2R1"
    obtain t1 where
      [ty]:"t1 be NatNAT-1M1" and 
      A3: "m =XBOOLE-0R4 n *XCMPLX-0K3 t1"
      using A1 nat_d_def_3 sorry
    have "k dividesNAT-DR1 t1"
      using A2 A3 pepin_th_3 sorry
    then obtain t2 where
      [ty]:"t2 be NatNAT-1M1" and 
      A4: "t1 =XBOOLE-0R4 k *XCMPLX-0K3 t2"
      using nat_d_def_3 sorry
    have "m =XBOOLE-0R4 (n *XCMPLX-0K3 k)*XCMPLX-0K3 t2"
      using A3 A4 sorry
    thus "n *XCMPLX-0K3 k dividesNAT-DR1 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_cl_1:
  mlet "i be IntegerINT-1M1"
"cluster i ^2SQUARE-1K1 as-term-is naturalORDINAL1V7"
proof
(*coherence*)
  show "i ^2SQUARE-1K1 be naturalORDINAL1V7"
  proof-
    have "i ^2SQUARE-1K1 inTARSKIR2 NATNUMBERSK1"
      using int_1_th_3 xreal_1_th_63 sorry
    thus "i ^2SQUARE-1K1 be naturalORDINAL1V7"
       sorry
  qed
qed "sorry"

mtheorem pepin_th_5:
" for c be IntegerINT-1M1 holds c >XXREAL-0R4 \<one>\<^sub>M implies \<one>\<^sub>M modINT-1K6 c =HIDDENR1 \<one>\<^sub>M"
proof-
  have " for c be IntegerINT-1M1 holds c >XXREAL-0R4 \<one>\<^sub>M implies \<one>\<^sub>M modINT-1K6 c =HIDDENR1 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix c assume [ty]: "c be IntegerINT-1M1"
    assume A1: "c >XXREAL-0R4 \<one>\<^sub>M"
    then have "\<one>\<^sub>M divINT-1K5 c =HIDDENR1 0NUMBERSK6"
      using pre_ff_th_4 sorry
    then have "\<one>\<^sub>M modINT-1K6 c =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (0NUMBERSK6)*XCMPLX-0K3 c"
      using A1 int_1_def_10 sorry
    thus "\<one>\<^sub>M modINT-1K6 c =HIDDENR1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_6:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies (i dividesNAT-DR1 n iff n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6)"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies  not (i dividesNAT-DR1 n &  not n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6) &  not (n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6 &  not i dividesNAT-DR1 n)"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "i <>HIDDENR2 0NUMBERSK6"
    have A2: "n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6 implies i dividesNAT-DR1 n"
    proof(rule impI)
      assume "n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6"
      then have " ex t be NatNAT-1M1 st n =XBOOLE-0R4 i *XCMPLX-0K3 t +NAT-1K1 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 i"
        using A1 nat_d_def_2 sorry
      thus "i dividesNAT-DR1 n"
         sorry
    qed
    have "i dividesNAT-DR1 n implies n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6"
    proof(rule impI)
      assume "i dividesNAT-DR1 n"
      then have " ex t be NatNAT-1M1 st n =XBOOLE-0R4 i *XCMPLX-0K3 t"
        using nat_d_def_3 sorry
      thus "n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6"
        using nat_d_th_13 sorry
    qed
    thus " not (i dividesNAT-DR1 n &  not n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6) &  not (n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6 &  not i dividesNAT-DR1 n)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_7:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <>HIDDENR2 0NUMBERSK6 & m dividesNAT-DR1 n modNAT-DK4 m implies m dividesNAT-DR1 n"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "m <>HIDDENR2 0NUMBERSK6"
    and A2: "m dividesNAT-DR1 n modNAT-DK4 m"
  obtain x where
    [ty]:"x be NatNAT-1M1" and 
    A3: "n modNAT-DK4 m =XBOOLE-0R4 m *XCMPLX-0K3 x"
    using A2 nat_d_def_3 sorry
  have "(n modNAT-DK4 m)+XCMPLX-0K2 m *XCMPLX-0K3 (n divNAT-DK3 m) =XBOOLE-0R4 m *XCMPLX-0K3 (x +NAT-1K1 (n divNAT-DK3 m))"
    using A3 sorry
  then have "n =XBOOLE-0R4 m *XCMPLX-0K3 (x +NAT-1K1 (n divNAT-DK3 m))"
    using A1 nat_d_th_2 sorry
  thus "m dividesNAT-DR1 n"
     sorry
qed "sorry"

mtheorem pepin_th_8:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for k be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n & m modNAT-DK4 n =XBOOLE-0R4 k implies n dividesINT-1R1 m -XCMPLX-0K6 k"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  fix k assume [ty]: "k be NatNAT-1M1"
  assume A1: "0NUMBERSK6 <XXREAL-0R3 n & m modNAT-DK4 n =XBOOLE-0R4 k"
  have Cut248: "m =XBOOLE-0R4 n *XCMPLX-0K3 (m divNAT-DK3 n) +XCMPLX-0K2 k"
    using A1 nat_d_th_2 sorry
  have "m -XCMPLX-0K6 k =HIDDENR1 n *XCMPLX-0K3 (m divNAT-DK3 n)"
  proof-
    show "m -XCMPLX-0K6 k =HIDDENR1 n *XCMPLX-0K3 (m divNAT-DK3 n)"
      using Cut248 sorry
  qed
  thus "n dividesINT-1R1 m -XCMPLX-0K6 k"
    using bexI[of _ "m divNAT-DK3 n"] int_1_def_3 sorry
qed "sorry"

mtheorem pepin_th_9:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds i *XCMPLX-0K3 p <>HIDDENR2 0NUMBERSK6 & k modNAT-DK4 i *XCMPLX-0K3 p <XXREAL-0R3 p implies k modNAT-DK4 i *XCMPLX-0K3 p =XBOOLE-0R4 k modNAT-DK4 p"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds i *XCMPLX-0K3 p <>HIDDENR2 0NUMBERSK6 & k modNAT-DK4 i *XCMPLX-0K3 p <XXREAL-0R3 p implies k modNAT-DK4 i *XCMPLX-0K3 p =XBOOLE-0R4 k modNAT-DK4 p"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "i *XCMPLX-0K3 p <>HIDDENR2 0NUMBERSK6"
      and A2: "k modNAT-DK4 i *XCMPLX-0K3 p <XXREAL-0R3 p"
    let ?T = "k modNAT-DK4 i *XCMPLX-0K3 p"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "k =XBOOLE-0R4 (i *XCMPLX-0K3 p)*XCMPLX-0K3 n +NAT-1K1 ?T"and "?T <XXREAL-0R3 i *XCMPLX-0K3 p"
      using A1 nat_d_def_2 sorry
    have "k =XBOOLE-0R4 p *XCMPLX-0K3 (i *XCMPLX-0K3 n) +NAT-1K1 ?T"
      using A3 sorry
    then have "k modNAT-DK4 p =HIDDENR1 ?T modNAT-DK4 p"
      using nat_d_th_21 sorry
    also have "... = ?T"
      using A2 nat_d_th_24 sorry
    finally have "k modNAT-DK4 p =HIDDENR1 ?T"
       sorry
    thus "k modNAT-DK4 i *XCMPLX-0K3 p =XBOOLE-0R4 k modNAT-DK4 p"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_10:
" for p be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
proof-
  have " for p be NatNAT-1M1 holds  for a be IntegerINT-1M1 holds (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
  proof(rule ballI,rule ballI)
    fix p assume [ty]: "p be NatNAT-1M1"
    fix a assume [ty]: "a be IntegerINT-1M1"
    show "(a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
    proof-
      have cases: "p <>HIDDENR2 0NUMBERSK6 or p =XBOOLE-0R4 0NUMBERSK6"
         sorry
      have case1: "p <>HIDDENR2 0NUMBERSK6 implies (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
      proof(rule impI)
        assume A1: "p <>HIDDENR2 0NUMBERSK6"
        have 
          [ty]:"p be IntegerINT-1M1"
           sorry
        have "(a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ((a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)divINT-1K5 p)*XCMPLX-0K3 p"
          using A1 int_1_def_10 sorry
        also have "... = (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ([\\INT-1K2 (a *XCMPLX-0K3 p)/XCMPLX-0K7 p +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 p /])*XCMPLX-0K3 p"
          using xcmplx_1_th_62 sorry
        also have "... = (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 ([\\INT-1K2 a +XCMPLX-0K2 \<one>\<^sub>M /XCMPLX-0K7 p /])*XCMPLX-0K3 p"
          using A1 xcmplx_1_th_89 sorry
        also have "... = (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)-XCMPLX-0K6 (a +XCMPLX-0K2 [\\INT-1K2 \<one>\<^sub>M /XCMPLX-0K7 p /])*XCMPLX-0K3 p"
          using int_1_th_28 sorry
        also have "... = \<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M divINT-1K5 p)*XCMPLX-0K3 p"
           sorry
        finally have "(a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M -XCMPLX-0K6 (\<one>\<^sub>M divINT-1K5 p)*XCMPLX-0K3 p"
           sorry
        thus "(a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
          using A1 int_1_def_10 sorry
      qed
      have case2: "p =XBOOLE-0R4 0NUMBERSK6 implies (a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
      proof(rule impI)
        assume "p =XBOOLE-0R4 0NUMBERSK6"
        thus "(a *XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
           sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_11:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (\<one>\<^sub>M <XXREAL-0R3 m & n *XCMPLX-0K3 k modNAT-DK4 m =XBOOLE-0R4 k modNAT-DK4 m) & (k,m)are-coprimeINT-2R1 implies n modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds \<one>\<^sub>M <XXREAL-0R3 m & (n *XCMPLX-0K3 k modNAT-DK4 m =XBOOLE-0R4 k modNAT-DK4 m & (k,m)are-coprimeINT-2R1) implies n modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "\<one>\<^sub>M <XXREAL-0R3 m"
      and A2: "n *XCMPLX-0K3 k modNAT-DK4 m =XBOOLE-0R4 k modNAT-DK4 m"
      and A3: "(k,m)are-coprimeINT-2R1"
    obtain t2 where
      [ty]:"t2 be NatNAT-1M1" and 
      A4: "k =XBOOLE-0R4 m *XCMPLX-0K3 t2 +NAT-1K1 (k modNAT-DK4 m)"and "k modNAT-DK4 m <XXREAL-0R3 m"
      using A1 nat_d_def_2 sorry
    obtain t1 where
      [ty]:"t1 be NatNAT-1M1" and 
      A5: "n *XCMPLX-0K3 k =XBOOLE-0R4 m *XCMPLX-0K3 t1 +NAT-1K1 (n *XCMPLX-0K3 k modNAT-DK4 m)"and "n *XCMPLX-0K3 k modNAT-DK4 m <XXREAL-0R3 m"
      using A1 nat_d_def_2 sorry
    have "n *XCMPLX-0K3 k -XCMPLX-0K6 \<one>\<^sub>M *XCMPLX-0K3 k =XBOOLE-0R4 m *XCMPLX-0K3 (t1 -XCMPLX-0K6 t2)"
      using A2 A5 A4 sorry
    then have A6: "m dividesINT-1R1 k *XCMPLX-0K3 (n -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    have 
      [ty]:"n be IntegerINT-1M1" and
      [ty]:"m be IntegerINT-1M1"
       sorry
    have "m dividesINT-1R1 n -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 A6 int_2_th_25 sorry
    then obtain tt where
      [ty]:"tt be IntegerINT-1M1" and 
      A7: "n -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 m *XCMPLX-0K3 tt"
       sorry
    have "n =HIDDENR1 m *XCMPLX-0K3 tt +XCMPLX-0K2 \<one>\<^sub>M"
      using A7 sorry
    then have "n modINT-1K6 m =HIDDENR1 \<one>\<^sub>M modINT-1K6 m"
      using euler_1_th_12 sorry
    also have "... = \<one>\<^sub>M"
      using A1 nat_d_th_14 sorry
    finally have "n modINT-1K6 m =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "n modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_12:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p  |^NEWTONK1 k modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 k modNAT-DK4 m"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p  |^NEWTONK1 k modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 k modNAT-DK4 m"
  proof(rule ballI,rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. p  |^NEWTONK1 Lamb1 modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 Lamb1 modNAT-DK4 m"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds p  |^NEWTONK1 n modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 n modNAT-DK4 m implies p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A2: "?P(n)"
        have "p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m =HIDDENR1 p  |^NEWTONK1 n *XCMPLX-0K3 p  |^NEWTONK1 \<one>\<^sub>M modNAT-DK4 m"
          using newton_th_8 sorry
        also have "... = (p  |^NEWTONK1 n modNAT-DK4 m)*NAT-1K2 (p modNAT-DK4 m) modNAT-DK4 m"
          using euler_2_th_9 sorry
        also have "... = (p modNAT-DK4 m) |^NEWTONK1 n *XCMPLX-0K3 (p modNAT-DK4 m) modNAT-DK4 m"
          using A2 euler_2_th_8 sorry
        also have "... = (p modNAT-DK4 m) |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
          using newton_th_6 sorry
        finally have "p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m =HIDDENR1 (p modNAT-DK4 m) |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
           sorry
        thus "p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 m"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "p  |^NEWTONK1 (0NUMBERSK6) modNAT-DK4 m =XBOOLE-0R4 \<one>\<^sub>M modNAT-DK4 m"
      using newton_th_4 sorry
    then have A3: "?P(0NUMBERSK6)"
      using newton_th_4 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "p  |^NEWTONK1 k modNAT-DK4 m =XBOOLE-0R4 (p modNAT-DK4 m) |^NEWTONK1 k modNAT-DK4 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_5:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
  proof(rule ballI,rule ballI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have "k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 k *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK1 n *XCMPLX-0K3 \<two>\<^sub>M)"
      using newton_th_6 sorry
    also have "... = (k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n)*XCMPLX-0K3 \<two>\<^sub>M"
       sorry
    finally have "k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n)*XCMPLX-0K3 \<two>\<^sub>M"
       sorry
    thus "k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
      using nat_d_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_6:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k <=XXREAL-0R1 n implies m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "k <=XXREAL-0R1 n"
    then obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A1: "n =XBOOLE-0R4 k +XCMPLX-0K2 t"
      using nat_1_th_10 sorry
    have "m  |^NEWTONK1 n =XBOOLE-0R4 m  |^NEWTONK1 k *XCMPLX-0K3 m  |^NEWTONK1 t"
      using A1 newton_th_8 sorry
    thus "m  |^NEWTONK1 k dividesNAT-DR1 m  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_7:
"\<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M"
proof-
  have "\<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M)"
     sorry
  also have "... = \<one>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
    using newton_th_8 power_th_62 sorry
  finally have "\<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =HIDDENR1 \<one>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
     sorry
  thus "\<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M"
     sorry
qed

mtheorem pepin_th_13:
" for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds i <>HIDDENR2 0NUMBERSK6 implies i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    assume A1: "i <>HIDDENR2 0NUMBERSK6"
    then have A2: "i +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    have "i >=XXREAL-0R2 \<one>\<^sub>M"
      using A1 nat_1_th_14 sorry
    then have "i -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then obtain I where 
      [ty]:"I be ElementSUBSET-1M1-of NATNUMBERSK1" and IDef:"I = i -XCMPLX-0K6 \<one>\<^sub>M"
      using int_1_th_3 sorry
    obtain II where 
      [ty]:"II be ElementSUBSET-1M1-of NATNUMBERSK1" and IIDef:"II = (i +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 I"
       sorry
    have "i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 (II +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = ((II modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M))+NAT-1K1 \<one>\<^sub>M)modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M)"
      using nat_d_th_22 sorry
    also have "... = (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M)"
      using nat_d_th_13 sorry
    also have "... = \<one>\<^sub>M"
      using A2 nat_d_th_24 sorry
    finally have "i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "i ^2SQUARE-1K1 modNAT-DK4 (i +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_14:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k ^2SQUARE-1K1 <XXREAL-0R3 j & i modNAT-DK4 j =XBOOLE-0R4 k implies i ^2SQUARE-1K1 modNAT-DK4 j =XBOOLE-0R4 k ^2SQUARE-1K1"
proof-
  have " for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k ^2SQUARE-1K1 <XXREAL-0R3 j & i modNAT-DK4 j =XBOOLE-0R4 k implies i ^2SQUARE-1K1 modNAT-DK4 j =XBOOLE-0R4 k ^2SQUARE-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix j assume [ty]: "j be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "k ^2SQUARE-1K1 <XXREAL-0R3 j"
      and A2: "i modNAT-DK4 j =XBOOLE-0R4 k"
    obtain n where
      [ty]:"n be NatNAT-1M1" and 
      A3: "i =XBOOLE-0R4 j *XCMPLX-0K3 n +XCMPLX-0K2 k"and "k <XXREAL-0R3 j"
      using A1 A2 nat_d_def_2 sorry
    have "i ^2SQUARE-1K1 =XBOOLE-0R4 j *XCMPLX-0K3 (((n *XCMPLX-0K3 j)*XCMPLX-0K3 n +XCMPLX-0K2 k *XCMPLX-0K3 n)+XCMPLX-0K2 n *XCMPLX-0K3 k) +XCMPLX-0K2 k ^2SQUARE-1K1"
      using A3 sorry
    then have "i ^2SQUARE-1K1 modNAT-DK4 j =XBOOLE-0R4 k ^2SQUARE-1K1 modNAT-DK4 j"
      using nat_d_th_21 sorry
    thus "i ^2SQUARE-1K1 modNAT-DK4 j =XBOOLE-0R4 k ^2SQUARE-1K1"
      using A1 nat_d_th_24 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_15:
" for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & i modNAT-DK4 p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i ^2SQUARE-1K1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & i modNAT-DK4 p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M implies i ^2SQUARE-1K1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "i modNAT-DK4 p =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M"
    have A3: "p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 int_2_def_4 sorry
    have "p <>HIDDENR2 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    then have "i modNAT-DK4 p =XBOOLE-0R4 i -XCMPLX-0K6 (i divNAT-DK3 p)*XCMPLX-0K3 p"
      using int_1_def_10 sorry
    then have "i =XBOOLE-0R4 (i divNAT-DK3 p)*XCMPLX-0K3 p -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 sorry
    then have "i ^2SQUARE-1K1 =XBOOLE-0R4 (((i divNAT-DK3 p)*XCMPLX-0K3 p -XCMPLX-0K6 \<two>\<^sub>M)*XCMPLX-0K3 (i divNAT-DK3 p))*XCMPLX-0K3 p +XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    then have "i ^2SQUARE-1K1 modNAT-DK4 p =HIDDENR1 \<one>\<^sub>M modNAT-DK4 p"
      using pepin_th_10 sorry
    also have "... = \<one>\<^sub>M"
      using A3 nat_d_th_24 sorry
    finally have "i ^2SQUARE-1K1 modNAT-DK4 p =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "i ^2SQUARE-1K1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_16:
" for n be NatNAT-1M1 holds n be evenABIANV3 implies n +NAT-1K1 \<one>\<^sub>M be oddABIANV2"
   sorry

mtheorem pepin_th_17:
" for p be NatNAT-1M1 holds p >XXREAL-0R4 \<two>\<^sub>M & p be primeINT-2V1 implies p be oddABIANV2"
proof-
  have " for p be NatNAT-1M1 holds p >XXREAL-0R4 \<two>\<^sub>M & p be primeINT-2V1 implies (p be evenABIANV3 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p >XXREAL-0R4 \<two>\<^sub>M & p be primeINT-2V1"
    assume "p be evenABIANV3"
    then have "p modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using nat_2_th_21 sorry
    then have " ex k be NatNAT-1M1 st p =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M"
      using nat_d_def_2 sorry
    then have "\<two>\<^sub>M dividesNAT-DR1 p"
       sorry
    thus " False "
      using A1 int_2_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_18:
" for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies \<two>\<^sub>M to-powerPOWERK2 n be evenABIANV1"
proof-
  have " for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies \<two>\<^sub>M to-powerPOWERK2 n be evenABIANV1"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n >XXREAL-0R4 0NUMBERSK6"
    then have "\<two>\<^sub>M to-powerPOWERK2 n modNAT-DK2 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using nat_2_th_17 sorry
    thus "\<two>\<^sub>M to-powerPOWERK2 n be evenABIANV1"
      using nat_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_19:
" for i be NatNAT-1M1 holds  for j be NatNAT-1M1 holds i be oddABIANV2 & j be oddABIANV2 implies i *XCMPLX-0K3 j be oddABIANV2"
   sorry

mtheorem pepin_th_20:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i be oddABIANV2 implies i  |^NEWTONK1 k be oddABIANV2"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds i be oddABIANV2 implies  not i  |^NEWTONK1 k be oddABIANV2"
  proof(rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. i  |^NEWTONK1 Lamb1 be oddABIANV2"
    assume A1: "i be oddABIANV2"
    have A2: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds i  |^NEWTONK1 n be oddABIANV2 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be oddABIANV2"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A3: "i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 i  |^NEWTONK1 n *XCMPLX-0K3 i"
          using newton_th_6 sorry
        assume "i  |^NEWTONK1 n be oddABIANV2"
        thus "i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be oddABIANV2"
          using A1 A3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "i  |^NEWTONK1 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M & \<one>\<^sub>M modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using nat_d_th_24 newton_th_4 sorry
    then have A4: "?P(0NUMBERSK6)"
      using nat_2_th_22 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A2 sorry
    thus " not i  |^NEWTONK1 k be oddABIANV2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_21:
" for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 k be evenABIANV3"
proof-
  have " for i be NatNAT-1M1 holds  for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 k be evenABIANV3"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    assume A1: "k >XXREAL-0R4 0NUMBERSK6"
      and A2: "i be evenABIANV3"
    let ?P = "\<lambda>Lamb1. Lamb1 >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 Lamb1 be evenABIANV3"
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (n >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 n be evenABIANV3) implies (n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "?P(n)"
        have "?P(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3"
          proof-
            have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3"
            proof-
              have "i  |^NEWTONK1 n *XCMPLX-0K3 i be evenABIANV3"
                using A2 sorry
              thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3"
                using newton_th_6 sorry
            qed
            thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 & i be evenABIANV3 implies i  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) be evenABIANV3"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A3 sorry
    thus "i  |^NEWTONK1 k be evenABIANV3"
      using A1 A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_22:
" for n be NatNAT-1M1 holds \<two>\<^sub>M dividesNAT-DR1 n iff n be evenABIANV3"
proof-
  have " for n be NatNAT-1M1 holds  not (\<two>\<^sub>M dividesNAT-DR1 n &  not n be evenABIANV3) &  not (n be evenABIANV3 &  not \<two>\<^sub>M dividesNAT-DR1 n)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "n be evenABIANV3 implies \<two>\<^sub>M dividesNAT-DR1 n"
    proof(rule impI)
      assume "n be evenABIANV3"
      then have "n modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
        using nat_2_th_21 sorry
      then have " ex k be NatNAT-1M1 st n =XBOOLE-0R4 \<two>\<^sub>M *XCMPLX-0K3 k +NAT-1K1 0NUMBERSK6 & 0NUMBERSK6 <XXREAL-0R3 \<two>\<^sub>M"
        using nat_d_def_2 sorry
      thus "\<two>\<^sub>M dividesNAT-DR1 n"
         sorry
    qed
    show " not (\<two>\<^sub>M dividesNAT-DR1 n &  not n be evenABIANV3) &  not (n be evenABIANV3 &  not \<two>\<^sub>M dividesNAT-DR1 n)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_23:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m *XCMPLX-0K3 n be evenABIANV3 implies m be evenABIANV3 or n be evenABIANV3"
   sorry

mtheorem pepin_th_24:
" for n be NatNAT-1M1 holds n  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 n ^2SQUARE-1K1"
proof-
  have " for n be NatNAT-1M1 holds n  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 n ^2SQUARE-1K1"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "n  |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 n  |^NEWTONK1 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = n  |^NEWTONK1 \<one>\<^sub>M *XCMPLX-0K3 n  |^NEWTONK1 \<one>\<^sub>M"
      using newton_th_8 sorry
    also have "... = n ^2SQUARE-1K1"
       sorry
    finally have "n  |^NEWTONK1 \<two>\<^sub>M =HIDDENR1 n ^2SQUARE-1K1"
       sorry
    thus "n  |^NEWTONK1 \<two>\<^sub>M =XBOOLE-0R4 n ^2SQUARE-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_25:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 \<one>\<^sub>M & n >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 \<one>\<^sub>M & n >XXREAL-0R4 0NUMBERSK6 implies  not m  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "n >XXREAL-0R4 0NUMBERSK6"
    let ?P = "\<lambda>Lamb1. Lamb1 >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 Lamb1 >XXREAL-0R4 \<one>\<^sub>M"
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (n >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M) implies (n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        have A4: "m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 m  |^NEWTONK1 n *XCMPLX-0K3 m  |^NEWTONK1 \<one>\<^sub>M"
          using newton_th_8 sorry
        also have "... = m  |^NEWTONK1 n *XCMPLX-0K3 m"
           sorry
        finally have "m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 m  |^NEWTONK1 n *XCMPLX-0K3 m"
           sorry
        assume A5: "?P(n)"
        have "?P(n +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
          proof-
            have "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
            proof-
              show "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
              proof-
                have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n <>HIDDENR2 0NUMBERSK6"
                   sorry
                have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies (n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M)"
                proof(rule impI)
                  assume "n =XBOOLE-0R4 0NUMBERSK6"
                  thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
                    using A1 sorry
                qed
                have case2: "n <>HIDDENR2 0NUMBERSK6 implies (n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M)"
                proof(rule impI)
                  assume "n <>HIDDENR2 0NUMBERSK6"
                  then have "m  |^NEWTONK1 n *XCMPLX-0K3 m >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 m"
                    using A1 A5 xreal_1_th_68 sorry
                  thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
                    using A1 A4 xxreal_0_th_2 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        thus "n +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies m  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A6 A3 sorry
    thus " not m  |^NEWTONK1 n >XXREAL-0R4 \<one>\<^sub>M"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_8:
" for n be NatNAT-1M1 holds (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 Lamb1))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M))"
    have A1: "\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M ^2SQUARE-1K1"
      using power_th_46 sorry
    finally have "\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)) =HIDDENR1 \<two>\<^sub>M ^2SQUARE-1K1"
       sorry
    have A2: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for x be NatNAT-1M1 holds (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 x))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M)) implies (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 (x +NAT-1K1 \<one>\<^sub>M)))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be NatNAT-1M1"
        assume A3: "(\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 x))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M))"
        have "(\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M)))^2SQUARE-1K1 =HIDDENR1 (\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 x *XCMPLX-0K3 \<two>\<^sub>M))^2SQUARE-1K1"
          using newton_th_6 sorry
        also have "... = ((\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 x)) |^NEWTONK1 \<two>\<^sub>M)^2SQUARE-1K1"
          using newton_th_9 sorry
        also have "... = ((\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 x))^2SQUARE-1K1)^2SQUARE-1K1"
          using pepin_th_24 sorry
        also have "... = (\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M))) |^NEWTONK11 \<two>\<^sub>M"
          using A3 pepin_th_24 sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M)"
          using newton_th_9 sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
          using newton_th_6 sorry
        finally have "(\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (x +NAT-1K1 \<one>\<^sub>M)))^2SQUARE-1K1 =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
           sorry
        thus "(\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 (x +NAT-1K1 \<one>\<^sub>M)))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 ((x +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_4 sorry
    then have A4: "?P(0NUMBERSK6)"
      using A1 sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A4 A2 sorry
    thus "(\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n))^2SQUARE-1K1 =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_26:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & p <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 p =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & p <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 p =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6 & p <>HIDDENR2 0NUMBERSK6"
    let ?P = "\<lambda>Lamb1. n <>HIDDENR2 0NUMBERSK6 & Lamb1 <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 Lamb1 =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (Lamb1 -'NAT-DK9 \<one>\<^sub>M)"
    have A2: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds (n <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 m =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (m -'NAT-DK9 \<one>\<^sub>M)) implies (n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume "?P(m)"
        have "n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
        proof-
          show "n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
          proof-
            have cases: "m =XBOOLE-0R4 0NUMBERSK6 or m <>HIDDENR2 0NUMBERSK6"
               sorry
            have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies (n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M))"
            proof(rule impI)
              assume A3: "m =XBOOLE-0R4 0NUMBERSK6"
              have "n *XCMPLX-0K3 n  |^NEWTONK1 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 n *XCMPLX-0K3 n  |^NEWTONK1 (0NUMBERSK6)"
                using xreal_1_th_232 sorry
              also have "... = n *XCMPLX-0K3 \<one>\<^sub>M"
                using newton_th_4 sorry
              finally have "n *XCMPLX-0K3 n  |^NEWTONK1 ((0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M) =HIDDENR1 n *XCMPLX-0K3 \<one>\<^sub>M"
                 sorry
              thus "n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
                using A3 sorry
            qed
            have case2: "m <>HIDDENR2 0NUMBERSK6 implies (n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M))"
            proof(rule impI)
              assume A4: "m <>HIDDENR2 0NUMBERSK6"
              have "n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 n  |^NEWTONK1 m *XCMPLX-0K3 n"
                using newton_th_6 sorry
              also have "... = n  |^NEWTONK1 ((m -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 n"
                using A4 nat_1_th_14 xreal_1_th_235 sorry
              also have "... = n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
                using A4 pepin_lm_4 sorry
              finally have "n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
                 sorry
              thus "n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
                 sorry
            qed
            show " ?thesis "
              using cases case1 case2 sorry
          qed
        qed
        thus "n <>HIDDENR2 0NUMBERSK6 & m +NAT-1K1 \<one>\<^sub>M <>HIDDENR2 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 ((m +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
       sorry
    have " for m be NatNAT-1M1 holds ?P(m)"
      using nat_1_sch_2 A5 A2 sorry
    thus "n  |^NEWTONK1 p =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M)"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_27:
" for n be NatNAT-1M1 holds  for m be NatNAT-1M1 holds m modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 implies (n  |^NEWTONK1 (m divNAT-DK3 \<two>\<^sub>M))^2SQUARE-1K1 =XBOOLE-0R4 n  |^NEWTONK1 m"
proof(rule ballI,rule ballI,rule impI)
  fix n assume [ty]: "n be NatNAT-1M1"
  fix m assume [ty]: "m be NatNAT-1M1"
  assume A1: "m modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
  have "(n  |^NEWTONK1 (m divNAT-DK3 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 n  |^NEWTONK1 ((m divNAT-DK3 \<two>\<^sub>M)+NAT-1K1 (m divNAT-DK3 \<two>\<^sub>M))"
    using newton_th_8 sorry
  also have "... = n  |^NEWTONK1 ((m +XCMPLX-0K2 m)divNAT-DK3 \<two>\<^sub>M)"
    using A1 nat_d_th_19 sorry
  also have "... = n  |^NEWTONK1 (\<two>\<^sub>M *XCMPLX-0K3 m divNAT-DK3 \<two>\<^sub>M)"
     sorry
  also have "... = n  |^NEWTONK1 m"
    using nat_d_th_18 sorry
  finally have "(n  |^NEWTONK1 (m divNAT-DK3 \<two>\<^sub>M))^2SQUARE-1K1 =HIDDENR1 n  |^NEWTONK1 m"
     sorry
  thus "(n  |^NEWTONK1 (m divNAT-DK3 \<two>\<^sub>M))^2SQUARE-1K1 =XBOOLE-0R4 n  |^NEWTONK1 m"
     sorry
qed "sorry"

mtheorem pepin_th_28:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M <=XXREAL-0R1 k implies n  |^NEWTONK1 k divNAT-DK3 n =XBOOLE-0R4 n  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M <=XXREAL-0R1 k implies n  |^NEWTONK1 k divNAT-DK3 n =XBOOLE-0R4 n  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 k"
    have A3: "k -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_9 sorry
    have "k =HIDDENR1 (k -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<one>\<^sub>M"
       sorry
    also have "... = (k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
      using A3 xreal_0_def_2 sorry
    finally have "k =HIDDENR1 (k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
       sorry
    then have "n  |^NEWTONK1 k =XBOOLE-0R4 n *XCMPLX-0K3 n  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
      using newton_th_6 sorry
    thus "n  |^NEWTONK1 k divNAT-DK3 n =XBOOLE-0R4 n  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
      using A1 nat_d_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_29:
" for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n"
proof-
  have " for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. \<two>\<^sub>M  |^NEWTONK11 (Lamb1 +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 Lamb1 +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 Lamb1"
    have A1: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for m be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 m +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 m implies \<two>\<^sub>M  |^NEWTONK11 ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impI)
        fix m assume [ty]: "m be NatNAT-1M1"
        assume A2: "\<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 m +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 m"
        have "\<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 m +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M)"
          using newton_th_6 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 m +XCMPLX-0K2 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 m"
          using newton_th_6 sorry
        also have "... = \<two>\<^sub>M *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK1 m +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 m)"
           sorry
        also have "... = \<two>\<^sub>M  |^NEWTONK11 ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
          using A2 newton_th_6 sorry
        finally have "\<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (m +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M)"
           sorry
        thus "\<two>\<^sub>M  |^NEWTONK11 ((m +NAT-1K1 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
      using newton_th_4 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
      using newton_th_4 sorry
    finally have "\<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6) +NAT-1K1 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
       sorry
    then have A3: "?P(0NUMBERSK6)"
       sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A3 A1 sorry
    thus "\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 n +XCMPLX-0K2 \<two>\<^sub>M  |^NEWTONK1 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_30:
" for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k >XXREAL-0R4 \<one>\<^sub>M & k  |^NEWTONK1 n =XBOOLE-0R4 k  |^NEWTONK1 m implies n =XBOOLE-0R4 m"
proof-
  have " for k be NatNAT-1M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds k >XXREAL-0R4 \<one>\<^sub>M & k  |^NEWTONK1 n =XBOOLE-0R4 k  |^NEWTONK1 m implies n =XBOOLE-0R4 m"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "k >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "k  |^NEWTONK1 n =XBOOLE-0R4 k  |^NEWTONK1 m"
    have "n =XBOOLE-0R4 m"
    proof-
      show "n =XBOOLE-0R4 m"
      proof-
        have cases: "n =XBOOLE-0R4 m or n <>HIDDENR2 m"
           sorry
        have case1: "n =XBOOLE-0R4 m implies n =XBOOLE-0R4 m"
        proof(rule impI)
          assume "n =XBOOLE-0R4 m"
          thus "n =XBOOLE-0R4 m"
             sorry
        qed
        have case2: "n <>HIDDENR2 m implies n =XBOOLE-0R4 m"
        proof(rule impI)
          assume "n <>HIDDENR2 m"
          then have "k to-powerPOWERK2 m <>HIDDENR2 k to-powerPOWERK2 n"
            using A1 power_th_50 sorry
          thus "n =XBOOLE-0R4 m"
            using A2 sorry
        qed
        show " ?thesis "
          using cases case1 case2 sorry
      qed
    qed
    thus "n =XBOOLE-0R4 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_9:
" for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds k >XXREAL-0R4 n & x >XXREAL-0R4 \<one>\<^sub>M implies x  |^NEWTONK1 k >XXREAL-0R4 x  |^NEWTONK1 n"
proof-
  have " for k be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for x be NatNAT-1M1 holds k >XXREAL-0R4 n & x >XXREAL-0R4 \<one>\<^sub>M implies  not x  |^NEWTONK1 k >XXREAL-0R4 x  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix x assume [ty]: "x be NatNAT-1M1"
    assume A1: "k >XXREAL-0R4 n"
      and A2: "x >XXREAL-0R4 \<one>\<^sub>M"
    obtain m where
      [ty]:"m be NatNAT-1M1" and 
      A3: "k =XBOOLE-0R4 n +XCMPLX-0K2 m"
      using A1 nat_1_th_10 sorry
    have "(m +XCMPLX-0K2 n)-XCMPLX-0K6 n >XXREAL-0R4 n -XCMPLX-0K6 n"
      using A1 A3 xreal_1_th_9 sorry
    then have "(m +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
       sorry
    then have "m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    then have A4: "m >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_13 sorry
    have "\<one>\<^sub>M  |^NEWTONK1 m =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
    then have A5: "x  |^NEWTONK1 m >XXREAL-0R4 \<one>\<^sub>M"
      using A2 A4 prepower_th_10 sorry
    have A6: "x  |^NEWTONK1 n >=XXREAL-0R2 \<one>\<^sub>M"
      using A2 prepower_th_11 sorry
    have "x  |^NEWTONK1 k =XBOOLE-0R4 x  |^NEWTONK1 n *XCMPLX-0K3 x  |^NEWTONK1 m"
      using A3 newton_th_8 sorry
    thus " not x  |^NEWTONK1 k >XXREAL-0R4 x  |^NEWTONK1 n"
      using A6 A5 xreal_1_th_155 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_10:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n implies m <=XXREAL-0R1 n"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  not (\<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n &  not m <=XXREAL-0R1 n)"
  proof(rule ballI,rule ballI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    have " not m <=XXREAL-0R1 n implies  not \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
    proof(rule impI)
      assume A1: " not m <=XXREAL-0R1 n"
      have " not \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
      proof-
        have "\<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n implies  False "
        proof(rule impI)
          have "\<two>\<^sub>M  |^NEWTONK1 n divNAT-DK3 \<two>\<^sub>M  |^NEWTONK1 m =XBOOLE-0R4 0NUMBERSK6"
            using A1 pepin_lm_9 nat_d_th_27 sorry
          then have A2: "\<two>\<^sub>M  |^NEWTONK1 n >XXREAL-0R4 \<two>\<^sub>M  |^NEWTONK1 m *XCMPLX-0K3 (\<two>\<^sub>M  |^NEWTONK1 n divNAT-DK3 \<two>\<^sub>M  |^NEWTONK1 m)"
            using prepower_th_6 sorry
          assume "\<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
          thus " False "
            using A2 nat_d_th_3 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus " not \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
         sorry
    qed
    thus " not (\<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n &  not m <=XXREAL-0R1 n)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_31:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m <=XXREAL-0R1 n iff \<two>\<^sub>M  |^NEWTONK1 m dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK1 n"
  using pepin_lm_6 pepin_lm_10 sorry

mtheorem pepin_th_32:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & i dividesNAT-DR1 p  |^NEWTONK1 n implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 implies  not ((i dividesNAT-DR1 p  |^NEWTONK1 n &  not i =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. i dividesNAT-DR1 p  |^NEWTONK1 Lamb1 implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
    assume A1: "p be primeINT-2V1"
    then have A2: "p <>HIDDENR2 0NUMBERSK6"
      using int_2_def_4 sorry
    have A3: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (i dividesNAT-DR1 p  |^NEWTONK1 n implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)) implies (i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A4: "?P(n)"
        have "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies (i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
        proof(rule impI)
          assume "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          then obtain u1 where
            [ty]:"u1 be NatNAT-1M1" and 
            A5: "p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 i *XCMPLX-0K3 u1"
            using nat_d_def_3 sorry
          have "p *XCMPLX-0K3 p  |^NEWTONK1 n =XBOOLE-0R4 i *XCMPLX-0K3 u1"
            using A5 newton_th_6 sorry
          then have A6: "p dividesNAT-DR1 i *XCMPLX-0K3 u1"
             sorry
          have "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
          proof-
            show "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
            proof-
              have cases: "p dividesNAT-DR1 i or p dividesNAT-DR1 u1"
                using A1 A6 newton_th_80 sorry
              have case1: "p dividesNAT-DR1 i implies (i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
              proof(rule impI)
                assume "p dividesNAT-DR1 i"
                then obtain w1 where
                  [ty]:"w1 be NatNAT-1M1" and 
                  A7: "i =XBOOLE-0R4 p *XCMPLX-0K3 w1"
                  using nat_d_def_3 sorry
                have "w1 inTARSKIR2 NATNUMBERSK1"
                  using ordinal1_def_12 sorry
                thus "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
                  using A7 sorry
              qed
              have case2: "p dividesNAT-DR1 u1 implies (i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
              proof(rule impI)
                assume "p dividesNAT-DR1 u1"
                then obtain w2 where
                  [ty]:"w2 be NatNAT-1M1" and 
                  A8: "u1 =XBOOLE-0R4 p *XCMPLX-0K3 w2"
                  using nat_d_def_3 sorry
                have "p *XCMPLX-0K3 p  |^NEWTONK1 n =XBOOLE-0R4 p *XCMPLX-0K3 (i *XCMPLX-0K3 w2)"
                  using A5 A8 newton_th_6 sorry
                then have "p  |^NEWTONK1 n =XBOOLE-0R4 p *XCMPLX-0K3 (i *XCMPLX-0K3 w2) divNAT-DK3 p"
                  using A2 nat_d_th_18 sorry
                then have "p  |^NEWTONK1 n =XBOOLE-0R4 i *XCMPLX-0K3 w2"
                  using A2 nat_d_th_18 sorry
                thus "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
                  using A4 nat_d_def_3 sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
             sorry
        qed
        thus "i dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: "?P(0NUMBERSK6)"
    proof-
      have "i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
      proof-
        have "i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies (i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
        proof(rule impI)
          assume "i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6)"
          then have "i dividesNAT-DR1 \<one>\<^sub>M"
            using newton_th_4 sorry
          then have " ex t be NatNAT-1M1 st \<one>\<^sub>M =XBOOLE-0R4 i *XCMPLX-0K3 t"
            using nat_d_def_3 sorry
          thus "i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
            using nat_1_th_15 sorry
        qed
        thus "i dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies i =XBOOLE-0R4 \<one>\<^sub>M or ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st i =XBOOLE-0R4 p *XCMPLX-0K3 k)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A9 A3 sorry
    thus " not ((i dividesNAT-DR1 p  |^NEWTONK1 n &  not i =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not i =XBOOLE-0R4 p *XCMPLX-0K3 k))"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_33:
" for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p be primeINT-2V1 & n <XXREAL-0R3 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) implies (n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) iff n dividesNAT-DR1 p  |^NEWTONK1 k)"
proof-
  have " for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p be primeINT-2V1 & n <XXREAL-0R3 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) implies  not (n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) &  not n dividesNAT-DR1 p  |^NEWTONK1 k) &  not (n dividesNAT-DR1 p  |^NEWTONK1 k &  not n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "n <XXREAL-0R3 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
    have A3: "p <>HIDDENR2 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    have A4: "n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) implies n dividesNAT-DR1 p  |^NEWTONK1 k"
    proof(rule impI)
      assume A5: "n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
      have "n dividesNAT-DR1 p  |^NEWTONK1 k"
      proof-
        show "n dividesNAT-DR1 p  |^NEWTONK1 k"
        proof-
          have cases: "n =XBOOLE-0R4 \<one>\<^sub>M or ( ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 p *XCMPLX-0K3 i)"
            using A1 A5 pepin_th_32 sorry
          have case1: "n =XBOOLE-0R4 \<one>\<^sub>M implies n dividesNAT-DR1 p  |^NEWTONK1 k"
          proof(rule impI)
            assume "n =XBOOLE-0R4 \<one>\<^sub>M"
            thus "n dividesNAT-DR1 p  |^NEWTONK1 k"
              using nat_d_th_6 sorry
          qed
          have case2: "( ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 p *XCMPLX-0K3 i) implies n dividesNAT-DR1 p  |^NEWTONK1 k"
          proof(rule impI)
            assume " ex i be ElementSUBSET-1M1-of NATNUMBERSK1 st n =XBOOLE-0R4 p *XCMPLX-0K3 i"
            then obtain i where
              [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A6: "n =XBOOLE-0R4 p *XCMPLX-0K3 i"
               sorry
            obtain u where
              [ty]:"u be NatNAT-1M1" and 
              A7: "p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (p *XCMPLX-0K3 i)*XCMPLX-0K3 u"
              using A5 A6 nat_d_def_3 sorry
            have "p *XCMPLX-0K3 p  |^NEWTONK1 k =XBOOLE-0R4 p *XCMPLX-0K3 (i *XCMPLX-0K3 u)"
              using A7 newton_th_6 sorry
            then have A8: "p  |^NEWTONK1 k =XBOOLE-0R4 p *XCMPLX-0K3 (i *XCMPLX-0K3 u) divNAT-DK3 p"
              using A3 nat_d_th_18 sorry
            then have A9: "p  |^NEWTONK1 k =XBOOLE-0R4 i *XCMPLX-0K3 u"
              using A3 nat_d_th_18 sorry
            then have A10: "u dividesNAT-DR1 p  |^NEWTONK1 k"
               sorry
            have "u <>HIDDENR2 \<one>\<^sub>M"
              using A2 A6 A9 newton_th_6 sorry
            then obtain j where
              [ty]:"j be ElementSUBSET-1M1-of NATNUMBERSK1" and 
              A11: "u =XBOOLE-0R4 p *XCMPLX-0K3 j"
              using A1 A10 pepin_th_32 sorry
            have "p  |^NEWTONK1 k =XBOOLE-0R4 n *XCMPLX-0K3 j"
              using A3 A6 A8 A11 nat_d_th_18 sorry
            thus "n dividesNAT-DR1 p  |^NEWTONK1 k"
               sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed
      thus "n dividesNAT-DR1 p  |^NEWTONK1 k"
         sorry
    qed
    have "n dividesNAT-DR1 p  |^NEWTONK1 k implies n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
    proof(rule impI)
      assume "n dividesNAT-DR1 p  |^NEWTONK1 k"
      then have "n dividesNAT-DR1 p  |^NEWTONK1 k *XCMPLX-0K3 p"
        using nat_d_th_9 sorry
      thus "n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
        using newton_th_6 sorry
    qed
    thus " not (n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) &  not n dividesNAT-DR1 p  |^NEWTONK1 k) &  not (n dividesNAT-DR1 p  |^NEWTONK1 k &  not n dividesNAT-DR1 p  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M))"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_34:
" for d be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for k be NatNAT-1M1 holds p be primeINT-2V1 & d dividesNAT-DR1 p  |^NEWTONK1 k implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 k)"
proof-
  have " for d be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for n be NatNAT-1M1 holds p be primeINT-2V1 & d dividesNAT-DR1 p  |^NEWTONK1 n implies  not ( for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix d assume [ty]: "d be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "d dividesNAT-DR1 p  |^NEWTONK1 n"
    let ?P = "\<lambda>Lamb1. d dividesNAT-DR1 p  |^NEWTONK1 Lamb1 implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 Lamb1)"
    have A3: "p >XXREAL-0R4 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    have A4: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds (d dividesNAT-DR1 p  |^NEWTONK1 n implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n)) implies (d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M))"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume A5: "?P(n)"
        have "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies (d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M))"
        proof(rule impI)
          assume A6: "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
          have "p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
            using A3 prepower_th_6 sorry
          then have A7: "d <=XXREAL-0R1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
            using A6 nat_d_th_7 sorry
          have "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
          proof-
            show "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
            proof-
              have cases: "d <XXREAL-0R3 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) or d =XBOOLE-0R4 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                using A7 xxreal_0_th_1 sorry
              have case1: "d <XXREAL-0R3 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies (d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI)
                assume "d <XXREAL-0R3 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                then have " ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n"
                  using A1 A5 A6 pepin_th_33 sorry
                thus "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
                  using nat_1_th_12 sorry
              qed
              have case2: "d =XBOOLE-0R4 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies (d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M))"
              proof(rule impI)
                assume "d =XBOOLE-0R4 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M)"
                thus "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
                   sorry
              qed
              show " ?thesis "
                using cases case1 case2 sorry
            qed
          qed
          thus "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
             sorry
        qed
        thus "d dividesNAT-DR1 p  |^NEWTONK1 (n +NAT-1K1 \<one>\<^sub>M) implies ( ex t be ElementSUBSET-1M1-of NATNUMBERSK1 st d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n +NAT-1K1 \<one>\<^sub>M)"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: "?P(0NUMBERSK6)"
    proof-
      have "d dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6) implies  not ( for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 0NUMBERSK6))"
      proof(rule impI)
        assume A9: "d dividesNAT-DR1 p  |^NEWTONK1 (0NUMBERSK6)"
        have "d =XBOOLE-0R4 p  |^NEWTONK1 (0NUMBERSK6)"
        proof-
          have " ex t be NatNAT-1M1 st p  |^NEWTONK1 (0NUMBERSK6) =XBOOLE-0R4 d *XCMPLX-0K3 t"
            using A9 nat_d_def_3 sorry
          then have "d =XBOOLE-0R4 \<one>\<^sub>M"
            using nat_1_th_15 newton_th_4 sorry
          thus "d =XBOOLE-0R4 p  |^NEWTONK1 (0NUMBERSK6)"
            using newton_th_4 sorry
        qed
        thus " not ( for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 0NUMBERSK6))"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A8 A4 sorry
    thus " not ( for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not (d =XBOOLE-0R4 p  |^NEWTONK1 t & t <=XXREAL-0R1 n))"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_35:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & i modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & i modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "i modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
    let ?P = "\<lambda>Lamb1. i  |^NEWTONK1 Lamb1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
    have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies i  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
        have "i  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 p =HIDDENR1 i  |^NEWTONK1 k *XCMPLX-0K3 i modNAT-DK4 p"
          using newton_th_6 sorry
        also have "... = (i  |^NEWTONK1 k modNAT-DK4 p)*XCMPLX-0K3 i modNAT-DK4 p"
          using euler_2_th_8 sorry
        also have "... = \<one>\<^sub>M"
          using A2 A4 sorry
        finally have "i  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 p =HIDDENR1 \<one>\<^sub>M"
           sorry
        thus "i  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<one>\<^sub>M modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 nat_d_th_24 sorry
    then have A5: "?P(0NUMBERSK6)"
      using newton_th_4 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A5 A3 sorry
    thus "i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_36:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds m >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 m modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
proof(rule ballI,rule ballI,rule impI)
  fix m assume [ty]: "m be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "m >XXREAL-0R4 0NUMBERSK6"
  let ?P = "\<lambda>Lamb1. Lamb1 >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 Lamb1 modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
  have A2: " for m be NatNAT-1M1 holds ?P(m) implies ?P(m +NAT-1K1 \<one>\<^sub>M)"
  proof-
    have " for m be NatNAT-1M1 holds (m >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 m modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6) implies (m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6)"
    proof(rule ballI,rule impI)
      fix m assume [ty]: "m be NatNAT-1M1"
      assume "?P(m)"
      have "?P(m +NAT-1K1 \<one>\<^sub>M)"
      proof-
        have "m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
        proof-
          have 
            [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and
            [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
            using ordinal1_def_12 sorry
          have "n *NAT-1K2 n  |^NEWTONK11 m modNAT-DK4 n =HIDDENR1 (n modNAT-DK4 n)*NAT-1K2 n  |^NEWTONK11 m modNAT-DK4 n"
            using euler_2_th_8 sorry
          also have "... = (0NUMBERSK6)*NAT-1K2 n  |^NEWTONK11 m modNAT-DK4 n"
            using nat_d_th_25 sorry
          also have "... = 0NUMBERSK6"
            using nat_d_th_26 sorry
          finally have "n *NAT-1K2 n  |^NEWTONK11 m modNAT-DK4 n =HIDDENR1 0NUMBERSK6"
             sorry
          thus "m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
            using newton_th_6 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      thus "m +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 implies n  |^NEWTONK1 (m +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  have A3: "?P(0NUMBERSK6)"
     sorry
  have " for n be NatNAT-1M1 holds ?P(n)"
    using nat_1_sch_2 A3 A2 sorry
  thus "n  |^NEWTONK1 m modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
    using A1 sorry
qed "sorry"

mtheorem pepin_th_37:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (n,p)are-coprimeINT-2R1 implies n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (n,p)are-coprimeINT-2R1 implies n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "(n,p)are-coprimeINT-2R1"
    have A3: "p <>HIDDENR2 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    have A4: "n <>HIDDENR2 0NUMBERSK6"
    proof-
      have "n =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "n =XBOOLE-0R4 0NUMBERSK6"
        then have "n gcdNAT-DK8 p =XBOOLE-0R4 p"
          using newton_th_52 sorry
        then have "n gcdNAT-DK8 p >XXREAL-0R4 \<one>\<^sub>M"
          using A1 int_2_def_4 sorry
        thus " False "
          using A2 int_2_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have A5: "n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) <>HIDDENR2 0NUMBERSK6"
      using prepower_th_5 sorry
    have "n  |^NEWTONK1 p modNAT-DK4 p =XBOOLE-0R4 n modNAT-DK4 p"
      using A1 A2 A4 euler_2_th_19 sorry
    then have A6: "n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) *XCMPLX-0K3 n modNAT-DK4 p =XBOOLE-0R4 n modNAT-DK4 p"
      using A3 A4 pepin_th_26 sorry
    have "p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 int_2_def_4 sorry
    thus "n  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A2 A6 A5 euler_2_th_12 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_38:
" for d be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds ((p be primeINT-2V1 & d >XXREAL-0R4 \<one>\<^sub>M) & d dividesNAT-DR1 p  |^NEWTONK1 k) &  not d dividesNAT-DR1 p  |^NEWTONK1 k divNAT-DK3 p implies d =XBOOLE-0R4 p  |^NEWTONK1 k"
proof-
  have " for d be NatNAT-1M1 holds  for k be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (d >XXREAL-0R4 \<one>\<^sub>M & (d dividesNAT-DR1 p  |^NEWTONK1 k &  not d dividesNAT-DR1 p  |^NEWTONK1 k divNAT-DK3 p)) implies d =XBOOLE-0R4 p  |^NEWTONK1 k"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impI)
    fix d assume [ty]: "d be NatNAT-1M1"
    fix k assume [ty]: "k be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "d >XXREAL-0R4 \<one>\<^sub>M"
      and A3: "d dividesNAT-DR1 p  |^NEWTONK1 k"
      and A4: " not d dividesNAT-DR1 p  |^NEWTONK1 k divNAT-DK3 p"
    have A5: "k <>HIDDENR2 0NUMBERSK6"
    proof-
      have "k =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "k =XBOOLE-0R4 0NUMBERSK6"
        then have "p  |^NEWTONK1 k =XBOOLE-0R4 \<one>\<^sub>M"
          using newton_th_4 sorry
        thus " False "
          using A2 A3 nat_d_th_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    then have "k >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have A6: "k -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    obtain t where
      [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and 
      A7: "d =XBOOLE-0R4 p  |^NEWTONK1 t"and A8: "t <=XXREAL-0R1 k"
      using A1 A3 pepin_th_34 sorry
    have A9: "p <>HIDDENR2 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    have " not t <XXREAL-0R3 k"
    proof-
      have "t <XXREAL-0R3 k implies  False "
      proof(rule impI)
        assume "t <XXREAL-0R3 k"
        then have "t <XXREAL-0R3 (k +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))+XCMPLX-0K2 \<one>\<^sub>M"
           sorry
        then have "t <XXREAL-0R3 (k -'NAT-DK9 \<one>\<^sub>M)+NAT-1K1 \<one>\<^sub>M"
          using A6 xreal_0_def_2 sorry
        then have "t <=XXREAL-0R1 k -'NAT-DK9 \<one>\<^sub>M"
          using nat_1_th_13 sorry
        then have "d dividesNAT-DR1 p  |^NEWTONK1 (k -'NAT-DK9 \<one>\<^sub>M)"
          using A7 pepin_lm_6 sorry
        thus " False "
          using A4 A9 A5 pepin_th_28 nat_1_th_14 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "d =XBOOLE-0R4 p  |^NEWTONK1 k"
      using A7 A8 xxreal_0_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

abbreviation(input) PEPINK1(" _ ^2PEPINK1" [354]354) where
  "i ^2PEPINK1 \<equiv> i ^2SQUARE-1K1"

mtheorem pepin_add_1:
  mlet "i be IntegerINT-1M1"
"cluster i ^2SQUARE-1K1 as-term-is ElementSUBSET-1M1-of NATNUMBERSK1"
proof
(*coherence*)
  show "i ^2SQUARE-1K1 be ElementSUBSET-1M1-of NATNUMBERSK1"
    using ordinal1_def_12 sorry
qed "sorry"

mtheorem pepin_th_39:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies (m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M iff (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n)"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M implies  not (m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M &  not (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n) &  not ((m,\<one>\<^sub>M)are-congruent-modINT-1R3 n &  not m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 \<one>\<^sub>M"
    have A2: "(m,\<one>\<^sub>M)are-congruent-modINT-1R3 n implies m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
    proof(rule impI)
      assume "(m,\<one>\<^sub>M)are-congruent-modINT-1R3 n"
      then obtain t where
        [ty]:"t be IntegerINT-1M1" and 
        A3: "n *XCMPLX-0K3 t =XBOOLE-0R4 m -XCMPLX-0K6 \<one>\<^sub>M"
         sorry
      have 
        [ty]:"m be IntegerINT-1M1" and
        [ty]:"n be IntegerINT-1M1"
         sorry
      have "m modINT-1K6 n =HIDDENR1 (n *XCMPLX-0K3 t +XCMPLX-0K2 \<one>\<^sub>M)modINT-1K6 n"
        using A3 sorry
      also have "... = \<one>\<^sub>M modINT-1K6 n"
        using euler_1_th_12 sorry
      finally have "m modINT-1K6 n =HIDDENR1 \<one>\<^sub>M modINT-1K6 n"
         sorry
      thus "m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
        using A1 nat_d_th_14 sorry
    qed
    have "m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M implies (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n"
    proof(rule impI)
      assume "m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
      then obtain k where
        [ty]:"k be NatNAT-1M1" and 
        A4: "m =XBOOLE-0R4 n *XCMPLX-0K3 k +NAT-1K1 \<one>\<^sub>M"and "\<one>\<^sub>M <XXREAL-0R3 n"
        using nat_d_def_2 sorry
      have "n *XCMPLX-0K3 k =XBOOLE-0R4 m -XCMPLX-0K6 \<one>\<^sub>M"
        using A4 sorry
      thus "(m,\<one>\<^sub>M)are-congruent-modINT-1R3 n"
         sorry
    qed
    thus " not (m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M &  not (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n) &  not ((m,\<one>\<^sub>M)are-congruent-modINT-1R3 n &  not m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M)"
      using A2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_11:
" for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds (n >XXREAL-0R4 \<one>\<^sub>M & m >XXREAL-0R4 \<one>\<^sub>M) & (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n implies m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 \<one>\<^sub>M & (m >XXREAL-0R4 \<one>\<^sub>M & (m,\<one>\<^sub>M)are-congruent-modINT-1R3 n) implies m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "m >XXREAL-0R4 \<one>\<^sub>M"
      and A3: "(m,\<one>\<^sub>M)are-congruent-modINT-1R3 n"
    obtain d where
      [ty]:"d be IntegerINT-1M1" and 
      A4: "n *XCMPLX-0K3 d =XBOOLE-0R4 m -XCMPLX-0K6 \<one>\<^sub>M"
      using A3 sorry
    have "m -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A2 xreal_1_th_9 sorry
    then have "d >XXREAL-0R4 0NUMBERSK6"
      using A4 sorry
    then have 
      [ty]:"d be ElementSUBSET-1M1-of NATNUMBERSK1"
      using int_1_th_3 sorry
    have "m =XBOOLE-0R4 n *XCMPLX-0K3 d +NAT-1K1 \<one>\<^sub>M"
      using A4 sorry
    then have "m modNAT-DK4 n =HIDDENR1 \<one>\<^sub>M modNAT-DK4 n"
      using nat_d_th_21 sorry
    also have "... = \<one>\<^sub>M"
      using A1 nat_d_th_14 sorry
    finally have "m modNAT-DK4 n =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "m modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_40:
" for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i1,i3)are-congruent-modINT-1R3 i5 implies (i2,i3)are-congruent-modINT-1R3 i5"
proof-
  have " for i1 be IntegerINT-1M1 holds  for i2 be IntegerINT-1M1 holds  for i3 be IntegerINT-1M1 holds  for i5 be IntegerINT-1M1 holds (i1,i2)are-congruent-modINT-1R3 i5 & (i1,i3)are-congruent-modINT-1R3 i5 implies (i2,i3)are-congruent-modINT-1R3 i5"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix i1 assume [ty]: "i1 be IntegerINT-1M1"
    fix i2 assume [ty]: "i2 be IntegerINT-1M1"
    fix i3 assume [ty]: "i3 be IntegerINT-1M1"
    fix i5 assume [ty]: "i5 be IntegerINT-1M1"
    assume A1: "(i1,i2)are-congruent-modINT-1R3 i5"
      and A2: "(i1,i3)are-congruent-modINT-1R3 i5"
    have "(i2,i1)are-congruent-modINT-1R3 i5"
      using A1 int_1_th_14 sorry
    then obtain t1 where
      [ty]:"t1 be IntegerINT-1M1" and 
      A3: "i5 *XCMPLX-0K3 t1 =XBOOLE-0R4 i2 -XCMPLX-0K6 i1"
       sorry
    have "(i3,i1)are-congruent-modINT-1R3 i5"
      using A2 int_1_th_14 sorry
    then obtain t2 where
      [ty]:"t2 be IntegerINT-1M1" and 
      A4: "i5 *XCMPLX-0K3 t2 =XBOOLE-0R4 i3 -XCMPLX-0K6 i1"
       sorry
    have "i2 -XCMPLX-0K6 i3 =XBOOLE-0R4 i5 *XCMPLX-0K3 (t1 -XCMPLX-0K6 t2)"
      using A3 A4 sorry
    thus "(i2,i3)are-congruent-modINT-1R3 i5"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_41:
"\<three>\<^sub>M be primeINT-2V1"
proof-
  have " for n be NatNAT-1M1 holds n dividesNAT-DR1 \<three>\<^sub>M implies n =XBOOLE-0R4 \<one>\<^sub>M or n =XBOOLE-0R4 \<three>\<^sub>M"
  proof-
    have " for n be NatNAT-1M1 holds n dividesNAT-DR1 \<three>\<^sub>M implies  not ( not n =XBOOLE-0R4 \<one>\<^sub>M &  not n =XBOOLE-0R4 \<three>\<^sub>M)"
    proof(rule ballI,rule impI)
      fix n assume [ty]: "n be NatNAT-1M1"
      assume A1: "n dividesNAT-DR1 \<three>\<^sub>M"
      have A2: "n <>HIDDENR2 \<two>\<^sub>M"
      proof-
        have "n =XBOOLE-0R4 \<two>\<^sub>M implies  False "
        proof(rule impI)
          have A3: "\<three>\<^sub>M modNAT-DK4 \<two>\<^sub>M =HIDDENR1 (\<two>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M"
             sorry
          also have "... = \<one>\<^sub>M modNAT-DK4 \<two>\<^sub>M"
            using nat_d_th_21 sorry
          also have "... = \<one>\<^sub>M"
            using nat_d_th_24 sorry
          finally have "\<three>\<^sub>M modNAT-DK4 \<two>\<^sub>M =HIDDENR1 \<one>\<^sub>M"
             sorry
          assume "n =XBOOLE-0R4 \<two>\<^sub>M"
          thus " False "
            using A1 A3 pepin_th_6 sorry
        qed
        thus " ?thesis "
           sorry
      qed
      have "n <=XXREAL-0R1 \<three>\<^sub>M"
        using A1 nat_d_th_7 sorry
      then have "n <XXREAL-0R3 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M or n =XBOOLE-0R4 \<three>\<^sub>M"
        using xxreal_0_th_1 sorry
      then have "n <=XXREAL-0R1 \<two>\<^sub>M or n =XBOOLE-0R4 \<three>\<^sub>M"
        using nat_1_th_13 sorry
      then have "(n <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M or n =XBOOLE-0R4 \<two>\<^sub>M) or n =XBOOLE-0R4 \<three>\<^sub>M"
        using xxreal_0_th_1 sorry
      then have "(n <=XXREAL-0R1 \<one>\<^sub>M or n =XBOOLE-0R4 \<two>\<^sub>M) or n =XBOOLE-0R4 \<three>\<^sub>M"
        using nat_1_th_13 sorry
      then have A4: "((n <XXREAL-0R3 \<one>\<^sub>M or n =XBOOLE-0R4 \<one>\<^sub>M) or n =XBOOLE-0R4 \<two>\<^sub>M) or n =XBOOLE-0R4 \<three>\<^sub>M"
        using xxreal_0_th_1 sorry
      have "n <>HIDDENR2 0NUMBERSK6"
        using A1 sorry
      thus " not ( not n =XBOOLE-0R4 \<one>\<^sub>M &  not n =XBOOLE-0R4 \<three>\<^sub>M)"
        using A4 A2 nat_1_th_14 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
  thus "\<three>\<^sub>M be primeINT-2V1"
    using int_2_def_4 sorry
qed

mtheorem pepin_th_42:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies EulerEULER-1K1 n <>HIDDENR2 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (EulerEULER-1K1 n =XBOOLE-0R4 0NUMBERSK6 implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    let ?X = "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n }"
    have A2: "?X c=TARSKIR1 finSegSETWOP-2K3 n"
    proof-
      have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } c=TARSKIR1 finSegSETWOP-2K3 n"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } implies x inHIDDENR3 finSegSETWOP-2K3 n"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 ?X"
          then have " ex xx be ElementSUBSET-1M1-of NATNUMBERSK1 st ((x =HIDDENR1 xx & (n,xx)are-coprimeINT-2R1) & xx >=XXREAL-0R2 \<one>\<^sub>M) & xx <=XXREAL-0R1 n"
             sorry
          thus "x inHIDDENR3 finSegSETWOP-2K3 n"
            using finseq_1_th_1 sorry
        qed "sorry"
        thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : ((n,k)are-coprimeINT-2R1 & k >=XXREAL-0R2 \<one>\<^sub>M) & k <=XXREAL-0R1 n } c=TARSKIR1 finSegSETWOP-2K3 n"
          using tarski_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume "EulerEULER-1K1 n =XBOOLE-0R4 0NUMBERSK6"
    then have A3: "cardCARD-1K1 ?X =XBOOLE-0R4 0NUMBERSK6"
      using euler_1_def_1 sorry
    obtain X where 
      [ty]:"X be finiteFINSET-1V1\<bar>setHIDDENM2" and XDef:"X = ?X"
      using A2 sorry
    have " ex k be NatNAT-1M1 st k inTARSKIR2 X"
    proof-
      have " ex tVar2 be NatNAT-1M1 st tVar2 inTARSKIR2 X"
      proof-
        show " ex tVar2 be NatNAT-1M1 st tVar2 inTARSKIR2 X"
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          have "n gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
            using newton_th_51 sorry
          then have A4: "(n,\<one>\<^sub>M)are-coprimeINT-2R1"
            using int_2_def_3 sorry
          have "\<one>\<^sub>M <=XXREAL-0R1 n"
            using A1 nat_1_th_14 sorry
          thus "\<one>\<^sub>M inTARSKIR2 X"
            using A4 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    thus " False "
      using A3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_43:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies -XCMPLX-0K4 n <XXREAL-0R3 n"
   sorry

mtheorem pepin_th_44:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies n divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume "n <>HIDDENR2 0NUMBERSK6"
    then have "n *XCMPLX-0K3 \<one>\<^sub>M divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
      using nat_d_th_18 sorry
    thus "n divNAT-DK3 n =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pepin_def_1 ("CryptoPEPINK2'( _ , _ , _ ')" [0,0,0]228 ) where
  mlet "k be NatNAT-1M1", "m be NatNAT-1M1", "n be NatNAT-1M1"
"func CryptoPEPINK2(m,n,k) \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  m  |^NEWTONK1 k modNAT-DK4 n"
proof-
  (*coherence*)
    show "m  |^NEWTONK1 k modNAT-DK4 n be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mtheorem pepin_th_45:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds ((((p be primeINT-2V1 & q be primeINT-2V1) & p <>HIDDENR2 q) & n =XBOOLE-0R4 p *XCMPLX-0K3 q) & (k1,EulerEULER-1K1 n)are-coprimeINT-2R1) & k1 *XCMPLX-0K3 k2 modNAT-DK4 EulerEULER-1K1 n =XBOOLE-0R4 \<one>\<^sub>M implies ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds m <XXREAL-0R3 n implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m)"
proof-
  have " for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds  for q be NatNAT-1M1 holds  for k1 be NatNAT-1M1 holds  for k2 be NatNAT-1M1 holds p be primeINT-2V1 & (q be primeINT-2V1 & (p <>HIDDENR2 q & (n =XBOOLE-0R4 p *XCMPLX-0K3 q & ((k1,EulerEULER-1K1 n)are-coprimeINT-2R1 & k1 *XCMPLX-0K3 k2 modNAT-DK4 EulerEULER-1K1 n =XBOOLE-0R4 \<one>\<^sub>M)))) implies ( for m be ElementSUBSET-1M1-of NATNUMBERSK1 holds m <XXREAL-0R3 n implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impMI ,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    fix q assume [ty]: "q be NatNAT-1M1"
    fix k1 assume [ty]: "k1 be NatNAT-1M1"
    fix k2 assume [ty]: "k2 be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "q be primeINT-2V1"
      and A3: "p <>HIDDENR2 q"
      and A4: "n =XBOOLE-0R4 p *XCMPLX-0K3 q"
      and A5: "(k1,EulerEULER-1K1 n)are-coprimeINT-2R1"
      and A6: "k1 *XCMPLX-0K3 k2 modNAT-DK4 EulerEULER-1K1 n =XBOOLE-0R4 \<one>\<^sub>M"
    have A7: "q >XXREAL-0R4 \<one>\<^sub>M"
      using A2 int_2_def_4 sorry
    have A8: "p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 int_2_def_4 sorry
    then have A9: "EulerEULER-1K1 n =HIDDENR1 EulerEULER-1K1 p *NAT-1K2 EulerEULER-1K1 q"
      using A1 A2 A3 A4 A7 euler_1_th_21 int_2_th_30 sorry
    also have "... = (p -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 EulerEULER-1K1 q"
      using A1 euler_1_th_20 sorry
    also have "... = (p -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (q -XCMPLX-0K6 \<one>\<^sub>M)"
      using A2 euler_1_th_20 sorry
    finally have "EulerEULER-1K1 n =HIDDENR1 (p -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 (q -XCMPLX-0K6 \<one>\<^sub>M)"
       sorry
    have A10: "n >XXREAL-0R4 \<one>\<^sub>M"
      using A4 A8 A7 xreal_1_th_161 sorry
    have A11: "p <>HIDDENR2 0NUMBERSK6 & q <>HIDDENR2 0NUMBERSK6"
      using A1 A2 int_2_def_4 sorry
    then obtain p1 q1 where 
      [ty]:"p1 be ElementSUBSET-1M1-of NATNUMBERSK1" and p1Def:"p1 = p -XCMPLX-0K6 \<one>\<^sub>M" and
      [ty]:"q1 be ElementSUBSET-1M1-of NATNUMBERSK1" and q1Def:"q1 = q -XCMPLX-0K6 \<one>\<^sub>M"
      using pepin_lm_3 int_1_th_3 sorry
    have "n <>HIDDENR2 0NUMBERSK6"
      using A4 A11 xcmplx_1_th_6 sorry
    then have A12: "EulerEULER-1K1 n <>HIDDENR2 0NUMBERSK6"
      using pepin_th_42 sorry
    have " not (p1 =XBOOLE-0R4 \<one>\<^sub>M & q1 =XBOOLE-0R4 \<one>\<^sub>M)"
      using A3 sorry
    then have A13: "p1 *NAT-1K2 q1 <>HIDDENR2 \<one>\<^sub>M"
      using nat_1_th_15 sorry
    have A14: "k1 <>HIDDENR2 0NUMBERSK6"
    proof-
      have "k1 =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume "k1 =XBOOLE-0R4 0NUMBERSK6"
        then have "k1 gcdNAT-DK8 EulerEULER-1K1 n =XBOOLE-0R4 EulerEULER-1K1 n"
          using newton_th_52 sorry
        thus " False "
          using A5 A9 A13 int_2_def_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A15: "k2 <>HIDDENR2 0NUMBERSK6"
      using A6 nat_d_th_26 sorry
    have A16: "q >XXREAL-0R4 0NUMBERSK6"
      using A2 int_2_def_4 sorry
    fix m assume [ty]: "m be ElementSUBSET-1M1-of NATNUMBERSK1"
    assume A17: "m <XXREAL-0R3 n"
    have A18: "p >XXREAL-0R4 0NUMBERSK6"
      using A1 int_2_def_4 sorry
    have "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
    proof-
      show "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
      proof-
        have cases: "(m =XBOOLE-0R4 0NUMBERSK6 or m =XBOOLE-0R4 \<one>\<^sub>M) or m <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 \<one>\<^sub>M"
           sorry
        have case1: "m =XBOOLE-0R4 0NUMBERSK6 implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
        proof(rule impI)
          assume A19: "m =XBOOLE-0R4 0NUMBERSK6"
          then have "m  |^NEWTONK1 k1 =XBOOLE-0R4 0NUMBERSK6"
            using A14 nat_1_th_14 newton_th_11 sorry
          then have "m  |^NEWTONK1 k1 modNAT-DK4 n =XBOOLE-0R4 0NUMBERSK6"
            using nat_d_th_26 sorry
          then have "CryptoPEPINK2(m,n,k1)  |^NEWTONK1 k2 =XBOOLE-0R4 0NUMBERSK6"
            using A15 nat_1_th_14 newton_th_11 sorry
          thus "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
            using A19 nat_d_th_26 sorry
        qed
        have case2: "m =XBOOLE-0R4 \<one>\<^sub>M implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
        proof(rule impI)
          assume A20: "m =XBOOLE-0R4 \<one>\<^sub>M"
          then have "m  |^NEWTONK1 k1 =XBOOLE-0R4 \<one>\<^sub>M"
             sorry
          then have "m  |^NEWTONK1 k1 modNAT-DK4 n =XBOOLE-0R4 \<one>\<^sub>M"
            using A10 nat_d_th_14 sorry
          then have "CryptoPEPINK2(m,n,k1)  |^NEWTONK1 k2 =XBOOLE-0R4 \<one>\<^sub>M"
             sorry
          thus "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
            using A10 A20 nat_d_th_14 sorry
        qed
        have case3: "m <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 \<one>\<^sub>M implies CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
        proof(rule impI)
          assume A21: "m <>HIDDENR2 0NUMBERSK6 & m <>HIDDENR2 \<one>\<^sub>M"
          have A22: " for t be ElementSUBSET-1M1-of NATNUMBERSK1 holds m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 m"
          proof(rule ballI)
            fix t assume [ty]: "t be ElementSUBSET-1M1-of NATNUMBERSK1"
            have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 m"
            proof-
              have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) >=XXREAL-0R2 \<one>\<^sub>M"
                using A21 nat_1_th_14 prepower_th_11 sorry
              then have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
                using xreal_1_th_9 sorry
              then obtain a where 
                [ty]:"a be ElementSUBSET-1M1-of NATNUMBERSK1" and aDef:"a = m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) -XCMPLX-0K6 \<one>\<^sub>M"
                using int_1_th_3 sorry
              have A23: "p dividesNAT-DR1 m *NAT-1K2 a"
              proof-
                have "p dividesNAT-DR1 m *NAT-1K2 a"
                proof-
                  show "p dividesNAT-DR1 m *NAT-1K2 a"
                  proof-
                    have cases: "m gcdNAT-DK8 p =XBOOLE-0R4 \<one>\<^sub>M or m gcdNAT-DK8 p <>HIDDENR2 \<one>\<^sub>M"
                       sorry
                    have case1: "m gcdNAT-DK8 p =XBOOLE-0R4 \<one>\<^sub>M implies p dividesNAT-DR1 m *NAT-1K2 a"
                    proof(rule impI)
                      assume "m gcdNAT-DK8 p =XBOOLE-0R4 \<one>\<^sub>M"
                      then have A24: "(m,p)are-coprimeINT-2R1"
                        using int_2_def_3 sorry
                      have "m  |^NEWTONK11 (t *NAT-1K2 q1) <>HIDDENR2 0NUMBERSK6"
                        using A21 prepower_th_5 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 q1)) |^NEWTONK11 (p1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 m  |^NEWTONK11 (t *NAT-1K2 q1) modNAT-DK4 p"
                        using A1 A21 A24 euler_2_th_17 euler_2_th_19 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 q1)) |^NEWTONK11 p1 *NAT-1K2 m  |^NEWTONK11 (t *NAT-1K2 q1) modNAT-DK4 p =XBOOLE-0R4 m  |^NEWTONK11 (t *NAT-1K2 q1) modNAT-DK4 p"
                        using newton_th_6 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 q1)) |^NEWTONK11 p1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
                        using A8 A21 A24 pepin_th_11 euler_2_th_17 sorry
                      then have "m  |^NEWTONK11 ((t *NAT-1K2 q1)*NAT-1K2 p1) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
                        using newton_th_9 sorry
                      then have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) =XBOOLE-0R4 p *XCMPLX-0K3 (m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) divNAT-DK3 p) +NAT-1K1 \<one>\<^sub>M"
                        using A18 nat_d_th_2 sorry
                      then have "p dividesNAT-DR1 a"
                         sorry
                      thus "p dividesNAT-DR1 m *NAT-1K2 a"
                        using nat_d_th_9 sorry
                    qed
                    have case2: "m gcdNAT-DK8 p <>HIDDENR2 \<one>\<^sub>M implies p dividesNAT-DR1 m *NAT-1K2 a"
                    proof(rule impI)
                      assume "m gcdNAT-DK8 p <>HIDDENR2 \<one>\<^sub>M"
                      then have " not (m,p)are-coprimeINT-2R1"
                        using int_2_def_3 sorry
                      then have "m gcdNAT-DK8 p =XBOOLE-0R4 p"
                        using A1 pepin_th_2 sorry
                      then have "p dividesNAT-DR1 m"
                        using nat_d_def_5 sorry
                      thus "p dividesNAT-DR1 m *NAT-1K2 a"
                        using nat_d_th_9 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "p dividesNAT-DR1 m *NAT-1K2 a"
                   sorry
              qed
              have "q dividesNAT-DR1 m *NAT-1K2 a"
              proof-
                have "q dividesNAT-DR1 m *NAT-1K2 a"
                proof-
                  show "q dividesNAT-DR1 m *NAT-1K2 a"
                  proof-
                    have cases: "m gcdNAT-DK8 q =XBOOLE-0R4 \<one>\<^sub>M or m gcdNAT-DK8 q <>HIDDENR2 \<one>\<^sub>M"
                       sorry
                    have case1: "m gcdNAT-DK8 q =XBOOLE-0R4 \<one>\<^sub>M implies q dividesNAT-DR1 m *NAT-1K2 a"
                    proof(rule impI)
                      assume "m gcdNAT-DK8 q =XBOOLE-0R4 \<one>\<^sub>M"
                      then have A25: "(m,q)are-coprimeINT-2R1"
                        using int_2_def_3 sorry
                      have "m  |^NEWTONK11 (t *NAT-1K2 p1) <>HIDDENR2 0NUMBERSK6"
                        using A21 prepower_th_5 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 p1)) |^NEWTONK11 (q1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 q =XBOOLE-0R4 m  |^NEWTONK11 (t *NAT-1K2 p1) modNAT-DK4 q"
                        using A2 A21 A25 euler_2_th_17 euler_2_th_19 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 p1)) |^NEWTONK11 q1 *NAT-1K2 m  |^NEWTONK11 (t *NAT-1K2 p1) modNAT-DK4 q =XBOOLE-0R4 m  |^NEWTONK11 (t *NAT-1K2 p1) modNAT-DK4 q"
                        using newton_th_6 sorry
                      then have "(m  |^NEWTONK11 (t *NAT-1K2 p1)) |^NEWTONK11 q1 modNAT-DK4 q =XBOOLE-0R4 \<one>\<^sub>M"
                        using A7 A21 A25 pepin_th_11 euler_2_th_17 sorry
                      then have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) modNAT-DK4 q =XBOOLE-0R4 \<one>\<^sub>M"
                        using newton_th_9 sorry
                      then have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) =XBOOLE-0R4 q *XCMPLX-0K3 (m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) divNAT-DK3 q) +NAT-1K1 \<one>\<^sub>M"
                        using A16 nat_d_th_2 sorry
                      then have "q dividesNAT-DR1 a"
                         sorry
                      thus "q dividesNAT-DR1 m *NAT-1K2 a"
                        using nat_d_th_9 sorry
                    qed
                    have case2: "m gcdNAT-DK8 q <>HIDDENR2 \<one>\<^sub>M implies q dividesNAT-DR1 m *NAT-1K2 a"
                    proof(rule impI)
                      assume "m gcdNAT-DK8 q <>HIDDENR2 \<one>\<^sub>M"
                      then have " not (m,q)are-coprimeINT-2R1"
                        using int_2_def_3 sorry
                      then have "m gcdNAT-DK8 q =XBOOLE-0R4 q"
                        using A2 pepin_th_2 sorry
                      then have "q dividesNAT-DR1 m"
                        using nat_d_def_5 sorry
                      thus "q dividesNAT-DR1 m *NAT-1K2 a"
                        using nat_d_th_9 sorry
                    qed
                    show " ?thesis "
                      using cases case1 case2 sorry
                  qed
                qed
                thus "q dividesNAT-DR1 m *NAT-1K2 a"
                   sorry
              qed
              then have "p *XCMPLX-0K3 q dividesNAT-DR1 m *NAT-1K2 a"
                using A1 A2 A3 A23 pepin_th_4 int_2_th_30 sorry
              then obtain k where
                [ty]:"k be NatNAT-1M1" and 
                A26: "m *NAT-1K2 a =XBOOLE-0R4 (p *XCMPLX-0K3 q)*XCMPLX-0K3 k"
                using nat_d_def_3 sorry
              have "m *XCMPLX-0K3 (m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 m *NAT-1K2 m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) -XCMPLX-0K6 m *NAT-1K2 \<one>\<^sub>M"
                 sorry
              also have "... = m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 m"
                using newton_th_6 sorry
              finally have "m *XCMPLX-0K3 (m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1) -XCMPLX-0K6 \<one>\<^sub>M) =HIDDENR1 m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 m"
                 sorry
              then have "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) -XCMPLX-0K6 (m -XCMPLX-0K6 m) =XBOOLE-0R4 n *XCMPLX-0K3 k +NAT-1K1 m"
                using A4 A26 xcmplx_1_th_37 sorry
              thus "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 m"
                using A17 nat_d_def_2 sorry
            qed
            thus "m  |^NEWTONK11 ((t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 n =XBOOLE-0R4 m"
               sorry
          qed "sorry"
          obtain t where 
            [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1" and tDef:"t = k1 *XCMPLX-0K3 k2 divNAT-DK3 EulerEULER-1K1 n"
             sorry
          have "k1 *XCMPLX-0K3 k2 =HIDDENR1 (p1 *NAT-1K2 q1)*NAT-1K2 t +NAT-1K1 \<one>\<^sub>M"
            using A6 A12 A9 nat_d_th_2 sorry
          also have "... = (t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M"
             sorry
          finally have "k1 *XCMPLX-0K3 k2 =HIDDENR1 (t *NAT-1K2 p1)*NAT-1K2 q1 +NAT-1K1 \<one>\<^sub>M"
             sorry
          then have "m  |^NEWTONK1 (k1 *XCMPLX-0K3 k2) modNAT-DK4 n =XBOOLE-0R4 m"
            using A22 sorry
          then have "(m  |^NEWTONK1 k1) |^NEWTONK1 k2 modNAT-DK4 n =XBOOLE-0R4 m"
            using newton_th_9 sorry
          thus "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
            using pepin_th_12 sorry
        qed
        show " ?thesis "
          using cases case1 case2 case3 sorry
      qed
    qed
    thus "CryptoPEPINK2(CryptoPEPINK2(m,n,k1),n,k2) =XBOOLE-0R4 m"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pepin_def_2 ("orderPEPINK3'( _ , _ ')" [0,0]228 ) where
  mlet "i be NatNAT-1M1", "p be NatNAT-1M1"
"assume p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 func orderPEPINK3(i,p) \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 means
  \<lambda>it. (it >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it & it <=XXREAL-0R1 k)"
proof-
  (*existence*)
    show "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 implies ( ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st (it >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it & it <=XXREAL-0R1 k))"
    proof(rule impI)
      assume Assume: "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1"
      have A1: "p >XXREAL-0R4 \<one>\<^sub>M"
        using Assume sorry
      have A2: "(i,p)are-coprimeINT-2R1"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of NATNUMBERSK1 st (it >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it & it <=XXREAL-0R1 k)"
      proof-
        have " ex tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 &  not tVar3 >XXREAL-0R4 0NUMBERSK6) & i  |^NEWTONK1 tVar3 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not (( not k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) &  not ( not 0NUMBERSK6 <XXREAL-0R3 tVar3 & tVar3 <=XXREAL-0R1 k)))"
        proof-
          let ?A = "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M }"
          have A3: "?A c=TARSKIR1 NATNUMBERSK1"
          proof-
            have "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M } c=TARSKIR1 NATNUMBERSK1"
            proof-
              have " for a be objectHIDDENM1 holds a inHIDDENR3 {k where k be ElementSUBSET-1M1-of NATNUMBERSK1 : k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M } implies a inHIDDENR3 NATNUMBERSK1"
              proof(rule ballI,rule impI)
                fix a assume [ty]: "a be objectHIDDENM1"
                assume "a inHIDDENR3 ?A"
                then have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (k =HIDDENR1 a & k >XXREAL-0R4 0NUMBERSK6) & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
                   sorry
                thus "a inHIDDENR3 NATNUMBERSK1"
                   sorry
              qed "sorry"
              thus "{k where k be ElementSUBSET-1M1-of NATNUMBERSK1 :  not k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M } c=TARSKIR1 NATNUMBERSK1"
                using tarski_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          have "i <>HIDDENR2 0NUMBERSK6"
          proof-
            have "i =XBOOLE-0R4 0NUMBERSK6 implies  False "
            proof(rule impI)
              assume "i =XBOOLE-0R4 0NUMBERSK6"
              then have "i gcdNAT-DK8 p =XBOOLE-0R4 p"
                using newton_th_52 sorry
              thus " False "
                using A1 A2 int_2_def_3 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          then have A4: "i  |^NEWTONK1 EulerEULER-1K1 p modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
            using A1 A2 euler_2_th_18 sorry
          have "EulerEULER-1K1 p <>HIDDENR2 0NUMBERSK6"
            using A1 pepin_th_42 sorry
          then have "EulerEULER-1K1 p inTARSKIR2 ?A"
            using A4 sorry
          then obtain A where 
            [ty]:"A be  non emptyXBOOLE-0V1\<bar>SubsetSUBSET-1M2-of NATNUMBERSK1" and ADef:"A = ?A"
            using A3 sorry
          let ?a = "the ElementSUBSET-1M3\<^bsub>(NATNUMBERSK1)\<^esub>-of A"
          let ?P = "\<lambda>Lamb1. Lamb1 inTARSKIR2 A"
          have "?a be ElementSUBSET-1M1-of NATNUMBERSK1"
             sorry
          then have A5: " ex kk be NatNAT-1M1 st ?P(kk)"
             sorry
          obtain kk where
            [ty]:"kk be NatNAT-1M1" and 
            A6: "?P(kk)"and A7: " for n be NatNAT-1M1 holds ?P(n) implies kk <=XXREAL-0R1 n"
            using nat_1_sch_5 A5 sorry
          show " ex tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 st ((tVar3 be ElementSUBSET-1M1-of NATNUMBERSK1 &  not tVar3 >XXREAL-0R4 0NUMBERSK6) & i  |^NEWTONK1 tVar3 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not (( not k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) &  not ( not 0NUMBERSK6 <XXREAL-0R3 tVar3 & tVar3 <=XXREAL-0R1 k)))"
          proof(rule bexI[of _ "kk"])
            have A8: " for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies kk <=XXREAL-0R1 k"
            proof(rule ballI,rule impI)
              fix k assume [ty]: "k be NatNAT-1M1"
              assume A9: "k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
              have "k inTARSKIR2 NATNUMBERSK1"
                using ordinal1_def_12 sorry
              then have "k inTARSKIR2 A"
                using A9 sorry
              thus "kk <=XXREAL-0R1 k"
                using A7 sorry
            qed "sorry"
            have " ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st (k =XBOOLE-0R4 kk & k >XXREAL-0R4 0NUMBERSK6) & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
              using A6 sorry
            thus "((kk be ElementSUBSET-1M1-of NATNUMBERSK1 &  not kk >XXREAL-0R4 0NUMBERSK6) & i  |^NEWTONK1 kk modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds  not (( not k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) &  not ( not 0NUMBERSK6 <XXREAL-0R3 kk & kk <=XXREAL-0R1 k)))"
              using A8 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1 implies ( for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((it1 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it1 & it1 <=XXREAL-0R1 k)) & ((it2 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it2 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it2 & it2 <=XXREAL-0R1 k)) implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: "p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1"
      have A1: "p >XXREAL-0R4 \<one>\<^sub>M"
        using Assume sorry
      have A2: "(i,p)are-coprimeINT-2R1"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for it2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds ((it1 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it1 & it1 <=XXREAL-0R1 k)) & ((it2 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 it2 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 it2 & it2 <=XXREAL-0R1 k)) implies it1 =HIDDENR1 it2"
      proof-
        have " for k1 be ElementSUBSET-1M1-of NATNUMBERSK1 holds  for k2 be ElementSUBSET-1M1-of NATNUMBERSK1 holds (((k1 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 k1 & k1 <=XXREAL-0R1 k)) & k2 >XXREAL-0R4 0NUMBERSK6) & (i  |^NEWTONK1 k2 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 k2 & k2 <=XXREAL-0R1 k)) implies k1 =HIDDENR1 k2"
        proof(rule ballI,rule ballI,rule impI)
          fix k1 assume [ty]: "k1 be ElementSUBSET-1M1-of NATNUMBERSK1"
          fix k2 assume [ty]: "k2 be ElementSUBSET-1M1-of NATNUMBERSK1"
          assume "(((k1 >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 k1 & k1 <=XXREAL-0R1 k)) & k2 >XXREAL-0R4 0NUMBERSK6) & (i  |^NEWTONK1 k2 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M & ( for k be NatNAT-1M1 holds k >XXREAL-0R4 0NUMBERSK6 & i  |^NEWTONK1 k modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies 0NUMBERSK6 <XXREAL-0R3 k2 & k2 <=XXREAL-0R1 k))"
          then have "k1 <=XXREAL-0R1 k2 & k2 <=XXREAL-0R1 k1"
             sorry
          thus "k1 =HIDDENR1 k2"
            using xxreal_0_th_1 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem pepin_th_46:
" for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M implies orderPEPINK3(\<one>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M implies (orderPEPINK3(\<one>\<^sub>M,p) <>HIDDENR2 \<one>\<^sub>M implies  False )"
  proof(rule ballI,rule impI,rule impI)
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p >XXREAL-0R4 \<one>\<^sub>M"
    have "p gcdNAT-DK8 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
      using newton_th_51 sorry
    then have A2: "(\<one>\<^sub>M,p)are-coprimeINT-2R1"
      using int_2_def_3 sorry
    have "\<one>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 nat_d_th_24 sorry
    then have "orderPEPINK3(\<one>\<^sub>M,p) <=XXREAL-0R1 \<one>\<^sub>M"
      using A1 A2 pepin_def_2 sorry
    then have "orderPEPINK3(\<one>\<^sub>M,p) <XXREAL-0R3 \<one>\<^sub>M or orderPEPINK3(\<one>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M"
      using xxreal_0_th_1 sorry
    then have A3: "orderPEPINK3(\<one>\<^sub>M,p) =XBOOLE-0R4 0NUMBERSK6 or orderPEPINK3(\<one>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    assume "orderPEPINK3(\<one>\<^sub>M,p) <>HIDDENR2 \<one>\<^sub>M"
    thus " False "
      using A1 A2 A3 pepin_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_47:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p >XXREAL-0R4 \<one>\<^sub>M & i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M) & (i,p)are-coprimeINT-2R1 implies orderPEPINK3(i,p) dividesNAT-DR1 n"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & (i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1) implies orderPEPINK3(i,p) dividesNAT-DR1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      and A3: "(i,p)are-coprimeINT-2R1"
    have A4: "orderPEPINK3(i,p) <>HIDDENR2 0NUMBERSK6"
      using A1 A3 pepin_def_2 sorry
    have A5: "i  |^NEWTONK1 orderPEPINK3(i,p) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A1 A3 pepin_def_2 sorry
    have "n modNAT-DK4 orderPEPINK3(i,p) =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have "n modNAT-DK4 orderPEPINK3(i,p) <>HIDDENR2 0NUMBERSK6 implies  False "
      proof(rule impI)
        let ?I = "n modNAT-DK4 orderPEPINK3(i,p)"
        obtain t where
          [ty]:"t be NatNAT-1M1" and 
          A6: "n =XBOOLE-0R4 orderPEPINK3(i,p) *XCMPLX-0K3 t +NAT-1K1 ?I"and A7: "?I <XXREAL-0R3 orderPEPINK3(i,p)"
          using A4 nat_d_def_2 sorry
        have 
          [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "i  |^NEWTONK1 (orderPEPINK3(i,p) *NAT-1K2 t) *XCMPLX-0K3 i  |^NEWTONK1 ?I modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using A2 A6 newton_th_8 sorry
        then have "(i  |^NEWTONK1 orderPEPINK3(i,p)) |^NEWTONK1 t *XCMPLX-0K3 i  |^NEWTONK1 ?I modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using newton_th_9 sorry
        then have "((i  |^NEWTONK1 orderPEPINK3(i,p)) |^NEWTONK1 t modNAT-DK4 p)*XCMPLX-0K3 i  |^NEWTONK1 ?I modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using euler_2_th_8 sorry
        then have A8: "\<one>\<^sub>M *XCMPLX-0K3 i  |^NEWTONK1 ?I modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using A1 A5 pepin_th_35 sorry
        assume "n modNAT-DK4 orderPEPINK3(i,p) <>HIDDENR2 0NUMBERSK6"
        thus " False "
          using A1 A3 A7 A8 pepin_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "orderPEPINK3(i,p) dividesNAT-DR1 n"
      using A4 pepin_th_6 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_48:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p >XXREAL-0R4 \<one>\<^sub>M & (i,p)are-coprimeINT-2R1) & orderPEPINK3(i,p) dividesNAT-DR1 n implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p >XXREAL-0R4 \<one>\<^sub>M & ((i,p)are-coprimeINT-2R1 & orderPEPINK3(i,p) dividesNAT-DR1 n) implies i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "(i,p)are-coprimeINT-2R1"
      and A3: "orderPEPINK3(i,p) dividesNAT-DR1 n"
    obtain t where
      [ty]:"t be NatNAT-1M1" and 
      A4: "n =XBOOLE-0R4 orderPEPINK3(i,p) *XCMPLX-0K3 t"
      using A3 nat_d_def_3 sorry
    have 
      [ty]:"t be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "i  |^NEWTONK1 n modNAT-DK4 p =HIDDENR1 (i  |^NEWTONK1 orderPEPINK3(i,p)) |^NEWTONK1 t modNAT-DK4 p"
      using A4 newton_th_9 sorry
    also have "... = (i  |^NEWTONK1 orderPEPINK3(i,p) modNAT-DK4 p) |^NEWTONK11 t modNAT-DK4 p"
      using pepin_th_12 sorry
    also have "... = \<one>\<^sub>M  |^NEWTONK11 t modNAT-DK4 p"
      using A1 A2 pepin_def_2 sorry
    also have "... = \<one>\<^sub>M"
      using A1 nat_d_th_24 sorry
    finally have "i  |^NEWTONK1 n modNAT-DK4 p =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "i  |^NEWTONK1 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_49:
" for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (i,p)are-coprimeINT-2R1 implies orderPEPINK3(i,p) dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (i,p)are-coprimeINT-2R1 implies orderPEPINK3(i,p) dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix i assume [ty]: "i be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "(i,p)are-coprimeINT-2R1"
    have "i  |^NEWTONK1 (p -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M & p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 A2 pepin_th_37 int_2_def_4 sorry
    thus "orderPEPINK3(i,p) dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
      using A2 pepin_th_47 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mdef pepin_def_3 ("FermatPEPINK4  _ " [228]228 ) where
  mlet "n be NatNAT-1M1"
"func FermatPEPINK4 n \<rightarrow> ElementSUBSET-1M1-of NATNUMBERSK1 equals
  \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) +NAT-1K1 \<one>\<^sub>M"
proof-
  (*coherence*)
    show "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) +NAT-1K1 \<one>\<^sub>M be ElementSUBSET-1M1-of NATNUMBERSK1"
       sorry
qed "sorry"

mtheorem pepin_th_50:
"FermatPEPINK4 (0NUMBERSK6) =XBOOLE-0R4 \<three>\<^sub>M"
proof-
  have "FermatPEPINK4 (0NUMBERSK6) =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
    using newton_th_4 sorry
  also have "... = \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  finally have "FermatPEPINK4 (0NUMBERSK6) =HIDDENR1 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "FermatPEPINK4 (0NUMBERSK6) =XBOOLE-0R4 \<three>\<^sub>M"
     sorry
qed

mtheorem pepin_th_51:
"FermatPEPINK4 \<one>\<^sub>M =XBOOLE-0R4 \<five>\<^sub>M"
proof-
  have "FermatPEPINK4 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
     sorry
  also have "... = \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
    using newton_th_6 sorry
  also have "... = \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  finally have "FermatPEPINK4 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "FermatPEPINK4 \<one>\<^sub>M =XBOOLE-0R4 \<five>\<^sub>M"
     sorry
qed

mtheorem pepin_th_52:
"FermatPEPINK4 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<seven>\<^sub>M"
proof-
  have "FermatPEPINK4 \<two>\<^sub>M =HIDDENR1 \<one>\<seven>\<^sub>M"
  proof-
    have "FermatPEPINK4 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)) +NAT-1K1 \<one>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using newton_th_6 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<three>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_6 sorry
    also have "... = (\<two>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 \<two>\<^sub>M)*NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_6 sorry
    also have "... = ((\<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M)*NAT-1K2 \<two>\<^sub>M)*NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_6 sorry
    also have "... = \<one>\<seven>\<^sub>M"
       sorry
    finally show "FermatPEPINK4 \<two>\<^sub>M =HIDDENR1 \<one>\<seven>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_53:
"FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
proof-
  have "FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
  proof-
    have "FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using power_th_61 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using power_th_62 sorry
    finally show "FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_54:
"FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
proof-
  have "FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
  proof-
    have "FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using power_th_62 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_8 sorry
    also have "... = (\<two>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M)*NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using newton_th_8 power_th_62 sorry
    finally show "FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_55:
" for n be NatNAT-1M1 holds FermatPEPINK4 n >XXREAL-0R4 \<two>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  not FermatPEPINK4 n >XXREAL-0R4 \<two>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?DN = "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n)"
    have "?DN >XXREAL-0R4 \<one>\<^sub>M"
      using pepin_lm_2 sorry
    then have "?DN +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
      using xreal_1_th_6 sorry
    thus " not FermatPEPINK4 n >XXREAL-0R4 \<two>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_12:
" for n be NatNAT-1M1 holds FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds  not FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "FermatPEPINK4 n <>HIDDENR2 \<one>\<^sub>M"
      using pepin_th_55 sorry
    then have "FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M or FermatPEPINK4 n <XXREAL-0R3 \<one>\<^sub>M"
      using xxreal_0_th_1 sorry
    thus " not FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M"
      using nat_1_th_14 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_13:
" for n be NatNAT-1M1 holds (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "\<two>\<^sub>M modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using nat_d_th_25 sorry
    then have "FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) & \<two>\<^sub>M be evenABIANV3"
      using nat_2_th_21 nat_d_th_34 sorry
    then have "FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M be evenABIANV3"
      using pepin_th_21 prepower_th_6 sorry
    thus "(FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using nat_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_14:
" for n be NatNAT-1M1 holds FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
proof-
  have " for n be NatNAT-1M1 holds  not FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "FermatPEPINK4 n >XXREAL-0R4 \<one>\<^sub>M"
      using pepin_lm_12 sorry
    then have "FermatPEPINK4 n -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_1_th_9 sorry
    thus " not FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6"
      using xreal_0_def_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_15:
" for n be NatNAT-1M1 holds FermatPEPINK4 n modNAT-DK4 \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) =XBOOLE-0R4 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds FermatPEPINK4 n modNAT-DK4 \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) =XBOOLE-0R4 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?DN = "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n)"
    have "FermatPEPINK4 n modNAT-DK4 ?DN =HIDDENR1 (?DN *XCMPLX-0K3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 ?DN"
       sorry
    also have "... = \<one>\<^sub>M modNAT-DK4 ?DN"
      using nat_d_th_21 sorry
    also have "... = \<one>\<^sub>M"
      using pepin_lm_2 nat_d_th_14 sorry
    finally have "FermatPEPINK4 n modNAT-DK4 ?DN =HIDDENR1 \<one>\<^sub>M"
       sorry
    thus "FermatPEPINK4 n modNAT-DK4 \<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) =XBOOLE-0R4 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_16:
" for n be NatNAT-1M1 holds FermatPEPINK4 n be oddABIANV2"
proof-
  have " for n be NatNAT-1M1 holds  not FermatPEPINK4 n be oddABIANV2"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have "FermatPEPINK4 n -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M & (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
      using pepin_lm_13 xreal_0_def_2 sorry
    thus " not FermatPEPINK4 n be oddABIANV2"
      using nat_2_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_56:
" for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds (p be primeINT-2V1 & p >XXREAL-0R4 \<two>\<^sub>M) & p dividesNAT-DR1 FermatPEPINK4 n implies ( ex k be ElementSUBSET-1M1-of NATNUMBERSK1 st p =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
proof-
  have " for n be NatNAT-1M1 holds  for p be NatNAT-1M1 holds p be primeINT-2V1 & (p >XXREAL-0R4 \<two>\<^sub>M & p dividesNAT-DR1 FermatPEPINK4 n) implies  not ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not p =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
  proof(rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix p assume [ty]: "p be NatNAT-1M1"
    assume A1: "p be primeINT-2V1"
      and A2: "p >XXREAL-0R4 \<two>\<^sub>M"
      and A3: "p dividesNAT-DR1 FermatPEPINK4 n"
    have A4: "p >XXREAL-0R4 \<one>\<^sub>M"
      using A1 int_2_def_4 sorry
    let ?t = "FermatPEPINK4 n divNAT-DK3 p"
    let ?DN = "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n)"
    have A5: "(p *XCMPLX-0K3 ?t +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M),0NUMBERSK6 +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<^sub>M))are-congruent-modINT-1R3 p"
       sorry
    have A6: "p *XCMPLX-0K3 ?t =XBOOLE-0R4 ?DN +NAT-1K1 \<one>\<^sub>M"
      using A3 nat_d_th_3 sorry
    have A7: "?DN modNAT-DK4 p <>HIDDENR2 \<one>\<^sub>M"
    proof-
      have "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M implies  False "
      proof(rule impI)
        assume "?DN modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
        then have "(?DN,\<one>\<^sub>M)are-congruent-modINT-1R3 p"
          using A4 pepin_th_39 sorry
        then have "(\<one>\<^sub>M,?DN)are-congruent-modINT-1R3 p"
          using int_1_th_14 sorry
        then have "(\<one>\<^sub>M,-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 p"
          using A6 A5 int_1_th_15 sorry
        then have "p dividesINT-1R1 \<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
           sorry
        thus " False "
          using A2 nat_d_th_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A8: "(\<two>\<^sub>M,p)are-coprimeINT-2R1"
      using A1 A2 int_2_th_28 int_2_th_30 sorry
    then have "orderPEPINK3(\<two>\<^sub>M,p) <>HIDDENR2 0NUMBERSK6"
      using A4 pepin_def_2 sorry
    then have "orderPEPINK3(\<two>\<^sub>M,p) >=XXREAL-0R2 \<one>\<^sub>M"
      using nat_1_th_14 sorry
    then have A9: "orderPEPINK3(\<two>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M or orderPEPINK3(\<two>\<^sub>M,p) >XXREAL-0R4 \<one>\<^sub>M"
      using xxreal_0_th_1 sorry
    have A10: "?DN >XXREAL-0R4 \<one>\<^sub>M"
      using pepin_th_25 prepower_th_6 sorry
    then have "?DN *XCMPLX-0K3 ?DN >XXREAL-0R4 \<one>\<^sub>M *XCMPLX-0K3 ?DN"
      using xreal_1_th_68 sorry
    then have A11: "?DN ^2PEPINK1 >XXREAL-0R4 \<one>\<^sub>M"
      using A10 xxreal_0_th_2 sorry
    have "(?DN ^2PEPINK1,(-XCMPLX-0K4 \<one>\<^sub>M)^2PEPINK1)are-congruent-modINT-1R3 p"
      using A6 A5 int_1_th_18 sorry
    then have "?DN ^2PEPINK1 modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using A4 A11 pepin_lm_11 sorry
    then have "\<two>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
      using pepin_lm_8 sorry
    then have A12: "orderPEPINK3(\<two>\<^sub>M,p) dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
      using A4 A8 pepin_th_47 sorry
    have "\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n divNAT-DK3 \<two>\<^sub>M"
      using newton_th_6 sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK1 n"
      using nat_d_th_18 sorry
    finally have "\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK1 n"
       sorry
    then have " not orderPEPINK3(\<two>\<^sub>M,p) dividesNAT-DR1 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M"
      using A1 A2 A4 A7 pepin_th_48 int_2_th_28 int_2_th_30 sorry
    then have "orderPEPINK3(\<two>\<^sub>M,p) =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M)"
      using A12 A9 pepin_th_38 int_2_th_28 nat_d_th_6 sorry
    then have "\<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
      using A1 A2 pepin_th_49 int_2_th_28 int_2_th_30 sorry
    then obtain t2 where
      [ty]:"t2 be NatNAT-1M1" and 
      A13: "p -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *XCMPLX-0K3 t2"
      using nat_d_def_3 sorry
    have 
      [ty]:"t2 be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "p -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using A4 xreal_1_th_9 sorry
    then have "p -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) *NAT-1K2 t2"
      using A13 xreal_0_def_2 sorry
    then have "p =XBOOLE-0R4 t2 *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
    thus " not ( for k be ElementSUBSET-1M1-of NATNUMBERSK1 holds  not p =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_57:
" for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (\<three>\<^sub>M,FermatPEPINK4 n)are-coprimeINT-2R1"
proof-
  have " for n be NatNAT-1M1 holds n <>HIDDENR2 0NUMBERSK6 implies (\<three>\<^sub>M,FermatPEPINK4 n)are-coprimeINT-2R1"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "n <>HIDDENR2 0NUMBERSK6"
    have "FermatPEPINK4 n gcdNAT-DK8 \<three>\<^sub>M <>HIDDENR2 \<three>\<^sub>M"
    proof-
      have "FermatPEPINK4 n gcdNAT-DK8 \<three>\<^sub>M =XBOOLE-0R4 \<three>\<^sub>M implies  False "
      proof(rule impI)
        assume "FermatPEPINK4 n gcdNAT-DK8 \<three>\<^sub>M =XBOOLE-0R4 \<three>\<^sub>M"
        then have "\<three>\<^sub>M dividesNAT-DR1 FermatPEPINK4 n"
          using nat_d_def_5 sorry
        then obtain k where
          [ty]:"k be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A2: "\<three>\<^sub>M =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
          using pepin_th_41 pepin_th_56 sorry
        have "\<one>\<^sub>M =XBOOLE-0R4 k *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (n +NAT-1K1 \<one>\<^sub>M) divNAT-DK3 \<two>\<^sub>M"
          using A2 nat_2_th_3 sorry
        then have "\<one>\<^sub>M =XBOOLE-0R4 k *XCMPLX-0K3 \<two>\<^sub>M  |^NEWTONK1 n"
          using pepin_lm_5 sorry
        then have "\<two>\<^sub>M  |^NEWTONK1 n =XBOOLE-0R4 \<one>\<^sub>M"
          using nat_1_th_15 sorry
        then have "\<two>\<^sub>M  |^NEWTONK1 n =XBOOLE-0R4 \<two>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
          using newton_th_4 sorry
        thus " False "
          using A1 pepin_th_30 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    thus "(\<three>\<^sub>M,FermatPEPINK4 n)are-coprimeINT-2R1"
      using pepin_th_2 pepin_th_41 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
(*\$N Pepin's test*)
mtheorem pepin_th_58:
" for n be NatNAT-1M1 holds (\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n implies FermatPEPINK4 n be primeINT-2V1"
proof-
  have " for n be NatNAT-1M1 holds  not ((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n &  not FermatPEPINK4 n be primeINT-2V1)"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    show " not ((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n &  not FermatPEPINK4 n be primeINT-2V1)"
    proof-
      have cases: "n =XBOOLE-0R4 0NUMBERSK6 or n >XXREAL-0R4 0NUMBERSK6"
         sorry
      have case1: "n =XBOOLE-0R4 0NUMBERSK6 implies  not ((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n &  not FermatPEPINK4 n be primeINT-2V1)"
      proof(rule impI)
        assume "n =XBOOLE-0R4 0NUMBERSK6"
        thus " not ((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n &  not FermatPEPINK4 n be primeINT-2V1)"
          using pepin_th_41 pepin_th_50 sorry
      qed
      have case2: "n >XXREAL-0R4 0NUMBERSK6 implies ((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n implies ( not FermatPEPINK4 n be primeINT-2V1 implies  False ))"
      proof(rule impI,rule impI,rule impI)
        assume A1: "n >XXREAL-0R4 0NUMBERSK6"
        have "FermatPEPINK4 n >XXREAL-0R4 \<two>\<^sub>M"
          using pepin_th_55 sorry
        then obtain p where
          [ty]:"p be ElementSUBSET-1M1-of NATNUMBERSK1" and 
          A2: "p be primeINT-2V1"and A3: "p dividesNAT-DR1 FermatPEPINK4 n"
          using int_2_th_31 sorry
        let ?d = "orderPEPINK3(\<three>\<^sub>M,p)"
        obtain i where
          [ty]:"i be NatNAT-1M1" and 
          A4: "FermatPEPINK4 n =XBOOLE-0R4 p *XCMPLX-0K3 i"
          using A3 nat_d_def_3 sorry
        have A5: "p >XXREAL-0R4 \<two>\<^sub>M"
        proof-
          have "p <=XXREAL-0R1 \<two>\<^sub>M implies  False "
          proof(rule impI)
            assume "p <=XXREAL-0R1 \<two>\<^sub>M"
            then have "p =XBOOLE-0R4 \<two>\<^sub>M or p <XXREAL-0R3 \<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
              using xxreal_0_th_1 sorry
            then have A6: "p =XBOOLE-0R4 \<two>\<^sub>M or p <=XXREAL-0R1 \<one>\<^sub>M"
              using nat_1_th_13 sorry
            have A7: "p <>HIDDENR2 0NUMBERSK6"
              using A2 int_2_def_4 sorry
            have "FermatPEPINK4 n be oddABIANV2"
              using pepin_lm_16 sorry
            then have "FermatPEPINK4 n modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
              using A2 A6 int_2_def_4 nat_2_th_22 sorry
            thus " False "
              using A3 A7 pepin_th_6 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have A8: "FermatPEPINK4 n -XCMPLX-0K6 \<one>\<^sub>M >=XXREAL-0R2 0NUMBERSK6"
           sorry
        assume A9: "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n"
        then have A10: "((\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M))^2PEPINK1,(-XCMPLX-0K4 \<one>\<^sub>M)^2PEPINK1)are-congruent-modINT-1R3 FermatPEPINK4 n"
          using int_1_th_18 sorry
        have "(FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)modNAT-DK4 \<two>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
          using pepin_lm_13 sorry
        then have A11: "(\<three>\<^sub>M  |^NEWTONK11 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M),(-XCMPLX-0K4 \<one>\<^sub>M)^2PEPINK1)are-congruent-modINT-1R3 FermatPEPINK4 n"
          using A10 pepin_th_27 sorry
        let ?DN = "\<two>\<^sub>M  |^NEWTONK1 (\<two>\<^sub>M  |^NEWTONK1 n)"
        assume A12: " not FermatPEPINK4 n be primeINT-2V1"
        have 
          [ty]:"i be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have A13: "\<one>\<^sub>M <XXREAL-0R3 p"
          using A2 int_2_def_4 sorry
        have A14: "p <>HIDDENR2 \<three>\<^sub>M"
        proof-
          have "p =XBOOLE-0R4 \<three>\<^sub>M implies  False "
          proof(rule impI)
            have "\<one>\<^sub>M gcdNAT-DK8 i =XBOOLE-0R4 \<one>\<^sub>M"
              using newton_th_51 sorry
            then have A15: "\<three>\<^sub>M *NAT-1K2 \<one>\<^sub>M gcdNAT-DK8 \<three>\<^sub>M *NAT-1K2 i =XBOOLE-0R4 \<three>\<^sub>M"
              using euler_1_th_5 sorry
            assume "p =XBOOLE-0R4 \<three>\<^sub>M"
            then have " not (\<three>\<^sub>M,FermatPEPINK4 n)are-coprimeINT-2R1"
              using A4 A15 int_2_def_3 sorry
            thus " False "
              using A1 pepin_th_57 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have "?d dividesNAT-DR1 p -'NAT-DK9 \<one>\<^sub>M"
          using A2 pepin_th_41 pepin_th_49 int_2_th_30 sorry
        then obtain x where
          [ty]:"x be NatNAT-1M1" and 
          A16: "p -'NAT-DK9 \<one>\<^sub>M =XBOOLE-0R4 ?d *XCMPLX-0K3 x"
          using nat_d_def_3 sorry
        have A17: "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 p"
          using A9 A4 int_1_th_20 sorry
        have A18: " not ?d dividesNAT-DR1 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M"
        proof-
          have "orderPEPINK3(\<three>\<^sub>M,p) dividesNAT-DR1 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M implies  False "
          proof(rule impI)
            assume "?d dividesNAT-DR1 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M"
            then have "\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
              using A2 A14 A13 pepin_th_41 pepin_th_48 int_2_th_30 sorry
            then have "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),\<one>\<^sub>M)are-congruent-modINT-1R3 p"
              using A13 pepin_th_39 sorry
            then have "(\<one>\<^sub>M,-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 p"
              using A17 pepin_th_40 sorry
            then have "p dividesINT-1R1 \<one>\<^sub>M -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
               sorry
            thus " False "
              using A5 nat_d_th_7 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        then have A19: " not ?d dividesNAT-DR1 ?DN divNAT-DK3 \<two>\<^sub>M"
          using A8 xreal_0_def_2 sorry
        have A20: "(\<three>\<^sub>M,p)are-coprimeINT-2R1"
          using A2 A14 pepin_th_41 int_2_th_30 sorry
        then have A21: "?d <>HIDDENR2 0NUMBERSK6"
          using A13 pepin_def_2 sorry
        have A22: "?d >XXREAL-0R4 \<one>\<^sub>M"
        proof-
          have "orderPEPINK3(\<three>\<^sub>M,p) <=XXREAL-0R1 \<one>\<^sub>M implies  not  True "
          proof(rule impI)
            assume A23: "?d <=XXREAL-0R1 \<one>\<^sub>M"
            have " not  True "
            proof-
              show " not  True "
              proof-
                have cases: "?d <XXREAL-0R3 \<one>\<^sub>M or ?d =XBOOLE-0R4 \<one>\<^sub>M"
                  using A23 xxreal_0_th_1 sorry
                have case1: "orderPEPINK3(\<three>\<^sub>M,p) <XXREAL-0R3 \<one>\<^sub>M implies  not  True "
                proof(rule impI)
                  assume "?d <XXREAL-0R3 \<one>\<^sub>M"
                  thus " not  True "
                    using A21 nat_1_th_14 sorry
                qed
                have case2: "orderPEPINK3(\<three>\<^sub>M,p) =XBOOLE-0R4 \<one>\<^sub>M implies  not  True "
                proof(rule impI)
                  assume "?d =XBOOLE-0R4 \<one>\<^sub>M"
                  thus " not  True "
                    using A18 nat_d_th_6 sorry
                qed
                show " ?thesis "
                  using cases case1 case2 sorry
              qed
            qed
            thus " not  True "
               sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have "\<three>\<^sub>M  |^NEWTONK11 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M) >XXREAL-0R4 \<one>\<^sub>M"
          using pepin_lm_14 pepin_th_25 sorry
        then have "\<three>\<^sub>M  |^NEWTONK11 (FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M) modNAT-DK4 p =XBOOLE-0R4 \<one>\<^sub>M"
          using A4 A13 A11 pepin_lm_11 int_1_th_20 sorry
        then have "?d dividesNAT-DR1 FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M"
          using A20 A13 pepin_th_47 sorry
        then have "?d dividesNAT-DR1 ?DN"
          using A8 xreal_0_def_2 sorry
        then have "?d =HIDDENR1 ?DN"
          using A19 A22 pepin_th_38 int_2_th_28 sorry
        also have "... = FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M"
          using A8 xreal_0_def_2 sorry
        finally have "?d =HIDDENR1 FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M"
           sorry
        then have A24: "?d =XBOOLE-0R4 ?DN"
          using A8 xreal_0_def_2 sorry
        have A25: "p *NAT-1K2 i modNAT-DK4 ?DN =XBOOLE-0R4 \<one>\<^sub>M"
          using A4 pepin_lm_15 sorry
        have "p -XCMPLX-0K6 \<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
          using A13 xreal_1_th_9 sorry
        then have A26: "p -XCMPLX-0K6 \<one>\<^sub>M =XBOOLE-0R4 x *XCMPLX-0K3 ?d"
          using A16 xreal_0_def_2 sorry
        then have A27: "p =XBOOLE-0R4 x *XCMPLX-0K3 ?DN +NAT-1K1 \<one>\<^sub>M"
          using A24 sorry
        then have "p modNAT-DK4 ?DN =HIDDENR1 \<one>\<^sub>M modNAT-DK4 ?DN"
          using nat_d_th_21 sorry
        also have "... = \<one>\<^sub>M"
          using pepin_lm_2 nat_d_th_24 sorry
        finally have "p modNAT-DK4 ?DN =HIDDENR1 \<one>\<^sub>M"
           sorry
        then have "\<one>\<^sub>M *NAT-1K2 i modNAT-DK4 ?DN =XBOOLE-0R4 \<one>\<^sub>M"
          using A25 euler_2_th_8 sorry
        then obtain y where
          [ty]:"y be NatNAT-1M1" and 
          A28: "i =XBOOLE-0R4 ?DN *XCMPLX-0K3 y +NAT-1K1 \<one>\<^sub>M"and "\<one>\<^sub>M <XXREAL-0R3 ?DN"
          using nat_d_def_2 sorry
        have A29: "?DN <>HIDDENR2 0NUMBERSK6"
          using pepin_lm_2 sorry
        have A30: "x >=XXREAL-0R2 \<one>\<^sub>M"
        proof-
          have "x <XXREAL-0R3 \<one>\<^sub>M implies  False "
          proof(rule impI)
            assume "x <XXREAL-0R3 \<one>\<^sub>M"
            then have "p =XBOOLE-0R4 (0NUMBERSK6)*XCMPLX-0K3 ?DN +NAT-1K1 \<one>\<^sub>M"
              using A27 nat_1_th_14 sorry
            thus " False "
              using A2 int_2_def_4 sorry
          qed
          thus " ?thesis "
             sorry
        qed
        have 
          [ty]:"y be ElementSUBSET-1M1-of NATNUMBERSK1"
          using ordinal1_def_12 sorry
        have "FermatPEPINK4 n =HIDDENR1 (x *XCMPLX-0K3 ?DN +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (y *XCMPLX-0K3 ?DN +NAT-1K1 \<one>\<^sub>M)"
          using A4 A24 A26 A28 sorry
        also have "... = ?DN *XCMPLX-0K3 (((x *XCMPLX-0K3 y)*XCMPLX-0K3 ?DN +XCMPLX-0K2 x)+NAT-1K1 y) +NAT-1K1 \<one>\<^sub>M"
           sorry
        finally have "FermatPEPINK4 n =HIDDENR1 ?DN *XCMPLX-0K3 (((x *XCMPLX-0K3 y)*XCMPLX-0K3 ?DN +XCMPLX-0K2 x)+NAT-1K1 y) +NAT-1K1 \<one>\<^sub>M"
           sorry
        then have A31: "\<one>\<^sub>M =HIDDENR1 ?DN *XCMPLX-0K3 (((x *XCMPLX-0K3 y)*XCMPLX-0K3 ?DN +XCMPLX-0K2 x)+NAT-1K1 y) divNAT-DK3 ?DN"
          using A29 pepin_th_44 sorry
        also have "... = ((x *XCMPLX-0K3 y)*XCMPLX-0K3 ?DN +XCMPLX-0K2 x)+NAT-1K1 y"
          using A29 nat_d_th_18 sorry
        finally have "\<one>\<^sub>M =HIDDENR1 ((x *XCMPLX-0K3 y)*XCMPLX-0K3 ?DN +XCMPLX-0K2 x)+NAT-1K1 y"
           sorry
        have "?DN >XXREAL-0R4 \<one>\<^sub>M"
          using pepin_lm_2 sorry
        then have "p =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 ?DN +NAT-1K1 \<one>\<^sub>M"
          using A27 A30 A31 pepin_lm_1 sorry
        also have "... = FermatPEPINK4 n"
           sorry
        finally have "p =HIDDENR1 FermatPEPINK4 n"
           sorry
        thus " False "
          using A12 A2 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_17:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =HIDDENR1 \<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
     sorry
qed

mlemma pepin_lm_18:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M *NAT-1K2 \<nine>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M)"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M"
    using newton_th_8 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M *NAT-1K2 \<nine>\<^sub>M"
    using pepin_lm_17 sorry
qed

mlemma pepin_lm_19:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M)"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M"
    using newton_th_8 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M"
    using pepin_lm_18 sorry
qed

mlemma pepin_lm_20:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<eight>\<^sub>M)"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M"
    using newton_th_8 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M"
    using pepin_lm_19 sorry
qed

mlemma pepin_lm_21:
" for i be NatNAT-1M1 holds FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 i +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for i be NatNAT-1M1 holds FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 i +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix i assume [ty]: "i be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M implies FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A2: "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 FermatPEPINK4 \<one>\<^sub>M *XCMPLX-0K3 m"
          using nat_d_def_3 sorry
        have "\<three>\<^sub>M  |^NEWTONK1 (\<four>\<^sub>M *XCMPLX-0K3 n) >=XXREAL-0R2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
          using prepower_th_93 sorry
        then have "\<three>\<^sub>M  |^NEWTONK1 (\<four>\<^sub>M *XCMPLX-0K3 n) >=XXREAL-0R2 \<one>\<^sub>M"
          using newton_th_4 sorry
        then have "\<three>\<^sub>M  |^NEWTONK1 (\<four>\<^sub>M *XCMPLX-0K3 n) *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M >XXREAL-0R4 (0NUMBERSK6)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M"
          using pepin_lm_17 xreal_1_th_68 sorry
        then have "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using newton_th_8 sorry
        then have "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "(FermatPEPINK4 \<one>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<eight>\<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M"
          using A2 xreal_1_th_68 sorry
        then have "((FermatPEPINK4 \<one>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M >XXREAL-0R4 (\<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M"
          using xreal_1_th_74 sorry
        then have "((m *XCMPLX-0K3 FermatPEPINK4 \<one>\<^sub>M)*XCMPLX-0K3 \<eight>\<one>\<^sub>M)*XCMPLX-0K3 (FermatPEPINK4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5 >XXREAL-0R4 (\<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M"
          using xcmplx_0_def_9 sorry
        then have "((m *XCMPLX-0K3 \<eight>\<one>\<^sub>M)*XCMPLX-0K3 (FermatPEPINK4 \<one>\<^sub>M)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 FermatPEPINK4 \<one>\<^sub>M >XXREAL-0R4 (\<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M"
           sorry
        then have "((m *XCMPLX-0K3 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M)*XCMPLX-0K3 FermatPEPINK4 \<one>\<^sub>M >XXREAL-0R4 (\<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<one>\<^sub>M"
          using xcmplx_0_def_9 sorry
        then have "m *XCMPLX-0K3 \<eight>\<one>\<^sub>M >XXREAL-0R4 \<eight>\<one>\<^sub>M /XCMPLX-0K7 \<five>\<^sub>M"
          using pepin_th_51 xcmplx_1_th_87 sorry
        then have "m *XCMPLX-0K3 \<eight>\<one>\<^sub>M >XXREAL-0R4 \<one>\<six>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have A3: "m *XCMPLX-0K3 \<eight>\<one>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<six>\<^sub>M) >XXREAL-0R4 \<one>\<six>\<^sub>M +XCMPLX-0K2 (-XCMPLX-0K4 \<one>\<six>\<^sub>M)"
          using xreal_1_th_6 sorry
        have "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 ((\<four>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<two>\<^sub>M)+NAT-1K1 \<four>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
        also have "... = (FermatPEPINK4 \<one>\<^sub>M *XCMPLX-0K3 m -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
          using A2 newton_th_8 sorry
        also have "... = FermatPEPINK4 \<one>\<^sub>M *XCMPLX-0K3 (m *XCMPLX-0K3 \<eight>\<one>\<^sub>M -XCMPLX-0K6 \<one>\<six>\<^sub>M)"
          using pepin_lm_18 pepin_th_51 sorry
        also have "... = FermatPEPINK4 \<one>\<^sub>M *NAT-1K2 (m *XCMPLX-0K3 \<eight>\<one>\<^sub>M -'NAT-DK9 \<one>\<six>\<^sub>M)"
          using A3 xreal_0_def_2 sorry
        finally have "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 FermatPEPINK4 \<one>\<^sub>M *NAT-1K2 (m *XCMPLX-0K3 \<eight>\<one>\<^sub>M -'NAT-DK9 \<one>\<six>\<^sub>M)"
           sorry
        thus "FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
          using nat_d_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<five>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using pepin_lm_17 sorry
    then have A4: "?P(0NUMBERSK6)"
      using pepin_th_51 nat_d_def_3 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A1 sorry
    thus "FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M *XCMPLX-0K3 i +NAT-1K1 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_22:
"\<two>\<^sub>M to-powerPOWERK2 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M"
   sorry

mlemma pepin_lm_23:
" for n be NatNAT-1M1 holds n =XBOOLE-0R4 \<one>\<^sub>M implies (\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n"
proof-
  have " for n be NatNAT-1M1 holds n =XBOOLE-0R4 \<one>\<^sub>M implies (\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n"
  proof(rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    have A1: "\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<two>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    also have "... = \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
       sorry
    finally have "\<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
       sorry
    have A2: "\<five>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<five>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
      using xreal_0_def_2 sorry
    also have "... = \<four>\<^sub>M +NAT-1K1 0NUMBERSK6"
       sorry
    finally have "\<five>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<four>\<^sub>M +NAT-1K1 0NUMBERSK6"
       sorry
    have A3: "\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
       sorry
    also have "... = \<two>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
      using newton_th_6 sorry
    also have "... = \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
       sorry
    finally have "\<two>\<^sub>M to-powerPOWERK2 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M *NAT-1K2 \<two>\<^sub>M"
       sorry
    assume A4: "n =XBOOLE-0R4 \<one>\<^sub>M"
    have "\<four>\<^sub>M divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 \<two>\<^sub>M"
      using A1 A3 pepin_lm_22 nat_2_th_16 sorry
    then have "(FermatPEPINK4 \<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 \<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<^sub>M"
      using A2 pepin_th_51 sorry
    then have "FermatPEPINK4 \<one>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      using A4 pepin_lm_21 sorry
    then have "FermatPEPINK4 \<one>\<^sub>M dividesINT-1R1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
       sorry
    thus "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 n -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 n"
      using A4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_24:
" for n be NatNAT-1M1 holds FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
proof-
  have " for n be NatNAT-1M1 holds FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
  proof(rule ballI)
    fix n assume [ty]: "n be NatNAT-1M1"
    let ?P = "\<lambda>Lamb1. FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 Lamb1 +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    have A1: " for n be NatNAT-1M1 holds ?P(n) implies ?P(n +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for n be NatNAT-1M1 holds FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M implies FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
      proof(rule ballI,rule impI)
        fix n assume [ty]: "n be NatNAT-1M1"
        assume "FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
        then obtain m where
          [ty]:"m be NatNAT-1M1" and 
          A2: "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m"
          using nat_d_def_3 sorry
        have "\<three>\<^sub>M  |^NEWTONK1 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n) >=XXREAL-0R2 \<three>\<^sub>M  |^NEWTONK11 (0NUMBERSK6)"
          using prepower_th_93 sorry
        then have "\<three>\<^sub>M  |^NEWTONK1 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n) >=XXREAL-0R2 \<one>\<^sub>M"
          using newton_th_4 sorry
        then have "\<three>\<^sub>M  |^NEWTONK1 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n) *XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M >XXREAL-0R4 (0NUMBERSK6)*NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M"
          using pepin_lm_19 xreal_1_th_68 sorry
        then have "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) >XXREAL-0R4 0NUMBERSK6"
          using newton_th_8 sorry
        then have "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M >XXREAL-0R4 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
          using xreal_1_th_6 sorry
        then have "(FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M >XXREAL-0R4 \<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M"
          using A2 xreal_1_th_68 sorry
        then have "((FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M >XXREAL-0R4 \<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M"
          using xreal_1_th_68 sorry
        then have "((FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M >XXREAL-0R4 \<six>\<five>\<six>\<two>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M"
          using xxreal_0_th_2 sorry
        then have "(((FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M >XXREAL-0R4 (\<six>\<five>\<six>\<zero>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<two>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M"
          using xreal_1_th_74 sorry
        then have "(((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 FermatPEPINK4 \<two>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 (FermatPEPINK4 \<two>\<^sub>M)\<inverse>XCMPLX-0K5 >XXREAL-0R4 (\<six>\<five>\<six>\<zero>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<two>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M"
          using xcmplx_0_def_9 sorry
        then have "(((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 (FermatPEPINK4 \<two>\<^sub>M)\<inverse>XCMPLX-0K5)*XCMPLX-0K3 FermatPEPINK4 \<two>\<^sub>M >XXREAL-0R4 (\<six>\<five>\<six>\<zero>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<two>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M"
           sorry
        then have "(((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M)*XCMPLX-0K3 FermatPEPINK4 \<two>\<^sub>M >XXREAL-0R4 (\<six>\<five>\<six>\<zero>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<two>\<^sub>M)/XCMPLX-0K7 FermatPEPINK4 \<two>\<^sub>M"
          using xcmplx_0_def_9 sorry
        then have "(m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M >XXREAL-0R4 (\<six>\<five>\<six>\<zero>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<two>\<^sub>M)/XCMPLX-0K7 \<one>\<seven>\<^sub>M"
          using pepin_th_52 xcmplx_1_th_87 sorry
        then have A3: "(m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M -XCMPLX-0K6 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M >XXREAL-0R4 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M -XCMPLX-0K6 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M"
          using xreal_1_th_9 sorry
        have "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 ((\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M)+NAT-1K1 \<one>\<six>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
           sorry
        also have "... = (FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 m -XCMPLX-0K6 \<one>\<^sub>M)*XCMPLX-0K3 \<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M +XCMPLX-0K2 \<one>\<^sub>M"
          using A2 newton_th_8 sorry
        also have "... = FermatPEPINK4 \<two>\<^sub>M *XCMPLX-0K3 ((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M -XCMPLX-0K6 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M)"
          using pepin_lm_20 pepin_th_52 sorry
        also have "... = FermatPEPINK4 \<two>\<^sub>M *NAT-1K2 ((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M -'NAT-DK9 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M)"
          using A3 xreal_0_def_2 sorry
        finally have "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *NAT-1K2 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =HIDDENR1 FermatPEPINK4 \<two>\<^sub>M *NAT-1K2 ((m *XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M)*XCMPLX-0K3 \<six>\<five>\<six>\<one>\<^sub>M -'NAT-DK9 \<three>\<eight>\<six>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<zero>\<^sub>M)"
           sorry
        thus "FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 (n +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
          using nat_d_def_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "\<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 \<one>\<seven>\<^sub>M *NAT-1K2 \<three>\<eight>\<six>\<^sub>M"
      using pepin_lm_19 sorry
    then have A4: "?P(0NUMBERSK6)"
      using pepin_th_52 nat_d_def_3 sorry
    have " for n be NatNAT-1M1 holds ?P(n)"
      using nat_1_sch_2 A4 A1 sorry
    thus "FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M *XCMPLX-0K3 n +NAT-1K1 \<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_25:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<nine>\<^sub>M"
  proof-
    have A1: "\<nine>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<nine>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<nine>\<^sub>M"
      using A1 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<nine>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_26:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<eight>\<one>\<^sub>M"
  proof-
    have A1: "\<eight>\<one>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<eight>\<one>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = (\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M)*NAT-1K2 (\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using euler_2_th_9 sorry
    also have "... = \<eight>\<one>\<^sub>M"
      using A1 pepin_lm_25 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<eight>\<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_27:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<one>\<three>\<six>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<one>\<three>\<six>\<^sub>M"
  proof-
    have A1: "\<six>\<five>\<six>\<one>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<one>\<three>\<six>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = (\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M)*NAT-1K2 (\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using euler_2_th_9 sorry
    also have "... = \<one>\<three>\<six>\<^sub>M"
      using A1 pepin_lm_26 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<one>\<three>\<six>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_28:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
  proof-
    have A1: "\<one>\<eight>\<four>\<nine>\<six>\<^sub>M =XBOOLE-0R4 \<seven>\<one>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<two>\<four>\<nine>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<one>\<three>\<six>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using pepin_lm_27 euler_2_th_9 sorry
    also have "... = \<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
      using A1 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_29:
"\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
proof-
  have A1: "((\<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M)*NAT-1K2 \<eight>\<three>\<^sub>M)*NAT-1K2 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<four>\<one>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<six>\<four>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M +NAT-1K1 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
    using newton_th_8 sorry
  also have "... = (\<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M)*NAT-1K2 (\<eight>\<three>\<^sub>M *NAT-1K2 \<three>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
    using pepin_lm_28 euler_2_th_9 sorry
  also have "... = \<six>\<four>\<^sub>M"
    using A1 pepin_th_53 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<six>\<four>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
     sorry
qed

mlemma pepin_lm_30:
"\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<four>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<four>\<one>\<^sub>M"
  proof-
    have A1: "\<four>\<zero>\<nine>\<six>\<^sub>M =XBOOLE-0R4 \<one>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<two>\<four>\<one>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M +NAT-1K1 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<six>\<four>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using pepin_lm_29 euler_2_th_9 sorry
    also have "... = \<two>\<four>\<one>\<^sub>M"
      using A1 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<four>\<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_31:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M"
  proof-
    have A1: "\<two>\<four>\<one>\<^sub>M *NAT-1K2 \<two>\<four>\<one>\<^sub>M =XBOOLE-0R4 \<two>\<two>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M +NAT-1K1 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<two>\<four>\<one>\<^sub>M *NAT-1K2 \<two>\<four>\<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
      using pepin_lm_30 euler_2_th_9 sorry
    also have "... = \<two>\<five>\<six>\<^sub>M"
      using A1 pepin_th_53 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_32:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<nine>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<nine>\<^sub>M"
  proof-
    have A1: "\<nine>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<nine>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<^sub>M +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<nine>\<^sub>M"
      using A1 pepin_th_54 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<nine>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_33:
"\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<eight>\<one>\<^sub>M"
  proof-
    have A1: "\<eight>\<one>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<one>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<^sub>M +NAT-1K1 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<nine>\<^sub>M *NAT-1K2 \<nine>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
      using pepin_lm_32 euler_2_th_9 sorry
    also have "... = \<eight>\<one>\<^sub>M"
      using A1 pepin_th_54 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<eight>\<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_34:
"\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<one>\<^sub>M"
proof-
  have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<six>\<five>\<six>\<one>\<^sub>M"
  proof-
    have A1: "\<six>\<five>\<six>\<one>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<six>\<five>\<six>\<one>\<^sub>M"
       sorry
    have "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
       sorry
    also have "... = \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
      using newton_th_8 sorry
    also have "... = \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
      using pepin_lm_33 euler_2_th_9 sorry
    also have "... = \<six>\<five>\<six>\<one>\<^sub>M"
      using A1 pepin_th_54 nat_d_def_2 sorry
    finally show "\<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<six>\<five>\<six>\<one>\<^sub>M"
       sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma pepin_lm_35:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
proof-
  have A1: "\<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M =XBOOLE-0R4 \<six>\<five>\<six>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 (\<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using newton_th_8 sorry
  also have "... = \<six>\<five>\<six>\<one>\<^sub>M *NAT-1K2 \<six>\<five>\<six>\<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_34 euler_2_th_9 sorry
  also have "... = \<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
qed

mlemma pepin_lm_36:
"\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
proof-
  have A1: "(\<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (\<two>\<six>\<three>\<^sub>M *NAT-1K2 \<one>\<seven>\<two>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<six>\<^sub>M +NAT-1K1 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using newton_th_8 sorry
  also have "... = (\<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<one>\<six>\<four>\<^sub>M *NAT-1K2 \<three>\<three>\<two>\<^sub>M +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_35 euler_2_th_9 sorry
  also have "... = \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M"
     sorry
qed

mlemma pepin_lm_37:
"\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
proof-
  have A1: "(\<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M)*NAT-1K2 (\<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M) =XBOOLE-0R4 (\<three>\<two>\<five>\<^sub>M +NAT-1K1 \<two>\<four>\<one>\<^sub>M *NAT-1K2 \<two>\<four>\<one>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 (\<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M +NAT-1K1 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<three>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using newton_th_8 sorry
  also have "... = (\<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M)*NAT-1K2 (\<one>\<two>\<three>\<^sub>M *NAT-1K2 \<five>\<zero>\<three>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_36 euler_2_th_9 sorry
  also have "... = \<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M"
     sorry
qed

mlemma pepin_lm_38:
"\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
proof-
  have A1: "(\<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 \<five>\<five>\<eight>\<nine>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M +NAT-1K1 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using newton_th_8 sorry
  also have "... = (\<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<one>\<four>\<^sub>M *NAT-1K2 \<one>\<three>\<six>\<seven>\<^sub>M +NAT-1K1 \<one>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_37 euler_2_th_9 sorry
  also have "... = \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M"
     sorry
qed

mlemma pepin_lm_39:
"\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<eight>\<two>\<^sub>M"
proof-
  have A1: "(\<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M)*NAT-1K2 (\<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M) =XBOOLE-0R4 \<three>\<four>\<four>\<six>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<eight>\<two>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<one>\<two>\<eight>\<^sub>M +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<one>\<two>\<eight>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using newton_th_8 sorry
  also have "... = (\<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M)*NAT-1K2 (\<five>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<nine>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_38 euler_2_th_9 sorry
  also have "... = \<two>\<eight>\<two>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<eight>\<two>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<eight>\<two>\<^sub>M"
     sorry
qed

mlemma pepin_lm_40:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
proof-
  have A1: "\<two>\<eight>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<two>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<five>\<one>\<two>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 \<two>\<five>\<six>\<^sub>M =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<five>\<one>\<two>\<^sub>M"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<eight>\<two>\<^sub>M *NAT-1K2 \<two>\<eight>\<two>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_39 euler_2_th_9 sorry
  also have "... = \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M"
     sorry
qed

mlemma pepin_lm_41:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
proof-
  have A1: "(\<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M)*NAT-1K2 (\<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M) =XBOOLE-0R4 \<two>\<nine>\<eight>\<five>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<one>\<zero>\<two>\<four>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<one>\<zero>\<two>\<four>\<^sub>M"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 (\<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M)*NAT-1K2 (\<seven>\<one>\<^sub>M *NAT-1K2 \<one>\<nine>\<seven>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_40 euler_2_th_9 sorry
  also have "... = \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M"
     sorry
qed

mlemma pepin_lm_42:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
proof-
  have A1: "(\<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M)*NAT-1K2 (\<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M) =XBOOLE-0R4 \<one>\<zero>\<three>\<one>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<two>\<zero>\<four>\<eight>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<four>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<two>\<zero>\<four>\<eight>\<^sub>M"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 (\<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M)*NAT-1K2 (\<three>\<two>\<^sub>M *NAT-1K2 \<two>\<five>\<seven>\<^sub>M) modNAT-DK4 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)"
    using pepin_lm_41 pepin_th_54 euler_2_th_9 sorry
  also have "... = \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
    using A1 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M"
     sorry
qed

mlemma pepin_lm_43:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
proof-
  have A1: "(\<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M)*NAT-1K2 (\<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M) =XBOOLE-0R4 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<five>\<^sub>M +NAT-1K1 \<two>\<four>\<one>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<six>\<four>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<four>\<zero>\<nine>\<six>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<four>\<zero>\<nine>\<six>\<^sub>M"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 (\<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M)*NAT-1K2 (\<eight>\<one>\<^sub>M *NAT-1K2 \<eight>\<zero>\<nine>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_42 euler_2_th_9 sorry
  also have "... = \<six>\<four>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<six>\<four>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<four>\<^sub>M"
     sorry
qed

mlemma pepin_lm_44:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
proof-
  have A1: "\<six>\<four>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M =XBOOLE-0R4 (0NUMBERSK6)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 \<eight>\<one>\<nine>\<two>\<^sub>M"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 \<eight>\<one>\<nine>\<two>\<^sub>M"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<six>\<four>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_43 euler_2_th_9 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
     sorry
qed

mlemma pepin_lm_45:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
proof-
  have A1: "(\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) =XBOOLE-0R4 \<two>\<five>\<five>\<^sub>M *NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 (\<three>\<two>\<^sub>M +NAT-1K1 \<three>\<two>\<^sub>M))"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<three>\<two>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 (\<three>\<two>\<^sub>M +NAT-1K1 \<three>\<two>\<^sub>M))"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_44 euler_2_th_9 sorry
  also have "... = \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M"
     sorry
qed

mlemma pepin_lm_46:
"\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
proof-
  have A1: "(\<two>\<five>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (\<two>\<five>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 (\<two>\<five>\<five>\<^sub>M *NAT-1K2 \<two>\<five>\<five>\<^sub>M)*NAT-1K2 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
     sorry
  have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M)"
    using newton_th_8 sorry
  also have "... = \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 (\<six>\<four>\<^sub>M +NAT-1K1 \<six>\<four>\<^sub>M))"
     sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) *NAT-1K2 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<six>\<four>\<^sub>M) =HIDDENR1 \<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 (\<six>\<four>\<^sub>M +NAT-1K1 \<six>\<four>\<^sub>M))"
     sorry
  then have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 (\<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M)*NAT-1K2 (\<six>\<seven>\<three>\<^sub>M *NAT-1K2 \<nine>\<seven>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M"
    using pepin_lm_45 euler_2_th_9 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
    using A1 pepin_th_54 nat_d_def_2 sorry
  finally have "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
     sorry
  thus "\<three>\<^sub>M  |^NEWTONK11 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
     sorry
qed

mlemma pepin_lm_47:
"FermatPEPINK4 \<three>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
proof-
  have A1: "\<two>\<five>\<seven>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<seven>\<^sub>M *NAT-1K2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have "\<one>\<^sub>M =XBOOLE-0R4 \<two>\<five>\<seven>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
     sorry
  then have "\<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using pepin_th_53 nat_d_def_2 sorry
  then have "(\<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 (\<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M"
    using pepin_lm_31 euler_2_th_6 sorry
  also have "... = 0NUMBERSK6"
    using A1 pepin_th_53 nat_d_def_2 sorry
  finally have "(\<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 FermatPEPINK4 \<three>\<^sub>M =HIDDENR1 0NUMBERSK6"
     sorry
  thus "FermatPEPINK4 \<three>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<three>\<two>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    using pepin_th_7 nat_d_th_6 sorry
qed

mlemma pepin_lm_48:
"FermatPEPINK4 \<four>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
proof-
  have "\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M =XBOOLE-0R4 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 \<one>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  then have A1: "(\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
    using pepin_th_54 nat_d_def_2 sorry
  have "\<one>\<^sub>M =XBOOLE-0R4 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)*NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<one>\<^sub>M"
     sorry
  then have "\<one>\<^sub>M modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 \<one>\<^sub>M"
    using pepin_th_54 nat_d_def_2 sorry
  then have "(\<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M)modNAT-DK4 FermatPEPINK4 \<four>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
    using A1 pepin_lm_46 euler_2_th_6 sorry
  thus "FermatPEPINK4 \<four>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 (\<six>\<four>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    using pepin_th_7 nat_d_th_6 sorry
qed

mtheorem pepin_th_59:
"\<five>\<^sub>M be primeINT-2V1"
proof-
  have "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<one>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 \<one>\<^sub>M"
    using pepin_lm_23 sorry
  thus "\<five>\<^sub>M be primeINT-2V1"
    using pepin_th_51 pepin_th_58 sorry
qed

mtheorem pepin_th_60:
"\<one>\<seven>\<^sub>M be primeINT-2V1"
proof-
  have A1: "\<four>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<four>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<three>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "\<four>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<three>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have A2: "\<one>\<seven>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<one>\<seven>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<one>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "\<one>\<seven>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<one>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have "\<one>\<six>\<^sub>M divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 \<eight>\<^sub>M"
    using A1 power_th_61 power_th_62 nat_2_th_16 pepin_lm_22 sorry
  then have "(FermatPEPINK4 \<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M =XBOOLE-0R4 \<one>\<six>\<^sub>M *NAT-1K2 (0NUMBERSK6) +NAT-1K1 \<eight>\<^sub>M"
    using A2 pepin_th_52 sorry
  then have "FermatPEPINK4 \<two>\<^sub>M dividesNAT-DR1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) +NAT-1K1 \<one>\<^sub>M"
    using pepin_lm_24 sorry
  then have "FermatPEPINK4 \<two>\<^sub>M dividesINT-1R1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
     sorry
  then have "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<two>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 \<two>\<^sub>M"
     sorry
  thus "\<one>\<seven>\<^sub>M be primeINT-2V1"
    using pepin_th_52 pepin_th_58 sorry
qed

mtheorem pepin_th_61:
"\<two>\<five>\<seven>\<^sub>M be primeINT-2V1"
proof-
  have A1: "\<eight>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<eight>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<seven>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "\<eight>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<seven>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have A2: "\<two>\<five>\<seven>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<two>\<five>\<seven>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "\<two>\<five>\<seven>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have "\<two>\<^sub>M to-powerPOWERK2 \<eight>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<four>\<^sub>M)"
     sorry
  also have "... = \<one>\<six>\<^sub>M *NAT-1K2 \<one>\<six>\<^sub>M"
    using newton_th_8 power_th_62 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M"
     sorry
  finally have "\<two>\<^sub>M to-powerPOWERK2 \<eight>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M"
     sorry
  then have "\<two>\<five>\<six>\<^sub>M divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<eight>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using pepin_lm_22 nat_2_th_16 sorry
  also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<three>\<^sub>M)"
    using A1 sorry
  also have "... = \<one>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M"
    using newton_th_8 power_th_61 power_th_62 sorry
  also have "... = \<one>\<two>\<eight>\<^sub>M"
     sorry
  finally have "\<two>\<five>\<six>\<^sub>M divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<one>\<two>\<eight>\<^sub>M"
     sorry
  then have "FermatPEPINK4 \<three>\<^sub>M dividesINT-1R1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<three>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
    using A2 pepin_lm_47 pepin_th_53 sorry
  then have "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<three>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 \<three>\<^sub>M"
     sorry
  thus "\<two>\<five>\<seven>\<^sub>M be primeINT-2V1"
    using pepin_th_53 pepin_th_58 sorry
qed

mtheorem pepin_th_62:
"\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M be primeINT-2V1"
proof-
  have A1: "\<one>\<six>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<one>\<six>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<one>\<five>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "\<one>\<six>\<^sub>M -'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<one>\<five>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have A2: "(\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M =HIDDENR1 (\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-XCMPLX-0K6 \<one>\<^sub>M"
    using xreal_0_def_2 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  finally have "(\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M)-'NAT-DK9 \<one>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 0NUMBERSK6"
     sorry
  have "\<two>\<^sub>M to-powerPOWERK2 \<one>\<six>\<^sub>M =HIDDENR1 \<two>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<eight>\<^sub>M)"
     sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
    using pepin_lm_7 newton_th_8 sorry
  finally have "\<two>\<^sub>M to-powerPOWERK2 \<one>\<six>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M"
     sorry
  then have "\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<two>\<^sub>M to-powerPOWERK2 (\<one>\<six>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)"
    using pepin_lm_22 nat_2_th_16 sorry
  also have "... = \<two>\<^sub>M  |^NEWTONK11 (\<eight>\<^sub>M +NAT-1K1 \<seven>\<^sub>M)"
    using A1 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<^sub>M  |^NEWTONK11 (\<four>\<^sub>M +NAT-1K1 \<three>\<^sub>M)"
    using pepin_lm_7 newton_th_8 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 (\<one>\<six>\<^sub>M *NAT-1K2 \<eight>\<^sub>M)"
    using newton_th_8 power_th_61 power_th_62 sorry
  also have "... = \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M"
     sorry
  finally have "\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M divNAT-DK3 \<two>\<^sub>M =HIDDENR1 \<two>\<five>\<six>\<^sub>M *NAT-1K2 \<one>\<two>\<eight>\<^sub>M"
     sorry
  then have "FermatPEPINK4 \<four>\<^sub>M dividesINT-1R1 \<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<four>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M) -XCMPLX-0K6 (-XCMPLX-0K4 \<one>\<^sub>M)"
    using A2 pepin_lm_48 pepin_th_54 sorry
  then have "(\<three>\<^sub>M  |^NEWTONK11 ((FermatPEPINK4 \<four>\<^sub>M -'NAT-DK9 \<one>\<^sub>M)divNAT-DK3 \<two>\<^sub>M),-XCMPLX-0K4 \<one>\<^sub>M)are-congruent-modINT-1R3 FermatPEPINK4 \<four>\<^sub>M"
     sorry
  thus "\<two>\<five>\<six>\<^sub>M *NAT-1K2 \<two>\<five>\<six>\<^sub>M +NAT-1K1 \<one>\<^sub>M be primeINT-2V1"
    using pepin_th_54 pepin_th_58 sorry
qed

mtheorem pepin_th_63:
" for i be IntegerINT-1M1 holds  for j be IntegerINT-1M1 holds j <>HIDDENR2 0NUMBERSK6 & i modINT-1K6 j =HIDDENR1 0NUMBERSK6 implies i divINT-1K5 j =HIDDENR1 i /XCMPLX-0K7 j"
proof(rule ballI,rule ballI,rule impMI ,rule impI)
  fix i assume [ty]: "i be IntegerINT-1M1"
  fix j assume [ty]: "j be IntegerINT-1M1"
  assume A1: "j <>HIDDENR2 0NUMBERSK6"
    and A2: "i modINT-1K6 j =HIDDENR1 0NUMBERSK6"
  have "i =HIDDENR1 (i divINT-1K5 j)*XCMPLX-0K3 j +XCMPLX-0K2 (i modINT-1K6 j)"
    using A1 int_1_th_59 sorry
  also have "... = (i divINT-1K5 j)*XCMPLX-0K3 j"
    using A2 sorry
  finally have "i =HIDDENR1 (i divINT-1K5 j)*XCMPLX-0K3 j"
     sorry
  thus "i divINT-1K5 j =HIDDENR1 i /XCMPLX-0K7 j"
    using A1 xcmplx_1_th_89 sorry
qed "sorry"

mtheorem pepin_th_64:
" for i be NatNAT-1M1 holds  for n be NatNAT-1M1 holds n >XXREAL-0R4 0NUMBERSK6 implies i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
proof(rule ballI,rule ballI,rule impI)
  fix i assume [ty]: "i be NatNAT-1M1"
  fix n assume [ty]: "n be NatNAT-1M1"
  assume A1: "n >XXREAL-0R4 0NUMBERSK6"
  show "i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
  proof-
    have cases: "i >XXREAL-0R4 0NUMBERSK6 or i =XBOOLE-0R4 0NUMBERSK6"
       sorry
    have case1: "i >XXREAL-0R4 0NUMBERSK6 implies i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
    proof(rule impI)
      assume A2: "i >XXREAL-0R4 0NUMBERSK6"
      have "i  |^NEWTONK1 n modNAT-DK4 i =XBOOLE-0R4 0NUMBERSK6"
        using A1 pepin_th_36 sorry
      thus "i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
        using A2 pepin_th_63 sorry
    qed
    have case2: "i =XBOOLE-0R4 0NUMBERSK6 implies i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
    proof(rule impI)
      assume A3: "i =XBOOLE-0R4 0NUMBERSK6"
      have "n >=XXREAL-0R2 0NUMBERSK6 +NAT-1K1 \<one>\<^sub>M"
        using A1 nat_1_th_13 sorry
      then have "i  |^NEWTONK1 n =XBOOLE-0R4 0NUMBERSK6"
        using A3 newton_th_11 sorry
      thus "i  |^NEWTONK1 n divNAT-DK3 i =XBOOLE-0R4 i  |^NEWTONK1 n /XCMPLX-0K7 i"
        using A3 nat_d_def_1 sorry
    qed
    show " ?thesis "
      using cases case1 case2 sorry
  qed
qed "sorry"

reserve r for "RealXREAL-0M1"
mtheorem pepin_th_65:
" for r be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n & \<one>\<^sub>M <XXREAL-0R3 r implies \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 n"
proof-
  have " for r be RealXREAL-0M1 holds  for n be NatNAT-1M1 holds 0NUMBERSK6 <XXREAL-0R3 n & r >XXREAL-0R4 \<one>\<^sub>M implies  not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "0NUMBERSK6 <XXREAL-0R3 n"
      and A2: "r >XXREAL-0R4 \<one>\<^sub>M"
    let ?P = "\<lambda>Lamb1. 0NUMBERSK6 <XXREAL-0R3 Lamb1 implies \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 Lamb1"
    have A3: " for k be NatNAT-1M1 holds ?P(k) implies ?P(k +NAT-1K1 \<one>\<^sub>M)"
    proof-
      have " for k be NatNAT-1M1 holds ?P(k) & 0NUMBERSK6 <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M implies  not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
      proof(rule ballI,rule impMI ,rule impI)
        fix k assume [ty]: "k be NatNAT-1M1"
        assume A4: "?P(k)"
          and "0NUMBERSK6 <XXREAL-0R3 k +NAT-1K1 \<one>\<^sub>M"
        show " not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
        proof-
          have cases: "k >XXREAL-0R4 0NUMBERSK6 or k =XBOOLE-0R4 0NUMBERSK6"
             sorry
          have case1: "k >XXREAL-0R4 0NUMBERSK6 implies  not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume "k >XXREAL-0R4 0NUMBERSK6"
            then have "r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M) =XBOOLE-0R4 r  |^NEWTONK1 k *XCMPLX-0K3 r & \<one>\<^sub>M *XCMPLX-0K3 r <=XXREAL-0R1 r  |^NEWTONK1 k *XCMPLX-0K3 r"
              using A2 A4 newton_th_6 xreal_1_th_64 sorry
            thus " not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A2 xxreal_0_th_2 sorry
          qed
          have case2: "k =XBOOLE-0R4 0NUMBERSK6 implies  not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
          proof(rule impI)
            assume "k =XBOOLE-0R4 0NUMBERSK6"
            thus " not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 (k +NAT-1K1 \<one>\<^sub>M)"
              using A2 sorry
          qed
          show " ?thesis "
            using cases case1 case2 sorry
        qed
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: "?P(0NUMBERSK6)"
       sorry
    have " for k be NatNAT-1M1 holds ?P(k)"
      using nat_1_sch_2 A5 A3 sorry
    thus " not \<one>\<^sub>M <XXREAL-0R3 r  |^NEWTONK1 n"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem pepin_th_66:
" for r be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds r >XXREAL-0R4 \<one>\<^sub>M & m >XXREAL-0R4 n implies r  |^NEWTONK1 m >XXREAL-0R4 r  |^NEWTONK1 n"
proof-
  have " for r be RealXREAL-0M1 holds  for m be NatNAT-1M1 holds  for n be NatNAT-1M1 holds r >XXREAL-0R4 \<one>\<^sub>M & m >XXREAL-0R4 n implies  not r  |^NEWTONK1 m >XXREAL-0R4 r  |^NEWTONK1 n"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix r assume [ty]: "r be RealXREAL-0M1"
    fix m assume [ty]: "m be NatNAT-1M1"
    fix n assume [ty]: "n be NatNAT-1M1"
    assume A1: "r >XXREAL-0R4 \<one>\<^sub>M"
      and A2: "m >XXREAL-0R4 n"
    have 
      [ty]:"m be ElementSUBSET-1M1-of NATNUMBERSK1" and
      [ty]:"n be ElementSUBSET-1M1-of NATNUMBERSK1"
      using ordinal1_def_12 sorry
    have "(m -'NAT-DK9 n)+NAT-1K1 n =XBOOLE-0R4 m"
      using A2 xreal_1_th_235 sorry
    then have A3: "r  |^NEWTONK1 m =XBOOLE-0R4 r  |^NEWTONK1 (m -'NAT-DK9 n) *XCMPLX-0K3 r  |^NEWTONK1 n"
      using newton_th_8 sorry
    have "m -'NAT-DK9 n <>HIDDENR2 0NUMBERSK6"
      using A2 nat_d_th_36 sorry
    then have "r  |^NEWTONK1 (m -'NAT-DK9 n) >XXREAL-0R4 \<one>\<^sub>M"
      using A1 pepin_th_65 sorry
    thus " not r  |^NEWTONK1 m >XXREAL-0R4 r  |^NEWTONK1 n"
      using A1 A3 newton_th_83 xreal_1_th_155 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
