theory measure5
  imports rcomp_1 supinf_2
   "../mizar_extension/E_number"
begin
(*begin*)
reserve a, b for "R-ealSUPINF-1M1"
theorem measure5_sch_1:
  fixes Pp1 
  shows " for X1 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for X2 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X1 iff Pp1(x)) & ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X2 iff Pp1(x)) implies X1 =MEMBEREDR9 X2"
  proof-
    have " for A1 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for A2 be SubsetSUBSET-1M2-of REALNUMBERSK2 holds ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 A1 iff Pp1(x)) & ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 A2 iff Pp1(x)) implies A1 =MEMBEREDR9 A2"
    proof(rule ballI,rule ballI,rule impMI ,rule impI)
      fix A1 assume [ty]: "A1 be SubsetSUBSET-1M2-of REALNUMBERSK2"
      fix A2 assume [ty]: "A2 be SubsetSUBSET-1M2-of REALNUMBERSK2"
      assume A1: " for x be R-ealSUPINF-1M1 holds x inTARSKIR2 A1 iff Pp1(x)"
        and A2: " for x be R-ealSUPINF-1M1 holds x inTARSKIR2 A2 iff Pp1(x)"
      have "A1 c=MEMBEREDR3 A2 & A2 c=TARSKIR1 A1"
      proof(rule conjMI)
        show "A1 c=MEMBEREDR3 A2"
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 A1 implies x inHIDDENR3 A2"
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A3: "x inHIDDENR3 A1"
            then have "x inHIDDENR3 REALNUMBERSK2"
               sorry
            then have 
              [ty]:"x be R-ealSUPINF-1M1"
              using numbers_th_31 sorry
            have "Pp1(x)"
              using A1 A3 sorry
            thus "x inHIDDENR3 A2"
              using A2 sorry
          qed "sorry"
          thus "A1 c=MEMBEREDR3 A2"
            using membered_def_9 sorry
        qed
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 A2 implies x inHIDDENR3 A1"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          assume A4: "x inHIDDENR3 A2"
          then have "x inHIDDENR3 REALNUMBERSK2"
             sorry
          then have 
            [ty]:"x be R-ealSUPINF-1M1"
            using numbers_th_31 sorry
          have "Pp1(x)"
            using A2 A4 sorry
          thus "x inHIDDENR3 A1"
            using A1 sorry
        qed "sorry"
        thus "A2 c=TARSKIR1 A1"
          using membered_def_9 sorry
      qed
      thus "A1 =MEMBEREDR9 A2"
        using xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed

abbreviation(input) MEASURE5K1("].MEASURE5K1 _ , _ .[" [0,0]164) where
  "].MEASURE5K1 a,b .[ \<equiv> ].XXREAL-1K4 a,b .["

mtheorem measure5_def_1:
  mlet "a be R-ealSUPINF-1M1", "b be R-ealSUPINF-1M1"
"redefine func ].MEASURE5K1 a,b .[ \<rightarrow> SubsetSUBSET-1M2-of REALNUMBERSK2 means
  \<lambda>it.  for x be R-ealSUPINF-1M1 holds x inTARSKIR2 it iff a <XXREAL-0R3 x & x <XXREAL-0R3 b"
proof
(*compatibility*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it =HIDDENR1 ].MEASURE5K1 a,b .[ iff ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 it iff a <XXREAL-0R3 x & x <XXREAL-0R3 b)"
  proof-
    have " for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds (X =MEMBEREDR9 ].RCOMP-1K2 a,b .[ implies ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X iff a <XXREAL-0R3 x & x <XXREAL-0R3 b)) & (( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X iff a <XXREAL-0R3 x & x <XXREAL-0R3 b) implies X =HIDDENR1 ].XXREAL-1K4 a,b .[)"
    proof(rule ballI,rule conjMI,rule impI)
      fix X assume [ty]: "X be SubsetSUBSET-1M2-of REALNUMBERSK2"
      show "X =MEMBEREDR9 ].RCOMP-1K2 a,b .[ implies ( for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X iff a <XXREAL-0R3 x & x <XXREAL-0R3 b)"
        using xxreal_1_th_4 sorry
      assume A1: " for x be R-ealSUPINF-1M1 holds x inTARSKIR2 X iff a <XXREAL-0R3 x & x <XXREAL-0R3 b"
      have "X c=MEMBEREDR3 ].RCOMP-1K2 a,b .[ & ].XXREAL-1K4 a,b .[ c=TARSKIR1 X"
      proof(rule conjMI)
        show "X c=MEMBEREDR3 ].RCOMP-1K2 a,b .["
        proof-
          have " for x be RealXREAL-0M1 holds x inHIDDENR3 X implies x inHIDDENR3 ].RCOMP-1K2 a,b .["
          proof(rule ballI,rule impI)
            fix x assume [ty]: "x be RealXREAL-0M1"
            assume A2: "x inHIDDENR3 X"
            then have "x inHIDDENR3 REALNUMBERSK2"
               sorry
            then obtain t where 
              [ty]:"t be R-ealSUPINF-1M1" and tDef:"t = x"
              using numbers_th_31 sorry
            have "a <XXREAL-0R3 t & t <XXREAL-0R3 b"
              using A1 A2 sorry
            thus "x inHIDDENR3 ].RCOMP-1K2 a,b .["
               sorry
          qed "sorry"
          thus "X c=MEMBEREDR3 ].RCOMP-1K2 a,b .["
            using membered_def_9 sorry
        qed
        have " for x be RealXREAL-0M1 holds x inHIDDENR3 ].RCOMP-1K2 a,b .[ implies x inHIDDENR3 X"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be RealXREAL-0M1"
          obtain t where 
            [ty]:"t be R-ealSUPINF-1M1" and tDef:"t = x"
            using xxreal_0_def_1 sorry
          assume "x inHIDDENR3 ].RCOMP-1K2 a,b .["
          then have "a <XXREAL-0R3 t & t <XXREAL-0R3 b"
            using xxreal_1_th_4 sorry
          thus "x inHIDDENR3 X"
            using A1 sorry
        qed "sorry"
        thus "].XXREAL-1K4 a,b .[ c=TARSKIR1 X"
          using membered_def_9 sorry
      qed
      thus "X =HIDDENR1 ].XXREAL-1K4 a,b .["
        using xboole_0_def_10 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem measure5_add_1:
  mlet "a be R-ealSUPINF-1M1", "b be R-ealSUPINF-1M1"
"cluster ].XXREAL-1K4 a,b .[ as-term-is SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show "].XXREAL-1K4 a,b .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
  proof-
    have " for x be setHIDDENM2 holds x inTARSKIR2 ].RCOMP-1K2 a,b .[ implies x inTARSKIR2 REALNUMBERSK2"
       sorry
    thus "].XXREAL-1K4 a,b .[ be SubsetSUBSET-1M2-of REALNUMBERSK2"
       sorry
  qed
qed "sorry"

mdef measure5_def_2 ("open-intervalMEASURE5V1" 70 ) where
"attr open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be R-ealSUPINF-1M1 st  ex b be R-ealSUPINF-1M1 st IT =MEMBEREDR9 ].MEASURE5K1 a,b .[)"..

mdef measure5_def_3 ("closed-intervalMEASURE5V2" 70 ) where
"attr closed-intervalMEASURE5V2 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st IT =MEMBEREDR9 [.RCOMP-1K1 a,b .])"..

mtheorem measure5_cl_1:
"cluster  non emptyXBOOLE-0V1\<bar>open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>open-intervalMEASURE5V1"
  proof-
    have " ex tVar1 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar1 be  non emptyXBOOLE-0V1 & tVar1 be open-intervalMEASURE5V1"
    proof-
      show " ex tVar1 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar1 be  non emptyXBOOLE-0V1 & tVar1 be open-intervalMEASURE5V1"
      proof(rule bexI[of _ "].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .["],rule conjMI)
        have "InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) inTARSKIR2 ].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .["
          using xxreal_1_th_224 sorry
        thus "].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .[ be  non emptyXBOOLE-0V1"
           sorry
        have " ex tVar3 be R-ealSUPINF-1M1 st ].MEASURE5K1 -inftySUPINF-1K2,tVar3 .[ =MEMBEREDR9 ].MEASURE5K1 -inftySUPINF-1K2,tVar3 .["
        proof(rule bexI[of _ "+inftySUPINF-1K1"])
          show "].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .[ =MEMBEREDR9 ].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .["
             sorry
        qed "sorry"
        thus "].MEASURE5K1 -inftySUPINF-1K2,+inftySUPINF-1K1 .[ be open-intervalMEASURE5V1"
          using bexI[of _ "-inftySUPINF-1K2"] measure5_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem measure5_cl_2:
"cluster  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2"
  proof-
    have " ex tVar4 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar4 be  non emptyXBOOLE-0V1 & tVar4 be closed-intervalMEASURE5V2"
    proof-
      show " ex tVar4 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar4 be  non emptyXBOOLE-0V1 & tVar4 be closed-intervalMEASURE5V2"
      proof(rule bexI[of _ "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"],rule conjMI)
        show "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] be  non emptyXBOOLE-0V1"
          using xxreal_1_th_30 sorry
        have " ex tVar6 be RealXREAL-0M1 st [.RCOMP-1K1 0NUMBERSK6,tVar6 .] =MEMBEREDR9 [.RCOMP-1K1 0NUMBERSK6,tVar6 .]"
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          show "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] =MEMBEREDR9 [.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .]"
             sorry
        qed "sorry"
        thus "[.RCOMP-1K1 0NUMBERSK6,\<one>\<^sub>M .] be closed-intervalMEASURE5V2"
          using bexI[of _ "0NUMBERSK6"] measure5_def_3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef measure5_def_4 ("right-open-intervalMEASURE5V3" 70 ) where
"attr right-open-intervalMEASURE5V3 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be RealXREAL-0M1 st  ex b be R-ealSUPINF-1M1 st IT =MEMBEREDR9 [.RCOMP-1K3 a,b .[)"..

abbreviation(input) MEASURE5V4("left-closed-intervalMEASURE5V4" 70) where
  "left-closed-intervalMEASURE5V4 \<equiv> right-open-intervalMEASURE5V3"

mdef measure5_def_5 ("left-open-intervalMEASURE5V5" 70 ) where
"attr left-open-intervalMEASURE5V5 for SubsetSUBSET-1M2-of REALNUMBERSK2 means
  (\<lambda>IT.  ex a be R-ealSUPINF-1M1 st  ex b be RealXREAL-0M1 st IT =MEMBEREDR9 ].RCOMP-1K4 a,b .])"..

abbreviation(input) MEASURE5V6("right-closed-intervalMEASURE5V6" 70) where
  "right-closed-intervalMEASURE5V6 \<equiv> left-open-intervalMEASURE5V5"

mtheorem measure5_cl_3:
"cluster  non emptyXBOOLE-0V1\<bar>right-open-intervalMEASURE5V3 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>right-open-intervalMEASURE5V3"
  proof-
    have " ex tVar7 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar7 be  non emptyXBOOLE-0V1 & tVar7 be right-open-intervalMEASURE5V3"
    proof-
      show " ex tVar7 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar7 be  non emptyXBOOLE-0V1 & tVar7 be right-open-intervalMEASURE5V3"
      proof(rule bexI[of _ "[.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .["],rule conjMI)
        have "0NUMBERSK6 inTARSKIR2 [.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .["
          using xxreal_1_th_236 sorry
        thus "[.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .[ be  non emptyXBOOLE-0V1"
           sorry
        have " ex tVar9 be R-ealSUPINF-1M1 st [.RCOMP-1K3 0NUMBERSK6,tVar9 .[ =MEMBEREDR9 [.RCOMP-1K3 0NUMBERSK6,tVar9 .["
        proof(rule bexI[of _ "+inftySUPINF-1K1"])
          show "[.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .[ =MEMBEREDR9 [.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .["
             sorry
        qed "sorry"
        thus "[.RCOMP-1K3 0NUMBERSK6,+inftySUPINF-1K1 .[ be right-open-intervalMEASURE5V3"
          using bexI[of _ "0NUMBERSK6"] measure5_def_4 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem measure5_cl_4:
"cluster  non emptyXBOOLE-0V1\<bar>left-open-intervalMEASURE5V5 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*existence*)
  show " ex it be SubsetSUBSET-1M2-of REALNUMBERSK2 st it be  non emptyXBOOLE-0V1\<bar>left-open-intervalMEASURE5V5"
  proof-
    have " ex tVar10 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar10 be  non emptyXBOOLE-0V1 & tVar10 be left-open-intervalMEASURE5V5"
    proof-
      show " ex tVar10 be SubsetSUBSET-1M2-of REALNUMBERSK2 st tVar10 be  non emptyXBOOLE-0V1 & tVar10 be left-open-intervalMEASURE5V5"
      proof(rule bexI[of _ "].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .]"],rule conjMI)
        have "\<one>\<^sub>M inTARSKIR2 ].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .]"
          using xxreal_1_th_234 sorry
        thus "].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .] be  non emptyXBOOLE-0V1"
           sorry
        have " ex tVar12 be RealXREAL-0M1 st ].RCOMP-1K4 -inftySUPINF-1K2,tVar12 .] =MEMBEREDR9 ].RCOMP-1K4 -inftySUPINF-1K2,tVar12 .]"
        proof(rule bexI[of _ "\<one>\<^sub>M"])
          show "].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .] =MEMBEREDR9 ].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .]"
             sorry
        qed "sorry"
        thus "].RCOMP-1K4 -inftySUPINF-1K2,\<one>\<^sub>M .] be left-open-intervalMEASURE5V5"
          using bexI[of _ "-inftySUPINF-1K2"] measure5_def_5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax MEASURE5M1 :: "Ty" ("IntervalMEASURE5M1" 70)
translations "IntervalMEASURE5M1" \<rightharpoonup> "intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"

reserve A, B for "IntervalMEASURE5M1"
mtheorem measure5_cl_5:
"cluster open-intervalMEASURE5V1 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be open-intervalMEASURE5V1 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_6:
"cluster closed-intervalMEASURE5V2 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be closed-intervalMEASURE5V2 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_7:
"cluster right-open-intervalMEASURE5V3 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be right-open-intervalMEASURE5V3 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_cl_8:
"cluster left-open-intervalMEASURE5V5 also-is intervalXXREAL-2V6 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be left-open-intervalMEASURE5V5 implies it be intervalXXREAL-2V6"
     sorry
qed "sorry"

mtheorem measure5_th_1:
" for I be intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds ((I be open-intervalMEASURE5V1 or I be closed-intervalMEASURE5V2) or I be right-open-intervalMEASURE5V3) or I be left-open-intervalMEASURE5V5"
proof-
  have " for I be intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
  proof(rule ballI)
    fix I assume [ty]: "I be intervalXXREAL-2V6\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    show " not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
    proof-
      have cases: "((I be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 or I be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2) or I be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2) or I be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2"
         sorry
      have case1: "I be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 implies  not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
      proof(rule impI)
        assume A1: "I be left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
        obtain a b where 
          [ty]:"a be R-ealSUPINF-1M1" and aDef:"a = infSUPINF-2K10 I" and
          [ty]:"b be R-ealSUPINF-1M1" and bDef:"b = supSUPINF-2K11 I"
           sorry
        have A2: "a inTARSKIR2 I & I =MEMBEREDR8 [.XXREAL-1K1 a,b .]"
          using A1 xxreal_2_th_75 xxreal_2_def_5 sorry
        show " not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
          using A1 A2 sorry
      qed
      have case2: "I be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2 implies  not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
      proof(rule impI)
        assume A3: "I be  non left-endXXREAL-2V1\<bar>right-endXXREAL-2V2"
        let ?a = "infSUPINF-2K10 I"
        let ?b = "supSUPINF-2K11 I"
        have A4: "I =MEMBEREDR8 ].XXREAL-1K3 ?a,?b .]"
          using A3 xxreal_2_th_76 sorry
        have A5: "?b inTARSKIR2 I"
          using A3 xxreal_2_def_6 sorry
        show " not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
          using A5 A4 sorry
      qed
      have case3: "I be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2 implies  not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
      proof(rule impI)
        assume A6: "I be left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2"
        let ?a = "infSUPINF-2K10 I"
        let ?b = "supSUPINF-2K11 I"
        have A7: "I =MEMBEREDR8 [.XXREAL-1K2 ?a,?b .["
          using A6 xxreal_2_th_77 sorry
        have A8: "?a inTARSKIR2 I"
          using A6 xxreal_2_def_5 sorry
        show " not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
          using A8 A7 sorry
      qed
      have case4: "I be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2 implies  not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
      proof(rule impI)
        assume "I be  non left-endXXREAL-2V1\<bar> non right-endXXREAL-2V2"
        then obtain a b where
          [ty]:"a be ExtRealXXREAL-0M1" "b be ExtRealXXREAL-0M1" and 
          A9: "a <=XXREAL-0R1 b"and A10: "I =MEMBEREDR9 ].RCOMP-1K2 a,b .["
          using xxreal_2_th_79 sorry
        have 
          [ty]:"a be R-ealSUPINF-1M1" and
          [ty]:"b be R-ealSUPINF-1M1"
          using xxreal_0_def_1 sorry
        have "a <=XXREAL-0R1 b"
          using A9 sorry
        thus " not ((( not I be open-intervalMEASURE5V1 &  not I be closed-intervalMEASURE5V2) &  not I be right-open-intervalMEASURE5V3) &  not I be left-open-intervalMEASURE5V5)"
          using A10 sorry
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_th_2:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b implies ( ex x be R-ealSUPINF-1M1 st (a <XXREAL-0R3 x & x <XXREAL-0R3 b) & x inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b implies ( ex tVar13 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar13 &  not tVar13 <XXREAL-0R3 b) & tVar13 inTARSKIR2 REALNUMBERSK2)"
  proof(rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    have A1: "a inTARSKIR2 REALNUMBERSK2 or a inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
      using xboole_0_def_3 xxreal_0_def_4 sorry
    have A2: "b inTARSKIR2 REALNUMBERSK2 or b inTARSKIR2 {TARSKIK2 -inftySUPINF-1K2,+inftySUPINF-1K1 }"
      using xboole_0_def_3 xxreal_0_def_4 sorry
    assume A3: "a <XXREAL-0R3 b"
    then have A4: " not a =XBOOLE-0R4 +inftySUPINF-1K1 &  not b =XBOOLE-0R4 -inftySUPINF-1K2"
      using xxreal_0_th_4 xxreal_0_th_6 sorry
    show " ex tVar13 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar13 &  not tVar13 <XXREAL-0R3 b) & tVar13 inTARSKIR2 REALNUMBERSK2"
    proof-
      have cases: "((a inTARSKIR2 REALNUMBERSK2 & b inTARSKIR2 REALNUMBERSK2 or a inTARSKIR2 REALNUMBERSK2 & b =XBOOLE-0R4 +inftySUPINF-1K1) or a =XBOOLE-0R4 -inftySUPINF-1K2 & b inTARSKIR2 REALNUMBERSK2) or a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1"
        using A1 A2 A4 tarski_def_2 sorry
      have case1: "a inTARSKIR2 REALNUMBERSK2 & b inTARSKIR2 REALNUMBERSK2 implies ( ex tVar13 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar13 &  not tVar13 <XXREAL-0R3 b) & tVar13 inTARSKIR2 REALNUMBERSK2)"
      proof(rule impI)
        assume "a inTARSKIR2 REALNUMBERSK2 & b inTARSKIR2 REALNUMBERSK2"
        then obtain x y where
          [ty]:"x be RealXREAL-0M1" "y be RealXREAL-0M1" and 
          A5: "x =HIDDENR1 a & y =HIDDENR1 b"and "x <=XXREAL-0R1 y"
          using A3 sorry
        obtain z where
          [ty]:"z be RealXREAL-0M1" and 
          A6: "x <XXREAL-0R3 z & z <XXREAL-0R3 y"
          using A3 A5 xreal_1_th_5 sorry
        have 
          [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        obtain o where 
          [ty]:"o be R-ealSUPINF-1M1" and oDef:"o = z"
          using xxreal_0_def_1 sorry
        show " ex tVar13 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar13 &  not tVar13 <XXREAL-0R3 b) & tVar13 inTARSKIR2 REALNUMBERSK2"
        proof(rule bexI[of _ "o"])
          show "( not a <XXREAL-0R3 o &  not o <XXREAL-0R3 b) & o inTARSKIR2 REALNUMBERSK2"
            using A5 A6 sorry
        qed "sorry"
      qed
      have case2: "a inTARSKIR2 REALNUMBERSK2 & b =XBOOLE-0R4 +inftySUPINF-1K1 implies ( ex tVar14 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar14 &  not tVar14 <XXREAL-0R3 b) & tVar14 inTARSKIR2 REALNUMBERSK2)"
      proof(rule impI)
        assume A7: "a inTARSKIR2 REALNUMBERSK2 & b =XBOOLE-0R4 +inftySUPINF-1K1"
        then obtain x where 
          [ty]:"x be RealXREAL-0M1" and xDef:"x = a"
           sorry
        obtain z where
          [ty]:"z be RealXREAL-0M1" and 
          A8: "x <XXREAL-0R3 z"
          using xreal_1_th_1 sorry
        have 
          [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        obtain o where 
          [ty]:"o be R-ealSUPINF-1M1" and oDef:"o = z"
          using xxreal_0_def_1 sorry
        show " ex tVar14 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar14 &  not tVar14 <XXREAL-0R3 b) & tVar14 inTARSKIR2 REALNUMBERSK2"
        proof(rule bexI[of _ "o"])
          show "( not a <XXREAL-0R3 o &  not o <XXREAL-0R3 b) & o inTARSKIR2 REALNUMBERSK2"
            using A7 A8 xxreal_0_th_9 sorry
        qed "sorry"
      qed
      have case3: "a =XBOOLE-0R4 -inftySUPINF-1K2 & b inTARSKIR2 REALNUMBERSK2 implies ( ex tVar15 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar15 &  not tVar15 <XXREAL-0R3 b) & tVar15 inTARSKIR2 REALNUMBERSK2)"
      proof(rule impI)
        assume A9: "a =XBOOLE-0R4 -inftySUPINF-1K2 & b inTARSKIR2 REALNUMBERSK2"
        then obtain y where 
          [ty]:"y be RealXREAL-0M1" and yDef:"y = b"
           sorry
        obtain z where
          [ty]:"z be RealXREAL-0M1" and 
          A10: "z <XXREAL-0R3 y"
          using xreal_1_th_2 sorry
        have 
          [ty]:"z be ElementSUBSET-1M1-of REALNUMBERSK2"
          using xreal_0_def_1 sorry
        obtain o where 
          [ty]:"o be R-ealSUPINF-1M1" and oDef:"o = z"
          using xxreal_0_def_1 sorry
        show " ex tVar15 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar15 &  not tVar15 <XXREAL-0R3 b) & tVar15 inTARSKIR2 REALNUMBERSK2"
        proof(rule bexI[of _ "o"])
          show "( not a <XXREAL-0R3 o &  not o <XXREAL-0R3 b) & o inTARSKIR2 REALNUMBERSK2"
            using A9 A10 xxreal_0_th_12 sorry
        qed "sorry"
      qed
      have case4: "a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1 implies ( ex tVar16 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar16 &  not tVar16 <XXREAL-0R3 b) & tVar16 inTARSKIR2 REALNUMBERSK2)"
      proof(rule impI)
        assume A11: "a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1"
        show " ex tVar16 be R-ealSUPINF-1M1 st ( not a <XXREAL-0R3 tVar16 &  not tVar16 <XXREAL-0R3 b) & tVar16 inTARSKIR2 REALNUMBERSK2"
        proof(rule bexI[of _ "0.SUPINF-2K2"])
          have "0.SUPINF-2K2 =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
             sorry
          thus "( not a <XXREAL-0R3 0.SUPINF-2K2 &  not 0.SUPINF-2K2 <XXREAL-0R3 b) & 0.SUPINF-2K2 inTARSKIR2 REALNUMBERSK2"
            using A11 sorry
        qed "sorry"
      qed
      show " ?thesis "
        using cases case1 case2 case3 case4 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_th_3:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b & a <XXREAL-0R3 c implies ( ex x be R-ealSUPINF-1M1 st ((a <XXREAL-0R3 x & x <XXREAL-0R3 b) & x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 b & a <XXREAL-0R3 c implies ( ex tVar18 be R-ealSUPINF-1M1 st (( not a <XXREAL-0R3 tVar18 &  not tVar18 <XXREAL-0R3 b) &  not tVar18 <XXREAL-0R3 c) & tVar18 inTARSKIR2 REALNUMBERSK2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    fix c assume [ty]: "c be R-ealSUPINF-1M1"
    have A1: "minXXREAL-0K4(b,c) =HIDDENR1 minXXREAL-2K5 {TARSKIK2 b,c }"
      using xxreal_2_th_14 sorry
    have " ex o be R-ealSUPINF-1M1 st o inTARSKIR2 {TARSKIK2 b,c } & o <=XXREAL-0R1 c"
    proof-
      have " ex tVar17 be R-ealSUPINF-1M1 st tVar17 inTARSKIR2 {TARSKIK2 b,tVar17 } & tVar17 <=XXREAL-0R1 tVar17"
      proof-
        show " ex tVar17 be R-ealSUPINF-1M1 st tVar17 inTARSKIR2 {TARSKIK2 b,tVar17 } & tVar17 <=XXREAL-0R1 tVar17"
        proof(rule bexI[of _ "c"])
          show "c inTARSKIR2 {TARSKIK2 b,c } & c <=XXREAL-0R1 c"
            using tarski_def_2 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
    then have A2: "minXXREAL-0K4(b,c) <=XXREAL-0R1 c"
      using A1 xxreal_2_th_62 sorry
    obtain m where 
      [ty]:"m be R-ealSUPINF-1M1" and mDef:"m = minXXREAL-0K4(b,c)"
      using xxreal_0_def_1 sorry
    assume "a <XXREAL-0R3 b & a <XXREAL-0R3 c"
    then have "a <XXREAL-0R3 minXXREAL-0K4(b,c)"
      using xxreal_0_def_9 sorry
    then obtain x where
      [ty]:"x be R-ealSUPINF-1M1" and 
      A3: "(a <XXREAL-0R3 x & x <XXREAL-0R3 m) & x inTARSKIR2 REALNUMBERSK2"
      using measure5_th_2 sorry
    show " ex tVar18 be R-ealSUPINF-1M1 st (( not a <XXREAL-0R3 tVar18 &  not tVar18 <XXREAL-0R3 b) &  not tVar18 <XXREAL-0R3 c) & tVar18 inTARSKIR2 REALNUMBERSK2"
    proof(rule bexI[of _ "x"])
      have " ex o be R-ealSUPINF-1M1 st o inTARSKIR2 {TARSKIK2 b,c } & o <=XXREAL-0R1 b"
      proof-
        have " ex tVar19 be R-ealSUPINF-1M1 st tVar19 inTARSKIR2 {TARSKIK2 tVar19,c } & tVar19 <=XXREAL-0R1 tVar19"
        proof-
          show " ex tVar19 be R-ealSUPINF-1M1 st tVar19 inTARSKIR2 {TARSKIK2 tVar19,c } & tVar19 <=XXREAL-0R1 tVar19"
          proof(rule bexI[of _ "b"])
            show "b inTARSKIR2 {TARSKIK2 b,c } & b <=XXREAL-0R1 b"
              using tarski_def_2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
      then have "minXXREAL-0K4(b,c) <=XXREAL-0R1 b"
        using A1 xxreal_2_th_62 sorry
      thus "(( not a <XXREAL-0R3 x &  not x <XXREAL-0R3 b) &  not x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2"
        using A3 A2 xxreal_0_th_2 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_th_4:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 c & b <XXREAL-0R3 c implies ( ex x be R-ealSUPINF-1M1 st ((a <XXREAL-0R3 x & b <XXREAL-0R3 x) & x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2)"
proof-
  have " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for c be R-ealSUPINF-1M1 holds a <XXREAL-0R3 c & b <XXREAL-0R3 c implies ( ex tVar20 be R-ealSUPINF-1M1 st (( not a <XXREAL-0R3 tVar20 &  not b <XXREAL-0R3 tVar20) &  not tVar20 <XXREAL-0R3 c) & tVar20 inTARSKIR2 REALNUMBERSK2)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    fix c assume [ty]: "c be R-ealSUPINF-1M1"
    obtain m where 
      [ty]:"m be R-ealSUPINF-1M1" and mDef:"m = maxXXREAL-0K5(a,b)"
      using xxreal_0_def_1 sorry
    have A1: "b inTARSKIR2 {TARSKIK2 a,b }"
      using tarski_def_2 sorry
    assume "a <XXREAL-0R3 c & b <XXREAL-0R3 c"
    then have "maxXXREAL-0K5(a,b) <XXREAL-0R3 c"
      using xxreal_0_def_10 sorry
    then obtain x where
      [ty]:"x be R-ealSUPINF-1M1" and 
      A2: "(m <XXREAL-0R3 x & x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2"
      using measure5_th_2 sorry
    show " ex tVar20 be R-ealSUPINF-1M1 st (( not a <XXREAL-0R3 tVar20 &  not b <XXREAL-0R3 tVar20) &  not tVar20 <XXREAL-0R3 c) & tVar20 inTARSKIR2 REALNUMBERSK2"
    proof(rule bexI[of _ "x"])
      have "maxXXREAL-0K5(a,b) =HIDDENR1 maxXXREAL-2K6 {TARSKIK2 a,b } & a inTARSKIR2 {TARSKIK2 a,b }"
        using tarski_def_2 xxreal_2_th_12 sorry
      thus "(( not a <XXREAL-0R3 x &  not b <XXREAL-0R3 x) &  not x <XXREAL-0R3 c) & x inTARSKIR2 REALNUMBERSK2"
        using A2 A1 xxreal_2_th_61 sorry
    qed "sorry"
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef measure5_def_6 ("diameterMEASURE5K2  _ " [164]164 ) where
  mlet "A be ext-real-memberedMEMBEREDV2\<bar>setHIDDENM2"
"func diameterMEASURE5K2 A \<rightarrow> R-ealSUPINF-1M1 equals
  supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A if A <>HIDDENR2 {}XBOOLE-0K1 otherwise 0.SUPINF-2K2"
proof-
  (*coherence*)
    show "(A <>HIDDENR2 {}XBOOLE-0K1 implies supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A be R-ealSUPINF-1M1) & ( not A <>HIDDENR2 {}XBOOLE-0K1 implies 0.SUPINF-2K2 be R-ealSUPINF-1M1)"
       sorry
  (*consistency*)
    show " for it be R-ealSUPINF-1M1 holds  True "
       sorry
qed "sorry"

mtheorem measure5_th_5:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2)"
proof(rule ballI,rule ballI,rule conjMI,rule impI)
  fix a assume [ty]: "a be R-ealSUPINF-1M1"
  fix b assume [ty]: "b be R-ealSUPINF-1M1"
  show "a <XXREAL-0R3 b implies diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a"
  proof(rule impI)
    assume A1: "a <XXREAL-0R3 b"
    then have A2: "supSUPINF-2K11 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 b"
      using xxreal_2_th_32 sorry
    have "].MEASURE5K1 a,b .[ <>HIDDENR2 {}XBOOLE-0K1 & infSUPINF-2K10 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 a"
      using A1 xxreal_1_th_33 xxreal_2_th_28 sorry
    thus "diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a"
      using A2 measure5_def_6 sorry
  qed
  assume "b <=XXREAL-0R1 a"
  then have "].MEASURE5K1 a,b .[ =MEMBEREDR9 {}XBOOLE-0K1"
    using xxreal_1_th_28 sorry
  thus "diameterMEASURE5K2 (].MEASURE5K1 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2"
    using measure5_def_6 sorry
qed "sorry"

mtheorem measure5_th_6:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <=XXREAL-0R1 b implies diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <XXREAL-0R3 a implies diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2)"
proof(rule ballI,rule ballI,rule conjMI,rule impI)
  fix a assume [ty]: "a be R-ealSUPINF-1M1"
  fix b assume [ty]: "b be R-ealSUPINF-1M1"
  show "a <=XXREAL-0R1 b implies diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a"
  proof(rule impI)
    assume A1: "a <=XXREAL-0R1 b"
    then have A2: "supSUPINF-2K11 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 b"
      using xxreal_2_th_29 sorry
    have "[.XXREAL-1K1 a,b .] <>HIDDENR2 {}XBOOLE-0K1 & infSUPINF-2K10 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 a"
      using A1 xxreal_1_th_30 xxreal_2_th_25 sorry
    thus "diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a"
      using A2 measure5_def_6 sorry
  qed
  assume "b <XXREAL-0R3 a"
  then have "[.XXREAL-1K1 a,b .] =MEMBEREDR8 {}XBOOLE-0K1"
    using xxreal_1_th_29 sorry
  thus "diameterMEASURE5K2 ([.XXREAL-1K1 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2"
    using measure5_def_6 sorry
qed "sorry"

mtheorem measure5_th_7:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2)"
proof(rule ballI,rule ballI,rule conjMI,rule impI)
  fix a assume [ty]: "a be R-ealSUPINF-1M1"
  fix b assume [ty]: "b be R-ealSUPINF-1M1"
  show "a <XXREAL-0R3 b implies diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a"
  proof(rule impI)
    assume A1: "a <XXREAL-0R3 b"
    then have A2: "supSUPINF-2K11 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 b"
      using xxreal_2_th_31 sorry
    have "[.XXREAL-1K2 a,b .[ <>HIDDENR2 {}XBOOLE-0K1 & infSUPINF-2K10 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 a"
      using A1 xxreal_1_th_31 xxreal_2_th_26 sorry
    thus "diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 b -SUPINF-2K5 a"
      using A2 measure5_def_6 sorry
  qed
  assume "b <=XXREAL-0R1 a"
  then have "[.XXREAL-1K2 a,b .[ =MEMBEREDR8 {}XBOOLE-0K1"
    using xxreal_1_th_27 sorry
  thus "diameterMEASURE5K2 ([.XXREAL-1K2 a,b .[) =XBOOLE-0R4 0.SUPINF-2K2"
    using measure5_def_6 sorry
qed "sorry"

mtheorem measure5_th_8:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a <XXREAL-0R3 b implies diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a) & (b <=XXREAL-0R1 a implies diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2)"
proof(rule ballI,rule ballI,rule conjMI,rule impI)
  fix a assume [ty]: "a be R-ealSUPINF-1M1"
  fix b assume [ty]: "b be R-ealSUPINF-1M1"
  show "a <XXREAL-0R3 b implies diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a"
  proof(rule impI)
    assume A1: "a <XXREAL-0R3 b"
    then have A2: "supSUPINF-2K11 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 b"
      using xxreal_2_th_30 sorry
    have "].XXREAL-1K3 a,b .] <>HIDDENR2 {}XBOOLE-0K1 & infSUPINF-2K10 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 a"
      using A1 xxreal_1_th_32 xxreal_2_th_27 sorry
    thus "diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 b -SUPINF-2K5 a"
      using A2 measure5_def_6 sorry
  qed
  assume "b <=XXREAL-0R1 a"
  then have "].XXREAL-1K3 a,b .] =MEMBEREDR8 {}XBOOLE-0K1"
    using xxreal_1_th_26 sorry
  thus "diameterMEASURE5K2 (].XXREAL-1K3 a,b .]) =XBOOLE-0R4 0.SUPINF-2K2"
    using measure5_def_6 sorry
qed "sorry"

mtheorem measure5_th_9:
" for A be IntervalMEASURE5M1 holds  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1) & (((A =MEMBEREDR9 ].MEASURE5K1 a,b .[ or A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) or A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) or A =MEMBEREDR8 ].XXREAL-1K3 a,b .]) implies diameterMEASURE5K2 A =XBOOLE-0R4 +inftySUPINF-1K1"
proof-
  have " for A be IntervalMEASURE5M1 holds  for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds (a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1) & (((A =MEMBEREDR9 ].MEASURE5K1 a,b .[ or A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) or A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) or A =MEMBEREDR8 ].XXREAL-1K3 a,b .]) implies diameterMEASURE5K2 A =XBOOLE-0R4 +inftySUPINF-1K1"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be IntervalMEASURE5M1"
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    assume A1: "a =XBOOLE-0R4 -inftySUPINF-1K2 & b =XBOOLE-0R4 +inftySUPINF-1K1"
      and A2: "((A =MEMBEREDR9 ].MEASURE5K1 a,b .[ or A =MEMBEREDR8 [.XXREAL-1K1 a,b .]) or A =MEMBEREDR8 [.XXREAL-1K2 a,b .[) or A =MEMBEREDR8 ].XXREAL-1K3 a,b .]"
    have A3: "supSUPINF-2K11 A =XBOOLE-0R4 +inftySUPINF-1K1 & infSUPINF-2K10 A =XBOOLE-0R4 -inftySUPINF-1K2"
      using A1 A2 xxreal_2_th_25 xxreal_2_th_26 xxreal_2_th_27 xxreal_2_th_28 xxreal_2_th_29 xxreal_2_th_30 xxreal_2_th_31 xxreal_2_th_32 sorry
    then have "A be  non emptyXBOOLE-0V1"
      using xxreal_2_th_40 sorry
    then have "diameterMEASURE5K2 A =HIDDENR1 b -SUPINF-2K5 a"
      using A1 A3 measure5_def_6 sorry
    also have "... = +inftySUPINF-1K1"
      using A1 xxreal_3_th_13 sorry
    finally have "diameterMEASURE5K2 A =HIDDENR1 +inftySUPINF-1K1"
       sorry
    thus "diameterMEASURE5K2 A =XBOOLE-0R4 +inftySUPINF-1K1"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_cl_9:
"cluster emptyXBOOLE-0V1 also-is open-intervalMEASURE5V1 for SubsetSUBSET-1M2-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be SubsetSUBSET-1M2-of REALNUMBERSK2 holds it be emptyXBOOLE-0V1 implies it be open-intervalMEASURE5V1"
  proof-
    have " for S be SubsetSUBSET-1M2-of REALNUMBERSK2 holds S be emptyXBOOLE-0V1 implies S be open-intervalMEASURE5V1"
    proof(rule ballI,rule impI)
      fix S assume [ty]: "S be SubsetSUBSET-1M2-of REALNUMBERSK2"
      assume "S be emptyXBOOLE-0V1"
      then have "S =MEMBEREDR9 ].MEASURE5K1 0.SUPINF-2K2,0.SUPINF-2K2 .["
         sorry
      thus "S be open-intervalMEASURE5V1"
         sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem measure5_th_10:
"diameterMEASURE5K2 {}XBOOLE-0K1 =XBOOLE-0R4 0.SUPINF-2K2"
  using measure5_def_6 sorry

mlemma measure5_lm_1:
" for A be IntervalMEASURE5M1 holds diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
proof-
  have " for A be IntervalMEASURE5M1 holds diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
  proof(rule ballI)
    fix A assume [ty]: "A be IntervalMEASURE5M1"
    show "diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
    proof-
      have cases: "A be emptyXBOOLE-0V1 or A be  non emptyXBOOLE-0V1"
         sorry
      have case1: "A be emptyXBOOLE-0V1 implies diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "A be emptyXBOOLE-0V1"
        thus "diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
          using measure5_def_6 sorry
      qed
      have case2: "A be  non emptyXBOOLE-0V1 implies diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
      proof(rule impI)
        assume "A be  non emptyXBOOLE-0V1"
        then have "infSUPINF-2K10 A <=XXREAL-0R1 supSUPINF-2K11 A"
          using xxreal_2_th_40 sorry
        then have "supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A >=XXREAL-0R2 0NUMBERSK6"
          using xxreal_3_th_40 sorry
        thus "diameterMEASURE5K2 A >=XXREAL-0R2 0NUMBERSK6"
          using measure5_def_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma measure5_lm_2:
" for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
proof-
  have " for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
  proof(rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be IntervalMEASURE5M1"
    fix B assume [ty]: "B be IntervalMEASURE5M1"
    assume A1: "A c=MEMBEREDR3 B"
    show "diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
    proof-
      have cases: "A =MEMBEREDR9 {}XBOOLE-0K1 or A <>HIDDENR2 {}XBOOLE-0K1"
         sorry
      have case1: "A =MEMBEREDR9 {}XBOOLE-0K1 implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
      proof(rule impI)
        assume "A =MEMBEREDR9 {}XBOOLE-0K1"
        then have "diameterMEASURE5K2 A =XBOOLE-0R4 0NUMBERSK6"
          using measure5_def_6 sorry
        thus "diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
          using measure5_lm_1 sorry
      qed
      have case2: "A <>HIDDENR2 {}XBOOLE-0K1 implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
      proof(rule impI)
        assume A2: "A <>HIDDENR2 {}XBOOLE-0K1"
        then have "B <>HIDDENR2 {}XBOOLE-0K1"
          using A1 sorry
        then have A3: "diameterMEASURE5K2 B =XBOOLE-0R4 supSUPINF-2K11 B -SUPINF-2K5 infSUPINF-2K10 B"
          using measure5_def_6 sorry
        have A4: "supSUPINF-2K11 A <=XXREAL-0R1 supSUPINF-2K11 B & infSUPINF-2K10 B <=XXREAL-0R1 infSUPINF-2K10 A"
          using A1 xxreal_2_th_59 xxreal_2_th_60 sorry
        have "diameterMEASURE5K2 A =XBOOLE-0R4 supSUPINF-2K11 A -SUPINF-2K5 infSUPINF-2K10 A"
          using A2 measure5_def_6 sorry
        thus "diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
          using A3 A4 xxreal_3_th_37 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_th_11:
" for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds (A c=MEMBEREDR3 B & B =MEMBEREDR8 [.XXREAL-1K1 a,b .]) & b <=XXREAL-0R1 a implies diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
proof-
  have " for a be R-ealSUPINF-1M1 holds  for b be R-ealSUPINF-1M1 holds  for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B & (B =MEMBEREDR8 [.XXREAL-1K1 a,b .] & b <=XXREAL-0R1 a) implies diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be R-ealSUPINF-1M1"
    fix b assume [ty]: "b be R-ealSUPINF-1M1"
    fix A assume [ty]: "A be IntervalMEASURE5M1"
    fix B assume [ty]: "B be IntervalMEASURE5M1"
    assume A1: "A c=MEMBEREDR3 B"
      and A2: "B =MEMBEREDR8 [.XXREAL-1K1 a,b .]"
      and A3: "b <=XXREAL-0R1 a"
    show "diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
    proof-
      have cases: "a =XBOOLE-0R4 b or b <XXREAL-0R3 a"
        using A3 xxreal_0_th_1 sorry
      have case1: "a =XBOOLE-0R4 b implies diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
      proof(rule impI)
        assume A4: "a =XBOOLE-0R4 b"
        then have "B =MEMBEREDR8 {TARSKIK1 a}"
          using A2 xxreal_1_th_17 sorry
        then have "infSUPINF-2K10 B =XBOOLE-0R4 a & supSUPINF-2K11 B =XBOOLE-0R4 a"
          using xxreal_2_th_11 xxreal_2_th_13 sorry
        then have A5: "diameterMEASURE5K2 B =HIDDENR1 a -SUPINF-2K5 a"
          using A2 A4 measure5_def_6 sorry
        also have "... = 0NUMBERSK6"
          using xxreal_3_th_7 sorry
        finally have "diameterMEASURE5K2 B =HIDDENR1 0NUMBERSK6"
           sorry
        then have "diameterMEASURE5K2 A <=XXREAL-0R1 0NUMBERSK6"
          using A1 measure5_lm_2 sorry
        thus "diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
          using A5 measure5_lm_1 sorry
      qed
      have case2: "b <XXREAL-0R3 a implies diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
      proof(rule impI)
        assume "b <XXREAL-0R3 a"
        then have A6: "B =MEMBEREDR9 {}XBOOLE-0K1"
          using A2 xxreal_1_th_29 sorry
        then have "A =MEMBEREDR9 {}XBOOLE-0K1"
          using A1 sorry
        thus "diameterMEASURE5K2 A =XBOOLE-0R4 0.SUPINF-2K2 & diameterMEASURE5K2 B =XBOOLE-0R4 0.SUPINF-2K2"
          using A6 measure5_def_6 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem measure5_th_12:
" for A be IntervalMEASURE5M1 holds  for B be IntervalMEASURE5M1 holds A c=MEMBEREDR3 B implies diameterMEASURE5K2 A <=XXREAL-0R1 diameterMEASURE5K2 B"
  using measure5_lm_2 sorry

mtheorem measure5_th_13:
" for A be IntervalMEASURE5M1 holds 0.SUPINF-2K2 <=XXREAL-0R1 diameterMEASURE5K2 A"
  using measure5_lm_1 sorry

mtheorem measure5_th_14:
" for X be SubsetSUBSET-1M2-of REALNUMBERSK2 holds X be  non emptyXBOOLE-0V1\<bar>closed-intervalMEASURE5V2 iff ( ex a be RealXREAL-0M1 st  ex b be RealXREAL-0M1 st a <=XXREAL-0R1 b & X =MEMBEREDR9 [.RCOMP-1K1 a,b .])"
  using xxreal_1_th_29 xxreal_1_th_30 sorry

end
