theory binop_1
  imports funct_2
begin
(*begin*)
mdef binop_1_def_1 (" _ .BINOP-1K1'( _ , _ ')" [200,0,0]200 ) where
  mlet "f be FunctionFUNCT-1M1", "a be objectHIDDENM1", "b be objectHIDDENM1"
"func f .BINOP-1K1(a,b) \<rightarrow> setHIDDENM2 equals
  f .FUNCT-1K1 [TARSKIK4 a,b ]"
proof-
  (*coherence*)
    show "f .FUNCT-1K1 [TARSKIK4 a,b ] be setHIDDENM2"
       sorry
qed "sorry"

reserve A for "setHIDDENM2"
syntax BINOP_1K2 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .BINOP-1K2\<^bsub>'( _ , _ , _ ')\<^esub>'( _ , _ ')" [200,0,0,0,0,0]200)
translations "f .BINOP-1K2\<^bsub>(A,B,C)\<^esub>(a,b)" \<rightharpoonup> "f .BINOP-1K1(a,b)"

mtheorem binop_1_add_1:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "B be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "C be setHIDDENM2", "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,B :],C)", "a be ElementSUBSET-1M1-of A", "b be ElementSUBSET-1M1-of B"
"cluster f .BINOP-1K1(a,b) as-term-is ElementSUBSET-1M1-of C"
proof
(*coherence*)
  show "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of C"
  proof-
    obtain ab where 
      [ty]:"ab be ElementSUBSET-1M1-of [:ZFMISC-1K2 A,B :]" and abDef:"ab = [TARSKIK4 a,b ]"
      using zfmisc_1_def_2 sorry
    have "f .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 A,B :],C)\<^esub> ab be ElementSUBSET-1M1-of C"
       sorry
    thus "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of C"
       sorry
  qed
qed "sorry"

reserve X, Y, Z for "setHIDDENM2"
reserve x, x1, x2, y, y1, y2, z, z1, z2 for "objectHIDDENM1"
mtheorem binop_1_th_1:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)) implies f1 =FUNCT-2R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
  fix X assume [ty]: "X be setHIDDENM2"
  fix Y assume [ty]: "Y be setHIDDENM2"
  fix Z assume [ty]: "Z be setHIDDENM2"
  fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
  fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
  assume A1: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
  have " for z be objectHIDDENM1 holds z inHIDDENR3 [:ZFMISC-1K2 X,Y :] implies f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
  proof(rule ballI,rule impI)
    fix z assume [ty]: "z be objectHIDDENM1"
    assume "z inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
    then obtain x y where
      [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
      A2: "x inHIDDENR3 X & y inHIDDENR3 Y"and A3: "z =HIDDENR1 [TARSKIK4 x,y ]"
      using zfmisc_1_def_2 sorry
    have "f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f1 .FUNCT-1K1 z & f2 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .FUNCT-1K1 z"
      using A3 sorry
    thus "f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
      using A1 A2 sorry
  qed "sorry"
  thus "f1 =FUNCT-2R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
    using funct_2_th_12 sorry
qed "sorry"

mtheorem binop_1_th_2:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of Y holds f1 .BINOP-1K1(a,b) =XBOOLE-0R4 f2 .BINOP-1K1(a,b)) implies f1 =FUNCT-2R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds ( for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of Y holds f1 .BINOP-1K1(a,b) =XBOOLE-0R4 f2 .BINOP-1K1(a,b)) implies f1 =FUNCT-2R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f1 assume [ty]: "f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
    fix f2 assume [ty]: "f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
    assume " for a be ElementSUBSET-1M1-of X holds  for b be ElementSUBSET-1M1-of Y holds f1 .BINOP-1K1(a,b) =XBOOLE-0R4 f2 .BINOP-1K1(a,b)"
    then have " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
       sorry
    thus "f1 =FUNCT-2R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
      using binop_1_th_1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

syntax BINOP_1M1 :: " Set \<Rightarrow> Ty" ("UnOpBINOP-1M1-of  _ " [70]70)
translations "UnOpBINOP-1M1-of A" \<rightharpoonup> "FunctionFUNCT-2M1-of(A,A)"

syntax BINOP_1M2 :: " Set \<Rightarrow> Ty" ("BinOpBINOP-1M2-of  _ " [70]70)
translations "BinOpBINOP-1M2-of A" \<rightharpoonup> "FunctionFUNCT-2M1-of([:ZFMISC-1K2 A,A :],A)"

reserve u for "UnOpBINOP-1M1-of A"
reserve o, o9 for "BinOpBINOP-1M2-of A"
reserve a, b, c, e, e1, e2 for "ElementSUBSET-1M1-of A"
theorem binop_1_sch_1:
  fixes Xf0 Yf0 Zf0 Pp3 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies ( ex z be objectHIDDENM1 st z inHIDDENR3 Zf0 & Pp3(x,y,z))"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies Pp3(x,y,f .BINOP-1K1(x,y))"
  proof-
    have " ex tVar2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies Pp3(x,y,tVar2 .BINOP-1K1(x,y))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds Lamb1 =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,Lamb2)"
      have A2: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] implies ( ex z be objectHIDDENM1 st z inHIDDENR3 Zf0 & ?R(x,z))"
      proof-
        have " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] implies ( ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 Zf0 & ( for x2 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x2,y2 ] implies Pp3(x2,y2,tVar1)))"
        proof(rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          assume "x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"
          then obtain x1 y1 where
            [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
            A3: "x1 inHIDDENR3 Xf0 & y1 inHIDDENR3 Yf0"and A4: "x =HIDDENR1 [TARSKIK4 x1,y1 ]"
            using zfmisc_1_def_2 sorry
          obtain z where
            [ty]:"z be objectHIDDENM1" and 
            A5: "z inHIDDENR3 Zf0"and A6: "Pp3(x1,y1,z)"
            using A1 A3 sorry
          show " ex tVar1 be objectHIDDENM1 st tVar1 inHIDDENR3 Zf0 & ( for x2 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x2,y2 ] implies Pp3(x2,y2,tVar1))"
          proof(rule bexI[of _ "z"],rule conjMI,rule ballI,rule ballI,rule impI)
            show "z inHIDDENR3 Zf0"
              using A5 sorry
            fix x2 assume [ty]: "x2 be objectHIDDENM1"
            fix y2 assume [ty]: "y2 be objectHIDDENM1"
            assume A7: "x =HIDDENR1 [TARSKIK4 x2,y2 ]"
            then have "x1 =HIDDENR1 x2"
              using A4 xtuple_0_th_1 sorry
            thus "Pp3(x2,y2,z)"
              using A4 A6 A7 xtuple_0_th_1 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A8: " for x be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] implies ?R(x,f .FUNCT-1K1 x)"
        using funct_2_sch_1 A2 sorry
      show " ex tVar2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies Pp3(x,y,tVar2 .BINOP-1K1(x,y))"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI,rule impI)
        fix x assume [ty]: "x be objectHIDDENM1"
        fix y assume [ty]: "y be objectHIDDENM1"
        assume "x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0"
        then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"
          using zfmisc_1_def_2 sorry
        thus "Pp3(x,y,f .BINOP-1K1(x,y))"
          using A8 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_1_sch_2:
  fixes Xf0 Yf0 Zf0 Ff2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies Ff2(x,y) inHIDDENR3 Zf0"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
    have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies ( ex z be objectHIDDENM1 st z inHIDDENR3 Zf0 & ?P(x,y,z))"
      using A1 sorry
    show " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)"
      using binop_1_sch_1 A2 sorry
  qed

theorem binop_1_sch_3:
  fixes Xf0 Yf0 Zf0 Pp3 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Zf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  ex z be ElementSUBSET-1M1-of Zf0 st Pp3(x,y,z)"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Pp3(x,y,f .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y))"
  proof-
    have " ex tVar4 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Pp3(x,y,tVar4 .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2.  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Lamb1 =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,Lamb2)"
      have A2: " for p be ElementSUBSET-1M1-of [:ZFMISC-1K2 Xf0,Yf0 :] holds  ex z be ElementSUBSET-1M1-of Zf0 st ?R(p,z)"
      proof-
        have " for p be ElementSUBSET-1M1-of [:ZFMISC-1K2 Xf0,Yf0 :] holds  ex tVar3 be ElementSUBSET-1M1-of Zf0 st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,tVar3)"
        proof(rule ballI)
          fix p assume [ty]: "p be ElementSUBSET-1M1-of [:ZFMISC-1K2 Xf0,Yf0 :]"
          obtain x1 y1 where
            [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
            A3: "x1 inHIDDENR3 Xf0"and A4: "y1 inHIDDENR3 Yf0"and A5: "p =HIDDENR1 [TARSKIK4 x1,y1 ]"
            using zfmisc_1_def_2 sorry
          have 
            [ty]:"y1 be ElementSUBSET-1M1-of Yf0"
            using A4 sorry
          have 
            [ty]:"x1 be ElementSUBSET-1M1-of Xf0"
            using A3 sorry
          obtain z where
            [ty]:"z be ElementSUBSET-1M1-of Zf0" and 
            A6: "Pp3(x1,y1,z)"
            using A1 sorry
          show " ex tVar3 be ElementSUBSET-1M1-of Zf0 st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds p =HIDDENR1 [TARSKIK4 x,y ] implies Pp3(x,y,tVar3)"
          proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impI)
            fix x assume [ty]: "x be ElementSUBSET-1M1-of Xf0"
            fix y assume [ty]: "y be ElementSUBSET-1M1-of Yf0"
            assume A7: "p =HIDDENR1 [TARSKIK4 x,y ]"
            then have "x1 =XBOOLE-0R4 x"
              using A5 xtuple_0_th_1 sorry
            thus "Pp3(x,y,z)"
              using A5 A6 A7 xtuple_0_th_1 sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A8: " for p be ElementSUBSET-1M1-of [:ZFMISC-1K2 Xf0,Yf0 :] holds ?R(p,f .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)\<^esub> p)"
        using funct_2_sch_3 A2 sorry
      show " ex tVar4 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Pp3(x,y,tVar4 .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y))"
      proof(rule bexI[of _ "f"],rule ballI,rule ballI)
        fix x assume [ty]: "x be ElementSUBSET-1M1-of Xf0"
        fix y assume [ty]: "y be ElementSUBSET-1M1-of Yf0"
        obtain xy where 
          [ty]:"xy be ElementSUBSET-1M1-of [:ZFMISC-1K2 Xf0,Yf0 :]" and xyDef:"xy = [TARSKIK4 x,y ]"
          using zfmisc_1_def_2 sorry
        have "Pp3(x,y,f .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)\<^esub> xy)"
          using A8 sorry
        thus "Pp3(x,y,f .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y))"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_1_sch_4:
  fixes Xf0 Yf0 Zf0 Ff2 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Zf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be ElementSUBSET-1M1-of Xf0 \<Longrightarrow> x2 be ElementSUBSET-1M1-of Yf0 \<Longrightarrow> Ff2(x1,x2) be ElementSUBSET-1M1-of Zf0"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds f .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y) =XBOOLE-0R4 Ff2(x,y)"
  proof-
    let ?P = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Lamb3 =XBOOLE-0R4 Ff2(Lamb1,Lamb2)"
    have A1: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  ex z be ElementSUBSET-1M1-of Zf0 st ?P(x,y,z)"
       sorry
    show " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds f .BINOP-1K2\<^bsub>(Xf0,Yf0,Zf0)\<^esub>(x,y) =XBOOLE-0R4 Ff2(x,y)"
      using binop_1_sch_3 A1 sorry
  qed

mdef binop_1_def_2 ("commutativeBINOP-1V1\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr commutativeBINOP-1V1\<^bsub>(A)\<^esub> for BinOpBINOP-1M2-of A means
  (\<lambda>o.  for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,b) =XBOOLE-0R4 o .BINOP-1K1(b,a))"..

mdef binop_1_def_3 ("associativeBINOP-1V2\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr associativeBINOP-1V2\<^bsub>(A)\<^esub> for BinOpBINOP-1M2-of A means
  (\<lambda>o.  for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o .BINOP-1K1(a,b),c))"..

mdef binop_1_def_4 ("idempotentBINOP-1V3\<^bsub>'( _ ')\<^esub>" [0]70 ) where
  mlet "A be setHIDDENM2"
"attr idempotentBINOP-1V3\<^bsub>(A)\<^esub> for BinOpBINOP-1M2-of A means
  (\<lambda>o.  for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,a) =XBOOLE-0R4 a)"..

mtheorem binop_1_cl_1:
"cluster note-that emptyXBOOLE-0V1\<bar>associativeBINOP-1V2\<^bsub>({}XBOOLE-0K1)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub> for BinOpBINOP-1M2-of {}XBOOLE-0K1"
proof
(*coherence*)
  show " for it be BinOpBINOP-1M2-of {}XBOOLE-0K1 holds it be emptyXBOOLE-0V1\<bar>associativeBINOP-1V2\<^bsub>({}XBOOLE-0K1)\<^esub>\<bar>commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub>"
  proof-
    have " for f be BinOpBINOP-1M2-of {}XBOOLE-0K1 holds f be emptyXBOOLE-0V1 & (f be associativeBINOP-1V2\<^bsub>({}XBOOLE-0K1)\<^esub> & f be commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub>)"
    proof(rule ballI,rule conjMI)
      fix f assume [ty]: "f be BinOpBINOP-1M2-of {}XBOOLE-0K1"
      show "f be emptyXBOOLE-0V1"
         sorry
      have A1: "f c=RELSET-1R1\<^bsub>([:ZFMISC-1K2 {}XBOOLE-0K1,{}XBOOLE-0K1 :],{}XBOOLE-0K1)\<^esub> [:ZFMISC-1K2 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 {}XBOOLE-0K1,{}XBOOLE-0K1 :])\<^esub> f,rngRELSET-1K2\<^bsub>({}XBOOLE-0K1)\<^esub> f :]"
         sorry
      have "( for a be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds  for b be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds  for c be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds f .BINOP-1K1(a,f .BINOP-1K1(b,c)) =HIDDENR1 f .BINOP-1K1(f .BINOP-1K1(a,b),c)) & f be commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub>"
      proof(rule conjMI)
        show " for a be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds  for b be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds  for c be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds f .BINOP-1K1(a,f .BINOP-1K1(b,c)) =HIDDENR1 f .BINOP-1K1(f .BINOP-1K1(a,b),c)"
        proof(rule ballI,rule ballI,rule ballI)
          fix a assume [ty]: "a be ElementSUBSET-1M1-of {}XBOOLE-0K1"
          fix b assume [ty]: "b be ElementSUBSET-1M1-of {}XBOOLE-0K1"
          fix c assume [ty]: "c be ElementSUBSET-1M1-of {}XBOOLE-0K1"
          have "f .BINOP-1K1(a,f .BINOP-1K1(b,c)) =HIDDENR1 {}XBOOLE-0K1"
            using A1 funct_1_def_2 sorry
          also have "... = f .BINOP-1K1(f .BINOP-1K1(a,b),c)"
            using A1 funct_1_def_2 sorry
          finally show "f .BINOP-1K1(a,f .BINOP-1K1(b,c)) =HIDDENR1 f .BINOP-1K1(f .BINOP-1K1(a,b),c)"
             sorry
        qed "sorry"
        have " for a be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds  for b be ElementSUBSET-1M1-of {}XBOOLE-0K1 holds f .BINOP-1K1(a,b) =HIDDENR1 f .BINOP-1K1(b,a)"
        proof(rule ballI,rule ballI)
          fix a assume [ty]: "a be ElementSUBSET-1M1-of {}XBOOLE-0K1"
          fix b assume [ty]: "b be ElementSUBSET-1M1-of {}XBOOLE-0K1"
          have "f .BINOP-1K1(a,b) =HIDDENR1 {}XBOOLE-0K1"
            using A1 funct_1_def_2 sorry
          also have "... = f .BINOP-1K1(b,a)"
            using A1 funct_1_def_2 sorry
          finally show "f .BINOP-1K1(a,b) =HIDDENR1 f .BINOP-1K1(b,a)"
             sorry
        qed "sorry"
        thus "f be commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub>"
          using binop_1_def_2 sorry
      qed
      thus "f be associativeBINOP-1V2\<^bsub>({}XBOOLE-0K1)\<^esub> & f be commutativeBINOP-1V1\<^bsub>({}XBOOLE-0K1)\<^esub>"
        using binop_1_def_3 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mdef binop_1_def_5 (" _ is-a-left-unity-wrtBINOP-1R1\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "e be objectHIDDENM1", "o be BinOpBINOP-1M2-of A"
"pred e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a"..

mdef binop_1_def_6 (" _ is-a-right-unity-wrtBINOP-1R2\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "e be objectHIDDENM1", "o be BinOpBINOP-1M2-of A"
"pred e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a"..

mdef binop_1_def_7 (" _ is-a-unity-wrtBINOP-1R3\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "e be objectHIDDENM1", "o be BinOpBINOP-1M2-of A"
"pred e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o means
  e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o & e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o"..

mtheorem binop_1_th_3:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a)) & (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of A"
    show "e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
    proof-
      have " not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a))"
      proof-
        have "e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o & e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
        proof(rule impI)
          assume "e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o & e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o"
          thus " for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a"
             sorry
        qed
        thus " not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a))"
          using binop_1_def_7 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Cut254: " for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a"
    have "( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a) & ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
    proof-
      show "( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a) & ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
        using Cut254 sorry
    qed
    thus "e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
      using binop_1_def_5 binop_1_def_6 binop_1_def_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_4:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a))"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a)) &  not (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a) &  not e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of A"
    assume A1: "o be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    have "(( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a)) & (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =HIDDENR1 a))"
    proof(rule conjMI,rule impI,rule ballI,rule conjMI)
      show "( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a)"
         sorry
      assume A2: " for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a"
      fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
      show "o .BINOP-1K1(e,a) =XBOOLE-0R4 a"
        using A2 sorry
      have "o .BINOP-1K1(a,e) =HIDDENR1 o .BINOP-1K1(e,a)"
        using A1 sorry
      also have "... = a"
        using A2 sorry
      finally show "o .BINOP-1K1(a,e) =HIDDENR1 a"
         sorry
    qed "sorry"
    thus " not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a)) &  not (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a) &  not e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
      using binop_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_5:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a))"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)) &  not (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a) &  not e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of A"
    assume A1: "o be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    have "(( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)) & (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =HIDDENR1 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a))"
    proof(rule conjMI,rule impI,rule ballI,rule conjMI)
      show "( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a & o .BINOP-1K1(a,e) =XBOOLE-0R4 a) implies ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
         sorry
      assume A2: " for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a"
      fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
      have "o .BINOP-1K1(e,a) =HIDDENR1 o .BINOP-1K1(a,e)"
        using A1 sorry
      also have "... = a"
        using A2 sorry
      finally show "o .BINOP-1K1(e,a) =HIDDENR1 a"
         sorry
      show "o .BINOP-1K1(a,e) =XBOOLE-0R4 a"
        using A2 sorry
    qed "sorry"
    thus " not (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)) &  not (( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a) &  not e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
      using binop_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_6:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o)"
  using binop_1_th_4 sorry

mtheorem binop_1_th_7:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o)"
  using binop_1_th_5 sorry

mtheorem binop_1_th_8:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o iff e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o)"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e be ElementSUBSET-1M1-of A holds o be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o &  not e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o) &  not (e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o &  not e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix e assume [ty]: "e be ElementSUBSET-1M1-of A"
    assume A1: "o be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    then have "e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o iff e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o"
      using binop_1_th_6 sorry
    thus " not (e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o &  not e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o) &  not (e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o &  not e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o)"
      using A1 binop_1_th_7 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_9:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e1 be ElementSUBSET-1M1-of A holds  for e2 be ElementSUBSET-1M1-of A holds e1 is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o & e2 is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o implies e1 =XBOOLE-0R4 e2"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e1 be ElementSUBSET-1M1-of A holds  for e2 be ElementSUBSET-1M1-of A holds e1 is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o & e2 is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o implies e1 =HIDDENR1 e2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix e1 assume [ty]: "e1 be ElementSUBSET-1M1-of A"
    fix e2 assume [ty]: "e2 be ElementSUBSET-1M1-of A"
    assume A1: "e1 is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o"
      and A2: "e2 is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o"
    have "e1 =HIDDENR1 o .BINOP-1K1(e1,e2)"
      using A2 sorry
    also have "... = e2"
      using A1 sorry
    finally show "e1 =HIDDENR1 e2"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_10:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for e1 be ElementSUBSET-1M1-of A holds  for e2 be ElementSUBSET-1M1-of A holds e1 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o & e2 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o implies e1 =XBOOLE-0R4 e2"
  using binop_1_th_9 sorry

mdef binop_1_def_8 ("the-unity-wrtBINOP-1K3\<^bsub>'( _ ')\<^esub>  _ " [0,228]228 ) where
  mlet "A be setHIDDENM2", "o be BinOpBINOP-1M2-of A"
"assume  ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o func the-unity-wrtBINOP-1K3\<^bsub>(A)\<^esub> o \<rightarrow> ElementSUBSET-1M1-of A means
  \<lambda>it. it is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
proof-
  (*existence*)
    show "( ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o) implies ( ex it be ElementSUBSET-1M1-of A st it is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o)"
    proof(rule impI)
      assume Assume: " ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
      have A1: " ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
        using Assume sorry
      show " ex it be ElementSUBSET-1M1-of A st it is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
        using A1 sorry
    qed
  (*uniqueness*)
    show "( ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o) implies ( for it1 be ElementSUBSET-1M1-of A holds  for it2 be ElementSUBSET-1M1-of A holds it1 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o & it2 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o implies it1 =HIDDENR1 it2)"
    proof(rule impI)
      assume Assume: " ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
      have A1: " ex e be ElementSUBSET-1M1-of A st e is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o"
        using Assume sorry
      show " for it1 be ElementSUBSET-1M1-of A holds  for it2 be ElementSUBSET-1M1-of A holds it1 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o & it2 is-a-unity-wrtBINOP-1R3\<^bsub>(A)\<^esub> o implies it1 =HIDDENR1 it2"
        using binop_1_th_10 sorry
    qed
qed "sorry"

mdef binop_1_def_9 (" _ is-left-distributive-wrtBINOP-1R4\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "o9 be BinOpBINOP-1M2-of A", "o be BinOpBINOP-1M2-of A"
"pred o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c))"..

mdef binop_1_def_10 (" _ is-right-distributive-wrtBINOP-1R5\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "o9 be BinOpBINOP-1M2-of A", "o be BinOpBINOP-1M2-of A"
"pred o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))"..

mdef binop_1_def_11 (" _ is-distributive-wrtBINOP-1R6\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "o9 be BinOpBINOP-1M2-of A", "o be BinOpBINOP-1M2-of A"
"pred o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o means
  o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o & o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o"..

mtheorem binop_1_th_11:
" for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))"
proof-
  have " for A be setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))) & (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))) implies o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule conjMI,rule impI)
    fix A assume [ty]: "A be setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix o9 assume [ty]: "o9 be BinOpBINOP-1M2-of A"
    show "o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))"
    proof-
      have " not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))))"
      proof-
        have "o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o & o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))"
        proof(rule impI)
          assume "o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o & o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o"
          thus " for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))"
             sorry
        qed
        thus " not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))))"
          using binop_1_def_11 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    assume Cut362: " for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c)) & o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c))"
    have "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c))) & ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))"
    proof-
      show "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(a,o .BINOP-1K1(b,c)) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,b),o9 .BINOP-1K1(a,c))) & ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K1(o .BINOP-1K1(a,b),c) =XBOOLE-0R4 o .BINOP-1K1(o9 .BINOP-1K1(a,c),o9 .BINOP-1K1(b,c)))"
        using Cut362 sorry
    qed
    thus "o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o"
      using binop_1_def_9 binop_1_def_10 binop_1_def_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_12:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))))"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))) &  not (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))) &  not o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix o9 assume [ty]: "o9 be BinOpBINOP-1M2-of A"
    assume A1: "o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    have "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))"
    proof-
      have "(( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))) & (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =HIDDENR1 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))))"
      proof(rule conjMI,rule impI,rule ballI,rule ballI,rule ballI,rule conjMI)
        show "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))"
           sorry
        assume A2: " for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))"
        fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
        fix b assume [ty]: "b be ElementSUBSET-1M1-of A"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of A"
        show "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))"
          using A2 sorry
        have "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =HIDDENR1 o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b))"
          using A1 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,a),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,b))"
          using A2 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,b))"
          using A1 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))"
          using A1 sorry
        finally show "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =HIDDENR1 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))) &  not (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))) &  not o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o)"
      using binop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_13:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))))"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))) &  not (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) &  not o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix o9 assume [ty]: "o9 be BinOpBINOP-1M2-of A"
    assume A1: "o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    have "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))"
    proof-
      have "(( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))) & (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =HIDDENR1 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))))"
      proof(rule conjMI,rule impI,rule ballI,rule ballI,rule ballI,rule conjMI)
        show "( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)) & o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) implies ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))"
           sorry
        assume A2: " for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))"
        fix a assume [ty]: "a be ElementSUBSET-1M1-of A"
        fix b assume [ty]: "b be ElementSUBSET-1M1-of A"
        fix c assume [ty]: "c be ElementSUBSET-1M1-of A"
        have "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =HIDDENR1 o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c),a)"
          using A1 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,a),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,a))"
          using A2 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(c,a))"
          using A1 sorry
        also have "... = o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))"
          using A1 sorry
        finally show "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =HIDDENR1 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))"
           sorry
        show "o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))"
          using A2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " not (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o &  not ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))) &  not (( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))) &  not o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o)"
      using binop_1_th_11 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_14:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o)"
  using binop_1_th_12 sorry

mtheorem binop_1_th_15:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o)"
  using binop_1_th_13 sorry

mtheorem binop_1_th_16:
" for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies (o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o iff o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o)"
proof-
  have " for A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2 holds  for o be BinOpBINOP-1M2-of A holds  for o9 be BinOpBINOP-1M2-of A holds o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub> implies  not (o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o &  not o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o) &  not (o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o &  not o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o)"
  proof(rule ballI,rule ballI,rule ballI,rule impI)
    fix A assume [ty]: "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
    fix o assume [ty]: "o be BinOpBINOP-1M2-of A"
    fix o9 assume [ty]: "o9 be BinOpBINOP-1M2-of A"
    assume A1: "o9 be commutativeBINOP-1V1\<^bsub>(A)\<^esub>"
    then have "o9 is-distributive-wrtBINOP-1R6\<^bsub>(A)\<^esub> o iff o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o"
      using binop_1_th_14 sorry
    thus " not (o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o &  not o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o) &  not (o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o &  not o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o)"
      using A1 binop_1_th_15 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef binop_1_def_12 (" _ is-distributive-wrtBINOP-1R7\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50 ) where
  mlet "A be setHIDDENM2", "u be UnOpBINOP-1M1-of A", "o be BinOpBINOP-1M2-of A"
"pred u is-distributive-wrtBINOP-1R7\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds u .FUNCT-1K1 (o .BINOP-1K1(a,b)) =XBOOLE-0R4 o .BINOP-1K1(u .FUNCT-1K1 a,u .FUNCT-1K1 b)"..

(*\$CD 3*)
abbreviation(input) BINOP_1R8(" _ is-a-left-unity-wrtBINOP-1R8\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "e is-a-left-unity-wrtBINOP-1R8\<^bsub>(A)\<^esub> o \<equiv> e is-a-left-unity-wrtBINOP-1R1\<^bsub>(A)\<^esub> o"

mtheorem binop_1_def_16:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "e be objectHIDDENM1", "o be BinOpBINOP-1M2-of A"
"redefine pred e is-a-left-unity-wrtBINOP-1R8\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a"
proof
(*compatibility*)
  show "e is-a-left-unity-wrtBINOP-1R8\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(e,a) =XBOOLE-0R4 a)"
     sorry
qed "sorry"

abbreviation(input) BINOP_1R9(" _ is-a-right-unity-wrtBINOP-1R9\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "e is-a-right-unity-wrtBINOP-1R9\<^bsub>(A)\<^esub> o \<equiv> e is-a-right-unity-wrtBINOP-1R2\<^bsub>(A)\<^esub> o"

mtheorem binop_1_def_17:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "e be objectHIDDENM1", "o be BinOpBINOP-1M2-of A"
"redefine pred e is-a-right-unity-wrtBINOP-1R9\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a"
proof
(*compatibility*)
  show "e is-a-right-unity-wrtBINOP-1R9\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds o .BINOP-1K1(a,e) =XBOOLE-0R4 a)"
     sorry
qed "sorry"

abbreviation(input) BINOP_1R10(" _ is-left-distributive-wrtBINOP-1R10\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "o9 is-left-distributive-wrtBINOP-1R10\<^bsub>(A)\<^esub> o \<equiv> o9 is-left-distributive-wrtBINOP-1R4\<^bsub>(A)\<^esub> o"

mtheorem binop_1_def_18:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "o9 be BinOpBINOP-1M2-of A", "o be BinOpBINOP-1M2-of A"
"redefine pred o9 is-left-distributive-wrtBINOP-1R10\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c))"
proof
(*compatibility*)
  show "o9 is-left-distributive-wrtBINOP-1R10\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c)))"
     sorry
qed "sorry"

abbreviation(input) BINOP_1R11(" _ is-right-distributive-wrtBINOP-1R11\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "o9 is-right-distributive-wrtBINOP-1R11\<^bsub>(A)\<^esub> o \<equiv> o9 is-right-distributive-wrtBINOP-1R5\<^bsub>(A)\<^esub> o"

mtheorem binop_1_def_19:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "o9 be BinOpBINOP-1M2-of A", "o be BinOpBINOP-1M2-of A"
"redefine pred o9 is-right-distributive-wrtBINOP-1R11\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c))"
proof
(*compatibility*)
  show "o9 is-right-distributive-wrtBINOP-1R11\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds  for c be ElementSUBSET-1M1-of A holds o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b),c) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,c),o9 .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(b,c)))"
     sorry
qed "sorry"

abbreviation(input) BINOP_1R12(" _ is-distributive-wrtBINOP-1R12\<^bsub>'( _ ')\<^esub>  _ " [50,0,50]50) where
  "u is-distributive-wrtBINOP-1R12\<^bsub>(A)\<^esub> o \<equiv> u is-distributive-wrtBINOP-1R7\<^bsub>(A)\<^esub> o"

mtheorem binop_1_def_20:
  mlet "A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2", "u be UnOpBINOP-1M1-of A", "o be BinOpBINOP-1M2-of A"
"redefine pred u is-distributive-wrtBINOP-1R12\<^bsub>(A)\<^esub> o means
   for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds u .FUNCT-2K3\<^bsub>(A,A)\<^esub> (o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(u .FUNCT-2K3\<^bsub>(A,A)\<^esub> a,u .FUNCT-2K3\<^bsub>(A,A)\<^esub> b)"
proof
(*compatibility*)
  show "u is-distributive-wrtBINOP-1R12\<^bsub>(A)\<^esub> o iff ( for a be ElementSUBSET-1M1-of A holds  for b be ElementSUBSET-1M1-of A holds u .FUNCT-2K3\<^bsub>(A,A)\<^esub> (o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(a,b)) =XBOOLE-0R4 o .BINOP-1K2\<^bsub>(A,A,A)\<^esub>(u .FUNCT-2K3\<^bsub>(A,A)\<^esub> a,u .FUNCT-2K3\<^bsub>(A,A)\<^esub> b))"
     sorry
qed "sorry"

mtheorem binop_1_th_17:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds (x inHIDDENR3 X & y inHIDDENR3 Y) & Z <>HIDDENR2 {}XBOOLE-0K1 implies f .BINOP-1K1(x,y) inTARSKIR2 Z"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds x inHIDDENR3 X & y inHIDDENR3 Y implies  not ( not Z <>HIDDENR2 {}XBOOLE-0K1 &  not f .BINOP-1K1(x,y) inTARSKIR2 Z)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix f assume [ty]: "f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
    assume "x inHIDDENR3 X & y inHIDDENR3 Y"
    then have "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
      using zfmisc_1_th_87 sorry
    thus " not ( not Z <>HIDDENR2 {}XBOOLE-0K1 &  not f .BINOP-1K1(x,y) inTARSKIR2 Z)"
      using funct_2_th_5 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_18:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for g be FunctionFUNCT-1M1 holds (Z <>HIDDENR2 {}XBOOLE-0K1 & x inHIDDENR3 X) & y inHIDDENR3 Y implies (g *FUNCT-1K3 f).BINOP-1K1(x,y) =XBOOLE-0R4 g .FUNCT-1K1 (f .BINOP-1K1(x,y))"
  using funct_2_th_15 zfmisc_1_th_87 sorry

mtheorem binop_1_th_19:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies (f be constantFUNCT-1V5 iff ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y implies f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2)))"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for f be FunctionFUNCT-1M1 holds domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :] implies (f be constantFUNCT-1V5 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y implies f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2))) & (( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y implies f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2)) implies f be constantFUNCT-1V5)"
  proof(rule ballI,rule ballI,rule ballI,rule impI,rule conjMI,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix f assume [ty]: "f be FunctionFUNCT-1M1"
    assume A1: "domRELAT-1K1 f =XBOOLE-0R4 [:ZFMISC-1K2 X,Y :]"
    show "f be constantFUNCT-1V5 implies ( for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y implies f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2))"
    proof(rule impI,rule ballI,rule ballI,rule ballI,rule ballI,rule impI)
      assume A2: "f be constantFUNCT-1V5"
      fix x1 assume [ty]: "x1 be objectHIDDENM1"
      fix x2 assume [ty]: "x2 be objectHIDDENM1"
      fix y1 assume [ty]: "y1 be objectHIDDENM1"
      fix y2 assume [ty]: "y2 be objectHIDDENM1"
      assume "((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y"
      then have "[TARSKIK4 x1,y1 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :] & [TARSKIK4 x2,y2 ] inHIDDENR3 [:ZFMISC-1K2 X,Y :]"
        using zfmisc_1_th_87 sorry
      thus "f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2)"
        using A1 A2 sorry
    qed "sorry"
    assume A3: " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds  for y2 be objectHIDDENM1 holds ((x1 inHIDDENR3 X & x2 inHIDDENR3 X) & y1 inHIDDENR3 Y) & y2 inHIDDENR3 Y implies f .BINOP-1K1(x1,y1) =XBOOLE-0R4 f .BINOP-1K1(x2,y2)"
    have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 domRELAT-1K1 f implies (y inHIDDENR3 domRELAT-1K1 f implies f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y)"
    proof(rule ballI,rule ballI,rule impI,rule impI)
      fix x assume [ty]: "x be objectHIDDENM1"
      fix y assume [ty]: "y be objectHIDDENM1"
      assume "x inHIDDENR3 domRELAT-1K1 f"
      then obtain x1 y1 where
        [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
        A4: "x1 inHIDDENR3 X & y1 inHIDDENR3 Y"and A5: "x =HIDDENR1 [TARSKIK4 x1,y1 ]"
        using A1 zfmisc_1_th_84 sorry
      assume "y inHIDDENR3 domRELAT-1K1 f"
      then obtain x2 y2 where
        [ty]:"x2 be objectHIDDENM1" "y2 be objectHIDDENM1" and 
        A6: "x2 inHIDDENR3 X & y2 inHIDDENR3 Y"and A7: "y =HIDDENR1 [TARSKIK4 x2,y2 ]"
        using A1 zfmisc_1_th_84 sorry
      have "f .FUNCT-1K1 x =HIDDENR1 f .BINOP-1K1(x1,y1)"
        using A5 sorry
      also have "... = f .BINOP-1K1(x2,y2)"
        using A3 A4 A6 sorry
      also have "... = f .FUNCT-1K1 y"
        using A7 sorry
      finally show "f .FUNCT-1K1 x =HIDDENR1 f .FUNCT-1K1 y"
         sorry
    qed "sorry"
    thus "f be constantFUNCT-1V5"
      using funct_1_def_10 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem binop_1_th_20:
" for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for f2 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z) holds domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f2 & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)) implies f1 =RELSET-1R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
proof-
  have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds  for Z be setHIDDENM2 holds  for f1 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z) holds  for f2 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z) holds domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f2 & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)) implies f1 =RELSET-1R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix X assume [ty]: "X be setHIDDENM2"
    fix Y assume [ty]: "Y be setHIDDENM2"
    fix Z assume [ty]: "Z be setHIDDENM2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 X,Y :],Z)"
    assume A1: "domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 =RELSET-1R2\<^bsub>(X,Y)\<^esub> domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f2"
      and A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
    have " for z be objectHIDDENM1 holds z inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1 implies f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
    proof(rule ballI,rule impI)
      fix z assume [ty]: "z be objectHIDDENM1"
      assume A3: "z inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 X,Y :])\<^esub> f1"
      then obtain x y where
        [ty]:"x be objectHIDDENM1" "y be objectHIDDENM1" and 
        A4: "z =HIDDENR1 [TARSKIK4 x,y ]"
        using relat_1_def_1 sorry
      have "f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
        using A2 A3 A4 sorry
      thus "f1 .FUNCT-1K1 z =XBOOLE-0R4 f2 .FUNCT-1K1 z"
        using A4 sorry
    qed "sorry"
    thus "f1 =RELSET-1R2\<^bsub>([:ZFMISC-1K2 X,Y :],Z)\<^esub> f2"
      using A1 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

theorem binop_1_sch_5:
  fixes Xf0 Yf0 Zf0 Pp3 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp3(x,y,z) implies z inHIDDENR3 Zf0" and
   A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp3(x,y,z1)) & Pp3(x,y,z2) implies z1 =HIDDENR1 z2"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies Pp3(x,y,f .BINOP-1K1(x,y)))"
  proof-
    have " ex tVar5 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar5 iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar5 &  not Pp3(x,y,tVar5 .BINOP-1K1(x,y))))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2.  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds Lamb1 =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,Lamb2)"
      have A3: " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] & ?Q(x,z) implies z inHIDDENR3 Zf0"
      proof-
        have " for x be objectHIDDENM1 holds  for z be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] implies (( for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z)) implies z inHIDDENR3 Zf0)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix z assume [ty]: "z be objectHIDDENM1"
          assume "x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"
          then have A4: " ex x1 be objectHIDDENM1 st  ex y1 be objectHIDDENM1 st (x1 inHIDDENR3 Xf0 & y1 inHIDDENR3 Yf0) & x =HIDDENR1 [TARSKIK4 x1,y1 ]"
            using zfmisc_1_def_2 sorry
          assume " for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z)"
          thus "z inHIDDENR3 Zf0"
            using A1 A4 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      have A5: " for x be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds (x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] & ?Q(x,z1)) & ?Q(x,z2) implies z1 =HIDDENR1 z2"
      proof-
        have " for x be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] & (( for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z1)) & ( for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z2))) implies z1 =HIDDENR1 z2"
        proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix z1 assume [ty]: "z1 be objectHIDDENM1"
          fix z2 assume [ty]: "z2 be objectHIDDENM1"
          assume A6: "x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"
            and A7: "( for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z1)) & ( for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds x =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z2))"
          obtain x1 y1 where
            [ty]:"x1 be objectHIDDENM1" "y1 be objectHIDDENM1" and 
            A8: "x1 inHIDDENR3 Xf0 & y1 inHIDDENR3 Yf0"and A9: "x =HIDDENR1 [TARSKIK4 x1,y1 ]"
            using A6 zfmisc_1_def_2 sorry
          have "Pp3(x1,y1,z1) & Pp3(x1,y1,z2)"
            using A7 A9 sorry
          thus "z1 =HIDDENR1 z2"
            using A2 A8 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A10: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff x inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :] & ( ex z be objectHIDDENM1 st ?Q(x,z))"and A11: " for x be objectHIDDENM1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies ?Q(x,f .FUNCT-1K1 x)"
        using partfun1_sch_2 A3 A5 sorry
      show " ex tVar5 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar5 iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar5 &  not Pp3(x,y,tVar5 .BINOP-1K1(x,y))))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))) & (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies (( ex z be objectHIDDENM1 st Pp3(x,y,z)) implies [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f))"
          proof(rule ballI,rule ballI,rule conjMI,rule impI,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            show "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st Pp3(x,y,z))"
            proof-
              have "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex tVar6 be objectHIDDENM1 st Pp3(x,y,tVar6))"
              proof(rule impI,rule conjMI)
                assume A12: "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f"
                thus "x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0"
                  using zfmisc_1_th_87 sorry
                obtain z where
                  [ty]:"z be objectHIDDENM1" and 
                  A13: " for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z)"
                  using A10 A12 sorry
                show " ex tVar6 be objectHIDDENM1 st Pp3(x,y,tVar6)"
                proof(rule bexI[of _ "z"])
                  show "Pp3(x,y,z)"
                    using A13 sorry
                qed "sorry"
              qed
              thus " ?thesis "
                 sorry
            qed
            assume "x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0"
            then have A14: "[TARSKIK4 x,y ] inHIDDENR3 [:ZFMISC-1K2 Xf0,Yf0 :]"
              using zfmisc_1_def_2 sorry
            assume Given: " ex z be objectHIDDENM1 st Pp3(x,y,z)"
            then obtain z where
              [ty]:"z be objectHIDDENM1" and 
              A15: "Pp3(x,y,z)"
               sorry
            have " ex z be objectHIDDENM1 st  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z)"
            proof-
              show " ex z be objectHIDDENM1 st  for x1 be objectHIDDENM1 holds  for y1 be objectHIDDENM1 holds [TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ] implies Pp3(x1,y1,z)"
              proof(rule bexI[of _ "z"],rule ballI,rule ballI,rule impI)
                fix x1 assume [ty]: "x1 be objectHIDDENM1"
                fix y1 assume [ty]: "y1 be objectHIDDENM1"
                assume A16: "[TARSKIK4 x,y ] =HIDDENR1 [TARSKIK4 x1,y1 ]"
                then have "x =HIDDENR1 x1"
                  using xtuple_0_th_1 sorry
                thus "Pp3(x1,y1,z)"
                  using A15 A16 xtuple_0_th_1 sorry
              qed "sorry"
            qed
            thus "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f"
              using A10 A14 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not Pp3(x,y,f .BINOP-1K1(x,y)))"
          using A11 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_1_sch_6:
  fixes Xf0 Yf0 Zf0 Ff2 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
  proof-
    have " ex tVar8 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar8 iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar8 &  not tVar8 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
    proof-
      let ?Q = "\<lambda>Lamb1. \<lambda>Lamb2. \<lambda>Lamb3. Pp2(Lamb1,Lamb2) & Lamb3 =HIDDENR1 Ff2(Lamb1,Lamb2)"
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z1 be objectHIDDENM1 holds  for z2 be objectHIDDENM1 holds ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ?Q(x,y,z1)) & ?Q(x,y,z2) implies z1 =HIDDENR1 z2"
         sorry
      have A3: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for z be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ?Q(x,y,z) implies z inHIDDENR3 Zf0"
        using A1 sorry
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A4: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ( ex z be objectHIDDENM1 st ?Q(x,y,z))"and A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies ?Q(x,y,f .BINOP-1K1(x,y))"
        using binop_1_sch_5 A3 A2 sorry
      show " ex tVar8 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar8 iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar8 &  not tVar8 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
      proof(rule bexI[of _ "f"],rule conjMI)
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)"
        proof-
          have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y) implies [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f)"
          proof(rule ballI,rule ballI,rule conjMI,rule impMI ,rule impI)
            fix x assume [ty]: "x be objectHIDDENM1"
            fix y assume [ty]: "y be objectHIDDENM1"
            show "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)"
            proof(rule impI)
              assume A6: "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f"
              then have " ex z be objectHIDDENM1 st Pp2(x,y) & z =HIDDENR1 Ff2(x,y)"
                using A4 sorry
              thus "(x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)"
                using A4 A6 sorry
            qed
            assume A7: "x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0"
              and A8: "Pp2(x,y)"
            have " ex z be objectHIDDENM1 st Pp2(x,y) & z =HIDDENR1 Ff2(x,y)"
              using A8 sorry
            thus "[TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f"
              using A4 A7 sorry
          qed "sorry"
          thus " ?thesis "
             sorry
        qed
        show " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_1_sch_7:
  fixes Xf0 Yf0 Zf0 Ff2 Pp2 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
  proof-
    have " ex tVar9 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9 &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9 &  not tVar9 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
    proof-
      let ?R = "\<lambda>Lamb1. \<lambda>Lamb2. (Lamb1 inHIDDENR3 Xf0 & Lamb2 inHIDDENR3 Yf0) & Pp2(Lamb1,Lamb2)"
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds ?R(x,y) implies Ff2(x,y) inHIDDENR3 Zf0"
        using A1 sorry
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A3: "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & ?R(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
        using binop_1_sch_6 A2 sorry
      show " ex tVar9 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9 &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar9 &  not tVar9 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
      proof(rule bexI[of _ "f"])
        show "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not ((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y))) &  not (((x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

theorem binop_1_sch_8:
  fixes Xf0 Yf0 Zf0 Ff2 Pp2 
  assumes
[ty]: "Xf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Yf0 be  non emptyXBOOLE-0V1\<bar>setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
  [ty_func]: "\<And> x1 x2. x1 be objectHIDDENM1 \<Longrightarrow> x2 be objectHIDDENM1 \<Longrightarrow> Ff2(x1,x2) be objectHIDDENM1" and
   A1: " for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0"
  shows " ex f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff Pp2(x,y)) & ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
  proof-
    have " ex tVar10 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10 &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10)) & ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10 &  not tVar10 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
    proof-
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y) implies Ff2(x,y) inHIDDENR3 Zf0"
        using A1 sorry
      obtain f where
        [ty]:"f be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A3: "( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f iff (x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0) & Pp2(x,y)) & ( for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f implies f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y))"
        using binop_1_sch_7 A2 sorry
      show " ex tVar10 be PartFuncPARTFUN1M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10 &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10)) & ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> tVar10 &  not tVar10 .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
      proof(rule bexI[of _ "f"])
        show "( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not Pp2(x,y)) &  not (Pp2(x,y) &  not [TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f)) & ( for x be ElementSUBSET-1M1-of Xf0 holds  for y be ElementSUBSET-1M1-of Yf0 holds  not ([TARSKIK4 x,y ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 Xf0,Yf0 :])\<^esub> f &  not f .BINOP-1K1(x,y) =HIDDENR1 Ff2(x,y)))"
          using A3 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

syntax BINOP_1K4 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> Set" (" _ .BINOP-1K4\<^bsub>'( _ ')\<^esub>'( _ , _ ')" [200,0,0,0]200)
translations "f .BINOP-1K4\<^bsub>(A)\<^esub>(a,b)" \<rightharpoonup> "f .BINOP-1K1(a,b)"

mtheorem binop_1_add_2:
  mlet "A be setHIDDENM2", "f be BinOpBINOP-1M2-of A", "a be ElementSUBSET-1M1-of A", "b be ElementSUBSET-1M1-of A"
"cluster f .BINOP-1K1(a,b) as-term-is ElementSUBSET-1M1-of A"
proof
(*coherence*)
  show "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
  proof-
    show "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
    proof-
      have cases: "A <>HIDDENR2 {}XBOOLE-0K1 or A =XBOOLE-0R4 {}XBOOLE-0K1"
         sorry
      have case1: "A <>HIDDENR2 {}XBOOLE-0K1 implies f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
      proof(rule impI)
        assume "A <>HIDDENR2 {}XBOOLE-0K1"
        then have 
          [ty]:"A be  non emptyXBOOLE-0V1\<bar>setHIDDENM2"
           sorry
        have 
          [ty]:"f be BinOpBINOP-1M2-of A"
           sorry
        obtain ab where 
          [ty]:"ab be ElementSUBSET-1M1-of [:ZFMISC-1K2 A,A :]" and abDef:"ab = [TARSKIK4 a,b ]"
          using zfmisc_1_def_2 sorry
        have "f .FUNCT-2K3\<^bsub>([:ZFMISC-1K2 A,A :],A)\<^esub> ab be ElementSUBSET-1M1-of A"
           sorry
        thus "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
           sorry
      qed
      have case2: "A =XBOOLE-0R4 {}XBOOLE-0K1 implies f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
      proof(rule impI)
        assume A1: "A =XBOOLE-0R4 {}XBOOLE-0K1"
        then have " not [TARSKIK4 a,b ] inHIDDENR3 domRELSET-1K1\<^bsub>([:ZFMISC-1K2 A,A :])\<^esub> f"
           sorry
        then have "f .BINOP-1K1(a,b) =XBOOLE-0R4 {}XBOOLE-0K1"
          using funct_1_def_2 sorry
        thus "f .BINOP-1K1(a,b) be ElementSUBSET-1M1-of A"
          using A1 subset_1_def_1 sorry
      qed
      show " ?thesis "
        using cases case1 case2 sorry
    qed
  qed
qed "sorry"

syntax BINOP_1R13 :: " Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow>  Set \<Rightarrow> o" (" _ =BINOP-1R13\<^bsub>'( _ , _ , _ ')\<^esub>  _ " [50,0,0,0,50]50)
translations "f1 =BINOP-1R13\<^bsub>(X,Y,Z)\<^esub> f2" \<rightharpoonup> "f1 =HIDDENR1 f2"

mtheorem binop_1_def_21:
  mlet "X be setHIDDENM2", "Y be setHIDDENM2", "Z be setHIDDENM2", "f1 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)", "f2 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 X,Y :],Z)"
"redefine pred f1 =BINOP-1R13\<^bsub>(X,Y,Z)\<^esub> f2 means
   for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y)"
proof
(*compatibility*)
  show "f1 =BINOP-1R13\<^bsub>(X,Y,Z)\<^esub> f2 iff ( for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 X & y inTARSKIR2 Y implies f1 .BINOP-1K1(x,y) =XBOOLE-0R4 f2 .BINOP-1K1(x,y))"
    using binop_1_th_1 sorry
qed "sorry"

theorem binop_1_sch_9:
  fixes Xf0 Yf0 Zf0 Pp3 
  assumes
[ty]: "Xf0 be setHIDDENM2" and
  [ty]: "Yf0 be setHIDDENM2" and
  [ty]: "Zf0 be setHIDDENM2" and
   A1: " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Xf0 & y inTARSKIR2 Yf0 implies ( ex z be setHIDDENM2 st z inTARSKIR2 Zf0 & Pp3(x,y,z))"
  shows " ex f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds x inTARSKIR2 Xf0 & y inTARSKIR2 Yf0 implies Pp3(x,y,f .BINOP-1K1(x,y))"
  proof-
    have " ex tVar12 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ((x inTARSKIR2 Xf0 & y inTARSKIR2 Yf0) &  not Pp3(x,y,tVar12 .BINOP-1K1(x,y)))"
    proof-
      have A2: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies ( ex z be objectHIDDENM1 st z inHIDDENR3 Zf0 & Pp3(x,y,z))"
      proof-
        have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies ( ex tVar11 be objectHIDDENM1 st tVar11 inHIDDENR3 Zf0 & Pp3(x,y,tVar11))"
        proof(rule ballI,rule ballI,rule impI)
          fix x assume [ty]: "x be objectHIDDENM1"
          fix y assume [ty]: "y be objectHIDDENM1"
          assume A3: "x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0"
          have 
            [ty]:"x be setHIDDENM2" and
            [ty]:"y be setHIDDENM2"
            using tarski_th_1 sorry
          obtain z where
            [ty]:"z be setHIDDENM2" and 
            A4: "z inTARSKIR2 Zf0 & Pp3(x,y,z)"
            using A3 A1 sorry
          show " ex tVar11 be objectHIDDENM1 st tVar11 inHIDDENR3 Zf0 & Pp3(x,y,tVar11)"
          proof(rule bexI[of _ "z"])
            have "z inTARSKIR2 Zf0 & Pp3(x,y,z)"
              using A4 sorry
            thus "z inHIDDENR3 Zf0 & Pp3(x,y,z)"
               sorry
          qed "sorry"
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
      obtain f where
        [ty]:"f be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0)" and 
        A5: " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds x inHIDDENR3 Xf0 & y inHIDDENR3 Yf0 implies Pp3(x,y,f .BINOP-1K1(x,y))"
        using binop_1_sch_1 A2 sorry
      show " ex tVar12 be FunctionFUNCT-2M1-of([:ZFMISC-1K2 Xf0,Yf0 :],Zf0) st  for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ((x inTARSKIR2 Xf0 & y inTARSKIR2 Yf0) &  not Pp3(x,y,tVar12 .BINOP-1K1(x,y)))"
      proof(rule bexI[of _ "f"])
        show " for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  not ((x inTARSKIR2 Xf0 & y inTARSKIR2 Yf0) &  not Pp3(x,y,f .BINOP-1K1(x,y)))"
          using A5 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed

end
