theory fdiff_8
  imports fdiff_7 fdiff_5
   "../mizar_extension/E_number"
begin
(*begin*)
reserve x, a, b, c for "RealXREAL-0M1"
reserve n for "NatNAT-1M1"
reserve Z for "openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
reserve f, f1, f2 for "PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
mtheorem fdiff_8_th_1:
" for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) implies  not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_4 sorry
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    thus " not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using rfunct_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_2:
" for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28) implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
proof-
  have " for x be RealXREAL-0M1 holds x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28) implies  not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
  proof(rule ballI,rule impI)
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cosSIN-COSK19) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using rfunct_1_def_1 sorry
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17) \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> (sinSIN-COSK17)\<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_0_def_4 sorry
    then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using rfunct_1_def_2 sorry
    thus " not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using rfunct_1_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_3:
" for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)#ZPREPOWERK3 n =HIDDENR1 (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 (f2 .FUNCT-1K1 x)#ZPREPOWERK3 n)"
proof-
  have " for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) implies ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)#ZPREPOWERK3 n =HIDDENR1 (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 (f2 .FUNCT-1K1 x)#ZPREPOWERK3 n)"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impI,rule ballI,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
    fix x assume [ty]: "x be RealXREAL-0M1"
    assume "x inHIDDENR3 Z"
    then have "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)#ZPREPOWERK3 n =HIDDENR1 (f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x)#ZPREPOWERK3 n"
      using A1 rfunct_1_def_1 sorry
    also have "... = (f1 .FUNCT-1K1 x /XCMPLX-0K7 f2 .FUNCT-1K1 x) |^NEWTONK1 n"
      using prepower_th_36 sorry
    also have "... = f1 .FUNCT-1K1 x  |^NEWTONK1 n /XCMPLX-0K7 f2 .FUNCT-1K1 x  |^NEWTONK1 n"
      using prepower_th_8 sorry
    also have "... = (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 f2 .FUNCT-1K1 x  |^NEWTONK1 n"
      using prepower_th_36 sorry
    also have "... = (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 (f2 .FUNCT-1K1 x)#ZPREPOWERK3 n"
      using prepower_th_36 sorry
    finally have "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)#ZPREPOWERK3 n =HIDDENR1 (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 (f2 .FUNCT-1K1 x)#ZPREPOWERK3 n"
       sorry
    thus "((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x)#ZPREPOWERK3 n =HIDDENR1 (f1 .FUNCT-1K1 x)#ZPREPOWERK3 n /XCMPLX-0K7 (f2 .FUNCT-1K1 x)#ZPREPOWERK3 n"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_4:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x +XCMPLX-0K2 a & f2 .FUNCT-1K1 x =HIDDENR1 x -XCMPLX-0K6 b) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((-XCMPLX-0K4 a)-XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x +XCMPLX-0K2 a & f2 .FUNCT-1K1 x =HIDDENR1 x -XCMPLX-0K6 b) implies f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((-XCMPLX-0K4 a)-XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 x +XCMPLX-0K2 a & f2 .FUNCT-1K1 x =HIDDENR1 x -XCMPLX-0K6 b"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> (domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 })"
      using A1 rfunct_1_def_1 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
      using xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f2 \\SUBSET-1K7\<^bsub>(REALNUMBERSK2)\<^esub> f2 \<inverse>FUNCT-1K6 {TARSKIK1 0NUMBERSK6 }"
          using A3 sorry
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f2 ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
          using rfunct_1_def_2 sorry
        thus " not f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using rfunct_1_th_3 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (f1 .FUNCT-1K1 x =HIDDENR1 x -XCMPLX-0K6 (-XCMPLX-0K4 a) & f2 .FUNCT-1K1 x =HIDDENR1 x -XCMPLX-0K6 b) & f2 .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using A2 sorry
    thus "f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f1 /RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((-XCMPLX-0K4 a)-XCMPLX-0K6 b)/XCMPLX-0K7 (x -XCMPLX-0K6 b)^2SQUARE-1K1))"
      using A1 fdiff_5_th_3 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma fdiff_8_lm_1:
"right-open-halflineLIMFUNC1K4 (0NUMBERSK6) =HIDDENR1 {g where g be RealXREAL-0M1 : 0NUMBERSK6 <XXREAL-0R3 g }"
  using xxreal_1_th_230 sorry

mtheorem fdiff_8_th_5:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using relat_1_th_25 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A2 xboole_1_th_1 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A5: "x inHIDDENR3 Z"
        then have A6: "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A3 rfunct_1_def_2 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 x"
          using A5 funct_1_th_18 sorry
        finally have "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
           sorry
        have "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A2 A5 funct_1_th_11 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st \<one>\<^sub>M /XCMPLX-0K7 x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using A6 fdiff_8_lm_1 sorry
        thus " not (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A6 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ?f .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A8: "x inHIDDENR3 Z"
        then have "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A4 sorry
        then have "(?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 >XXREAL-0R4 0NUMBERSK6"
          using A3 A8 rfunct_1_def_2 sorry
        thus " not idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A9: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A10: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x & (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
          using A4 A9 fdiff_1_th_9 sorry
        thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using taylor_1_th_20 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A11: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A12: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A13: "x inHIDDENR3 Z"
        then have "?f .FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using A7 sorry
        then have A14: "x <>HIDDENR2 0NUMBERSK6"
          using A13 funct_1_th_18 sorry
        have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using A10 A13 sorry
        also have "... = ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using A9 A13 fdiff_1_def_7 sorry
        also have "... = ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5"
          using A3 A13 rfunct_1_def_2 sorry
        also have "... = ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5)"
          using A13 funct_1_th_18 sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5)"
          using A1 A13 fdiff_5_th_4 sorry
        also have "... = -XCMPLX-0K4 x /XCMPLX-0K7 x ^2SQUARE-1K1"
           sorry
        also have "... = -XCMPLX-0K4 (x /XCMPLX-0K7 x)/XCMPLX-0K7 x"
          using xcmplx_1_th_78 sorry
        also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x"
          using A14 xcmplx_1_th_60 sorry
        finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x"
           sorry
        thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x"
          using A12 A13 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x))"
      using A2 A11 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_6:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using relat_1_th_25 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 xboole_1_th_1 sorry
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 sorry
      then have A8: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      have "f is-differentiable-inFDIFF-1R1 x"
        using A4 A7 fdiff_1_th_9 sorry
      thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      have A12: "(cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 A10 sorry
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      then have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_7_th_46 sorry
      also have "... = (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A2 A10 sorry
      also have "... = (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A4 A10 fdiff_1_def_7 sorry
      also have "... = a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A2 A3 A10 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
         sorry
      thus "(((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_7:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using relat_1_th_25 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A1 xboole_1_th_1 sorry
    then have A4: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 sorry
      then have A8: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      have "f is-differentiable-inFDIFF-1R1 x"
        using A4 A7 fdiff_1_th_9 sorry
      thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "f is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_1_th_9 sorry
      have A12: "(sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 A10 sorry
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 f .FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      then have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,f .FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f,x))"
        using A12 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x))^2SQUARE-1K1"
         sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A2 A10 sorry
      also have "... = -XCMPLX-0K4 (f `|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A4 A10 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A2 A3 A10 fdiff_1_th_23 sorry
      finally have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x) =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
         sorry
      thus "(((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x +XCMPLX-0K2 b))^2SQUARE-1K1))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_8:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using relat_1_th_25 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A2 xboole_1_th_1 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A2 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A7: "x inHIDDENR3 Z"
        then have "(cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using A5 sorry
        then have A8: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using fdiff_7_th_46 sorry
        have "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A3 A7 fdiff_1_th_9 sorry
        thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
          using A8 fdiff_2_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A9: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have A11: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A3 fdiff_1_th_9 sorry
        have A12: "(cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using A5 A10 sorry
        then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using fdiff_7_th_46 sorry
        then have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A11 fdiff_2_th_13 sorry
        also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A12 fdiff_7_th_46 sorry
        also have "... = (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)^2SQUARE-1K1"
          using A4 A10 rfunct_1_def_2 sorry
        also have "... = (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A10 funct_1_th_18 sorry
        also have "... = ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A3 A10 fdiff_1_def_7 sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A1 A10 fdiff_5_th_4 sorry
        also have "... = ((-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1"
           sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
          using xcmplx_1_th_78 sorry
        also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
           sorry
        finally have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
           sorry
        thus "(((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
          using A9 A10 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
      using A2 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_9:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using relat_1_th_25 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A2 xboole_1_th_1 sorry
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A2 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A7: "x inHIDDENR3 Z"
        then have "(sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using A5 sorry
        then have A8: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using fdiff_7_th_47 sorry
        have "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A3 A7 fdiff_1_th_9 sorry
        thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-inFDIFF-1R1 x"
          using A8 fdiff_2_th_13 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have A9: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A10: "x inHIDDENR3 Z"
        then have A11: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-inFDIFF-1R1 x"
          using A3 fdiff_1_th_9 sorry
        have A12: "(sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using A5 A10 sorry
        then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x"
          using fdiff_7_th_47 sorry
        then have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A11 fdiff_2_th_13 sorry
        also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))"
          using A12 fdiff_7_th_47 sorry
        also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x))^2SQUARE-1K1"
           sorry
        also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5)^2SQUARE-1K1"
          using A4 A10 rfunct_1_def_2 sorry
        also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A10 funct_1_th_18 sorry
        also have "... = -XCMPLX-0K4 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A3 A10 fdiff_1_def_7 sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M *XCMPLX-0K3 x \<inverse>XCMPLX-0K5))^2SQUARE-1K1"
          using A1 A10 fdiff_5_th_4 sorry
        also have "... = -XCMPLX-0K4 ((-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 x ^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1"
           sorry
        also have "... = -XCMPLX-0K4 (-XCMPLX-0K4 \<one>\<^sub>M)/XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
          using xcmplx_1_th_78 sorry
        also have "... = \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
           sorry
        finally have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
           sorry
        thus "(((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)"
          using A9 A10 fdiff_1_def_7 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x ^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 (\<one>\<^sub>M /XCMPLX-0K7 x))^2SQUARE-1K1)))"
      using A2 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_10:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using relat_1_th_25 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 xboole_1_th_1 sorry
    then have A5: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_12 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A4 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A7 sorry
      then have A10: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A5 A9 fdiff_1_th_9 sorry
      thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using A10 fdiff_2_th_13 sorry
    qed "sorry"
    then have A11: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A4 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 x +XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A6 A12 valued_1_def_5 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A3 A12 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1"
        using newton_th_81 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1"
         sorry
      have A14: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A5 A12 fdiff_1_th_9 sorry
      have A15: "(cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A7 A12 sorry
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      then have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A14 fdiff_2_th_13 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A15 fdiff_7_th_46 sorry
      also have "... = ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A5 A12 A13 fdiff_1_def_7 sorry
      also have "... = (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A2 A3 A4 A12 fdiff_4_th_12 sorry
      finally have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
         sorry
      thus "(((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A11 A12 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_11:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds (Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for c be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds  for f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) & (f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix c assume [ty]: "c be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f1 assume [ty]: "f1 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    fix f2 assume [ty]: "f2 be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))"
      and A2: "f2 =FUNCT-1R1 #ZTAYLOR-1K1 \<two>\<^sub>M"
      and A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f1 .FUNCT-1K1 x =HIDDENR1 a +XCMPLX-0K2 b *XCMPLX-0K3 x"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using relat_1_th_25 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A1 xboole_1_th_1 sorry
    then have A5: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-onFDIFF-1R2 Z"
      using A2 A3 fdiff_4_th_12 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f1 /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using A4 valued_1_def_1 sorry
    then have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)"
      using xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A8: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A7 sorry
      then have A10: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      have "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A5 A9 fdiff_1_th_9 sorry
      thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-inFDIFF-1R1 x"
        using A10 fdiff_2_th_13 sorry
    qed "sorry"
    then have A11: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A12: "x inHIDDENR3 Z"
      then have A13: "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 f1 .FUNCT-1K1 x +XCMPLX-0K2 (c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using A4 valued_1_def_1 sorry
      also have "... = f1 .FUNCT-1K1 x +XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A6 A12 valued_1_def_5 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 f2 .FUNCT-1K1 x"
        using A3 A12 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x #ZPREPOWERK3 \<two>\<^sub>M"
        using A2 taylor_1_def_1 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x  |^NEWTONK1 \<two>\<^sub>M"
        using prepower_th_36 sorry
      also have "... = (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1"
        using newton_th_81 sorry
      finally have "(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x =HIDDENR1 (a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1"
         sorry
      have A14: "f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2 is-differentiable-inFDIFF-1R1 x"
        using A5 A12 fdiff_1_th_9 sorry
      have A15: "(sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A7 A12 sorry
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      then have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A14 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))"
        using A15 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A13 sorry
      also have "... = -XCMPLX-0K4 ((f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2)`|FDIFF-1K2 Z).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A5 A12 fdiff_1_def_7 sorry
      also have "... = -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A2 A3 A4 A12 fdiff_4_th_12 sorry
      finally have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2),x) =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
         sorry
      thus "(((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1"
        using A11 A12 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (f1 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> c (#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> f2))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (b +XCMPLX-0K2 (\<two>\<^sub>M *XCMPLX-0K3 c)*XCMPLX-0K3 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((a +XCMPLX-0K2 b *XCMPLX-0K3 x)+XCMPLX-0K2 c *XCMPLX-0K3 x ^2SQUARE-1K1))^2SQUARE-1K1))"
      using A1 A8 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_12:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using fdiff_7_th_46 sin_cos_th_65 sorry
      thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    then have A4: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have A6: "(cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using fdiff_7_th_46 sin_cos_th_65 sorry
      then have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,(exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using fdiff_2_th_13 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using A6 fdiff_7_th_46 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      finally have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
         sorry
      thus "(((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
        using A4 A5 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_13:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(exp-RSIN-COSK23).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using fdiff_7_th_47 sin_cos_th_65 sorry
      thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-inFDIFF-1R1 x"
        using fdiff_2_th_13 sorry
    qed "sorry"
    then have A4: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A5: "x inHIDDENR3 Z"
      then have A6: "(sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x & cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (exp-RSIN-COSK23).FUNCT-1K1 x"
        using fdiff_7_th_47 sin_cos_th_65 sorry
      then have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,(exp-RSIN-COSK23).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x))"
        using A6 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(exp-RSIN-COSK23,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
         sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      finally have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23),x) =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
         sorry
      thus "(((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1"
        using A4 A5 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((exp-RSIN-COSK23).FUNCT-1K1 x))^2SQUARE-1K1))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_14:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using relat_1_th_25 sorry
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using A1 xboole_1_th_1 sorry
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A2 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_8_lm_1 sorry
      thus "diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
        using taylor_1_th_18 sorry
    qed "sorry"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(lnTAYLOR-1K3).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 sorry
      then have A8: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      have "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 A7 taylor_1_th_18 sorry
      thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 taylor_1_th_18 sorry
      have A12: "(cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 A10 sorry
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using fdiff_7_th_46 sorry
      then have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A12 fdiff_7_th_46 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1"
        using A4 A10 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
         sorry
      thus "(((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_15:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))"
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using relat_1_th_25 sorry
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using A1 xboole_1_th_1 sorry
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A2 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A3 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_8_lm_1 sorry
      thus "diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
        using taylor_1_th_18 sorry
    qed "sorry"
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(lnTAYLOR-1K3).FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 sorry
      then have A8: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      have "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 A7 taylor_1_th_18 sorry
      thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-inFDIFF-1R1 x"
        using A8 fdiff_2_th_13 sorry
    qed "sorry"
    then have A9: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
        using A3 taylor_1_th_18 sorry
      have A12: "(sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A5 A10 sorry
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 (lnTAYLOR-1K3).FUNCT-1K1 x"
        using fdiff_7_th_47 sorry
      then have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,(lnTAYLOR-1K3).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A11 fdiff_2_th_13 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)*XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x))"
        using A12 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (diffFDIFF-1K1(lnTAYLOR-1K3,x))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1"
         sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1"
        using A4 A10 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
         sorry
      thus "(((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)"
        using A9 A10 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (x *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 ((lnTAYLOR-1K3).FUNCT-1K1 x))^2SQUARE-1K1)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_16:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have A4: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (tanSIN-COSK27).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_2_th_13 sorry
    qed "sorry"
    then have A5: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A6: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (tanSIN-COSK27).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      assume A7: "x inHIDDENR3 Z"
      then have A8: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,(tanSIN-COSK27).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A6 fdiff_2_th_13 sorry
      also have "... = (diffFDIFF-1K1(exp-RSIN-COSK23,(tanSIN-COSK27).FUNCT-1K1 x))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A8 fdiff_7_th_46 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_65 sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27),x) =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (exp-RSIN-COSK23).FUNCT-1K1 ((tanSIN-COSK27).FUNCT-1K1 x) /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_17:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A3: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have A4: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      have "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (cotSIN-COSK28).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
        using A4 fdiff_2_th_13 sorry
    qed "sorry"
    then have A5: "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A6: "exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 (cotSIN-COSK28).FUNCT-1K1 x"
        using sin_cos_th_65 sorry
      assume A7: "x inHIDDENR3 Z"
      then have A8: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      then have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28),x) =HIDDENR1 (diffFDIFF-1K1(exp-RSIN-COSK23,(cotSIN-COSK28).FUNCT-1K1 x))*XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A6 fdiff_2_th_13 sorry
      also have "... = (diffFDIFF-1K1(exp-RSIN-COSK23,(cotSIN-COSK28).FUNCT-1K1 x))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A8 fdiff_7_th_47 sorry
      also have "... = (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using sin_cos_th_65 sorry
      also have "... = -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "diffFDIFF-1K1((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28),x) =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A5 A7 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (exp-RSIN-COSK23).FUNCT-1K1 ((cotSIN-COSK28).FUNCT-1K1 x) /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A3 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_18:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (tanSIN-COSK27).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (tanSIN-COSK27).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(tanSIN-COSK27).FUNCT-1K1 x inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A1 funct_1_th_11 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st (tanSIN-COSK27).FUNCT-1K1 x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not (tanSIN-COSK27).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using relat_1_th_25 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using A1 xboole_1_th_1 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
    qed "sorry"
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & (tanSIN-COSK27).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A7: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & (tanSIN-COSK27).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 A8 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27),x) =HIDDENR1 (diffFDIFF-1K1(tanSIN-COSK27,x))/XCMPLX-0K7 (tanSIN-COSK27).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (tanSIN-COSK27).FUNCT-1K1 x"
        using A9 fdiff_7_th_46 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (tanSIN-COSK27).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x))"
        using A3 A8 rfunct_1_def_1 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      also have "... = (cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_57 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using xcmplx_1_th_78 sorry
      also have "... = (((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using xcmplx_1_th_78 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x"
        using A4 A8 xcmplx_1_th_60 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27),x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A7 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_19:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
    have A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cotSIN-COSK28).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cotSIN-COSK28).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "(cotSIN-COSK28).FUNCT-1K1 x inTARSKIR2 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A1 funct_1_th_11 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st (cotSIN-COSK28).FUNCT-1K1 x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not (cotSIN-COSK28).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using relat_1_th_25 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using A1 xboole_1_th_1 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
    qed "sorry"
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & (cotSIN-COSK28).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 sorry
      thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_20 sorry
    qed "sorry"
    then have A7: "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & (cotSIN-COSK28).FUNCT-1K1 x >XXREAL-0R4 0NUMBERSK6"
        using A2 A5 A8 sorry
      then have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28),x) =HIDDENR1 (diffFDIFF-1K1(cotSIN-COSK28,x))/XCMPLX-0K7 (cotSIN-COSK28).FUNCT-1K1 x"
        using taylor_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (cotSIN-COSK28).FUNCT-1K1 x"
        using A9 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (cotSIN-COSK28).FUNCT-1K1 x"
         sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (cotSIN-COSK28).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x))"
        using A3 A8 rfunct_1_def_1 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      also have "... = -XCMPLX-0K4 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using xcmplx_1_th_57 sorry
      also have "... = -XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 (((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 (\<one>\<^sub>M /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x"
        using A4 A8 xcmplx_1_th_60 sorry
      also have "... = -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      finally have "diffFDIFF-1K1((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28),x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
         sorry
      thus "(((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)"
        using A7 A8 fdiff_1_def_7 sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)))"
      using A1 A6 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_20:
" for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) & \<one>\<^sub>M <=XXREAL-0R1 n implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) & \<one>\<^sub>M <=XXREAL-0R1 n implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 n"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using relat_1_th_25 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A1 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      then have "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A6: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      let ?m = "n -XCMPLX-0K6 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A7: " ex m be NatNAT-1M1 st n =HIDDENR1 m +NAT-1K1 \<one>\<^sub>M"
        using A2 nat_1_th_6 sorry
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      then have A10: "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
      have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27),x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (n *XCMPLX-0K3 ((tanSIN-COSK27).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A10 taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((tanSIN-COSK27).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A9 fdiff_7_th_46 sorry
      also have "... = (n *XCMPLX-0K3 (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 ?m /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 ?m))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A3 A8 A7 fdiff_8_th_3 xboole_1_th_1 sorry
      also have "... = ((n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M)"
        using A4 A8 prepower_th_44 sorry
      also have "... = (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      finally have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (n *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)))"
      using A1 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_21:
" for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) & \<one>\<^sub>M <=XXREAL-0R1 n implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M))"
proof-
  have " for n be NatNAT-1M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) & \<one>\<^sub>M <=XXREAL-0R1 n implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)))"
  proof(rule ballI,rule ballI,rule impMI ,rule impI)
    fix n assume [ty]: "n be NatNAT-1M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
      and A2: "\<one>\<^sub>M <=XXREAL-0R1 n"
    have A3: "domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using relat_1_th_25 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A1 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have A5: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies #ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      then have "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-inFDIFF-1R1 x"
        using taylor_1_th_3 sorry
    qed "sorry"
    then have A6: "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
    proof(rule ballI,rule impI)
      let ?m = "n -XCMPLX-0K6 \<one>\<^sub>M"
      fix x assume [ty]: "x be RealXREAL-0M1"
      have A7: " ex m be NatNAT-1M1 st n =HIDDENR1 m +NAT-1K1 \<one>\<^sub>M"
        using A2 nat_1_th_6 sorry
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 sorry
      then have A10: "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
      have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28),x)"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = (n *XCMPLX-0K3 ((cotSIN-COSK28).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A10 taylor_1_th_3 sorry
      also have "... = (n *XCMPLX-0K3 ((cotSIN-COSK28).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A9 fdiff_7_th_47 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cotSIN-COSK28).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 (((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 ?m /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 ?m))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A1 A3 A8 A7 fdiff_8_th_3 xboole_1_th_1 sorry
      also have "... = -XCMPLX-0K4 ((n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using xcmplx_1_th_78 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 (((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M) *XCMPLX-0K3 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 \<two>\<^sub>M)"
        using fdiff_7_th_1 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 ((n -XCMPLX-0K6 \<one>\<^sub>M)+XCMPLX-0K2 \<two>\<^sub>M)"
        using A4 A8 prepower_th_44 sorry
      also have "... = -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      finally have "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
      thus "((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)"
         sorry
    qed "sorry"
    thus "#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((#ZTAYLOR-1K1 n *PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 -XCMPLX-0K4 (n *XCMPLX-0K3 ((cosSIN-COSK19).FUNCT-1K1 x)#ZPREPOWERK3 (n -XCMPLX-0K6 \<one>\<^sub>M))/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)#ZPREPOWERK3 (n +NAT-1K1 \<one>\<^sub>M)))"
      using A1 A5 fdiff_1_th_9 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_22:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A1 valued_1_def_1 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    then have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using fdiff_8_th_1 sorry
    then have A5: "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_39 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have A6: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A9: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 A7 fdiff_8_th_1 sorry
      have "((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(tanSIN-COSK27,x) +XCMPLX-0K2 diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A1 A5 A6 A7 fdiff_1_th_18 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A9 fdiff_7_th_46 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A7 fdiff_4_th_39 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)-XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
         sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using sin_cos_th_28 sorry
      also have "... = (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))"
         sorry
      also have "... = ((\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A8 xcmplx_1_th_60 sorry
      finally have "((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 +VALUED-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A5 A6 fdiff_1_th_18 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_23:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6) implies tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies \<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6 & \<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A1 valued_1_th_12 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    then have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
      using fdiff_8_th_1 sorry
    then have A5: "(cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using fdiff_4_th_39 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have A6: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A7: "x inHIDDENR3 Z"
      then have A8: "\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A2 sorry
      have A9: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 A7 fdiff_8_th_1 sorry
      have "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(tanSIN-COSK27,x) -XCMPLX-0K6 diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A1 A5 A6 A7 fdiff_1_th_19 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 diffFDIFF-1K1((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)"
        using A9 fdiff_7_th_46 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (((cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A7 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A7 fdiff_4_th_39 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)-XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
         sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using sin_cos_th_28 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 ((\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x))"
         sorry
      also have "... = ((\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (\<one>\<^sub>M -XCMPLX-0K6 (sinSIN-COSK17).FUNCT-1K1 x))/XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using xcmplx_1_th_78 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
        using A8 xcmplx_1_th_60 sorry
      finally have "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
      thus "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)"
         sorry
    qed "sorry"
    thus "tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19)^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 (\<one>\<^sub>M +XCMPLX-0K2 (sinSIN-COSK17).FUNCT-1K1 x)))"
      using A1 A5 A6 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_24:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) implies tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) implies tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A3 xboole_1_th_18 sorry
    then have A6: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have A7: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have A9: "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_1 sorry
      then have A10: "((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using square_1_th_12 sorry
      have "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(tanSIN-COSK27,x) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A2 A6 A7 A8 fdiff_1_th_19 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A9 fdiff_7_th_46 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A6 A8 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
        using A5 A1 A8 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A10 xcmplx_1_th_60 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      also have "... = ((((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)-XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_28 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((tanSIN-COSK27 -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A6 A7 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_25:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) implies (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)"
      using xboole_1_th_18 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using valued_1_th_8 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A5 fdiff_8_th_2 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
        using fdiff_7_th_47 sorry
    qed "sorry"
    then have A6: "cotSIN-COSK28 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_9 sorry
    then have A7: "(-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_20 sorry
    have A8: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A3 xboole_1_th_18 sorry
    then have A9: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_23 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have A11: "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A5 fdiff_8_th_2 sorry
      then have A12: "((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using square_1_th_12 sorry
      have "((?f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(?f,x) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A2 A9 A7 A10 fdiff_1_th_19 sorry
      also have "... = (((-XCMPLX-0K4 \<one>\<^sub>M)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A7 A10 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x)) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A4 A6 A10 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A11 fdiff_7_th_47 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A9 A10 fdiff_1_def_7 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 \<one>\<^sub>M"
        using A8 A1 A10 fdiff_1_th_23 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A12 xcmplx_1_th_60 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      also have "... = ((((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)-XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using sin_cos_th_28 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "((?f -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-VALUED-1K34\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> cotSIN-COSK28)-VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A9 A7 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_26:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6) implies (\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A1 valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using xboole_1_th_18 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A2 sorry
    then have A7: "(tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_8_th_6 sorry
    then have A8: "(\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_20 sorry
    let ?g = "(\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A3 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((sinSIN-COSK17)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cosSIN-COSK19))"
          using A5 funct_1_th_11 sorry
        thus " not (cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_1 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
        using A2 sorry
      have "(cosSIN-COSK19).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A12 A13 sorry
      then have A15: "((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using A14 square_1_th_12 sorry
      have "((?g -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(?g,x) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A1 A8 A11 A13 fdiff_1_th_19 sorry
      also have "... = (?g `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (diffFDIFF-1K1((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A4 A7 A13 fdiff_1_th_20 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A13 fdiff_1_def_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (a /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1) -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 A13 A14 fdiff_8_th_6 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)*XCMPLX-0K3 (a /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M"
        using A10 A9 A13 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A13 xcmplx_1_th_60 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
        using A15 xcmplx_1_th_60 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      also have "... = ((((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 +XCMPLX-0K2 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)-XCMPLX-0K6 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
        using sin_cos_th_28 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      finally have "((?g -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      thus "(((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((\<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((tanSIN-COSK27)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
      using A1 A8 A11 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_27:
" for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6) implies (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x & a <>HIDDENR2 0NUMBERSK6"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A1 valued_1_th_12 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f))"
      using xboole_1_th_18 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
      using valued_1_def_5 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using A2 sorry
    then have A7: "(cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_8_th_7 sorry
    then have A8: "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_20 sorry
    let ?g = "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)"
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z .FUNCT-1K1 x =HIDDENR1 \<one>\<^sub>M *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
      using funct_1_th_18 sorry
    have A10: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)"
      using A3 xboole_1_th_18 sorry
    then have A11: "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z"
      using A9 fdiff_1_th_23 sorry
    have A12: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "f .FUNCT-1K1 x inTARSKIR2 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((cosSIN-COSK19)/RFUNCT-1K3\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> (sinSIN-COSK17))"
          using A5 funct_1_th_11 sorry
        thus " not (sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
          using fdiff_8_th_2 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A13: "x inHIDDENR3 Z"
      then have A14: "f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 0NUMBERSK6"
        using A2 sorry
      have "(sinSIN-COSK17).FUNCT-1K1 (f .FUNCT-1K1 x) <>HIDDENR2 0NUMBERSK6"
        using A12 A13 sorry
      then have A15: "((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 >XXREAL-0R4 0NUMBERSK6"
        using A14 square_1_th_12 sorry
      have "((?g -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 diffFDIFF-1K1(?g,x) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A1 A8 A11 A13 fdiff_1_th_19 sorry
      also have "... = (?g `|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A8 A13 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (diffFDIFF-1K1((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f,x)) -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A4 A7 A13 fdiff_1_th_20 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 diffFDIFF-1K1(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z,x)"
        using A7 A13 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f)`|FDIFF-1K2 Z).FUNCT-1K1 x -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A11 A13 fdiff_1_def_7 sorry
      also have "... = (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)*XCMPLX-0K3 (-XCMPLX-0K4 a /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1) -XCMPLX-0K6 (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z `|FDIFF-1K2 Z).FUNCT-1K1 x"
        using A5 A6 A13 A14 fdiff_8_th_7 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)*XCMPLX-0K3 (a /XCMPLX-0K7 a) -XCMPLX-0K6 \<one>\<^sub>M"
        using A10 A9 A13 fdiff_1_th_23 sorry
      also have "... = (\<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)*XCMPLX-0K3 \<one>\<^sub>M -XCMPLX-0K6 \<one>\<^sub>M"
        using A2 A13 xcmplx_1_th_60 sorry
      also have "... = \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
        using A15 xcmplx_1_th_60 sorry
      also have "... = (\<one>\<^sub>M -XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      also have "... = ((((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 +XCMPLX-0K2 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)-XCMPLX-0K6 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
        using sin_cos_th_28 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      finally have "((?g -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
      thus "(((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 a)(#)VALUED-1K28\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> ((cotSIN-COSK28)*PARTFUN1K1\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> f) -VALUED-1K49\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z)`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 (a *XCMPLX-0K3 x))^2SQUARE-1K1))"
      using A1 A8 A11 fdiff_1_th_19 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_28:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A8: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x)) +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A1 A6 A8 fdiff_1_th_21 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A2 A5 A9 fdiff_1_th_23 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A2 A9 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A7 A9 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (a /XCMPLX-0K7 \<one>\<^sub>M) +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A9 rfunct_1_def_1 sorry
      also have "... = (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A6 A8 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_29:
" for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for a be RealXREAL-0M1 holds  for b be RealXREAL-0M1 holds  for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  for f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2) holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b) implies f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
    fix a assume [ty]: "a be RealXREAL-0M1"
    fix b assume [ty]: "b be RealXREAL-0M1"
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    fix f assume [ty]: "f be PartFuncPARTFUN1M1-of(REALNUMBERSK2,REALNUMBERSK2)"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
      and A2: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies f .FUNCT-1K1 x =HIDDENR1 a *XCMPLX-0K3 x +XCMPLX-0K2 b"
    have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using A1 valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using xboole_1_th_18 sorry
    have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> f"
      using A3 xboole_1_th_18 sorry
    then have A6: "f is-differentiable-onFDIFF-1R2 Z"
      using A2 fdiff_1_th_23 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_2 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_47 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A8: "cotSIN-COSK28 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A9: "x inHIDDENR3 Z"
      then have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(f,x)) +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A1 A6 A8 fdiff_1_th_21 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (f `|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A6 A9 fdiff_1_def_7 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 f .FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A2 A5 A9 fdiff_1_th_23 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A2 A9 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 a +XCMPLX-0K2 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)*XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A7 A9 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (a /XCMPLX-0K7 \<one>\<^sub>M) -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A9 rfunct_1_def_1 sorry
      also have "... = (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not ((f (#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (a *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (a *XCMPLX-0K3 x +XCMPLX-0K2 b)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A6 A8 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_30:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
      using sin_cos_th_65 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using A3 xboole_1_th_18 sorry
    then have A5: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A7: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A2 A5 A7 fdiff_1_th_21 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using sin_cos_th_65 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A6 A8 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 \<one>\<^sub>M) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A8 rfunct_1_def_1 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A5 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_31:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    have A1: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies exp-RSIN-COSK23 is-differentiable-inFDIFF-1R1 x"
      using sin_cos_th_65 sorry
    assume A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using valued_1_def_4 sorry
    then have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using xboole_1_th_18 sorry
    have "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (exp-RSIN-COSK23)"
      using A3 xboole_1_th_18 sorry
    then have A5: "exp-RSIN-COSK23 is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_1_th_9 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A4 fdiff_8_th_2 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_47 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A7: "cotSIN-COSK28 is-differentiable-onFDIFF-1R2 Z"
      using A4 fdiff_1_th_9 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A8: "x inHIDDENR3 Z"
      then have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(exp-RSIN-COSK23,x)) +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A2 A5 A7 fdiff_1_th_21 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using sin_cos_th_65 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (exp-RSIN-COSK23).FUNCT-1K1 x +XCMPLX-0K2 (exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A6 A8 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 ((exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 \<one>\<^sub>M) -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A4 A8 rfunct_1_def_1 sorry
      also have "... = ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      finally have "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((exp-RSIN-COSK23)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((exp-RSIN-COSK23).FUNCT-1K1 x *XCMPLX-0K3 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x -XCMPLX-0K6 (exp-RSIN-COSK23).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A5 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_32:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using valued_1_def_4 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A5: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using A2 xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A6 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
      using taylor_1_th_18 sorry
    then have A8: "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A7 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_8_lm_1 sorry
      thus "diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
        using taylor_1_th_18 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x)) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A1 A8 A5 fdiff_1_th_21 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
        using A9 A10 sorry
      also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A4 A10 sorry
      also have "... = ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using A3 A10 rfunct_1_def_1 sorry
      finally have "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A8 A5 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_33:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    assume A1: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
    then have A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using valued_1_def_4 sorry
    then have A3: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using xboole_1_th_18 sorry
    have A4: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A3 fdiff_8_th_2 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_47 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A5: "cotSIN-COSK28 is-differentiable-onFDIFF-1R2 Z"
      using A3 fdiff_1_th_9 sorry
    have A6: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (lnTAYLOR-1K3)"
      using A2 xboole_1_th_18 sorry
    have A7: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies x >XXREAL-0R4 0NUMBERSK6"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies  not x >XXREAL-0R4 0NUMBERSK6"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume "x inHIDDENR3 Z"
        then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
          using A6 taylor_1_th_18 sorry
        then have " ex g be RealXREAL-0M1 st x =HIDDENR1 g & 0NUMBERSK6 <XXREAL-0R3 g"
          using fdiff_8_lm_1 sorry
        thus " not x >XXREAL-0R4 0NUMBERSK6"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies lnTAYLOR-1K3 is-differentiable-inFDIFF-1R1 x"
      using taylor_1_th_18 sorry
    then have A8: "lnTAYLOR-1K3 is-differentiable-onFDIFF-1R2 Z"
      using A6 fdiff_1_th_9 sorry
    have A9: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "x >XXREAL-0R4 0NUMBERSK6"
        using A7 sorry
      then have "x inHIDDENR3 right-open-halflineLIMFUNC1K4 (0NUMBERSK6)"
        using fdiff_8_lm_1 sorry
      thus "diffFDIFF-1K1(lnTAYLOR-1K3,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 x"
        using taylor_1_th_18 sorry
    qed "sorry"
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume A10: "x inHIDDENR3 Z"
      then have "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(lnTAYLOR-1K3,x)) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A1 A8 A5 fdiff_1_th_21 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
        using A9 A10 sorry
      also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x) +XCMPLX-0K2 (lnTAYLOR-1K3).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
        using A4 A10 sorry
      also have "... = ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using A3 A10 rfunct_1_def_1 sorry
      finally have "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
      thus "(((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
         sorry
    qed "sorry"
    thus "(lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((lnTAYLOR-1K3)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x -XCMPLX-0K6 (lnTAYLOR-1K3).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A1 A8 A5 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_34:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using A2 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (tanSIN-COSK27)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(cosSIN-COSK19).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A5 fdiff_8_th_1 sorry
      thus "tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(tanSIN-COSK27,x) =HIDDENR1 \<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_46 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies tanSIN-COSK27 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A7: "tanSIN-COSK27 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_9 sorry
    have A8: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A4 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A9: "x inHIDDENR3 Z"
        then have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
          using A2 A3 A7 fdiff_1_th_21 sorry
        also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
          using A3 A9 fdiff_1_def_7 sorry
        also have "... = (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(tanSIN-COSK27,x))"
          using A1 A9 fdiff_5_th_4 sorry
        also have "... = (-XCMPLX-0K4 (tanSIN-COSK27).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))+XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1)"
          using A6 A9 sorry
        also have "... = (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))+XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
          using A5 A9 rfunct_1_def_1 sorry
        also have "... = (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 /XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
          using A8 A9 rfunct_1_def_2 sorry
        also have "... = (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
          using A9 funct_1_th_18 sorry
        finally have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
           sorry
        thus "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (tanSIN-COSK27))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((sinSIN-COSK17).FUNCT-1K1 x /XCMPLX-0K7 (cosSIN-COSK19).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)+XCMPLX-0K2 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((cosSIN-COSK19).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A3 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem fdiff_8_th_35:
" for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
proof-
  have " for Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2 holds  not 0NUMBERSK6 inTARSKIR2 Z & Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28)) implies (idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
  proof(rule ballI,rule impMI ,rule impI)
    fix Z assume [ty]: "Z be openRCOMP-1V3\<bar>SubsetSUBSET-1M2-of REALNUMBERSK2"
    let ?f = "idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z"
    assume A1: " not 0NUMBERSK6 inTARSKIR2 Z"
      and A2: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))"
    have A3: "?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub> is-differentiable-onFDIFF-1R2 Z"
      using A1 fdiff_5_th_4 sorry
    have A4: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>) /\\SUBSET-1K9\<^bsub>(REALNUMBERSK2)\<^esub> domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using A2 valued_1_def_4 sorry
    then have A5: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (cotSIN-COSK28)"
      using xboole_1_th_18 sorry
    have A6: " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof(rule ballI,rule impI)
      fix x assume [ty]: "x be RealXREAL-0M1"
      assume "x inHIDDENR3 Z"
      then have "(sinSIN-COSK17).FUNCT-1K1 x <>HIDDENR2 0NUMBERSK6"
        using A5 fdiff_8_th_2 sorry
      thus "cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x & diffFDIFF-1K1(cotSIN-COSK28,x) =HIDDENR1 -XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
        using fdiff_7_th_47 sorry
    qed "sorry"
    then have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies cotSIN-COSK28 is-differentiable-inFDIFF-1R1 x"
       sorry
    then have A7: "cotSIN-COSK28 is-differentiable-onFDIFF-1R2 Z"
      using A5 fdiff_1_th_9 sorry
    have A8: "Z c=TARSKIR1 domRELSET-1K1\<^bsub>(REALNUMBERSK2)\<^esub> (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)"
      using A4 xboole_1_th_18 sorry
    have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
    proof-
      have " for x be RealXREAL-0M1 holds x inHIDDENR3 Z implies (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
      proof(rule ballI,rule impI)
        fix x assume [ty]: "x be RealXREAL-0M1"
        assume A9: "x inHIDDENR3 Z"
        then have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>,x)) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
          using A2 A3 A7 fdiff_1_th_21 sorry
        also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 ((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)`|FDIFF-1K2 Z).FUNCT-1K1 x +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
          using A3 A9 fdiff_1_def_7 sorry
        also have "... = (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1) +XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (diffFDIFF-1K1(cotSIN-COSK28,x))"
          using A1 A9 fdiff_5_th_4 sorry
        also have "... = (-XCMPLX-0K4 (cotSIN-COSK28).FUNCT-1K1 x *XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))+XCMPLX-0K2 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x *XCMPLX-0K3 (-XCMPLX-0K4 \<one>\<^sub>M /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1)"
          using A6 A9 sorry
        also have "... = (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)*XCMPLX-0K3 (\<one>\<^sub>M /XCMPLX-0K7 x ^2SQUARE-1K1))-XCMPLX-0K6 (?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>).FUNCT-1K1 x /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
          using A5 A9 rfunct_1_def_1 sorry
        also have "... = (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (?f .FUNCT-1K1 x)\<inverse>XCMPLX-0K5 /XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
          using A8 A9 rfunct_1_def_2 sorry
        also have "... = (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
          using A9 funct_1_th_18 sorry
        finally have "(((?f ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
           sorry
        thus "(((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1"
           sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus "(idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28) is-differentiable-onFDIFF-1R2 Z & ( for x be RealXREAL-0M1 holds  not (x inHIDDENR3 Z &  not (((idPARTFUN2K1\<^bsub>(REALNUMBERSK2)\<^esub> Z ^RFUNCT-1K6\<^bsub>(REALNUMBERSK2,REALNUMBERSK2)\<^esub>)(#)VALUED-1K21\<^bsub>(REALNUMBERSK2,REALNUMBERSK2,REALNUMBERSK2)\<^esub> (cotSIN-COSK28))`|FDIFF-1K2 Z).FUNCT-1K1 x =HIDDENR1 (-XCMPLX-0K4 ((cosSIN-COSK19).FUNCT-1K1 x /XCMPLX-0K7 (sinSIN-COSK17).FUNCT-1K1 x)/XCMPLX-0K7 x ^2SQUARE-1K1)-XCMPLX-0K6 (\<one>\<^sub>M /XCMPLX-0K7 x)/XCMPLX-0K7 ((sinSIN-COSK17).FUNCT-1K1 x)^2SQUARE-1K1))"
      using A2 A3 A7 fdiff_1_th_21 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
