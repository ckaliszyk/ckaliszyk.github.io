theory enumset1
  imports xboole_1
begin
(*begin*)
reserve x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, y for "objectHIDDENM1"
reserve X, Z for "setHIDDENM2"
mlemma enumset1_lm_1:
" for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} } iff x inHIDDENR3 X or x =HIDDENR1 y"
proof-
  have " for x be objectHIDDENM1 holds  for y be objectHIDDENM1 holds  for X be setHIDDENM2 holds  not ((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} } &  not x inHIDDENR3 X) &  not x =HIDDENR1 y) &  not ( not ( not x inHIDDENR3 X &  not x =HIDDENR1 y) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} })"
  proof(rule ballI,rule ballI,rule ballI)
    fix x assume [ty]: "x be objectHIDDENM1"
    fix y assume [ty]: "y be objectHIDDENM1"
    fix X assume [ty]: "X be setHIDDENM2"
    have A1: "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} } implies x inHIDDENR3 X or x inHIDDENR3 {TARSKIK1 y}"
    proof-
      have "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} } implies  not ( not x inHIDDENR3 X &  not x inHIDDENR3 {TARSKIK1 y})"
      proof(rule impI)
        assume "x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} }"
        then have " ex Z be setHIDDENM2 st x inHIDDENR3 Z & Z inTARSKIR2 {TARSKIK2 X,{TARSKIK1 y} }"
          using tarski_def_4 sorry
        thus " not ( not x inHIDDENR3 X &  not x inHIDDENR3 {TARSKIK1 y})"
          using tarski_def_2 sorry
      qed
      thus " ?thesis "
         sorry
    qed
    have A2: "x inHIDDENR3 {TARSKIK1 y} iff x =HIDDENR1 y"
      using tarski_def_1 sorry
    have "X inTARSKIR2 {TARSKIK2 X,{TARSKIK1 y} } & {TARSKIK1 y} inTARSKIR2 {TARSKIK2 X,{TARSKIK1 y} }"
      using tarski_def_2 sorry
    thus " not ((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} } &  not x inHIDDENR3 X) &  not x =HIDDENR1 y) &  not ( not ( not x inHIDDENR3 X &  not x =HIDDENR1 y) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 X,{TARSKIK1 y} })"
      using A1 A2 tarski_def_4 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mdef enumset1_def_1 ("{ENUMSET1K1 _ , _ , _ }" [0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1"
"func {ENUMSET1K1 x1,x2,x3 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3"
    proof-
      have " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((x inHIDDENR3 tVar1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 tVar1)"
      proof-
        show " ex tVar1 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((x inHIDDENR3 tVar1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 tVar1)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {TARSKIK2 x1,x2 },{TARSKIK1 x3} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {TARSKIK2 x1,x2 } iff x =HIDDENR1 x1 or x =HIDDENR1 x2"
            using tarski_def_2 sorry
          thus " not (((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {TARSKIK2 x1,x2 },{TARSKIK1 x3} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {TARSKIK2 x1,x2 },{TARSKIK1 x3} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. (Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not ( not (( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_2 ("{ENUMSET1K2 _ , _ , _ , _ }" [0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1"
"func {ENUMSET1K2 x1,x2,x3,x4 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
    proof-
      have " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 tVar2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 tVar2)"
      proof-
        show " ex tVar2 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 tVar2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 tVar2)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K1 x1,x2,x3 },{TARSKIK1 x4} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3"
            using enumset1_def_1 sorry
          thus " not ((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K1 x1,x2,x3 },{TARSKIK1 x4} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K1 x1,x2,x3 },{TARSKIK1 x4} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. ((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not ( not ((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_3 ("{ENUMSET1K3 _ , _ , _ , _ , _ }" [0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1"
"func {ENUMSET1K3 x1,x2,x3,x4,x5 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5"
    proof-
      have " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 tVar3 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 tVar3)"
      proof-
        show " ex tVar3 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 tVar3 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 tVar3)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K2 x1,x2,x3,x4 },{TARSKIK1 x5} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
            using enumset1_def_2 sorry
          thus " not (((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K2 x1,x2,x3,x4 },{TARSKIK1 x5} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K2 x1,x2,x3,x4 },{TARSKIK1 x5} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. (((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not ( not (((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_4 ("{ENUMSET1K4 _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1"
"func {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6"
    proof-
      have " ex tVar4 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 tVar4 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 tVar4)"
      proof-
        show " ex tVar4 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 tVar4 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 tVar4)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K3 x1,x2,x3,x4,x5 },{TARSKIK1 x6} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5"
            using enumset1_def_3 sorry
          thus " not ((((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K3 x1,x2,x3,x4,x5 },{TARSKIK1 x6} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K3 x1,x2,x3,x4,x5 },{TARSKIK1 x6} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. ((((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5) or Lamb1 =HIDDENR1 x6"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not ( not ((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_5 ("{ENUMSET1K5 _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1"
"func {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7"
    proof-
      have " ex tVar5 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 tVar5 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 tVar5)"
      proof-
        show " ex tVar5 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 tVar5 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 tVar5)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 },{TARSKIK1 x7} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6"
            using enumset1_def_4 sorry
          thus " not (((((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 },{TARSKIK1 x7} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 },{TARSKIK1 x7} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. (((((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5) or Lamb1 =HIDDENR1 x6) or Lamb1 =HIDDENR1 x7"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not (((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not ( not (((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_6 ("{ENUMSET1K6 _ , _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1"
"func {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8"
    proof-
      have " ex tVar6 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 tVar6 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 tVar6)"
      proof-
        show " ex tVar6 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 tVar6 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 tVar6)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 },{TARSKIK1 x8} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } iff (((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7"
            using enumset1_def_5 sorry
          thus " not ((((((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 },{TARSKIK1 x8} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 },{TARSKIK1 x8} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) implies it1 =HIDDENR1 it2"
    proof-
      have " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
      proof-
        let ?P = "\<lambda>Lamb1. ((((((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5) or Lamb1 =HIDDENR1 x6) or Lamb1 =HIDDENR1 x7) or Lamb1 =HIDDENR1 x8"
        have " for X1 be setHIDDENM2 holds  for X2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X1 iff ?P(x)) & ( for x be objectHIDDENM1 holds x inHIDDENR3 X2 iff ?P(x)) implies X1 =XBOOLE-0R4 X2"
          using xboole_0_sch_3 sorry
        thus " for VarFor1 be setHIDDENM2 holds  for VarFor2 be setHIDDENM2 holds  not ((( for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 VarFor1 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 VarFor1)) & ( for x be objectHIDDENM1 holds  not ((((((((x inHIDDENR3 VarFor2 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not ( not ((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x inHIDDENR3 VarFor2))) &  not VarFor1 =HIDDENR1 VarFor2)"
           sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_7 ("{ENUMSET1K7 _ , _ , _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1", "x9 be objectHIDDENM1"
"func {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9"
    proof-
      have " ex tVar7 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((((((x inHIDDENR3 tVar7 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not ( not (((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x inHIDDENR3 tVar7)"
      proof-
        show " ex tVar7 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not (((((((((x inHIDDENR3 tVar7 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not ( not (((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x inHIDDENR3 tVar7)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 },{TARSKIK1 x9} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } iff ((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8"
            using enumset1_def_6 sorry
          thus " not (((((((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 },{TARSKIK1 x9} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not ( not (((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 },{TARSKIK1 x9} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) implies X =XBOOLE-0R4 Y"
      proof-
        let ?P = "\<lambda>Lamb1. (((((((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5) or Lamb1 =HIDDENR1 x6) or Lamb1 =HIDDENR1 x7) or Lamb1 =HIDDENR1 x8) or Lamb1 =HIDDENR1 x9"
        show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) implies X =XBOOLE-0R4 Y"
          using xboole_0_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mdef enumset1_def_8 ("{ENUMSET1K8 _ , _ , _ , _ , _ , _ , _ , _ , _ , _ }" [0,0,0,0,0,0,0,0,0,0]356 ) where
  mlet "x1 be objectHIDDENM1", "x2 be objectHIDDENM1", "x3 be objectHIDDENM1", "x4 be objectHIDDENM1", "x5 be objectHIDDENM1", "x6 be objectHIDDENM1", "x7 be objectHIDDENM1", "x8 be objectHIDDENM1", "x9 be objectHIDDENM1", "x10 be objectHIDDENM1"
"func {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } \<rightarrow> setHIDDENM2 means
  \<lambda>it.  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10"
proof-
  (*existence*)
    show " ex it be setHIDDENM2 st  for x be objectHIDDENM1 holds x inHIDDENR3 it iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10"
    proof-
      have " ex tVar8 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((((((x inHIDDENR3 tVar8 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not ( not ((((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not x inHIDDENR3 tVar8)"
      proof-
        show " ex tVar8 be setHIDDENM2 st  for x be objectHIDDENM1 holds  not ((((((((((x inHIDDENR3 tVar8 &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not ( not ((((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not x inHIDDENR3 tVar8)"
        proof(rule bexI[of _ "unionTARSKIK3 {TARSKIK2 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 },{TARSKIK1 x10} }"],rule ballI)
          fix x assume [ty]: "x be objectHIDDENM1"
          have "x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } iff (((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9"
            using enumset1_def_7 sorry
          thus " not ((((((((((x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 },{TARSKIK1 x10} } &  not x =HIDDENR1 x1) &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not ( not ((((((((( not x =HIDDENR1 x1 &  not x =HIDDENR1 x2) &  not x =HIDDENR1 x3) &  not x =HIDDENR1 x4) &  not x =HIDDENR1 x5) &  not x =HIDDENR1 x6) &  not x =HIDDENR1 x7) &  not x =HIDDENR1 x8) &  not x =HIDDENR1 x9) &  not x =HIDDENR1 x10) &  not x inHIDDENR3 unionTARSKIK3 {TARSKIK2 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 },{TARSKIK1 x10} })"
            using enumset1_lm_1 sorry
        qed "sorry"
      qed
      thus " ?thesis "
         sorry
    qed
  (*uniqueness*)
    show " for it1 be setHIDDENM2 holds  for it2 be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 it1 iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) & ( for x be objectHIDDENM1 holds x inHIDDENR3 it2 iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) implies it1 =HIDDENR1 it2"
    proof-
      have " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) implies X =XBOOLE-0R4 Y"
      proof-
        let ?P = "\<lambda>Lamb1. ((((((((Lamb1 =HIDDENR1 x1 or Lamb1 =HIDDENR1 x2) or Lamb1 =HIDDENR1 x3) or Lamb1 =HIDDENR1 x4) or Lamb1 =HIDDENR1 x5) or Lamb1 =HIDDENR1 x6) or Lamb1 =HIDDENR1 x7) or Lamb1 =HIDDENR1 x8) or Lamb1 =HIDDENR1 x9) or Lamb1 =HIDDENR1 x10"
        show " for X be setHIDDENM2 holds  for Y be setHIDDENM2 holds ( for x be objectHIDDENM1 holds x inHIDDENR3 X iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) & ( for x be objectHIDDENM1 holds x inHIDDENR3 Y iff ((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10) implies X =XBOOLE-0R4 Y"
          using xboole_0_sch_3 sorry
      qed
      thus " ?thesis "
         sorry
    qed
qed "sorry"

mtheorem enumset1_th_1:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK2 x1,x2 } iff x inHIDDENR3 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {TARSKIK2 x1,x2 } iff x =HIDDENR1 x1 or x =HIDDENR1 x2"
        using tarski_def_2 sorry
      then have "x inHIDDENR3 {TARSKIK2 x1,x2 } iff x inHIDDENR3 {TARSKIK1 x1} or x inHIDDENR3 {TARSKIK1 x2}"
        using tarski_def_1 sorry
      thus "x inHIDDENR3 {TARSKIK2 x1,x2 } iff x inHIDDENR3 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "{TARSKIK2 x1,x2 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_2:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } iff x inHIDDENR3 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } iff (x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3"
        using enumset1_def_1 sorry
      then have "x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } iff x inHIDDENR3 {TARSKIK1 x1} or x inHIDDENR3 {TARSKIK2 x2,x3 }"
        using tarski_def_1 tarski_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } iff x inHIDDENR3 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using enumset1_th_2 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({TARSKIK1 x2} \\/XBOOLE-0K2 {TARSKIK1 x3})"
      using enumset1_th_1 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2})\\/XBOOLE-0K2 {TARSKIK1 x3}"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
      using enumset1_th_1 sorry
    finally show "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_2:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff x inHIDDENR3 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
        using enumset1_def_2 sorry
      then have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff x inHIDDENR3 {TARSKIK2 x1,x2 } or x inHIDDENR3 {TARSKIK2 x3,x4 }"
        using tarski_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff x inHIDDENR3 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_4:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
      using enumset1_lm_2 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2})\\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
      using enumset1_th_1 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({TARSKIK1 x2} \\/XBOOLE-0K2 {TARSKIK2 x3,x4 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_2 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_5:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
  using enumset1_lm_2 sorry

mtheorem enumset1_th_6:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 }"
      using enumset1_lm_2 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK1 x3} \\/XBOOLE-0K2 {TARSKIK1 x4})"
      using enumset1_th_1 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3})\\/XBOOLE-0K2 {TARSKIK1 x4}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_3 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_3:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } iff (((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5"
        using enumset1_def_3 sorry
      then have "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } or x inHIDDENR3 {TARSKIK2 x4,x5 }"
        using enumset1_def_1 tarski_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K3 x1,x2,x3,x4,x5 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_7:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using enumset1_lm_3 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 })\\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using enumset1_th_2 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({TARSKIK2 x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
      using enumset1_lm_2 sorry
    finally show "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_8:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K1 x3,x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K1 x3,x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using enumset1_lm_3 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3})\\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using enumset1_th_3 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK1 x3} \\/XBOOLE-0K2 {TARSKIK2 x4,x5 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K1 x3,x4,x5 }"
      using enumset1_th_2 sorry
    finally show "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K1 x3,x4,x5 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_9:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
  using enumset1_lm_3 sorry

mtheorem enumset1_th_10:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 }"
      using enumset1_lm_3 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK1 x4} \\/XBOOLE-0K2 {TARSKIK1 x5})"
      using enumset1_th_1 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4})\\/XBOOLE-0K2 {TARSKIK1 x5}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5}"
      using enumset1_th_6 sorry
    finally show "{ENUMSET1K3 x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_4:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } iff ((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6"
        using enumset1_def_4 sorry
      then have "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } or x inHIDDENR3 {ENUMSET1K1 x4,x5,x6 }"
        using enumset1_def_1 sorry
      thus "x inHIDDENR3 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } iff x inHIDDENR3 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
        using xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_11:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_lm_4 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 })\\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_th_2 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({TARSKIK2 x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using enumset1_th_8 sorry
    finally show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_12:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K2 x3,x4,x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K2 x3,x4,x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_lm_4 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3})\\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_th_3 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK1 x3} \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K2 x3,x4,x5,x6 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K2 x3,x4,x5,x6 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_13:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
  using enumset1_lm_4 sorry

mtheorem enumset1_th_14:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_lm_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK1 x4} \\/XBOOLE-0K2 {TARSKIK2 x5,x6 })"
      using enumset1_th_2 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4})\\/XBOOLE-0K2 {TARSKIK2 x5,x6 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 }"
      using enumset1_th_6 sorry
    finally show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_15:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK1 x6}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK1 x6}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K1 x4,x5,x6 }"
      using enumset1_lm_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK2 x4,x5 } \\/XBOOLE-0K2 {TARSKIK1 x6})"
      using enumset1_th_3 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK2 x4,x5 })\\/XBOOLE-0K2 {TARSKIK1 x6}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK1 x6}"
      using enumset1_lm_3 sorry
    finally show "{ENUMSET1K4 x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK1 x6}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_5:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 {ENUMSET1K1 x5,x6,x7 } iff (x =HIDDENR1 x5 or x =HIDDENR1 x6) or x =HIDDENR1 x7"
        using enumset1_def_1 sorry
      have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
        using enumset1_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
        using A1 enumset1_def_5 xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_16:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_5 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({ENUMSET1K1 x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using enumset1_lm_4 sorry
    finally show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_17:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K3 x3,x4,x5,x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K3 x3,x4,x5,x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_5 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_2 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK2 x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K3 x3,x4,x5,x6,x7 }"
      using enumset1_th_8 sorry
    finally show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K3 x3,x4,x5,x6,x7 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_18:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K2 x4,x5,x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K2 x4,x5,x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_5 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4})\\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK1 x4} \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 })"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K2 x4,x5,x6,x7 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K2 x4,x5,x6,x7 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_19:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
  using enumset1_lm_5 sorry

mtheorem enumset1_th_20:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK2 x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK2 x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_5 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK1 x5} \\/XBOOLE-0K2 {TARSKIK2 x6,x7 })"
      using enumset1_th_2 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5})\\/XBOOLE-0K2 {TARSKIK2 x6,x7 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK2 x6,x7 }"
      using enumset1_th_10 sorry
    finally show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {TARSKIK2 x6,x7 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_21:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK1 x7}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK1 x7}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 }"
      using enumset1_lm_5 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK2 x5,x6 } \\/XBOOLE-0K2 {TARSKIK1 x7})"
      using enumset1_th_3 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 })\\/XBOOLE-0K2 {TARSKIK1 x7}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK1 x7}"
      using enumset1_th_14 sorry
    finally show "{ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK1 x7}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_6:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 {ENUMSET1K2 x5,x6,x7,x8 } iff ((x =HIDDENR1 x5 or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8"
        using enumset1_def_2 sorry
      have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
        using enumset1_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
        using A1 enumset1_def_6 xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_22:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({ENUMSET1K1 x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
      using enumset1_th_18 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K5 x2,x3,x4,x5,x6,x7,x8 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_23:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K4 x3,x4,x5,x6,x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K4 x3,x4,x5,x6,x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_2 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK2 x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K4 x3,x4,x5,x6,x7,x8 }"
      using enumset1_th_12 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K4 x3,x4,x5,x6,x7,x8 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_24:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K3 x4,x5,x6,x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K3 x4,x5,x6,x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4})\\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK1 x4} \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 })"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K3 x4,x5,x6,x7,x8 }"
      using enumset1_th_7 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K3 x4,x5,x6,x7,x8 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_25:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
  using enumset1_lm_6 sorry

mtheorem enumset1_th_26:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK1 x5} \\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 })"
      using enumset1_th_4 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5})\\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 }"
      using enumset1_th_10 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K1 x6,x7,x8 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_27:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK2 x7,x8 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK2 x7,x8 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK2 x5,x6 } \\/XBOOLE-0K2 {TARSKIK2 x7,x8 })"
      using enumset1_lm_2 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 })\\/XBOOLE-0K2 {TARSKIK2 x7,x8 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK2 x7,x8 }"
      using enumset1_th_14 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {TARSKIK2 x7,x8 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_28:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =XBOOLE-0R4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK1 x8}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK1 x8}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 }"
      using enumset1_lm_6 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({ENUMSET1K1 x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK1 x8})"
      using enumset1_th_6 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 })\\/XBOOLE-0K2 {TARSKIK1 x8}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK1 x8}"
      using enumset1_lm_5 sorry
    finally show "{ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK1 x8}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_29:
" for x1 be objectHIDDENM1 holds {TARSKIK2 x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {TARSKIK2 x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {TARSKIK2 x1,x1 } iff x inHIDDENR3 {TARSKIK1 x1}"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have "x inHIDDENR3 {TARSKIK2 x1,x1 } iff x =HIDDENR1 x1"
        using tarski_def_2 sorry
      thus "x inHIDDENR3 {TARSKIK2 x1,x1 } iff x inHIDDENR3 {TARSKIK1 x1}"
        using tarski_def_1 sorry
    qed "sorry"
    thus "{TARSKIK2 x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_30:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K1 x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K1 x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {TARSKIK1 x2}"
      using enumset1_th_3 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK1 x2}"
      using enumset1_th_29 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_1 sorry
    finally show "{ENUMSET1K1 x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_31:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x1,x2,x3 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using enumset1_lm_2 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using enumset1_th_29 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_2 sorry
    finally show "{ENUMSET1K2 x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_32:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x1,x2,x3,x4 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_8 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_29 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K3 x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_33:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x1,x2,x3,x4,x5 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
      using enumset1_th_12 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K2 x2,x3,x4,x5 }"
      using enumset1_th_29 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 }"
      using enumset1_th_7 sorry
    finally show "{ENUMSET1K4 x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_34:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using enumset1_th_17 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K3 x2,x3,x4,x5,x6 }"
      using enumset1_th_29 sorry
    also have "... = {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
      using enumset1_th_11 sorry
    finally show "{ENUMSET1K5 x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_35:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x2,x3,x4,x5,x6,x7 } =XBOOLE-0R4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {TARSKIK2 x1,x1 } \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using enumset1_th_23 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K4 x2,x3,x4,x5,x6,x7 }"
      using enumset1_th_29 sorry
    also have "... = {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"
      using enumset1_th_16 sorry
    finally show "{ENUMSET1K6 x1,x1,x2,x3,x4,x5,x6,x7 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_36:
" for x1 be objectHIDDENM1 holds {ENUMSET1K1 x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K1 x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_30 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K1 x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_37:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x1,x1,x2 } =HIDDENR1 {ENUMSET1K1 x1,x1,x2 }"
      using enumset1_th_31 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_30 sorry
    finally show "{ENUMSET1K2 x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_38:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K2 x1,x1,x2,x3 }"
      using enumset1_th_32 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_31 sorry
    finally show "{ENUMSET1K3 x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_39:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K3 x1,x1,x2,x3,x4 }"
      using enumset1_th_33 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_th_32 sorry
    finally show "{ENUMSET1K4 x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_40:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K4 x1,x1,x2,x3,x4,x5 }"
      using enumset1_th_34 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 }"
      using enumset1_th_33 sorry
    finally show "{ENUMSET1K5 x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_41:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x2,x3,x4,x5,x6 } =XBOOLE-0R4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K5 x1,x1,x2,x3,x4,x5,x6 }"
      using enumset1_th_35 sorry
    also have "... = {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
      using enumset1_th_34 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x2,x3,x4,x5,x6 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_42:
" for x1 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K2 x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_37 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K2 x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_43:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x1,x1,x1,x2 } =HIDDENR1 {ENUMSET1K1 x1,x1,x2 }"
      using enumset1_th_38 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_30 sorry
    finally show "{ENUMSET1K3 x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_44:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K2 x1,x1,x2,x3 }"
      using enumset1_th_39 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_31 sorry
    finally show "{ENUMSET1K4 x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_45:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K3 x1,x1,x2,x3,x4 }"
      using enumset1_th_40 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_th_32 sorry
    finally show "{ENUMSET1K5 x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_46:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x2,x3,x4,x5 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K4 x1,x1,x2,x3,x4,x5 }"
      using enumset1_th_41 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 }"
      using enumset1_th_33 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x1,x2,x3,x4,x5 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_47:
" for x1 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K3 x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K3 x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_43 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K3 x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_48:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x1,x1,x1,x1,x2 } =HIDDENR1 {ENUMSET1K1 x1,x1,x2 }"
      using enumset1_th_44 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_30 sorry
    finally show "{ENUMSET1K4 x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_49:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K2 x1,x1,x2,x3 }"
      using enumset1_th_45 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_31 sorry
    finally show "{ENUMSET1K5 x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_50:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K3 x1,x1,x2,x3,x4 }"
      using enumset1_th_46 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 }"
      using enumset1_th_32 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x1,x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_51:
" for x1 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K4 x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K4 x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_48 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K4 x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_52:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {ENUMSET1K1 x1,x1,x2 }"
      using enumset1_th_49 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_30 sorry
    finally show "{ENUMSET1K5 x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_53:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K2 x1,x1,x2,x3 }"
      using enumset1_th_50 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_31 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_54:
" for x1 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K5 x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K5 x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_52 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K5 x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_55:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x2 } =XBOOLE-0R4 {TARSKIK2 x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
  proof(rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {ENUMSET1K1 x1,x1,x2 }"
      using enumset1_th_53 sorry
    also have "... = {TARSKIK2 x1,x2 }"
      using enumset1_th_30 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x2 } =HIDDENR1 {TARSKIK2 x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_56:
" for x1 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x1 } =XBOOLE-0R4 {TARSKIK1 x1}"
proof-
  have " for x1 be objectHIDDENM1 holds {ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
  proof(rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    have "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK2 x1,x1 }"
      using enumset1_th_55 sorry
    also have "... = {TARSKIK1 x1}"
      using enumset1_th_29 sorry
    finally show "{ENUMSET1K6 x1,x1,x1,x1,x1,x1,x1,x1 } =HIDDENR1 {TARSKIK1 x1}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_57:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x1,x3,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x3,x2 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {TARSKIK2 x2,x3 }"
      using enumset1_th_2 sorry
    also have "... = {ENUMSET1K1 x1,x3,x2 }"
      using enumset1_th_2 sorry
    finally show "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x1,x3,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_58:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x2,x1,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x2,x1,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK1 x3}"
      using enumset1_th_3 sorry
    also have "... = {ENUMSET1K1 x2,x1,x3 }"
      using enumset1_th_3 sorry
    finally show "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x2,x1,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_59:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x2,x3,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x2,x3,x1 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {TARSKIK2 x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x1}"
      using enumset1_th_2 sorry
    also have "... = {ENUMSET1K1 x2,x3,x1 }"
      using enumset1_th_3 sorry
    finally show "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x2,x3,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_60:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =XBOOLE-0R4 {ENUMSET1K1 x3,x2,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds {ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x3,x2,x1 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    have "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x3,x1,x2 }"
      using enumset1_th_59 sorry
    also have "... = {ENUMSET1K1 x3,x2,x1 }"
      using enumset1_th_57 sorry
    finally show "{ENUMSET1K1 x1,x2,x3 } =HIDDENR1 {ENUMSET1K1 x3,x2,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_61:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x4,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x4,x3 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x4,x3 }"
      using enumset1_th_57 sorry
    also have "... = {ENUMSET1K2 x1,x2,x4,x3 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x2,x4,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_62:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x3,x2,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x3,x2,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x3,x2,x4 }"
      using enumset1_th_58 sorry
    also have "... = {ENUMSET1K2 x1,x3,x2,x4 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x3,x2,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_63:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x3,x4,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x3,x4,x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x3,x4,x2 }"
      using enumset1_th_59 sorry
    also have "... = {ENUMSET1K2 x1,x3,x4,x2 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x3,x4,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_64:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x1,x4,x3,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x4,x3,x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x4,x3,x2 }"
      using enumset1_th_60 sorry
    also have "... = {ENUMSET1K2 x1,x4,x3,x2 }"
      using enumset1_th_4 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x1,x4,x3,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_65:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x1,x3,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x1,x3,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x2,x1,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_58 sorry
    also have "... = {ENUMSET1K2 x2,x1,x3,x4 }"
      using enumset1_th_6 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x1,x3,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_7:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x3,x1,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x2,x3,x1 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_59 sorry
    also have "... = {ENUMSET1K2 x2,x3,x1,x4 }"
      using enumset1_th_6 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_66:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x1,x4,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x1,x4,x3 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
      using enumset1_lm_7 sorry
    also have "... = {ENUMSET1K2 x2,x1,x4,x3 }"
      using enumset1_th_63 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x1,x4,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_67:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x3,x1,x4 }"
  using enumset1_lm_7 sorry

mtheorem enumset1_th_68:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x3,x4,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x4,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
      using enumset1_lm_7 sorry
    also have "... = {ENUMSET1K2 x2,x3,x4,x1 }"
      using enumset1_th_61 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x4,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_69:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x4,x1,x3 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x4,x1,x3 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
      using enumset1_lm_7 sorry
    also have "... = {ENUMSET1K2 x2,x4,x1,x3 }"
      using enumset1_th_64 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x4,x1,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_70:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x2,x4,x3,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x4,x3,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x3,x1,x4 }"
      using enumset1_lm_7 sorry
    also have "... = {ENUMSET1K2 x2,x4,x3,x1 }"
      using enumset1_th_63 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x2,x4,x3,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_8:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x3,x2,x1,x4 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x1,x4 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x3,x2,x1 } \\/XBOOLE-0K2 {TARSKIK1 x4}"
      using enumset1_th_60 sorry
    also have "... = {ENUMSET1K2 x3,x2,x1,x4 }"
      using enumset1_th_6 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x1,x4 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_71:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x3,x2,x1,x4 }"
  using enumset1_lm_8 sorry

mtheorem enumset1_th_72:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x3,x2,x4,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x4,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x1,x4 }"
      using enumset1_lm_8 sorry
    also have "... = {ENUMSET1K2 x3,x2,x4,x1 }"
      using enumset1_th_61 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x4,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_73:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x3,x4,x1,x2 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x1,x2 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x1,x4 }"
      using enumset1_lm_8 sorry
    also have "... = {ENUMSET1K2 x3,x4,x1,x2 }"
      using enumset1_th_64 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x1,x2 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_74:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x3,x4,x2,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x2,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x2,x1,x4 }"
      using enumset1_lm_8 sorry
    also have "... = {ENUMSET1K2 x3,x4,x2,x1 }"
      using enumset1_th_63 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x2,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_75:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x4,x2,x3,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x4,x2,x3,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x2,x1 }"
      using enumset1_th_74 sorry
    also have "... = {ENUMSET1K2 x4,x2,x3,x1 }"
      using enumset1_lm_7 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x4,x2,x3,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_76:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =XBOOLE-0R4 {ENUMSET1K2 x4,x3,x2,x1 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds {ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x4,x3,x2,x1 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    have "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x3,x4,x2,x1 }"
      using enumset1_th_74 sorry
    also have "... = {ENUMSET1K2 x4,x3,x2,x1 }"
      using enumset1_th_65 sorry
    finally show "{ENUMSET1K2 x1,x2,x3,x4 } =HIDDENR1 {ENUMSET1K2 x4,x3,x2,x1 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mlemma enumset1_lm_9:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 {ENUMSET1K3 x5,x6,x7,x8,x9 } iff (((x =HIDDENR1 x5 or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9"
        using enumset1_def_3 sorry
      have "x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } iff ((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4"
        using enumset1_def_2 sorry
      thus "x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } iff x inHIDDENR3 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
        using A1 enumset1_def_7 xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_77:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K6 x2,x3,x4,x5,x6,x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K6 x2,x3,x4,x5,x6,x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = ({TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K1 x2,x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 ({ENUMSET1K1 x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K6 x2,x3,x4,x5,x6,x7,x8,x9 }"
      using enumset1_th_24 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {TARSKIK1 x1} \\/XBOOLE-0K2 {ENUMSET1K6 x2,x3,x4,x5,x6,x7,x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_78:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K5 x3,x4,x5,x6,x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K5 x3,x4,x5,x6,x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = ({TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {TARSKIK2 x3,x4 })\\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_2 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 ({TARSKIK2 x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 })"
      using xboole_1_th_4 sorry
    also have "... = {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K5 x3,x4,x5,x6,x7,x8,x9 }"
      using enumset1_th_17 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {TARSKIK2 x1,x2 } \\/XBOOLE-0K2 {ENUMSET1K5 x3,x4,x5,x6,x7,x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_79:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K4 x4,x5,x6,x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K4 x4,x5,x6,x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = ({ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {TARSKIK1 x4})\\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_th_6 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 ({TARSKIK1 x4} \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 })"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K4 x4,x5,x6,x7,x8,x9 }"
      using enumset1_th_11 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 } \\/XBOOLE-0K2 {ENUMSET1K4 x4,x5,x6,x7,x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_80:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
  using enumset1_lm_9 sorry

mtheorem enumset1_th_81:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK1 x5} \\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 })"
      using enumset1_th_7 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK1 x5})\\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 }"
      using enumset1_th_10 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K3 x1,x2,x3,x4,x5 } \\/XBOOLE-0K2 {ENUMSET1K2 x6,x7,x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_82:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({TARSKIK2 x5,x6 } \\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 })"
      using enumset1_th_8 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {TARSKIK2 x5,x6 })\\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 }"
      using enumset1_th_14 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K4 x1,x2,x3,x4,x5,x6 } \\/XBOOLE-0K2 {ENUMSET1K1 x7,x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_83:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK2 x8,x9 }"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK2 x8,x9 }"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({ENUMSET1K1 x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK2 x8,x9 })"
      using enumset1_lm_3 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K1 x5,x6,x7 })\\/XBOOLE-0K2 {TARSKIK2 x8,x9 }"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK2 x8,x9 }"
      using enumset1_lm_5 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K5 x1,x2,x3,x4,x5,x6,x7 } \\/XBOOLE-0K2 {TARSKIK2 x8,x9 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_84:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =XBOOLE-0R4 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } \\/XBOOLE-0K2 {TARSKIK1 x9}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } \\/XBOOLE-0K2 {TARSKIK1 x9}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    have "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K3 x5,x6,x7,x8,x9 }"
      using enumset1_lm_9 sorry
    also have "... = {ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 ({ENUMSET1K2 x5,x6,x7,x8 } \\/XBOOLE-0K2 {TARSKIK1 x9})"
      using enumset1_th_10 sorry
    also have "... = ({ENUMSET1K2 x1,x2,x3,x4 } \\/XBOOLE-0K2 {ENUMSET1K2 x5,x6,x7,x8 })\\/XBOOLE-0K2 {TARSKIK1 x9}"
      using xboole_1_th_4 sorry
    also have "... = {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } \\/XBOOLE-0K2 {TARSKIK1 x9}"
      using enumset1_lm_6 sorry
    finally show "{ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } =HIDDENR1 {ENUMSET1K6 x1,x2,x3,x4,x5,x6,x7,x8 } \\/XBOOLE-0K2 {TARSKIK1 x9}"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

mtheorem enumset1_th_85:
" for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds  for x10 be objectHIDDENM1 holds {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } =XBOOLE-0R4 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \\/XBOOLE-0K2 {TARSKIK1 x10}"
proof-
  have " for x1 be objectHIDDENM1 holds  for x2 be objectHIDDENM1 holds  for x3 be objectHIDDENM1 holds  for x4 be objectHIDDENM1 holds  for x5 be objectHIDDENM1 holds  for x6 be objectHIDDENM1 holds  for x7 be objectHIDDENM1 holds  for x8 be objectHIDDENM1 holds  for x9 be objectHIDDENM1 holds  for x10 be objectHIDDENM1 holds {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } =XBOOLE-0R4 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \\/XBOOLE-0K2 {TARSKIK1 x10}"
  proof(rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be objectHIDDENM1"
    fix x2 assume [ty]: "x2 be objectHIDDENM1"
    fix x3 assume [ty]: "x3 be objectHIDDENM1"
    fix x4 assume [ty]: "x4 be objectHIDDENM1"
    fix x5 assume [ty]: "x5 be objectHIDDENM1"
    fix x6 assume [ty]: "x6 be objectHIDDENM1"
    fix x7 assume [ty]: "x7 be objectHIDDENM1"
    fix x8 assume [ty]: "x8 be objectHIDDENM1"
    fix x9 assume [ty]: "x9 be objectHIDDENM1"
    fix x10 assume [ty]: "x10 be objectHIDDENM1"
    have " for x be objectHIDDENM1 holds x inHIDDENR3 {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } iff x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \\/XBOOLE-0K2 {TARSKIK1 x10}"
    proof(rule ballI)
      fix x assume [ty]: "x be objectHIDDENM1"
      have A1: "x inHIDDENR3 {TARSKIK1 x10} iff x =HIDDENR1 x10"
        using tarski_def_1 sorry
      have "((((((((x =HIDDENR1 x1 or x =HIDDENR1 x2) or x =HIDDENR1 x3) or x =HIDDENR1 x4) or x =HIDDENR1 x5) or x =HIDDENR1 x6) or x =HIDDENR1 x7) or x =HIDDENR1 x8) or x =HIDDENR1 x9) or x =HIDDENR1 x10 iff x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } or x =HIDDENR1 x10"
        using enumset1_def_7 sorry
      thus "x inHIDDENR3 {ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } iff x inHIDDENR3 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \\/XBOOLE-0K2 {TARSKIK1 x10}"
        using A1 enumset1_def_8 xboole_0_def_3 sorry
    qed "sorry"
    thus "{ENUMSET1K8 x1,x2,x3,x4,x5,x6,x7,x8,x9,x10 } =XBOOLE-0R4 {ENUMSET1K7 x1,x2,x3,x4,x5,x6,x7,x8,x9 } \\/XBOOLE-0K2 {TARSKIK1 x10}"
      using tarski_th_2 sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

(*begin*)
mtheorem enumset1_th_86:
" for x be setHIDDENM2 holds  for y be setHIDDENM2 holds  for z be setHIDDENM2 holds x <>HIDDENR2 y & x <>HIDDENR2 z implies {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y,z }"
proof(rule ballI,rule ballI,rule ballI,rule impI)
  fix x assume [ty]: "x be setHIDDENM2"
  fix y assume [ty]: "y be setHIDDENM2"
  fix z assume [ty]: "z be setHIDDENM2"
  assume A1: "x <>HIDDENR2 y & x <>HIDDENR2 z"
  have "( for a be objectHIDDENM1 holds a inHIDDENR3 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} implies a inHIDDENR3 {TARSKIK2 y,z }) & {TARSKIK2 y,z } c=TARSKIR1 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
  proof(rule conjMI)
    show " for a be objectHIDDENM1 holds a inHIDDENR3 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} implies a inHIDDENR3 {TARSKIK2 y,z }"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume A2: "a inHIDDENR3 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
      then have "a inHIDDENR3 {ENUMSET1K1 x,y,z }"
        using xboole_0_def_5 sorry
      then have A3: "(a =HIDDENR1 x or a =HIDDENR1 y) or a =HIDDENR1 z"
        using enumset1_def_1 sorry
      have " not a inHIDDENR3 {TARSKIK1 x}"
        using A2 xboole_0_def_5 sorry
      thus "a inHIDDENR3 {TARSKIK2 y,z }"
        using A3 tarski_def_1 tarski_def_2 sorry
    qed "sorry"
    have " for a be objectHIDDENM1 holds a inHIDDENR3 {TARSKIK2 y,z } implies a inHIDDENR3 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
    proof(rule ballI,rule impI)
      fix a assume [ty]: "a be objectHIDDENM1"
      assume "a inHIDDENR3 {TARSKIK2 y,z }"
      then have A4: "a =HIDDENR1 y or a =HIDDENR1 z"
        using tarski_def_2 sorry
      then have A5: " not a inHIDDENR3 {TARSKIK1 x}"
        using A1 tarski_def_1 sorry
      have "a inHIDDENR3 {ENUMSET1K1 x,y,z }"
        using A4 enumset1_def_1 sorry
      thus "a inHIDDENR3 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
        using A5 xboole_0_def_5 sorry
    qed "sorry"
    thus "{TARSKIK2 y,z } c=TARSKIR1 {ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x}"
      using tarski_def_3 sorry
  qed
  thus "{ENUMSET1K1 x,y,z } \\XBOOLE-0K4 {TARSKIK1 x} =XBOOLE-0R4 {TARSKIK2 y,z }"
    using tarski_def_3 xboole_0_def_10 sorry
qed "sorry"

mtheorem enumset1_th_87:
" for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds {TARSKIK2 x2,x1 } \\/XBOOLE-0K2 {TARSKIK2 x3,x1 } =XBOOLE-0R4 {ENUMSET1K1 x1,x2,x3 }"
proof-
  have " for x1 be setHIDDENM2 holds  for x2 be setHIDDENM2 holds  for x3 be setHIDDENM2 holds {TARSKIK2 x2,x1 } \\/XBOOLE-0K2 {TARSKIK2 x3,x1 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
  proof(rule ballI,rule ballI,rule ballI)
    fix x1 assume [ty]: "x1 be setHIDDENM2"
    fix x2 assume [ty]: "x2 be setHIDDENM2"
    fix x3 assume [ty]: "x3 be setHIDDENM2"
    have "{TARSKIK2 x2,x1 } \\/XBOOLE-0K2 {TARSKIK2 x3,x1 } =HIDDENR1 {ENUMSET1K2 x2,x1,x3,x1 }"
      using enumset1_lm_2 sorry
    also have "... = {ENUMSET1K2 x1,x1,x2,x3 }"
      using enumset1_th_69 sorry
    also have "... = {ENUMSET1K1 x1,x2,x3 }"
      using enumset1_th_31 sorry
    finally show "{TARSKIK2 x2,x1 } \\/XBOOLE-0K2 {TARSKIK2 x3,x1 } =HIDDENR1 {ENUMSET1K1 x1,x2,x3 }"
       sorry
  qed "sorry"
  thus " ?thesis "
     sorry
qed

end
