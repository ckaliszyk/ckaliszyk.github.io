theory xcmplx_0
  imports arytm_0 funcop_1
   "../mizar_extension/E_number"
begin
(*begin*)
mdef xcmplx_0_def_1 ("<i>XCMPLX-0K1" 164 ) where
"func <i>XCMPLX-0K1 \<rightarrow> NumberORDINAL1M1 equals
  (0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,\<one>\<^sub>M)"
proof-
  (*coherence*)
    show "(0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,\<one>\<^sub>M) be NumberORDINAL1M1"
       sorry
qed "sorry"

mdef xcmplx_0_def_2 ("complexXCMPLX-0V1" 70 ) where
"attr complexXCMPLX-0V1 for NumberORDINAL1M1 means
  (\<lambda>c. c inHIDDENR3 COMPLEXNUMBERSK3)"..

mlemma
"0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
   sorry

mlemma
"0NUMBERSK6 inTARSKIR2 REALNUMBERSK2"
  using numbers_th_19 sorry

mlemma xcmplx_0_lm_1:
"InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) =XBOOLE-0R4 0NUMBERSK6"
  using subset_1_def_8 sorry

mlemma
"\<one>\<^sub>M inTARSKIR2 NATNUMBERSK1"
   sorry

mlemma xcmplx_0_lm_2:
"\<one>\<^sub>M inTARSKIR2 REALNUMBERSK2"
  using numbers_th_19 sorry

mtheorem xcmplx_0_cl_1:
"cluster <i>XCMPLX-0K1 as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "<i>XCMPLX-0K1 be complexXCMPLX-0V1"
  proof-
    let ?X = "{x where x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 }"
    have A1: "<i>XCMPLX-0K1 inHIDDENR3 {x where x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) : x .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6 } implies  False "
    proof(rule impI)
      assume "<i>XCMPLX-0K1 inHIDDENR3 ?X"
      then have " ex x be ElementFUNCT-2M4\<^bsub>({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)\<^esub>-of FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) st <i>XCMPLX-0K1 =HIDDENR1 x & x .FUNCT-1K1 \<one>\<^sub>M =XBOOLE-0R4 0NUMBERSK6"
         sorry
      thus " False "
        using funct_4_th_63 sorry
    qed
    have A2: "{TARSKIK2 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),\<one>\<^sub>M } c=TARSKIR1 REALNUMBERSK2"
      using zfmisc_1_th_32 xcmplx_0_lm_2 sorry
    have "rngFUNCT-1K2 ((0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,\<one>\<^sub>M)) c=TARSKIR1 {TARSKIK2 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2),\<one>\<^sub>M }"
      using funct_4_th_62 xcmplx_0_lm_1 sorry
    then have "rngFUNCT-1K2 ((0NUMBERSK6,\<one>\<^sub>M)-->FUNCT-4K7\<^bsub>(omegaORDINAL1K4)\<^esub>(0NUMBERSK6,\<one>\<^sub>M)) c=TARSKIR1 REALNUMBERSK2"
      using A2 xboole_1_th_1 sorry
    then have "<i>XCMPLX-0K1 be RelationRELSET-1M1-of({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)"
      using relset_1_th_6 sorry
    then have "<i>XCMPLX-0K1 inHIDDENR3 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2)"
      using funct_2_th_8 sorry
    then have Cut67: "<i>XCMPLX-0K1 inHIDDENR3 FuncsFUNCT-2K9({TARSKIK2 0NUMBERSK6,\<one>\<^sub>M },REALNUMBERSK2) \\SUBSET-1K6 ?X"
      using A1 xboole_0_def_5 sorry
    have "<i>XCMPLX-0K1 inHIDDENR3 COMPLEXNUMBERSK3"
    proof-
      show "<i>XCMPLX-0K1 inHIDDENR3 COMPLEXNUMBERSK3"
        using numbers_def_2 xboole_0_def_3 Cut67 sorry
    qed
    thus "<i>XCMPLX-0K1 be complexXCMPLX-0V1"
      using xcmplx_0_def_2 sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_2:
"cluster complexXCMPLX-0V1 for NumberORDINAL1M1"
proof
(*existence*)
  show " ex it be NumberORDINAL1M1 st it be complexXCMPLX-0V1"
  proof-
    have " ex tVar1 be NumberORDINAL1M1 st tVar1 be complexXCMPLX-0V1"
    proof-
      show " ex tVar1 be NumberORDINAL1M1 st tVar1 be complexXCMPLX-0V1"
      proof(rule bexI[of _ "<i>XCMPLX-0K1"])
        show "<i>XCMPLX-0K1 be complexXCMPLX-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_3:
"cluster complexXCMPLX-0V1 for numberORDINAL1M2"
proof
(*existence*)
  show " ex it be numberORDINAL1M2 st it be complexXCMPLX-0V1"
  proof-
    have " ex tVar2 be numberORDINAL1M2 st tVar2 be numberORDINAL1M2 & tVar2 be complexXCMPLX-0V1"
    proof-
      show " ex tVar2 be numberORDINAL1M2 st tVar2 be numberORDINAL1M2 & tVar2 be complexXCMPLX-0V1"
      proof(rule bexI[of _ "<i>XCMPLX-0K1"])
        show "<i>XCMPLX-0K1 be numberORDINAL1M2 & <i>XCMPLX-0K1 be complexXCMPLX-0V1"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

syntax XCMPLX_0M1 :: "Ty" ("ComplexXCMPLX-0M1" 70)
translations "ComplexXCMPLX-0M1" \<rightharpoonup> "complexXCMPLX-0V1\<bar>NumberORDINAL1M1"

mtheorem xcmplx_0_sethood_1:
"cluster sethood of ComplexXCMPLX-0M1"
proof
(*sethood*)
  show " ex cover be setHIDDENM2 st  for it be ComplexXCMPLX-0M1 holds it inHIDDENR3 cover"
  proof-
    have " ex tVar3 be setHIDDENM2 st  for VarFor1 be ComplexXCMPLX-0M1 holds VarFor1 inHIDDENR3 tVar3"
    proof-
      show " ex tVar3 be setHIDDENM2 st  for VarFor1 be ComplexXCMPLX-0M1 holds VarFor1 inHIDDENR3 tVar3"
      proof(rule bexI[of _ "COMPLEXNUMBERSK3"])
        show " for VarFor1 be ComplexXCMPLX-0M1 holds VarFor1 inHIDDENR3 COMPLEXNUMBERSK3"
          using xcmplx_0_def_2 sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

(*\$CD*)
mdef xcmplx_0_def_4 (" _ +XCMPLX-0K2  _ " [132,132]132 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x +XCMPLX-0K2 y \<rightarrow> numberORDINAL1M2 means
  \<lambda>it.  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
proof-
  (*existence*)
    show " ex it be numberORDINAL1M2 st  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
    proof-
      have "x inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x1 x2 where
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
        using arytm_0_th_9 sorry
      have "y inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain y1 y2 where
        [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
        using arytm_0_th_9 sorry
      show " ex it be numberORDINAL1M2 st  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ITDef:"IT = [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]))"
              using A1 A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) & ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) implies it1 =HIDDENR1 it2"
    proof-
      have "x inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x1 x2 where
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
        using arytm_0_th_9 sorry
      have "y inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain y1 y2 where
        [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
        using arytm_0_th_9 sorry
      show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) & ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be numberORDINAL1M2 holds  for c2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) implies (( ex x19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x29 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y29 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x19,x29 *] & y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]) & c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x19,y19),+ARYTM-0K1(x29,y29) *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be numberORDINAL1M2"
          fix c2 assume [ty]: "c2 be numberORDINAL1M2"
          assume Given: " ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
          then obtain x1 x2 y1 y2 where
            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A3: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A4: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A5: "c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
             sorry
          assume Given: " ex x19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x29 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y29 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x19,x29 *] & y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]) & c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x19,y19),+ARYTM-0K1(x29,y29) *]"
          then obtain x19 x29 y19 y29 where
            [ty]:"x19 be ElementSUBSET-1M1-of REALNUMBERSK2" "x29 be ElementSUBSET-1M1-of REALNUMBERSK2" "y19 be ElementSUBSET-1M1-of REALNUMBERSK2" "y29 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A6: "x =HIDDENR1 [*ARYTM-0K5 x19,x29 *]"and A7: "y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]"and A8: "c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x19,y19),+ARYTM-0K1(x29,y29) *]"
             sorry
          have A9: "x1 =XBOOLE-0R4 x19 & x2 =XBOOLE-0R4 x29"
            using A3 A6 arytm_0_th_10 sorry
          have "y1 =XBOOLE-0R4 y19"
            using A4 A7 arytm_0_th_10 sorry
          thus "c1 =HIDDENR1 c2"
            using A4 A5 A7 A8 A9 arytm_0_th_10 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem XCMPLX_0K2_commutativity:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x +XCMPLX-0K2 y =HIDDENR1 y +XCMPLX-0K2 x"
proof-
  have " for it be numberORDINAL1M2 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds it =HIDDENR1 x +XCMPLX-0K2 y implies it =HIDDENR1 y +XCMPLX-0K2 x"
  proof-
    have "x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x1 x2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
      using arytm_0_th_9 sorry
    have "y inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain y1 y2 where
      [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
      using arytm_0_th_9 sorry
    have " for it be numberORDINAL1M2 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]) implies ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (y =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & x =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *])"
       sorry
    thus " ?thesis "
      using xcmplx_0_def_4 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xcmplx_0_def_5 (" _ *XCMPLX-0K3  _ " [164,164]164 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x *XCMPLX-0K3 y \<rightarrow> numberORDINAL1M2 means
  \<lambda>it.  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
proof-
  (*existence*)
    show " ex it be numberORDINAL1M2 st  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
    proof-
      have "x inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x1 x2 where
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
        using arytm_0_th_9 sorry
      have "y inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain y1 y2 where
        [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
        using arytm_0_th_9 sorry
      show " ex it be numberORDINAL1M2 st  ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      proof-
        have " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]))"
        proof-
          obtain IT where 
            [ty]:"IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3" and ITDef:"IT = [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
             sorry
          show " ex IT be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 st  not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]))"
          proof(rule bexI[of _ "IT"])
            show " not ( for x1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for x2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y1 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y2 be ElementSUBSET-1M1-of REALNUMBERSK2 holds  not ((x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & IT =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]))"
              using A1 A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) & ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) implies it1 =HIDDENR1 it2"
    proof-
      have "x inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x1 x2 where
        [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
        using arytm_0_th_9 sorry
      have "y inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain y1 y2 where
        [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
        using arytm_0_th_9 sorry
      show " for it1 be numberORDINAL1M2 holds  for it2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) & ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be numberORDINAL1M2 holds  for c2 be numberORDINAL1M2 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) implies (( ex x19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x29 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y29 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x19,x29 *] & y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]) & c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x19,y19),oppARYTM-0K3 ( *ARYTM-0K2(x29,y29))),+ARYTM-0K1( *ARYTM-0K2(x19,y29), *ARYTM-0K2(x29,y19)) *]) implies c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule impI,rule impI)
          fix c1 assume [ty]: "c1 be numberORDINAL1M2"
          fix c2 assume [ty]: "c2 be numberORDINAL1M2"
          assume Given: " ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
          then obtain x1 x2 y1 y2 where
            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A10: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A11: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A12: "c1 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
             sorry
          assume Given: " ex x19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x29 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y19 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y29 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x19,x29 *] & y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]) & c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x19,y19),oppARYTM-0K3 ( *ARYTM-0K2(x29,y29))),+ARYTM-0K1( *ARYTM-0K2(x19,y29), *ARYTM-0K2(x29,y19)) *]"
          then obtain x19 x29 y19 y29 where
            [ty]:"x19 be ElementSUBSET-1M1-of REALNUMBERSK2" "x29 be ElementSUBSET-1M1-of REALNUMBERSK2" "y19 be ElementSUBSET-1M1-of REALNUMBERSK2" "y29 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A13: "x =HIDDENR1 [*ARYTM-0K5 x19,x29 *]"and A14: "y =HIDDENR1 [*ARYTM-0K5 y19,y29 *]"and A15: "c2 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x19,y19),oppARYTM-0K3 ( *ARYTM-0K2(x29,y29))),+ARYTM-0K1( *ARYTM-0K2(x19,y29), *ARYTM-0K2(x29,y19)) *]"
             sorry
          have A16: "x1 =XBOOLE-0R4 x19 & x2 =XBOOLE-0R4 x29"
            using A10 A13 arytm_0_th_10 sorry
          have "y1 =XBOOLE-0R4 y19 & y2 =XBOOLE-0R4 y29"
            using A11 A14 arytm_0_th_10 sorry
          thus "c1 =HIDDENR1 c2"
            using A12 A15 A16 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem XCMPLX_0K3_commutativity:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds x *XCMPLX-0K3 y =HIDDENR1 y *XCMPLX-0K3 x"
proof-
  have " for it be numberORDINAL1M2 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds it =HIDDENR1 x *XCMPLX-0K3 y implies it =HIDDENR1 y *XCMPLX-0K3 x"
  proof-
    have "x inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x1 x2 where
      [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"
      using arytm_0_th_9 sorry
    have "y inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain y1 y2 where
      [ty]:"y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"
      using arytm_0_th_9 sorry
    have " for it be numberORDINAL1M2 holds  for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (x =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]) implies ( ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (y =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & x =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & it =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *])"
       sorry
    thus " ?thesis "
      using xcmplx_0_def_5 sorry
  qed
  thus " ?thesis "
     sorry
qed

mlemma xcmplx_0_lm_3:
" for x be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for y be ElementSUBSET-1M1-of REALNUMBERSK2 holds  for z be ElementSUBSET-1M1-of REALNUMBERSK2 holds +ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6 & +ARYTM-0K1(x,z) =XBOOLE-0R4 0NUMBERSK6 implies y =XBOOLE-0R4 z"
proof(rule ballI,rule ballI,rule ballI,rule impMI ,rule impI)
  fix x assume [ty]: "x be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix y assume [ty]: "y be ElementSUBSET-1M1-of REALNUMBERSK2"
  fix z assume [ty]: "z be ElementSUBSET-1M1-of REALNUMBERSK2"
  assume A1: "+ARYTM-0K1(x,y) =XBOOLE-0R4 0NUMBERSK6"
    and A2: "+ARYTM-0K1(x,z) =XBOOLE-0R4 0NUMBERSK6"
  show "y =XBOOLE-0R4 z"
  proof-
    have cases: "((((((x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or ( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) or ( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
       sorry
    have case1: "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2 implies y =XBOOLE-0R4 z"
    proof(rule impI)
      assume "(x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) & z inTARSKIR2 REAL+ARYTM-2K2"
      then have "( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9) & ( ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9)"
        using A1 A2 arytm_0_def_1 sorry
      thus "y =XBOOLE-0R4 z"
        using arytm_2_th_11 sorry
    qed
    have case2: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A3: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A4: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A5: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have A6: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & y =XBOOLE-0R4 y9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 y9"
        using A1 A3 A4 arytm_0_def_1 sorry
      obtain x99 y99 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A7: "x =XBOOLE-0R4 x99"and A8: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,y99 ] & 0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 y99"
        using A2 A3 A5 arytm_0_def_1 sorry
      have A9: "x99 =XBOOLE-0R4 0NUMBERSK6"
        using A6 A7 arytm_2_th_5 sorry
      have "[TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] }"
        using tarski_def_1 sorry
      then have A10: " not [TARSKIK4 {}XBOOLE-0K1,{}XBOOLE-0K1 ] inHIDDENR3 REALNUMBERSK2"
        using numbers_def_1 xboole_0_def_5 sorry
      have "z inTARSKIR2 REALNUMBERSK2"
         sorry
      thus "y =XBOOLE-0R4 z"
        using A8 A9 A10 arytm_1_th_19 sorry
    qed
    have case3: "x inTARSKIR2 REAL+ARYTM-2K2 & (z inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A11: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A12: "z inTARSKIR2 REAL+ARYTM-2K2"
        and A13: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      have A14: " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =XBOOLE-0R4 x9 & z =XBOOLE-0R4 z9) & 0NUMBERSK6 =XBOOLE-0R4 x9 +ARYTM-2K7 z9"
        using A2 A11 A12 arytm_0_def_1 sorry
      obtain x99 y9 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A15: "x =XBOOLE-0R4 x99"and A16: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ] & 0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 y9"
        using A1 A11 A13 arytm_0_def_1 sorry
      have A17: "x99 =XBOOLE-0R4 0NUMBERSK6"
        using A14 A15 arytm_2_th_5 sorry
      have "[TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 {TARSKIK1 [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] }"
        using tarski_def_1 sorry
      then have A18: " not [TARSKIK4 0NUMBERSK6,0NUMBERSK6 ] inHIDDENR3 REALNUMBERSK2"
        using numbers_def_1 xboole_0_def_5 sorry
      have "y inTARSKIR2 REALNUMBERSK2"
         sorry
      thus "y =XBOOLE-0R4 z"
        using A16 A17 A18 arytm_1_th_19 sorry
    qed
    have case4: "x inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :] & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A19: "x inTARSKIR2 REAL+ARYTM-2K2"
        and A20: "y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
        and A21: "z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      obtain x9 y9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A22: "x =XBOOLE-0R4 x9"and A23: "y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]"and A24: "0NUMBERSK6 =XBOOLE-0R4 x9 -ARYTM-1K2 y9"
        using A1 A19 A20 arytm_0_def_1 sorry
      obtain x99 z9 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A25: "x =XBOOLE-0R4 x99"and A26: "z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]"and A27: "0NUMBERSK6 =XBOOLE-0R4 x99 -ARYTM-1K2 z9"
        using A2 A19 A21 arytm_0_def_1 sorry
      have "y9 =HIDDENR1 x9"
        using A24 arytm_0_th_6 sorry
      also have "... = z9"
        using A22 A25 A27 arytm_0_th_6 sorry
      finally have "y9 =HIDDENR1 z9"
         sorry
      thus "y =XBOOLE-0R4 z"
        using A23 A26 sorry
    qed
    have case5: "z inTARSKIR2 REAL+ARYTM-2K2 & (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impMI ,rule impMI ,rule impI)
      assume A28: "z inTARSKIR2 REAL+ARYTM-2K2"
        and A29: "y inTARSKIR2 REAL+ARYTM-2K2"
        and A30: "x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]"
      obtain x9 y9 where
        [ty]:"x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A31: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ]"and A32: "y =XBOOLE-0R4 y9"and A33: "0NUMBERSK6 =XBOOLE-0R4 y9 -ARYTM-1K2 x9"
        using A1 A29 A30 arytm_0_def_1 sorry
      obtain x99 z9 where
        [ty]:"x99 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" "z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2" and 
        A34: "x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x99 ]"and A35: "z =XBOOLE-0R4 z9"and A36: "0NUMBERSK6 =XBOOLE-0R4 z9 -ARYTM-1K2 x99"
        using A2 A28 A30 arytm_0_def_1 sorry
      have "x9 =XBOOLE-0R4 x99"
        using A31 A34 xtuple_0_th_1 sorry
      then have "z9 =HIDDENR1 x9"
        using A36 arytm_0_th_6 sorry
      also have "... = y9"
        using A33 arytm_0_th_6 sorry
      finally have "z9 =HIDDENR1 y9"
         sorry
      thus "y =XBOOLE-0R4 z"
        using A32 A35 sorry
    qed
    have case6: "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impI)
      assume "( not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & y inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (y inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex y9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & y =HIDDENR1 [TARSKIK4 0NUMBERSK6,y9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 y9 ]"
        using A1 arytm_0_def_1 sorry
      thus "y =XBOOLE-0R4 z"
         sorry
    qed
    have case7: "( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :]) implies y =XBOOLE-0R4 z"
    proof(rule impI)
      assume "( not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 REAL+ARYTM-2K2) &  not (x inTARSKIR2 REAL+ARYTM-2K2 & z inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])) &  not (z inTARSKIR2 REAL+ARYTM-2K2 & x inTARSKIR2 [:ZFMISC-1K2 {TARSKIK1 0NUMBERSK6 },REAL+ARYTM-2K2 :])"
      then have " ex x9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st  ex z9 be ElementSUBSET-1M1-of REAL+ARYTM-2K2 st (x =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 ] & z =HIDDENR1 [TARSKIK4 0NUMBERSK6,z9 ]) & 0NUMBERSK6 =HIDDENR1 [TARSKIK4 0NUMBERSK6,x9 +ARYTM-2K7 z9 ]"
        using A2 arytm_0_def_1 sorry
      thus "y =XBOOLE-0R4 z"
         sorry
    qed
    show " ?thesis "
      using cases case1 case2 case3 case4 case5 case6 case7 sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_4:
  mlet "z be ComplexXCMPLX-0M1", "z9 be ComplexXCMPLX-0M1"
"cluster z +XCMPLX-0K2 z9 as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "z +XCMPLX-0K2 z9 be complexXCMPLX-0V1"
  proof-
    have Cut259: " ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (z =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & z9 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & z +XCMPLX-0K2 z9 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
      using xcmplx_0_def_4 sorry
    have "z +XCMPLX-0K2 z9 inTARSKIR2 COMPLEXNUMBERSK3"
    proof-
      show "z +XCMPLX-0K2 z9 inTARSKIR2 COMPLEXNUMBERSK3"
        using Cut259 sorry
    qed
    thus "z +XCMPLX-0K2 z9 be complexXCMPLX-0V1"
      using xcmplx_0_def_2 sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_5:
  mlet "z be ComplexXCMPLX-0M1", "z9 be ComplexXCMPLX-0M1"
"cluster z *XCMPLX-0K3 z9 as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "z *XCMPLX-0K3 z9 be complexXCMPLX-0V1"
  proof-
    have Cut266: " ex x1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex x2 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y1 be ElementSUBSET-1M1-of REALNUMBERSK2 st  ex y2 be ElementSUBSET-1M1-of REALNUMBERSK2 st (z =HIDDENR1 [*ARYTM-0K5 x1,x2 *] & z9 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]) & z *XCMPLX-0K3 z9 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
      using xcmplx_0_def_5 sorry
    have "z *XCMPLX-0K3 z9 inTARSKIR2 COMPLEXNUMBERSK3"
    proof-
      show "z *XCMPLX-0K3 z9 inTARSKIR2 COMPLEXNUMBERSK3"
        using Cut266 sorry
    qed
    thus "z *XCMPLX-0K3 z9 be complexXCMPLX-0V1"
      using xcmplx_0_def_2 sorry
  qed
qed "sorry"

mdef xcmplx_0_def_6 ("-XCMPLX-0K4  _ " [132]132 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func -XCMPLX-0K4 z \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it. z +XCMPLX-0K2 it =XBOOLE-0R4 0NUMBERSK6"
proof-
  (*existence*)
    show " ex it be ComplexXCMPLX-0M1 st z +XCMPLX-0K2 it =XBOOLE-0R4 0NUMBERSK6"
    proof-
      have "z inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x y where
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
        using arytm_0_th_9 sorry
      show " ex it be ComplexXCMPLX-0M1 st z +XCMPLX-0K2 it =XBOOLE-0R4 0NUMBERSK6"
      proof-
        have " ex tVar6 be ComplexXCMPLX-0M1 st z +XCMPLX-0K2 tVar6 =XBOOLE-0R4 0NUMBERSK6"
        proof-
          obtain z9 where 
            [ty]:"z9 be ComplexXCMPLX-0M1" and z9Def:"z9 = [*ARYTM-0K5 oppARYTM-0K3 x,oppARYTM-0K3 y *]"
            using xcmplx_0_def_2 sorry
          show " ex tVar6 be ComplexXCMPLX-0M1 st z +XCMPLX-0K2 tVar6 =XBOOLE-0R4 0NUMBERSK6"
          proof(rule bexI[of _ "z9"])
            have A2: "0NUMBERSK6 =XBOOLE-0R4 +ARYTM-0K1(x,oppARYTM-0K3 x) & 0NUMBERSK6 =XBOOLE-0R4 +ARYTM-0K1(y,oppARYTM-0K3 y)"
              using arytm_0_def_3 sorry
            have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
               sorry
            then obtain zz where 
              [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
              using numbers_th_19 sorry
            have "0NUMBERSK6 =XBOOLE-0R4 [*ARYTM-0K5 zz,zz *]"
              using arytm_0_def_5 sorry
            thus "z +XCMPLX-0K2 z9 =XBOOLE-0R4 0NUMBERSK6"
              using A1 xcmplx_0_def_4 A2 sorry
          qed "sorry"
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds z +XCMPLX-0K2 it1 =XBOOLE-0R4 0NUMBERSK6 & z +XCMPLX-0K2 it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2"
    proof-
      have "z inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x y where
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
        using arytm_0_th_9 sorry
      show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds z +XCMPLX-0K2 it1 =XBOOLE-0R4 0NUMBERSK6 & z +XCMPLX-0K2 it2 =XBOOLE-0R4 0NUMBERSK6 implies it1 =HIDDENR1 it2"
      proof-
        have " for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds z +XCMPLX-0K2 c1 =XBOOLE-0R4 0NUMBERSK6 & z +XCMPLX-0K2 c2 =XBOOLE-0R4 0NUMBERSK6 implies c1 =HIDDENR1 c2"
        proof(rule ballI,rule ballI,rule impMI ,rule impI)
          fix c1 assume [ty]: "c1 be ComplexXCMPLX-0M1"
          fix c2 assume [ty]: "c2 be ComplexXCMPLX-0M1"
          assume A2: "z +XCMPLX-0K2 c1 =XBOOLE-0R4 0NUMBERSK6"
            and A3: "z +XCMPLX-0K2 c2 =XBOOLE-0R4 0NUMBERSK6"
          obtain x1 x2 y1 y2 where
            [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A4: "z =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A5: "c1 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A6: "0NUMBERSK6 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
            using A2 xcmplx_0_def_4 sorry
          obtain x19 x29 y19 y29 where
            [ty]:"x19 be ElementSUBSET-1M1-of REALNUMBERSK2" "x29 be ElementSUBSET-1M1-of REALNUMBERSK2" "y19 be ElementSUBSET-1M1-of REALNUMBERSK2" "y29 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
            A7: "z =HIDDENR1 [*ARYTM-0K5 x19,x29 *]"and A8: "c2 =HIDDENR1 [*ARYTM-0K5 y19,y29 *]"and A9: "0NUMBERSK6 =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x19,y19),+ARYTM-0K1(x29,y29) *]"
            using A3 xcmplx_0_def_4 sorry
          have A10: "x1 =XBOOLE-0R4 x19"
            using A4 A7 arytm_0_th_10 sorry
          have A11: "x2 =XBOOLE-0R4 x29"
            using A4 A7 arytm_0_th_10 sorry
          have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
             sorry
          then obtain zz where 
            [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
            using numbers_th_19 sorry
          have Lm3: "0NUMBERSK6 =XBOOLE-0R4 [*ARYTM-0K5 zz,zz *]"
            using arytm_0_def_5 sorry
          have A12: "+ARYTM-0K1(x1,y1) =XBOOLE-0R4 0NUMBERSK6"
            using A6 Lm3 arytm_0_th_10 sorry
          have "+ARYTM-0K1(x1,y19) =XBOOLE-0R4 0NUMBERSK6"
            using A9 A10 Lm3 arytm_0_th_10 sorry
          then have A13: "y1 =XBOOLE-0R4 y19"
            using A12 xcmplx_0_lm_3 sorry
          have A14: "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
            using A6 Lm3 arytm_0_th_10 sorry
          have "+ARYTM-0K1(x2,y29) =XBOOLE-0R4 0NUMBERSK6"
            using A9 A11 Lm3 arytm_0_th_10 sorry
          thus "c1 =HIDDENR1 c2"
            using A5 A8 A13 A14 xcmplx_0_lm_3 sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
qed "sorry"

mtheorem XCMPLX_0K4_involutiveness:
" for z be ComplexXCMPLX-0M1 holds -XCMPLX-0K4 (-XCMPLX-0K4 z) =HIDDENR1 z"
proof-
  have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1 -XCMPLX-0K4 z implies z =HIDDENR1 -XCMPLX-0K4 it"
  proof-
    have "z inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x y where
      [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
      using arytm_0_th_9 sorry
    have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds z +XCMPLX-0K2 it =XBOOLE-0R4 0NUMBERSK6 implies it +XCMPLX-0K2 z =XBOOLE-0R4 0NUMBERSK6"
       sorry
    thus " ?thesis "
      using xcmplx_0_def_6 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xcmplx_0_def_7 (" _ \<inverse>XCMPLX-0K5" [228]228 ) where
  mlet "z be ComplexXCMPLX-0M1"
"func z \<inverse>XCMPLX-0K5 \<rightarrow> ComplexXCMPLX-0M1 means
  \<lambda>it. z *XCMPLX-0K3 it =XBOOLE-0R4 \<one>\<^sub>M if z <>HIDDENR2 0NUMBERSK6 otherwise \<lambda>it. it =HIDDENR1 0NUMBERSK6"
proof-
  (*existence*)
    show "(z <>HIDDENR2 0NUMBERSK6 implies ( ex it be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 it =XBOOLE-0R4 \<one>\<^sub>M)) & ( not z <>HIDDENR2 0NUMBERSK6 implies ( ex it be ComplexXCMPLX-0M1 st it =HIDDENR1 0NUMBERSK6))"
    proof-
      have "z inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x y where
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
        using arytm_0_th_9 sorry
      show "(z <>HIDDENR2 0NUMBERSK6 implies ( ex it be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 it =XBOOLE-0R4 \<one>\<^sub>M)) & ( not z <>HIDDENR2 0NUMBERSK6 implies ( ex it be ComplexXCMPLX-0M1 st it =HIDDENR1 0NUMBERSK6))"
      proof-
        have "(z <>HIDDENR2 0NUMBERSK6 implies ( ex z9 be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M)) & (z =HIDDENR1 0NUMBERSK6 implies  not ( for VarFor1 be ComplexXCMPLX-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6))"
        proof(rule conjMI,rule impI)
          show "z <>HIDDENR2 0NUMBERSK6 implies ( ex z9 be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M)"
          proof-
            have "z <>HIDDENR2 0NUMBERSK6 implies ( ex tVar7 be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 tVar7 =XBOOLE-0R4 \<one>\<^sub>M)"
            proof(rule impI)
              let ?y1 = " *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
              let ?y2 = " *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
              let ?z9 = "[*ARYTM-0K5 ?y1,?y2 *]"
              obtain z9 where 
                [ty]:"z9 be ComplexXCMPLX-0M1" and z9Def:"z9 = ?z9"
                using xcmplx_0_def_2 sorry
              assume A15: "z <>HIDDENR2 0NUMBERSK6"
              show " ex tVar7 be ComplexXCMPLX-0M1 st z *XCMPLX-0K3 tVar7 =XBOOLE-0R4 \<one>\<^sub>M"
              proof(rule bexI[of _ "z9"])
                have A16: "oppARYTM-0K3 ( *ARYTM-0K2(y,?y2)) =HIDDENR1 oppARYTM-0K3 ( *ARYTM-0K2(y,oppARYTM-0K3 ( *ARYTM-0K2(y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))))))"
                  using arytm_0_th_15 sorry
                also have "... = oppARYTM-0K3 (oppARYTM-0K3 ( *ARYTM-0K2(y, *ARYTM-0K2(y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))))))"
                  using arytm_0_th_15 sorry
                also have "... =  *ARYTM-0K2( *ARYTM-0K2(y,y),invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                  using arytm_0_th_13 sorry
                finally have "oppARYTM-0K3 ( *ARYTM-0K2(y,?y2)) =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(y,y),invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                   sorry
                have A17: " *ARYTM-0K2(x,?y1) =XBOOLE-0R4  *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                  using arytm_0_th_13 sorry
                have A18: "+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)) =XBOOLE-0R4 0NUMBERSK6 implies  False "
                proof(rule impI)
                  assume "+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)) =XBOOLE-0R4 0NUMBERSK6"
                  then have "x =XBOOLE-0R4 0NUMBERSK6 & y =XBOOLE-0R4 0NUMBERSK6"
                    using arytm_0_th_17 sorry
                  thus " False "
                    using A1 A15 arytm_0_def_5 sorry
                qed
                have " *ARYTM-0K2(x,?y2) =HIDDENR1  *ARYTM-0K2(oppARYTM-0K3 y,?y1)"
                  using arytm_0_th_13 sorry
                also have "... = oppARYTM-0K3 ( *ARYTM-0K2(y,?y1))"
                  using arytm_0_th_15 sorry
                finally have " *ARYTM-0K2(x,?y2) =HIDDENR1 oppARYTM-0K3 ( *ARYTM-0K2(y,?y1))"
                   sorry
                then have "+ARYTM-0K1( *ARYTM-0K2(x,?y2), *ARYTM-0K2(y,?y1)) =XBOOLE-0R4 0NUMBERSK6"
                  using arytm_0_def_3 sorry
                then have "[*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x,?y1),oppARYTM-0K3 ( *ARYTM-0K2(y,?y2))),+ARYTM-0K1( *ARYTM-0K2(x,?y2), *ARYTM-0K2(y,?y1)) *] =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x,?y1),oppARYTM-0K3 ( *ARYTM-0K2(y,?y2)))"
                  using arytm_0_def_5 sorry
                also have "... =  *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)),invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                  using A16 A17 arytm_0_th_14 sorry
                also have "... = \<one>\<^sub>M"
                  using A18 arytm_0_def_4 sorry
                finally have "[*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x,?y1),oppARYTM-0K3 ( *ARYTM-0K2(y,?y2))),+ARYTM-0K1( *ARYTM-0K2(x,?y2), *ARYTM-0K2(y,?y1)) *] =HIDDENR1 \<one>\<^sub>M"
                   sorry
                thus "z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M"
                  using A1 xcmplx_0_def_5 sorry
              qed "sorry"
            qed
            thus " ?thesis "
               sorry
          qed
          assume "z =HIDDENR1 0NUMBERSK6"
          thus " not ( for VarFor1 be ComplexXCMPLX-0M1 holds  not VarFor1 =HIDDENR1 0NUMBERSK6)"
             sorry
        qed
        thus " ?thesis "
           sorry
      qed
    qed
  (*uniqueness*)
    show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds (z <>HIDDENR2 0NUMBERSK6 implies (z *XCMPLX-0K3 it1 =XBOOLE-0R4 \<one>\<^sub>M & z *XCMPLX-0K3 it2 =XBOOLE-0R4 \<one>\<^sub>M implies it1 =HIDDENR1 it2)) & ( not z <>HIDDENR2 0NUMBERSK6 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
    proof-
      have "z inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x y where
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
        using arytm_0_th_9 sorry
      show " for it1 be ComplexXCMPLX-0M1 holds  for it2 be ComplexXCMPLX-0M1 holds (z <>HIDDENR2 0NUMBERSK6 implies (z *XCMPLX-0K3 it1 =XBOOLE-0R4 \<one>\<^sub>M & z *XCMPLX-0K3 it2 =XBOOLE-0R4 \<one>\<^sub>M implies it1 =HIDDENR1 it2)) & ( not z <>HIDDENR2 0NUMBERSK6 implies (it1 =HIDDENR1 0NUMBERSK6 & it2 =HIDDENR1 0NUMBERSK6 implies it1 =HIDDENR1 it2))"
      proof-
        have " for c1 be ComplexXCMPLX-0M1 holds  for c2 be ComplexXCMPLX-0M1 holds ((z <>HIDDENR2 0NUMBERSK6 & z *XCMPLX-0K3 c1 =XBOOLE-0R4 \<one>\<^sub>M) & z *XCMPLX-0K3 c2 =XBOOLE-0R4 \<one>\<^sub>M implies c1 =HIDDENR1 c2) &  not (((z <>HIDDENR2 0NUMBERSK6 & c1 =HIDDENR1 0NUMBERSK6) & c2 =HIDDENR1 0NUMBERSK6) &  not c1 =HIDDENR1 c2)"
        proof(rule ballI,rule ballI,rule conjMI)
          fix c1 assume [ty]: "c1 be ComplexXCMPLX-0M1"
          fix c2 assume [ty]: "c2 be ComplexXCMPLX-0M1"
          have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
             sorry
          then obtain zz j where 
            [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6" and
            [ty]:"j be ElementSUBSET-1M1-of REALNUMBERSK2" and jDef:"j = \<one>\<^sub>M"
            using xcmplx_0_lm_2 numbers_th_19 sorry
          show "(z <>HIDDENR2 0NUMBERSK6 & z *XCMPLX-0K3 c1 =XBOOLE-0R4 \<one>\<^sub>M) & z *XCMPLX-0K3 c2 =XBOOLE-0R4 \<one>\<^sub>M implies c1 =HIDDENR1 c2"
          proof-
            have "z <>HIDDENR2 0NUMBERSK6 & (z *XCMPLX-0K3 c1 =XBOOLE-0R4 \<one>\<^sub>M & z *XCMPLX-0K3 c2 =XBOOLE-0R4 \<one>\<^sub>M) implies c1 =HIDDENR1 c2"
            proof(rule impMI ,rule impMI ,rule impI)
              assume A19: "z <>HIDDENR2 0NUMBERSK6"
                and A20: "z *XCMPLX-0K3 c1 =XBOOLE-0R4 \<one>\<^sub>M"
                and A21: "z *XCMPLX-0K3 c2 =XBOOLE-0R4 \<one>\<^sub>M"
              have A22: " for z9 be ComplexXCMPLX-0M1 holds z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M implies z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
              proof(rule ballI,rule impI)
                fix z9 assume [ty]: "z9 be ComplexXCMPLX-0M1"
                assume A23: "z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M"
                obtain x1 x2 x9 y9 where
                  [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "x9 be ElementSUBSET-1M1-of REALNUMBERSK2" "y9 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
                  A24: "z =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A25: "z9 =HIDDENR1 [*ARYTM-0K5 x9,y9 *]"and A26: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,x9),oppARYTM-0K3 ( *ARYTM-0K2(x2,y9))),+ARYTM-0K1( *ARYTM-0K2(x1,y9), *ARYTM-0K2(x2,x9)) *]"
                  using A23 xcmplx_0_def_5 sorry
                have A27: "x =XBOOLE-0R4 x1 & y =XBOOLE-0R4 x2"
                  using A1 A24 arytm_0_th_10 sorry
                show "z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                proof-
                  have cases: "(x =XBOOLE-0R4 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6 or oppARYTM-0K3 y =XBOOLE-0R4 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6) or oppARYTM-0K3 y <>HIDDENR2 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6"
                    using A1 A19 arytm_0_def_5 sorry
                  have case1: "x =XBOOLE-0R4 0NUMBERSK6 & y <>HIDDENR2 0NUMBERSK6 implies z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                  proof(rule impMI ,rule impI)
                    assume A28: "x =XBOOLE-0R4 0NUMBERSK6"
                      and A29: "y <>HIDDENR2 0NUMBERSK6"
                    have "+ARYTM-0K1(y,oppARYTM-0K3 y) =XBOOLE-0R4 0NUMBERSK6"
                      using arytm_0_def_3 sorry
                    then have A30: "oppARYTM-0K3 y <>HIDDENR2 0NUMBERSK6"
                      using A29 arytm_0_th_11 sorry
                    have " *ARYTM-0K2(x,y9) =XBOOLE-0R4 0NUMBERSK6 &  *ARYTM-0K2(x,x9) =XBOOLE-0R4 0NUMBERSK6"
                      using A28 arytm_0_th_12 sorry
                    then have A31: "\<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5 oppARYTM-0K3 ( *ARYTM-0K2(y,y9)),+ARYTM-0K1(zz, *ARYTM-0K2(y,x9)) *]"
                      using A26 A27 arytm_0_th_11 sorry
                    also have "... = [*ARYTM-0K5 oppARYTM-0K3 ( *ARYTM-0K2(y,y9)), *ARYTM-0K2(y,x9) *]"
                      using arytm_0_th_11 sorry
                    finally have "\<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5 oppARYTM-0K3 ( *ARYTM-0K2(y,y9)), *ARYTM-0K2(y,x9) *]"
                       sorry
                    have A32: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 j,zz *]"
                      using arytm_0_def_5 sorry
                    have " *ARYTM-0K2(oppARYTM-0K3 y,y9) =HIDDENR1 oppARYTM-0K3 ( *ARYTM-0K2(y,y9))"
                      using arytm_0_th_15 sorry
                    also have "... = \<one>\<^sub>M"
                      using A31 A32 arytm_0_th_10 sorry
                    finally have " *ARYTM-0K2(oppARYTM-0K3 y,y9) =HIDDENR1 \<one>\<^sub>M"
                       sorry
                    then have A33: "y9 =XBOOLE-0R4 invARYTM-0K4 oppARYTM-0K3 y"
                      using A30 arytm_0_def_4 sorry
                    have A34: " *ARYTM-0K2(x,x) =XBOOLE-0R4 0NUMBERSK6"
                      using A28 arytm_0_th_12 sorry
                    have " *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 (invARYTM-0K4 y)) =HIDDENR1 oppARYTM-0K3 ( *ARYTM-0K2(y,oppARYTM-0K3 (invARYTM-0K4 y)))"
                      using arytm_0_th_15 sorry
                    also have "... = oppARYTM-0K3 (oppARYTM-0K3 ( *ARYTM-0K2(y,invARYTM-0K4 y)))"
                      using arytm_0_th_15 sorry
                    also have "... = \<one>\<^sub>M"
                      using A29 arytm_0_def_4 sorry
                    finally have " *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 (invARYTM-0K4 y)) =HIDDENR1 \<one>\<^sub>M"
                       sorry
                    then have A35: "invARYTM-0K4 oppARYTM-0K3 y =XBOOLE-0R4 oppARYTM-0K3 (invARYTM-0K4 y)"
                      using A30 arytm_0_def_4 sorry
                    have " *ARYTM-0K2(y,x9) =XBOOLE-0R4 0NUMBERSK6"
                      using A31 A32 arytm_0_th_10 sorry
                    then have "z9 =HIDDENR1 [*ARYTM-0K5 zz,invARYTM-0K4 oppARYTM-0K3 y *]"
                      using A25 A29 A33 arytm_0_th_21 sorry
                    also have "... = [*ARYTM-0K5 zz,oppARYTM-0K3 ( *ARYTM-0K2(j,invARYTM-0K4 y)) *]"
                      using A35 arytm_0_th_19 sorry
                    also have "... = [*ARYTM-0K5 zz,oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(y,invARYTM-0K4 y),invARYTM-0K4 y)) *]"
                      using A29 arytm_0_def_4 sorry
                    also have "... = [*ARYTM-0K5 zz,oppARYTM-0K3 ( *ARYTM-0K2(y, *ARYTM-0K2(invARYTM-0K4 y,invARYTM-0K4 y))) *]"
                      using arytm_0_th_13 sorry
                    also have "... = [*ARYTM-0K5 zz, *ARYTM-0K2(oppARYTM-0K3 y, *ARYTM-0K2(invARYTM-0K4 y,invARYTM-0K4 y)) *]"
                      using arytm_0_th_15 sorry
                    also have "... = [*ARYTM-0K5 zz, *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 ( *ARYTM-0K2(y,y))) *]"
                      using arytm_0_th_22 sorry
                    also have "... = [*ARYTM-0K5 zz, *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1(zz, *ARYTM-0K2(y,y)))) *]"
                      using arytm_0_th_11 sorry
                    also have "... = [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                      using A28 A34 arytm_0_th_12 sorry
                    finally show "z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                       sorry
                  qed
                  have case2: "oppARYTM-0K3 y =XBOOLE-0R4 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6 implies z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                  proof(rule impMI ,rule impI)
                    assume A36: "oppARYTM-0K3 y =XBOOLE-0R4 0NUMBERSK6"
                      and A37: "x <>HIDDENR2 0NUMBERSK6"
                    have "+ARYTM-0K1(y,oppARYTM-0K3 y) =XBOOLE-0R4 0NUMBERSK6"
                      using arytm_0_def_3 sorry
                    then have A38: "y =XBOOLE-0R4 0NUMBERSK6"
                      using A36 arytm_0_th_11 sorry
                    then have A39: " *ARYTM-0K2(y,x9) =XBOOLE-0R4 0NUMBERSK6"
                      using arytm_0_th_12 sorry
                    have "oppARYTM-0K3 ( *ARYTM-0K2(y,y9)) =HIDDENR1  *ARYTM-0K2(oppARYTM-0K3 y,y9)"
                      using arytm_0_th_15 sorry
                    also have "... = 0NUMBERSK6"
                      using A36 arytm_0_th_12 sorry
                    finally have "oppARYTM-0K3 ( *ARYTM-0K2(y,y9)) =HIDDENR1 0NUMBERSK6"
                       sorry
                    then have A40: "\<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,x9),+ARYTM-0K1( *ARYTM-0K2(x,y9),zz) *]"
                      using A26 A27 A39 arytm_0_th_11 sorry
                    also have "... = [*ARYTM-0K5  *ARYTM-0K2(x,x9), *ARYTM-0K2(x,y9) *]"
                      using arytm_0_th_11 sorry
                    finally have "\<one>\<^sub>M =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,x9), *ARYTM-0K2(x,y9) *]"
                       sorry
                    have A41: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 j,zz *]"
                      using arytm_0_def_5 sorry
                    then have " *ARYTM-0K2(x,x9) =XBOOLE-0R4 \<one>\<^sub>M"
                      using A40 arytm_0_th_10 sorry
                    then have A42: "x9 =XBOOLE-0R4 invARYTM-0K4 x"
                      using A37 arytm_0_def_4 sorry
                    have " *ARYTM-0K2(x,y9) =XBOOLE-0R4 0NUMBERSK6"
                      using A40 A41 arytm_0_th_10 sorry
                    then have A43: "y9 =XBOOLE-0R4 0NUMBERSK6"
                      using A37 arytm_0_th_21 sorry
                    have A44: " *ARYTM-0K2(y,y) =XBOOLE-0R4 0NUMBERSK6"
                      using A38 arytm_0_th_12 sorry
                    have "x9 =HIDDENR1  *ARYTM-0K2(j,invARYTM-0K4 x)"
                      using A42 arytm_0_th_19 sorry
                    also have "... =  *ARYTM-0K2( *ARYTM-0K2(x,invARYTM-0K4 x),invARYTM-0K4 x)"
                      using A37 arytm_0_def_4 sorry
                    also have "... =  *ARYTM-0K2(x, *ARYTM-0K2(invARYTM-0K4 x,invARYTM-0K4 x))"
                      using arytm_0_th_13 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 ( *ARYTM-0K2(x,x)))"
                      using arytm_0_th_22 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x),zz)))"
                      using arytm_0_th_11 sorry
                    finally have "x9 =HIDDENR1  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x),zz)))"
                       sorry
                    thus "z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                      using A25 A36 A43 A44 arytm_0_th_12 sorry
                  qed
                  have case3: "oppARYTM-0K3 y <>HIDDENR2 0NUMBERSK6 & x <>HIDDENR2 0NUMBERSK6 implies z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                  proof(rule impMI ,rule impI)
                    assume A45: "oppARYTM-0K3 y <>HIDDENR2 0NUMBERSK6"
                      and A46: "x <>HIDDENR2 0NUMBERSK6"
                    have A47: "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y) =XBOOLE-0R4 0NUMBERSK6 implies  False "
                    proof(rule impI)
                      assume "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y) =XBOOLE-0R4 0NUMBERSK6"
                      then have "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y), *ARYTM-0K2(oppARYTM-0K3 y,j)) =XBOOLE-0R4 0NUMBERSK6"
                        using arytm_0_th_19 sorry
                      then have "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y), *ARYTM-0K2(oppARYTM-0K3 y, *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 oppARYTM-0K3 y))) =XBOOLE-0R4 0NUMBERSK6"
                        using A45 arytm_0_def_4 sorry
                      then have "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y),invARYTM-0K4 oppARYTM-0K3 y)) =XBOOLE-0R4 0NUMBERSK6"
                        using arytm_0_th_13 sorry
                      then have A48: " *ARYTM-0K2(invARYTM-0K4 oppARYTM-0K3 y,+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))) =XBOOLE-0R4 0NUMBERSK6"
                        using arytm_0_th_14 sorry
                      have "+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y)) <>HIDDENR2 0NUMBERSK6"
                        using A46 arytm_0_th_17 sorry
                      then have A49: "invARYTM-0K4 oppARYTM-0K3 y =XBOOLE-0R4 0NUMBERSK6"
                        using A48 arytm_0_th_21 sorry
                      have " *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 oppARYTM-0K3 y) =XBOOLE-0R4 \<one>\<^sub>M"
                        using A45 arytm_0_def_4 sorry
                      thus " False "
                        using A49 arytm_0_th_12 sorry
                    qed
                    have A50: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 j,zz *]"
                      using arytm_0_def_5 sorry
                    then have "+ARYTM-0K1( *ARYTM-0K2(x1,y9), *ARYTM-0K2(x2,x9)) =XBOOLE-0R4 0NUMBERSK6"
                      using A26 arytm_0_th_10 sorry
                    then have " *ARYTM-0K2(x,y9) =XBOOLE-0R4 oppARYTM-0K3 ( *ARYTM-0K2(y,x9))"
                      using A27 arytm_0_def_3 sorry
                    then have " *ARYTM-0K2(x,y9) =XBOOLE-0R4  *ARYTM-0K2(oppARYTM-0K3 y,x9)"
                      using arytm_0_th_15 sorry
                    then have A51: "x9 =HIDDENR1  *ARYTM-0K2( *ARYTM-0K2(x,y9),invARYTM-0K4 oppARYTM-0K3 y)"
                      using A45 arytm_0_th_20 sorry
                    also have "... =  *ARYTM-0K2(x, *ARYTM-0K2(y9,invARYTM-0K4 oppARYTM-0K3 y))"
                      using arytm_0_th_13 sorry
                    finally have "x9 =HIDDENR1  *ARYTM-0K2(x, *ARYTM-0K2(y9,invARYTM-0K4 oppARYTM-0K3 y))"
                       sorry
                    then have "+ARYTM-0K1( *ARYTM-0K2(x, *ARYTM-0K2(x, *ARYTM-0K2(y9,invARYTM-0K4 oppARYTM-0K3 y))),oppARYTM-0K3 ( *ARYTM-0K2(y,y9))) =XBOOLE-0R4 \<one>\<^sub>M"
                      using A26 A27 A50 arytm_0_th_10 sorry
                    then have "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x), *ARYTM-0K2(y9,invARYTM-0K4 oppARYTM-0K3 y)),oppARYTM-0K3 ( *ARYTM-0K2(y,y9))) =XBOOLE-0R4 \<one>\<^sub>M"
                      using arytm_0_th_13 sorry
                    then have "+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x), *ARYTM-0K2(y9,invARYTM-0K4 oppARYTM-0K3 y)), *ARYTM-0K2(oppARYTM-0K3 y,y9)) =XBOOLE-0R4 \<one>\<^sub>M"
                      using arytm_0_th_15 sorry
                    then have "+ARYTM-0K1( *ARYTM-0K2(y9, *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y)), *ARYTM-0K2(oppARYTM-0K3 y,y9)) =XBOOLE-0R4 \<one>\<^sub>M"
                      using arytm_0_th_13 sorry
                    then have " *ARYTM-0K2(y9,+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y)) =XBOOLE-0R4 \<one>\<^sub>M"
                      using arytm_0_th_14 sorry
                    then have A52: "y9 =XBOOLE-0R4 invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y))"
                      using A47 arytm_0_def_4 sorry
                    then have A53: "x9 =HIDDENR1  *ARYTM-0K2(x,invARYTM-0K4 ( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y),oppARYTM-0K3 y)))"
                      using A51 arytm_0_th_22 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))))"
                      using arytm_0_th_14 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y),oppARYTM-0K3 ( *ARYTM-0K2(y,oppARYTM-0K3 y)))))"
                      using arytm_0_th_15 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y),oppARYTM-0K3 (oppARYTM-0K3 ( *ARYTM-0K2(y,y))))))"
                      using arytm_0_th_15 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x), *ARYTM-0K2(invARYTM-0K4 oppARYTM-0K3 y,oppARYTM-0K3 y)), *ARYTM-0K2(y,y))))"
                      using arytm_0_th_13 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),j), *ARYTM-0K2(y,y))))"
                      using A45 arytm_0_def_4 sorry
                    also have "... =  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                      using arytm_0_th_19 sorry
                    finally have "x9 =HIDDENR1  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                       sorry
                    have "y9 =HIDDENR1  *ARYTM-0K2(j,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y)))"
                      using A52 arytm_0_th_19 sorry
                    also have "... =  *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 oppARYTM-0K3 y),invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y)))"
                      using A45 arytm_0_def_4 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y, *ARYTM-0K2(invARYTM-0K4 oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y))))"
                      using arytm_0_th_13 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 ( *ARYTM-0K2(oppARYTM-0K3 y,+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y),oppARYTM-0K3 y))))"
                      using arytm_0_th_22 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 y, *ARYTM-0K2( *ARYTM-0K2(x,x),invARYTM-0K4 oppARYTM-0K3 y)), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))))"
                      using arytm_0_th_14 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 oppARYTM-0K3 y)), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))))"
                      using arytm_0_th_13 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x,x),j), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))))"
                      using A45 arytm_0_def_4 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(oppARYTM-0K3 y,oppARYTM-0K3 y))))"
                      using arytm_0_th_19 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x),oppARYTM-0K3 ( *ARYTM-0K2(y,oppARYTM-0K3 y)))))"
                      using arytm_0_th_15 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x),oppARYTM-0K3 (oppARYTM-0K3 ( *ARYTM-0K2(y,y))))))"
                      using arytm_0_th_15 sorry
                    also have "... =  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                       sorry
                    finally have "y9 =HIDDENR1  *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y))))"
                       sorry
                    thus "z9 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                      using A25 A53 sorry
                  qed
                  show " ?thesis "
                    using cases case1 case2 case3 sorry
                qed
              qed "sorry"
              then have "c1 =HIDDENR1 [*ARYTM-0K5  *ARYTM-0K2(x,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))), *ARYTM-0K2(oppARYTM-0K3 y,invARYTM-0K4 (+ARYTM-0K1( *ARYTM-0K2(x,x), *ARYTM-0K2(y,y)))) *]"
                using A20 sorry
              also have "... = c2"
                using A21 A22 sorry
              finally show "c1 =HIDDENR1 c2"
                 sorry
            qed
            thus " ?thesis "
               sorry
          qed
          show " not (((z <>HIDDENR2 0NUMBERSK6 & c1 =HIDDENR1 0NUMBERSK6) & c2 =HIDDENR1 0NUMBERSK6) &  not c1 =HIDDENR1 c2)"
             sorry
        qed "sorry"
        thus " ?thesis "
           sorry
      qed
    qed
  (*consistency*)
    show " for it be ComplexXCMPLX-0M1 holds  True "
    proof-
      have "z inHIDDENR3 COMPLEXNUMBERSK3"
        using xcmplx_0_def_2 sorry
      then obtain x y where
        [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
        using arytm_0_th_9 sorry
      show " for it be ComplexXCMPLX-0M1 holds  True "
         sorry
    qed
qed "sorry"

mtheorem XCMPLX_0K5_involutiveness:
" for z be ComplexXCMPLX-0M1 holds (z \<inverse>XCMPLX-0K5)\<inverse>XCMPLX-0K5 =HIDDENR1 z"
proof-
  have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds it =HIDDENR1 z \<inverse>XCMPLX-0K5 implies z =HIDDENR1 it \<inverse>XCMPLX-0K5"
  proof-
    have "z inHIDDENR3 COMPLEXNUMBERSK3"
      using xcmplx_0_def_2 sorry
    then obtain x y where
      [ty]:"x be ElementSUBSET-1M1-of REALNUMBERSK2" "y be ElementSUBSET-1M1-of REALNUMBERSK2" and 
      A1: "z =HIDDENR1 [*ARYTM-0K5 x,y *]"
      using arytm_0_th_9 sorry
    have " for it be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds (z <>HIDDENR2 0NUMBERSK6 implies z *XCMPLX-0K3 it =XBOOLE-0R4 \<one>\<^sub>M) & ( not z <>HIDDENR2 0NUMBERSK6 implies it =HIDDENR1 0NUMBERSK6) implies (it <>HIDDENR2 0NUMBERSK6 implies it *XCMPLX-0K3 z =XBOOLE-0R4 \<one>\<^sub>M) & ( not it <>HIDDENR2 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6)"
    proof-
      have " for z be ComplexXCMPLX-0M1 holds  for z9 be ComplexXCMPLX-0M1 holds (z9 <>HIDDENR2 0NUMBERSK6 implies z9 *XCMPLX-0K3 z =XBOOLE-0R4 \<one>\<^sub>M) & (z9 =HIDDENR1 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6) implies (z <>HIDDENR2 0NUMBERSK6 implies z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M) & (z =HIDDENR1 0NUMBERSK6 implies (z9 <>HIDDENR2 0NUMBERSK6 implies  False ))"
      proof(rule ballI,rule ballI,rule impMI ,rule impI,rule conjMI,rule impI,rule impI)
        fix z assume [ty]: "z be ComplexXCMPLX-0M1"
        fix z9 assume [ty]: "z9 be ComplexXCMPLX-0M1"
        have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
           sorry
        then obtain zz where 
          [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
          using numbers_th_19 sorry
        assume A54: "z9 <>HIDDENR2 0NUMBERSK6 implies z9 *XCMPLX-0K3 z =XBOOLE-0R4 \<one>\<^sub>M"
          and A55: "z9 =HIDDENR1 0NUMBERSK6 implies z =HIDDENR1 0NUMBERSK6"
        show "z <>HIDDENR2 0NUMBERSK6 implies z *XCMPLX-0K3 z9 =XBOOLE-0R4 \<one>\<^sub>M"
          using A54 A55 sorry
        assume A56: "z =HIDDENR1 0NUMBERSK6"
        assume "z9 <>HIDDENR2 0NUMBERSK6"
        then obtain x1 x2 y1 y2 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A57: "z =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and "z9 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A58: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
          using A54 xcmplx_0_def_5 sorry
        have A59: "z =HIDDENR1 [*ARYTM-0K5 zz,zz *]"
          using A56 arytm_0_def_5 sorry
        then have A60: "x1 =XBOOLE-0R4 0NUMBERSK6"
          using A57 arytm_0_th_10 sorry
        have A61: "x2 =XBOOLE-0R4 0NUMBERSK6"
          using A57 A59 arytm_0_th_10 sorry
        have A62: " *ARYTM-0K2(x1,y1) =XBOOLE-0R4 0NUMBERSK6"
          using A60 arytm_0_th_12 sorry
        have " *ARYTM-0K2(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
          using A61 arytm_0_th_12 sorry
        then have A63: "+ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))) =XBOOLE-0R4 0NUMBERSK6"
          using A62 arytm_0_def_3 sorry
        have A64: " *ARYTM-0K2(x1,y2) =XBOOLE-0R4 0NUMBERSK6"
          using A60 arytm_0_th_12 sorry
        have " *ARYTM-0K2(x2,y1) =XBOOLE-0R4 0NUMBERSK6"
          using A61 arytm_0_th_12 sorry
        then have "+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) =XBOOLE-0R4 0NUMBERSK6"
          using A64 arytm_0_th_11 sorry
        thus " False "
          using A58 A63 arytm_0_def_5 sorry
      qed "sorry"
      thus " ?thesis "
         sorry
    qed
    thus " ?thesis "
      using xcmplx_0_def_7 sorry
  qed
  thus " ?thesis "
     sorry
qed

mdef xcmplx_0_def_8 (" _ -XCMPLX-0K6  _ " [132,132]132 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x -XCMPLX-0K6 y \<rightarrow> numberORDINAL1M2 equals
  x +XCMPLX-0K2 (-XCMPLX-0K4 y)"
proof-
  (*coherence*)
    show "x +XCMPLX-0K2 (-XCMPLX-0K4 y) be numberORDINAL1M2"
       sorry
qed "sorry"

mdef xcmplx_0_def_9 (" _ '/XCMPLX-0K7  _ " [164,164]164 ) where
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"func x /XCMPLX-0K7 y \<rightarrow> numberORDINAL1M2 equals
  x *XCMPLX-0K3 y \<inverse>XCMPLX-0K5"
proof-
  (*coherence*)
    show "x *XCMPLX-0K3 y \<inverse>XCMPLX-0K5 be numberORDINAL1M2"
       sorry
qed "sorry"

mtheorem xcmplx_0_cl_6:
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"cluster x -XCMPLX-0K6 y as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "x -XCMPLX-0K6 y be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem xcmplx_0_cl_7:
  mlet "x be ComplexXCMPLX-0M1", "y be ComplexXCMPLX-0M1"
"cluster x /XCMPLX-0K7 y as-term-is complexXCMPLX-0V1"
proof
(*coherence*)
  show "x /XCMPLX-0K7 y be complexXCMPLX-0V1"
     sorry
qed "sorry"

mlemma xcmplx_0_lm_4:
" for x be ComplexXCMPLX-0M1 holds  for y be ComplexXCMPLX-0M1 holds  for z be ComplexXCMPLX-0M1 holds x *XCMPLX-0K3 (y *XCMPLX-0K3 z) =XBOOLE-0R4 (x *XCMPLX-0K3 y)*XCMPLX-0K3 z"
proof(rule ballI,rule ballI,rule ballI)
  fix x assume [ty]: "x be ComplexXCMPLX-0M1"
  fix y assume [ty]: "y be ComplexXCMPLX-0M1"
  fix z assume [ty]: "z be ComplexXCMPLX-0M1"
  obtain x1 x2 y1 y2 where
    [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A1: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A2: "y =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A3: "x *XCMPLX-0K3 y =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
    using xcmplx_0_def_5 sorry
  obtain y3 y4 z1 z2 where
    [ty]:"y3 be ElementSUBSET-1M1-of REALNUMBERSK2" "y4 be ElementSUBSET-1M1-of REALNUMBERSK2" "z1 be ElementSUBSET-1M1-of REALNUMBERSK2" "z2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A4: "y =HIDDENR1 [*ARYTM-0K5 y3,y4 *]"and A5: "z =HIDDENR1 [*ARYTM-0K5 z1,z2 *]"and A6: "y *XCMPLX-0K3 z =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(y3,z1),oppARYTM-0K3 ( *ARYTM-0K2(y4,z2))),+ARYTM-0K1( *ARYTM-0K2(y3,z2), *ARYTM-0K2(y4,z1)) *]"
    using xcmplx_0_def_5 sorry
  have A7: "y1 =XBOOLE-0R4 y3"
    using A2 A4 arytm_0_th_10 sorry
  have A8: "y2 =XBOOLE-0R4 y4"
    using A2 A4 arytm_0_th_10 sorry
  obtain x3 x4 yz1 yz2 where
    [ty]:"x3 be ElementSUBSET-1M1-of REALNUMBERSK2" "x4 be ElementSUBSET-1M1-of REALNUMBERSK2" "yz1 be ElementSUBSET-1M1-of REALNUMBERSK2" "yz2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A9: "x =HIDDENR1 [*ARYTM-0K5 x3,x4 *]"and A10: "y *XCMPLX-0K3 z =XBOOLE-0R4 [*ARYTM-0K5 yz1,yz2 *]"and A11: "x *XCMPLX-0K3 (y *XCMPLX-0K3 z) =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x3,yz1),oppARYTM-0K3 ( *ARYTM-0K2(x4,yz2))),+ARYTM-0K1( *ARYTM-0K2(x3,yz2), *ARYTM-0K2(x4,yz1)) *]"
    using xcmplx_0_def_5 sorry
  have A12: "x1 =XBOOLE-0R4 x3"
    using A1 A9 arytm_0_th_10 sorry
  have A13: "x2 =XBOOLE-0R4 x4"
    using A1 A9 arytm_0_th_10 sorry
  obtain xy1 xy2 z3 z4 where
    [ty]:"xy1 be ElementSUBSET-1M1-of REALNUMBERSK2" "xy2 be ElementSUBSET-1M1-of REALNUMBERSK2" "z3 be ElementSUBSET-1M1-of REALNUMBERSK2" "z4 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
    A14: "x *XCMPLX-0K3 y =XBOOLE-0R4 [*ARYTM-0K5 xy1,xy2 *]"and A15: "z =HIDDENR1 [*ARYTM-0K5 z3,z4 *]"and A16: "(x *XCMPLX-0K3 y)*XCMPLX-0K3 z =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(xy1,z3),oppARYTM-0K3 ( *ARYTM-0K2(xy2,z4))),+ARYTM-0K1( *ARYTM-0K2(xy1,z4), *ARYTM-0K2(xy2,z3)) *]"
    using xcmplx_0_def_5 sorry
  have A17: "z1 =XBOOLE-0R4 z3"
    using A5 A15 arytm_0_th_10 sorry
  have A18: "z2 =XBOOLE-0R4 z4"
    using A5 A15 arytm_0_th_10 sorry
  have A19: "xy1 =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
    using A3 A14 arytm_0_th_10 sorry
  have A20: "xy2 =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1))"
    using A3 A14 arytm_0_th_10 sorry
  have A21: "yz1 =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(y3,z1),oppARYTM-0K3 ( *ARYTM-0K2(y4,z2)))"
    using A6 A10 arytm_0_th_10 sorry
  have A22: "yz2 =XBOOLE-0R4 +ARYTM-0K1( *ARYTM-0K2(y3,z2), *ARYTM-0K2(y4,z1))"
    using A6 A10 arytm_0_th_10 sorry
  have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1)), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4))"
    using A7 A13 A18 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4))"
    using A8 A13 A17 arytm_0_th_13 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4))"
     sorry
  then have A23: "+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(oppARYTM-0K3 y4,z2)),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1)))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,oppARYTM-0K3 y2),z4),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using A8 A12 A18 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x1,y2)),z4),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using arytm_0_th_23 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(oppARYTM-0K3 y4,z2)),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1)))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
     sorry
  have A24: "+ARYTM-0K1( *ARYTM-0K2(x3,yz1),oppARYTM-0K3 ( *ARYTM-0K2(x4,yz2))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x3,yz1), *ARYTM-0K2(oppARYTM-0K3 x4,yz2))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3,+ARYTM-0K1( *ARYTM-0K2(y3,z1), *ARYTM-0K2(oppARYTM-0K3 y4,z2))), *ARYTM-0K2(oppARYTM-0K3 x4,yz2))"
    using A21 arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z1)), *ARYTM-0K2(x3, *ARYTM-0K2(oppARYTM-0K3 y4,z2))), *ARYTM-0K2(oppARYTM-0K3 x4,+ARYTM-0K1( *ARYTM-0K2(y3,z2), *ARYTM-0K2(y4,z1))))"
    using A22 arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z1)), *ARYTM-0K2(x3, *ARYTM-0K2(oppARYTM-0K3 y4,z2))),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(oppARYTM-0K3 x4, *ARYTM-0K2(y4,z1))))"
    using arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z1)),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4))))"
    using A23 arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z1)), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3)),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y1),z3), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y2),z3)),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using A7 A12 A17 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x2,y1),z4)))"
    using arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4), *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y1)),z4)))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(oppARYTM-0K3 x1,y2),z4),oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x2,y1),z4))))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x1,y2)),z4),oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x2,y1),z4))))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),+ARYTM-0K1(oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x1,y2),z4)),oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x2,y1),z4))))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),oppARYTM-0K3 (+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y2),z4), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z4))))"
    using arytm_0_th_25 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3),oppARYTM-0K3 ( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)),z4)))"
    using arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(+ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2)),z3), *ARYTM-0K2(oppARYTM-0K3 xy2,z4))"
    using A20 arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(xy1,z3), *ARYTM-0K2(oppARYTM-0K3 xy2,z4))"
    using A19 arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(xy1,z3),oppARYTM-0K3 ( *ARYTM-0K2(xy2,z4)))"
    using arytm_0_th_15 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(x3,yz1),oppARYTM-0K3 ( *ARYTM-0K2(x4,yz2))) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(xy1,z3),oppARYTM-0K3 ( *ARYTM-0K2(xy2,z4)))"
     sorry
  have A25: "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z3)) =HIDDENR1 +ARYTM-0K1(oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x2,y2),z4)), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z3))"
    using arytm_0_th_15 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x4, *ARYTM-0K2(y3,z1)),oppARYTM-0K3 ( *ARYTM-0K2( *ARYTM-0K2(x2,y2),z4)))"
    using A7 A13 A17 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x4, *ARYTM-0K2(y3,z1)),oppARYTM-0K3 ( *ARYTM-0K2(x4, *ARYTM-0K2(y4,z2))))"
    using A8 A13 A18 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x4, *ARYTM-0K2(y3,z1)), *ARYTM-0K2(x4,oppARYTM-0K3 ( *ARYTM-0K2(y4,z2))))"
    using arytm_0_th_15 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z3)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x4, *ARYTM-0K2(y3,z1)), *ARYTM-0K2(x4,oppARYTM-0K3 ( *ARYTM-0K2(y4,z2))))"
     sorry
  have A26: "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2(xy2,z3)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4),+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y2),z3), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z3)))"
    using A20 arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y2),z3),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2( *ARYTM-0K2(x2,y1),z3)))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y4,z1)),+ARYTM-0K1( *ARYTM-0K2(x4, *ARYTM-0K2(y3,z1)), *ARYTM-0K2(x4,oppARYTM-0K3 ( *ARYTM-0K2(y4,z2)))))"
    using A8 A12 A17 A25 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y4,z1)), *ARYTM-0K2(x4,yz1))"
    using A21 arytm_0_th_14 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2(xy2,z3)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y4,z1)), *ARYTM-0K2(x4,yz1))"
     sorry
  have "+ARYTM-0K1( *ARYTM-0K2(xy1,z4), *ARYTM-0K2(xy2,z3)) =HIDDENR1 +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y1),z4), *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4)), *ARYTM-0K2(xy2,z3))"
    using A19 arytm_0_th_14 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2( *ARYTM-0K2(x1,y1),z4),+ARYTM-0K1( *ARYTM-0K2(oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)),z4), *ARYTM-0K2(xy2,z3)))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z2)),+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y4,z1)), *ARYTM-0K2(x4,yz1)))"
    using A7 A12 A18 A26 arytm_0_th_13 sorry
  also have "... = +ARYTM-0K1(+ARYTM-0K1( *ARYTM-0K2(x3, *ARYTM-0K2(y3,z2)), *ARYTM-0K2(x3, *ARYTM-0K2(y4,z1))), *ARYTM-0K2(x4,yz1))"
    using arytm_0_th_23 sorry
  also have "... = +ARYTM-0K1( *ARYTM-0K2(x3,yz2), *ARYTM-0K2(x4,yz1))"
    using A22 arytm_0_th_14 sorry
  finally have "+ARYTM-0K1( *ARYTM-0K2(xy1,z4), *ARYTM-0K2(xy2,z3)) =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x3,yz2), *ARYTM-0K2(x4,yz1))"
     sorry
  thus "x *XCMPLX-0K3 (y *XCMPLX-0K3 z) =XBOOLE-0R4 (x *XCMPLX-0K3 y)*XCMPLX-0K3 z"
    using A11 A16 A24 sorry
qed "sorry"

mtheorem xcmplx_0_cl_8:
"cluster naturalORDINAL1V7 also-is complexXCMPLX-0V1 for objectHIDDENM1"
proof
(*coherence*)
  show " for it be objectHIDDENM1 holds it be naturalORDINAL1V7 implies it be complexXCMPLX-0V1"
    using numbers_th_20 sorry
qed "sorry"

mlemma xcmplx_0_lm_5:
"\<one>\<^sub>M be ComplexXCMPLX-0M1"
   sorry

mtheorem xcmplx_0_cl_9:
"cluster zeroORDINAL1V8 for ComplexXCMPLX-0M1"
proof
(*existence*)
  show " ex it be ComplexXCMPLX-0M1 st it be zeroORDINAL1V8"
  proof-
    have " ex tVar8 be ComplexXCMPLX-0M1 st tVar8 be zeroORDINAL1V8"
    proof-
      show " ex tVar8 be ComplexXCMPLX-0M1 st tVar8 be zeroORDINAL1V8"
      proof(rule bexI[of _ "0NUMBERSK6"])
        show "0NUMBERSK6 be zeroORDINAL1V8"
           sorry
      qed "sorry"
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_10:
"cluster  non zeroORDINAL1V8 for ComplexXCMPLX-0M1"
proof
(*existence*)
  show " ex it be ComplexXCMPLX-0M1 st it be  non zeroORDINAL1V8"
    using xcmplx_0_lm_5 sorry
qed "sorry"

mtheorem xcmplx_0_cl_11:
"cluster  non zeroORDINAL1V8 for ComplexXCMPLX-0M1"
proof
(*existence*)
  show " ex it be ComplexXCMPLX-0M1 st it be  non zeroORDINAL1V8"
    using xcmplx_0_lm_5 sorry
qed "sorry"

mlemma xcmplx_0_lm_6:
"REALNUMBERSK2 c=TARSKIR1 COMPLEXNUMBERSK3"
  using numbers_def_2 xboole_1_th_7 sorry

mtheorem xcmplx_0_cl_12:
  mlet "x be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster -XCMPLX-0K4 x as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "-XCMPLX-0K4 x be  non zeroORDINAL1V8"
  proof-
    have " not -XCMPLX-0K4 x be zeroORDINAL1V8"
    proof-
      have "-XCMPLX-0K4 x =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A1: "-XCMPLX-0K4 x =HIDDENR1 0NUMBERSK6"
        have "x +XCMPLX-0K2 (-XCMPLX-0K4 x) =XBOOLE-0R4 0NUMBERSK6"
          using xcmplx_0_def_6 sorry
        then obtain x1 x2 y1 y2 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          A2: "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A3: "-XCMPLX-0K4 x =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A4: "InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2) =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1(x1,y1),+ARYTM-0K1(x2,y2) *]"
          using xcmplx_0_def_4 xcmplx_0_lm_1 sorry
        have A5: "+ARYTM-0K1(x2,y2) =XBOOLE-0R4 0NUMBERSK6"
          using A4 arytm_0_th_24 sorry
        then have A6: "+ARYTM-0K1(x1,y1) =XBOOLE-0R4 0NUMBERSK6"
          using A4 arytm_0_def_5 xcmplx_0_lm_1 sorry
        have "y2 =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
          using A1 A3 arytm_0_th_24 xcmplx_0_lm_1 sorry
        then have A7: "y1 =XBOOLE-0R4 0NUMBERSK6"
          using A1 A3 arytm_0_def_5 xcmplx_0_lm_1 sorry
        have "x2 =XBOOLE-0R4 0NUMBERSK6"
          using A1 A3 A5 arytm_0_th_11 arytm_0_th_24 sorry
        then have "x =HIDDENR1 x1"
          using A2 arytm_0_def_5 sorry
        also have "... = 0NUMBERSK6"
          using A6 A7 arytm_0_th_11 sorry
        finally have "x =HIDDENR1 0NUMBERSK6"
           sorry
        thus " False "
           sorry
      qed
      thus " not -XCMPLX-0K4 x be zeroORDINAL1V8"
        using ordinal1_def_14 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_13:
  mlet "x be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster x \<inverse>XCMPLX-0K5 as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "x \<inverse>XCMPLX-0K5 be  non zeroORDINAL1V8"
  proof-
    have " not x \<inverse>XCMPLX-0K5 be zeroORDINAL1V8"
    proof-
      have "x \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A8: "x \<inverse>XCMPLX-0K5 =HIDDENR1 0NUMBERSK6"
        then have A9: "x \<inverse>XCMPLX-0K5 =HIDDENR1 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
          using xcmplx_0_lm_1 sorry
        have "x *XCMPLX-0K3 x \<inverse>XCMPLX-0K5 =XBOOLE-0R4 \<one>\<^sub>M"
          using xcmplx_0_def_7 sorry
        then obtain x1 x2 y1 y2 where
          [ty]:"x1 be ElementSUBSET-1M1-of REALNUMBERSK2" "x2 be ElementSUBSET-1M1-of REALNUMBERSK2" "y1 be ElementSUBSET-1M1-of REALNUMBERSK2" "y2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
          "x =HIDDENR1 [*ARYTM-0K5 x1,x2 *]"and A10: "x \<inverse>XCMPLX-0K5 =HIDDENR1 [*ARYTM-0K5 y1,y2 *]"and A11: "\<one>\<^sub>M =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2))),+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) *]"
          using xcmplx_0_def_5 sorry
        have "y2 =XBOOLE-0R4 InSUBSET-1K10(0NUMBERSK6,REALNUMBERSK2)"
          using A8 A10 arytm_0_th_24 xcmplx_0_lm_1 sorry
        then have A12: "y1 =XBOOLE-0R4 0NUMBERSK6"
          using A8 A10 arytm_0_def_5 xcmplx_0_lm_1 sorry
        have "+ARYTM-0K1( *ARYTM-0K2(x1,y2), *ARYTM-0K2(x2,y1)) =XBOOLE-0R4 0NUMBERSK6"
          using A11 arytm_0_th_24 xcmplx_0_lm_2 sorry
        then have "\<one>\<^sub>M =HIDDENR1 +ARYTM-0K1( *ARYTM-0K2(x1,y1),oppARYTM-0K3 ( *ARYTM-0K2(x2,y2)))"
          using A11 arytm_0_def_5 sorry
        also have "... = +ARYTM-0K1( *ARYTM-0K2(x1,y1), *ARYTM-0K2(oppARYTM-0K3 x2,y2))"
          using arytm_0_th_15 sorry
        also have "... =  *ARYTM-0K2(oppARYTM-0K3 x2,y2)"
          using A12 arytm_0_th_11 arytm_0_th_12 sorry
        finally have "\<one>\<^sub>M =HIDDENR1  *ARYTM-0K2(oppARYTM-0K3 x2,y2)"
           sorry
        thus " False "
          using A10 arytm_0_th_12 arytm_0_th_24 A9 sorry
      qed
      thus " not x \<inverse>XCMPLX-0K5 be zeroORDINAL1V8"
        using ordinal1_def_14 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_14:
  mlet "x be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1", "y be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster x *XCMPLX-0K3 y as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "x *XCMPLX-0K3 y be  non zeroORDINAL1V8"
  proof-
    have " not x *XCMPLX-0K3 y be zeroORDINAL1V8"
    proof-
      let ?j = "\<one>\<^sub>M"
      have "0NUMBERSK6 inTARSKIR2 NATNUMBERSK1"
         sorry
      then obtain zz where 
        [ty]:"zz be ElementSUBSET-1M1-of REALNUMBERSK2" and zzDef:"zz = 0NUMBERSK6"
        using numbers_th_19 sorry
      obtain u1 u2 v1 v2 where
        [ty]:"u1 be ElementSUBSET-1M1-of REALNUMBERSK2" "u2 be ElementSUBSET-1M1-of REALNUMBERSK2" "v1 be ElementSUBSET-1M1-of REALNUMBERSK2" "v2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        A13: "?j =XBOOLE-0R4 [*ARYTM-0K5 u1,u2 *]"and A14: "y =HIDDENR1 [*ARYTM-0K5 v1,v2 *] & ?j *XCMPLX-0K3 y =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))),+ARYTM-0K1( *ARYTM-0K2(u1,v2), *ARYTM-0K2(u2,v1)) *]"
        using xcmplx_0_def_5 sorry
      have A15: "u2 =XBOOLE-0R4 0NUMBERSK6"
        using A13 arytm_0_th_24 xcmplx_0_lm_2 sorry
      then have A16: "+ARYTM-0K1( *ARYTM-0K2(u1,v2), *ARYTM-0K2(u2,v1)) =XBOOLE-0R4  *ARYTM-0K2(u1,v2)"
        using arytm_0_th_11 arytm_0_th_12 sorry
      have A17: "u1 =XBOOLE-0R4 \<one>\<^sub>M"
        using A13 A15 arytm_0_def_5 sorry
      have "+ARYTM-0K1(zz,oppARYTM-0K3 zz) =XBOOLE-0R4 0NUMBERSK6"
        using arytm_0_def_3 sorry
      then have A18: "oppARYTM-0K3 zz =XBOOLE-0R4 0NUMBERSK6"
        using arytm_0_th_11 sorry
      have A19: "+ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))) =HIDDENR1 +ARYTM-0K1(v1,oppARYTM-0K3 ( *ARYTM-0K2(u2,v2)))"
        using A17 arytm_0_th_19 sorry
      also have "... = +ARYTM-0K1(v1, *ARYTM-0K2(oppARYTM-0K3 u2,v2))"
        using arytm_0_th_15 sorry
      also have "... = +ARYTM-0K1(v1, *ARYTM-0K2(zz,v2))"
        using A13 A18 arytm_0_th_24 xcmplx_0_lm_2 sorry
      also have "... = v1"
        using arytm_0_th_11 arytm_0_th_12 sorry
      finally have "+ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))) =HIDDENR1 v1"
         sorry
      let ?z = "0NUMBERSK6"
      obtain u1 u2 v1 v2 where
        [ty]:"u1 be ElementSUBSET-1M1-of REALNUMBERSK2" "u2 be ElementSUBSET-1M1-of REALNUMBERSK2" "v1 be ElementSUBSET-1M1-of REALNUMBERSK2" "v2 be ElementSUBSET-1M1-of REALNUMBERSK2" and 
        "x \<inverse>XCMPLX-0K5 =HIDDENR1 [*ARYTM-0K5 u1,u2 *]"and A20: "?z =XBOOLE-0R4 [*ARYTM-0K5 v1,v2 *]"and A21: "x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 ?z =XBOOLE-0R4 [*ARYTM-0K5 +ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))),+ARYTM-0K1( *ARYTM-0K2(u1,v2), *ARYTM-0K2(u2,v1)) *]"
        using xcmplx_0_def_5 sorry
      have "v2 =XBOOLE-0R4 zz"
        using A20 arytm_0_th_24 sorry
      then have A22: "v1 =XBOOLE-0R4 0NUMBERSK6"
        using A20 arytm_0_def_5 sorry
      then have A23: "+ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))) =HIDDENR1 oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))"
        using arytm_0_th_11 arytm_0_th_12 sorry
      also have "... = 0NUMBERSK6"
        using A18 A20 arytm_0_th_12 arytm_0_th_24 sorry
      finally have "+ARYTM-0K1( *ARYTM-0K2(u1,v1),oppARYTM-0K3 ( *ARYTM-0K2(u2,v2))) =HIDDENR1 0NUMBERSK6"
         sorry
      have A24: "+ARYTM-0K1( *ARYTM-0K2(u1,v2), *ARYTM-0K2(u2,v1)) =HIDDENR1 +ARYTM-0K1(zz, *ARYTM-0K2(u2,v1))"
        using A20 arytm_0_th_12 arytm_0_th_24 sorry
      also have "... =  *ARYTM-0K2(u2,v1)"
        using arytm_0_th_11 sorry
      also have "... = 0NUMBERSK6"
        using A22 arytm_0_th_12 sorry
      finally have "+ARYTM-0K1( *ARYTM-0K2(u1,v2), *ARYTM-0K2(u2,v1)) =HIDDENR1 0NUMBERSK6"
         sorry
      have "x *XCMPLX-0K3 y =XBOOLE-0R4 0NUMBERSK6 implies  False "
      proof(rule impI)
        assume A25: "x *XCMPLX-0K3 y =XBOOLE-0R4 0NUMBERSK6"
        have A26: "(x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 x)*XCMPLX-0K3 y =HIDDENR1 x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 (x *XCMPLX-0K3 y)"
          using xcmplx_0_lm_4 sorry
        also have "... = 0NUMBERSK6"
          using A21 A23 A24 A25 arytm_0_def_5 sorry
        finally have "(x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 x)*XCMPLX-0K3 y =HIDDENR1 0NUMBERSK6"
           sorry
        have "(x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 x)*XCMPLX-0K3 y =HIDDENR1 ?j *XCMPLX-0K3 y"
          using xcmplx_0_def_7 sorry
        also have "... = y"
          using A14 A16 A17 A19 arytm_0_th_19 sorry
        finally have "(x \<inverse>XCMPLX-0K5 *XCMPLX-0K3 x)*XCMPLX-0K3 y =HIDDENR1 y"
           sorry
        thus " False "
          using A26 sorry
      qed
      thus " not x *XCMPLX-0K3 y be zeroORDINAL1V8"
        using ordinal1_def_14 sorry
    qed
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_15:
  mlet "x be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1", "y be  non zeroORDINAL1V8\<bar>ComplexXCMPLX-0M1"
"cluster x /XCMPLX-0K7 y as-term-is  non zeroORDINAL1V8"
proof
(*coherence*)
  show "x /XCMPLX-0K7 y be  non zeroORDINAL1V8"
     sorry
qed "sorry"

mtheorem xcmplx_0_cl_16:
"cluster note-that complexXCMPLX-0V1 for ElementSUBSET-1M1-of REALNUMBERSK2"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of REALNUMBERSK2 holds it be complexXCMPLX-0V1"
  proof-
    have " for n be ElementSUBSET-1M1-of REALNUMBERSK2 holds n be complexXCMPLX-0V1"
    proof(rule ballI)
      fix n assume [ty]: "n be ElementSUBSET-1M1-of REALNUMBERSK2"
      have "n inTARSKIR2 REALNUMBERSK2"
         sorry
      thus "n be complexXCMPLX-0V1"
        using xcmplx_0_lm_6 sorry
    qed "sorry"
    thus " ?thesis "
       sorry
  qed
qed "sorry"

mtheorem xcmplx_0_cl_17:
"cluster note-that complexXCMPLX-0V1 for ElementSUBSET-1M1-of COMPLEXNUMBERSK3"
proof
(*coherence*)
  show " for it be ElementSUBSET-1M1-of COMPLEXNUMBERSK3 holds it be complexXCMPLX-0V1"
     sorry
qed "sorry"

mtheorem xcmplx_0_reduce_1:
  mlet "i be ComplexXCMPLX-0M1"
"reduce InSUBSET-1K10(i,COMPLEXNUMBERSK3) to i"
proof
(*reducibility*)
  show "InSUBSET-1K10(i,COMPLEXNUMBERSK3) =HIDDENR1 i"
    using xcmplx_0_def_2 subset_1_def_8 sorry
qed "sorry"

end
